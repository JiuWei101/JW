//$(function(){
//	$.fn.datebox.defaults.formatter = function(date){
//		var y = date.getFullYear();
//		var m = date.getMonth()+1;
//		var d = date.getDate();
//		return y+"-"+(m<10?('0'+m):m)+"-"+(d<10?('0'+d):d);
//	}
//	$.fn.datebox.defaults.parser = function(s){ 
//        if (!s) return new Date(); 
//        var ss = s.split('-'); 
//        var y = parseInt(ss[0],10); 
//        var m = parseInt(ss[1],10); 
//        var d = parseInt(ss[2],10); 
//        if (!isNaN(y) && !isNaN(m) && !isNaN(d)){ 
//            return new Date(y,m-1,d); 
//        } else { 
//            return new Date(); 
//        } 
//    };
//	//初始化日期控件
//	$("#startDate,#endDate").datebox({
//		editable:false
//	});
//	
//});
function operate(str,id){
	var startDate = $("#startDate").val();
	var endDate = $("#endDate").val();
	if('list' == str){//查询
		if(startDate !='' && endDate !=''){
			if(!compareTime(startDate,endDate)){
				alert($('#sedatenote').val());
				return;
			}
		}
		document.listform.action = "../log/operatorLog_list.action";
		document.listform.submit();
	}else if('delete' == str){//删除
    	if(!checkChk()){
    		alert($("#alert_please_select_a_record").val());	//请先进行选择
    		return;
    	}
    	var rs=window.confirm($("#alert_delete").val());	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../log/deletelog.action",
				data: {'logdata.id':getCheckChkValue("chk_record"),
					},
				success: function(msg){
					if(msg.success){
						operate('list');
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
	}
}

/**
 * 日期比较
 */
function compareTime(startDate, endDate){
	var start = startDate.split(" ")[0];
	var end = endDate.split(" ")[0];
	var starts = start.split("-");
	var ends = end.split("-");
	var start_Time = new Date(starts[0], starts[1], starts[2]).getTime();
	var end_Time = new Date(ends[0], ends[1], ends[2]).getTime();
	if(start_Time > end_Time){
		return false;
	} else{
		return true;
	}
}