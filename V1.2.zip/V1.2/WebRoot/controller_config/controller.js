function onload(){
	setTimeout("Refresh()",5000);
}

function Refresh(){
	document.listform.start.value=1;
	document.listform.action = "../controller_config/config_task.action";
	document.listform.submit();
}
function operate(str,id){
	if(str == "refresh"){
		Refresh();
	}
	else if(str=="create"){
    	wopen("../controller_config/controller_create.action","_blank",800,480);
	}else if(str=="delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../controller_config/controller_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					} else {
						alert(msg.msg);
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var ids = getCheckChkValue();
    	if(ids.indexOf(";") == -1){
    		wopen("../controller_config/controller_edit.action?data.id="+ids,"_blank",800,480);
    	} else {
    		wopen("../controller_config/controller_multiedit.action?data.id="+ids,"_blank",800,480);
    	}
    }else if(str=="editall"){ 
    	wopen("../controller_config/controller_multiedit.action","_blank",800,480);
    }else if(str=="config_task"){ 
    	wopen("../controller_config/config_task.action","_blank",800,480);
	}else if(str=="config_task_delete"){//删除下发任务
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 
    	var rst = window.confirm(document.getElementById("alert_will_delete_controller_settings").value);

    	if(rst){
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
			if(rs){
				$.ajax({
				    async: false,
					type: "POST",
					dataType: "json",
					url: "../controller_config/config_task_delete.action",
					data: {'data.id':getCheckChkValue("chk_record")},
					success: function(msg){
						if(msg.success){
					    	document.listform.start.value=1;
					    	document.listform.action = "../controller_config/config_task.action";
							document.listform.submit();
						} else {
							alert(msg.msg);
						}
					},
					error:function(msg){
						alert('error'+msg);
					}
				});
		    }
    	}
    	
    }else if(str == "task_history_delete"){//删除下发历史记录
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
			if(rs){
				$.ajax({
				    async: false,
					type: "POST",
					dataType: "json",
					url: "../controller_config/task_history_delete.action",
					data: {'data.id':getCheckChkValue("chk_record")},
					success: function(msg){
						if(msg.success){
					    	document.listform.start.value=1;
					    	document.listform.action = "../controller_config/config_history.action";
							document.listform.submit();
						} else {
							alert(msg.msg);
						}
					},
					error:function(msg){
						alert('error'+msg);
					}
				});
		    }
    }else if(str=="config_history"){ 
    	wopen("../controller_config/config_history.action","_blank",960,600);
    }else if(str=="inifile"){ //“下发配置文件”按钮操作
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	
    	var flag = false;
    	//生成配置文件前检查操作
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/check_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(!msg.line){
					alert($('#alert_line_cant_for_empty').val());
					flag = true;
					return;
				}
				if(!msg.success){
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
					flag = true;
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
		if(flag){
			return;
		}
		//生成配置文件操作
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(msg.success){
					alert($('#alert_ini_file_task_established').val());  //下发配置文件提示信息 “任务建立成功”  add by shenlk 2012-08-03
				} else {
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }else if(str=="list"){ 
    	document.listform.start.value=1;
    	document.listform.action = "../controller_config/controller_list.action";
		document.listform.submit();
    }else if(str=="back"){
		winClose();
	}else if(str=="save"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_save.action",
			data: $("#controller_create").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($("#process_success").val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="update"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_update.action",
			data: $("#controller_edit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					if(msg.sysModel != "2"){   //如果是视频就不用提示重新下发配置文件了
						alert($('#alert_again_issued_config_file').val());
					}
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="multiupdate"){
 		if(getCheckChkValue("data.field") == ""){
 			alert(document.getElementById("modify_content").value + document.getElementById("alert_is_not_null").value);
 			return;
 		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_multiupdate.action",
			data: $("#controller_multiedit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					 if(msg.sysModel != "2"){			//如果是视频就不用提示重新下发配置文件了
						 alert($('#alert_again_issued_config_file').val());
					 }
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
   	}
}
var field_code = new Array("lineId","port","status","notes");
function changeOptions(obj){
	for(var i = 0; i < field_code.length; i++){
		if(field_code[i] == obj.value){
			document.getElementById("div_" + field_code[i]).style.display = "block";
		} else {
			document.getElementById("div_" + field_code[i]).style.display = "none";
		}
	}
}