function barClicked(index, onClickText)
{
	if(onClickText.indexOf('noCheckUrl') != -1){
		return;
	}else{
		location.href = onClickText;
	}
}


function open_flash_chart_data()
{
	 var ss;
//因firefox及chrome无法触发此ajax,改为dwr实现
//	 $.ajax({
//		    async: false,
//			type: "post",
//			dataType: "json",
//			url: '../monitor/chart_list.action',
//			data: {},
//			success: function(msg){
//				ss = msg.toJSONString();
//			},
//			error:function(msg){
//				var s = document.getElementById("PrintA");
//				ss = msg.responseText;
//			}
//		});
	 
	 dwr.engine.setAsync(false);
	ChartData.getChartData(function(json){
		ss = json.toJSONString();
	});
	 return ss;
}


    