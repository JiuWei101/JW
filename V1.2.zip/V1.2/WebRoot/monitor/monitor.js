var t = "";

/**
 * 查看设备在地图上的位置　
 * @param mapId
 * @param self_type 设备类型
 * @param bayNo　　故障设备地址
 * @param bayPosition 设备编号
 */
function viewPosition(mapId, self_type, bayNo, bayCode){
	$.getJSON("../monitor/getFlashPath.action",
	    {"data.mapId" : mapId},
	    function(item){
	    	console.log(item.path);
			$('#jdialogswf').html('');			//先把原来的地图信息清掉
			showMap(item.path,'100%', ($(".right_B").height() - 20) + 'px', 'mySWF', 'mySWF');
			showDiv();                      //先顯示地圖,FF和GG瀏覽器要先看到元素才能操作Flash地圖
			var obj = getRegionMap('mySWF');
			inter = setInterval(function(){
				if(obj.PercentLoaded() == 100){
					clearInterval(inter);
					updateBayNo(self_type, bayNo, bayCode);
				}
		},1000);
	});
}

/**
 * 更新地圖的幀位置,設備的狀態
 * @param self_type 设备类型
 * @param bayNo 故障设备地址
 * @param bayCode 设备编号
 */
function updateBayNo(self_type, bayNo, bayCode){
    var saveBayNo = $("#saveBayNo").val();
    var self_type_input = $("#self_type").val();
//    if(saveBayNo != "" && self_type_input != ""){    //如果之前有改变故障的状态
//        if(self_type_input == "5"){    //如果之前是引导屏的故障,把之前的去掉
//            updateBays(getRegionMap("mySWF"), saveBayNo, 1);
//        } else if(self_type == "4"){	//如果之前是AKE屏
//            updateBays(getRegionMap("mySWF"), saveBayNo, 2);
//        }
//    }
    if(bayNo != ""){
        if(self_type == "5"){ //如果是引导屏的故障
            updateBays(getRegionMap("mySWF"), bayNo, 2);
        } else if(self_type == "4"){	//如果是视频探测器故障
        	bayNo = bayNo.replace(new RegExp('\\.', 'g'), "_") + "_" + bayCode;
            updateBays(getRegionMap("mySWF"), bayNo, 6);
        }
    }
    $("#self_type").val(self_type);
    $("#saveBayNo").val(bayNo);
}

function operate(str,id){
    if(str=="create"){
        wopen("../map_manage/map_create.action","_blank",800,480);
    }else if(str=="fault_list"){ 
        document.listform.action = "../monitor/fault_list.action";
        document.listform.submit();
    }else if(str=="timeout_list"){ 
        if(!isNumber($("#userDateInt").val())){
        	$("#userDateInt").val(48);
        	alert("超时时间只能输入数字,请重新输入.");
        	return;
        }
    	
        document.listform.action = "../monitor/timeout_list.action";
        document.listform.submit();
    }
}
//顯示地圖
function showMap(file,width,height,objId,objName){
    var html ="<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+ width +"' height='"+ height +"' id='"+objId+"' name='"+objName+"'>";
    html +="<param name='allowScriptAccess' value='always' />";
    html +="<param name='movie' value='" + file + "'>";
    html +="<param name='wmode' value='transparent'>";
    html +="<param name='quality' value='high'>";
    html +="<embed wmode='transparent' src='"+ file + "' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+ width +"' height='"+ height +"' id='"+objId+"' name='"+objName+"'></embed></object>";
    $('#jdialogswf').html(html);
    document.getElementById(objId).movie=encodeURI(file);
}

//半透明弹出层=============Start========================================
function showDiv(){
    document.getElementById('popDiv').style.display='block';
    document.getElementById('popIframe').style.display='block';
    document.getElementById('bg').style.display='block';
}
function closeDiv(){   
    document.getElementById('popDiv').style.display='none';
    document.getElementById('bg').style.display='none';
    document.getElementById('popIframe').style.display='none';
    getRegionMap("mySWF").Zoom(1200);
}
//半透明弹出层=============End========================================

//Flash地圖縮放功能
function Zoom(percent){
    getRegionMap("mySWF").Zoom(percent);
}