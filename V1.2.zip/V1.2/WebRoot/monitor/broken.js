var store1

/***************************创建子grid start*********************************/

Ext.onReady(function(){

     var store = new Ext.data.JsonStore({
        fields:['name', 'use_number', 'total_number'],
        data: [
            {name:'Jul 07', use_number: 245000, total_number: 3000000},
            {name:'Aug 07', use_number: 240000, total_number: 3500000},
            {name:'Sep 07', use_number: 355000, total_number: 4000000},
            {name:'Oct 07', use_number: 375000, total_number: 4200000},
            {name:'Nov 07', use_number: 490000, total_number: 4500000},
            {name:'Dec 07', use_number: 495000, total_number: 5800000},
            {name:'Jan 08', use_number: 520000, total_number: 6000000},
            {name:'Feb 08', use_number: 620000, total_number: 7500000}
        ]
    });
	store1 = new Ext.data.JsonStore({  
			                  
    		root: 'data',
    		sortInfo: {field: 'user_id', dir: 'ASC'},
			remoteSort: true, //true 则整体排序  false 则单页排序
	        fields: [
	         		 
	         		 'name',
	         		 'total_number',
	         		 'use_number'
	         		 
	        		 
        		],
    		proxy: new Ext.data.HttpProxy({url: '../monitor/chart_list.action'})
	    });
	store1.load();
	/* 创建列表数据*/
     var chart = new Ext.Panel({
        iconCls:'chart',
        title: '车辆实时监控图表',
        frame:true,
        renderTo : "list",
        height:400,
        layout:'fit',

        items: {
            xtype: 'columnchart',
            store: store1,
            url:'../resources/charts.swf',
            xField: 'name',
            yAxis: new Ext.chart.NumericAxis({
                displayName: 'total_number',
                labelRenderer : Ext.util.Format.numberRenderer('0,0')
            }),
            tipRenderer : function(chart, record, index, series){
            	if(series.yField == 'use_number'){
                    return  record.data.name + ' 有'+ Ext.util.Format.number(record.data.use_number, '0,0') + ' 车位已使用';
                }else{
                    return  record.data.name + ' 车位总数量为'+ Ext.util.Format.number(record.data.total_number, '0,0');
                }
            },
            listeners: {
				itemclick: function(o){
					var rec = store.getAt(o.index);
					alert(rec.get('name'));
					//Ext.example.msg('Item Selected', 'You chose {0}.', rec.get('name'));
				}
			},
            chartStyle: {
                padding: 10,
                animationEnabled: true,
                font: {
                    name: 'Tahoma',
                    color: 0x444444,
                    size: 11
                },
                dataTip: {
                    padding: 5,
                    border: {
                        color: 0x99bbe8,
                        size:1
                    },
                    background: {
                        color: 0xDAE7F6,
                        alpha: .9
                    },
                    font: {
                        name: 'Tahoma',
                        color: 0x15428B,
                        size: 10,
                        bold: true
                    }
                },
                xAxis: {
                    color: 0x69aBc8,
                    majorTicks: {color: 0x69aBc8, length: 4},
                    minorTicks: {color: 0x69aBc8, length: 2},
                    majorGridLines: {size: 1, color: 0xeeeeee}
                },
                yAxis: {
                    color: 0x69aBc8,
                    majorTicks: {color: 0x69aBc8, length: 4},
                    minorTicks: {color: 0x69aBc8, length: 2},
                    majorGridLines: {size: 1, color: 0xdfe8f6}
                }
            },
            series: [{
                type:'column',
                displayName: 'use_number',
                yField: 'use_number',
                style: {
                    color: 0x15428B
                }
            },{
                type: 'column',
                displayName: 'total_number',
                yField: 'total_number',
                style: {
                    image:'bar.gif',
                    mode: 'stretch',
                    color:0x99BBE8
                }
            }]
        }
    });
	
	
})


    