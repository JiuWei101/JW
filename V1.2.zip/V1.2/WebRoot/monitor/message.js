/**
 * 
 */
function operate(str,id){
    if(str=="create"){
    	wopen("../map_manage/map_create.action","_blank",800,480);
    }else if(str=="message_list"){ 
    	document.listform.action = "../monitor/message_list.action";
		document.listform.submit();
    }else if(str=="refresh"){ 
    	document.listform.action = "../monitor/message_list.action";
		document.listform.submit();
    }else if(str == "save"){
    		var mpnum = $("#mobilephone").val();
    		var reg = /^(1[3,5,8,7]{1}[\d]{9})|(((400)-(\d{3})-(\d{4}))|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{3,7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)$/ ;
    		
    	if($("#mobilephone").val() == ""){
			alert($("#mobPhone").val() + $("#alert_is_not_null").val());
			return;
		}else if(!reg.test(mpnum))
			{
			alert($("#mobPhone").val() + $("#alert_field_format_error").val());
			return;
			}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../monitor/base_save.action",
			data: {'data.bid':$("#bid").val(),
				'data.mobilephone':$("#mobilephone").val(),
				'data.noticeway': $("#noticeway").val(),
				'data.enableflag':$("#enableflag").val(),
				'data.attribute1':$("#serialnumber").val(),
				'data.attribute2':$("#password").val()
				},
			success: function(msg){
				if(msg.success){
					alert($("#process_success").val());	//操作成功
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }
}