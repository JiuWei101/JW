function operate(str,id){
    if(str=="delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../logicregion_manage/logicregion_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					} else {
						alert(msg.ex);
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	if(checkOne()){
    		var logic_id = getCheckChkValue();
    		$("#id").val(logic_id);
    		$("#code").val($("#code" + "_" + logic_id).val());
    		$("#name").val($("#name" + "_" + logic_id).val());
    		$("#notes").val($("#notes" + "_" + logic_id).val());
    		$("#physicalRegionId").val($("#physicalRegionId" + "_" + logic_id).val());
    	}
    }else if(str=="clear"){ 
		$("#id").val("");
		$("#code").val("");
		$("#name").val("");
		$("#notes").val("");
    }else if(str=="list"){ 
    	operate("clear");
    	document.listform.action = "../logicregion_manage/logicregion_list.action";
		document.listform.submit();
    }else if(str=="return"){
		winClose();
    }else if(str=="replace_region"){
    	opener.replaceRegion("logic");
	}else if(str=="save"){
		var name = trim($("#name").val());//去除所有空格并重新赋值
		$("#name").val(name);
		var code = trim($("#code").val());//去除所有空格并重新赋值
		$("#code").val(code);
		if($("#code").val() == ""){
			alert($("#alert_code").val() + $("#alert_is_not_null").val());
			return;
		}
		if($("#name").val() == ""){
			alert($("#alert_name").val() + $("#alert_is_not_null").val());
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../logicregion_manage/logicregion_save.action",
			data: $("#logicregion_list").formSerialize(),
			success: function(msg){
				if(msg.success){
					operate('list');
				} else {
					alert($('#alert_logic_area_name_repeat').val());
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}
}




function ajaxFileUpload()  
{  
//    $("#loading")  
//    .ajaxStart(function(){  
//        $(this).show();  
//    })//开始上传文件时显示一个图片  
//    .ajaxComplete(function(){  
//        $(this).hide();  
//    });//文件上传完成将图片隐藏起来  
      
    $.ajaxFileUpload  
    (  
        {  
            url:'../map_manage/map_impsave.action',//用于文件上传的服务器端请求地址  
            secureuri:false,//一般设置为false  
            fileElementId:'myFile',//文件上传空间的id属性  <input type="file" id="file" name="file" />  
            dataType: 'json',//返回值类型 一般设置为json  
            data:{'data.id':$("#id").val()},
            success: function (data, status)  //服务器成功响应处理函数  
            {  
               if(data.success){
            	   window.opener.operate('list');
            	   winClose();
               }else{
            	   if(data.message == 'file exist'){
						alert('地图文件已经存在请重新上传');
						return;
					}
               }
            },  
            error: function (data, status, e)//服务器响应失败处理函数  
            {  
                alert(e);  
            }  
        }  
    );
      
    return false;  

}  


//获得所有车位信息
function getFlashEqNo()
{
	var obj = getRegionMap("regionMap");//获取Object
    var bays = obj.CallFunction("<invoke name=\"GetCarList\" returntype=\"xml\"><arguments></arguments></invoke>");
	
	if(bays.length >0)
	{		
		bays = bays.replace("<string>","").replace("</string>","");			 
		
		
		var baysArr = bays.split(",");
		for(var i=0;i<baysArr.length;i++)
		{
			updateBays(obj,baysArr[i], 9);				 
		}
	}
	
	return bays;
}

//获得所有引导屏信息
function getFlashScreenNo()
{
	var obj = getRegionMap("regionMap");//获取Object
    var bays = obj.CallFunction("<invoke name=\"GetScreenList\" returntype=\"xml\"><arguments></arguments></invoke>");
	
	if(bays.length >0)
	{		
		bays = bays.replace("<string>","").replace("</string>","");			 
		
		
		var baysArr = bays.split(",");
		for(var i=0;i<baysArr.length;i++)
		{
			updateBays(obj,baysArr[i], 9);				 
		}
	}
	
	return bays;
}
