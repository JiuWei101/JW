/**
 * @createtime	2008-07-07
 * @author	zhaoyan
 * @note	����Ʈ���ӿ�
 * @version 	1.0
 */
//������www.forsoft.cn:9090 ����10.5.31.97/10.5.31.123:8080
var g_service_url = 'http://www.forsoft.cn:9090';//WIM������ַ
var g_webservice_url = 'http://www.forsoft.cn:9090';//У�������ַ

var wim_service_url_zw=g_service_url+"/zwservice/indexbak.jsp";//WIM����Ա������ҳ��IE
//var wim_service_url_kh=g_service_url+"/zwservice/wimm/system/loginactionWD.do";//WIM�������������ҳ��IE
var wim_service_url_kh=g_service_url+"/zwservice/browser.html";//WIM�������������ҳ��IE
var web_service_url=g_webservice_url+"/hsk/services/IcsWimWebService";//webserviceУ���ַ
var accurl=g_webservice_url+"/hsk/system/icsWimLogin.action";//�û���Ϣ��ȡ��ַ

var wim_interface_baseurl = g_service_url+"/zwservice/interface";//WIM���������û�����ַ

var wim_httpreq = null;
var wim_hwnd = null;
/**
 * @createtime	2008-10-31
 * @author		yushuo
 * @note		��ѯ�����ṩ�����
 * @param 		win_widthƮ������
 * @param 		win_heightƮ���߶�
 * @param 		win_rightƮ���ര���Ҳ����
 * @param 		win_topƮ���ര�ڶ�������
 * @param 		ad_word����
 * @return		��
 * @version 	1.0
*/
function createWin(win_width,win_height,win_right,win_top,ad_word) {
	if(!wim_httpreq){
		if(window.XMLHttpRequest){//Mozilla�����
			wim_httpreq=new XMLHttpRequest();
			if(wim_httpreq.overrideMimeType){//����MIME���
				wim_httpreq.overrideMimeType("text/xml");
			}
		} else if(window.ActiveXObject){//IE�����
			try{
				wim_httpreq=new ActiveXObject("Msxml2.XMLHTTP");
			} catch(e) {
				try{
					wim_httpreq=new ActiveXObject("Microsoft.XMLHTTP");
				} catch(e1) {
				}
			}
		}
	}
	if(!wim_httpreq) {
		alert('���ܴ�������');
		return false;
	}
	wim_httpreq.abort();
	wim_httpreq.onreadystatechange=function (){
		if(wim_httpreq.readyState==4){
			if(wim_httpreq.status==200){
				try{
					var rpObj = eval('('+wim_httpreq.responseText+')');
					if(rpObj['code']=='0'){
						createWin_base(rpObj['content'],win_width,win_height,win_right,win_top,ad_word)
					}
				}catch(e){
				}
			} else {
			}
		}
	}
	
	wim_httpreq.open("GET",g_service_url+"/zwservice/friends/serviceUser",true);
//	wim_httpreq.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	wim_httpreq.send();
}
/**
 * @createtime	2008-07-07
 * @author		zhaoyan
 * @note		����Ʈ������
 * @param 		chat_type�Ի����ͣ����飬[{��¼�����û�����key}]
 * @param 		win_widthƮ������
 * @param 		win_heightƮ���߶�
 * @param 		win_rightƮ���ര���Ҳ����
 * @param 		win_topƮ���ര�ڶ�������
 * @param 		ad_word����
 * @return		��
 * @version 	1.0
*/
function createWin_base(chattype,win_width,win_height,win_right,win_top,ad_word) {
	//���������div
	var windiv=document.createElement("DIV");
	windiv.id="wim_float_window";
	windiv.style.position="absolute";
	windiv.style.width=win_width;
	windiv.style.right=win_right;
	windiv.style.top=win_top;
	windiv.className="waiku";
	var htmlstr="";
	
	win_height = chattype.length*30;
	
	//���ӱ���
	htmlstr+='<div><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr>';
    htmlstr+='<td class="top-left"></td><td class="top-center"><span class="waiku_font1">���߿ͷ�</span></td>';
    htmlstr+='<td class="top-right"></td></tr></table></div>';
    
	//�ȼӶ�����
	htmlstr+='<div id="neiku">';
	htmlstr+='<div style="width:92px;" id="nk-left">';
	htmlstr+='<div>';
	htmlstr+='<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	htmlstr+='  <tr>';
	htmlstr+='    <td class="n_top1-left"></td>';
	htmlstr+='    <td class="n_top1-center"><img src="'+wim_interface_baseurl+'/images/n-top1_center.gif"></td>';
	htmlstr+='    <td class="n_top1-right"></td>';
	htmlstr+='  </tr>';
	htmlstr+='</table>';
	htmlstr+='</div>';
	htmlstr+='<div class="n_middle" style="height:'+win_height+'px;">';
	
	var otable=document.createElement("TABLE");
	for(var i=0;i<chattype.length;i++){		
		htmlstr+='<div class="nk_div1"';
		if(i==0){
			htmlstr+='style="border-top:1px solid #e5e4e8"';
		}
		htmlstr+='><span><img src="'+wim_interface_baseurl+'/images/bt.gif"></span><span>';
		htmlstr+="<a href=\"#\" onclick=\"javascript:wim_openChat('"+chattype[i]['login_name']+"','"+chattype[i]['real_name']+"','"+chattype[i]['key']+"')\">"+chattype[i]['real_name']+"</a>";
		htmlstr+='</span></div>';
		if(i!=chattype.length-1){
			htmlstr+='<div class="nk_div2"><img src="'+wim_interface_baseurl+'/images/div2.gif"></div>';
		}
	}
	htmlstr+='</div>';
	htmlstr+='<div>';
	htmlstr+='<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	htmlstr+='  <tr>';
	htmlstr+='    <td class="n_bottom-left"></td>';
	htmlstr+='    <td class="n_bottom-center"><img src="'+wim_interface_baseurl+'/images/n-bottom_center.gif"></td>';
	htmlstr+='    <td class="n_bottom-right"></td>';
	htmlstr+='  </tr>';
	htmlstr+='</table>';
	htmlstr+='</div>';
	htmlstr+='</div>';
	
	if(ad_word){
		htmlstr+='<div style="width:92px; margin-top:2px;" id="nk-left">';
		htmlstr+='<div>';
		htmlstr+='<table width="100%" border="0" cellspacing="0" cellpadding="0">';
		htmlstr+='  <tr>';
		htmlstr+='    <td class="n_top1-left"></td>';
		htmlstr+='    <td class="n_top1-center"><img src="'+wim_interface_baseurl+'/images/n-top1_center.gif"></td>';
		htmlstr+='    <td class="n_top1-right"></td>';
		htmlstr+='  </tr>';
		htmlstr+='</table>';
		htmlstr+='</div>';
		htmlstr+='<div class="n_middle" style="height:30px;">';
		htmlstr+=ad_word;
		htmlstr+='</div>';
		htmlstr+='<div>';
		htmlstr+='<table width="100%" border="0" cellspacing="0" cellpadding="0">';
		htmlstr+='  <tr>';
		htmlstr+='    <td class="n_bottom-left"></td>';
		htmlstr+='    <td class="n_bottom-center"><img src="'+wim_interface_baseurl+'/images/n-bottom_center.gif"></td>';
		htmlstr+='    <td class="n_bottom-right"></td>';
		htmlstr+='  </tr>';
		htmlstr+='</table>';
		htmlstr+='</div>';
		htmlstr+='</div>';
	}
	document.body.appendChild(windiv);
	htmlstr+='</div>';
	htmlstr+='</div>';
	htmlstr+='<iframe src="javascript:false" style="position:absolute; visibility:inherit; top:0px; left:0px; width:100%; height:100%; z-index:-2; filter=\'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)\';"></iframe>';
	windiv.innerHTML=htmlstr;
	wim_win_top=win_top;
	wim_win_right=win_right;
}

/**
 * @createtime	2008-07-07
 * @author		zhaoyan
 * @note		�򿪶Ի�����
 * @param 		login_name��¼�����ı�
 * @param 		real_name�û������ı�
 * @param 		key���ı�
 * @return		��
 * @version 	1.0
*/
function wim_openChat(login_name,real_name,key) {
	if(wim_hwnd&&!wim_hwnd.closed){
		if(!window.confirm("���Ѿ�����һ���Ի����ڣ�Ҫ�滻����")){
			return false;
		}
	}
	$.ajax({
			async: false,
			type: "POST",
			url: "../system/icsWimLogin.action",
			data:"",
			success: function(data){
				//alert(data);
				var args=data.split("|");
				if(args[0]=="1"){
					var openurl=null;
					if(navigator.userAgent.indexOf("MSIE")>0){
						if(args[1]=='4'){
				       		openurl=wim_service_url_zw;
						}else if(args[1]=='3'){
				       		openurl=wim_service_url_kh;
						}
				    }else if(navigator.userAgent.indexOf("Firefox")>0){
						//��firefox���������һ��ҳ
				       	alert("��֧��ie����������");
				    }else if(navigator.userAgent.indexOf("Safari")>0){
				       	alert("��֧��ie����������");
				    }else if(navigator.userAgent.indexOf("Camino")>0){
				       	alert("��֧��ie����������");
				    }else if(navigator.userAgent.indexOf("Gecko/")>0){
				       	alert("��֧��ie����������");
				    }
					openurl+="?login_type=2&state=01";
					openurl+="&endpoint="+web_service_url;
					openurl+="&user_type="+args[1];
					openurl+="&login_name="+args[2];
					openurl+="&random="+args[3];
					openurl+="&friend_name="+login_name;
					openurl+="&friend_key="+key;
					openurl+="&title="+real_name+"�������";

					//wim_hwnd=window.open(openurl);
					//alert(openurl);
					document.all['iframe_wim'].src = openurl;
				}
			}
		});
}