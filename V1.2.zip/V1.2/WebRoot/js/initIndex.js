//��������ʾ����͵���ʱ�õ��ĺ����
var taskdate=new Array();
var notask;
//1��ǰ����������2�ǵ�ǰ����������3��ǰ����������4�ǵ�ǰ����������5�ǵ�ǰ������
var color1,color2,color3,color4,color5;
color1="td-index-time4";
color2="td-index-time5";
color3="td-index-time2"
color4=""
color5="td-index-time3"

function fInit(){
	//createWin(100,60,890,100,null);
	var div = $("div.main");
	for(var i=0; i<div.length; i++){
		makeResizable(div[i]);
	}
	getOutlove();
	getAddressBook();
	getFun();
	
}

function getAddressBook(){
	var divAddress = $("div.content-main-address");
	if(divAddress.length > 0){
		var id = divAddress[0].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getAddressBook.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}else{
		//alert("ҳ��û��ͨѶ¼�ؼ�");
	}

}

function getFun(){
	var div = $("div.content-main-fun");
	if(div.length > 0){
		var id = div[0].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}

}
function getOutlove(){
	var div = $("div.content-main-outlove");
	
	if(div.length > 0){
		var id = div[0].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}

}
function getDataByDiv(){
	var div = $("div.content-main");
	for(var i=0; i<div.length; i++){
		var id = div[i].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: false,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}
	
	var rl = $("div.content-main-kalendar");
	if(rl.length > 0){
		var rlId = rl[0].id;
		$.ajax({
			async: false,
			type: "POST",
			url: "../counters/getViewMsg.action",
			contentType: "application/json",
			data:"",
			dataType: "json",
			success: function(data){
				taskdate = new Array();
				if(data[0].JOBDIARY.length > 0){
			       	for(var j=0;j<data[0].JOBDIARY.length;j++){
			       		 taskdate[j] = data[0].JOBDIARY[j].DAY;
			       	}
		       	}
		       		
		       	//��ʾ����
		       	try{	
					doDisCalendar(rlId);
				} catch(e) {	}
			}
		});
	}else{
		//alert("ҳ��û�����ڿؼ�");
	}

}

function sInit(){
	var userId = document.getElementById("id").value;
	$.ajax({
		async: true,
		type: "POST",
		url: "../maintain/ajax_updateOnline.action",
		data:"userId="+userId,
		success: function(msg){
			if(msg.length){
				var msgs = msg.split("|");
				if(msgs.length>0){
					if(msgs[0]=="01"){
						alert(msgs[1]);
					}
				}
			}
		}
	});
	setTimeout('sInit()',3000);
}

function tInit(){
	getDataByDiv();
	setTimeout('tInit()',1000*30);
}



//��ʾ����
function doDisCalendar(id){
	var calstr=showCalendar();
	var disstr=calstr+"</table></td></tr>";
	disstr+="<tr><td><div id=dis_time></div></td></tr></table>";
	document.getElementById(id).innerHTML = disstr;
	//alert(disstr);
	try{doDisTime();}catch(e){}
	disstr=null;
}

function showCalendar(){
	var curDate=new Date();
	var Year=curDate.getYear();
	var Month=curDate.getMonth();
	var Day=curDate.getDate();
	var YearPrev,MonthPrev;
	if(Month==0)
	{
		MonthPrev=11;
		YearPrev=Year-1;
	}
	else
	{
		MonthPrev=Month-1;
		YearPrev=Year;
	}
	var YearNext,MonthNext;
	if(Month==11)
	{
		MonthNext=0;
		YearNext=Year+1;
	}
	else
	{
		MonthNext=Month+1;
		YearNext=Year;
	}
	tmpDate=new Date(Year,Month,1);
	var Weekday=tmpDate.getDay();
	tmpDate.setDate(40);
	var totalDay=40-tmpDate.getDate();
	tmpDate=new Date(YearPrev,MonthPrev,1);
	tmpDate.setDate(40);
	var totalDayPrev=40-tmpDate.getDate();
	var disstr="";
	disstr="<table>";
	disstr+="<tr><td style='cursor:hand;padding:10px 5px 5px 5px;' onclick='openWin(\"counter/jobdiary_calendar.action?year="+Year+"&month="+(Month+1)+"\")'><strong>"+Year+"��"+(Month+1)+"��</strong></td></tr>";
	disstr+="<tr><td><table><tr>";
	disstr+="<td class=td-index-time1>��</td><td class=td-index-time1>һ</td><td class=td-index-time1>��</td>"
	disstr+="<td class=td-index-time1>��</td><td class=td-index-time1>��</td><td class=td-index-time1>��</td>"
	disstr+="<td class=td-index-time1>��</td></tr><tr class=td-index-time>";
	if(Weekday>0)
	{
		for(var i=0;i<Weekday;i++)
		{
			disstr+=writetd(YearPrev,MonthPrev,(totalDayPrev-Weekday+i+1),color5);
		}
		for(i=1;i<totalDay;i++)
		{
			notask=1;
			for(var m=0;m<taskdate.length;m++)
			{
				if(taskdate[m]==i&&i==Day)
				{
					disstr+=writetd(Year,Month,i,color1);
					notask=0;
					break;
				}
				else if(taskdate[m]==i)
				{
					disstr+=writetd(Year,Month,i,color2);
					notask=0;
					break;
				}
			}
			if(notask!=0)
			{
				if(i==Day)
				{
					disstr+=writetd(Year,Month,i,color3);
				}
				else
				{
					disstr+=writetd(Year,Month,i,color4);
				}
			}
			if(Weekday!=6)
			{
				Weekday++;
			}
			else
			{
				disstr+="</tr><tr class=td-index-time>";
				Weekday=0;
			}
		}
		notask=1;
		for(var m=0;m<taskdate.length;m++)
		{
			if(taskdate[m]==i&&i==Day)
			{
				disstr+=writetd(Year,Month,i,color1);
				notask=0;
				break;
			}
			else if(taskdate[m]==i)
			{
				disstr+=writetd(Year,Month,i,color2);
				notask=0;
				break;
			}
		}
		if(notask!=0)
		{
			if(i==Day)
			{
				disstr+=writetd(Year,Month,i,color3);
			}
			else
			{
				disstr+=writetd(Year,Month,i,color4);
			}
		}
		Weekday++;
		if(Weekday!=6)
		{
			for(i=1;Weekday<=6;Weekday++,i++)
			{
				disstr+=writetd(YearNext,MonthNext,i,color5);
			}
		}
		disstr+="</tr>";
	}
	else
	{
		for(i=1;i<totalDay;i++)
		{
			notask=1;
			for(var m=0;m<taskdate.length;m++)
			{
				if(taskdate[m]==i&&i==Day)
				{
					disstr+=writetd(Year,Month,i,color1);
					notask=0;
					break;
				}
				else if(taskdate[m]==i)
				{
					disstr+=writetd(Year,Month,i,color2);
					notask=0;
					break;
				}
			}
			if(notask!=0)
			{
				if(i==Day)
				{
					disstr+=writetd(Year,Month,i,color3);
				}
				else
				{
					disstr+=writetd(Year,Month,i,color4);
				}
			}
			if(Weekday!=6)
			{
				Weekday++;
			}
			else
			{
				disstr+="</tr><tr class=td-index-time>";
				Weekday=0;
			}
		}
		notask=1;
		for(var m=0;m<taskdate.length;m++)
		{
			if(taskdate[m]==i&&i==Day)
			{
				disstr+=writetd(Year,Month,i,color1);
				notask=0;
				break;
			}
			else if(taskdate[m]==i)
			{
				disstr+=writetd(Year,Month,i,color2);
				notask=0;
				break;
			}
		}
		if(notask!=0)
		{
			if(i==Day)
			{
				disstr+=writetd(Year,Month,i,color3);
			}
			else
			{
				disstr+=writetd(Year,Month,i,color4);
			}
		}
		Weekday++;
		if(Weekday!=6)
		{
			for(i=1;Weekday<=6;Weekday++,i++)
			{
				disstr+=writetd(YearNext,MonthNext,i,color5);
			}
		}
		disstr+="</tr>";
	}
	curDate=null;
	Year=null;
	Month=null;
	Day=null;
	YearPrev=null;
	MonthPrev=null;
	YearNext=null;
	MonthNext=null;
	Weekday=null;
	totalDay=null;
	totalDayPrev=null;
	return disstr;
}

function writetd(year,month,day,classname)
{
	var returnstr;
	returnstr="<td style='cursor:hand' onclick='openWin(\"counter/jobdiary_list.action?nyr=";
	returnstr+=getNyr(year,month,day)+"\")' class='"+classname+"'>"+day+"</td>";
	return returnstr;
}
// ����������yyyy-mm-dd
function getNyr(year,month,day){
	var returnstr;
	var cMonth = month + 1;
	if(cMonth.toString().length == 1){
		cMonth = "0" + cMonth;
	}
	var cDay = day;
	if(cDay.toString().length == 1){
		cDay = "0" + cDay;
	}
	returnstr = year +"-" +cMonth +"-"+ cDay;
	return returnstr;
}
// ����������yyyy��mm��
function getNy(year,month){
	var returnstr;
	returnstr = year +"��" +(month +1) +"��";
	return returnstr;
}

//��ʾʱ���timeoutid
var distimeid;
//��ʾʱ��
function doDisTime()
{
	if(distimeid){
		clearTimeout(distimeid);
	}
	var dt=new Date();
	var h=dt.getHours();
	var m=dt.getMinutes();
	var disstr=doubledigit(h)+":"+doubledigit(m);
	document.getElementById("dis_time").innerHTML = disstr;
	dt=null;
	h=null;
	m=null;
	disstr=null;
	distimeid=setTimeout("doDisTime()",500);
}

function doubledigit(source)
{
	source=""+source;
	if(source.length==2) return source;
	else return "0"+source;
}

function openWin(url){
	wopen("../"+url,"",950,600);
}

function makeResizable(obj){
  var d=5;
  var l,t,r,b,ex,ey,cur;
  obj.attachEvent("onmousedown",mdown);
  obj.attachEvent("onmouseup",mup);
  obj.attachEvent("onmousemove",mmove);
  function mdown(){
    if(event.button==1&&obj.style.cursor){
      	obj.resizing=true;
      	obj.setCapture();
      }
    }
  function mup(){
    if(event.button==1&&obj.resizing){
      obj.resizing=false;
      obj.releaseCapture();
      var id = obj.id;   //mian �� id
      //var divContMain = document.getElementById('c'+id);
      //if(divContMain.className=="content-main-address"){
      	//alert("���϶�����ͨѶ¼��");
      	//getAddressBook();
      //}
       
		x = parseInt(obj.style.left);
		y = parseInt(obj.style.top);
		w = parseInt(obj.style.width);
		h = parseInt(obj.style.height);
		var	str = obj.id + "A" + x + "A" + y + "A" + "td1" + "A" + w + "A" + h + ";"
					  $.ajax({
		    			async: true,
						type: "POST",
						url: "../system/saveLayout.action",
						data: "data="+str,
						success: function(msg){
							if(msg=="ok"){
								//alert("success");
							}
						},
						error: function(request) {
          					//alert("err:"+request.responseText);
            			}
					});
      }
    }
    
  function mmove(){
    if(obj.resizing){
      var dx=event.screenX-ex;
      var dy=event.screenY-ey;
      if(cur.indexOf("w")>-1) l+=dx;
      else if(cur.indexOf("e")>-1) r+=dx;
      if(cur.indexOf("n")>-1) t+=dy;
      else if(cur.indexOf("s")>-1) b+=dy;
      var s=obj.style;
      if(r-l>2*d){
        s.left=l;
        s.width=r-l;
        }
      if(b-t>2*d){
        s.top=t;
        s.height=b-t;
        }
      ex+=dx;
      ey+=dy;
      }
    else if(event.srcElement==obj){
      var x=event.offsetX,y=event.offsetY;
      var c=obj.currentStyle;
      w=parseInt(c.width),h=parseInt(c.height);
      cur=y<d?"n":h-y<d?"s":"";
      cur+=x<d?"w":w-x<d?"e":"";
      if(cur){
        obj.style.cursor=cur+"-resize";
        l=parseInt(c.left);
        t=parseInt(c.top);
        r=l+w;
        b=t+h;
        ex=event.screenX;
        ey=event.screenY;
        }
      else if(obj.style.cursor)
        obj.style.cursor="";
      }
    }
  }
  
  function getPos(){
	var str = "";
	var div = $("div.main");
	for(var i=0; i<div.length; i++){
		x = parseInt(div[i].style.left);
		y = parseInt(div[i].style.top);
		w = parseInt(div[i].style.width);
		h = parseInt(div[i].style.height);
		str = str + div[i].id + "A" + x + "A" + y + "A" + "td1" + "A" + w + "A" + h + ";"
		
	}
	return str;
}

function openService(url){
	wopen("../"+url,"",800,600);
}

function openReport(url){
	wopen("../"+url,"",800,450);
}

function openMission(url){
	wopen("../"+url,"",950,650);
}

function openJobNote(url){
	wopen("../"+url,"",800,550);
}

function openItem(url){
	wopen("../"+url,"",800,550);
}

function openPending(url){
	wopen("../"+url,"",800,600);
}

function openNotice(url){
	wopen("../"+url,"",800,600);
}

function openEditPassWord(url){
	wopen("../"+url,"",320,220);
}
function openShortCut(url){
	wopen("../"+url,"",800,400);
}
function openDiary(url){
	wopen("../"+url,"",800,630);
}
//�˳�ϵͳ
function loginOut(){
	var userId = document.getElementById("id").value;
	document.listform.action="../system/exit.action";
  	document.listform.submit();
}
