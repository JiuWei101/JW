$(document).ready(
	function()
	{
		// Toggle Single Portlet
		$('a.toggle').click(function()
			{
				$(this).parent('div').next('div').toggle();
				return false;
			}
		);

		// Invert All Portlets
		$('a#all_invert').click(function()
			{
				$('div.portlet_content').toggle();
				return false;
			}
		);

		// Expand All Portlets
		$('a#all_expand').click(function()
			{
				$('div.portlet_content:hidden').show();
				return false;
			}
		);

		// Collapse All Portlets
		$('a#all_collapse').click(function()
			{
				$('div.portlet_content:visible').hide();
				return false;
			}
		);

		// Open All Portlets
		$('a#all_open').click(function()
			{
				$('div.portlet:hidden').show();
				$('a#all_open:visible').hide();
				$('a#all_close:hidden').show();
				return false;
			}
		);

		// Close All Portlets
		$('a#all_close').click(function()
			{
				$('div.portlet:visible').hide();
				$('a#all_close:visible').hide();
				$('a#all_open:hidden').show();
				return false;
			}
		);

		// Controls Drag + Drop
		$('#columns td').Sortable(
			{
				accept: 'portlet',
				helperclass: 'sort_placeholder',
				handle: 'div.portlet_topper',
				opacity: 0.7,
				tolerance: 'intersect',
				onStart : function()
				{
				},
				 onStop : function()
				 {
					  var str = getPos();
					  $.ajax({
		    			async: false,
						type: "POST",
						url: "../system/saveLayout.action",
						data: "data="+str,
						success: function(msg){
							if(msg=="ok"){
								//alert("success");
							}
						},
						error: function(request) {
          					alert("err:"+request.responseText);
            			}
					});
				 }
			}
		);
	}
	
	
);

function getPos(){
	var str = "";
	var table = document.getElementById("columns");
	var tr = table.getElementsByTagName('tr');
    var td1  = tr[0].getElementsByTagName('td');
    var td = $("td.myClass");
    for(var i=0; i<td.length; i++){
		for(var j=0; j<td[i].childNodes.length; j++){
			var b = td[i].childNodes[j];
			if(b.id!='sortHelper'){
				var oRect=b.getBoundingClientRect();     
				var x=oRect.left;                        
				var y=oRect.top;  
				str = str + td[i].childNodes[j].id + "A" + x + "A" + y + "A" + td[i].id + "A" + b.offsetWidth + "A" + b.offsetHeight + ";"
				
			}
		}
	}
	//alert("ok"+str);
   return str;
}

$(document).ready(function(){
		$(".portlet").each(function(){
		
		var ow,oh;
		handleDrag(this,
				function(tar,x,y){
					ow=$(tar).width();
					oh=$(tar).height();
				},
				function(tar,x,y,dx,dy,ddx,ddy){
					p=$(tar);
					p.width(ow+dx);
					p.height(oh+dy);
		        });
		
	});
});