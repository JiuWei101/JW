var _x=0;
var _y=0;
var _ox=0;
var _oy=0;
var _dragingElement;
/*
 * @src handle element
 * @on_mousedown  function(handlingElement,x,y)
 * @on_mousemove  function(handlingElement,dx,dy,ddx,ddy,x,y);
 * x,y current x,y
 * dx,dy  delta x,y from mousedown
 * ddx,ddy delta x,y from last move
 */
function handleDrag(src,on_mousedown,on_mousemove){
	$(src).mousedown(
		function(ev){
			//debug("mousedown");
			ev = ev || window.event;
			drag=true;
			_x=ev.clientX;
			_y=ev.clientY;
			_ox=_x;
			_oy=_y;
			_dragingElement=this;
			on_mousedown(_dragingElement,_x,_y);
			$(document).mousemove(function(ev){
				ev = ev || window.event;
				ddx=ev.clientX-_x;
				_x=ev.clientX;
				ddy=ev.clientY-_y;
				_y=ev.clientY;
				dx=_x-_ox;
				dy=_y-_oy;
				on_mousemove(_dragingElement,_x,_y,dx,dy,ddx,ddy);
			});
			$(document).mouseup(function(ev){
				$(document).unbind('mousemove');
				$(document).unbind('mouseup');		
				 var str = getPos();
					  $.ajax({
		    			async: false,
						type: "POST",
						url: "../system/saveLayout.action",
						data: "data="+str,
						success: function(msg){
							if(msg=="ok"){
								//alert("success");
							}
						},
						error: function(request) {
          					alert("err:"+request.responseText);
            			}
					});
			});
			
		}
		
	);
	
}

function getPos(){
	var str = "";
	var table = document.getElementById("columns");
	var tr = table.getElementsByTagName('tr');
    var td1  = tr[0].getElementsByTagName('td');
    var td = $("td.myClass");
    for(var i=0; i<td.length; i++){
		for(var j=0; j<td[i].childNodes.length; j++){
			var b = td[i].childNodes[j];
			if(b.id!='sortHelper'){
				var oRect=b.getBoundingClientRect();     
				var x=oRect.left;                        
				var y=oRect.top;  
				str = str + td[i].childNodes[j].id + "A" + x + "A" + y + "A" + td[i].id + "A" + b.offsetWidth + "A" + b.offsetHeight + ";"
				
			}
		}
	}
	//alert(str);
   return str;
   	
	
}