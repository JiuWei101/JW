/*
* jQuery CascadingSelect AddOption
*
* Licensed like jQuery, see http://docs.jquery.com/License
*
* ���ߣ�jianglei
*/


jQuery.fn.CascadingSelect = function(target,url,options,endfn){
    $.ajaxSetup({async:false});        
	if(target[0].tagName != "SELECT") throw "target must be SELECT";
    if(url.length == 0) throw "request is required";            
    if(options.parameter == undefined) throw "parameter is required";
	
    this.change(function(){
		var newurl = "";
		urlstr = url.split("?");
		newurl = urlstr[0] + "?" + options.parameter + "=" + $(this).val() + "&" +urlstr[1];
        target.FillOptions(newurl,options);
        if(typeof endfn =="function") endfn();
    });
}

jQuery.fn.AddOption = function(text,value,is_default,is_dufault_value,index){
	var i = 0;
	
	if( is_default ){
		if( is_dufault_value ){
			option = new Option(is_dufault_value,'');
		}else{
			option = new Option('��ѡ��','');
		}
		this[0].options.add(option,0)
		i = 1;
	}

	for(var j=0; j < text.length; j++){
   
		option = new Option(text[j],value[j]);
		this[0].options.add(option,i++);
		
		if( index ){
			this[0].options[index].selected = true;
		}
	}

}

