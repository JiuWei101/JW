function showmenu(total,start,turl,numperpage,paginationnum,lang)
{
	var totalpage,pagearea;
	
	if(total.length==0)
		totalpage="";
	else
		totalpage=Math.ceil(parseInt(total)/numperpage);
	var i;
	var fpaginationnum,bpaginationnum;
	fpaginationnum=Math.ceil(parseInt(paginationnum)/2);
	bpaginationnum=parseInt(paginationnum)-fpaginationnum;

	var temp1,temp10;
	temp1=(Math.ceil(parseInt(start)/numperpage)-fpaginationnum)>=0?(Math.ceil(parseInt(start)/numperpage)-fpaginationnum):0;
	
	temp10=(Math.ceil(parseInt(start)/numperpage)+bpaginationnum)<totalpage?(Math.ceil(parseInt(start)/numperpage)+bpaginationnum):totalpage;
	if( Math.ceil(parseInt(total)/numperpage)<Math.ceil(paginationnum) ) {
		temp1 = 0;
		temp10 = Math.ceil(parseInt(total)/numperpage);
	}
	else
	{
		if( Math.ceil(temp10-temp1)<Math.ceil(paginationnum) ) {
			if( Math.ceil(temp1)==0 ) {
				temp10 = 10;
			}else {
				temp1 = Math.ceil(temp10-paginationnum);
			}
		}
	}
	var content = '<td width="40%">&nbsp;</td><td><p class="sty2" style="margin:0px;padding:0px;">';
	if(totalpage==1){
		content += '1/1  （共'+total+'条）</p></td>';
	}
	if(totalpage>1)
	{		
		content += Math.ceil(parseInt(start)/numperpage) + "/" + totalpage +"（共"+total+"条）</p></td>";
		if(start!=1)
		{	
			content += '<td><table><tr><td><img src="../images/Forward.jpg" width="18" height="18" align="middle" onclick="tranoperate(\''+turl+'\',1)"/></td>';
		}
		else
		{
			content += '<td><table><tr><td><img src="../images/Forward_Fail.jpg" width="18" height="18" align="middle" /></td>';
		}
		content += '<td><p class="sty2" style="margin:0px;padding:0px;">';
		for(i=temp1;i<temp10;i++)
		{
			if(Math.ceil(parseInt(start)/numperpage)==i+1)
			{
				content += "<strong>"+(i+1)+"</strong>";
				if(i!=temp10-1){
					content += "&nbsp;";
				}
			}
			else
			{	
				content += "<a href=\"javascript:tranoperate('"+turl+"',"+(numperpage*i+1)+")\" >"+(i+1)+"</a>";
				if(i!=temp10-1){
					content += "&nbsp;";
				}
			}
		}
		content += '</p></td>';
		if(start!=(totalpage-1)*numperpage+1)
		{
			content += '<td><img src="../images/Back.jpg" width="18" height="18" onclick="tranoperate(\''+turl+'\','+((totalpage-1)*numperpage+1)+
					')"/></td></tr></table></td>';
		}
		else
		{
			content += '<td><img src="../images/back_Fail.jpg" width="18" height="18" /></td></tr></table></td>';
		}
		content += '<td align="right"><label for="textfield">';
		content += '<input type="text" id="go" style="width:80px; height:16x; overflow:hidden; padding:0px; margin:0px;" size="3" />';
		content += '</td><td><a href="javascript:go(\''+turl+'\')"><img src="../images/go.jpg" border="0"></a></td>';
	}
	if(lang=='44'||lang==44){
		content = content.replace('共','Total ').replace('条','').replace('条','').replace('go.jpg','Turnto.jpg');
	}else if(lang == "87" || lang == 87){
		content = content.replace('共','共').replace('条','條').replace('条','條').replace('go.jpg','go_fan.jpg');
	}
	document.write(content);

}
function tranoperate(url,start){
	document.listform.action=url;
	document.listform.start.value=start;
	document.listform.submit();
}
function tranoperate1(url,start,nums){
	document.listform.action=url;
	document.listform.start.value=start;
	document.listform.limit.value=nums;
	document.listform.submit();
}
function go(url){
	var value = document.getElementById("go").value;
	if(value == ""){
		alert($('#alert_input_number_is_empty').val());
		document.getElementById("go").focus();
		return;
	}
	if(vailnum(parseInt(value))){
		alert($('#alert_input_number_not_Numbers').val());
		document.getElementById("go").focus();
		return;
	}
	if(value <= 0){
		alert($('#alert_input_number_too_small').val());
		document.getElementById("go").focus();
		return;
	}
	if((value - 1)*document.listform.limit.value>=document.listform.total.value){
		alert($('#alert_input_number_too_big').val());
		document.getElementById("go").focus();
		return;
	}
	
	document.listform.action=url;
	document.listform.start.value=((parseInt(value)-1)*parseInt(document.listform.limit.value))+1;
	document.listform.submit();
}
function vailnum(str){ 	
	var myReg = /^[0-9]+$/;
	return !myReg.test(str);
}
