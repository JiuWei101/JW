/**
 * 获取object或embeds标签
 * @param mapName	标签id
 * @returns {String}
 */
function getRegionMap(mapName) 
{
	var obj = "";
	if (navigator.appName.indexOf("Microsoft Internet") == -1) {
		if (document.embeds && document.embeds[mapName])
			obj = document.embeds[mapName];
		}
	else {
			obj = document.getElementById(mapName);
		}
		return obj;
}

/**
 * 元件跳帧
 * @param bayNo	探测器或条屏编码
 * @param bayType	帧数
 */
function updateBays(obj,bayNo,bayType)
{
	if(obj != null && obj != undefined){
		obj.TGotoFrame(bayNo, bayType);
	}		
}

/**
 * flash地图缩放
 * @param percent	比例
 */
function Zoom(percent){
	getRegionMap("regionMap").Zoom(percent);
}

/**
 * flash元件上展示文字
 * @param code	探测器或条屏编码
 * @param mark	标识
 */
function showMark(code,mark){
	getRegionMap("regionMap").CallFunction("<invoke name=\"SetGroupNo\" returntype=\"xml\">" +
			"<arguments><string>"+ code +"</string><string>"+ mark +"</string></arguments></invoke>");
}
/**
 * 无参数调用,有返回
 * @param obj
 * @param funcName
 */
function callFuncNoPara(obj,funcName){
	var bays = obj.CallFunction("<invoke name=\""+funcName+"\" returntype=\"xml\"><arguments></arguments></invoke>");
	return bays;
}

/**
 * 一个参数调用
 * @param obj
 * @param funcName
 * @param para
 */
function callFuncOnePara(obj,funcName,para){
	var bays = obj.CallFunction("<invoke name=\""+funcName+"\" returntype=\"xml\">" +
			"<arguments><string>"+ para +"</string></arguments></invoke>");
	return bays;
}

/**
 * 两个参数调用
 * @param obj
 * @param funcName
 * @param para1
 * @param para2
 */
function callFuncTwoParas(obj,funcName,para1,para2){
	obj.CallFunction("<invoke name=\""+funcName+"\" returntype=\"xml\">" +
			"<arguments><string>"+ para1 +"</string><string>"+ para2 +"</string></arguments></invoke>");
}

/**
 * 展示swf到对应的container
 * @param containerId	容器id
 * @param objId		object标签id
 * @param objName	object标签name
 * @param file		swf文件路径
 * @param width		宽度
 * @param height	高度
 */
function showMapInContainer(containerId,objId,objName,file,width,height){
	var html = "<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"
			+ width
			+ "' height='"
			+ height
			+ "' id='"+objId+"' name='"+objName+"'>";
	html += "<param name='allowScriptAccess' value='always' />";
	html += "<param name='movie' value='" + file + "'>";
	html += "<param name='quality' value='high'>";
	html += "<param name='wmode' value='Opaque'>";
	html += "<embed src='"
			+ file
			+ "' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"
			+ width + "' height='" + height
			+ "' id='"+objId+"' name='"+objName+"'></embed></object>";
	document.getElementById(containerId).innerHTML = html;
	document.getElementById(objId).movie = encodeURI(file);
}

/**
 * 查看flash是否加载完成并清除Interval
 * @param obj
 * @param intervalProcess
 * @returns {Boolean}
 */
function checkFlashComplete(obj,intervalProcess){
	if(obj.PercentLoaded() == 100){
		clearInterval(intervalProcess);
		return true;
	}else{
		return false;
	}
}

function showMap(file,width,height){
	document.write("<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+ width +"' height='"+ height +"' id='regionMap' name='regionMap'>");
		document.write("<param name='allowScriptAccess' value='always' />");
		document.write("<param name='movie' value='"+ file +"'>");
		document.write("<param name='quality' value='high'>");
		document.write("<param name='allowFullScreen' value='true'>");
		document.write("<param name='wmode' value='transparent'>");
		document.write("<embed src='"+ file +"' quality='high' allowFullScreen='true' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+ width +"' height='"+ height +"' id='regionMap' name='regionMap'></embed></object>");
		
      document.getElementById("regionMap").movie=encodeURI(file);
	
}

function zoomRect(obj, rect){
//	console.log(typeof rect.left);
	
//	obj.Zoom(60);
	obj.SetZoomRect(rect.left, rect.top, rect.right, rect.bottom);
}