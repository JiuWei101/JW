//��������ʾ����͵���ʱ�õ��ĺ������
var taskdate=new Array();
var notask;
//1��ǰ����������2�ǵ�ǰ����������3��ǰ����������4�ǵ�ǰ����������5�ǵ�ǰ������
var color1,color2,color3,color4,color5;
color1="kalendar-time4";
color2="kalendar-time5";
color3="kalendar-time2";
color4="";
color5="kalendar-time3";

function fInit(){
	getFun();
	getOutlove();
	//document.getElementById('oftentool').innerHTML = oftentool;
	//document.getElementById('ofteweb').innerHTML = ofteweb;
	//document.getElementById('oftensoft').innerHTML = oftensoft;
	$("#oftentool").html(oftentool);
	$("#ofteweb").html(ofteweb);
	$("#oftensoft").html(oftensoft);
	$("#oftengswh").html(oftengswh);//  ��˾�Ļ�qn��
	oftentool = null;
	ofteweb = null;
	oftensoft = null;
	oftengswh = null;//  ��˾�Ļ�qn��
}

function getAddressBook(){
	var divAddress = $("div.content-main-address");
	if(divAddress.length > 0){
		var id = divAddress[0].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getAddressBook.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}else{
		//alert("ҳ��û��ͨѶ¼�ؼ�");
	}

}

function getFun(){
	var div = $("div.content-main-fun");
	if(div.length > 0){
		var id = div[0].id;
		var divMain = document.getElementById(id);
		var w = parseInt(divMain.style.width);
		var h = parseInt(divMain.style.height);
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id,
			success: function(data){
				document.getElementById(id).innerHTML = data;
				//$("#"+id).html(data);
			}
		});
	}

}
function getOutlove(){
	var div = $("div.content-main-outlove");
	
	if(div.length > 0){
		var id = div[0].id;
		var divMainId = id.substring(1,id.length);
		var divMain = document.getElementById(divMainId);
		var w = 20;
		var h = 20;
		$.ajax({
			async: true,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id+"&width="+w+"&height="+h,
			success: function(data){
				document.getElementById(id).innerHTML = data;
			}
		});
	}

}
function getDataByDiv(){
	var div = $("div.content-main");
	for(var i=0; i<div.length; i++){
		var id = div[i].id;
		var divMain = document.getElementById(id);
		$.ajax({
			async: false,
			type: "POST",
			url: "../maintain/ajax_getData.action",
			data:"id="+id,
			success: function(data){
				document.getElementById(id).innerHTML = data;
				//$("#"+id).html(data);
			}
		});
	}
		
}

//��ʾ����
function loadRl(){
	var currNyr = document.getElementById('currNyr').value; 
	var ny = currNyr.toString().substring(0,6);
	   	var year = currNyr.toString().substring(0,4);
	  	var month = currNyr.toString().substring(4,6);
	  	var day = currNyr.toString().substring(6,8);
	   	var iYue = Number(month);
	   	var iDay = Number(day);
	   	var curDate = new Date(year,iYue-1,iDay); 
		
		$.ajax({
			async: false,
			type: "POST",
			url: "../counters/getViewMsg.action?ny="+ny,
			contentType: "application/json",
			data:"",
			dataType: "json",
			success: function(data){
				taskdate = new Array();
				if(data[0].JOBDIARY.length > 0){
			       	for(var j=0;j<data[0].JOBDIARY.length;j++){
			       		 taskdate[j] = data[0].JOBDIARY[j].DAY;
			       	}
		       	}
			}
		});
		
		var calstr = showCalendar(curDate);
		document.getElementById("rl").innerHTML = calstr;
		//$("#rl").html(calstr);
	    try{doDisTime();}catch(e){}
	    
	    setTimeout('loadRl()',1000*20);
}

// �л���ʾ����
function showRl(type){
	// ��ǰ��ʾ������
	var currNyr = document.getElementById('currNyr').value; 
	var currNy = currNyr.substring(0,6); 
	var day = currNyr.substring(6,8);
	var iDay = Number(day);
	if(type=="pre"){
    	var preNy = nyAdd(currNy,-1);
		var year = preNy.toString().substring(0,4);
		var month = preNy.toString().substring(4,6);
		var iYue = Number(month);
		var curDate=new Date(year,iYue-1,iDay); 
	    var calstr=showCalendar(curDate);
		document.getElementById('currNyr').value = preNy.toString() + day;
	}else{
		var nextNy = nyAdd(currNy,1); 
		var year = nextNy.toString().substring(0,4);
		var month = nextNy.toString().substring(4,6);
		var iYue = Number(month);
		var curDate=new Date(year,iYue-1,iDay);  //��ǰ����1��
	    var calstr=showCalendar(curDate);
	    document.getElementById('currNyr').value = nextNy.toString() + day;
	}
	document.getElementById("rl").innerHTML = calstr;
	document.getElementById('yue').innerHTML = iYue;
	//$("#rl").html(calstr);
	//$("#yue").html(iYue);
	loadRl();
}
	
function showListRl(){
    var currNyr = document.getElementById('currNyr').value; 
	var year = currNyr.substring(0,4); 
	var month = currNyr.substring(4,6);	
    var url = "counter/jobdiary_calendar.action?year="+year+"&month="+month;
	openWin(url);
}

function sInit(){
	var userId = document.getElementById("id").value;
	$.ajax({
		async: true,
		type: "POST",
		url: "../maintain/ajax_updateOnline.action",
		data:"userId="+userId,
		success: function(msg){
			if(msg.length){
				var msgs = msg.split("|");
				if(msgs.length>0){
					if(msgs[0]=="01"){
						alert(msgs[1]);
					}
				}
			}
		}
	});
	setTimeout('sInit()',3000);
}

function tInit(){
	getDataByDiv();
	setTimeout('tInit()',1000*30);
}



//��ʾ����
function doDisCalendar(id,curDate){
	var calstr=showCalendar(curDate);
	document.getElementById(id).innerHTML = calstr;
	//$("#"+id).html(calstr);
	try{doDisTime();}catch(e){}
}

function showCalendar(curDate){
	//var curDate=new Date();
	var Year=curDate.getYear();
	var Month=curDate.getMonth();
	var Day=curDate.getDate();
	var YearPrev,MonthPrev;
	if(Month==0)
	{
		MonthPrev=11;
		YearPrev=Year-1;
	}
	else
	{
		MonthPrev=Month-1;
		YearPrev=Year;
	}
	var YearNext,MonthNext;
	if(Month==11)
	{
		MonthNext=0;
		YearNext=Year+1;
	}
	else
	{
		MonthNext=Month+1;
		YearNext=Year;
	}
	tmpDate=new Date(Year,Month,1);
	var Weekday=tmpDate.getDay();
	tmpDate.setDate(40);
	var totalDay=40-tmpDate.getDate();
	tmpDate=new Date(YearPrev,MonthPrev,1);
	tmpDate.setDate(40);
	var totalDayPrev=40-tmpDate.getDate();
	var disstr="";
	disstr="<table border=\"0\" cellpadding=\"0\" cellspacing=\"4\" class=\"kalendar\">";
	disstr+="<tr>";
	disstr+="<th style=\"color:#afafaf;\">��</th><th>һ</th><th>��</th><th>��</th><th>��</th><th>��</th><th style=\"color:#afafaf;\">��</th>";
	disstr+="<th style=\"color:#afafaf;\">��</th><th>һ</th><th>��</th><th>��</th><th>��</th><th>��</th><th style=\"color:#afafaf;\">��</th>";
	disstr+="<th style=\"color:#afafaf;\">��</th><th>һ</th><th>��</th><th>��</th><th>��</th><th>��</th><th style=\"color:#afafaf;\">��</th>";
	disstr+="</tr>";
	disstr+="<tr>";
	if(Weekday>0)
	{
	    var j = 1;
		for(var i=0;i<Weekday;i++,j++)
		{
			disstr+=writetd(YearPrev,MonthPrev,(totalDayPrev-Weekday+i+1),color5);
		}
		for(i=1;i<totalDay;i++,j++)
		{
			notask=1;
			for(var m=0;m<taskdate.length;m++)
			{
				if(taskdate[m]==i&&i==Day)
				{
					disstr+=writetd(Year,Month,i,color1);
					notask=0;
					break;
				}
				else if(taskdate[m]==i)
				{
					disstr+=writetd(Year,Month,i,color2);
					notask=0;
					break;
				}
			}
			if(notask!=0)
			{
				if(i==Day)
				{
					disstr+=writetd(Year,Month,i,color3);
				}
				else
				{
					disstr+=writetd(Year,Month,i,color4);
				}
			}
			if(Weekday!=6)
			{
				Weekday++;
			}
			else
			{
				Weekday=0;
			}
			if(j==21){
				disstr+="</tr><tr class=td-index-time>";
			}
		}
		notask=1;
		for(var m=0;m<taskdate.length;m++)
		{
			if(taskdate[m]==i&&i==Day)
			{
				disstr+=writetd(Year,Month,i,color1);
				notask=0;
				break;
			}
			else if(taskdate[m]==i)
			{
				disstr+=writetd(Year,Month,i,color2);
				notask=0;
				break;
			}
		}
		if(notask!=0)
		{
			if(i==Day)
			{
				disstr+=writetd(Year,Month,i,color3);
			}
			else
			{
				disstr+=writetd(Year,Month,i,color4);
			}
		}
		Weekday++;
		if(Weekday!=6)
		{
			for(i=1;Weekday<=6;Weekday++,i++)
			{
				disstr+=writetd(YearNext,MonthNext,i,color5);
			}
		}
		disstr+="</tr>";
	}
	else
	{
		for(i=1;i<totalDay;i++)
		{
			notask=1;
			for(var m=0;m<taskdate.length;m++)
			{
				if(taskdate[m]==i&&i==Day)
				{
					disstr+=writetd(Year,Month,i,color1);
					notask=0;
					break;
				}
				else if(taskdate[m]==i)
				{
					disstr+=writetd(Year,Month,i,color2);
					notask=0;
					break;
				}
			}
			if(notask!=0)
			{
				if(i==Day)
				{
					disstr+=writetd(Year,Month,i,color3);
				}
				else
				{
					disstr+=writetd(Year,Month,i,color4);
				}
			}
			if(Weekday!=6)
			{
				Weekday++;
			}
			else
			{
				Weekday=0;
			}
			if(i==21){
				disstr+="</tr><tr class=td-index-time>";
			}
		}
		notask=1;
		for(var m=0;m<taskdate.length;m++)
		{
			if(taskdate[m]==i&&i==Day)
			{
				disstr+=writetd(Year,Month,i,color1);
				notask=0;
				break;
			}
			else if(taskdate[m]==i)
			{
				disstr+=writetd(Year,Month,i,color2);
				notask=0;
				break;
			}
		}
		if(notask!=0)
		{
			if(i==Day)
			{
				disstr+=writetd(Year,Month,i,color3);
			}
			else
			{
				disstr+=writetd(Year,Month,i,color4);
			}
		}
		Weekday++;
		if(Weekday!=6)
		{
			for(i=1;Weekday<=6;Weekday++,i++)
			{
				disstr+=writetd(YearNext,MonthNext,i,color5);
			}
		}
		disstr+="</tr>";
	}
	curDate=null;
	Year=null;
	Month=null;
	Day=null;
	YearPrev=null;
	MonthPrev=null;
	YearNext=null;
	MonthNext=null;
	Weekday=null;
	totalDay=null;
	totalDayPrev=null;
	return disstr;
}

function writetd(year,month,day,classname)
{
	var returnstr;
	if(classname == "kalendar-time3"){
		returnstr="<td style='cursor:hand' class='"+classname+"'>"+day+"</td>";
	}else{
		returnstr="<td style='cursor:hand' onclick='showListRl()' class='"+classname+"'>"+day+"</td>";
	}
	
	return returnstr;
}
// ����������yyyy-mm-dd
function getNyr(year,month,day){
	var returnstr;
	var cMonth = month;
	if(cMonth.toString().length == 1){
		cMonth = "0" + cMonth;
	}
	var cDay = day;
	if(cDay.toString().length == 1){
		cDay = "0" + cDay;
	}
	returnstr = year +"-" +cMonth +"-"+ cDay;
	return returnstr;
}
// ����������yyyy��mm��
function getNy(year,month){
	var returnstr;
	returnstr = year +"��" +(month +1) +"��";
	return returnstr;
}

function nyAdd(ny,ys){
	var year  = Number(ny.substring(0,4));
	var month = Number(ny.substring(4,6));
	var sumMonth = year * 12 + month + ys;
	year =  parseInt((sumMonth / 12));
	month = sumMonth - year * 12;
	if(month == 0){
		month = 12;
		year = year - 1;
	}
	return year * 100 + month;
}

//��ʾʱ���timeoutid
var distimeid;
//��ʾʱ��
function doDisTime()
{
	if(distimeid){
		clearTimeout(distimeid);
	}
	var dt=new Date();
	var h=dt.getHours();
	var m=dt.getMinutes();
	var disstr=doubledigit(h)+":"+doubledigit(m);
	document.getElementById("currTime").innerHTML = disstr;
	//$("#currTime").html(disstr);
	dt=null;
	h=null;
	m=null;
	disstr=null;
	distimeid=setTimeout("doDisTime()",500);
}

function doubledigit(source)
{
	source=""+source;
	if(source.length==2) return source;
	else return "0"+source;
}

function openWin(url){
	wopen("../"+url,"",950,600);
}

function makeResizable(obj){
  var d=5;
  var l,t,r,b,ex,ey,cur;
  obj.attachEvent("onmousedown",mdown);
  obj.attachEvent("onmouseup",mup);
  obj.attachEvent("onmousemove",mmove);
  function mdown(){
    if(event.button==1&&obj.style.cursor){
      	obj.resizing=true;
      	obj.setCapture();
      }
    }
  function mup(){
    if(event.button==1&&obj.resizing){
      obj.resizing=false;
      obj.releaseCapture();
      var id = obj.id;   //mian �� id
      //var divContMain = document.getElementById('c'+id);
      //if(divContMain.className=="content-main-address"){
      	//alert("���϶�����ͨѶ¼��");
      	//getAddressBook();
      //}
       
		x = parseInt(obj.style.left);
		y = parseInt(obj.style.top);
		w = parseInt(obj.style.width);
		h = parseInt(obj.style.height);
		var	str = obj.id + "A" + x + "A" + y + "A" + "td1" + "A" + w + "A" + h + ";";
					  $.ajax({
		    			async: true,
						type: "POST",
						url: "../system/saveLayout.action",
						data: "data="+str,
						success: function(msg){
							if(msg=="ok"){
								//alert("success");
							}
						},
						error: function(request) {
          					//alert("err:"+request.responseText);
            			}
					});
      }
    }
    
  function mmove(){
    if(obj.resizing){
      var dx=event.screenX-ex;
      var dy=event.screenY-ey;
      if(cur.indexOf("w")>-1) l+=dx;
      else if(cur.indexOf("e")>-1) r+=dx;
      if(cur.indexOf("n")>-1) t+=dy;
      else if(cur.indexOf("s")>-1) b+=dy;
      var s=obj.style;
      if(r-l>2*d){
        s.left=l;
        s.width=r-l;
        }
      if(b-t>2*d){
        s.top=t;
        s.height=b-t;
        }
      ex+=dx;
      ey+=dy;
      }
    else if(event.srcElement==obj){
      var x=event.offsetX,y=event.offsetY;
      var c=obj.currentStyle;
      w=parseInt(c.width),h=parseInt(c.height);
      cur=y<d?"n":h-y<d?"s":"";
      cur+=x<d?"w":w-x<d?"e":"";
      if(cur){
        obj.style.cursor=cur+"-resize";
        l=parseInt(c.left);
        t=parseInt(c.top);
        r=l+w;
        b=t+h;
        ex=event.screenX;
        ey=event.screenY;
        }
      else if(obj.style.cursor)
        obj.style.cursor="";
      }
    }
  }
  
  function getPos(){
	var str = "";
	var div = $("div.main");
	for(var i=0; i<div.length; i++){
		x = parseInt(div[i].style.left);
		y = parseInt(div[i].style.top);
		w = parseInt(div[i].style.width);
		h = parseInt(div[i].style.height);
		str = str + div[i].id + "A" + x + "A" + y + "A" + "td1" + "A" + w + "A" + h + ";";
		
	}
	return str;
}

function openService(url){
	wopen("../"+url,"",800,600);
}

function openReport(url){
	wopen("../"+url,"",800,450);
}

function openMission(url){
	wopen("../"+url,"",950,650);
}

function openJobNote(url){
	wopen("../"+url,"",800,550);
}

function openItem(url){
	wopen("../"+url,"",800,550);
}

function openPending(url){
	wopen("../"+url,"",800,600);
}

function openNotice(url){
	wopen("../"+url,"",800,600);
}

function openEditPassWord(url){
	wopen("../"+url,"",320,220);
}
function openShortCut(url){
	wopen("../"+url,"",800,400);
}
function openDiary(url){
	wopen("../"+url,"",800,630);
}
//�˳�ϵͳ
function loginOut(){
	var userId = document.getElementById("id").value;
	document.listform.action="../system/exit.action";
  	document.listform.submit();
}

var oftentool = "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"font-size:12px;\">"
                                          +"<tr>"
                                            +"<td><A href=\"http://www.kiees.cn/\" target=\"_blank\">��ݲ�ѯ</A></td>"
                                            +"<td><A href=\"http://www.ip138.com/\" target=\"_blank\">�ֻ���������</A></td>"
                                            +"<td><A href=\"http://weather.news.sina.com.cn/\" target=\"_blank\">����Ԥ��</A></td>"
                                            +"<td><A href=\"http://www.soft8.net/yb.htm\" target=\"_blank\">�������</A></td>"
                                            +"<td><A href=\"http://flights.ctrip.com/Domestic/SearchFlights.aspx\" target=\"_blank\">�����ѯ</A></td>"
                                            +"<td><A href=\"http://www.huoche.com.cn/\" target=\"_blank\">�г�ʱ��</A></td>"
                                            +"<td><A href=\"http://translate.google.cn/translate_t#\" target=\"_blank\">���߷���</A></td>"
                                            +"<td><A href=\"http://site.baidu.com/list/wannianli.htm\" target=\"_blank\">������</A></td>"
                                            +"<td><a href=\"http://www.ip138.com/\" target=\"_blank\">IP��ַ</a></td>"
                                            +"<td><a href=\"http://fund.baidu.com/\" target=\"_blank\">���ֵ</a></td>"
                                            +"<td><a href=\"http://bus.mapbar.com/\" target=\"_blank\">������ѯ</a></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://car.autohome.com.cn/\" target=\"_blank\">����</a></td>"
                                            +"<td><a href=\"http://auto.sohu.com/s2004/weizhangchaxun.shtml\" target=\"_blank\">��ͨΥ�²�ѯ</a></td>"
                                            +"<td><a href=\"http://www.51jiemeng.com/\" target=\"_blank\">�ܹ�����</a></td>"
                                            +"<td><a href=\"http://www.zhcw.com/\" target=\"_blank\">�����Ʊ</a></td>"
                                            +"<td><a href=\"http://www.lottery.gov.cn/\" target=\"_blank\">�����Ʊ</a></td>"
                                            +"<td><a href=\"http://www.zdic.net/\" target=\"_blank\">�����ֵ�ǵ�</a></td>"
                                            +"<td><a href=\"http://map.baidu.com/\" target=\"_blank\">��ͼ��ѯ</a></td>"
                                            +"<td><a href=\"http://www.hao123.com/haoserver/jianfanzh.htm\" target=\"_blank\">��ת��</a></td>"
                                            +"<td><a href=\"http://www.hao123.com/haoserver/xzcx.htm\" target=\"_blank\">�����ѯ</a></td>"
                                            +"<td><a href=\"http://www.boc.cn/sourcedb/whpj/\" target=\"_blank\">����Ƽ�</a></td>"
                                            +"<td><a href=\"http://law.chinalawinfo.com/\" target=\"_blank\">���ɷ���</a></td>"
                                          +"</tr>"
                                        +"</table>";
                       
var ofteweb =  "<table width=\"96%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
                                          +"<tr>"
                                            +"<td><a href=\"http://www.baidu.com\" target=\"_blank\">�ٶ�</a></td>"
                                            +"<td><A href=\"http://www.google.cn\" target=\"_blank\">Google</A></td>"
                                            +"<td><a href=\"http://www.qq.com\" target=\"_blank\">��ѶQQ</a></td>"
                                            +"<td><a href=\"http://www.sina.com.cn\" target=\"_blank\">����</a></td>"
                                            +"<td><a href=\"http://www.163.com\" target=\"_blank\">����</a></td>"
                                            +"<td><a href=\"http://www.sohu.com\" target=\"_blank\">�Ѻ�</a></td>"
                                         +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://www.xinhuanet.com/\" target=\"_blank\">�»���</a></td>"
                                            +"<td><a href=\"http://www.ifeng.com\" target=\"_blank\">�����</a></td>"
                                            +"<td><A href=\"http://www.zaobao.com\" target=\"_blank\">�����籨</A></td>"
                                            +"<td><A href=\"http://www.pconline.com.cn/\" target=\"_blank\">̫ƽ����</A></td>"
                                            +"<td><A href=\"http://www.zol.com.cn/\" target=\"_blank\">�йش�����</A></td>"
                                            +"<td><a href=\"http://www.chinamobile.com/\" target=\"_blank\">�й��ƶ�</a></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://www.taobao.com\" target=\"_blank\">�Ա���</a></td>"
                                            +"<td><a href=\"http://p.yiqifa.com\" target=\"_blank\">�����̳�</a></td>"
                                            +"<td><a href=\"http://p.yiqifa.com\" target=\"_blank\">����</a></td>"
                                            +"<td><a href=\"http://p.yiqifa.com\" target=\"_blank\">׿Խ</a></td>"
                                            +"<td><A href=\"http://www.ctrip.com\" target=\"_blank\">Я����</A></td>"
                                            +"<td><A href=\"http://www.rayli.com.cn/\" target=\"_blank\">����Ů����</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://kankan.xunlei.com/\" target=\"_blank\">Ѹ�׿���</a></td>"
                                            +"<td><A href=\"http://www.youku.com\" target=\"_blank\">�ſ���</A></td>"
                                            +"<td><A href=\"http://www.tudou.com\" target=\"_blank\">������</A></td>"
                                            +"<td><A href=\"http://www.duowan.com\" target=\"_blank\">����</A></td>"
                                            +"<td><a href=\"http://www.autohome.com.cn/\" target=\"_blank\">��֮��</a></td>"
                                            +"<td><a href=\"http://www.soufun.com/\" target=\"_blank\">�ѷ���</a></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://www.xiaonei.com/\" target=\"_blank\">У����</a></td>"
                                            +"<td><a href=\"http://www.kaixin001.com\" target=\"_blank\">������</a></td>"
                                            +"<td><a href=\"http://www.tianya.cn/\" target=\"_blank\">��������</a></td>"
                                            +"<td><a href=\"http://www.51.com\" target=\"_blank\">51.com</a></td>"
                                            +"<td><a href=\"http://www.qidian.com/\" target=\"_blank\">���������</a></td>"
                                            +"<td><a href=\"http://www.jiayuan.com/\" target=\"_blank\">���ͼ�Ե</a></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><a href=\"http://www.icbc.com.cn/icbc/\" target=\"_blank\">��������</a></td>"
                                            +"<td><a href=\"http://www.cmbchina.com/\" target=\"_blank\">��������</a></td>"
                                            +"<td><a href=\"http://www.51job.com/\" target=\"_blank\">ǰ������</a></td>"
                                            +"<td><a href=\"http://fund.eastmoney.com/\" target=\"_blank\">������</a></td>"
                                            +"<td><a href=\"http://www.zhcw.com/\" target=\"_blank\">�в���</a></td>"
                                            +"<td><a href=\"http://www.eastmoney.com/\" target=\"_blank\">�����Ƹ�</a></td>"
                                          +"</tr>"
                                      +"</table>";

var oftensoft = "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"font-size:12px;\">"
                                          +"<tr>"
                                            +"<td><A href=\"http://dl_dir.qq.com/qqfile/qq/QQ2009preview4/QQ2009Preview4_chs.exe\">��ѶQQ</A></td>"
                                            +"<td><A href=\"http://g.live.com/1rewlive3/zh-chs/wlsetup-custom.exe\">MSN</A></td>"
                                            +"<td><A href=\"http://download.ppstream.com/hz/ppstreamsetup_mtsoft.exe\">PPstream</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><A href=\"http://dl.baofeng.com/stormII/Storm3-554.exe\">����Ӱ��</A></td>"
                                            +"<td><A href=\"http://ttplayer.qianqian.com/download/ttpsetup.exe\">ǧǧ����</A></td>"
                                            +"<td><A href=\"http://downmini.kugoo.com/KuGou_Maxthon2.exe\">�ṷ����</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><A href=\"http://down.sandai.net/Thunder5.8.8.653.exe\">Ѹ��</A></td>"
                                            +"<td><A href=\"http://down5.flashget.com/flashget24cn.exe\">��ʿ쳵</A></td>"
                                            +"<td><A href=\"http://download.verycd.com/easyMule-Setup.exe\">��¿Emule</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><A href=\"http://www.winrar.com.cn/download/wrar380sc.exe\">WinRAR</A></td>"
                                            +"<td><A href=\"http://down.360safe.com/setup.exe\">360��ȫ��ʿ</A></td>"
                                            +"<td><A href=\"ftp://file6.mydrivers.com/others/mydrivers_dg_b52.zip\">����</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><A href=\"http://rsdownload.rising.com.cn/for_down/rsfree/Ravd29.exe\">����2009</A></td>"
                                            +"<td><A href=\"http://down.neoimaging.cn/neoimaging/NeoImaging3.01.20.exe\">��Ӱħ����</A></td>"
                                            +"<td><A href=\"ftp://southdown.gw.com.cn/pub/Dzh_2in1.exe\">���ǻ�</A></td>"
                                          +"</tr>"
                                          +"<tr>"
                                            +"<td><A href=\"http://dl.google.com/pinyin/GooglePinyinInstaller.exe\">�ȸ�ƴ��</A></td>"
                                            +"<td><A href=\"http://ime.sogou.com/dl/sogou_pinyin_40b.exe\">�ѹ�ƴ��</A></td>"
                                            +"<td><A href=\"http://www.jpwb.net/download/jpwb.exe\">��Ʒ���</A></td>"
                                          +"</tr>"
                                      +"</table>";      
//  ��˾�Ļ�qn��                                  
var oftengswh = "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"font-size:12px;\">"
					+"<tr>"
						+"<td>"
							+"<div>"
							+"<div>"
							+"<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0\" width=\"714\" height=\"185\">"
							+"<param name=\"movie\" value=\"../images/skin-1/wc.swf\" />"
							+"<param name=\"quality\" value=\"high\" />"
							+"<param name=\"WMODE\" value=\"transparent\">"
							+"<embed src=\"../images/skin-1/wc.swf\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"714\" height=\"185\"></embed>"
							+"</object>"
							+"</div>"
						+"</td>"
					+"</tr>"
                    +"</table>";                                
