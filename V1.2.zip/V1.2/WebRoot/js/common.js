$(function(){
	//全局的ajax访问，处理ajax清求时sesion超时  
	$.ajaxSetup({   
	    contentType:"application/x-www-form-urlencoded;charset=utf-8", 
	    global: true,
	    complete:function(XMLHttpRequest,textStatus){ 
	        var sessionstatus = XMLHttpRequest.getResponseHeader("sessionstatus"); //通过XMLHttpRequest取得响应头，sessionstatus，  
	        if(sessionstatus == "timeout"){  
	        	//如果超时就处理 ，指定要跳转的页面  
	        	window.location.replace("${path}/system/login.action");  
	        }   
		}
	});
});
function trim(str){//去除字符串中所有空格
	return str.replace(/\s/g,"");
}

function trim2(str){//去除字符串中所有空格,斜杠，括号
	return str.replace(/(\s)|(\\)|(\()|(\))|(\+)|(\*)/g,"");
}
//检查电话号码，规则：以数字开头和结尾，以“－”分隔的字符串。
function fIsPhone(telstr)
{
	if(!telstr) return false;
	if(trim(telstr)=="") return false;
	if(isNaN(trim(telstr).substring(0,1))) return false;
	if(isNaN(trim(telstr).substring(trim(telstr).length-1,trim(telstr).length))) return false;
	var list=telstr.split("-");
	for(i=0;i<list.length;i++)
	{
		if(isNaN(list[i])) return false;
		if(!((list[i]).indexOf(".")==-1)) return false;
	}
	if(trim(telstr).length<7) return false;
	return true;
}

function fIsMobile(argstr)
{
	if(!argstr) return false;
	if(argstr.length!=11) return false;
	if(trim(argstr).length!=11) return false;
	if(isNaN(argstr)) return false;
	if(parseFloat(argstr)<0) return false;
	if(parseInt(argstr)-parseFloat(argstr)!=0) return false;	
	return true;
}

function testblank(str){ 	
	var myReg = /^[\s]+$/;
	return myReg.test(str);
}
function testpar(str){ 	
	var myReg = /[\(\)%_\'\"\\]/;
	return myReg.test(str);
}
function testnumchat(str){ 	
	var myReg = /^[a-zA-Z0-9 ]+$/;		
	return !myReg.test(str);
}

//身份证号判断
function testpersoncode(str){
	if(testnum(trim(str).substring(0,trim(str).length-1)))
		return false;
	if(trim(str).substring(trim(str).length-1,trim(str).length)!="x" && (trim(str).substring(trim(str).length-1,trim(str).length)!="X") && (testnum(trim(str).substring(trim(str).length-1),trim(str).length)))
	 return false;
	if(trim(str).length!="15" && trim(str).length!="18")
		return false;
	return true;
}

function testnum(str){ 	
	var myReg = /^(-|)[0-9]+$/;
	return myReg.test(str);
}
function testnumber(str){
	var flag=false;
	var myReg = /^[0-9]+$/;
	if(!myReg.test(str)){
		flag=true;
	}
//	if(str=="0"){
//		flag=true;
//	}
	return flag;
}

//是否是数字（0-9）
//可以是小数
function isNumber(value)
{
	var num=/[^0-9]/;
	var dot;
	var times=0;
	var a;
	var b;
	for(var loc=0;loc<value.length;loc++)
	{
		if(value.charAt(loc)=='.')
		{
			dot=loc;
			times++;
		}
	}
	if(times>1)
		return false;
	a=value.substring(0,dot);
	b=value.substring(dot+1,value.length);
	return !num.test(a)&&!num.test(b);
}

//字符串是否只有字母和数字（A-Z,a-z,0-9）
//数字不能包含小数点
function isLetOrNum(value)
{
	var letOrNum=/[^0-9A-z]/;
	return !letOrNum.test(value);
}

//是否有效字符，是返回ture；否则返回false
//有效字符为：数字或字母的集合
function bvalidstring(theStr){
	if(theStr.length==0) return false;
	for (var loc=0;loc<theStr.length;loc++)
	{
		if(((theStr.charAt(loc)<'0') || (theStr.charAt(loc)>'9'))
		   &&((theStr.charAt(loc)<'a')||(theStr.charAt(loc)>'z'))
		   &&((theStr.charAt(loc)<'A')||(theStr.charAt(loc)>'Z'))){
			return (false);
		}
	}
	return true;
}

//字符串里是否存在单引号
function single(value)
{
	var parttern=/[\']/;
	return parttern.test(value);
}

//字符串是否只有字母（A-Z,a-z）
function isLetter(value)
{
	var letter=/[^A-z]/;
	return !letter.test(value);
}
function isInt(value){//判断是否正整数
	var number=/[^0-9]/;
	return !number.test(value);
}
function testchar(str){	
	var myReg = /^[a-zA-Z]+$/;		
	return !myReg.test(str);
}
//验证email	
function checkEmail(str){
	var myReg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	return myReg.test(str);
}

function funDateCompare(Date1,Time1,Date2,Time2)
{
	var sign=0;
	var DateList1=Date1.split("-");
	var DateList2=Date2.split("-");
	if(Time1==""&&Time2=="")
	{
		sign=1;
	}
	else
	{
		if(Time1!=""&&Time2!="")
		{
			sign=2;
		}
	}
	if(sign==1)
	{
		DateTime1=new Date(DateList1[0],DateList1[1]-1,DateList1[2],0,0,0,0);
		DateTime2=new Date(DateList2[0],DateList2[1]-1,DateList2[2],0,0,0,0);
		var N=DateTime1-DateTime2;
		return N;
	}
	
	if(sign==2)
	{
		var TimeList1=Time1.split(":");
		var TimeList2=Time2.split(":");
		DateTime1=new Date(DateList1[0],DateList1[1]-1,DateList1[2],TimeList1[0],TimeList1[1]);
		DateTime2=new Date(DateList2[0],DateList2[1]-1,DateList2[2],TimeList2[0],TimeList2[1]);
		var N=DateTime1-DateTime2;
		return N;
	}
	if(sign==0)
	{
		alert("请检查日期比较函数时间参数要不全空要不全有");
	}
	
}

/*
==================================================================
功能：验证身份证号码是否有效
提示信息：未输入或输入身份证号不正确！
使用：isIDno(obj,string)
返回：bool
==================================================================
*/
function isIDno(obj,ShowMsg){
	var show = IfShow(ShowMsg);
	
	//aCity={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"};
	var aCity = "11,12,13,14,15,21,22,23,31,32,33,34,35,36,37,41,42,43,44,45,46,50,51,52,53,54,61,62,63,64,65,71,81,82,91";
	
	var iSum = 0;
	var info = "";
	var idCardLength = obj.value.length;

	if(!/^\d{17}(\d|x)$/i.test(obj.value)&&!/^\d{15}$/i.test(obj.value)){
		if (show) alert(ShowMsg);
		obj.focus();
		obj.select();
		return false;
	}

	//在后面的运算中x相当于数字10,所以转换成a
	obj.value = obj.value.replace(/x$/i,"a");
	
	var curCity = obj.value.substr(0,2);

	if(!(aCity.indexOf(curCity) >= 0) ){
		if (show) alert(ShowMsg);
		obj.focus();
		obj.select();
		return false;
	}

	if (idCardLength==18){
		sBirthday=obj.value.substr(6,4)+"-"+Number(obj.value.substr(10,2))+"-"+Number(obj.value.substr(12,2));
		var d = new Date(sBirthday.replace(/-/g,"/"));
		if(sBirthday!=(d.getFullYear()+"-"+ (d.getMonth()+1) + "-" + d.getDate())){
			if (show) 
			alert(ShowMsg);
			obj.focus();
			obj.select();
			return false;
		}
		for(var i = 17;i>=0;i--)
		iSum += (Math.pow(2,i) % 11) * parseInt(obj.value.charAt(17 - i),11);
		if(iSum%11!=1){
			if (show) 
			alert(ShowMsg);
			obj.focus();
			obj.select();
			return false;
		}

	}else if (idCardLength==15){
		sBirthday = "19" + obj.value.substr(6,2) + "-" + Number(obj.value.substr(8,2)) + "-" + Number(obj.value.substr(10,2));
		var d = new Date(sBirthday.replace(/-/g,"/"));
		var dd = d.getFullYear().toString() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(sBirthday != dd){ 
			if (show) 
			alert(ShowMsg);
			obj.focus();
			obj.select();
			return false;
		}
	}
	obj.value = obj.value.replace(/a$/i,"x");
	return true; 
} 
function IfShow(ShowMsg){
	if (ShowMsg == "" ){
		return false;
	}else{
		return true;
	}
}
// 中间弹出新窗体
function wopen(pageURL,innerTitle, innerWidth, innerHeight)
{    
    var ScreenWidth  = screen.width;
    var ScreenHeight = screen.height;
    var StartX = (ScreenWidth - innerWidth) / 2;
    var StartY = (ScreenHeight - innerHeight) / 2;
    if(StartY>40)
    {
    	StartY=StartY-40;
    }
//    if((ScreenWidth/ScreenHeight)>(16 / 9))
//	{
//		StartX =  (ScreenWidth / 2-innerWidth) / 2;
//	}
	win =  window.open(pageURL, innerTitle, 'left='+ StartX + ', top='+ StartY + ', Width=' + innerWidth +', height=' + innerHeight 
    			+ ', resizable=yes, scrollbars=yes, status=yes, toolbar=no, menubar=no, location=no');
    winlist.push(win);
    return win;
}
function r_OpenWindow(pageURL,innerTitle, innerWidth, innerHeight)
{    
    var ScreenWidth  = screen.width;
    var ScreenHeight = screen.height;
    var StartX = (ScreenWidth - innerWidth) / 2;
    var StartY = (ScreenHeight - innerHeight) / 2;
    if(StartY>40)
    {
    	//alert("40");
    	StartY=StartY-40;
    }
    if((ScreenWidth/ScreenHeight)>(16 / 9))
	{
		StartX =  (ScreenWidth / 2-innerWidth) / 2;
	}
    return window.open(pageURL, '_blank', 'left='+ StartX + ', top='+ StartY + ', Width=' + innerWidth +', height=' + innerHeight 
    			+ ', resizable=yes, scrollbars=yes, status=yes, toolbar=no, menubar=no, location=no');
}
//实现父窗体关闭子窗体同时关闭
var winlist = new Array();  
function closeAllWin(){
	for(var i= 0; i < winlist.length; i++)   
      if(!winlist[i].closed)   
           winlist[i].close();  
}
//关闭窗体并将焦点交给父窗体
function winClose(){
	try{
		window.close();
		window.opener.focus();
	}catch(e){
		
	}
}
// 验证日期
function checkDate(date){
	var myReg = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;
	return myReg.test(date);
}

// 验证手机电话
function checkMob(str)
{
  var myReg=/^((13)|(15))(\d{9})$/;
  return myReg.test(str);
}

//验证时间（时，分，秒）
function checkTime(time){
	var p = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;  
	if(!p.test(time.substr(0,10))) return false;
	if (!/^\d\d:\d\d:\d\d$/.test(time.substr(11,21))) return false;
	d=time.substr(11,21).split(':');
	if (d[0]<0||d[0]>23) return false;
	if (d[1]<0||d[1]>59) return false;
	if (d[2]<0||d[2]>59) return false;
	return true;
}

//验证时间（时，分）
function checkTimes(time){
	var p = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;  
	if(!p.test(time.substr(0,10))) return false;
	if (!/^\d\d:\d\d$/.test(time.substr(11,19))) return false;
	d=time.substr(11,19).split(':');
	if (d[0]<0||d[0]>23) return false;
	if (d[1]<0||d[1]>59) return false;
	return true;
}

//验证时间（时，分）
function checkTimesHM(time){
	var p = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;  
	if(!p.test(time.substr(0,10))) return false;
	if (!/^\d\d:\d\d$/.test(time.substr(11,16))) return false;
	d=time.substr(11,16).split(':');
	if (d[0]<0||d[0]>23) return false;
	if (d[1]<0||d[1]>59) return false;
	return true;
}
//验证年月日
function checkTimen(time){
	var p = /(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)/;  
	if(!p.test(time)) return false;
	return true;
}


// 验证用户名
function checkUser(str){
	var myReg = /^\w+$/;
	return myReg.test(str);
}
//全选复选框,obj:点击全选或全不选那个复选框对象，chk_name：要选中或不选中的复选框的名称
function chkAll(obj,chk_name){
	var chkname=chk_name?chk_name:"chk_record";
	var chks=document.getElementsByName(chkname);
	var flag=obj.checked;
	for(var i=0;i<chks.length;i++){
		chks[i].checked=flag;
	}
}
//检查是否有复选框选中，chk_name：要检查的复选框的名称
function checkChk(chk_name){
	var chkname=chk_name?chk_name:"chk_record";
	var chks=document.getElementsByName(chkname);
	for(var i=0;i<chks.length;i++){
		if(chks[i].checked){
			return true;
		}
	}
	return false;
	
}

//检查是否有复选框选中一个，chk_name：要检查的复选框的名称
function checkOne(chk_name){
	var chkname=chk_name?chk_name:"chk_record";
	var chks=document.getElementsByName(chkname);
	var count = 0;
	for(var i=0;i<chks.length;i++){
		if(chks[i].checked){
			count ++;
		}
	}
	
	if(count == 1){
		return true;
	}else if(count == 0){
		alert($("#alert_please_select_a_record").val());
		return false;
	}else{
		alert($("#alert_single_select").val());
		return false;
	}
}
//返回复选框选中的值
function getCheckChkValue(chk_name){
	var chkname=chk_name?chk_name:"chk_record";
	var id = '';
	var chks=document.getElementsByName(chkname);
	for(var i=0;i<chks.length;i++){
		if(chks[i].checked){
			id += chks[i].value + ';';
		}
	}
	return id.substring(0, id.length-1);
	
}

function getCheckBoxValue(id){
	var obj = Ext.getCmp(id).getValue();
	var ret = '';
	for(var i = 0;i< obj.length;i++){
		ret += obj[i].inputValue;
		if((i+1) != obj.length){
			ret += ',';
		}
	}
	
	return ret;
}


function checkboxSetValue(id,value){
	var obj = Ext.getCmp(id);
	
	//解开
	var checkValue = value.split(',');
	obj.items.each(function(c){
		for(var i = 0;i < checkValue.length;i++){
			
			if(checkValue[i]== c.inputValue){
				c.setValue(true);
			}
		}	
	});
}
//返回td对应的text内容 去掉最后的: 国际化判断的时候使用
function getTdText(id){
	text = $("#" + id).html();
	text = text.substr(0,text.length-1);

	return text;
}

function getFieldValue(id){
	return $("#" + id).val();
}
//一般用于页面只能填写数字的textfield onblur事件控制
function checknum1(obj){
	var sort=obj.value;
	if(sort!="" && testnumber(sort)){
		alert(getFieldValue("alert_only_number"));
		obj.value="";
	}
}

//字符转日期yyyy-mm-dd hh:mm格式
function str2Date(str){
	var date = new Date();
	
	date.setFullYear(str.substr(0,4), parseInt(str.substr(5,2))-1, str.substr(8,2));
	date.setHours(str.substr(11,2), str.substr(14,2));
	
	return date;
}
//验证文件后缀名是否满足要求
function testsuffix(str)
{
	var bool = false;
	var suf = str.toString().substring(parseInt(str.indexOf("."))+1,str.length);
	if("swf" == suf){
		bool = true;
	}
	return bool;
}
//验证ip
function checkIP(ip){
	var myReg = /^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
	return myReg.test(ip);
}
//判断是否为最多两位小数正数
function checkNum(value){
	var myReg = /^[0-9]+\.{0,1}[0-9]{0,2}$/;
	return myReg.test(value);
}
//验证探头编码是否正确，如172_18_0_1_000
function checkDetector(value){
	//var myReg = /((2[0-4]\d|25[0-5]|[01]?\d\d?)\_){4}(0{2}[0123])/;
	var myReg = /[a-f0-9]{4}_0{2}[0123]/;
	return myReg.test(value);
}
//判断一个值是否为空
function checkValue(value){
	if(value == "" || value == null || value == undefined || value == "null"){
		return false;
	}else{
		return true;
	}
}
//判断是否为正整数
function checkNumber(value){
	var myReg = /^[0-9]+$/;
	return myReg.test(value);
}
//判断MAC地址
function checkMac(value){
	var myReg = /[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}/;
	return myReg.test(value);
}
/**
 * 去掉数组中重复的字符串
 * @returns {Array}
 */
Array.prototype.uniqueString = function() { 
    var res = [], hash = {}; 
    for(var i=0, elem; (elem = this[i]) != null; i++)  { 
        if (!hash[elem]) 
        { 
            res.push(elem); 
            hash[elem] = true; 
        } 
    } 
    return res; 
};

/**
 * mask
 * 遮罩
 * 
 *
 * Requires:
 * 依赖:
 * 		jquery.js
 * 
 * How to use:
 * 使用方法:
 * 		$('.class').easyMask('show'[,options]);
 *		$('.class').easyMask('hide'[,options]);
 *
 *		$.easyMask('.class','show'[,options]);
 *		$.easyMask('.class','hide'[,options]);
 * 		
 *		options = {msg:''}
 *		default options = $.easyMask.options;
 */
(function($){
	//$对象
	$.fn.easyMask = function(method,options){
		return $.easyMask(this,method,options);
	}
	//全局函数
	$.easyMask = function(target,method,options){
		var tar = target||'body';
		var $targ = $(tar);
		var opt = $.extend({},$.easyMask.options,options);
		var method = $.easyMask.methods[method];
		if(method){
			return method(tar,opt);
		}
		return $targ;
	};
	
	$.easyMask.methods = {
		show:function(target,options){
			return $(target).each(function(){
				var $targ = $(this);
				//如果当前对象不是relative,那就添加该属性
				//$("#hehe").css("position")
				if($targ.css('position')!='relative'){
					$targ.data('position',$targ.css('position'));
					$targ.css('position','relative');
				}
				$('<div class=\'easy-mask\' style=\"display:block\"></div>').css('width',$targ.css('width')).appendTo($targ);
				var msg = $('<div class=\'easy-mask-msg\' style=\"display:block;left:50%\"></div>')
							.html(options.msg).appendTo($targ);
				msg.css("marginLeft", -msg.outerWidth() / 2);
			});
		},
		hide:function(target,options){
			return $(target).each(function(){
				$here = $(this);
				$here.children('.easy-mask').remove();  
				$here.children('.easy-mask-msg').remove();
				//还原position属性
				if($here.data().position!=undefined){
					$here.css("position",$here.data().position);
					$here.removeData('position');
				}
			});
		}
	}
	
	$.easyMask.options = {
		msg:'Loading...'
	};
})(jQuery);