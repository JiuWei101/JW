/**
 * add by wj 2013-04-03
 * index界面显示系统配置窗口
 */
$(function(){
//	$(".top").dblclick(function(){
//		$(".easyui-layout").layout('collapse','north')
//	});
//	$("#sys_dialog").dialog({
//		buttons:[{
//					text:$('#btn_save').val(),
//					iconCls:'icon-ok',
//					handler:function(){
//						save_sysModel();
//					}
//				},{
//					text:$('#btn_return').val(),
//					iconCls:'icon-cancel',
//					handler:function(){
//						$("#sys_dialog").dialog('close');
//					}
//				}],
//				modal:true,
//			    closable:false
//		});
//	$("#model_tb").show();
	
	$.ajax({
	    async: false,
		type: "POST",
		dataType: "json",
		url: "../system/saveSystemModel.action",
		data:{"user.sysModel":"2"},
		success: function(msg){
			if(msg.success){
			}else{
			}						
		},
		error:function(msg){
			
		}
	});
});