Ext.override(Ext.data.HttpProxy, {
	    /**
     * Callback for read action
     * @param {String} action Action name as per {@link Ext.data.Api.actions#read}.
     * @param {Object} o The request transaction object
     * @param {Object} res The server response
     * @fires loadexception (deprecated)
     * @fires exception
     * @fires load
     * @private
     */
    onRead : function(action, o, response) {
        var result;
        try {
            result = o.reader.read(response);
        }catch(e){
            // @deprecated: fire old loadexception for backwards-compat.
            // TODO remove in 3.1
            this.fireEvent('loadexception', this, o, response, e);

            this.fireEvent('exception', this, 'response', action, o, response, e);
            o.request.callback.call(o.request.scope, null, o.request.arg, false,response);
            return;
        }
        if (result.success === false) {
            // @deprecated: fire old loadexception for backwards-compat.
            // TODO remove in 3.1
            this.fireEvent('loadexception', this, o, response);

            // Get DataReader read-back a response-object to pass along to exception event
            var res = o.reader.readResponse(action, response);
            this.fireEvent('exception', this, 'remote', action, o, res, null);
        }
        else {
            this.fireEvent('load', this, o, o.request.arg);
        }
        // TODO refactor onRead, onWrite to be more generalized now that we're dealing with Ext.data.Response instance
        // the calls to request.callback(...) in each will have to be made identical.
        // NOTE reader.readResponse does not currently return Ext.data.Response
        o.request.callback.call(o.request.scope, result, o.request.arg, result.success,response);
    }
});

Ext.override(Ext.data.Store, {
	   // private
    // Called as a callback by the Reader during a load operation.
    loadRecords : function(o, options, success,res){
        if(!o || success === false){
            if(success !== false){
                this.fireEvent('load', this, [], options);
            }

            if(options.callback){
                options.callback.call(options.scope || this, [], options, false, res);
            }
            return;
        }
        var r = o.records, t = o.totalRecords || r.length;
        if(!options || options.add !== true){
            if(this.pruneModifiedRecords){
                this.modified = [];
            }
            for(var i = 0, len = r.length; i < len; i++){
                r[i].join(this);
            }
            if(this.snapshot){
                this.data = this.snapshot;
                delete this.snapshot;
            }
            this.clearData();
            this.data.addAll(r);
            this.totalLength = t;
            this.applySort();
            this.fireEvent('datachanged', this);
        }else{
            this.totalLength = Math.max(t, this.data.length+r.length);
            this.add(r);
        }
        this.fireEvent('load', this, r, options);
        if(options.callback){

            options.callback.call(options.scope || this, r, options, true,res);
        }
    }
});
//==========================================================================
//
//	
//  代码描述:弹出窗口ext样式
//  
//  传入参数: title    标题
//           msg      显示内容
//			 minWidth 最小宽度
//	         icon     显示在左边的图片 在不等于nowarning的时候都显示感叹号
//  	     fn       回调函数
//  返回参数:新窗口对象
//
//	作者    :jl
//==========================================================================
Ext.MessageBox.alert= function(title, msg, minWidth , icon ,fn, scope){
	if( icon != 'nowarning'){
	 icon =  Ext.MessageBox.WARNING;
	}else{
	  
	}
	
    this.show({
        title : title,
        msg : msg,
        buttons: this.OK,
        fn: fn,
        scope : scope,
        icon: icon,
        minWidth : minWidth
    });
    return this;
}

