Ext.namespace('Ext.ux');

Ext.ux.DataStore = function(){
   this.dataStore = new Array();
   this.parentRecord = new Array();
};
/*
 * dataStore层次结构
 * 1.dataStore数组:每个元素对应一个外层grid，其中包含grid对应的record记录和其他相关信息
 * 2.grid的子元素:包括其外层对象的一些属性，以及其内部的record数组
 * 3.record数组:记录子层的记录集
 * */
Ext.apply(Ext.ux.DataStore.prototype,{
	addRec : function(config){
		var is_insert = true

		//查找dataStore 如果存在则遍历并找到对应项并替换其record
		if(this.dataStore.length && this.dataStore.length!=0){
			var ds = this.dataStore;
			for(var i = 0;i < ds.length;i++){
				var d = ds[i];
				 
				//如果存在了替换
				if(d.id == config.id){
					d.record[config.rowIndex] = config.record;
					//为false不增加到dataStore
					is_insert = false;
				}
			}
			this.dataStore = ds;
		}
		
		//不存在对应的记录，新增
		if(is_insert){
			var d = {};
			d.id = config.id;
			d.err_col = config.err_col;
			d.parent = config.parent;
			d.err_colValue = config.err_colValue;
			d.record = new Array();
			d.record.push(config.record);
			this.dataStore.push(d);
		}
	},
	readRecord:function(json,ch_store,config){
		var parent_store = config.parent_store;
		//首先取得所有父record并存储
		for(var i = 0;i < parent_store.getCount();i++){
			var record = parent_store.getAt(i);
			var d = {};
			//alert(parent_store.idProperty)
			d.id = record.data[parent_store.idProperty];
			d.err_col = config.err_col;
			d.err_colValue = record.data[config.err_colId];
			d.record = new Array();
			this.dataStore.push(d)
		}
//		alert(Ext.util.JSON.encode(this.dataStore))
		for(var i = 0;i < json.length;i++){
			var record = new ch_store.recordType({newRecord : false});
			var field = record.fields;
		
			field.each(function(f){
//				alert([f.name])
//				alert(json[i][f.name])
				record.set([f.name],json[i][f.name]);
			})
			
//			alert(record.data[parent_store.idProperty])
			
			for(var j = 0;j < this.getDataStoreLen();j++){
				this.dataStore[j];
//				alert(this.dataStore[j].id)
				if( record.data[parent_store.idProperty] == this.dataStore[j].id){
					this.dataStore[j].record.push(record)
				}
			}
		}
//		alert(Ext.util.JSON.encode(this.dataStore))
	},
	getRecrodLen:function(id){
		var count = this.getDataStoreLen();
		if(count == 0){
			return 0;
		}

		var dataStore = this.dataStore;
		for(var i = 0;i < count;i++){
			var data = dataStore[i];
			if(id == data.id){
				return data.record.length;
			}
		}
		return 0;
	},
	getDataStoreLen:function(){
		return this.dataStore.length;
	}
	,
	getRecord:function(id){
		var record;
		if(this.getRecrodLen(id) == 0){
			return 0;
		}
		
		for(var i = 0;i < this.dataStore.length;i++){
			if(id == this.dataStore[i].id){
				record = this.dataStore[i].record;
			}
		}
		return record;
	},
	check:function(){
		var check = true;
		
		for(var i = 0;i < this.dataStore.length;i++){
			var record = this.dataStore[i];

			var ch_record = record.record;
			for(var j = 0;j < ch_record.length;j++){
				var r = ch_record[j];
				var field = r.fields;
				field.each(function(f){
					if(f.valid && !r.data[f.name]){
						Ext.Msg.alert(
							'警告',
							'"'+record.err_col+'"的值为['+record.err_colValue+'] 的记录,其对应的子表中"'+f.value+'"不能为空，请填写!',
							350
							)
						check = false;
						return false;
					}
				})
				if(check==false){
					break;
				}
			}
			
		
		}
		
		return check;
	},
	toJson:function(){
		var json='';
		var flag = false;

		for(var i = 0;i < this.dataStore.length;i++){
			var record = this.dataStore[i].record;
	
			for(var j = 0;j < record.length;j++){
				flag = true;
				
				json+=Ext.util.JSON.encode(record[j].data)
				
				if(flag){
					json += ','
				}
			}
		}
		
		json = json.substr(0,json.length-1)
		return json;
	},
	removeRecord:function(store_id,record_id,contact_id){
		for(var i = 0;i < this.dataStore.length;i++){
			var store = this.dataStore[i];

			if(store.id == store_id){
				for(var j = 0;j < store.record.length;j++){
					if(store.record[j].data['button_id'] == record_id||store.record[j].data[contact_id] == record_id){
						store.record.splice(j,1);
						j--;
					}
				}
				
			}
		}
		//alert(store.record.length)
	},
	removeStore:function(store_id){
		for(var i = 0;i < this.dataStore.length;i++){
			var store = this.dataStore[i];

			if(store.id == store_id){
				this.dataStore.splice(i,1);
				i--;
			}

		}
	},
	upremove:function(store_id,store){
		for(var i = 0;i < this.dataStore.length;i++){
			var ds = this.dataStore[i];
			if(ds.id == store_id){
				ds.record = new Array();
				for(var j = 0;j < store.getCount();j++){
					var record = store.getAt(j);
					ds.record[j]=record;
				}
			}
		}
//	},不用此验证zhaoyan100411
//	/**
//	 * 请求书的联系人列表验证总数
//	 * @return {Boolean}
//	 */
//	CheckCount:function(){
//		if(this.dataStore.length>1){
//			Ext.Msg.alert('警告','只能填写一条代表人对应的联系人信息！',300);
//			return false;
//		}
//		return true;
	}
})