Ext.namespace('Ext.ux');	/*定义命名空间 实际上就是指定包名*/
String.prototype.Trim = function() { return this.replace(/(^\s*)|(\s*$)/g, ""); }
/*首先继承BasicForm*/
Ext.ux.BasicForm = function(config) {
	Ext.apply(this, config);

	Ext.ux.BasicForm.superclass.constructor.call(this, config);
};

Ext.ux.BasicForm = Ext.extend(Ext.form.BasicForm, {
	
	setValues : function(values){
        if(Ext.isArray(values)){ // array of objects
            for(var i = 0, len = values.length; i < len; i++){
                var v = values[i];
                var f = this.findField(v.id);
                if(f){
                	if(isString(v.value)){
                   	 	f.setValue(v.value.replace(/<br\/>/ig,"\r\n"));
                	}else{
                		f.setValue(v.value)
                	}
                    if(this.trackResetOnLoad){
                    	if(isString(v.value)){
                        	f.originalValue = f.getValue().replace(/<br\/>/ig,"\r\n");
                    	}else{
                    		f.originalValue = f.getValue()
                    	}
                    }
                }
            }
        }else{ // object hash
            var field, id;
            for(id in values){
                if(!Ext.isFunction(values[id]) && (field = this.findField(id))){
               
                	if(isString(values[id])){
                    	field.setValue(values[id].replace(/<br\/>/ig,"\r\n"));
                	}else{
                		field.setValue(values[id]);
                	}
                	
                    if(this.trackResetOnLoad){
                    	if(isString(values[id])){
                        	field.originalValue = field.getValue().replace(/<br\/>/ig,"\r\n");
                    	}else{
                    		field.originalValue = field.getValue();
                    	}
                    }
                }
            }
        }
        return this;
    },

     /**
      * 重写源码 增加对radiogroup、checkboxgroup的处理
     */
    findField : function(id){
        var field = this.items.get(id);
        if(!Ext.isObject(field)){
            this.items.each(function(f){
            	/* 新添加对raidogourp以及checkboxgroup进行setvalues*/
            	if(f.isXType('raidogourp')||f.isXType('checkboxgroup')){
            		f.items.each(function(c){
            			if(c.isFormField &&(c.dataIndex == id || c.id ==id || c.getName() == id)){
            				field = c;
							return false;
						}	
				})
			}
			
            if(f.isFormField && (f.dataIndex == id || f.id == id || f.getName() == id)){
                field = f;
                return false;
            }
            });
        }
        return field || null;
    }
   	
});

Ext.ux.FormPanel = function(config) {
	Ext.apply(this, config);

	Ext.ux.FormPanel.superclass.constructor.call(this, config);
};
/*
 * 具体属性
 * 1.label居左-labelAlign属性
 * 2.按钮居中-buttonAlign属性
 * 3.表单验证为true-monitorValid属性
 * */
Ext.ux.FormPanel = Ext.extend(Ext.FormPanel, {
	
	//初始化组件
	initComponent : function() {
		
		//调用父类的初始化组件，必须调用
		Ext.ux.FormPanel.superclass.initComponent.apply(this, arguments);
	},
    
    //渲染
    onRender : function() {
    	//初始化父类的onRender，必须调用
    	Ext.ux.FormPanel.superclass.onRender.apply(this, arguments);
    	
    	/* 订阅关闭事件 统一用closeEvent来发布*/
 
    },
    
     // private
    createForm : function(){
        var config = Ext.applyIf({listeners: {}}, this.initialConfig);
        return new Ext.ux.BasicForm(null, config);
    },
    
    layout: 'form',    
    frame: true,
	labelAlign: 'right',
    buttonAlign: 'center',
    monitorValid: true,		//此属性为验证使用
    
    /* 定义弹出窗口事件 窗口大小 850*560*/
    createBigWindow:function(url,title){
    	openBigWindow(url,title);
    },
    
     /* 定义弹出窗口事件 窗口大小 625*450*/
    createSmallWindow:function(url,title){
    	openBigWindow(url,title);
    },
    
     /* 定义弹出窗口事件 窗口大小自定义*/
    createDefWindow:function(url,title,width,height){
    	openDefWindow(url,title,width,height);
    },
    
    /*调用BasicForm的方法 将编辑或者查看页的值回填*/
    setValues:function(values){
    	this.getForm().setValues(values)
    },
    /*返回key:value,key:value...形式串*/
    serializeForm : function(form) {

            var fElements = form.elements || (document.forms[form] || Ext.getDom(form)).elements,

                hasSubmit = false,

                encoder = encodeURIComponent,

                element,

                options, 

                name, 

                val,                

                data = '',

                type;

                

            Ext.each(fElements, function(element) {                 

                name = element.name;                 

                type = element.type;

              

                if ( name){

                    if(/select-(one|multiple)/i.test(type)) {

                        Ext.each(element.options, function(opt) {

                            if (opt.selected) {

                                data += String.format('"{0}":"{1}",', encoder(name), (opt.hasAttribute ? opt.hasAttribute('value') : opt.getAttribute('value') !== null) ? opt.value : opt.text);

                            }                               

                        });

                    } else if(!/file|undefined|reset|button/i.test(type)) {

                            if(!(/radio|checkbox/i.test(type) && !element.checked) && !(type == 'submit' && hasSubmit)){

                                

                                data += '"'+encoder(name) + '":"' + valueReplace(element.value) + '",';                     
                                hasSubmit = /submit/i.test(type);    

                            }                       

                    } 

                }

            });        
			//alert(data.substr(0, data.length - 1))

            return data.substr(0, data.length - 1);

        },
          /*返回key:value,key:value...形式串*/
    serializeFormBr : function(form) {

            var fElements = form.elements || (document.forms[form] || Ext.getDom(form)).elements,

                hasSubmit = false,

                encoder = encodeURIComponent,

                element,

                options, 

                name, 

                val,                

                data = '',

                type;

                

            Ext.each(fElements, function(element) {                 

                name = element.name;                 

                type = element.type;

              

                if ( name){

                    if(/select-(one|multiple)/i.test(type)) {

                        Ext.each(element.options, function(opt) {

                            if (opt.selected) {

                                data += String.format('"{0}":"{1}",', encoder(name), (opt.hasAttribute ? opt.hasAttribute('value') : opt.getAttribute('value') !== null) ? opt.value : opt.text);

                            }                               

                        });

                    } else if(!/file|undefined|reset|button/i.test(type)) {

                            if(!(/radio|checkbox/i.test(type) && !element.checked) && !(type == 'submit' && hasSubmit)){

                                

                                data += '"'+encoder(name) + '":"' + valueReplaceBr(element.value) + '",';                     
                                hasSubmit = /submit/i.test(type);    

                            }                       

                    } 

                }

            });        
			//alert(data.substr(0, data.length - 1))

            return data.substr(0, data.length - 1);

        }
        ,
        getCheckBoxValue:function(id,format){
        	var value ='';
        
        	var checkBoxGroup = Ext.getCmp(id);
       
        	var checkBox = checkBoxGroup.getValue();
        	
        	if(checkBox.length){
        		if(format == 'json'){
        			value +='[';
        		}
        	}
        	for(var i = 0;i < checkBox.length;i++){
        		if(format == 'json'){
        			value += "{"
        		}
        		value += checkBox[i].getRawValue();
        		
        		if(format == 'json'){
        			value += "}"
        			if((i+1) != checkBox.length){
        				value += ','
        			}
        		}else
        		if((i+1) != checkBox.length){
        			value += ';'
        		}
        	}
        	
        	if(checkBox.length){
        		if(format == 'json'){
        			value +=']';
        		}
        	}
        	return value;
        },
        bindHandler : function(){	//重写验证方法 加入对不为空时 输入空格仍可点保存的问题
	        var valid = true;
	        this.form.items.each(function(f){
	            if(!f.isValid(true)){
	                valid = false;
	                return false;
	            }else{
	            	if(f.allowBlank == false && f.disabled == false){
		            	if(String(f.getValue()).Trim() == ''){
		            		valid = false;
		                	return false;
		            	}
	            	}
	            }
	        });
	        if(this.fbar){
	            var fitems = this.fbar.items.items;
	            for(var i = 0, len = fitems.length; i < len; i++){
	                var btn = fitems[i];
	                if(btn.formBind === true && btn.disabled === valid){
	                    btn.setDisabled(!valid);
	                }
	            }
	        }
	        this.fireEvent('clientvalidation', this, valid);
      }
    
    
   	
});

Ext.reg('forsoft-form', Ext.ux.FormPanel);


function valueReplace(v){
	/*转义双引号*/
	v=v.toString().replace(new RegExp('(["\"])', 'g'),"\\\""); 
	
	/*将回车符转义*/
	v=v.replace(/\r/ig,"\\r");
	v=v.replace(/\n/ig,"\\n");
	
	return v; 
} 

function valueReplaceBr(v){
	/*转义双引号*/
	v=v.toString().replace(new RegExp('(["\"])', 'g'),"\\\""); 
	
	/*将回车符转义*/
	v=v.replace(/\r\n/ig,"<br/>");

	
	return v; 
} 

 function isString(str){ 
        return (typeof str=='string')&&str.constructor==String; 
    } 