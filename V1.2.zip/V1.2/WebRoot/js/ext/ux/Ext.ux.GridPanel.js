Ext.namespace('Ext.ux');	/*定义命名空间 实际上就是指定包名*/

Ext.ux.GridPanel = function(config) {
	Ext.apply(this, config);

	Ext.ux.GridPanel.superclass.constructor.call(this, config);
};

Ext.ux.GridPanel = Ext.extend(Ext.grid.GridPanel, {
	loadMask : true,	//加载时屏蔽表格 会有一个Ext.LoadMask的遮罩效果。
	stripeRows : true,
	loadMask   : {
        msg : '载入中,请稍候......'
       },
	//初始化组件
	initComponent : function() {

		//调用父类的初始化组件，必须调用
		Ext.ux.GridPanel.superclass.initComponent.apply(this, arguments);
	},
    
    //渲染
    onRender : function() {
    	//初始化父类的onRender，必须调用
    	Ext.ux.GridPanel.superclass.onRender.apply(this, arguments);
    	
    	/* 订阅关闭事件 统一用closeEvent来发布*/
    	
 
    },
    
    /*公共方法:用于重新刷新grid*/
    reload: function(limit){
    	var store = this.store;
    	store.load({
			params : {
				start : 0,
				limit : limit
			}
    	});
    },
    /*公用方法: 用于返回选中行数*/
    getSmCount:function(){
		return this.getSelectionModel().getCount();
	},
	/*公用方法: 用于返回选中行Array*/
	getSmSelections:function(){
		return this.getSelectionModel().getSelections();
	},
   	
	/*公用方法: 判断只能选择一行*/
	validSelectOne:function(){
		if(this.getSmCount() == 0 ){
			Ext.Msg.alert('警告', '请选择一条记录进行操作'); 
			return false;
		}
		
		if(this.getSmCount() != 1 ){
			 Ext.Msg.alert('警告', '您只能操作一条记录'); 
			return false;
		}
		return true;
	},
	 /*公用方法提交时将store转换成json*/
    store2Json:function(){
    	var json = "[";
    	var store = this.store;
    	for(var i = 0;i < store.getCount();i++){
    		var record = store.getAt(i);
			if(i>0){
				json+= ',';
			}
			json += Ext.util.JSON.encode(record.data)
								
		}
		json += "]";
		return json;
    },
    setValue2Grid:function (json){
    	var store = this.store;
		var rec = new store.recordType({
			newRecord : true
		});
		var field = rec.fields;
		field.each(function(f){
			rec.set([f.name],json[f.name]);
		})
		store.insert(store.getCount(), rec);
	},
	removeSelections : function() {
		var grid = this;
		var selectedRow = this.getSelectionModel().getSelections();
		// var grid = this;
		if (selectedRow.length == 0) {
			return;
		}
		Ext.MessageBox.confirm('询问', '是否删除选中记录？', function(btn) {
			if (btn == 'yes') {
				if (selectedRow) {
					for (var i = 0; i < selectedRow.length; i++) {
						this.removeRecord(selectedRow[i]);
					}
					//需要刷新grid 避免Ext.grid.RowNumberer()出现断号
					grid.view.refresh();
				}
			}
		}, this);

	},
	removeRecord : function(record) {
		if (record.dirty) {
			// if the record is dirty (not yet in the database), reje
			// ct the changes
			record.reject();
		}


		this.store.remove(record);
	},	
	upRemove:function(){
		var selectedRow = this.getSelectionModel().getSelections();
		var store = this.getStore();
		
		//暂时只实现一行的上移
		if(selectedRow.length == 0){
			Ext.MessageBox.alert('警告','请选择一行数据进行移动')
			return false;
		}
		
		//暂时只实现一行的上移
		if(selectedRow.length > 1){
			Ext.MessageBox.alert('警告','只能上移一行数据')
			return false;
		}
		for (var i = 0; i < selectedRow.length; i++) {
			var record = selectedRow[i];
			//获取行坐标
			 var rowIndex = store.indexOfId(record.id);
			 if(rowIndex == 0){
			 	Ext.MessageBox.alert('警告','不能上移第一行数据');
			 	return false;
			 }
		  	store.remove(record);
          	store.insert(rowIndex-1, record);
			this.view.refresh();
			//修改dataStore
			DataStore.upremove(record.data['comp_detail_id'],store)
		}
	},
	downRemove:function(){
		var selectedRow = this.getSelectionModel().getSelections();
		var store = this.getStore();
		
		//暂时只实现一行的上移
		if(selectedRow.length == 0){
			Ext.MessageBox.alert('警告','请选择一行数据进行移动')
			return false;
		}
		
		//暂时只实现一行的上移
		if(selectedRow.length > 1){
			Ext.MessageBox.alert('警告','只能下移一行数据')
			return false;
		}
		for (var i = 0; i < selectedRow.length; i++) {
			var record = selectedRow[i];
			//获取行坐标
			 var rowIndex = store.indexOfId(record.id);
			 if(rowIndex == (store.getCount()-1)){
			 	Ext.MessageBox.alert('警告','不能下移最后一行数据');
			 	return false;
			 }
		  	store.remove(record);
          	store.insert(rowIndex+1, record);
			this.view.refresh();
			//修改dataStore
			DataStore.upremove(record.data['comp_detail_id'],store)
		}
	}
});

Ext.reg('forsoft-grid', Ext.ux.GridPanel);