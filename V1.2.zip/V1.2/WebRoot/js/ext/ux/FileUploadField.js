//*****************************************上传的公共js***************************************************************//   
  
/**  
 
 * 约定:types为调用时传来的参数.形式为jsp-gig-png  
 
 *      uploadid为上传后要填充路径的控件id  
 
 *      上传的属性均为upload  
 
 * 功能:页面调用openUpload("","");方法即可  
 
 */  
  
//...允许上传的后缀名   
  
var types = "";   
  
  
  
//...上传后填充控件的id   
  
var uploadid = "";   
  
  
  
function openUpload(type,id){   
  
    types = type;   
  
    uploadid = id;   
  
    winUpload.show();   
  
  }   
  
  
  
var formUpload = new Ext.form.FormPanel({   
  
    baseCls: 'x-plain',   
  
    labelWidth: 80,   
  
    fileUpload:true,   
  
    defaultType: 'textfield',   
  
    items: [{   
  
      xtype: 'textfield',   
  
      fieldLabel: '文 件',   
  
      name: 'upload',   
  
      inputType: 'file',   
  
      allowBlank: false,   
  
      blankText: '请上传文件',   
  
      anchor: '90%'  // anchor width by percentage   
  
    }]   
  
  });   
  
  
  
var winUpload = new Ext.Window({   
  
    title: '资源上传',   
  
    width: 400,   
  
    height:200,   
  
    minWidth: 300,   
  
    minHeight: 100,   
  
    layout: 'fit',   
  
    plain:true,   
  
    bodyStyle:'padding:5px;',   
  
    buttonAlign:'center',   
  
    items: formUpload,   
  
    buttons: [{   
  
      text: '上 传',   
  
      handler: function() {   
  
        if(formUpload.form.isValid()){   
  
          Ext.MessageBox.show({   
  
               title: 'Please wait',   
  
               msg: 'Uploading...',   
  
               progressText: '',   
  
               width:300,   
  
               progress:true,   
  
               closable:false,   
  
               animEl: 'loding'  
  
             });   
  
          formUpload.getForm().submit({       
  
            url:'uploadAction.action?types='+types,   
  
            success: function(form, action){   
  
               var objxzdz = Ext.get(uploadid).dom;   
  
               var value = action.result.msg;   
  
               objxzdz.value = value;   
  
               Ext.Msg.alert('成功','上传成功.');   
  
               winUpload.hide();     
  
            },       
  
             failure: function(form, action){       
  
              //... action生成的json{msg:上传失败},页面就可以用action.result.msg得到非常之灵活   
  
              Ext.Msg.alert('Error', action.result.msg);       
  
             }   
  
          })              
  
        }   
  
       }   
  
    },{   
  
      text: '取 消',   
  
      handler:function(){winUpload.hide();}   
  
    }]   
  
  });   
  
//*****************************************上传的公共js***************************************************************//   