Ext.namespace('Ext.ux');	/*定义命名空间 实际上就是指定包名*/

Ext.ux.Window = function(config) {
	Ext.apply(this, config);

	Ext.ux.Window.superclass.constructor.call(this, config);
};

Ext.ux.Window = Ext.extend(Ext.Window, {
	//初始化组件
	initComponent : function() {

		//调用父类的初始化组件，必须调用
		Ext.ux.Window.superclass.initComponent.apply(this, arguments);
	},
    
    //渲染
    onRender : function() {
    	//初始化父类的onRender，必须调用
    	Ext.ux.Window.superclass.onRender.apply(this, arguments);
    	
    	/* 订阅关闭事件 统一用closeEvent来发布*/
    	this.on('close', this.closeEvent, this);
    },
    
    frame : true,	/* 对象四周有圆角*/ 
 	closable:false,		/* 是否可关闭 � */
    layout :'form',/* 采用form对象布局*/
    plain : true
   	
});