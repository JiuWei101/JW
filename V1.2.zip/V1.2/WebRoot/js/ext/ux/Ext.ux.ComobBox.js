Ext.namespace('Ext.ux');	/*定义命名空间 实际上就是指定包名*/

Ext.ux.ComobBox = function(config) {
	Ext.apply(this, config);

	Ext.ux.ComobBox.superclass.constructor.call(this, config);
	
};

/*
 * 1.默认从本地取数据-mode属性
 * 2.显示文本对应code_name键值-valueField属性
 * 3.value值对应code_id键值-valueField属性
 * 4.阻止ComboBox渲染直到该对象被请求(被渲染到Ext.Editor 组件的时候应该使用这个参数)-lazyRender属性
 * 5.禁止用户直接在输入框内输入文本-editable属性
 * 6.默认为请选择-emptyText属性
 * */
Ext.ux.ComobBox = Ext.extend(Ext.form.ComboBox, {
	typeAhead: true,
	triggerAction: 'all',
	lazyRender:true,
	mode: 'local',
	valueField: 'code_id',
	displayField: 'code_name',
	editable: true,
	emptyText: '请选择',
	editable:true,
	forceAll:true,
	minChars:0,
	beforequery:function(qe){
		var combo = qe.combo;   
	    //q 是用户输入的文本内容.   
	    var q = qe.query;   
	    forceAll = qe.forceAll;   
	//alert('forceAll->'+forceAll+' q.length='+q.length+' combo.minChars='+combo.minChars)
	    if(forceAll === true || (q.length >= combo.minChars)){
	
	        if(combo.lastQuery !== q){   
	            combo.lastQuery = q;   
	            if(combo.mode == 'local'){   
	                combo.selectedIndex = -1;   
	                if(forceAll){  
	                    combo.store.clearFilter();   
	                }else{   
	                    combo.store.filterBy(function(record,id){   
	                        var text = record.get(combo.displayField);   
	                        //在这里写自己的过滤代码   暂时还没写
	                        return (text.indexOf(q)!=-1); 
	                    });   
	                    
	                    //自己添加如果没有查找到则将内容清空,防止将脏数据提交到后台
	                    if(combo.store.getCount() == 0 ){
	                    	combo.clearValue()
	                    }
	                }   
	                combo.onLoad();	               
	            }else{   
	                combo.store.baseParams[combo.queryParam] = q;   
	                if(combo.store.getCount() <= 0){
		                combo.store.load({   
		                    params: combo.getParams(q),
		                    callback:function(){
		                    
		                    } 
		                });   
		                }
	            //    combo.expand();  
	            	combo.store.filterBy(function(record,id){   
	                        var text = record.get(combo.displayField);   
	                        //在这里写自己的过滤代码   暂时还没写
	                        return (text.indexOf(q)!=-1); 
	                    });  
	                 //自己添加如果没有查找到则将内容清空,防止将脏数据提交到后台
	                if(combo.store.getCount() == 0 ){
	                	combo.clearValue()
	                }
	            }   
	        }else{
	            combo.selectedIndex = -1;   
	            combo.onLoad(); 
	              
	            //自己添加如果没有查找到则将内容清空,防止将脏数据提交到后台
                if(combo.store.getCount() == 0 ){
                	combo.clearValue()
                }
	        }   
	    }else{ 
	    	return false; 
	    
	    }
	},
	 // private
    initEvents : function(){
        Ext.form.ComboBox.superclass.initEvents.call(this);

        /**
         * @property keyNav
         * @type Ext.KeyNav
         * <p>A {@link Ext.KeyNav KeyNav} object which handles navigation keys for this ComboBox. This performs actions
         * based on keystrokes typed when the input field is focused.</p>
         * <p><b>After the ComboBox has been rendered</b>, you may override existing navigation key functionality,
         * or add your own based upon key names as specified in the {@link Ext.KeyNav KeyNav} class.</p>
         * <p>The function is executed in the scope (<code>this</code> reference of the ComboBox. Example:</p><pre><code>
myCombo.keyNav.esc = function(e) {  // Override ESC handling function
    this.collapse();                // Standard behaviour of Ext's ComboBox.
    this.setValue(this.startValue); // We reset to starting value on ESC
};
myCombo.keyNav.tab = function() {   // Override TAB handling function
    this.onViewClick(false);        // Select the currently highlighted row
};
</code></pre>
         */
        this.keyNav = new Ext.KeyNav(this.el, {
            "up" : function(e){
                this.inKeyMode = true;
                this.selectPrev();
            },

            "down" : function(e){
                if(!this.isExpanded()){
                    this.onTriggerClick();
                }else{
                    this.inKeyMode = true;
                    this.selectNext();
                }
            },

            "enter" : function(e){
                this.onViewClick();
            },

            "esc" : function(e){
                this.collapse();
            },

            "tab" : function(e){
                if (this.forceSelection === true) {
                    this.collapse();
                } else {
                    this.onViewClick(false);
                }
                return true;
            },

            scope : this,

            doRelay : function(e, h, hname){
                if(hname == 'down' || this.scope.isExpanded()){
                    // this MUST be called before ComboBox#fireKey()
                    var relay = Ext.KeyNav.prototype.doRelay.apply(this, arguments);
                    if(!Ext.isIE && Ext.EventManager.useKeydown){
                        // call Combo#fireKey() for browsers which use keydown event (except IE)
                        this.scope.fireKey(e);
                    }
                    return relay;
                }
                return true;
            },

            forceKeyDown : true,
            defaultEventAction: 'stopEvent'
        });
        this.queryDelay = Math.max(this.queryDelay || 10,
                this.mode == 'local' ? 10 : 10);
        this.dqTask = new Ext.util.DelayedTask(this.initQuery, this);
        if(this.typeAhead){
            this.taTask = new Ext.util.DelayedTask(this.onTypeAhead, this);
        }
        if(!this.enableKeyEvents){
            this.mon(this.el, 'keyup', this.onKeyUp, this);
        }
    },
	doQuery : function(q, forceAll){
        q = Ext.isEmpty(q) ? '' : q;
        var qe = {
            query: q,
            forceAll: forceAll,
            combo: this,
            cancel:false
        };
        //改造源码,在这里将事件重新赋给beforequery来处理
        this.on('beforequery',this.beforequery)
        if(this.fireEvent('beforequery', qe)===false || qe.cancel){
            return false;
        }
        q = qe.query;
        b = qe.forceAll
        forceAll = qe.forceAll;
        if(forceAll === true || (q.length >= this.minChars)){
            if(this.lastQuery !== q){
                this.lastQuery = q;
                if(this.mode == 'local'){
                    this.selectedIndex = -1;
                    if(forceAll){
                        this.store.clearFilter();
                    }else{
                        this.store.filter(this.displayField, q);
                    }
                    this.onLoad();
                }else{
                   /* this.store.baseParams[this.queryParam] = q;
                    this.store.load({
                        params: this.getParams(q)
                    });
                    this.expand();*/
                    this.selectedIndex = -1;
                if (forceAll) {
                        this.store.clearFilter()
                    } else {
                        this.store.filter(this.displayField, q)
                    }
                    this.onLoad()
                }
            }else{
                this.selectedIndex = -1;
                if (forceAll) {
                        this.store.clearFilter()
                    } else {
                        this.store.filter(this.displayField, q)
                    }
                    this.onLoad()

            }
        }
    },
        onTriggerClick : function(){
        if(this.readOnly || this.disabled){
            return;
        }
      
        if(this.isExpanded()){
            this.collapse();
            this.el.focus();
        }else {
            this.onFocus({});
            if(this.triggerAction == 'all') {
                this.doQuery(this.allQuery, true);
            } else {
                this.doQuery(this.getRawValue());
            }
            this.el.focus();
        }
    },
	bindStore : function(store, initial){
        if(this.store && !initial){
            if(this.store !== store && this.store.autoDestroy){
                this.store.destroy();
            }else{
                this.store.un('beforeload', this.onBeforeLoad, this);
                this.store.un('load', this.onLoad, this);
                this.store.un('exception', this.collapse, this);
            }
            if(!store){
                this.store = null;
                if(this.view){
                    this.view.bindStore(null);
                }
                if(this.pageTb){
                    this.pageTb.bindStore(null);
                }
            }
        }
        if(store){
            if(!initial) {
                this.lastQuery = null;
                if(this.pageTb) {
                    this.pageTb.bindStore(store);
                }
            }

            this.store = Ext.StoreMgr.lookup(store);
            this.store.on({
                scope: this,
                beforeload: this.onBeforeLoad,
                load: this.onLoad,
                exception: this.collapse
            });

            if(this.view){
                this.view.bindStore(store);
            }
        }
    }
    
   	
});

Ext.reg('forsoft-combox', Ext.ux.ComobBox);