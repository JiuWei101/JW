Ext.namespace('Ext.ux');	/*定义命名空间 实际上就是指定包名*/

Ext.ux.Panel = function(config) {
	Ext.apply(this, config);

	Ext.ux.Panel.superclass.constructor.call(this, config);
};

Ext.ux.Panel = Ext.extend(Ext.Panel, {
	//初始化组件
	initComponent : function() {

		//调用父类的初始化组件，必须调用
		Ext.ux.Panel.superclass.initComponent.apply(this, arguments);
	},
    
    //渲染
    onRender : function() {
    	//初始化父类的onRender，必须调用
    	Ext.ux.Panel.superclass.onRender.apply(this, arguments);
    	
    	/* 订阅关闭事件 统一用closeEvent来发布*/
    	
 
    }
});

