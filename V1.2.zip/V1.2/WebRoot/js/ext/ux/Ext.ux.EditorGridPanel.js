Ext.namespace('Ext.ux');

Ext.ux.EditorGridPanel = function(config) {
	Ext.apply(this, config);

	Ext.ux.EditorGridPanel.superclass.constructor.call(this, config);
};

Ext.ux.EditorGridPanel = Ext.extend(Ext.grid.EditorGridPanel, {
	loadMask : true,	//加载时屏蔽表格 会有一个Ext.LoadMask的遮罩效果。
	stripeRows : true, //为Grid的隔行之处都会加上x-grid3-row-alt样式。 原理是利用加入背景色的CSS规则来实现，但你可以用有修饰符"!important"的background-color样式覆盖这个规则，或使用较高优先级的CSS选择符。
	clicksToEdit : 1,	//单击编辑
	enableDragDrop: true,

	initComponent : function() {

		// call parent
		Ext.ux.EditorGridPanel.superclass.initComponent.apply(this, arguments);
	} // eo function initComponent
	// {{{
	,
	onRender : function() {
		// call parent
		Ext.ux.EditorGridPanel.superclass.onRender.apply(this, arguments);

		// bind a few useful events to handle row selection, and context menu
		this.on('render',this.onRenderEx);
		

	} ,// eo function onRender
	// }}}
	onRenderEx: function(){
		var grid = this;
		//行可拖拽 放到目标方法
		var drogAndDrap = new Ext.dd.DropTarget(grid.container, {
			ddGroup : 'GridDD',
	        copy    : false,
			 notifyDrop : function(dd, e, data) {
	            var rows = data.selections;
	            var index = dd.getDragData(e).rowIndex;
	            if (typeof(index) == "undefined") {
	                return;
	            }
	            for(i = 0; i < rows.length; i++) {
	                var rowData = rows[i];
	                if(!this.copy) 
	                    grid.store.remove(rowData);
	                	grid.store.insert(index, rowData);
	                	grid.view.refresh();
	            }
	        }
	
		 });
	}
	,
	onBeforeLoad : function(t, o, a) {//t代表this,o代表config即属性项

		if (this.isDirty()) {
			//如果参数passBeforeLoad为false则询问是否已保存
			if (!o.params['passBeforeLoad']) {
				delete(o.params['passBeforeLoad']);
				// var grid = this;
				Ext.MessageBox.confirm('询问', '数据已改变是否保存？', function(btn) {
					if (btn == 'yes') {
						this.commitChanges();
					} else {
						var pas = o.params;
						pas['passBeforeLoad'] = true;
						this.store.load({
							params : pas
						});
					}
				}, this);
				return false;
			}
		}
		// alert(o);
	}

	,
	/*增加一行记录在第一行*/
	addRecord : function() {
		var store = this.store;
		if (store.recordType) {
			var rec = new store.recordType({
				newRecord : true
			});
			rec.fields.each(function(f) {
				//rec.data[f.name] = f.defaultValue || null;
				rec.set([f.name],f.defaultValue || null) ;
			});
			//rec.commit();
			// store.add(rec);
			this.stopEditing();
			store.insert(0, rec);
			this.startEditing(0, 0);
			return rec;
		}
		return false;
	} // eo function addRecord

	// this function handles removing a record from the grid
	,
	/*增加一行记录在最后一行*/
	addRecordA : function() {
		var store = this.store;
		if (store.recordType) {
			var rec = new store.recordType({
				newRecord : true
			});
			rec.fields.each(function(f) {
				var defaultValue;
				//如果默认值是function则调用并取值
				if(Ext.isFunction(f.defaultValue)){
					defaultValue = f.defaultValue();
				}else{
					defaultValue = f.defaultValue;
				}

				rec.set([f.name],defaultValue || null) ;
			});

			this.stopEditing();
			store.insert(this.store.getCount(), rec);
			this.startEditing(0, 0);
			return rec;
		}
		return false;
	},
	removeRecord : function(record) {
		if (record.dirty) {
			// if the record is dirty (not yet in the database), reje
			// ct the changes
			record.reject();
		}


		this.store.remove(record);
	} // eo function removeRecord

	// 删除选择的记录
	,
	up1Record : function() {
		var selectedRow = this.getSelectionModel().getSelections();
		for (var i = 0; i < selectedRow.length; i++) {
			var tt = selectedRow[i];
			for(var id in tt[data]){
				alert(id)
			}
		}
	},
	removeSelections : function() {
		var grid = this;
		var selectedRow = this.getSelectionModel().getSelections();
		// var grid = this;
		if (selectedRow.length == 0) {
			return;
		}
		Ext.MessageBox.confirm('询问', '是否删除选中记录？', function(btn) {
			if (btn == 'yes') {
				if (selectedRow) {
					for (var i = 0; i < selectedRow.length; i++) {
						this.removeRecord(selectedRow[i]);
					}
					//需要刷新grid 避免Ext.grid.RowNumberer()出现断号
					grid.view.refresh();
				}
			}
		}, this);

	} // eo function removeSelections

	// 取得被删除记录的ID
	,
	getDeletedId : function() {
		var delId = [];
		for (var i = 0; i < this.deleted.length; i++) {
			delId.push(this.deleted[i].id);
		}
		return delId;
	}
	,
	commitChanges : function() {

		if (!this.isDirty()) {
			return;
		}
		var records = this.store.getModifiedRecords();
		var data = [];
		Ext.each(records, function(r, i) {
			var o = r.getChanges();
			if (r.data.newRecord) {
				o.newRecord = true;
			}
			o[this.idName] = r.get(this.idName);
			// o['oldId'] = r.id;
			data.push(o);
		}, this);
		var params = {
			// cmd:'saveData'
			objName : this.objName || '',
			idName : this.idName || '',
			data : Ext.encode(data),
			deletedId : Ext.encode(this.getDeletedId())
		};
		var grid = this;

		/*Grid.commitChanges(Ext.encode(params), function(data) {
			grid.requestCallback.call(grid, data);
		});*/
	} // eo function commitChanges

	,
	/*公共方法:用于重新刷新grid*/
    reload: function(limit){
    	var store = this.store;
    	store.load({
			params : {
				start : 0,
				limit : limit
			}
    	});
    },
    /*公用方法提交时将store转换成json*/
    store2Json:function(){
    	var json = "[";
    	var store = this.store;
    	for(var i = 0;i < store.getCount();i++){
    		var record = store.getAt(i);
			if(i>0){
				json+= ',';
			}
			json += Ext.util.JSON.encode(record.data)
								
		}
		json += "]";
		return json;
    },
    /*提交时检查store是否包含不能为空字段*/
    submitCheck:function(){
		var check = true;
		store = this.store;
		store.each(function(s,row){
			fields = s.fields;
			fields.each(function(f){
				if(f.valid){
					if(!s.data[f.name] || s.data[f.name] ==''){
						Ext.Msg.alert('警告','第'+(row+1)+'行的['+f.value+"]不能为空，请填写",300);
						check = false;
						return false;
						
					}
				}
			})
			
			if(check  == false){
				return false;
			}
		})
		return check;
	},
	setValue2Grid:function (json){
    	var store = this.store;
		var rec = new store.recordType({
			newRecord : true
		});
		var field = rec.fields;
		field.each(function(f){
			rec.set([f.name],json[f.name]);
		})
		this.stopEditing();
		store.insert(this.store.getCount(), rec);
		//this.startEditing(0, 0);
	}
}); // eo extend
Ext.reg('forsoft-editgrid', Ext.ux.EditorGridPanel);
