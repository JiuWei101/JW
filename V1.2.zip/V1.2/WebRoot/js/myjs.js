$(document).ready(function(){
var height = document.body.clientHeight;
height=height-138-40;
//document.getElementById("left").style.height=height+"px";
$(".left").css("height",height);
//document.getElementById("right").style.height=height+"px";
$(".iframediv").css("height",height);
var width= document.body.clientWidth;
width=width-184-50-50-8;
//document.getElementById("right").style.width=width+"px";
$(".iframediv").css("width",width);
//$(".framright").css("height",height+17);
//$(".framright_left").css("height",height+17);
$(".sty1").mousemove(function(){
	$(this).addClass("Selected_tr");
	});
$(".sty1").mouseout(function(){
	$(this).removeClass("Selected_tr");
});
$(".hiden").click(function(){
	var imgsrcc=$(this).attr("src");
	if(imgsrcc=="../images/show.jpg")
	{
	$(".tdflash").css("width","100%");
	$(".tdlist").css("display","none");
	$(this).attr("src","../images/Hide.jpg");
	}
	else
	{
	$(".tdflash").css("width","70%");
	$(".tdlist").css("display","block");
	$(".tdlist").css("width","100%");
	$(this).attr("src","../images/show.jpg");
		}
	});
});
