


function saveUserTitle()
{
    if($('#divUserTitle2').attr("innerText")==undefined){
    	 $('#divUserTitle2').text("您可以输入一些您的个性化描述"); 
         alert("[个性化描述]必须为1-17个字!");
         return;
    }
    var title2 = $('#divUserTitle2').attr("innerText").replace('\\','');
    if(trim(title2).length < 1 || trim(title2).length > 17){
        $('#divUserTitle2').text("您可以输入一些您的个性化描述"); 
        alert("[个性化描述]必须为1-17个字!");
        return;
    }
    
   $.ajax({
		async: true,
		type: "POST",
		url: "../maintain/ajax_saveUserTitle.action",
		data:encodeURI(encodeURI("title2="+title2)),
		success: function(data){
		}
	});
    
}


function ltrim(s){ 
    return s.replace( /^\s*/, ""); 
} 
 
function rtrim(s){ 
    return s.replace( /\s*$/, ""); 
} 

function trim(s){ 
    return rtrim(ltrim(s)); 
} 

function WebJsonService(methodUrl, callback, data) {
	if (data == null)
	{
		data = '{}';
	}
    //alert(data);
	$.ajax({
		url: methodUrl,
		data: data,
		type: "POST",
		contentType: "application/json;utf-8",
		dataType: 'json',
		error: function(msg, status) {
			if (status == 'error')
			{
				try {
					var json = eval('(' + msg.responseText + ')');
					alert(json.Message + '\n' + json.StackTrace);
				}
				catch (e) { }
			}
			else
			{
				alert(status);
			}
		},
		success: function(json) {
			callback(json);
			
		}
	});
}

function WebAjaxService(methodUrl, callback, data) {
	if (data == null)
	{
		data = '{}';
	}
    //alert(data);
	$.ajax({
		url: methodUrl,
		data: data,
		type: "POST",
		error: function(msg, status) {
			if (status == 'error')
			{
				try {
				}
				catch (e) { }
			}
			else
			{
				alert(status);
			}
		},
		success: function(msg) {
			callback(msg);
			
		}
	});
}
