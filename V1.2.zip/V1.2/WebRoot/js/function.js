function checkAll(radioName){
  	var flag = false;
	var a = document.getElementsByName(radioName);
	for (var i=0; i<a.length; i++){
  		if(a[i].checked){
  			flag = true;
  			break;
  		}
 	}
 	return flag;
}
function getRadioBoxValue(radioName){  
	var obj = document.getElementsByName(radioName);
    for(i = 0; i < obj.length; i++)    {  
		if(obj[i].checked)    {  
            return   obj[i].value;  
         }  
    }          
    return "undefined";        
} 
//�ַ��滻����entry�а�bad���ַ��滻��good
function strReplace( entry, bad, good ) {
	temp = "" + entry; // temporary holder
	while( temp.indexOf(bad) > -1 ) {
		pos= temp.indexOf( bad );
		temp = "" + ( temp.substring(0, pos) + good + 
			temp.substring( (pos + bad.length), temp.length) );
	}
	return temp;
}

//�Ƿ����֣��Ƿ���ture�����򷵻�false
//���ֲ��ܰ�С���
//�մ�����true
function bnum(theStr){
	if(theStr.length==0) return true;
	for (var loc=0;loc<theStr.length;loc++)
	{
		if((theStr.charAt(loc)<'0') || (theStr.charAt(loc)>'9')){
			return (false);
		}
	}
	return true;
}

//Ϊ��������ִ�����ָ��������䣬��ǰ�����0
//��num�ĳ��ȴ���len�򷵻�ԭ��
//�մ�����false
function fullnum(num, len) {
	if(num.length==0) return false;
	if(!bnum(num)) return false;
	if(num.length >= len) return num;
	sub = len-num.length;
	for(i=0; i<sub; i++) {
		num = '0' + num;
	}
	return num;
}

//�����ת����tab -> return
function tabtoreturn(){
    if(window.event.keyCode==13){
      window.event.keyCode=9;
    }
}

//�����ת����esc -> close
function esctoclose(){
	if(window.event.keyCode==27){
	  window.close();
	}
}



//ȡ��ǰ���ڵ���һ��,����dd��Ϊyyyy-mm-dd���ַ�
function nextDate(dd)
{
	var d=new Date();
	var year=parseInt(dd.substring(0,4));
	var month=parseInt(dd.substring(5,7))-1;
	var day=parseInt(dd.substring(8,10));
	var tmp=new Array(4);
	tmp[0]=4;
	tmp[1]=6;
	tmp[2]=9;
	tmp[3]=11;
	if((day==28)&&(month==2)&&!isLeapYear(year))//ƽ��
	{
		d.setYear(year);d.setMonth(2);d.setDate(1);
		return d;
	}
	if((day==29)&&(month==2)&&isLeapYear(year))//����
	{
		d.setYear(year);d.setMonth(2);d.setDate(1);
		return d;
	}
	if((month==12)&&(day==31))
	{
		d.setYear(year+1);d.setMonth(0);d.setDate(1);
		return d;
	}
	if((day==30)&&((month==4)||(month==6)||(month==9)||(month==11)))
	{
		d.setYear(year);d.setMonth(month+1);d.setDate(1);
		return d;
	}
	if(day==31)
	{
		d.setYear(year);d.setMonth(month+1);d.setDate(1);
		return d;
	}
	if(day==0)
		day=parseInt(dd.substring(9,10));
	d.setYear(year);d.setMonth(month);d.setDate(day+1);
	return d;
}

//�ж�����
function isLeapYear(year)
{
	var tmp=parseInt(year);
	if((tmp%4==0)&&(tmp%100!=0)||(tmp%400==0))
		return true;
	return false;
}

//�������� ��ʽΪ2007-7-8,2007/7/8,20070809,
function RandomDate(theStr){
	   str=theStr;
	  var str2="";
	  var t1=str.indexOf("/");
	  var t2=str.lastIndexOf("/");
	  var t3=str.indexOf("-");
	  var t4=str.lastIndexOf("-");
	  var t5=str.indexOf(".");
	  var t6=str.lastIndexOf(".");
	  var year="";
	  var month="";
	  var days="";
      var f;
	  if(t1>0&&t2>0){
	   f=str.split("/");
	    if(f.length!=3){
	    return "";
	    }
	    
         year=str.substring(0,t1);
		 month=str.substring(t1+1,t2);
		 days=str.substring(t2+1);
		 if(isNaN(year)){
		    return str2;
		 }
		 if(isNaN(month)){
		    return str2;
		 }
		 if(isNaN(days)){
		    return str2;
		 }
		 if((month<1)||(month>12)){
		
			    return str2;
			 }
			 if((days<1)||(days>31)){

				return str2;
			 }
		 if(year.length>4||year.length<2){
		     return str2;
		 }
		 if(year.length==2){
		    var tt=new Date().getFullYear()+"";
		     year=tt.substr(0,2)+year;
         }
			 
		
			 var date=new Date(year,month-1,days);
			 if(date.getMonth()<9){
			     if(date.getDate()<10){
			        str2=date.getFullYear()+"-0"+(date.getMonth()+1)+"-0"+date.getDate();
			     }
			     else{
			        str2=date.getFullYear()+"-0"+(date.getMonth()+1)+"-"+date.getDate();
			     }
             	
             }
             else{
                if(date.getDate()<10){
			        str2=date.getFullYear()+"-"+(date.getMonth()+1)+"-0"+date.getDate();
			     }
			     else{
			        str2=date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate();
			     }
             }
			 date =new Date();
			 if(str2.substring(0,4)>(date.getFullYear()+100)||str2.substring(0,4)<(date.getFullYear()-100)){
			    return "";
			 }

			
		return  str2;
	}
	   else  if(t3>0&&t4>0){
	      str=str.replace(/-/g,"/");
		  str=RandomDate(str);
		  return str;
		   
	    }
	    else  if(t5>0&&t6>0){
	      str=str.replace(/\./g,"/");
		  str=RandomDate(str);
		  return str;
		   
	    }
	/*    if(str.length==4){
	      if(isNaN(str)){

		     return "";
		  }
			date=new Date();
		   var v1=date.getFullYear()+30;
		   var v2=date.getFullYear()-30;
		   if(str<v1&&str>v2){
              str=str+"0101";
			  bTenDate(str);
		   }   
	   }   */
	   
     else   if(str.length==8){
		  if(isNaN(str)){
		     return "";
		  }
		    year=str.substr(0,4);
		   month=str.substr(4,2);
		    days=str.substr(6,2);
		    if((month<1)||(month>12)){
			    return str2;
			 }
			 if((days<1)||(days>31)){
				return str2;
			 }
		   date=new Date();
		   var v1=date.getFullYear()+30;
		   var v2=date.getFullYear()-30;
		   if(str.substr(0,4)<v1&&str>v2){
		      var dat=new Date(year,month-1,days);
			  if(dat.getMonth()<9){
			     if(dat.getDate()<10){
			        str2=dat.getFullYear()+"-0"+(dat.getMonth()+1)+"-0"+dat.getDate();
			     }
			     else{
			        str2=dat.getFullYear()+"-0"+(dat.getMonth()+1)+"-"+dat.getDate();
			     }
             	
             }
             else{
                if(dat.getDate()<10){
			        str2=dat.getFullYear()+"-"+(dat.getMonth()+1)+"-0"+dat.getDate();
			     }
			     else{
			        str2=dat.getFullYear()+"-"+(dat.getMonth()+1)+"-"+dat.getDate();
			     }
             }
			  return str2;
		   }   
		   return "";
		}
       else{
       
			return "";
	
	   }
}
//�ж��ַ�Ϊʱ���ʽ��hh24:mi:ss
//wangjun
function RandomTime(str)
{
	var rMsg = "";
	if (str.length!=8){
		return rMsg;
	}
	for (var loc=0;loc<str.length;loc++)
	{

		if(loc==2)
		{
	
			if(str.charAt(loc)!=":")	return rMsg;
		}
	    else if(loc==5)
		{
			if(str.charAt(loc)!=":")	return rMsg;
		}
		else if((str.charAt(loc)<'0') || (str.charAt(loc)>'9')){

			return rMsg;
		}
	}

	var hour = str.substr(0, 2);
	if(!(hour>="00"&&hour<="23")) 	return rMsg;	
	var minute=str.substr(3,2);	
	if(!(minute>="00"&&minute<="59"))	return rMsg;
	var second=str.substr(6,2);	
	if(!(second>="00"&&second<="59"))	return rMsg;
	return str;	
}

//�ж�ʱ���ʽΪ  "2005-05-30 13:09:00"��19λ
function beRandomTime(theStr)
{
	var msg="";
	var baseMsg="";
	var t=theStr.indexOf(" ");
	if(!(t>0)){
	   return msg;
	}
	msg=RandomDate(theStr.substring(0,t));
	if(msg==""){
	   return msg;
	}
	baseMsg=RandomTime(theStr.substring(t+1));
	if(baseMsg==""){
	  return "";
	}
	return msg+" "+baseMsg;

}

//�ж�ʱ���ʽΪ2005-06-07 ��10 λ
function bTenDate(theStr){

	var msg="";
	var baseMsg="������Ϸ������ڣ���ʽΪ 2005-05-30 ��";
	
	if (theStr.length!=10||theStr==''){
		return baseMsg;
	}
	for (var loc=0;loc<theStr.length;loc++)
	{
	    if(loc==4 || loc==7)
		{
			if(theStr.charAt(loc)!="-")	return baseMsg+"������֮�������Ӣ���ַ�-��������";
		}
		else if((theStr.charAt(loc)<'0') || (theStr.charAt(loc)>'9')){
			return baseMsg+"����ֵ����Ϊ���֡�";
		}
	}
	var y=theStr.substr(0,4);
	var m=theStr.substr(5,2);
	var d=theStr.substr(8,2);
	var isleap=false;
	if(y%100==0){//�ж��Ƿ�Ϊ����
		if(y%400==0){
			isleap=true;
		}
	}else if(y%4==0){
		isleap=true;
	}
	//alert("m="+m+",isleap="+isleap+",d="+d);
	if(m=="01"||m=="03"||m=="05"||m=="07"||m=="08"||m=="10"||m=="12")
	{
		if((d<1)||(d>31))
		{
			msg=y+"��"+m+"�������31�죡";
			return msg;
		}
     }
     else if(m=="04"||m=="06"||m=="09"||m=="11")
     {
		if((d<1)||(d>30)){
			msg=(y+"��"+m+"�������30�죡");
			return msg;
		}
	 }
	 else if(m=="02")
	 {
			if(isleap==true){
				if((d<1)||(d>29)){
					msg=(y+"��"+m+"�������29�죡");
					return msg;
				}
			}
			else{
				if((d<1)||(d>28)){
					msg=(y+"��"+m+"�������28�죡");
					return msg;
				}
			}
	  }
	   else
	  {
		    msg="�·ݲ��Ϸ����·�ӦΪ 01 �� 12����ʽΪ 2005-06-28 ��";
		    return msg;
	  }   
	  return msg;
}

//�ж��ַ�Ϊʱ���ʽ��hh24:mi:ss
//wangjun
function fnIsTrueTime(str)
{
	var rMsg = "";
	var msg="������Ϸ���ʱ��,��ʽΪ23:04:00��";	
	if (str.length!=8){
		return msg;
	}
	for (var loc=0;loc<str.length;loc++)
	{

		if(loc==2)
		{
			if(str.charAt(loc)!=":")	return msg+"Сʱ�ֱ�����Ӣ��:����";
		}
	    else if(loc==5)
		{
			if(str.charAt(loc)!=":")	return msg+"���������Ӣ��:����";
		}
		else if((str.charAt(loc)<'0') || (str.charAt(loc)>'9')){

			return msg+"ʱ��ֵ����Ϊ����";
		}
	}

	var hour = str.substr(0, 2);
	if(!(hour>="00"&&hour<="23"))	rMsg="Сʱ�����ڡ�00������23��֮�䡣";	
	var minute=str.substr(3,2);	
	if(!(minute>="00"&&minute<="59"))	rMsg="���ӱ����ڡ�00������59��֮�䡣";
	var second=str.substr(6,2);	
	if(!(second>="00"&&second<="59"))	rMsg="������ڡ�00������59��֮�䡣";

	return rMsg;	
}

//�ж�ʱ���ʽΪ  "2005-05-30 13:09:00"��19λ
function beLongTime(theStr)
{
	var msg="";
	var baseMsg="������Ϸ������ڣ�19λ���֣���ʽΪ  2005-05-30 13:09:00��";
	if (theStr.length!=19 || theStr==''){
		return baseMsg;
	}
	
	if(theStr.charAt(10)!=" ")	return baseMsg+"���ں�ʱ��֮��Ŀո�������롣";
	
	//�ж������Ƿ�Ϊʵ�ʴ��ڵ����ڡ�
    msg=bTenDate(theStr.substr(0,10));
    if(msg.length>0) return msg;

	//�ж������Ƿ�Ϊʵ�ʴ��ڵ����ڡ�
    msg=fnIsTrueTime(theStr.substr(11,8));
    if(msg.length>0) return msg;
	
	return msg;
}