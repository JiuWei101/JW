var unlockDialog;
$(function(){
	$(".onlyread tr td select").combobox({hasDownArrow: false});
	$(".onlyread tr td input").attr("readonly", "readonly");
	
	unlockDialog = $("#unlockDialog").dialog({						//解锁
		closable: true,
		modal: true,
		closed: true,
		buttons: [{
			text: '解锁',
			handler: function(){
				if($("#unlockPassword").val() == "ake123"){
					$(".onlyread tr td input").removeAttr("readonly");
					$(".onlyread tr td select").combobox({hasDownArrow: true});
					$("#res").html("");
					$("#unlockDialog").dialog("close");
				} else{
					$("#res").html("密码不正确,请重新输入");
				}
			}
		}]
	});
	
	var $map_cb = $("#map_cb");
	var $s_all = $("#s_all");//显示所有车位状态“按钮”
	var $a_all = $("#a_all");//显示所有车位状态及绘图区域的列表框
	var $p_btn = $("#p_btn");// 参数设置按钮
	var $paradlg = $("#paradlg"); //参数设置dialog
	var $paratab = $("#paratab"); //参数设置tab栏
	var $multiUpdate = $("#multiUpdate"); //OTA批量升级
	var $multiParaSet = $("#multiParaSet");
	$p_btn.on("click",function(){
		try {
			$paradlg.dialog("open");
		} catch (e) {
			// TODO: handle exception
		}
	});
	$paratab.tabs({
		border: false,
		fit: true,
		onSelect: function(title){
			if(title === "wifi信号强度"){
				if(!isSelectOneDtc()){
					return;
				}else{
					$("#wificnt").empty();
					var addr = getAddr();
					showMask();
					WifiStren.read(addr);
				}
			}
		}
	});
	$multiParaSet.on("click", function(){
		$("#mulitParaDlg").dialog("open");
		$("#multiPara").tabs({
			border: false,
			fit: true
		});
	});
	
	var WifiStren = {
		'read': function(addr){
			var that = this;
			$.ajax({
				async: true,
				type: 'post',
				url: '../debugtool/readWifiSignalStrength.action',
				dataType: 'json',
				data: {'data.shortmac':addr},
				success: function(data){
					hideMask();
					if(data.flag){
						that.show(data.arr);
					}else{
						alert(data.message);
					}
				},
				error: function(e){
					hideMask();
				}
			});
		},
		'show':function(arr){
			var html, $wificnt = $("#wificnt");
			if(arr.length > 0){
				html = "<tr><th scope='col'>AP名称</th><th scope='col'>信号强度</th></tr>";
				for(var i=0,len=arr.length; i<len; i++){
					html += "<tr><td class='row'>"+arr[i].apName+"</td><td class='row'>"+arr[i].signalStren+"</td></tr>";
				}
				$(html).appendTo($wificnt);
			}
		}
	};
	var $paraIP = $("#paraIP"),
		$paraPort = $("#paraPort"),
		$paraIPmask = $("#paraIPmask"),
		$paraNetworkgate = $("#paraNetworkgate"),
		$paraVer = $("#paraVer");
	$("#ip_read").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			showMask();
			IPManage.ipread(addr);
		}
	});
	$("#ip_set").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			IPManage.ipset(addr, $paraIP.val(), $paraPort.val(), $paraIPmask.val(), $paraNetworkgate.val());
		}
	});
	$("#dhcp_set").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			IPManage.dhcpset(addr, $paraPort.val());
		}
	});
	
	//批量识别区域设置
	$("#carCycle_set").on("click", function(){
		var $p_dialog = $('#p_dialog');			//弹出窗
		var _x1 = $("#topLeftX").val();
		var _y1 = $("#topLeftY").val();
		var _x2 = $("#botRigX").val();
		var _y2 = $("#botRigY").val();
		var addr = $("#detectorAddr").html();
		if(_x1 === '' || _x2 === '' || _y1 === '' || _y2 === ''){
			alert("请输入数字");
			return;
		}
		showMask();
		$.ajax({
			async: true,
			type: 'post',
			url: '../debugtool/setMultiCycle.action',
			dataType: 'json',
			data: {'data.shortmac': addr, 'carData.topLeftCornerX' : _x1, 'carData.topLeftCornerY' : _y1
				, 'carData.bottomRightCornerX' : _x2, 'carData.bottomRightCornerY' : _y2},
			success: function(data){
				hideMask();
				$p_dialog.dialog({
					width: 300,
					height: 200,
					resizable: true,
					title: '批量设置结果',
					content: data.message
				});
			},
			error: function(e){
				hideMask();
			}
		});
	});
	
	//批量识别参数设置
	$("#mulitLp_set").on("click", function(){
		var $p_dialog = $('#p_dialog');			//弹出窗
		var addr = $("#cameraAddr").html();
		showMask();
		$.ajax({
			async: true,
			type: 'post',
			url: '../debugtool/setMultiParam.action',
			dataType: 'json',
			data: {'data.shortmac':addr,
				'data.minPlateWidth':$("#paraMinPlateMulti").val(),
				'data.maxPlateWidth':$("#paraMaxPlateMulti").val(),
				'data.maxImageWidth':$("#paraMaxWidthMulti").val(),
				'data.maxImageHeight':$("#paraMaxHeightMulti").val(),
				
				'data.isVertCompress':getComboboxValue("isVertCompressMulti"),//是否垂直方向压缩1倍后识别，默认0
				'data.isFieldImage':getComboboxValue("isFieldImageMulti"),//是否是场图像 ，默认0
				'data.isOptSimpleFrame':getComboboxValue("isOptSimpleFrameMulti"),//是否视频图像中同一个车的多幅图像只输出一次结果，默认0
				'data.isMovingImage':getComboboxValue("isMovingImageMulti"),//识别运动or静止图像，默认0
				'data.isNight':getComboboxValue("isNightMulti"),//是否夜间模式，默认0
				
				'data.imageFormat':$("#paraNVMulti").val(),//NV21，默认6
				
				'data.optOrder':getComboboxValue("orderOptMulti"),//输出顺序选项 0-置信度 1-自上而下 2-自下而上，默认0
				'data.isLeanCorrect':getComboboxValue("isLeanCorrectMulti"),//是否启用倾斜校正功能，默认0
				'data.movingOutputOpt':getComboboxValue("movingOutputOptMulti"),//0-内部推送+外部获取 1:外部获取，默认0
				'data.identifyMode':getComboboxValue("improveSpeedMulti"),//识别模式，0: 识别率优先 1:识别速度优先，默认0
				'data.isEvaColor':getComboboxValue("isEvaColorMulti"),//是否识别车辆颜色，默认0
				'data.isVertFlip':getComboboxValue("isVertFlipMulti"),//是否位图，默认0
				'data.isDwordAligned':getComboboxValue("isDwordAlignedMulti"),//是否位图，默认0
				
				'data.provinces':$("#paraProMulti").val(),//省份字符串，默认无
				'data.reservedStr':$("#paraRevStrMulti").val(),//保留字符串
				'data.plateLocateShre':$("#paraLocShrMulti").val(),//车牌定位阈值，默认5
				'data.plateIdentShre':$("#paraIdeShrMulti").val(),//车牌识别阈值，默认1
				
				'data.indiviPlate':getComboboxValue("indiviPlateMulti"),//个性化车牌，默认0
				'data.doubleYelPlate':getComboboxValue("doubleYelPlateMulti"),//双层黄色车牌
				'data.armPolicePlate':getComboboxValue("armPolicePlateMulti"),//武警车牌，默认1
				'data.doubleMilPlate':getComboboxValue("doubleMilPlateMulti"),//双层军车
				'data.farmPlate':getComboboxValue("farmPlateMulti"),//农用车
				'data.emPlate':getComboboxValue("emPlateMulti"),//使领馆车
				'data.dbArmPoliPlate':getComboboxValue("dbArmPoliPlateMulti"),//双层武警车
				'data.isDetectCar':getComboboxValue("isDetectCarMulti"),//是否检测车辆
				
				'data.recognitionLibType':getComboboxValue("recognitionLibTypeMulti") //是否检测车辆
			},
			success: function(data){
				hideMask();
				$p_dialog.dialog({
					width: 300,
					height: 200,
					resizable: true,
					title: '批量设置结果',
					content: data.message
				});
			},
			error: function(e){
				hideMask();
			}
		});
	});
	
	var IPManage = {
		'ipread': function(addr){
			$.ajax({
				async: true,
				type: 'post',
				url: '../debugtool/readIP.action',
				dataType: 'json',
				data: {'data.shortmac':addr},
				success: function(data){
					hideMask();
					if(data.flag){
						$paraIP.val(data.ip);
						$paraPort.val(data.port);
						$paraIPmask.val(data.ipMask);
						$paraNetworkgate.val(data.returnNetwork);
						$paraVer.text(data.version);
					}else{
						alert(data.message);
					}
				},
				error: function(e){
					hideMask();
				}
			});
		},
		'ipset': function(addr, ip, port, mask, network){
			$.ajax({
				async: true,
				type: 'post',
				url: '../debugtool/setIP.action',
				dataType: 'json',
				data: {
					'data.shortmac': addr,
					'data.ipaddress': ip,
					'data.ipport': port,
					'data.ipmask': mask,
					'data.networkgate': network
				},
				success: function(data){
					alert(data.message);
				},
				error: function(e){
					
				}
			});
		},
		'dhcpset': function(addr, port){
			$.ajax({
				async: true,
				type: 'post',
				url: '../debugtool/setIP.action',
				dataType: 'json',
				data: {
					'data.shortmac': addr,
					'data.ipport': port
				},
				success: function(data){
					alert(data.message);
				},
				error: function(e){
					
				}
			});
		}
	};
	(function($){
		var yon = [{value:'0',text:'否'},{value:'1',text:'是'}];
		var dcar = [{value:'0',text:'0不检测'},{value:'1',text:'1使用前照灯检测'},{value:'2',text:'2使用尾灯检测'},{value:'3',text:'3启动前照灯和尾灯检测'},{value:'4',text:'4使用标记检测（只用于排除前照灯和尾灯的结果）'},{value:'7',text:'7(1+2+4)'}];
		var is = [{value:'0',text:'识别率优先'},{value:'1',text:'识别速度优先'}];
		var mo = [{value:'0',text:'外部获取'},{value:'1',text:'内部推送+外部获取'}];
		var no = [{value:'0',text:'置信度'},{value:'1',text:'自上而下'},{value:'2',text:'自下而上'}];
		var rlt = [{value:'0',text:'大陆'},{value:'1',text:'台湾'}];
		$("#isDetectCar, #isDetectCarMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:dcar,
			valueField:'value',
			value: '0',
			textField:'text'
		});
		$("#isNight, #isLeanCorrect, #isVertCompress, #isFieldImage, #isEvaColor, #isVertFlip, #isDwordAligned, #indiviPlate," +
				" #doubleYelPlate, #armPolicePlate, #doubleMilPlate, #farmPlate, #emPlate, #dbArmPoliPlate, #isOptSimpleFrame, #isMovingImage," +
				"#isNightMulti, #isLeanCorrectMulti, #isVertCompressMulti, #isFieldImageMulti, #isEvaColorMulti, #isVertFlipMulti," +
				" #isDwordAlignedMulti, #indiviPlateMulti, #doubleYelPlateMulti, #armPolicePlateMulti, #doubleMilPlateMulti, " +
				"#farmPlateMulti, #emPlateMulti, #dbArmPoliPlateMulti, #isOptSimpleFrameMulti, #isMovingImageMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:yon,
			valueField:'value',
			value: '0',
			textField:'text'
		});
		$("#improveSpeed, #improveSpeedMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:is,
			valueField:'value',
			value: '0',
			textField:'text'
		});
		$("#movingOutputOpt, #movingOutputOptMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:mo,
			valueField:'value',
			value: '0',
			textField:'text'
		});
		$("#orderOpt, #orderOptMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:no,
			valueField:'value',
			value: '0',
			textField:'text'
		});
		$("#recognitionLibType, #recognitionLibTypeMulti").combobox({
			width:100,
			panelHeight:'auto',
			editable:false,
			data:rlt,
			valueField:'value',
			value: '0',
			textField:'text'
		});
	})($);
	
	function getLibPara(addr){//读取识别库参数
		showMask();
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url:'../debugtool/getLibPara.action',
			data:{'data.shortmac':addr},
			success:function(data){
				hideMask();
				if(data.flag){
					$("#paraMinPlate").val(data.nminPlateWidth);
					$("#paraMaxPlate").val(data.nmaxPlateWidth);
					$("#paraMaxWidth").val(data.nmaxImageWidth);
					$("#paraMaxHeight").val(data.nmaxImageHeight);
					setComboboxValue("isNight",data.bisNight);
					setComboboxValue("isLeanCorrect",data.bleanCorrection);
					setComboboxValue("isVertCompress",data.bvertCompress);
					setComboboxValue("isFieldImage",data.bisFieldImage);
					
					$("#paraNV").val(data.nimageFormat);
					setComboboxValue("orderOpt",data.norderOpt);
					
					setComboboxValue("movingOutputOpt",data.bmovingOutputOpt);
					setComboboxValue("improveSpeed",data.nimproveSpeed);
					
					setComboboxValue("isDetectCar",data.isDetectCar);
					setComboboxValue("isEvaColor",data.bevaCarColor);
					
					setComboboxValue("isVertFlip",data.bVertFlip);
					setComboboxValue("isDwordAligned",data.bDwordAligned);
					
					$("#paraPro").val(data.provinces);
					$("#paraRevStr").val(data.reservedStr);
					
					$("#paraLocShr").val(data.plateLocateShre);
					$("#paraIdeShr").val(data.plateIdentShre);
					
					setComboboxValue("indiviPlate",data.indiviPlate);
					setComboboxValue("doubleYelPlate",data.doubleYelPlate);
					
					setComboboxValue("armPolicePlate",data.armPolicePlate);
					setComboboxValue("doubleMilPlate",data.doubleMilPlate);
					
					setComboboxValue("farmPlate",data.farmPlate);
					setComboboxValue("emPlate",data.emPlate);
					
					setComboboxValue("dbArmPoliPlate",data.dbArmPoliPlate);
					setComboboxValue("isOptSimpleFrame",data.boutputSingleFrame);//读取是否视频图像中同一个车的多幅图像只输出一次结果
					
					setComboboxValue("isMovingImage",data.bmovingImage);
					
					setComboboxValue("recognitionLibType",data.recognitionLibType);//识别库类型
					
				}else{
					alert(data.message);
				}
			},
			error:function(e){
				hideMask();
			}
		});
	}
	function setLibPara(addr){//设置识别库参数
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url:'../debugtool/setLibPara.action',
			data:{
				'data.shortmac':addr,
				'data.minPlateWidth':$("#paraMinPlate").val(),
				'data.maxPlateWidth':$("#paraMaxPlate").val(),
				'data.maxImageWidth':$("#paraMaxWidth").val(),
				'data.maxImageHeight':$("#paraMaxHeight").val(),
				
				'data.isVertCompress':getComboboxValue("isVertCompress"),//是否垂直方向压缩1倍后识别，默认0
				'data.isFieldImage':getComboboxValue("isFieldImage"),//是否是场图像 ，默认0
				'data.isOptSimpleFrame':getComboboxValue("isOptSimpleFrame"),//是否视频图像中同一个车的多幅图像只输出一次结果，默认0
				'data.isMovingImage':getComboboxValue("isMovingImage"),//识别运动or静止图像，默认0
				'data.isNight':getComboboxValue("isNight"),//是否夜间模式，默认0
				
				'data.imageFormat':$("#paraNV").val(),//NV21，默认6
				
				'data.optOrder':getComboboxValue("orderOpt"),//输出顺序选项 0-置信度 1-自上而下 2-自下而上，默认0
				'data.isLeanCorrect':getComboboxValue("isLeanCorrect"),//是否启用倾斜校正功能，默认0
				'data.movingOutputOpt':getComboboxValue("movingOutputOpt"),//0-内部推送+外部获取 1:外部获取，默认0
				'data.identifyMode':getComboboxValue("improveSpeed"),//识别模式，0: 识别率优先 1:识别速度优先，默认0
				'data.isEvaColor':getComboboxValue("isEvaColor"),//是否识别车辆颜色，默认0
				'data.isVertFlip':getComboboxValue("isVertFlip"),//是否位图，默认0
				'data.isDwordAligned':getComboboxValue("isDwordAligned"),//是否位图，默认0
				
				'data.provinces':$("#paraPro").val(),//省份字符串，默认无
				'data.reservedStr':$("#paraRevStr").val(),//保留字符串
				'data.plateLocateShre':$("#paraLocShr").val(),//车牌定位阈值，默认5
				'data.plateIdentShre':$("#paraIdeShr").val(),//车牌识别阈值，默认1
				
				'data.indiviPlate':getComboboxValue("indiviPlate"),//个性化车牌，默认0
				'data.doubleYelPlate':getComboboxValue("doubleYelPlate"),//双层黄色车牌
				'data.armPolicePlate':getComboboxValue("armPolicePlate"),//武警车牌，默认1
				'data.doubleMilPlate':getComboboxValue("doubleMilPlate"),//双层军车
				'data.farmPlate':getComboboxValue("farmPlate"),//农用车
				'data.emPlate':getComboboxValue("emPlate"),//使领馆车
				'data.dbArmPoliPlate':getComboboxValue("dbArmPoliPlate"),//双层武警车
				'data.isDetectCar':getComboboxValue("isDetectCar"),//是否检测车辆
				
				'data.recognitionLibType':getComboboxValue("recognitionLibType")//是否检测车辆
			},
			success:function(data){
				alert(data.message);
			},
			error:function(e){
				
			}
		});
	}
	function setComboboxValue(id,value){
		$("#"+id).combobox('setValue',value);
	}
	function getComboboxValue(id){
		return $("#"+id).combobox('getValue');
	}
	
	/**
	 * OTA远程升级
	 */
	function otaUpdate(addr){
		showMask();
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url:'../debugtool/otaUpdate.action',
			data:{
				'data.shortmac':addr
			},
			success:function(data){
				hideMask();
				alert(data.message);
//				$cameraota.datagrid('loadData',data);
			},
			error:function(e){
				hideMask();
			}
		});
	}
	
	/**
	 * 读取版本号
	 */
	function readVersion(addr){
		showMask();
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url:'../debugtool/readVersion.action',
			data:{
				'data.shortmac':addr
			},
			success:function(data){
				hideMask();
				alert(data.message);
//				$cameraota.datagrid('loadData',data);
			},
			error:function(e){
				hideMask();
			}
		});
	}
	//读取“识别库参数”按钮操作
	$("#lp_read").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			getLibPara(addr);
		}
	});
	//设置“识别库参数”按钮操作
	$("#lp_set").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			setLibPara(addr);
		}
	});
	//OTA远程升级
	$("#ota_update").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			otaUpdate(addr);
		}
	});
	//读取版本号
	$("#readVersion").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			readVersion(addr);
		}
	});
	/** OTA升级的table */
	$cameraota = $("#cameraota");
	$cameraota.datagrid({
		fit: true,
		border: false,
		columns: [[
		          {field:'ip',title:'摄像头IP',width:80},
		          {field:'message',title:'返回数据',width:80}
		]]
	});
	
	var ev = [{value:'-4',text:'-4'},{value:'-3',text:'-3'},{value:'-2',text:'-2'},{value:'-1',text:'-1'},{value:'0',text:'0'},{value:'1',text:'1'},{value:'2',text:'2'},{value:'3',text:'3'},{value:'4',text:'4'}];
	var pm = [{value:'auto',text:'auto(自动)'},{value:'daylight',text:'daylight(日光)'},{value:'cloudy-daylight',text:'cloudy-daylight(阴天)'},
	          {value:'fluorescent',text:'fluorescent(日光灯)'},{value:'incandescent',text:'incandescent(白炽光)'},{value:'tungsten',text:'tungsten(荧光)'}];
	$camerapara = $("#camerapara");
	$camerapara.datagrid({
		fit:true,
		border:false,
		singleSelect:true,
		toolbar:'#ctb',
		columns:[[
		          {field:'cameraId',title:'摄像头ID',width:60},
		          {field:'exposureValue',title:'曝光度',width:60,editor:{
		        	  type:'combobox',
		        		 options:{
		        			 valueField:'value',
		        			 textField:'text',
		        			 data:ev,
		        			 editable:false,
		        			 panelHeight:'auto'}
		          			}},
		          {field:'photoMode',title:'拍照模式',width:150,editor:{
		        		 type:'combobox',
		        		 options:{
		        			 valueField:'value',
		        			 textField:'text',
		        			 data:pm,
		        			 editable:false,
		        			 panelHeight:'auto'}
		        	 		}},
		          ]],
		onClickRow:onClickRow
	});
	//“摄像头参数”读取按钮
	$("#cmp_read").on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			readCameraPara(addr);
		}
	});
	//“摄像头参数”设置按钮
	$("#cmp_set").on("click",function(){
		if(endEditing($camerapara)){
			var row = $camerapara.datagrid('getSelected');
			if(row == null){
				alert("请先选中一行");
				return;
			}else{
				if(!isSelectOneDtc()){
					return;
				}
				var addr = getAddr();
				var cameraId = row.cameraId;
				var exposureValue = row.exposureValue;
				var photoMode = row.photoMode;
				$.ajax({
					async:true,
					type:'post',
					dataType:'json',
					url:'../debugtool/setCameraPara.action',
					data:{'data.shortmac':addr,
						  'camera.cameraId':cameraId,
						  'camera.exposureValue':exposureValue,
						  'camera.photoMode':photoMode
						},
					success:function(data){
						alert(data.message);
					},
					error:function(e){
						
					}
				});
			}
		}		
	});
	
	function readCameraPara(addr){
		showMask();
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url:'../debugtool/readCameraPara.action',
			data:{'data.shortmac':addr},
			success:function(data){
				$camerapara.datagrid('loadData',data.arr);
				hideMask();
			},
			error:function(e){
				hideMask();
			}
		});
	}
	var pstype = [{value:'0',text:'临时'},{value:'1',text:'预定'},{value:'2',text:'固定'}];
	var eb = [{value:'1',text:'启用'},{value:'0',text:'禁用'}];
	var ps = [{value:'0',text:'无车'},{value:'1',text:'有车'},{value:'2',text:'摄像头故障'}];
	$carpara = $("#carpara");
	$carpara.datagrid({
		//title:'摄像头及车位参数',
		fit:true,
		border:false,
		singleSelect:true,
		toolbar:'#tb',
		columns:[[
			         {field:'ck',checkbox:true},
			         {field:'cameraId',title:'摄像头ID',width:60},
			         {field:'carCode',title:'车位编号',width:60},
			         {field:'parkingSpaceType',title:'车位类型',width:80,
			        	 editor:{
			        		 type:'combobox',
			        		 options:{
			        			 valueField:'value',
			        			 textField:'text',
			        			 data:pstype,
			        			 editable:false,
			        			 panelHeight:'auto'}
			        	 		},
				         formatter:function(v,d,i){
				        		for(var i=0; i<pstype.length; i++){
				        			if(pstype[i].value == v){
				        				return pstype[i].text;
				        			}
				        		}
				        		return v;
				        	}
			        	 },
			         {field:'enable',title:'车位使能',width:60,
			        	editor:{
			        		 type:'combobox',
			        		 options:{
			        			 valueField:'value',
			        			 textField:'text',
			        			 data:eb,
			        			 editable:false,
			        			 panelHeight:'auto'}
			        	},
			        	formatter:function(v,d,i){
			        		for(var i=0; i<eb.length; i++){
			        			if(eb[i].value == v){
			        				return eb[i].text;
			        			}
			        		}
			        		return v;
			        	}
			        	},
			         {field:'parkingSpaceStatus',title:'车位状态',width:80,
			        		formatter:function(v,d,i){
			        			for(var i=0; i<ps.length; i++){
			        				if(ps[i].value == v){
			        					return ps[i].text;
			        				}
			        			}
			        			return v;
			        		}
			        	}
			          ]],
			 onClickRow:onClickRow
	});
	var editIndex = undefined;
	function endEditing(obj){
		if (editIndex == undefined){return true}
		if (obj.datagrid('validateRow', editIndex)){
			obj.datagrid('endEdit', editIndex);
			editIndex = undefined;
			return true;
		} else {
			return false;
		}
	}
	function onClickRow(index,d){
		if (editIndex != index){
			if (endEditing($(this))){
				$(this).datagrid('selectRow', index)
						.datagrid('beginEdit', index);
				editIndex = index;
			} else {
				$(this).datagrid('selectRow', editIndex);
			}
		}
	}
	
	//取消摄像头及车位参数编辑
	$("#reject").on("click",function(){
		$carpara.datagrid('rejectChanges');
		editIndex = undefined;
	});
	
	$cmr_read = $("#cmr_read"); //车位参数读取按钮
	$cmr_read.on("click", function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			readAllCarPara(addr);
		}
	});
	function showMask(){
		$('.paratabs').easyMask('show',{msg:'读取数据中......'});
	}
	function hideMask(){
		$('.paratabs').easyMask('hide',{});
	}
	function readAllCarPara(addr){
		showMask();
		$.ajax({
			async:true,
			url:'../debugtool/readAllCarPara.action',
			type:'post',
			dataType:'json',
			data:{'data.shortmac':addr},
			success: function(data){
				if(data.flag){
					$carpara.datagrid('loadData',data.arr);
				}else{
					alert(data.message);
				}
				hideMask();
			},
			error: function(){
				hideMask();
			}
		});
	}
	$("#cartype_accept, #carenbale_accept").on("click",function(){
		if(endEditing($carpara)){
			var row = $carpara.datagrid('getSelected');
			if(row == null){
				alert("请先选中一行");
		}else{
			if(!isSelectOneDtc()){
				return;
			}
			var addr = getAddr();
			var carCode = row.carCode;//车位编号
			var id = $(this).attr("id");
			if(id == "cartype_accept"){
				var parkingSpaceType = row.parkingSpaceType;
				$.ajax({
					async:true,
					type:'post',
					dataType:'json',
					url:'../debugtool/setCarType.action',
					data:{
						'data.shortmac':addr,
						'carData.carCode':carCode,
						'carData.parkingSpaceType':parkingSpaceType
					},
					success:function(data){
						alert(data.message);
					},
					error:function(){
						
					}
				});
			}else if(id == "carenbale_accept"){
				var enable = row.enable;
				$.ajax({
					async:true,
					type:'post',
					dataType:'json',
					url:'../debugtool/setCarEnable.action',
					data:{
						'data.shortmac':addr,
						'carData.carCode':carCode,
						'carData.parkingSpaceStatus':enable
					},
					success:function(data){
						alert(data.message);
					},
					error:function(){
						
					}
				});
			}
			}
		}
	});
	
	$bpr_btn = $("#bpr_btn");//基本参数读取按钮
	$bpr_btn.on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			
		}
	});
	
	$ap_read = $("#ap_read");//首选AP读取按钮
	$ap_read.on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			readPreferAP(addr);
		}
	});
	$ap_set = $("#ap_set");//首选AP设置按钮
	$ap_set.on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			var apName = $("#paraAP").val();
			var enType = $("#paraEncryptType").combobox('getValue');
			var srKey = $("#paraSecretKey").val();
			$.ajax({
				async:true,
				url: '../debugtool/setPreferAP.action',
				type: 'post',
				dataType: 'json',
				data: {
					'data.shortmac': addr,
					'data.preferAP': apName,
					'data.encryptType': enType,
					'data.secretKey': srKey
				},
				success: function(data){
					alert(data.message);
				},
				error: function(e){
					
				}
			});
		}
	});
	
	function readPreferAP(addr){
		showMask();
		$.ajax({
			async:true,
			url:'../debugtool/readPreferAP.action',
			type:'post',
			dataType:'json',
			data:{'data.shortmac':addr},
			success: function(data){
				if(data.flag){
					$("#paraAP").val(data.apName);
					$("#paraEncryptType").combobox('setValue',data.encryptType);
					$("#paraSecretKey").val(data.secretKey);
				}else{
					alert(data.message);
				}
				hideMask();
			},
			error: function(){
				hideMask();
			}
		});
	}
	
	$map_cb.combobox({
		url:'../debugtool/getmaplist.action?mapId='+$("#map_id").val(),
		valueField:'id',
		textField:'name',
		panelHeight:'auto',
		onLoadSuccess:onLoadSuccess,
		onSelect:onSelect
	});
	function onLoadSuccess(){
		
	}
	function onSelect(r){
		location='../debugtool/debugtool_index.action?mapId='+r.id;
	}
	
	//判断是否选中车位
	function isSelectOneDtc(){
		if(lastSelectDetector == null){
			alert("请先选择车位");
			return false;
		}else{
			return true;
		}
	}
	
	function getAddr(){
		return lastSelectDetector.substring(0,lastSelectDetector.indexOf("_"));
	}
	
	//显示所有车位状态“按钮”
	$s_all.on("click",function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = getAddr();
			$.ajax({
				async:true,
				url:'../debugtool/getallcarstatus.action',
				type:'post',
				dataType:'json',
				data:{'data.shortmac':addr},
				success:function(data){
					$("#carimg_div").html("");
					if(!data.flag){
						alert(data.message);
					}else{
						//显示取得的车位状态
						for(var i = 0; i < data.carlist.length; i++){
							if(data.carlist[i].picPath){
								$("#detectorAddr").html(addr);
								var $img = $("<img alt='pic' style='width:100%;height:100%'/>");
								$img.attr("src", "/pgs/inversion/picCreate.jsp?ppath=" + data.carlist[i].picPath);
								$("#carimg_div").append($img);
							}
						}
					}
				},
				error:function(e){
					
				}
			});
		}
	});
	var flagShow = true;					//车位显示
	$("#showHide_addr").click(function() {
		var obj = getRegionMap("regionMap");
		if (obj) {
			if (flagShow) {
				$(this).linkbutton({
					text : "隐藏车位地址"
				});
				callFuncOnePara(obj, "ShowDetectorAddr", "1");
				flagShow = false;
			} else {
				$(this).linkbutton({
					text : "显示车位地址"
				});
				callFuncOnePara(obj, "ShowDetectorAddr", "2");
				flagShow = true;
			}
		}
	});
	
	//显示所有车位状态及绘图区域的列表框
	$a_all.click(function(){
		if(!isSelectOneDtc()){
			return;
		}else{
			var addr = lastSelectDetector.substring(0, lastSelectDetector.indexOf("_"));		//MAC地址后四位
			var carCode = lastSelectDetector.substring(lastSelectDetector.indexOf("_") + 1, lastSelectDetector.length);	//摄像头编号
			$.ajax({
				async:true,
				url:'../debugtool/getSingleCar.action',
				type:'post',
				dataType:'json',
				data:{'data.shortmac':addr, 'data.carCode': carCode},
				success:function(data){
					$("#detectorAddr").html("");
					$("#carimg_div").html("");
					if(!data.flag){
						alert(data.message);
					}else{
						$("#myIframe").attr("src", "readSetCarCycle.jsp");
						$("#myWindow").window("open");
						//显示取得的车位状态
						for(var i = 0; i < data.list.length; i++){
							var cycle = data.list[i].list[0];				//List列表
							var _picPath = cycle.picPath;					//图片路径
							if(_picPath){
								$("#cameraAddr").html(addr);
								$("#detectorAddr").html(carCode);
								var $img = $("<img alt='pic' style='width:100%;height:100%'/>");
								$img.attr("src", "/pgs/inversion/picCreate.jsp?ppath=" + _picPath);
								$("#carimg_div").append($img);
								$("#leftTopX").val(cycle.topLeftCornerX);
								$("#leftTopY").val(cycle.topLeftCornerY);
								$("#rightBottomX").val(cycle.bottomRightCornerX);
								$("#rightBottomY").val(cycle.bottomRightCornerY);
								$("#picWidth").val(cycle.picWidth);
								$("#picHeight").val(cycle.picHeight);
							} else{
								alert("无法获取该车位图片.");
							}
						}
					}
				},
				error:function(e){
					
				}
			});
		}
	});
	
	//批量升级
	$multiUpdate.click(function(){
		var $p_dialog = $('#p_dialog');			//弹出窗
		var addr = $("#cameraAddr").html();
		var html = "<div style='text-align:center;padding-top:20px'><p><img alt='pro' src='../images/processbar.gif'/></p></div>";
		$p_dialog.dialog({
			title:'升级中...',
			width:350,
			height:300,
			modal:true,
			closable:true,
			draggable:false
		}).html(html).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
		
		sendOTACmd(addr);
	});
});

//发送OTA升级命令
function sendOTACmd(addr){
	var $p_dialog = $('#p_dialog');			//弹出窗
	$.ajax({
		async:true,
		url:'../debugtool/multiOTAUpdate.action',
		type:'post',
		dataType:'json',
		data:{'data.shortmac':addr},
		success:function(data){
			$p_dialog.dialog({
				width: 300,
				height: 200,
				resizable: true
			}).html(data.message);
		},
		error:function(e){
			
		}
	});
}

$(function(){
	var $cs = $("#cs");//搜索按钮
	var sS = null;	//查询结果选中的车位
	var mapSatus = $("#map_status").val();//地图状态字符串
	var lstn = lstv = null;	//上次查询类型及条件
	$cs.searchbox({
		width:200,
		prompt: '请输入',
		menu: "#mm",
		searcher: searchHandler
	});
	function searchHandler(value, name){
		var obj = getRegionMap("regionMap");
		if(lstn !== name || lstv !== value){
			if(sS){
				clearSelected(obj);
			}
		}
		lstn = name;
		lstv = value;
		$.ajax({
			async: false,
			type: 'post',
			url: '../debugtool/searchParkingSpace.action',
			dataType: 'json',
			data: {
				'data.code_id':value,
				'data.code_name':name,
				'data.id':$("#map_cb").combobox("getValue")
			},
			success: function(data){
				if(data.flag){
					var rarr = data.rstr.split(';');
					sS = rarr[0];
					searchResult(rarr[0]);
					var parr = rarr[1].split(',');
					var px = Math.ceil(parr[0]), py = Math.ceil(parr[1]);
					var xLen = 60,
						zoomPara = 20,
						yLen = 60;
					var rect = {
						'left':(px - xLen)*zoomPara,
						'top': (py - yLen)*zoomPara,
						'right': (px + xLen)*zoomPara,
						'bottom': (py + yLen)*zoomPara
					}
					zoomRect(obj, rect);
				}
			},
			error: function(){
				
			}
		});
	};
	function searchResult(str, mark){
		if(str.length > 0){
			var arr = str.split(",");
			if(mark){
				for(var i=0, len=arr.length; i<len; i++){
					showMark(arr[i], mark);
				}
			}else{
				for(var i=0, len=arr.length; i<len; i++){
					var m = arr[i].substring(arr[i].indexOf("_"));
					showMark(arr[i], m);
				}
			}
		}
	};
	function clearSelected(obj){//取消选中
		if(sS){
			searchResult(sS, "&#x0020;");
			obj.Zoom(0);
		}
	};
	(function(){//加载地图时更新地图状态
		var mapObj = getRegionMap("regionMap");
		var interval = setInterval(function(){
			if(checkFlashComplete(mapObj, interval)){
//				callFuncOnePara(mapObj,"NToGotoFrame",mapSatus);
				getFlashEqNo();
			}
		},500);
	})();
	
});
/**
 * 设置单个探测器的值到界面上
 * @param dcode
 */
function setDetectorValues(dcode){
	$("#multiOptios").hide();
	
	$.ajax({
		async:false,
		url:'../debugtool/getParkingSpaceNO.action',
		type:'post',
		dataType:'json',
		data:{'data.code_name':dcode},
		success:function(data){
			$("#pakringSpaceNo").html(data.code);
		},
		error:function(e){
			
		}
	});

	$("#detectorAddr").append(dcode);
	$("#cameraAddr").append(dcode);
	$("#singleOptions").show();
}
/**
 * 设置多个探测器的值到界面上
 * @param dcode
 */
function setMultiDetectorValues(dcode){
	$("#singleOptions").hide();
	var cameras = dcode.split(",");
	var arr = new Array();
	$.each(cameras, function(key, value){
		var _nextLine = (key + 1) % 3 == 0 ? "\n" : "";
		$("#detectorAddr").append(value + ";" + _nextLine);
		var camera = value.substring(0,value.indexOf("_"));
		arr.push(camera);
	});
	$.each(arr.uniqueString(), function(key, value){
		var _nextLine = (key + 1) % 3 == 0 ? "\n" : "";
		$("#cameraAddr").append(value + ";" + _nextLine);
	});
	
	$("#multiOptios").show();
}

/**
 * 清除探测器的值到界面上
 */
function clearDetectorValues(){
	$("#cameraAddr").html("");
	$("#detectorAddr").html("");
	$("#pakringSpaceNo").html("");
}

/**
 * 点击探测器或条屏触发操作
 * @param command
 * @param args
 */
var lastSelectDetector = null;
function regionMap_DoFSCommand(command, args) 
{ 
	clearDetectorValues();
	var obj = getRegionMap("regionMap");
	if (command == "sensor") { // 传感器(探测器)
		updateBays(obj, args, 2);// 选中车位跳到第3帧，紫红色
		lastSelectDetector = args;
		setDetectorValues(args);
	} else if (command == "MultiSelect") { // 传感器(探测器)
		updateBays(obj, args, 2);// 选中车位跳到第3帧，紫红色
		lastSelectDetector = args;
		setMultiDetectorValues(args);
	} else if (command == "screen") {
		getFlashEqNo();
	} else if (command == "Clear") {// “清空”，每次选中元件都是先触发此操作，flash中写的是“Clear”
		getFlashEqNo();
	}
}
/**
 * 车位跳到同一帧
 */
function getFlashEqNo()
{
	var obj = getRegionMap("regionMap");
	callFuncOnePara(obj,"AllToOneFrame",10);
}
/**
 * 清除Flash地图上的
 */
function ClearFlashEqNo()
{
	var obj = getRegionMap("regionMap");//获取Object
	bays = obj.CallFunction("<invoke name=\"GetCarList\" returntype=\"xml\"><arguments></arguments></invoke>");
	
	if(bays.length >0)
	{		
		bays = bays.replace("<string>","").replace("</string>","");				
		var baysArr = bays.split(",");
		for(var i=0;i<baysArr.length;i++)
		{
			updateBays(obj,baysArr[i], 9);				 
		}
	}
}

//缩放
function Zoom(percent){
	getRegionMap("regionMap").Zoom(percent);
}

function showMark(code,mark){
	getRegionMap("regionMap").CallFunction("<invoke name=\"SetGroupNo\" returntype=\"xml\">" +
			"<arguments><string>"+ code +"</string><string>"+ mark +"</string></arguments></invoke>");
}
