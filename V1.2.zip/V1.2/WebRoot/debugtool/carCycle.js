/**
 * 绘制识别区域
 */
var pixel = 2;
$(function(){
	init();
	var _clientTopX, _clientTopY, _clientBottomX, _clientBottomY;				
	//添加在图片上画区域的方法===============================
	$("#drawDiv").mousedown(function(even){				
		$(this).html("");
		_clientTopX = even.clientX;
		_clientTopY = even.clientY;
		rect(_clientTopX, _clientTopY, _clientTopX - _clientTopX, _clientTopY - _clientTopY, $("#drawDiv"));
		$(this).bind("mousemove", (function(even){
			$(this).html("");
			_clientBottomX = even.clientX;
			_clientBottomY = even.clientY;
			rect(_clientTopX, _clientTopY, _clientBottomX - _clientTopX, _clientBottomY - _clientTopY, $("#drawDiv"));
			//setZuoB(_clientTopX * 2, _clientTopY * 2, _clientBottomX * 2, _clientBottomY * 2);
			setZuoB(_clientTopX * pixel, _clientTopY * pixel, _clientBottomX * pixel, _clientBottomY * pixel);
		}));
	}).mouseup(function(){
		$(this).unbind("mousemove");
	});
});

//=========================================FIREFOX下==============================
function makedot(x,y, obj){ // 画点函数
	obj.append("<div z-index='99' style='height:5px;position:absolute;left:"+x+"px;top:"+y+"px;width:5px;background:#f00;overflow:hidden'></div>");
}

/**
 * 函数功能：根据指点矩形左上角坐标及长宽绘制矩形。 函数思路：根据左上坐标及长宽，计算横纵向边每点的坐标
 */
function rect(x,y,w,h, obj){ // (x,y)左上角坐标,w,h 宽与高
	for(var i=0;i<w;i++){
	  makedot(x+i,y, obj);
	  makedot(x+i,y+h, obj);
	}
	for(var i=0;i<h;i++){
	  makedot(x,y+i, obj);
	  makedot(x+w,y+i, obj);
	}
}

/**
 * 设置坐标
 * @param _clientTopX
 * @param _clientTopY
 * @param _clientBottomX
 * @param _clientBottomY
 */
function setZuoB(_clientTopX, _clientTopY, _clientBottomX, _clientBottomY){
	$("#leftX").html(Math.ceil(_clientTopX));
	$("#leftY").html(Math.ceil(_clientTopY));
	$("#rightX").html(Math.ceil(_clientBottomX));
	$("#rightY").html(Math.ceil(_clientBottomY));
}

/**
 * 初始化页面
 */
function init(){
	var pw = parent.$("#picWidth").val();//图片宽度
	var ph = parent.$("#picHeight").val();//图片高度
	var leftTopX = parent.$("#leftTopX").val();
	var leftTopY = parent.$("#leftTopY").val();
	var rightBottomX = parent.$("#rightBottomX").val();
	var rightBottomY = parent.$("#rightBottomY").val();
	$("#drawImage").attr("src", parent.$("#carimg_div > img").attr("src"));		//将图片显示在DIV上
	$("#macAddr").text(parent.$("#cameraAddr").text());		//探测器MAC地址
	$("#detectorCode").text(parent.$("#detectorAddr").text());		//探测器MAC地址
	$("#picWidth").html(pw + "px");
	$("#picHeight").html(ph + "px");
	pixel = pw / 640;
	setZuoB(leftTopX, leftTopY, rightBottomX, rightBottomY);
	rect(leftTopX / pixel,  leftTopY / pixel, (rightBottomX - leftTopX) / pixel, (rightBottomY - leftTopY) / pixel, $("#drawDiv"));
	
}
//=========================================FIREFOX下==============================

//==================================设置按钮点击事件================================

function operate(oper){
	if(oper === 'cycleSetup'){
		$.ajax({
			async:true,
			type:'post',
			dataType:'json',
			url: '../debugtool/setCarCycle.action',
			data: {'data.shortmac':$("#macAddr").text(), 'carData.carCode' : $("#detectorCode").text(),
				'carData.topLeftCornerX': $("#leftX").html(), 'carData.topLeftCornerY': $("#leftY").html(),
				'carData.bottomRightCornerX': $("#rightX").html(), 'carData.bottomRightCornerY': $("#rightY").html()},
			success: function(data){
				if(!data.flag){
					alert(data.message);
				}else if(data.status === '55'){
					alert("设置成功");
				}
			},
			error: function(data){
				
			}
		});
	}
}

//==================================设置按钮点击事件================================





























