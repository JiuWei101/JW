//浏览器每1min对web服务器发送一次心跳
$(function(){
	var inter = window.setInterval(function(){
		sendHeart();
	}, 10000);
	

});
function sendHeart(){
	$.ajax({
		async : false,
		type : "POST",
		dataType : "json",
		url:"../inversion/reciveHeart.action",
		data: {}
	});
}