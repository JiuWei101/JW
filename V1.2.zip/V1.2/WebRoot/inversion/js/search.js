var searchMachine = "", backTime = 60, refreshTimer = 0; //默认为60秒跳转到首页
$(function(){
	var zoomRect = "";
	$(this).mousedown(function(){
		refreshTimer = 0;
	});
	$.getJSON(
			"inversion/queryBackTime.action",
			function(data){
				backTime = (data.backTime == '' || data.backTime == undefined) ? 60 : data.backTime;
				backToIndex(backTime);
		}
	);
	
	//初始化全局ajax事件
	$("#centerdv").ajaxStart(function(){
		$(this).spin("large");
	}).ajaxComplete(function(){
		$(this).spin(false);
	}).ajaxError(function(){
		//alert(GlobalMesObj[LocalLanguage].alert.ajaxerror);
	});
	$("#backtoindexbtn").on("click",function(){
		//返回首页按键事件
		location.href = GlobalPath + "inversion/index.html";
	});
	//选项卡切换事件
	$("#pageTab div.tablink").on("click",function(){
		//refreshTimer = 0;
		var $activeLi = $("#pageTab li.active"),
			$this = $(this),
			$pli = $this.parent(),
			$backbtn = $("#backbtn").removeClass("disabled");
		while(!$backbtn.is(":hidden")){
			$backbtn.trigger("click");
		}
		if($activeLi == $pli) return;
		$("#tabContent>div.active").removeClass("active");
		$activeLi.removeClass("active");
		$pli.addClass("active");
		var href = $this.attr("data-href");
		if(href === "#nocarnumsearch"){
			//获取无车牌信息
			getNoCarInfo();
		}else{
			$(href).addClass("active");
		}
		//------切换选项卡时把输入框内容都清空------------------------
		$(".easyinput").each(function(){			
			var target = "#" + $(this).attr("id"),
				$target = $(target);
			if($target.hasClass("empty")) return;
			$target.addClass("empty").text(emptyTxtObj[target]);
		});
		//------切换选项卡时把输入框内容都清空------------------------
		return false;
	});
	//获取无车牌信息
	function getNoCarInfo(){
		$("#prebtn,#nextbtn,#pageInfo").show();
		//显示车信息区域
		beforeOpenWin("#cardialogarea");
		$("#cardialogarea").cargrid({
    		url : "/pgs/inversion/carSearch.action",
    		pgOpts : {
    			pageIndex : 1,
    			pageSize : gridPageSize
    		},
    		param : {carNum : '无牌车' , type : 5, pageIndex : 1,	pageSize : gridPageSize}
		});
		$("#backbtn").addClass("disabled");
	}
	var openedDialog = [];
	//TODO 顶部返回键点击事件
	$("#backbtn").on("click",function(){
		if($(this).hasClass("disabled")) return;
		//refreshTimer = 0;
		if(openedDialog.length > 0){
			var target = openedDialog.pop();
			$(target).hide();
			if(target === "#cardialogarea"){
				//关闭的是车信息窗口
				$("#prebtn,#nextbtn,#pageInfo").hide();
			}
			//关闭完后打开前一个窗口
			if(openedDialog.length > 0){
				var preOpen = openedDialog[openedDialog.length - 1];
				$(preOpen).show();
				if(preOpen === "#cardialogarea"){
					$("#prebtn,#nextbtn,#pageInfo").show();
					if($("#tab5li").hasClass("active")){
						//如果点击了左部无车牌按钮
						$("#backbtn").addClass("disabled");
					}
				}
			}else{
				$("#tabContent").show();
				$(this).hide();
			}
		}
	});
	// TODO 在打开窗口前
	function beforeOpenWin(wId){
		if(openedDialog.length > 0){
			var preOpen = openedDialog[openedDialog.length - 1];
			$(preOpen).hide();
			if(preOpen === "#cardialogarea"){
				$("#prebtn,#nextbtn,#pageInfo").hide();
				if($("#tab5li").hasClass("active")){
					//如果点击了左部无车牌按钮
					$("#backbtn").removeClass("disabled");
				}
			}
		}else{
			$("#tabContent").hide();
			$("#backbtn").show();
		}
		$(wId).show();
		openedDialog.push(wId);
	}
	//AKE LOGO点击事件
	$("#akelogo").on("click",function(){
		//refreshTimer = 0;
		beforeOpenWin("#akedialogarea");
		$("#backbtn").show();
	});
	//输入域没内容时，默认显示的信息对象
	var emptyTxtObj = {};
	//为各个区域下的按键绑定事件
	$("#easysearch,#fuzzysearch,#timesearch,#carportsearch").each(function(){
		var	$this = $(this),
			target = $this.attr("data-target"),
			$target = $(target);
		$this.find("a.key").on("click",function(){
			//refreshTimer = 0;
			var val = $target.text();
			if($target.hasClass("empty")){
				if(!emptyTxtObj[target]) emptyTxtObj[target] = val;
				val = "";
				$target.text("").removeClass("empty");
			}
			if(target == "#timesearch-input"){
				var text = formatTem(Number($(this).text())),
					printString = text + ':00' + '-' + text + ':59';
				$target.text(printString).attr("data-value",$(this).text());
			}else{
				if(val.length >= 5) return;//最长5位
				$target.text(val + $(this).text());
			}
		});
	    function formatTem(num){
	    	if(num < 10){
	    		return '0'+num;
	    	}
	    	return num;
	    }
	});
	//退格事件
	$("#easysearch-backbtn,#fuzzysearch-backbtn,#carportsearch-backbtn").on("click",function(){
		//refreshTimer = 0;
		var target = getTarget($(this).attr("id")),
			$target = $(target);
		if($target.hasClass("empty")) return;
		var text = $target.text();
		$target.text(text.substr(0,text.length-1));
		if(text.length == 1){
			$target.addClass("empty").text(emptyTxtObj[target]);
		}
	});
	//清除事件
	$("#easysearch-resetbtn,#fuzzysearch-resetbtn,#carportsearch-resetbtn,#timesearch-resetbtn").on("click",function(){
		//refreshTimer = 0;
		var target = getTarget($(this).attr("id")),
			$target = $(target);
		if($target.hasClass("empty")) return;
		$target.addClass("empty").text(emptyTxtObj[target]);
	});
	//查询按钮事件
	var gridPageSize = 6;
	$("#easysearch-searchtbn,#fuzzysearch-searchtbn,#timesearch-searchtbn,#carportsearch-searchbtn").on("click",function(){
		//refreshTimer = 0;
		var	$this = $(this),
			idStr = $this.attr("id"),
			target = getTarget(idStr),
			$target = $(target);
		if($target.hasClass("empty")) return;
		var text = $target.text();
		if(idStr == "fuzzysearch-searchtbn" && text.length < 5){
			var $popover = $this.popover('show').parent().find(">div.popover");
			$popover.find(">h3.popover-title").remove();
			$popover.find(">div.arrow").remove();
			window.setTimeout(function(){
				if($this.parent().find(">div.popover").length == 0) return;
				$this.popover('hide');
			}, 2000);
			return;
		}
		//显示上一页下一页
		$("#prebtn,#nextbtn,#pageInfo").show();
		//显示车信息区域
		beforeOpenWin("#cardialogarea");
		var $car = $("#cardialogarea"),param;
		if(target == "#easysearch-input"){
			//简易寻车
			param = {carNum : $target.text() , type : 2};
		}else if(target == "#fuzzysearch-input"){
			//全车牌查询
			param = {carNum : "%" + $target.text() + "%" , type : 5};
		}else if(target == "#timesearch-input"){
			//时间查询
			param = {sDate : $target.attr("data-value"), type : 3};
		}else if(target == "#carportsearch-input"){
			//车位查询
			param = {carNum : $target.text() , type : 4};
		}
		$.extend(param,{
			pageIndex : 1,
			pageSize : gridPageSize
		});
		$car.cargrid({
    		url : "/pgs/inversion/carSearch.action",
    		pgOpts : {
    			pageIndex : 1,
    			pageSize : gridPageSize
    		},
    		param : param
		});
	});
	//全车牌查询按键提示信息，当输入车牌不足5位时提醒
	$("#fuzzysearch-searchtbn").popover({
		animation : false,
		content : GlobalMesObj[LocalLanguage].alert.format,
		trigger : "manual"
	});
	function getTarget(id){
		var arr = id.split("-");
		arr[0] = "#" + arr[0];
		arr[1] = "input";
		return arr.join("-");
	}
	//最大化图片区域查询路线函数
	$("#maxpicroutebtn").on("click",function(){
		//refreshTimer = 0;
		doExactSearch($(this).attr("data-psid"), $(this).attr("data-target"));
	});
    (function($){
    	$.fn.extend({
    	    /**
    	     * 获取模糊查询数据 jquery 插件
    	     */
    		cargrid : function(options){
    			var $this = this;
    			if(typeof options == "object"){
    				$this.data(options);
    				if(!$this.data("isInit")){
        				$("#prebtn").on("click",function(){
        					//上一页按键事件
        					if($(this).hasClass("disabled")) return;
        					var index = $this.data("pgOpts").pageIndex;
        					if(index == 1) return;
        					index--;
        					changeParam($this,{pageIndex : index, searchMachine: searchMachine});
        					getData($this);
        				});
        				$("#nextbtn").on("click",function(){
        					//下一页按键事件
        					if($(this).hasClass("disabled")) return;
        					var pgOpts = $this.data("pgOpts"),
        						index = pgOpts.pageIndex;
        					if(index == pgOpts.pageNum) return;
        					index++;
        					changeParam($this,{pageIndex : index, searchMachine: searchMachine});
        					getData($this);
        				});
        				$this.data("isInit",true);
    				}
    			}
    			getData($this);
    			return $this;
    		}
    	});
    	function changeParam($this,paramObj){
    		$.extend($this.data("param"),paramObj);
    		$.extend($this.data("pgOpts"),paramObj);
    	}
    	var localCarInfo = GlobalMesObj[LocalLanguage].carInfo,
    		carTpl = ["<div class='item'>",
    	              	"<div class='carimgdv'><img alt='car' src='$img' /></div>",
    	              	"<div class='carinfodv'>",
    	              		"<p class='carinfop local1'><span class='carinfotext'>",localCarInfo.carNum,"</span><span class='carinfosplite'>:</span><span>$carNum</span></p>",
    	              		"<p class='carinfop local1'><span class='carinfotext'>",localCarInfo.carPos,"</span><span class='carinfosplite'>:</span><span>$position</span></p>",
    	              		"<p class='carinfop local1'><span class='carinfotext'>",localCarInfo.parkTime,"</span><span class='carinfosplite'>:</span><span>$parktime</span></p>",
    	              		"<div class='carinfobtn' data-target='$carNum' data-psid='$psid'><p>",localCarInfo.findroute,"</p></div>",
    	              	"</div>",
    	              "</div>"].join("");
    	function getData($target){
    		var thisData = $target.empty().data(),
    			thisParam = thisData.param,
    			thisPgOpts = thisData.pgOpts,
    			thisUrl = thisData.url;
//    		var $this = $target.empty().data().param;
			$.ajax({
				url : thisUrl,
				data : thisParam,	
				cache : false,
				type : 'POST',
				dataType : "json",
				beforeSend :function(xmlHttp){
					xmlHttp.setRequestHeader("If-Modified-Since","0");
					xmlHttp.setRequestHeader("Cache-Control","no-cache");
				},
				success : function(data){
					searchMachine = data.searchMachine;
					thisPgOpts.pageNum = parseInt(data.total / thisPgOpts.pageSize);
			    	var lastPageSize = data.total % thisPgOpts.pageSize;
			    	if(lastPageSize != 0) thisPgOpts.pageNum++;
			    	if(thisPgOpts.pageNum <= 1){
			    		$("#prebtn,#nextbtn").addClass("disabled");
			    		$("#pageInfo").hide();
			    	}else{
			    		var isEnableArr;
			    		if(thisPgOpts.pageIndex <= 1){
			    			isEnableArr = [false,true];
			    		}else if(thisPgOpts.pageIndex == thisPgOpts.pageNum){
			    			isEnableArr = [true,false];
			    		}else if(thisPgOpts.pageIndex > 1 && thisPgOpts.pageIndex < thisPgOpts.pageNum){
			    			isEnableArr = [true,true];
			    		}
			    		var pageInfo = localCarInfo.pageInfo
			    			.replace("${pageIndex}", thisPgOpts.pageIndex)
			    			.replace("${pageNum}", thisPgOpts.pageNum);
			    		$("#pageInfo").text(pageInfo);
			    		$("#prebtn,#nextbtn").each(function(i){
			    			$(this)[isEnableArr[i] ? "removeClass" : "addClass"]("disabled");
			    		});
			    	}
			    	if(data.total == 0 || !data.rows){
			    		var $dv;
			    		if($("#timesearch").hasClass("active")){
			    			$dv = $(["<div class='nomesarea'><div class='nomesareacontent'>",
			    		             	"<p style='height:107px'></p>",
			    		             	"<p class='qin' style='margin-left:215px;'>",localCarInfo.dear,":</p>",
			    		             	"<p style='margin-top:40px;margin-left:215px;'>",localCarInfo.nocartime,"</p>",
			    		             "</div></div>"].join(""));
			    		}else if($("#carportsearch").hasClass("active")){
			    			$dv = $(["<div class='nomesarea'><div class='nomesareacontent'>",
			    		             	"<p style='height:107px'></p>",
			    		             	"<p class='qin' style='margin-left:215px;'>",localCarInfo.dear,":</p>",
			    		             	"<p style='margin-top:40px;margin-left:215px;'>",localCarInfo.nocarport,"</p>",
			    		             "</div></div>"].join(""));
			    		}else{			//如果有不能识别车牌的车的信息
			    			$dv = $(["<div class='nomesarea'><div class='nomesareacontent'>",
			    		             	"<p style='height:107px'></p>",
			    		             	"<p class='qin' style='margin-left:215px;'>",localCarInfo.dear,":</p>",
			    		             	"<p style='margin-top:40px;margin-left:215px;'>",localCarInfo.notIdentify,"</p>",
			    		             	"<p style='margin-top:20px;margin-left:215px;'>",
			    		             		"<span class='vam' style='margin-right:25px;'>",localCarInfo.notIdentify1,"</span>",
			    		             		"<span class='carinfobtninline vam'><span>",$("#carportsearch-searchbtn").text(),"</span></span>",
			    		             	"</p>",
			    		             "</div></div>"].join(""));
				    		$dv.find("span.carinfobtninline").on("click",function(){
			    				$("#cardialogarea").cargrid({
			    		    		url : "/pgs/inversion/carSearch.action",
			    		    		/*pgOpts : {
			    		    			pageIndex : 1,
			    		    			pageSize : gridPageSize
			    		    		},*/
			    		    		param : {carNum : '无牌车' , type : 5, pageIndex : 1,	pageSize : gridPageSize}
			    				});
			    			});
				    		if(LocalLanguage === "zh-tw" || LocalLanguage === "en"){
				    			//$dv.find("p.qin").remove();
				    			if(LocalLanguage === "en"){
				    				var $content = $dv.find(">div.nomesareacontent");
				    				$content.find(">p").css({
				    					"margin-left" : "130px"
				    				});
				    				$content.css("font-size","38px")
				    					.find("span.carinfobtninline span").css({
				    						"font-size" : "25px",
				    						"margin-top" : "30px"
				    					});
				    			}
				    		}
			    		}
			    		$("#cardialogarea").append($dv);
	    	    		return;
					} else if(data.total == -1 || !data.rows){		//如果没有不能识别车牌的车的信息
						$dv = $(["<div class='nomesarea'><div class='nomesareacontent'>",
		    		             	"<p style='height:107px'></p>",
		    		             	"<p style='margin-top:40px;margin-left:215px;'>",localCarInfo.notIdentifyInfo,"</p>",
		    		             "</div></div>"].join(""));
			    		$("#cardialogarea").append($dv);
	    	    		return;
					}
			    	var rowData = data.rows,
			    		html = [];
			    	for(var i=0,l=rowData.length;i<l;i++){
			    		var item = rowData[i];
			    		//tanx tag for 反向寻车默认图片
			    		
			    		//item.img = item.img + "&ran=" + (+new Date);
			    		
			    		html.push(carTpl.replace("$img",item.img)
			    						.replace(/\$carNum/g,item.carNum)
			    						.replace("$position",item.position.length > 9 ? "..." + item.position.substr(item.position.length - 9, item.position.length) : item.position)
			    						.replace("$parktime",item.parktime)
			    						.replace("$psid",item.psid));
			    	}
			    	$("#cardialogarea").html(html.join("")).find("div.carinfobtn").on("click",function(){
			    		//refreshTimer = 0;
			    		doExactSearch($(this).attr("data-psid"), $(this).attr("data-target"));
			    	});
			    	//最大化图片
			    	$("#cardialogarea").find("img").on("click",function(){
			    		//refreshTimer = 0;
			    		beforeOpenWin("#maxpicarea");
			    		$("#maxpicimg").attr("src",$(this).attr("src"));
			    		var $btn = $(this).parent().next().find("div.carinfobtn");
			    		$("#maxpicroutebtn").attr("data-psid",$btn.attr("data-psid"))
			    			.attr("data-target",$btn.attr("data-target"));
			    	});
				}
			});
    	}
    })(jQuery);
    function doExactSearch(carIdVal, carNumVal){
    	//TODO ：精确查询信息数据接口
    	$.ajax({
			url : "/pgs/inversion/carSearch.action",
			data : {carId : carIdVal, carNum : carNumVal , type : 1, searchMachine : searchMachine},	
			cache : false,
			type : 'POST',
			dataType : "json",
			beforeSend :function(xmlHttp){
				xmlHttp.setRequestHeader("If-Modified-Since","0");
				xmlHttp.setRequestHeader("Cache-Control","no-cache");
			},
			success : function(data){
				if(!data){
					alert(GlobalMesObj[LocalLanguage].alert.carleft);
					return;
				}
				if(checkMessage(data)){
					return;
				}
				$("#flashroutinfo>div.active").removeClass("active");
				flashArea.data = null;
				beforeOpenWin("#flasharea");
				$('#jdialogswf').empty();
				showMap(data.flash,'100%','100%','mySWF','mySWF');
				var pStr = data.point,
					line = data.line,
					arrow = data.arrow,
					num = data.num,
					rect = data.zoomRect;
				zoomRect = data.zoomRect.split(",");			//要放大区域的点[]
				if(intervalProcess) clearInterval(intervalProcess);
				$("#flashroutinfo").spin("large");
				intervalProcess = setInterval(function(){
					var flag = checkFlashLoaded(intervalProcess);
					if(flag){
						hideElements();
						$("#flashroutinfo").spin(false);
						//汽泡開始================================================================================================
						showBub(data, num);
						//汽泡結束================================================================================================
						num = getMapInfo(num);
						drawShortestLine(pStr,line,arrow,num,data.cratio);	//画路线
						var nextfloor = data.nextfloor,
							$flashroutinfo = $("#flashroutinfo");
						$flashroutinfo.find("span.flashcarnum").text(data.carNum);
						$flashroutinfo.find("span.flashcarpotnum").text(data.position);
						if(nextfloor){
							flashArea.data = data;
							//如果有下一层
							$flashroutinfo.find("span.flashcurpos").text(data.currentFloor);
							$flashroutinfo.find("span.flashtargetpos").text(data.carFloor);
							$flashroutinfo.find(">div.nextfloor").addClass("active");
							//setFlashTitle(data.currentFloor);
						}else{
							$flashroutinfo.find("span.flashcurpos").text(data.carFloor);
							$flashroutinfo.find(">div.curfloor").addClass("active");
							$flashroutinfo.find("span.flashtargetpos").text("");
							//setFlashTitle(data.carFloor);
						}
					};
				}, 1000);
			}
    	});
    }
    /*检查后台返回的message*/
    function checkMessage(data){
    	if(data.errorMsg){
    		switch (data.errorMsg) {
			case 1:		//代表当前查询机尚未登记
				alert(GlobalMesObj[LocalLanguage].alert.ajaxerror);
				break;
			}
    		return true;
    	} else{
    		return false;
    	}
    }
    //设置flash楼层信息
    function setFlashTitle(title){
    	var $title = $("#flashtitle").text(title || "");
    	if(title){
    		var fW = $("#jdialogswf").width() / 2,
    			ftW = $title.width() / 2;
    		$title.css("left",fW - ftW);
    	}
    }
    /**
     * 显示汽泡
     * @param curStep 1,2 0,2代表车所在的层,1代表起点到电梯的层
     */
    function showBub(data, curStep){
    	//汽泡開始================================================================================================
    	var pStr = (curStep == 2 ? data.nextfloor.point : data.point);
    	var rect = (curStep == 2 ? data.nextfloor.zoomRect : data.zoomRect);
    	var	num = (curStep == 2 ? data.nextfloor.num : data.num);
		var bpstr = pStr.substring(pStr.lastIndexOf(";") + 1, pStr.length);
		bpstr = rect + "," + bpstr;
		var carFloor = curStep == 1 ? data.currentFloor : data.carFloor;
		carFloor = carFloor.length > 16 ? "..." + carFloor.substr(carFloor.length - 16, carFloor.length) : carFloor;
		var floor = GlobalMesObj[LocalLanguage].mapInfo.curFloor + "," +  carFloor;
		var carNum = GlobalMesObj[LocalLanguage].carInfo.carNum + "," +  data.carNum;
		//如果只有一层停车位置就不顯示当前层
		var position = GlobalMesObj[LocalLanguage].carInfo.carPos + "," +  (curStep == 0? data.position : (data.carFloor + " " + data.position));
		var step = (curStep == 1 ? GlobalMesObj[LocalLanguage].mapInfo.next : GlobalMesObj[LocalLanguage].mapInfo.pre);
		showBubble(num, bpstr, floor, carNum, position, GlobalMesObj[LocalLanguage].mapInfo.plsMove, step, data.bratio);
		//汽泡結束================================================================================================
    }
	var flashArea = {
		data : null,
		init : function(){
			$("#flashnextbtn").on("click",function(){
				$("#flashroutinfo>div.nextfloor").removeClass("active");
				$("#flashroutinfo>div.prefloor").addClass("active");
				if(flashArea.data){
					flashArea.loadFlashData(flashArea.data.nextfloor);
					//setFlashTitle(flashArea.data.carFloor);
				}
			});
			$("#flashprebtn").on("click",function(){
				$("#flashroutinfo>div.prefloor").removeClass("active");
				$("#flashroutinfo>div.nextfloor").addClass("active");
				if(flashArea.data){
					flashArea.loadFlashData(flashArea.data);
					//setFlashTitle(flashArea.data.currentFloor);
				}
			});
		},
		loadFlashData : function(data){
			$('#jdialogswf').empty();
			showMap(data.flash,'100%','100%','mySWF','mySWF');
			var pStr = data.point,
				line = data.line,
				arrow = data.arrow,
				rect = data.zoomRect,
				num = data.num;
//			zoomRect = data.zoomRect.split(",");			//要放大区域的点[]
//			if(zoomRect.length == 4){
//				var pointsToTwips = 20;
//				getRegionMap('mySWF').SetZoomRect(zoomRect[0] * pointsToTwips, zoomRect[1] * pointsToTwips,
//						zoomRect[2] * pointsToTwips, zoomRect[3] * pointsToTwips);
//			}
			if(intervalProcess) clearInterval(intervalProcess);
			intervalProcess = setInterval(function(){
				var flag = checkFlashLoaded(intervalProcess);
				if(flag){
					hideElements();
					showBub(flashArea.data, num);		//调用显示汽泡方法
					num = getMapInfo(num);
					drawShortestLine(pStr,line,arrow,num,data.cratio);
				};
			}, 1000);
		}
	};
	flashArea.init();
    $("#upPath").on("click",function(){
    	//refreshTimer = 0;
		getRegionMap("mySWF").Pan(0, -200, 0);
    });
    $("#downPath").on("click",function(){
    	//refreshTimer = 0;
		getRegionMap("mySWF").Pan(0, 200, 0);
    });
	$("#leftPath").on("click",function(){
		//refreshTimer = 0;
		getRegionMap("mySWF").Pan(-200, 0, 0);
	});
	$("#rightPath").on("click",function(){
		//refreshTimer = 0;
		getRegionMap("mySWF").Pan(200, 0, 0);
	});
	$("#zoomInPath").on("click",function(){
		//refreshTimer = 0;
    	getRegionMap("mySWF").Zoom(140);
	});
	$("#zoomOutPath").on("click",function(){
		//refreshTimer = 0;
    	getRegionMap("mySWF").Zoom(60);			//放大
//		if (zoomRect.length == 4) {		//直接把地图上的表示“起点”“终点”上的区域放大
//			var pointsToTwips = 20;
//			getRegionMap('mySWF').SetZoomRect(
//					zoomRect[0] * pointsToTwips,
//					zoomRect[1] * pointsToTwips,
//					zoomRect[2] * pointsToTwips,
//					zoomRect[3] * pointsToTwips);
//		}
	});
	$("#zoomPath").on("click",function(){
		//refreshTimer = 0;
		getRegionMap("mySWF").Zoom(1200);
	});
	/*底部广告切换*/
	(function(){
		var $advertdv = $("#advertdv");
		$.ajax({
			url : "inversion/queryAdvertJson.action",
			data : {advertPosition : 1},
			cache : false,
			type : 'POST',
			dataType : "json",
			beforeSend :function(xmlHttp){
				xmlHttp.setRequestHeader("If-Modified-Since","0");
				xmlHttp.setRequestHeader("Cache-Control","no-cache");
				$advertdv.spin("large");
			},
			complete : function(){
				$advertdv.spin(false);
			},
			success : function(data){
		    	var _playTime = 10;
				var i = 0;
				function loadData(){
					if(data && data.arr){
						var arr = data.arr;
						_playTime = arr[i].playTime;
						if (arr[i].type.indexOf("flash") != -1){
							$("#imageDiv").hide(500);
							swfobject.embedSWF(arr[i].data, "flash", "1343", "122", "9.0.0", "expressInstall.swf");
							$("#flashDiv").show(500);
						} else if (arr[i].type.indexOf("image") != -1){
							$("#flashDiv").hide(500);
							$("#image").attr("src", arr[i].data);
							$("#imageDiv").show(500);
						}
						if(++i >= arr.length){
							i = 0;
						}
						setTimeout(loadData, _playTime * 1000);	//每_playTime秒轮转一次图片
					}
				}
				loadData();
			}
    	});
	})();
    function backToIndex(backTimes){
	    window.setInterval(function(){		//自动跳转到主页
	    	++refreshTimer;
	    	if(refreshTimer == backTime){
	    		window.location.href = GlobalPath + "inversion/index.html";
	    	}
	    }, 1000);
    }
    
    var intervalProcess;
    function getRegionMap(mapName){
    	var obj = "";
    	if (navigator.appName.indexOf("Microsoft Internet") == -1) {
    		if (document.embeds && document.embeds[mapName])
    			obj = document.embeds[mapName];
    	}else{
    		obj = document.getElementById(mapName);
    	}
    	return obj;
    }
    function showMap(file,width,height,objId,objName){
    	var html ="<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+ width +"' height='"+ height +"' id='"+objId+"' name='"+objName+"'>";
    	html +="<param name='allowScriptAccess' value='always' />";
    	html +="<param name='movie' value='"+ file +"'>";
    	/*html +="<param name='wmode' value='transparent'>";*/
    	html +="<param name='quality' value='high'>";
    	html +="<embed wmode='transparent' src='"+ file +"' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+ width +"' height='"+ height +"' id='"+objId+"' name='"+objName+"'></embed></object>";
    	$('#jdialogswf').html(html);
    	document.getElementById(objId).movie=encodeURI(file);
    }
    function checkFlashLoaded(intervalProcess){
//		if(a != null && a != undefined){
//			clearInterval(intervalProcess);
//    		return true;
//    	}else{
//    		return false;
//    	}
//    	getRegionMap("mySWF").CallFunction("<invoke name=\"GetLinePointList\" returntype=\"xml\"><arguments></arguments></invoke>");
//		while(getRegionMap("mySWF").PercentLoaded() < 100){
//			//console.log("Loop: " + getRegionMap("mySWF").PercentLoaded() + ", RefreshTimer: " + refreshTimer);
//		}
//		//console.log(getRegionMap("mySWF").PercentLoaded() + ", RefreshTimer: " + refreshTimer);
//		clearInterval(intervalProcess);
//		
//		return true;
    	if(getRegionMap("mySWF").PercentLoaded() == 100){
    		clearInterval(intervalProcess);
    		return true;
    	}else{
    		return false;
    	}
    }
    function drawShortestLine(str,line,arrowlm,num,cratio){
    	getRegionMap("mySWF").CallFunction("<invoke name=\"DrawReverseShortestLine\" returntype=\"xml\"><arguments><string>"+ str +"</string><string>"+ line +"</string><string>"+ arrowlm +"</string><string>"+ num +"</string><string>"+ cratio +"</string></arguments></invoke>");
    }
    function showBubble(num, position,floor,plateno,parkcode,nmess,nstep,bratio){
    	getRegionMap("mySWF").CallFunction("<invoke name=\"showBubble\" returntype=\"xml\"><arguments><string>"+ num +"</string><string>"+ position +"</string><string>"+ floor +"</string><string>"+ plateno +"</string><string>"+ parkcode +"</string><string>"+ nmess +"</string><string>"+ nstep +"</string><string>"+ bratio +"</string></arguments></invoke>");
    }
    function hideElements(){
    	try {
    		getRegionMap("mySWF").CallFunction("<invoke name=\"hideElements\" returntype=\"xml\"><arguments></arguments></invoke>");
		} catch (e) {
			// TODO: handle exception
		}
    }
    /**
     * 获取地图上的语言信息
     */
    function getMapInfo(num){
    	switch (num) {
		case 0:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.start + "," + GlobalMesObj[LocalLanguage].mapInfo.end;
			break;
		case 1:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.start + "," + GlobalMesObj[LocalLanguage].mapInfo.lift;
			break;
		case 2:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.lift + "," + GlobalMesObj[LocalLanguage].mapInfo.end;
			break;
		}
		return num;
    }
});
//不可放置在$();里
//Flash地圖裡的按鈕点击触发的事件
function flashBtnClick(num){
	var id = "#flashprebtn";
	switch (num) {
	case '1':
		id = "#flashnextbtn";
		break;
	}
	$(id).click();
}