//简单语言包
(function(window){
	"use strict";
	var LocalLanguage = "zh-ch",
		LangCode = $("#langCodeInput").val();
	if(LangCode === "87") LocalLanguage = "zh-tw";
	else if(LangCode === "44") LocalLanguage = "en";
	else LocalLanguage = "zh-ch";
	window.LocalLanguage = LocalLanguage;
	window.GlobalMesObj = {
		"zh-ch" : {
			page : {
				carnum : "车牌查询",
				exact : "精确查询",
				time : "时间查询",
				carport : "车位查询",
				no : "无牌车",
				route : "路线"
			},
			dialog : {
				title : "信息"
			},
			alert : {
				format : "请正确输入5位车牌号码！",
				error : "查询失败！请重试！",
				ajaxerror : "本查询机尚未登记,请联系系统管理员!",
				nothing : "抱歉，查询结果为空",
				carleft : "该车已开出,请确认后再重新查询",
				nogroup : "该车位未分组,请联系系统管理员!"
			},
			carInfo : {
				carNum : "车牌号码",
				carPos : "停车位置",
				parkTime : "停车时间",
				findroute : "路线",
				pageInfo : "当前第${pageIndex}页,共${pageNum}页",
				dear : "亲",
				notIdentify : "车辆暂时未能识别",
				notIdentify1 : "请尝试点击",
				nocartime : "抱歉,该时间段没有查询到车",
				nocarport : "抱歉,没有该车位信息",
				notIdentifyInfo: "没有查询到相关的信息!<br />请尝试使用【车位查询】",
				search : "查询"
			},
			mapInfo: {
				start : "起点",
				end : "终点",
				lift : "电梯",
				curFloor : "当前楼层",
				plsMove : "请移步",
				next : "下一步",
				pre : "上一步"
			}
		},
		"zh-tw" : {
			page : {
				carnum : "車牌查詢",
				exact : "精確查詢",
				time : "時間查詢",
				carport : "車位查詢",
				no : "無牌車",
				route : "路線"
			},
			dialog : {
				title : "信息"
			},
			alert : {
				format : "請正確輸入5位車牌號碼！",
				error : "查詢失敗,請重試!",
				ajaxerror : "本查詢機尚未登記,請聯繫系統管理員!",
				nothing : "查詢結果為空，請修改查詢信息",
				carleft : "該車已開出,請確認後再重新查詢",
				nogroup : "該車位未分組,請聯繫系統管理員!"
			},
			carInfo : {
				carNum : "車牌號码",
				carPos : "停車位置",
				parkTime : "停車時間",
				findroute : "路線",
				pageInfo : "當前前${pageIndex}頁,共${pageNum}頁",
				dear : "親",
				notIdentify : "車輛暫時未能識別",
				notIdentify1 : "請嘗試點擊",
				nocartime : "抱歉,該時間段沒有查詢到車",
				nocarport : "抱歉,沒有該車位信息",
				notIdentifyInfo: "沒有查詢到相關的信息!<br />請嘗試使用【車位查詢】",
				search : "查询"
			},
			mapInfo: {
				start : "起點",
				end : "終点",
				lift : "電梯",
				curFloor : "當前樓層",
				plsMove : "請移步",
				next : "下一步",
				pre : "上一步"
			}
		},
		"en" : {
			page : {
				carnum : "License Plate Search",
				exact : "Exact Search",
				time : "Parking Time Search",
				carport : "Parking Search",
				no : "Unlicensed Vehicles",
				route : "Route"
			},
			dialog : {
				title : "-Information"
			},
			alert : {
				format : "Please input correct 5 license plate number！",
				error : "Failure, pls try again.",
				ajaxerror : "This machine is not registered, please contact the system administrator!",
				nothing : "No result. Pls change the query info!",
				carleft : "The car has been driven away, pls confirm again after the query!",
				nogroup : "This is parkingspace is not grouping, please contact the system administrator!"
			},
			carInfo : {
				carNum : "Plate NO.",
				carPos : "Car location",
				parkTime : "Time",
				findroute : "Route",
				pageInfo : "current page:${pageIndex},total pages:${pageNum}",
				dear : "Dear",
				notIdentify : "The car you search is not identified",
				notIdentify1 : "please try to click",
				nocartime : "The time period of no inquiry into the car",
				nocarport : "None of the parking information",
				notIdentifyInfo: "Couldn't find any info.<br />&nbsp;&nbsp;&nbsp;&nbsp;Please try to use<br />[Parking Space Search]",
				search : "search"
			},
			mapInfo: {
				start : "Start",
				end : "End",
				lift : "Lift",
				curFloor : "Current Floor",
				plsMove : "Pls Move",
				next : "Next",
				pre : "Prev"
			}
		}
	};
		/**
	 * 多語言初始化
	 */
	(function(){
		var arr = ["carnum","exact","time","carport","no"];
		var page = GlobalMesObj[LocalLanguage].page;
		$("#tabbtn>a.btn").each(function(i){
			$(this).text(page[arr[i]]);
		});
		$("#picRouteBtn").text(page.route);
	})();
})(window);