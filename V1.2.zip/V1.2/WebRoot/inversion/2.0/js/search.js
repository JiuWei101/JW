(function(window){
	"use strict";
	//打印函数
//	window.LOG = function(){
//		if(typeof console != 'undefined'){
//			console.log.apply(console,arguments);
//		}
//	};
	//全局命名空间
	var Search = window.Search = (function(){
		var stack = [],
			alertInter;
		return {
			//获取当前搜索方式的信息
			getCurSearchInfo : function(){
				var $active = $("#center>div.center-active");
				return {
					curAreaId : $active.attr("id"),
					$span : $($active.attr("data-target"))
				};
			},
			/**
			 * 显示相应区域：键盘 查询信息 图片放大 AKE简介 
			 */
			showItem : function(idStr){
				$("#page>div.active").removeClass("active");
				var isPush = true;
				for(var i=0,ii=stack.length;i<ii;i++){
					if(stack[i] === idStr){
						isPush = false;
						stack.splice(i + 1);
						break;
					}
				}
				$(idStr).addClass("active");
				if(isPush){
					stack.push(idStr);
				}
				$("#backbtn").show();
			},
			hideItem : function(){
				var len = stack.length;
				if(len === 0) return;
				if(len === 1){
					$("#backbtn").hide();
				}
				var popItem = stack.pop();
				$(popItem).removeClass("active");
				len = stack.length;
				if(len === 0){
					$("#centerarea").addClass("active");
				}else{
					$(stack[len - 1]).addClass("active");
				}
			},
			clearItem : function(){
				$("#page>div.active").removeClass("active");
				$("#centerarea").addClass("active");
				$("#backbtn").hide();
				stack = [];
			},
			noNumSearch : function(){
				$("#grid").cargrid({
		    		url : "/pgs/inversion/carSearch.action",
		    		pgOpts : {
		    			pageIndex : 1
		    		},
		    		param : {carNum : '无牌车' , type : 5, pageIndex : 1}
				});
			},
			alert : function(mes){
				//80 + 10 + 5
				var $tip = $("#tip").html(mes);
				if(!$tip.is(":hidden")){
					clearTimeout(alertInter);
					$tip.stop().hide();
				}
				$tip.css("top","-95px").show().animate({top : "5px"},300);
				alertInter = setTimeout(function(){
					$tip.hide(300);
				},2000);
			}
		};
	})();
	$(function(){
		/**
		 * 查询方式界面切换效果
		 */
		(function(){
			var WIDTH = 1680;
			function getIndex($p,el){
				var index = -1;
				$p.children().each(function(i){
					if(el === this){
						index = i;
						return false;
					}
				});
				return index;
			}
			$("#tabbtn>a.mr1").click(function(){
				//先判断目标按钮和目标区域是否已处于激活状态
				//若是则什么也不做，否则滑动到相应区域
				if($("#centerarea").is(":hidden")){
					Search.clearItem();
				}
				var $this = $(this);
				if($this.hasClass("btn1-selected")) return;
				var $pbtn = $("#tabbtn"),
					index = getIndex($pbtn,this),
					$center = $("#center"),
					$target = $center.children("div:eq("+index+")");
				if($target.hasClass("center-active")) return;
				$pbtn.children("a.btn1-selected").removeClass("btn1-selected");
				$center.children("div.center-active").removeClass("center-active")
					.end().animate({left : (-WIDTH * index) + "px"},300);
				$target.addClass("center-active");
				$this.addClass("btn1-selected");
			});
			//wu pai che
			$("#nonumsearch").click(function(){
				Search.showItem("#grid");
				Search.noNumSearch();
			});
		})();
		/**
		 * 各种按键逻辑
		 */
		(function(){
			function setEmptySpan($span){
				$span.data("isEmpty",true).text($span.data("emptyMes"));
			}
			//初始化输入框
			$("#carPlateSearch-input,#exactSearch-input,#timeSearch-input,#carPosSearch-input").each(function(){
				$(this).data('isEmpty',true).data("emptyMes",$(this).text());
			});
			//键盘按键
			$("#carPlateSearch,#exactSearch,#carPosSearch").each(function(){
				var id = "#" + this.id + "-input";
				$(this).find("div.center-keyborad a.btn:not(.btn5)").click(function(){
					var $span = $(id),
						txt = $(this).text();
					if($span.data("isEmpty")){
						$span.text(txt).data("isEmpty",false);
					}else{
						var stxt = $span.text();
						if(stxt.length === 5){
							return false;
						}
						$span.text(stxt + txt);
					}
					return false;
				});
			});
			//时间查询键盘按键
			$("#timeSearch div.center-keyborad a.btn").click(function(){
				var num = Number($(this).text());
				if(num < 10){
					num = "0" + num;
				}
				$("#timeSearch-input").text(num + ":" + "00-" + num + ":59").data("value",num).data("isEmpty",false);
			});
			//退格
			$("#center").find("a.key-back").click(function(){
				var $span = Search.getCurSearchInfo().$span;
				if($span.data("isEmpty")) return false;
				var txt = $span.text(),
					len = txt.length;
				if(len === 1){
					setEmptySpan($span);
				}else{
					$span.text(txt.substring(0,len - 1));
				}
				return false;
			})
			//清空
			.end().find("a.key-clear").click(function(){
				setEmptySpan(Search.getCurSearchInfo().$span);
			});
			//后退事件
			$("#backbtn,#backbtn-win").click(function(){
				Search.hideItem();
			});
		})();
		/**
		 * 底部广告切换
		 */
		(function(){
			var $advertdv = $("#advert");
			$.ajax({
				url : "../queryAdvertJson.action",
				data : {advertPosition : 1},
				cache : false,
				type : 'POST',
				dataType : "json",
				beforeSend :function(xmlHttp){
					xmlHttp.setRequestHeader("If-Modified-Since","0");
					xmlHttp.setRequestHeader("Cache-Control","no-cache");
					$advertdv.spin('large');
				},
				complete : function(){
					$advertdv.spin(false);
				},
				success : function(data){
			    	var _playTime = 10;
					var i = 0;
					function loadData(){
						if(data && data.arr){
							var arr = data.arr,
								item = arr[i],
								type = item.type,
								$advertImg = $("#advertImg"),
								$advertFlash = $("#advertFlash");
							_playTime = item.playTime;
							if (type.indexOf("flash") !== -1){
								$advertImg.hide(500);
								swfobject.embedSWF(item.data, "flash", "100%", "100%", "9.0.0", "expressInstall.swf");
								$advertFlash.show(500);
							} else if (type.indexOf("image") !== -1){
								$advertFlash.hide(500);
								var $img = $advertImg.children("img");
								if($img.length === 0){
									$img = $("<img src='" + item.data + "' alt='advert' class='wh100'/>").appendTo($advertImg);
								}else{
									$img.attr("src", item.data);
								}
								$advertImg.show(500);
							}
							var len = arr.length;
							if(len > 1){
								if(++i >= arr.length){
									i = 0;
								}
								setTimeout(loadData, _playTime * 1000);	//每_playTime秒轮转一次图片
							}
						}
					}
					loadData();
				}
	    	});
		})();
		(function(){
			var count = 0;
			$(document).on("click",function(){
				count = 0;
			}).on("mousemove",function(){
				count = 0;
		    });
			window.setInterval(function(){
//				LOG(count);
				if(++count === 30){
					window.location.href = PATH + "/inversion/2.0/index.html";
				}
			},1000);
		})();
	});
})(window);