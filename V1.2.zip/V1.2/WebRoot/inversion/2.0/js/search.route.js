$(function(){
	"use strict";
	//判断flash是否加载完计时器
	var intervalProcess,
		mapData;
    function showMap(file){
    	var width = $("#routeFlash").width();
    	var height = $("#routeFlash").height();
    	var html = "<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' " +
    			"codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+ 
    	width +"' height='"+ height +"' id='mySWF' name='mySWF'>";
    	html +="<param name='allowScriptAccess' value='always' />";
    	html +="<param name='movie' value='"+ file +"'>";
    	html +="<param name='wmode' value='transparent'>";
    	html +="<param name='quality' value='high'>";
    	html +="<embed wmode='transparent' src='"+ file +"' quality='high' " +
    			"pluginspage='http://www.macromedia.com/go/getflashplayer' " +
    			"type='application/x-shockwave-flash' width='"+ width +"' " +
    					"height='"+ height +"' id='mySWF' name='mySWF'></embed>" +
    	"</object>";
    	document.getElementById("routeFlash").innerHTML = html;
//    	document.getElementById(objId).movie = encodeURI(file);
    }
    function checkFlashLoaded(intervalProcess){
		if(getRegionMap("mySWF").PercentLoaded() == 100){
    		clearInterval(intervalProcess);
    		return true;
    	}else{
    		return false;
    	}
    }
    function hideElements(){
    	try {
    		getRegionMap("mySWF").CallFunction("<invoke name=\"hideElements\" returntype=\"xml\"><arguments></arguments></invoke>");
		} catch (e) {
			// TODO: handle exception
		}
    }
    /**
     * 显示汽泡
     * @param curStep 1,2 0,2代表车所在的层,1代表起点到电梯的层
     */
    function showBub(data, curStep){
    	//汽泡開始================================================================================================
    	var pStr = (curStep == 2 ? data.nextfloor.point : data.point);
    	var rect = (curStep == 2 ? data.nextfloor.zoomRect : data.zoomRect);
    	var	num = (curStep == 2 ? data.nextfloor.num : data.num);
		var bpstr = pStr.substring(pStr.lastIndexOf(";") + 1, pStr.length);
		bpstr = rect + "," + bpstr;
		var floor = GlobalMesObj[LocalLanguage].mapInfo.curFloor + "," +  (curStep == 1 ? data.currentFloor : data.carFloor);
		var carNum = GlobalMesObj[LocalLanguage].carInfo.carNum + "," +  data.carNum;
		//如果只有一层停车位置就不顯示当前层
		var position = GlobalMesObj[LocalLanguage].carInfo.carPos + "," +  (curStep == 0? data.position : (data.carFloor + " " + data.position));
		var step = (curStep == 1 ? GlobalMesObj[LocalLanguage].mapInfo.next : GlobalMesObj[LocalLanguage].mapInfo.pre);
		showBubble(num, bpstr, floor, carNum, position, GlobalMesObj[LocalLanguage].mapInfo.plsMove, step, data.bratio);
		//汽泡結束================================================================================================
    }
    function showBubble(num, position,floor,plateno,parkcode,nmess,nstep,bratio){
    	getRegionMap("mySWF").CallFunction("<invoke name=\"showBubble\" returntype=\"xml\"><arguments><string>"+ num +"</string><string>"+ position +"</string><string>"+ floor +"</string><string>"+ plateno +"</string><string>"+ parkcode +"</string><string>"+ nmess +"</string><string>"+ nstep +"</string><string>"+ bratio +"</string></arguments></invoke>");
    }
    function getRegionMap(mapName){
    	var obj = "";
    	if (navigator.appName.indexOf("Microsoft Internet") == -1) {
    		if (document.embeds && document.embeds[mapName]){
    			obj = document.embeds[mapName];
    		}
    	}else{
    		obj = document.getElementById(mapName);
    	}
    	return obj;
    }
    function drawShortestLine(str,line,arrowlm,num,cratio){
    	getRegionMap("mySWF").CallFunction("<invoke name=\"DrawReverseShortestLine\" returntype=\"xml\"><arguments><string>"+ str +"</string><string>"+ line +"</string><string>"+ arrowlm +"</string><string>"+ num +"</string><string>"+ cratio +"</string></arguments></invoke>");
    }
    /**
     * 获取地图上的语言信息
     */
    function getMapInfo(num){
    	switch (num) {
		case 0:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.start + "," + GlobalMesObj[LocalLanguage].mapInfo.end;
			break;
		case 1:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.start + "," + GlobalMesObj[LocalLanguage].mapInfo.lift;
			break;
		case 2:
			num += "," + GlobalMesObj[LocalLanguage].mapInfo.lift + "," + GlobalMesObj[LocalLanguage].mapInfo.end;
			break;
		}
		return num;
    }
	function loadFlashData(data){
		showMap(data.flash);
		var pStr = data.point,
			line = data.line,
			arrow = data.arrow,
			rect = data.zoomRect,
			num = data.num;
//		zoomRect = data.zoomRect.split(",");			//要放大区域的点[]
//		if(zoomRect.length == 4){
//			var pointsToTwips = 20;
//			getRegionMap('mySWF').SetZoomRect(zoomRect[0] * pointsToTwips, zoomRect[1] * pointsToTwips,
//					zoomRect[2] * pointsToTwips, zoomRect[3] * pointsToTwips);
//		}
		if(intervalProcess !== undefined) clearInterval(intervalProcess);
		intervalProcess = setInterval(function(){
			var flag = checkFlashLoaded(intervalProcess);
			if(flag){
				hideElements();
				showBub(mapData, num);		//调用显示汽泡方法
				num = getMapInfo(num);
				drawShortestLine(pStr,line,arrow,num,data.cratio);
			};
		}, 500);
	}
	function showRouteWin(carIdVal,carNumVal){
		//查询路线
		$.ajax({
			url : "/pgs/inversion/carSearch.action",
			data : {carId : carIdVal, carNum : carNumVal , type : 1},	
			cache : false,
			type : 'POST',
			dataType : "json",
			beforeSend :function(xmlHttp){
				xmlHttp.setRequestHeader("If-Modified-Since","0");
				xmlHttp.setRequestHeader("Cache-Control","no-cache");
			},
			complete : function(){
				$("#prevbtn,#nextbtn").show();
			},
			success : function(data){
				if(!data){
					alert(GlobalMesObj[LocalLanguage].alert.carleft);
					return;
				}
				if(data.errorMsg === 1){
					//代表当前查询机尚未登记
					alert(GlobalMesObj[LocalLanguage].alert.ajaxerror);
					return;
				}else if(data.errorMsg === 2){//代表车位未分组
					alert(GlobalMesObj[LocalLanguage].alert.nogroup);
					return;
				}
				$("#routeDetail>div.active").removeClass("active");
				mapData = null;
				Search.showItem("#route");
				$('#routeFlash').empty();
				data.flash = "../." + data.flash;
				showMap(data.flash);
				var pStr = data.point,
					line = data.line,
					arrow = data.arrow,
					num = data.num,
					rect = data.zoomRect;
//				zoomRect = data.zoomRect.split(",");			//要放大区域的点[]
				if(intervalProcess !== undefined) clearInterval(intervalProcess);
				var $detail = $("#routeDetail").spin('large');
				intervalProcess = setInterval(function(){
					var flag = checkFlashLoaded(intervalProcess);
					if(flag){
						hideElements();
						$detail.spin(false);
						//汽泡開始================================================================================================
						showBub(data, num);
						//汽泡結束================================================================================================
						num = getMapInfo(num);
						drawShortestLine(pStr,line,arrow,num,data.cratio);	//画路线
						var nextfloor = data.nextfloor;
						$detail.find("span.flashcarnum").text(data.carNum);
						$detail.find("span.flashcarpotnum").text(data.position);
						if(nextfloor){
							nextfloor.flash = PATH + "/" + nextfloor.flash;
							mapData = data;
							//如果有下一层
							$detail.find("span.flashcurpos").text(data.currentFloor);
							$detail.find("span.flashtargetpos").text(data.carFloor);
							$detail.find(">div.nextfloor").addClass("active");
							//setFlashTitle(data.currentFloor);
						}else{
							$detail.find("span.flashcurpos").text(data.carFloor);
							$detail.find(">div.curfloor").addClass("active");
							$detail.find("span.flashtargetpos").text('');
							//setFlashTitle(data.carFloor);
						}
					};
				}, 500);
			}
    	});
	}
	$("#flashnextbtn").on("click",function(){
		$("#routeDetail>div.nextfloor").removeClass("active");
		$("#routeDetail>div.prefloor").addClass("active");
		if(mapData){
			loadFlashData(mapData.nextfloor);
			//setFlashTitle(flashArea.data.carFloor);
		}
	});
	$("#flashprebtn").on("click",function(){
		$("#routeDetail>div.prefloor").removeClass("active");
		$("#routeDetail>div.nextfloor").addClass("active");
		if(mapData){
			loadFlashData(mapData);
			//setFlashTitle(flashArea.data.currentFloor);
		}
	});
	$("#gridresult").on("click","a.btn9",function(){
		showRouteWin($(this).attr("data-psid"),$(this).attr("data-target"));
	});
	$("#picRouteBtn").click(function(){
		showRouteWin($(this).attr("data-psid"),$(this).attr("data-target"));
	});
	 $("#upPath").on("click",function(){
		getRegionMap("mySWF").Pan(0, -200, 0);
    });
    $("#downPath").on("click",function(){
		getRegionMap("mySWF").Pan(0, 200, 0);
    });
	$("#leftPath").on("click",function(){
		getRegionMap("mySWF").Pan(-200, 0, 0);
	});
	$("#rightPath").on("click",function(){
		getRegionMap("mySWF").Pan(200, 0, 0);
	});
	$("#zoomInPath").on("click",function(){
		getRegionMap("mySWF").Zoom(60);
	});
	$("#zoomOutPath").on("click",function(){
		getRegionMap("mySWF").Zoom(140);
	});
	$("#zoomPath").on("click",function(){
		getRegionMap("mySWF").Zoom(1200);
	});
	//Flash地圖裡的按鈕点击触发的事件
	function flashBtnClick(num){
		var id = "#flashprebtn";
		switch (num) {
			case '1':
			id = "#flashnextbtn";
			break;
		}
		try{
			$(id).click();
		}catch(ex){
			$.error(ex);
			LOG(ex);
		}
	}
	window.flashBtnClick = flashBtnClick;
	window.showRouteWin = showRouteWin;
});