$(function(){
	"use strict";
	//上一页 下一页 按键效果
	$("#prevbtn,#nextbtn").mousedown(function(){
		$(this).addClass(this.id + "-active");
	}).mouseup(function(){
		$(this).removeClass(this.id + "-active");
	}).mouseout(function(){
		$(this).removeClass(this.id + "-active");
	});
	//查询事件函数
	$("#center a.key-search").click(function(){
		var $span = Search.getCurSearchInfo().$span;
		if($span.data("isEmpty")) return;
		var txt = $span.text();
		var type = $(this).attr("data-type");
		if(type === "5"){
			if(txt.length < 5){
				Search.alert(GlobalMesObj[LocalLanguage].alert.format);
				return;
			}
		}
		var	param;
		if(type === '2'){
			//简易寻车
			param = {carNum : txt , type : 2};
		}else if(type === "5"){
			//全车牌查询
			param = {carNum : "%" + txt + "%" , type : 5};
		}else if(type === "3"){
			//时间查询
			param = {sDate : $span.data("value"), type : 3};
		}else if(type === "4"){
			//车位查询
			/*
			var rflag = false;
			$.ajax({
				async: false,
				type: 'post',
				dataType: 'json',
				url: '/pgs/inversion/exactNumberSearch.action',
				data: {
					'dcode' : txt
				},
				success: function(data){
					if(data){
						showRouteWin(data.carId, data.carNum);
						rflag = true;
					}
				}
			});
			if(rflag){
				return;
			}else{
				param = {carNum : txt , type : 4};
			}
			*/
			param = {carNum : txt , type : 4};
		}
		Search.showItem("#grid");
		$.extend(param,{
			pageIndex : 1
		});
		$("#grid").cargrid({
    		url : "/pgs/inversion/carSearch.action",
    		pgOpts : {
    			pageIndex : 1
    		},
    		param : param
		});
	});
	(function($){
		var GRID_PAGESIZE = 6,
			localCarInfo = GlobalMesObj[LocalLanguage].carInfo,
			carTpl = ["<span class='grid-item$cls'>",
		              	"<img alt='car' src='$img'/>",
		              	"<span class='grid-carinfo'>",
		              		"<span>",localCarInfo.carNum,"</span><span class='mlr1'>:</span><span>$carNum</span><br />",
		              		"<span>",localCarInfo.carPos,"</span><span class='mlr1'>:</span><span>$position</span><br />",
		              		"<span>",localCarInfo.parkTime,"</span><span class='mlr1'>:</span><span>$parktime</span>",
		              	"</span>",
		              	"<a class='btn9 btn mt2 mr4' href='javascript:void(0)' data-target='$carNum' data-psid='$psid'>",localCarInfo.findroute,"</a>",
		              "</span>"].join("");
		/**
	     * 获取模糊查询数据 jquery 插件
	     */
		$.fn.cargrid = function(options){
			var $this = this;
			if(typeof options == "object"){
				$this.data(options);
				if(!$this.data("isInit")){
					$("#gridresult").on("click","img",function(){
			    		//最大化图片
			    		Search.showItem("#pic");
						var $con = $("#pic>div.pic-con");
			    		var $img = $con.find("img");
			    		if($img.length === 0){
			    			$img = $("<img alt='car' src='" + this.src + "'/>").appendTo($con);
			    		}else{
			    			$img.attr("src",this.src);
			    		}
			    		var $a = $(this).parent().children("a.btn9");
			    		$("#picRouteBtn").attr({
			    			"data-target" : $a.attr("data-target"),
			    			"data-psid" : $a.attr("data-psid")
			    		});
			    	})
    				$("#prevbtn").on("click",function(){
    					//上一页按键事件
    					if($(this).hasClass("disabled")) return;
    					var index = $this.data("pgOpts").pageIndex;
    					if(index == 1) return;
    					index--;
    					changeParam($this,{pageIndex : index});
    					getData($this);
    				});
    				$("#nextbtn").on("click",function(){
    					//下一页按键事件
    					if($(this).hasClass("disabled")) return;
    					var pgOpts = $this.data("pgOpts"),
    						index = pgOpts.pageIndex;
    					if(index == pgOpts.pageNum) return;
    					index++;
    					changeParam($this,{pageIndex : index});
    					getData($this);
    				});
    				$this.data("isInit",true);
				}
			}
			getData($this);
			return $this;
		};
    	function changeParam($this,paramObj){
    		$.extend($this.data("param"),paramObj);
    		$.extend($this.data("pgOpts"),paramObj);
    	}
    	function toggleArea(method1,method2){
    		$("#gridresult,#prevbtndv,#nextbtndv")[method1]();
    		$("#gridnomes")[method2]();
    	}
    	function getData($target){
    		$("#gridresult").empty();
    		var thisData = $target.data(),
    			thisParam = thisData.param,
    			thisPgOpts = thisData.pgOpts,
    			thisUrl = thisData.url;
    		if(!thisParam.pageSize){
    			thisParam.pageSize = GRID_PAGESIZE;
    		}
			$.ajax({
				url : thisUrl,
				data : thisParam,	
				cache : false,
				type : 'POST',
				dataType : "json",
				beforeSend :function(xmlHttp){
					xmlHttp.setRequestHeader("If-Modified-Since","0");
					xmlHttp.setRequestHeader("Cache-Control","no-cache");
					$("#prevbtn,#nextbtn").hide();
					$("#grid").spin('large');
				},
				complete : function(){
					$("#prevbtn,#nextbtn").show();
					$("#grid").spin(false);
				},
				success : function(data){
					if(!thisPgOpts.pageSize){
						thisPgOpts.pageSize = GRID_PAGESIZE;
					}
					thisPgOpts.pageNum = parseInt(data.total / thisPgOpts.pageSize);
			    	var lastPageSize = data.total % thisPgOpts.pageSize;
			    	if(lastPageSize != 0) thisPgOpts.pageNum++;
			    	if(thisPgOpts.pageNum <= 1){
			    		$("#prevbtn,#nextbtn").addClass("disabled");
//			    		$("#pageinfo").hide();
			    	}else{
			    		var isEnableArr;
			    		if(thisPgOpts.pageIndex <= 1){
			    			isEnableArr = [false,true];
			    		}else if(thisPgOpts.pageIndex == thisPgOpts.pageNum){
			    			isEnableArr = [true,false];
			    		}else if(thisPgOpts.pageIndex > 1 && thisPgOpts.pageIndex < thisPgOpts.pageNum){
			    			isEnableArr = [true,true];
			    		}
//			    		var pageInfo = localCarInfo.pageInfo
//			    			.replace("${pageIndex}", thisPgOpts.pageIndex)
//			    			.replace("${pageNum}", thisPgOpts.pageNum);
//			    		$("#pageinfo").text(pageInfo);
			    		$("#prevbtn,#nextbtn").each(function(i){
			    			$(this)[isEnableArr[i] ? "removeClass" : "addClass"]("disabled");
			    		});
			    	}
			    	if(data.total == 0 || !data.rows){
			    		var html,
			    			isInitClick = false,
			    			curId = Search.getCurSearchInfo().curAreaId;
			    		if(curId === "timeSearch"){
			    			html = localCarInfo.dear + "," + localCarInfo.nocartime;
			    		}else if(curId === "carPosSearch"){
			    			html = localCarInfo.dear + "," + localCarInfo.nocarport;
			    		}else{
			    			//如果有不能识别车牌的车的信息
			    			html = localCarInfo.dear + "," + localCarInfo.notIdentify + "<br />" + localCarInfo.notIdentify1 
			    				+ "<a class='btn btn3 nomes-search' href='javascript:void(0)'>" + localCarInfo.search + "</a>";
			    			isInitClick = true;
			    		}
			    		var $p = $("#gridnomes>p").html(html);
			    		if(isInitClick){
			    			$p.find("a.nomes-search").on("click",function(){
			    				Search.noNumSearch();
			    			});
			    		}
			    		toggleArea("hide","show");
	    	    		return;
					} else if(data.total == -1 || !data.rows){
						//如果没有不能识别车牌的车的信息
			    		$("#gridnomes>p").html(localCarInfo.notIdentifyInfo);
			    		toggleArea("hide","show");
	    	    		return;
					}
			    	toggleArea("show","hide");
			    	var rowData = data.rows,
			    		html = [];
			    	for(var i=0,l=rowData.length;i<l;i++){
			    		var item = rowData[i];
			    		var mid = carTpl.replace("$img",item.img)
									.replace(/\$carNum/g,item.carNum)
									.replace("$position",item.position)
									.replace("$parktime",item.parktime)
									.replace("$psid",item.psid);
			    		
			    		if(i !== l - 1){
			    			mid = mid.replace("$cls","");
			    		}else{
			    			mid = mid.replace("$cls","");
			    		}
			    		html.push(mid);
			    	}
			    	$("#gridresult").html(html.join(""));
				}
			});
    	}
    })($);
});