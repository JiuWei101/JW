$(function(){
	//查询按钮点击事件
	$("#searchBtn").click(function(){
		var $startDate = $("#only_input_start").val();
		var $endDate = $("#only_input_end").val();
		if($startDate != "" && $endDate != ""){
			if(!compareTime($startDate, $endDate)){
				alert($("#sedatenote").html());
				return false;
			}
		}
		$("#searchForm").submit();
	});
	
	/**
	 * 日期比较
	 */
	function compareTime(startDate, endDate){
		var start = startDate.split(" ")[0];
		var end = endDate.split(" ")[0];
		var starts = start.split("-");
		var ends = end.split("-");
		var start_Time = new Date(starts[0], starts[1], starts[2]).getTime();
		var end_Time = new Date(ends[0], ends[1], ends[2]).getTime();
		if(start_Time > end_Time){
			return false;
		} else{
			return true;
		}
	}

    //导航按钮触发的事件
    navFounction = function(index){
    	$("input[name=pageIndex]").val(index);
    	$("#navForm").submit();
    };
    
    /******Start遮罩层*********************************************************/
	function showDiv(){
		$("#popDiv").fadeIn();
		$("#popIframe").fadeIn();
		$("#bg").fadeIn();
	}
	
	function closeDiv(){
		$("#popDiv").fadeOut();
		$("#popIframe").fadeOut();
		$("#bg").fadeOut();
	}
	
	/*图片点击事件*/
	$("td.viewDetail").click(function(){
		var i = $("td.viewDetail").index(this);
		var src = "carSrc_" + i;
		var $src = $("#" + src);
		var $img = $("#popDiv img");
		if($src.val()){
			$img.attr("src", $src.val());
			showDiv();
		}
	});
	
	$("#popDiv,#bg").click(function(){
		closeDiv();
	});
	/******End遮罩层*********************************************************/
});