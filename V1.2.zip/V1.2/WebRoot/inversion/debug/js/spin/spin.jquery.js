$.fn.spin = function(opts, color,mes) {
	var presets = {
		"tiny": { lines: 8, length: 2, width: 2, radius: 3 },
		"small": { lines: 8, length: 4, width: 3, radius: 5 },
		"large": { lines: 8, length: 6, width: 10, radius: 10 }
	};
	if (Spinner) {
		return this.each(function() {
			var $this = $(this),
				data = $this.data();
			if (data.spinner) {
				data.spinner.stop();
				delete data.spinner;
			}
			if (opts !== false) {
				if (typeof opts === "string") {
					if (opts in presets) {
						opts = presets[opts];
					} else {
						opts = {};
					}
					if (color) {
						opts.color = color;
					}
				}
				data.spinner = new Spinner($.extend({color: $this.css('color')}, opts)).spin(this);
			}
		});
	} else {
		throw "Spinner class not available.";
	}
};