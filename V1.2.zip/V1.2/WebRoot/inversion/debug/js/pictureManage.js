$(function(){

	/* 页面加载时读取配置文件的数据*/
	$.getJSON("queryPicParam.action",
			{"rand" : Math.random()},
			function(data){
				setLanage(data);
	});
	
	function setLanage(data){
		$("#dayParam").html(data.param);
		$("#inversionManage").html(data.map.inversionSearch);
		$("span.paramset").html(data.map.paramset);
		$("#nowday").html(data.map.nowday);
		$("#dayParam").html(data.map.dayParam);
		$("#example").html(data.map.example);
		$("#setday").html(data.map.setday);
		$("span.setup").html(data.map.setup);
		$("span.datetimesetup").html(data.map.datetimesetup);
		$("span.searchhomesetup").html(data.map.searchhomesetup);
		$("span.choicedateformat").html(data.map.choicedateformat);
		$("span.wordsetup").html(data.map.wordsetup);
		
		
	}

	/*设置 图片存储按钮事件*/
	$("#setBtn").click(function(){
		var $date = $("#pic_input").val();
		var $statusImg = $("#picStatusImage");
		$.getJSON(
			"setPicParam.action",
			{"dateParam" : $date, "rand" : Math.random()},
			function(data){
				$("#dayParam").html(data.dateParam);
				showStatus(data.flag, $statusImg);
			}
		);
	});
	
	/*设置 返回查询首页时间事件*/
	$("#setBackTime").click(function(){
		var $backTime = $("#backTime").val();
		$.getJSON(
			"setBackTime.action",
			{"dateParam" : $backTime, "rand" : Math.random()},
			function(data){
				$("#backTimeParam").html(data.backTime);
				showStatus(data.flag, $statusImg);
			}
		);
	});

	/*设置日期时间格式按钮事件*/
	$("#setupDateFormat").click(function(){
		var $formatSel = $("#dateFormatSel").val();
		var $statusImg = $("#dateStatusImage");
		$.getJSON(
				"setFormatParam.action",
				{"rand" : Math.random(), "dateFormat" : $formatSel},
				function(data){
					showStatus(data.flag, $statusImg);
				}
			);
	});

	/*设置寻车首页文字按钮事件*/
	$("#setupInversionIndex").click(function(){
		var $inversionInput = $("#inversionInput").val();
		var $statusImg = $("#indexStatusImage");
		$.getJSON(
			"setInversionIndex.action",
			{"rand" : Math.random(), "inversionInput" : encodeURI($inversionInput)},
			function(data){
				showStatus(data.flag, $statusImg);
			}
		);
	});

	//设置只能输入数字
	$("#pic_input").keyup(function(){  //keyup事件处理 
        $(this).val($(this).val().replace(/[^0-9]/g,''));
        maxLength($(this));
    }).bind("paste",function(){  //CTR+V事件处理 
        $(this).val($(this).val().replace(/[^0-9]/g,''));
        maxLength($(this));
    }).css("ime-mode", "disabled");  //CSS设置输入法不可用
	
	function maxLength(data){
		var str = data.val().toString();
		if(str.length > 3){
			data.val(str.substring(0, 3));
		}
	}
	
});

/**
 * 根据返回的结果显示正确或错误图片
 * @param flag
 */
function showStatus(flag, $statusImg){
	if(flag){
		$statusImg.attr("src", "../images/start.png").fadeIn(500);
		setTimeout(function(){
			$statusImg.fadeOut(500);
		}, 1500);
	} else{
		$statusImg.attr("src", "../images/stop.png").fadeIn(500);
		setTimeout(function(){
			$statusImg.fadeOut(500);
		}, 1500);
	}
}

//显示选定的界面
function show(showId){
	switch (showId) {
	case 1:
		$("#right2").hide();
		$("#right3").hide();
		$("#right4").hide();
		$("#aclass1").addClass("clicked");
		$("#aclass2").removeClass("clicked");
		$("#aclass3").removeClass("clicked");
		$("#aclass4").removeClass("clicked");
		break;
	case 2:
		$("#right1").hide();
		$("#right3").hide();
		$("#right4").hide();
		$("#aclass2").addClass("clicked");
		$("#aclass1").removeClass("clicked");
		$("#aclass3").removeClass("clicked");
		$("#aclass4").removeClass("clicked");
		break;
	case 3:
		$("#right1").hide();
		$("#right2").hide();
		$("#right4").hide();
		$("#aclass3").addClass("clicked");
		$("#aclass1").removeClass("clicked");
		$("#aclass2").removeClass("clicked");
		$("#aclass4").removeClass("clicked");
		$.getJSON("queryInversionIndex.action",{"rand" : Math.random()},
			function(data){
				$("#inversionInput").val(data.param);
			}
		);
		break;
	case 4:
		$("#right1").hide();
		$("#right2").hide();
		$("#right3").hide();
		$("#aclass4").addClass("clicked");
		$("#aclass1").removeClass("clicked");
		$("#aclass2").removeClass("clicked");
		$("#aclass3").removeClass("clicked");
		break;
	}
	$("#right" + showId).show();
}