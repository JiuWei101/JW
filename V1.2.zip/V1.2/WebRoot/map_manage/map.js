var sysmdoel;
$(function(){
	sysmdoel = $('#sysModel').val();//当前系统类型
	
	$f_dialog = $("#f_dialog");//excel文件上传窗口
	var url = "";
	var data = {};
	var needRefresh = false;
	function showDialog(dtitle, ftile){
		var html="<div style='height:40px;margin-top:10px;text-align:center'><label>"+ftile+"：<label><input type='file' name='myFile' id='myFile'/></div>";
		$f_dialog.dialog({
			title: dtitle,
			content:html,
			width:400,
			height:120,
			top:'20%',
			modal:true,
			buttons:[{
				text:$("#btn_save_mess").val(),
				iconCls:'icon-save',
				handler: onSaveCommand
			},{
				text:$("#btn_return_mess").val(),
				iconCls:'icon-cancel',
				handler: onCancelCommand
			}]
		});
	}
	function onSaveCommand(){
		fileUpload(url, data);
	}
	function onCancelCommand(){
		$f_dialog.dialog('close');
	}
	function fileUpload(url, data){
		$.ajaxFileUpload({
			url: url,//用于文件上传的服务器端请求地址  
			secureuri : false,//一般设置为false  
			fileElementId : 'myFile',//文件上传空间的id属性  <input type="file" id="file" name="file" />
			dataType:'json',
			data:data,
			success:function(data,status){
				if(data.flag){
					$f_dialog.dialog('close');
					if(needRefresh){
						operate('list');
					}
				}else{
					$f_dialog.dialog('close');
					alert(data.message);
				}
			},
			error:function(data,status,e){
				$f_dialog.dialog('close');
				alert(e);
			}
		});
	}
	$('#fbtn').on('click',function(){
		data = {};
		needRefresh = false;
		var dtitle = $("#excel_file_imp").val();
		var ftile = $("#excel_file_path").val();
		url = "../map_manage/save_excel.action";
		showDialog(dtitle,ftile);
	});
	$("#uploadjpg").on("click", function(){
		if (checkOne() == false) {
			return;
		} else {
			data = {
				'data.id':getCheckChkValue()
			};
			needRefresh = true;
			var dtitle = "地图jpg文件上传";
			var ftile = "文件路径";
			url = "../map_manage/saveImg.action";
			showDialog(dtitle,ftile);
		}
	});
});
var Process = {
	'content': "<div style='text-align:center;padding-top:20px'><p><img alt='pro' src='../images/processbar.gif'/></p></div>",
	'show': function(container,title){
		var that = this;
		container.dialog({
			title:title,
			width:200,
			height:100,
			modal:true,
			closable:false,
			draggable:false
		}).html(that.content).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
	},
	'hide': function(container){
		if(container){
			container.dialog('close');
		}
	}
};
function operate(str, id) {
	if (str == "create") {  //新建按钮，打开一个新的页面
		wopen("../map_manage/map_create.action", "_blank", 800, 480);
	} else if (str == "delete") {
		if (!checkChk()) {
			alert(getFieldValue("alert_please_select_a_record")); //请先进行选择
			return;
		}
		var rst = window
				.confirm(getFieldValue("alert_remove_parking_and_logicset"));
		if (rst) {
			var rs = window.confirm(getFieldValue("alert_delete"));

			if (rs) {
				$.ajax({
					async : false,
					type : "POST",
					dataType : "json",
					url : "../map_manage/map_delete.action",
					data : {
						'data.id' : getCheckChkValue("chk_record")
					},
					success : function(msg) {
						if (msg.success) {
							operate('list');
						} else {
							alert(msg.ex);
						}
					},
					error : function(msg) {
						alert('error' + msg);
					}
				});
			}

		}
	} else if (str == "edit") {//编辑  地图名
		if (checkOne() == false) {
			return;
		} else {
			wopen(
					"../map_manage/map_edit.action?data.id="
							+ getCheckChkValue(), "_blank", 800, 480);
		}
	} else if (str == "list") {// 列出 多个地图
		document.listform.action = "../map_manage/map_list.action";
		document.listform.submit();
	} else if (str == "back") {	
		winClose();
		window.opener.operate('list');
	} else if (str == "save") {// 打开新建 新建完成保存
		var name = trim($("#name").val());//去除所有空格并重新赋值
		$("#name").val(name);
		var number = trim($("#number").val());
		$("#number").val(number);
		var legend_value = 0.0;		//图例值
		if($('#sys_model').val() == 2){		//如果系统类型是视频
			var legendobj = document.getElementById('legend');
			if(legendobj != undefined){
				legend_value = trim(legendobj.value);
				//是否数值判断
				if(!checkNum(legend_value)){
					alert(getTdText("map_legend") + " " + getFieldValue("alert_only_number"));
					return;
				}
			}
		}
		var flag = true;
		if (getFieldValue('myFile') == '') {//上传地图不能为空
			alert(getTdText("myFile_text") + getFieldValue("alert_is_not_null"));
			flag = false;
			return;
		}
		if (getFieldValue('myFile_fla') == '') {//上传地图不能为空
			alert(getTdText("myFile_text_fla") + getFieldValue("alert_is_not_null"));
			flag = false;
			return;
		}
		if(replacePostfix(getFieldValue('myFile')) != replacePostfix(getFieldValue('myFile_fla'))){
			alert(getFieldValue("alert_filename_no_same"));
			flag = false;
			return;
		}
        var filenameSwf=getFieldValue('myFile');
        var filenameFla=getFieldValue('myFile_fla');
        
        filenameSwf=filenameSwf.substring(filenameSwf.lastIndexOf("\\")+1,filenameSwf.length);
        var finameSwf=filenameSwf.split(".");
        
        filenameFla=filenameFla.substring(filenameFla.lastIndexOf("\\")+1,filenameFla.length);
        var finameFla=filenameFla.split(".");
        
        if(/.*[\u4e00-\u9fa5]+.*$/.test(finameSwf[0])){
        	alert($("#alert_map_chines_extension").val());
	        return ;
        }
        if(/.*[\u4e00-\u9fa5]+.*$/.test(finameFla[0])){
        	alert($("#alert_map_chines_extension").val());
	        return ;
        }
        if(finameSwf[1]!="swf" || finameFla[1]!="fla"){
        	alert($("#alert_map_chines_extension").val());
        	return ;
        } 
            
		if (checkCont() && flag) {
			$.ajaxFileUpload({ //文件上传
				url : '../map_manage/map_save.action',//用于文件上传的服务器端请求地址  
				secureuri : false,//一般设置为false  
				fileElementId : ['myFile','myFile_fla'],//文件上传空间的id属性  <input type="file" id="file" name="file" />  
				dataType : 'json',//返回值类型 一般设置为json  
				data : {
					'data.number' : $("#number").val(),
					'data.name' : $("#name").val(),
					'data.physicalRegionId' : $("#physicalRegionId").val(),
					'data.notes' : $("#notes").val(),
					'data.legend':legend_value,
					'myFile_flaFileName':filenameFla
				},
				success : function(data, status) //服务器成功响应处理函数  
				{
					
					if (data.success == true) {
						window.opener.operate('list');
						winClose();
					} else {
						if (data.success == false) {
							
							if(data.message=='exist'){
								alert($("#alert_map_already_exists").val());
								return;
							}
							
						} else {
							if (data.ex == "") {
								alert($("#map_name").val() + ","
										+ $("#map_number").val()
										+ $("#alert_is_exist").val());
							} else {
								alert(data.ex);
							}
						}
					}
				},
				error : function(data, status, e)//服务器响应失败处理函数  
				{
					alert(e);
				}
			});
		}
	} else if (str == "update") {//编辑时  保存

		if (checkCont()) {
			$.ajaxFileUpload({
				url : '../map_manage/map_update.action',//用于文件上传的服务器端请求地址  
				secureuri : false,//一般设置为false  
				fileElementId : 'myFile',//文件上传空间的id属性  <input type="file" id="file" name="file" />  
				dataType : 'json',//返回值类型 一般设置为json  
				data : {
					'data.number' : $("#number").val(),
					'data.name' : $("#name").val(),
					'data.physicalRegionId' : $("#physicalRegionId").val(),
					'data.notes' : $("#notes").val(),
					'data.id' : $("#id").val()
				},
				success : function(data, status) //服务器成功响应处理函数  
				{
					if (data.success == true) {
						winClose();
						window.opener.operate('list');
					} else {
						if (data.success == 'exist') {
							alert($("#alert_map_already_exists").val());
							return;
						} else {
							if (data.ex == "") {
								alert($("#map_name").val() + ","
										+ $("#map_number").val()
										+ $("#alert_is_exist").val());
							} else {
								alert(data.ex);
							}
						}
					}
				},
				error : function(data, status, e)//服务器响应失败处理函数  
				{
					alert(e);
				}
			});
		}
	} else if (str == "imp") {  //导入数据时  打开一个新的页面
		wopen("../map_manage/map_imp.action?data.id=" + getCheckChkValue(),
				"_blank", 800, 480);
	
	} else if (str == "map_data") {//打开一个新的页面
		if (checkOne() == false) {
			return;
		}else
		{
			wopen("../map_manage/map_impdata.action?data.id="+ getCheckChkValue(), "_blank",
					screen.availWidth / 3 * 2, screen.availHeight / 4 * 3);
			}
	} else if (str == "first") {//向导页  added by LLX 20120821
		if (checkOne() == false) {
			return;
		} else {
			wopen("../map_manage/map_index.action?data.id="
					+ getCheckChkValue(),"_blank",screen.availWidth/3*2,
					screen.availHeight/3* 2);
		}
	} else if (str == "pre2first") {//地图预览页返回向导页  added by LLX 20120821   		
		wopen("../map_manage/map_index.action?data.id=" + id, "_top",
				screen.availWidth / 3 * 2, screen.availHeight / 3 * 2);
	} else if (str == "map_savedata") {//地图数据验证页,成功则保存，不论成功失败，结果放在下一页  added by LLX 20120821
		var $p_dialog = $('#p_dialog');
		var html = "<div style='text-align:center;padding-top:20px'><p><img alt='pro' src='../images/processbar.gif'/></p></div>";
		var import_btn = document.getElementById('import_btn');
		var sysmodel = $('#sysModel').val();
		if(sysmodel == '' || sysmodel == null){//判断系统类型是否为空
			import_btn.disabled = true;
			alert($("#sysmodel_null_mess").val());
			return;
		}else{
			var sc = $("#sc").attr("checked");
			var de = $("#de").attr("checked");
			var gr = $("#gr").attr("checked");
			if (sc == "checked" || de == "checked" || gr == "checked") {
//				try {
					$p_dialog.dialog({
						title:$('#impdata_process').val(),
						width:200,
						height:100,
						modal:true,
						closable:false,
						draggable:false
					}).html(html).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
					
					var eqno = getFlashEqNo(sysmodel); //车位
					var srno = getFlashScreenNo();	//引导屏
					var grno = getFlashGroundNo();	//地感
					var linepoints = getFlashLinePoints(); //路劲点
					var machinepoints = getMachinePoints(); //查询机点
					var liftentrancepoints = getLiftEntranceList(); //电梯入口点
					var dimensionpoints = getDimensionPoints(); //二维码点
					if(!isMatch(sysmodel,eqno)){
						$p_dialog.dialog('close');
						alert($("#sysmodel_notmatch").val());
						return;
					}
					var jflag = true;
					//校验条屏
					var srepeat = judgeRepeat(srno,sysmodel);
					var serror = verifyData(srno,"screen",sysmodel);
					if(srepeat!="" && srepeat!="null"){
						jflag = false;
						$('#srepeat').html(srepeat);
					}
					if(serror!="" && serror!="null"){
						jflag = false;
						$('#serror').html(serror);
					}
					
					//校验车位探测器
					/**
					 * 因大数量车位1500左右，浏览器会报"脚本忙"错误，将车位重复逻辑移植到后台实现
					 * @date 2013-05-15
					 */
					//var drepeat = judgeRepeat(eqno,sysmodel);
					var derror = verifyData(eqno,"detector",sysmodel);
//					if(drepeat!="" && drepeat!="null"){
//						jflag = false;
//						$('#drepeat').html(drepeat);
//					}
					if(derror!="" && derror!="null"){
						jflag = false;
						$('#derror').html(derror);
					}
					
					//校验地感探测器
					var grepeat = judgeRepeat(grno,sysmodel);
					var gerror = verifyData(grno,"groundor",sysmodel);
					if(grepeat!="" && grepeat!="null"){
						jflag = false;
						$('#grepeat').html(grepeat);
					}
					if(gerror!="" && gerror!= "null"){
						jflag = false;
						$('#gerror').html(gerror);
					}
					//判断路径点、查询机点、电梯入口点
					if(!checkIsExist(linepoints,machinepoints,liftentrancepoints)){
						jflag = false;
						$p_dialog.dialog('close');
						return;
					}
					if(jflag){
						//发ajax请求执行后台验证选择项的信息是否正确
						$.ajax({
							async : false,
							type : "POST",
							dataType : "json",
							timeout : 30000,
							url : "../map_manage/map_savedata.action",
							data : {
								'data.id' : $('#id').val(),
								'data.imp_data_sc' : sc == "checked" ? getFlashScreenNo()
										: null,
								'data.imp_data_de' : de == "checked" ? getFlashEqNo(sysmodel)
										: null,
								'data.imp_data_gr' : gr == "checked" ? getFlashGroundNo()
										: null,
								'data.imp_data_linepoint':de == "checked" ? getFlashLinePoints() : null,
								'data.imp_data_machinepoint':de == "checked" ? getMachinePoints():null,
								'data.imp_data_liftentrance':de == "checked" ? getLiftEntranceList():null,
								'data.imp_data_dimension':de == "checked" ? getDimensionPoints():null
							},
							success : function(msg) {//返回数据验证结果
								var obj = getRegionMap("regionMap");
								if (msg.success) {//打印数据验证结果
									callFuncOnePara(obj,"AllToOneFrame",'10');
									$p_dialog.dialog('close');
									alert($("#process_success").val());
									if (msg.message) { //message为false 说明注册已过期
										//TODO
									}
								} else {
									if(msg.drepeat != null && msg.drepeat != ""){
										$('#mysql_drepeat').html(msg.drepeat);
									}
									if(msg.srepeat != null && msg.srepeat != ""){
										$('#mysql_srepeat').html(msg.srepeat);
									}
									if(msg.repeat != null && msg.srepeat != ""){
										$('#mysql_grepeat').html(msg.grepeat);
									}
									if(checkValue(msg.pointerror)){
										$('#mlerror').html(msg.pointerror);
									}
									callFuncOnePara(obj,"HighlightRepeat",msg.derror);//改变不重复的探测器为绿色
									$('#drepeat').html(msg.derror);
									$p_dialog.dialog('close');
									alert($("#alert_map_file_is_not_correct").val());
									return;
								}
							},
							error : function(msg) {
								$p_dialog.dialog('close');
								alert('error' + msg);
								return;
							}
						});

					}else{
						$p_dialog.dialog('close');
						alert(getFieldValue("alert_map_file_is_not_correct"));
						return;
					}
					
//				} catch (e) {
//					$p_dialog.dialog('close');
//					alert(e + getFieldValue("alert_map_file_is_not_correct"));
//					return;
//				}

			} else {
				alert($("#alert_is_not_null").val());
				return;
			}
		}
	}else if("update_mapdata" == str){//更新地图数据，增量或减量或增减  
		if (checkOne() == false) {
			return;
		} else {
			wopen("../map_manage/update_mapdata.action?data.id="+ getCheckChkValue(), "_blank",screen.availWidth / 3 * 2, screen.availHeight / 4 * 3);
		}
	}else if("nupdate" == str){//上传新地图
//		var filenameFla=getFieldValue('myFile_fla');
//		filenameFla=filenameFla.substring(filenameFla.lastIndexOf("\\")+1,filenameFla.length);
		
		var id = $("#id").val();
		$("#imp_btn").linkbutton('enable');
		upload_update(id);
		
	}
}
function upload_update(id){
	$.ajaxFileUpload({
		url : '../map_manage/save_updatemap.action',//用于文件上传的服务器端请求地址  
		secureuri : false,//一般设置为false  
		fileElementId : ['myFile','myFile_fla'],//文件上传空间的id属性  <input type="file" id="file" name="file" />  
		dataType : 'json',//返回值类型 一般设置为json  
		data : {
			"data.id":id
		},
		success : function(data, status) //服务器成功响应处理函数  
		{
			if(data.success){//上传地图成功后，自动进行地图的校验
				showMapInContainer("n_obj","regionMap","regionMap",data.path,"100%","400");
				$("#map_src").val(data.mapSrc);
				$('#sysModel').val(data.sysModel);
				var obj = getRegionMap("regionMap");
				interval = setInterval(function(){
					var flag = checkFlashComplete(obj,interval);
					if(flag){
						updateMapCheck("regionMap",$('#id').val(),data.sysModel);
					}
				},500);
			}else{
				var message = data.message;
				alert(message);
			}
		},
		error : function(data, status, e)//服务器响应失败处理函数  
		{
			alert(e);
		}
	});
}

//去除后缀名
function replacePostfix(str){
	var reg = /\.\w+$/;
	return str.replace(reg,'');
}

function imp_update(mapId,mapSrc,sysModel){   //第二次 调用导入数据
	var $p = $('#p_dialog');
	Process.show($p, $('#impdata_process').val());
	var obj = getRegionMap("regionMap");
	var cars = callFuncOnePara(obj,"GetCarList",sysModel);
	cars = cars.replace("<string>", "").replace("</string>", "");
	var screens = callFuncNoPara(obj,"GetScreenList");
	screens = screens.replace("<string>", "").replace("</string>", "");
	var grounds = callFuncNoPara(obj,"GetGroundSensorList");
	grounds = grounds.replace("<string>", "").replace("</string>", "");
	var linepoints = callFuncNoPara(obj,"GetLinePointList");
	linepoints = linepoints.replace("<string>", "").replace("</string>", "");
	var machinepoints = callFuncNoPara(obj,"GetMachinePointList");
	machinepoints = machinepoints.replace("<string>", "").replace("</string>", "");
	var liftpoints = callFuncNoPara(obj,"GetLiftEntranceList");
	liftpoints = liftpoints.replace("<string>", "").replace("</string>", "");
	var dmspoints = getDimensionPoints();
	$.ajax({
		async:false,
		url:'../map_manage/updatemap_imp.action',
		type:'post',
		dataType:'json',
		data:{
			'data.id':mapId,
			'data.map_src':mapSrc,
			'data.imp_data_sc':screens,
			'data.imp_data_de':cars,
			'data.imp_data_gr':grounds,
			'data.imp_data_linepoint':linepoints,
			'data.imp_data_machinepoint':machinepoints,
			'data.imp_data_liftentrance':liftpoints,
			'data.imp_data_dimension':dmspoints
		},
		success:function(data){
			Process.hide($p);
			if(data.success){
				var html = "";
				var dh = 0;
				if(checkValue(data.cmess)){
					html += "<div class='mess'>"+data.cmess+"</div>";
					dh++;
				}
				if(checkValue(data.dmess)){
					html += "<div class='mess'>"+data.dmess+"</div>";
					dh++;
				}
				if(checkValue(data.smess)){
					html += "<div class='mess'>"+data.smess+"</div>";
					dh++;
				}
				if(checkValue(data.gmess)){
					html += "<div class='mess'>"+data.gmess+"</div>";
					dh++;
				}
				html += "<div class='mess'>"+data.message+"</div>";
				dh = dh*20+60;
				$i_alert = $("#i_alert");
				$i_alert.dialog({
					title:$("#update_map_title").val(),
					width:300,
					height:dh,
					resizable:true,
					content:html
				}).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
			}else{
				
			}
		},
		error:function(e){
			Process.hide($p);
			alert(e);
		}
	});
}

/**
 * 更新地图的数据的校验
 * @param objName
 * @param mapId
 * @param sysModel
 */
function updateMapCheck(objName,mapId,sysModel){ //第二次 导入 检查
	var obj = getRegionMap(objName);
	var cars = callFuncOnePara(obj,"GetCarList",sysModel);
	cars = cars.replace("<string>", "").replace("</string>", "");
	var screens = callFuncNoPara(obj,"GetScreenList");
	screens = screens.replace("<string>", "").replace("</string>", "");
	var grounds = callFuncNoPara(obj,"GetGroundSensorList");
	grounds = grounds.replace("<string>", "").replace("</string>", "");
	var linepoints = callFuncNoPara(obj,"GetLinePointList");
	linepoints = linepoints.replace("<string>", "").replace("</string>", "");
	var machinepoints = callFuncNoPara(obj,"GetMachinePointList");
	machinepoints = machinepoints.replace("<string>", "").replace("</string>", "");
	var liftpoints = callFuncNoPara(obj,"GetLiftEntranceList");
	liftpoints = liftpoints.replace("<string>", "").replace("</string>", "");
	
	var dmspoints = getDimensionPoints();
	if(checkIsExist(linepoints,machinepoints,liftpoints)){
		$.ajax({
			async:false,
			url:'../map_manage/updatemap_check.action',
			type:'post',
			dataType:'json',
			data:{
				'data.id':mapId,
				'data.sysModel':sysModel,
				'data.imp_data_sc':screens,
				'data.imp_data_de':cars,
				'data.imp_data_gr':grounds,
				'data.imp_data_linepoint':linepoints,
				'data.imp_data_machinepoint':machinepoints,
				'data.imp_data_liftentrance':liftpoints,
				'data.imp_data_dimension':dmspoints
			},
			success:function(data){
				if(!data.flag){//地图校验有错
					var html = "";
					var dh = 0;
					if(checkValue(data.drmess)){
						html += "<div class='mess'>"+data.drmess+"</div>";
						dh++;
					}
					if(checkValue(data.demess)){
						html += "<div class='mess'>"+data.demess+"</div>";
						dh++;
					}
					if(checkValue(data.srmess)){
						html += "<div class='mess'>"+data.srmess+"</div>";
						dh++;
					}
					if(checkValue(data.semess)){
						html += "<div class='mess'>"+data.semess+"</div>";
						dh++;
					}
					if(checkValue(data.grmess)){
						html += "<div class='mess'>"+data.grmess+"</div>";
						dh++;
					}
					if(checkValue(data.gemess)){
						html += "<div class='mess'>"+data.gemess+"</div>";
						dh++;
					}
					if(checkValue(data.pmess)){
						html += "<div class='mess'>"+data.pmess+"</div>";
						dh++;
					}
					dh = dh*20+40;
					$m_alert = $("#m_alert");
					$m_alert.dialog({
						title:$("#update_map_title").val(),
						width:240,
						height:dh,
						content:html
					}).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
					$("#srepeat").html(data.srepeat);
					$("#serror").html(data.serror);
					$("#drepeat").html(data.drepeat);
					$("#derror").html(data.derror);
					$("#grepeat").html(data.grepeat);
					$("#gerror").html(data.gerror);
					$("#imp_btn").linkbutton('disable');
				}else{
					alert(data.message);
				}
			},
			error:function(e){
				alert(e);
			}
		});
	}else{
		return;
	}
}
//获得所有超声波探测器信息
function getFlashEqNo(sysModel) {
	var bays = getRegionMap("regionMap")
			.CallFunction(
					"<invoke name=\"GetCarList\" returntype=\"xml\"><arguments><string>"+sysModel+"</string></arguments></invoke>");
		bays = bays.replace("<string>", "").replace("</string>", "");
	return bays;
}

//获得所有地感信息
function getFlashGroundNo() {
	var bays = getRegionMap("regionMap")
			.CallFunction(
					"<invoke name=\"GetGroundSensorList\" returntype=\"xml\"><arguments></arguments></invoke>");
		bays = bays.replace("<string>", "").replace("</string>", "");
	return bays;
}

//获得所有引导屏信息
function getFlashScreenNo() {
	var bays = getRegionMap("regionMap")
			.CallFunction(
					"<invoke name=\"GetScreenList\" returntype=\"xml\"><arguments></arguments></invoke>");
		bays = bays.replace("<string>", "").replace("</string>", "");
	return bays;
}
//获取路径关键点
function getFlashLinePoints(){
	var points = getRegionMap("regionMap").CallFunction("<invoke name=\"GetLinePointList\" returntype=\"xml\"><arguments></arguments></invoke>");
	points = points.replace("<string>", "").replace("</string>", "");
	return points;
}
//获取查询机点
function getMachinePoints(){
	var mpoints = getRegionMap("regionMap").CallFunction("<invoke name=\"GetMachinePointList\" returntype=\"xml\"><arguments></arguments></invoke>");
	mpoints = mpoints.replace("<string>", "").replace("</string>", "");
	return mpoints;
}

//获取电梯入口点
function getLiftEntranceList(){
	var mpoints = getRegionMap("regionMap").CallFunction("<invoke name=\"GetLiftEntranceList\" returntype=\"xml\"><arguments></arguments></invoke>");
	mpoints = mpoints.replace("<string>", "").replace("</string>", "");
	return mpoints;
}

//获取二维码点
function getDimensionPoints(){
	var dpoints = getRegionMap("regionMap").CallFunction("<invoke name=\"GetDimensionPointList\" returntype=\"xml\"><arguments></arguments></invoke>");
	if(dpoints){
		dpoints = dpoints.replace("<string>", "").replace("</string>", "");
	}else{
		dpoints = "null";
	}
	return dpoints;
}

//校验页面输入项
function checkCont() {
	var flag = true;

	if (getFieldValue("number") == '') {
		alert($("#map_number").val() + getFieldValue("alert_is_not_null"));
		flag = false;
	} else if (getFieldValue('name') == '') {
		alert($("#map_name").val() + getFieldValue("alert_is_not_null"));
		flag = false;
	} else if (getFieldValue('physicalRegionId') == null) {
		alert(getTdText("physical_area_text")
				+ getFieldValue("alert_is_not_null"));
		flag = false;
	} else if (getFieldValue("notes").length > 200) {
		alert(getTdText("remark_text") + getFieldValue("alert_max_length")
				+ "200");
		flag = false;
	}
	return flag;
}
function showMap(file, width, height) {
	document.write("<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"
					+ width
					+ "' height='"
					+ height
					+ "' id='regionMap' name='regionMap'>");
	document.write("<param name='allowScriptAccess' value='always' />");
	document.write("<param name='movie' value='" + file + "'>");
	document.write("<param name='quality' value='high'>");
	document.write("<embed src='"
					+ file
					+ "' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"
					+ width + "' height='" + height
					+ "' id='regionMap' name='regionMap'></embed></object>");
	document.getElementById("regionMap").movie = encodeURI(file);
}

//下载地图文件模版
function downloadFile(){
   	MapManageAction.downloadFile(function(data){  
		dwr.engine.openInDownload(data);
	});  
}

/**
 * 
 *根据传进来的编码和类型，判断当前地图超声波探测器、地感探测器、条屏是否存在编码重复或错误，并高亮显示
 */
//判断重复
function judgeRepeat(bays,sysModel){
	var obj = getRegionMap("regionMap");//获取Object
	var repeat = "";
	var baysArr = bays.split(",");
	if(sysModel == 2){	//当前系统类型为视频
		for(var i=0; i<baysArr.length; i++){
			if(baysArr[i].indexOf("_") != -1){	//忽略条屏、地感
				baysArr[i] = baysArr[i].substring(0,baysArr[i].indexOf("|"));
			}
		}
	}
	if(bays.length > 1){
		for(var i=0; i<baysArr.length; i++){
			var rflag = true;
			for(var j=i+1; j<baysArr.length; j++){
				if(baysArr[i] == baysArr[j]){
					repeat += baysArr[i]+",";
					repeat += baysArr[j]+",";
					rflag = false;
				}
			}
			if(rflag && baysArr[i].indexOf('P')== -1){
				updateBays(obj,baysArr[i], 9);
			}
		}
		if(repeat !=""){
			repeat = repeat.substring(0, repeat.length-1);
		}
		return repeat;
	}else{
		return repeat;
	}
}

//判断错误
function verifyData(bays,type,sysModel){
	var obj = getRegionMap("regionMap");//获取Object
	var baysArr = bays.split(",");
	var repeat = "";
	if(type == "detector"){
		if(sysModel == 1){	//系统为超声波类型
			for(var i=0; i<baysArr.length; i++){
				if(baysArr[i].length != 6){//判断探测器长度是否是6
					updateBays(obj,baysArr[i], 4);	//跳到第5帧
					repeat +=baysArr[i]+",";
				}else{
					var cno = baysArr[i].substring(0,3);
					var dno = baysArr[i].substring(3,6);
					if(parseInt(dno,10) > 95){//判断探测器编码是否不大于95
						updateBays(obj,baysArr[i], 5);	//跳到第6帧
						repeat +=baysArr[i]+",";
					}
					if(parseInt(cno,10) > 95){//判断管理器编码是否不大于95
						updateBays(obj,baysArr[i], 3);	//跳到第4帧
						repeat +=baysArr[i]+",";
					}
				}
			}
		}
		if(sysModel == 2){ //系统为视频类型
			for(var i=0; i<baysArr.length; i++){
				var tempBay = baysArr[i].substring(0,baysArr[i].indexOf('|'));
				if(!checkDetector(tempBay)){
					updateBays(obj,tempBay, 4);	//跳到第5帧
					repeat +=tempBay+",";
				}
			}
		}
		if(sysModel == 3){	//系统为地磁类型
			for(var i=0; i<baysArr.length; i++){
				if(baysArr[i].length != 9){//判断探测器长度是否是9
					updateBays(obj,baysArr[i], 4);
					repeat +=baysArr[i]+",";
				}else{
					var dno = baysArr[i].substring(6,9);
					if(parseInt(dno,10) > 32){//判断探测器编码是否不大于32
						updateBays(obj,baysArr[i], 5);
						repeat +=baysArr[i]+",";
					}
				}
			}
		}
	}else if(type == "groundor"){
		if(sysModel == 1){		//地感在超声波类型系统中使用
			for(var i=0; i<baysArr.length; i++){
				if(baysArr[i].length != 6){//判断地感长度是否是6
					updateBays(obj,baysArr[i], 9);
					repeat +=baysArr[i]+",";
				}else{
					var dno = baysArr[i].substring(3,6);
					if(parseInt(dno,10) < 96 || parseInt(dno,10) > 127){//判断探测器编码是否96 <= dno <=127
						updateBays(obj,baysArr[i], 9);
						repeat +=baysArr[i]+",";
					}
				}
			}
		}
	}else if("screen" == type){//判断条屏
		for(var i=0; i<baysArr.length; i++){
			if(baysArr[i].length != 6 || baysArr[i].indexOf('P')!= 0){//判断条屏长度是否是6,且是否以“P”开头
				updateBays(obj,baysArr[i], 9);
				repeat +=baysArr[i]+",";
			}else{
				var dno = baysArr[i].substring(4,6);
				if(parseInt(dno,10) > 100){//判断条屏编码是否不大于63
					updateBays(obj,baysArr[i], 9);
					repeat +=baysArr[i]+",";
				}
			}
		}
	}else if("linepoint" == type){//判断路径点
		
	}
	if(repeat!=""){
		repeat = repeat.substring(0, repeat.length-1);
	}
	return repeat;
}
var InternetExplorer = navigator.appName.indexOf("Microsoft") != -1;		

if (navigator.appName && navigator.appName.indexOf("Microsoft") != -1 && 
  navigator.userAgent.indexOf("Windows") != -1 && navigator.userAgent.indexOf("Windows 3.1") == -1) {
  document.write("<script language='vbscript'> \n");
  document.write("on error resume next \n");
  document.write("Sub regionMap_FSCommand(ByVal command, ByVal args)\n");
  document.write(" call regionMap_DoFSCommand(command, args)\n");
  document.write("end sub\n");
  document.write("<\/script> \n");
}
function regionMap_DoFSCommand(command, args){
	if(command == "sensor" || command == "GroundSensor" || command == "screen" || command == "reversemachine" || command == "linepoint"){
		$('#curr_code').html(args);
	}else if("Clear" == command){
		$('#curr_code').html('');
	}
}
/**
 * 根据系统类别和车位探测器name判断是否一致
 * @param sysModel
 * @param bays
 * @returns {Boolean}
 */
function isMatch(sysModel,bays){
	if(bays != "" && bays != null && bays != "null"){	
		bayArr = bays.split(",");
		bay = bayArr[0];
		baylen = bay.length;
		if(sysModel == 1){
			if(baylen != 6){
				return false;
			}else{
				return true;
			}
		}else if(sysModel == 2){
			if(bay.indexOf("_") == -1){
				return false;
			}else{
				return true;
			}
		}else{
			if(baylen != 9){
				return false;
			}else{
				return true;
			}
		}
	}else{
		return true;
	}
}
//获取路径点和查询机点字符串数组
function getLineAndMachinePoints(linepoints,machinepoints){
	var prArr = new Array();
	if(checkValue(linepoints) && checkValue(machinepoints)){
		var lineArr = linepoints.split("]");
		var machineArr = machinepoints.split("]");
		for(var i=0; i<lineArr.length; i++){
			var prName = lineArr[i].substring(0,lineArr[i].indexOf("|"));
			prArr.push(prName);
		}
		for(var i=0; i<machineArr.length; i++){
			var prName = machineArr[i].substring(0,machineArr[i].indexOf("|"));
			prArr.push(prName);
		}
	}
	return prArr;
}
//验证是否缺少连通关系
function checkErrorCode(arr){
	var obj = getRegionMap("regionMap");//获取Object
	var flag = true;
	if(arr.length > 0){
		for(var i=0; i<arr.length; i++){
			var temp = arr[i];
			if(temp.indexOf("-") == -1){
				flag = false;
				alert(temp+"---缺少连通关系");
			}
		}
	}
	return flag;
}
//检验编码是否重复及连通关系是否描述正确
function checkIsRepeatOrNotComplete(prArr){
	var obj = getRegionMap("regionMap");//获取Object
	if(prArr.length > 0){
		var globeflag = true;//全局标识，若最终为true，表明编码无重复，则校验连通关系是否完全
		for(var i=0; i<prArr.length;i++){
			var flag = true;
			var iTemp = prArr[i].substring(0,prArr[i].indexOf("-"));
			for(var j=i+1; j <prArr.length; j++){
				var jTemp = prArr[j].substring(0,prArr[j].indexOf("-"));
				if(iTemp == jTemp){
					flag = false;
					globeflag = false;
				 }else{
					}
				}
			if(flag){
				updateBays(obj,prArr[i], 1);//跳到第2帧，表示编码不重复
			}
		}
		
		if(globeflag){
			for(var i=0; i<prArr.length; i++){
				var iTempStart = prArr[i].substring(0,prArr[i].indexOf("-"));
				var iTempEnd =  prArr[i].substring(prArr[i].indexOf("-") + 1);
				var tarr = iTempEnd.split(",");
				for(var j=0; j<tarr.length; j++){
					var jtemp = tarr[i];
					for(var m=0; m<prArr.length; m++){
						var mtemp =  prArr[j].substring(0,prArr[j].indexOf("-"));
						if(jtemp == mtemp){
							if(prArr[j].indexOf(jtemp) == -1){
								
							}
						}
					}
				}
			}
		}
	}
}
//判断路径点、查询机点、电梯入口点
function checkIsExist(linepoints,machinepoints,liftentrancepoints){
	var cflag = false;
	if(checkValue(liftentrancepoints)){//电梯入口点不为空
		if(checkValue(linepoints)){//路径点不为空
			//&& checkValue(machinepoints)
			/**
			 * 下一步需校验当前数据库是否存在“电梯入口点”，如果不存在，则不需校验是否存在“查询机点”
			 * 如果存在，则需校验当前地图上的“电梯入口点”命名与数据库中的“电梯入口点”命名是否相同
			 
			$.ajax({
				async:false,
				url:'../map_manage/check_lifts.action',
				type:'post',
				dataType:'json',
				data:{'data.imp_data_liftentrance':liftentrancepoints},
				success:function(data){
					if(data.flag){
						cflag =  true;
					}else{
						cflag =  false;
						alert(data.msg);
					}
				},
				error: function(e){
					cflag=  false;
					alert(e);
				}
			});*/
			cflag =  true;
		}else{
			cflag =  false;
		}
	}else{//电梯入口点为空，则查询机点和路径点均为空，或均不为空
		if((checkValue(linepoints) && checkValue(machinepoints)) || (!checkValue(linepoints) && !checkValue(machinepoints))){
			cflag =  true;
		}else{
			cflag =  false;
		}
	}
	return cflag;
}
function exp(){
	if (!checkChk()) {
		alert(getFieldValue("alert_please_select_a_record")); //请先进行选择
		return;
	}else{
		var id = getCheckChkValue("chk_record");
		$.ajax({
			async:false,
			type:"post",
			dataType:'json',
			url:'../map_manage/before_expcheck.action',
			data:{'data.id':id},
			success: function(data){
				if(data.flag){
					document.listform.action = "../map_manage/exp_mapdata.action?ids="+id;
					document.listform.submit();
				}else{
					alert(data.name);
				}
			},
			error: function(e){
				alert(e);
			}
		});
	}
}