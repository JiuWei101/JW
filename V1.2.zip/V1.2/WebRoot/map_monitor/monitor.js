$(function(){
	$.extend($.messager.defaults,{  
	    ok:$('#alert_btn_return').val()
	});
	$('.arrow_a').on('click',function(){
		var id = $(this).attr('id');
		var str = "";
		if(id == 'arrow_up'){
			str = "↑";
		}else if(id == 'arrow_left'){
			str = "←";
		}else if(id == 'arrow_right'){
			str = "→";
		}else if(id == 'arrow_down'){
			str = "↓";
		}
		get_screen_relation_mess(str);
	});
	//读取配置文件设置连接配置参数
	$.getJSON("../mapmonitor/readMonitorXml.action?random=" + new Date().getTime() + Math.random(), "",
		 function(data){
			var $monitor = data.monitor.split(",");
			if($monitor.length >= 8){
				$('#ipadress').val($monitor[0]);
				$('#portnum').val($monitor[1]);
				$('#username').val($monitor[2]);
				$('#password').val($monitor[3] == "nana" ? "" : $monitor[3]);
				$('#ipadress_second').val($monitor[4]);
				$('#portnum_second').val($monitor[5]);
				$('#username_second').val($monitor[6]);
				$('#password_second').val($monitor[7] == "nana" ? "" : $monitor[7]);
			}
		}
	);
	$("#cariamgeA").colorbox();
});

var cardetector = "";
var carzhen = "";
function onLoad(){
	var isexistmap = $('#isexistmap').val();
	if(isexistmap == "none"){	//当前系统不存在地图文件
		$.messager.alert($('#alert_map_title').val(),$('#alert_no_maps_mess').val(),'info');
	}else{
		refresh();
	}
	setInterval(function(){funhander();}, 60000);
}
//把引导屏内容格式保存为数组，方便生成预览内容
var sFormatArray = new Array();
function funhander(){
	$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/communication_status.action",
			data:{},
			success: function(msg){
				if(msg.success){

				}else{
					document.getElementById('alert_com_service_offline').value = $('#alert_com_service_offline').val();
				}						
			},
			error:function(msg){
				
			}
		});
}
function refresh(){
	//TODO
	refreshMapData();//更新地图数据统计
	getMapMonitorData();//更新地图状态
	setTimeout("refresh();",5000);//5秒刷新一次
}
function updatecar(){
	var obj = getRegionMap("regionMap");
	updateScreenStatus(obj,cardetector,carzhen);
}
var InternetExplorer = navigator.appName.indexOf("Microsoft") != -1;		
	
	if (navigator.appName && navigator.appName.indexOf("Microsoft") != -1 && 
	  navigator.userAgent.indexOf("Windows") != -1 && navigator.userAgent.indexOf("Windows 3.1") == -1) {
	  document.write("<script language='vbscript'> \n");
	  document.write('on error resume next \n');
	  document.write('Sub regionMap_FSCommand(ByVal command, ByVal args)\n');
	  document.write(' call regionMap_DoFSCommand(command, args)\n');
	  document.write('end sub\n');
	  document.write('</script\> \n');
	} 
	
	var lastSelectingBays = "";		//记录上次选中的探测器或条屏编码
	
	/**
	 * 点击探测器或条屏触发操作
	 * @param command
	 * @param args
	 */
	function regionMap_DoFSCommand(command, args) 
	{ 
	  var obj = getRegionMap("regionMap");
	  if(command == "sensor")   //传感器(探测器)
	  {
		$('#monitor_tabs').tabs('select',$('#parking_state_title').val());
		  if(""!=carzhen){
			  updateScreenStatus(obj,lastSelectingBays, carzhen);//改变上次选中的颜色
		  }
	  	
	  	updateScreenStatus(obj,args, 2);//变更已选中的车位颜色
	  	lastSelectingBays = args; 
//************************车位信息******************	
		document.getElementById("hid_parking_code").value = args+"";
		get_parking_mess();
	  	setTimeout("updatecar()",10000);
	  	
//*************************************************************	
		  	
	  }
	  else if(command == "screen")
	  {
		$('#monitor_tabs').tabs('select',$('#all_map_collection_title').val());
		var map_id = document.getElementById("map_id").value;
		//updateScreenStatus(lastSelectingBays, 1);
//****************屏信息**********************
		document.getElementById("hid_screen_code").value = args+"";
		get_screen_mess();
	  		
//****************************************
		updateScreenStatus(obj,args,1);
	  }
	  else if(command == "Clear")    //清除
	  {	
		//$('#monitor_tabs').tabs('select',$('#all_map_collection_title').val());
	    //变更为初始状态。如数据未导入，则更新为默认状态；如数据已经导入则更新为临时车位状态；如已经设置了车位类型或逻辑区域则更新为已经设置好的状态
	  	bays = lastSelectingBays;
		if(bays.length >0)
		{
			obj.SetVariable("enableEdit","1");
							
			bays = bays.replace("<string>","").replace("</string>","");				 
			var baysArr = bays.split(",");
			for(var i=0;i<baysArr.length;i++)
			{
				//updateScreenStatus(baysArr[i], 9);//Test,9为空临时车位
			}
		}
	  }
	}
	var $html = $("<img id='carimage' alt='pic' style='width:100%;height:100%'/>");
	var pInterval = null;//取车位定时器
	//取车位信息
	function get_parking_mess(){
		var obj = getRegionMap("regionMap");
		var map_id = document.getElementById("map_id").value;
		var args = document.getElementById("hid_parking_code").value;
		$.ajax({
		    async: false,
		    cache : false,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/get_parking_mess.action",
			data:{"data.detector_code":args,"data.map_id":map_id},
			success: function(msg){

				if(msg.success){
					if(msg.mapData.cur_detector_status=='默认'){
						alert($("#not_configured").val());
					}else{
						$("#detector_code").text(msg.mapData.detector_code);
						$("#parkingSpace_code").text(msg.mapData.parkingSpace_code);
						$("#spotTypeNow").text(msg.mapData.spotTypeNow);
						$("#bgn_detector").text(msg.mapData.bgn_detector);
						$("#end_detector").text(msg.mapData.end_detector);
						$("#cur_detector_status").text(msg.mapData.cur_detector_status);
						$("#updateDate").text(msg.mapData.updateDate);
						$("#car_plateno").text(msg.mapData.plateno);
						var picpath = msg.mapData.picturepath;
						if(picpath !="" && picpath != null && picpath !="null"){
							if($("#carimage").length == 0){
								$html.attr("src", picpath + "&random=" + Math.random());
								$("#cariamgeA").html($html);
							}else{
								$("#carimage").attr("src", picpath + "&random=" + Math.random());
							}
							$("#cariamgeA").attr("href", picpath);
						}else{
							$("#cariamgeA").empty();
						}
						cardetector = msg.mapData.detector_code;
						carzhen = msg.mapData.data_total;
					}
					var code = msg.mapData.detector_code.replace(/\./g,"_");
					updateScreenStatus(obj,code,msg.mapData.data_total);
					if(!pInterval){
						pInterval = setInterval("get_parking_mess();",5000);
					}
				}						
			},
			error:function(msg){
			}
		});
	}
	function sendparkingspacetask(){
		var map_id = document.getElementById("map_id").value;
		var args = document.getElementById("hid_parking_code").value;
		//alert(map_id+"****"+args);
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/sendparkingspacetask.action",
			data:{"data.detector_code":args,"data.map_id":map_id},
			success: function(msg){
				$.messager.show({
					title:msg.message,
					msg:msg.message,
					timeout:3000,
					showType:'slide'
				});
			},
			error:function(msg){
			}
		});
	}
	//取屏信息
	var sInterval = null;//条屏信息定时器
	function get_screen_mess(args,map_id){
		var map_id = document.getElementById("map_id").value;
		var args = document.getElementById("hid_screen_code").value;
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/get_screen_mess.action",
			data:{"data.screen_code":args,"data.map_id":map_id},
			success: function(msg){

				if(msg.success){
					$("#screen_code").text(msg.mapData.screen_code);
					$("#cur_screen_status").text(msg.mapData.cur_screen_status);
					var str = msg.regionCode;
					var srcStr = msg.srcRegionCode;
					var screen_width = msg.mapData.screen_width;
					document.getElementById("contentFormat").innerHTML = setPreview(str,screen_width*10);
					document.getElementById("srcContentFormat").innerHTML = setPreview(srcStr,screen_width*10);
					if(str != '' && sInterval == null)
						sInterval = setInterval("get_screen_mess();",5000);	
				}						
			},
			error:function(msg){
			}
		});
	}
	var MES = (function($){
		return {
			'show':function(mes){
				var html = "<div><img src='../themes/default/images/messager_info.gif' alt='img'/>"+mes+"</div>";
				$.messager.show({
					title:'',
					msg:html,
					width:180,
					height:80,
					timeOut:'2000',
					showType:'slide'
				});
			}
		};
	})($);
	//获取与条屏相关的探头信息
	function get_screen_relation_mess(arrow){
		var obj = getRegionMap("regionMap");
		var map_id = document.getElementById("map_id").value;	//地图id
		var args = document.getElementById("hid_screen_code").value;	//引导屏编号
		if(args == "" || args == null){
			MES.show($("#alert_select_screen_mess").val());
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/get_screen_relation_mess.action",
			data:{
				"data.screen_code":args,
				"data.map_id":map_id,
				"data.direction":arrow
				},
			success: function(msg){
				if(msg.success){
					if(msg.mess){
						MES.show($("#alert_no_such_guideRegion").val());
					}
					callFuncOnePara(obj,"NSetGroupNo",msg.dataStr);
				}else{
					MES.show($("#alert_no_such_guideRegion").val());
				}						
			},
			error:function(msg){
			}
		});
	}	
	function clear(){
		//变更为初始状态。如数据未导入，则更新为默认状态；如数据已经导入则更新为临时车位状态；如已经设置了车位类型或逻辑区域则更新为已经设置好的状态
	  	bays = lastSelectingBays;
	  	var obj = getRegionMap("regionMap");
		if(bays.length >0)
		{
			getRegionMap("regionMap").SetVariable("enableEdit","1");
							
			bays = bays.replace("<string>","").replace("</string>","");				 
			var baysArr = bays.split(",");
			for(var i=0;i<baysArr.length;i++)
			{
				updateScreenStatus(obj,baysArr[i], 9);//Test,9为空临时车位
			}
		}
	}
	
//更新地图数据统计
function refreshMapData(){
	var map_id = document.getElementById("map_id").value;
	
	$.ajax({
		    async: true,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/getSAMapData.action",
			data:{"data.map_id":map_id},
			success: function(msg){
				if(msg.success){					
					var temp = msg.mapData.stemp_data.split(',');
					for(var i=0;i<temp.length;i++){
						$("#data_count"+i).text(temp[i]);
					}
					var ls_total = (temp[0]-0)+(temp[3]-0);
					$("#ls_total").text(ls_total);
					var ls_lv = getBiLv(temp[3],ls_total);
					document.getElementById("ls_lv").innerHTML = ls_lv;//显示百分率
					document.getElementById("ls_lv_css").style.width = ls_lv;//设置显示条长度
					var gd_total = (temp[1]-0)+(temp[4]-0);
					$("#gd_total").text(gd_total);
					var gd_lv = getBiLv(temp[4],gd_total);
					document.getElementById("gd_lv").innerHTML = gd_lv;
					document.getElementById("gd_lv_css").style.width = gd_lv;
					var yd_total = (temp[2]-0)+(temp[5]-0);
					$("#yd_total").text(yd_total);
					var yd_lv = getBiLv(temp[5],yd_total);
					document.getElementById("yd_lv").innerHTML = yd_lv;
					document.getElementById("yd_lv_css").style.width = yd_lv;
					var zj_zhan = (temp[3]-0)+(temp[4]-0)+(temp[5]-0);
					document.getElementById("zj_zhan").innerHTML = zj_zhan;
					document.getElementById("zj_sheng").innerHTML = (temp[0]-0)+(temp[1]-0)+(temp[2]-0);
					var zj_total = ls_total+gd_total+yd_total;
					document.getElementById("zj_total").innerHTML = zj_total;
					var zj_lv = getBiLv(zj_zhan,zj_total);
					document.getElementById("zj_lv").innerHTML = zj_lv;
					document.getElementById("zj_lv_css").style.width = zj_lv;
					
					temp = msg.mapData.atemp_data.split(',');
					for(var i=0;i<temp.length;i++){
						$("#total_count"+i).text(temp[i]);
					}
					var ls_total = (temp[0]-0)+(temp[3]-0);
					$("#total_ls_total").text(ls_total);
					var ls_lv = getBiLv(temp[3],ls_total);
					document.getElementById("total_ls_lv").innerHTML = ls_lv;//显示百分率
					document.getElementById("total_ls_lv_css").style.width = ls_lv;//设置显示条长度
					var gd_total = (temp[1]-0)+(temp[4]-0);
					$("#total_gd_total").text(gd_total);
					var gd_lv = getBiLv(temp[4],gd_total);
					document.getElementById("total_gd_lv").innerHTML = gd_lv;
					document.getElementById("total_gd_lv_css").style.width = gd_lv;
					var yd_total = (temp[2]-0)+(temp[5]-0);
					$("#total_yd_total").text(yd_total);
					var yd_lv = getBiLv(temp[5],yd_total);
					document.getElementById("total_yd_lv").innerHTML = yd_lv;
					document.getElementById("total_yd_lv_css").style.width = yd_lv;
					var zj_zhan = (temp[3]-0)+(temp[4]-0)+(temp[5]-0);
					document.getElementById("total_zj_zhan").innerHTML = zj_zhan;
					document.getElementById("total_zj_sheng").innerHTML = (temp[0]-0)+(temp[1]-0)+(temp[2]-0);
					var zj_total = ls_total+gd_total+yd_total;
					document.getElementById("total_zj_total").innerHTML = zj_total;
					var zj_lv = getBiLv(zj_zhan,zj_total);
					document.getElementById("total_zj_lv").innerHTML = zj_lv;
					document.getElementById("total_zj_lv_css").style.width = zj_lv;
				}else{
					flag = true;
				}						
			}
		});
}
//地图实时状态数据
function getMapMonitorData(){
	var map_id = document.getElementById("map_id").value;
	var map_name = document.getElementById("map_name").value;
	if(map_id==null||map_id==''||map_name==null || map_name==''){
		return;
	}else{
		$.ajax({
		    async: true,
			type: "POST",
			dataType: "json",
			url: "../mapmonitor/getMapMonitorData.action",
			data:{"data.map_name":map_name,
				  "data.map_id":map_id
				},
			success: function(msg){
				if(msg.success){
					var obj = getRegionMap("regionMap");
					callFuncOnePara(obj,"NToGotoFrame",msg.mapData.str);
				}else{
					flag = true;
				}						
			},
			error:function(msg){
				//alert('error'+msg)
			}
		});
	}
}
function updateScreenStatus(obj,screenNo,status){
	if(obj != null && obj != undefined){
		obj.TGotoFrame(screenNo, status);
	}		
}

//求百分比
function getBiLv(xiao,da){
	if(da==0&&xiao!=0){
		return '100%';
	}else if(da==0&&xiao==0){
		return '0%';
	}else{
		var s1 = parseInt(xiao);
		var s2 = parseInt(da);
		var temp = ((s1/s2)*100).toString();
		
		if(temp.length>5){
			var str = temp.substring(0,temp.indexOf(".") + 3)+"%";
			return str;
		}else{
			return temp+'%';
		}
	}
}
//变更选中颜色
function CommandSelectingBays(args){
	bays = args;
	if(bays.length >0)
	{
		var obj = getRegionMap("regionMap");
		obj.SetVariable("enableEdit","1");
						
		bays = bays.replace("<string>","").replace("</string>","");				
		var baysArr = bays.split(",");
		for(var i=0;i<baysArr.length;i++)
		{
			updateScreenStatus(obj,baysArr[i], 2);
		}
	}
}
/**
 * 获取object或embeds标签
 * @param mapName	标签id
 * @returns {String}
 */
function getRegionMap(mapName) 
{
	var obj = "";
	if (navigator.appName.indexOf("Microsoft Internet") == -1) {
		if (document.embeds && document.embeds[mapName])
			obj = document.embeds[mapName];
		}
	else {
			obj = document.getElementById(mapName);
		}
		return obj;
}

//缩放
function Zoom(percent){
	getRegionMap("regionMap").Zoom(percent);
}

function showMap(file,width,height){
	document.write("<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+ width +"' height='"+ height +"' id='regionMap' name='regionMap'>");
		document.write("<param name='allowScriptAccess' value='always' />");
		document.write("<param name='movie' value='"+ file +"'>");
		document.write("<param name='quality' value='high'>");
		document.write("<param name='allowFullScreen' value='true'>");
		document.write("<param name='wmode' value='transparent'>");
		document.write("<embed src='"+ file +"' quality='high' allowFullScreen='true' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+ width +"' height='"+ height +"' id='regionMap' name='regionMap'></embed></object>");
		
      document.getElementById("regionMap").movie=encodeURI(file);
	
}
function setup(){
	//wopen("../base_info/flash_setup.action","_blank",458,248);
//	$('#window').window(options).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
//	or
//	$('#dailog').dailog(options).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
	$.ajax({
		async:false,
		type:'post',
		dataType:'json',
		url:'../base_info/flash_setup.action',
		data:{},
		success:function(msg){
			$('#timeToCount').val(msg.timeToCount);
			$('#timeOut').val(msg.timeOut);
			$('#t2').val(msg.timeOut);
			$('#t1').val(msg.timeToCount);
			try{
				$s_dialog = $('#s_dialog');
				$s_dialog.dialog('open');
			}catch(e){
				$s_dialog.dialog({
					width:500,
					height:250,
					left:'30%',
					top:'20%'
				}).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
			}
			$('#s_table').show();
		},
		error:function(){
			
		}
	});
}

//Start展示图例==========================================
function showExample(){
	try{
		$pic_dialog = $('#pic_dialog');
		$pic_dialog.dialog('open');
	}catch(e){
		$pic_dialog.dialog({
			width:500,
			height:250,
			left:'30%',
			top:'20%'
		}).data().window.shadow.append('<iframe width="100%" height="100%" frameborder="0" scrolling="no"></iframe>');
	}
	$('#pic_table').show();
}
//End展示图例==========================================

function onChange(args){
	//alert(args.value);
	if(1==flag)
		{
		location='../mapmonitor/monitor_main.action?map_id='+args.value+'&flag=1';
		}
	else
		{
		location='../mapmonitor/monitor_main.action?map_id='+args.value;
		}
}

	
//生成预览内容
function setPreview(str,screen_width){

	makeSFormatArray(str);
	//alert(str+"****"+screen_width+"*****"+sFormatArray.length);
	//document.getElementById("contentFormat").value = sFormatArray.join("");
	var contentFormat = "";
	var flag = false;
	if(sFormatArray.length==0){
		contentFormat+="<div style='width:"+screen_width+"px;background-color:black;height:18px;font-size:16px;overflow:hidden;'>&nbsp;</div>";
	}else{
		//alert(screen_width+"px");
		contentFormat += "<div style='width:"+screen_width+"px;background-color:black;height:18px;font-size:16px;overflow:hidden;'>";
		for(var i = 0; i < sFormatArray.length; i++){
			if(sFormatArray[i].indexOf("\\R") != -1 || sFormatArray[i].indexOf("\\Y") != -1 || sFormatArray[i].indexOf("\\G") != -1){
				if(flag){
					contentFormat += "</font>";
					flag = false;
				}
				var color = sFormatArray[i] == "\\R" ? "red" : (sFormatArray[i] == "\\Y" ? "yellow" : "green");
				contentFormat += "<font color='" + color + "' >";
				flag = true;
			}  
			else {
				contentFormat += sFormatArray[i];
			}
		}
	}
	if(flag){
		contentFormat += "</font>";
	}
	return contentFormat;
}

//由引导屏显示内容分解出sFormatArray数组
function makeSFormatArray(str){
	sFormatArray = new Array();
	//var contentFormat = document.getElementById("contentFormat").value;
	var contentFormat = str;
	var content = "";
	while(contentFormat != ""){
		if(contentFormat.indexOf("\\R") == 0){
			if(content != ""){
				sFormatArray.push(content);
				content = "";
			}
			sFormatArray.push("\\R");
			contentFormat = contentFormat.substring("\\R".length);
		} else if(contentFormat.indexOf("\\Y") == 0){
			if(content != ""){
				sFormatArray.push(content);
				content = "";
			}
			sFormatArray.push("\\Y");
			contentFormat = contentFormat.substring("\\Y".length);
		} else if(contentFormat.indexOf("\\G") == 0){
			if(content != ""){
				sFormatArray.push(content);
				content = "";
			}
			sFormatArray.push("\\G");
			contentFormat = contentFormat.substring("\\G".length);
		} else if(contentFormat.indexOf("[") == 0 && contentFormat.indexOf("]") != -1){
			if(content != ""){
				sFormatArray.push(content);
				content = "";
			}
			sFormatArray.push(contentFormat.substring(0,contentFormat.indexOf("]") + 1));
			contentFormat = contentFormat.substring(contentFormat.indexOf("]") + 1);
		} else {
			content += contentFormat.substring(0,1);
			contentFormat = contentFormat.substring(1);
		} 
	}
	if(content != ""){
		//alert(content+"********"+contentFormat);
		sFormatArray.push(content);
	}
}
function change_little(text_self){
	var val = text_self.value.replace(/[^\d]/g,'');
	if(val=='')
		$('#little').val(val);
	$('#t1').val(text_self.value);
}
function change_old(text_self){
	var val = text_self.value.replace(/[^\d]/g,'');
	if(val=='')
		$('#old').val(val);
	$('#t2').val(text_self.value);
}
function save_setup(){
	var timeOutValue = $('#timeOut').val();
	var timeToCountValue = $('#timeToCount').val();
	if(!checkNum(timeOutValue)){
		alert(timeOutValue+$('#alert_data_format_error').val());
		return;
	}
	if(!checkNum(timeToCountValue)){
		alert(timeToCountValue+$('#alert_data_format_error').val());
		return;
	}if(parseFloat(timeOutValue) <= parseFloat(timeToCountValue)){
		alert($('#alert_timeout_timetocount_mess').val());
		return;
	}
	//var bool_ = document.getElementById('useColor').checked;
	
	$.ajax({
	    async: false,
		type: "POST",
		dataType: "json",
		url:"../base_info/base_setup.action",
		data:{
			"data.timeOut":$('#timeOut').val(),
			"data.timeToCount":$('#timeToCount').val()
			
		},
		success: function(msg){
			if(msg.success){
				alert($('#process_success').val());
			}						
		}
	});
}
//“返回”按钮功能
function back_(){
	$('#s_dialog').dialog('close');
	}
function showMark(code,mark){
	getRegionMap("regionMap").CallFunction("<invoke name=\"SetGroupNo\" returntype=\"xml\">" +
			"<arguments><string>"+ code +"</string><string>"+ mark +"</string></arguments></invoke>");
}

/**
 * 地磁视频配置保存
 */
function video_save(){
	//Monitor1===================================================
	var ipaddress = trim($('#ipadress').val());
	var port = trim($('#portnum').val());
	var username = trim($('#username').val());
	var password = trim($('#password').val());
	if(ipaddress == '' || ipaddress == null){
		alert($('#ip_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
	if(port == '' || port == null){
		alert( $('#port_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
	if(username == '' || username == null){
		alert($('#username_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
//	if(password == '' || password == null){
//		alert($('#password_lbl').html() + $('#alert_is_not_null').val());
//		return;
//	}
	var url = "http://"+ipaddress;
	//Monitor1===================================================
	//Monitor2===================================================
	var ipaddress_second = trim($('#ipadress_second').val());
	var port_second = trim($('#portnum_second').val());
	var username_second = trim($('#username_second').val());
	var password_second = trim($('#password_second').val());
	if(ipaddress_second == '' || ipaddress_second == null){
		alert($('#ip_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
	if(port_second == '' || port_second == null){
		alert( $('#port_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
	if(username_second == '' || username_second == null){
		alert($('#username_lbl').html() + $('#alert_is_not_null').val());
		return;
	}
//	if(password_second == '' || password_second == null){
//		alert($('#password_lbl').html() + $('#alert_is_not_null').val());
//		return;
//	}
	var url_second = "http://" + ipaddress_second;
	//Monitor2===================================================
	
	var monitor = ipaddress + "," + port + "," + username + "," + (password == "" ? "nana" : password) + "," + 
		ipaddress_second + "," + port_second + "," + username_second + "," + (password_second == "" ? "nana" : password_second);
	//传到后台写到配置文件里去
	$.getJSON("../mapmonitor/insertMonitorXml.action?random=" + new Date().getTime() + Math.random(), {"monitor" : monitor}, function(data){});
	
	if (navigator.appName.indexOf("Microsoft Internet Explorer") != -1)
	{
		var streamnum = DHiMPlayer.GetStreamNum();
		var setvalue = DHiMPlayer.SetUrl(url,port,streamnum,username,password);
		var playvalue = DHiMPlayer.GetPlayState();
		
		var streamnum_second = DHiMPlayerSecond.GetStreamNum();
		var setvalue_second = DHiMPlayerSecond.SetUrl(url_second,port_second,streamnum_second,username_second,password_second);
		var playvalue_second = DHiMPlayerSecond.GetPlayState();
		
		var value = DHiMPlayer.Play();
		var values = DHiMPlayerSecond.Play();
	}
	else
	{
		$('#mydisplay').html('');
		w=parseInt(350);
		h=parseInt(240);
		rtsp=url + ":" + port + "/web/11?" + username + ":" + password + "&";
		data='<embed src='+rtsp+' width='+w+' height='+h+' autoplay="true" controller="true" ShowStatusBar="false" type="video/quicktime"';
		data=data+' pluginspage="http://www.apple.com/quicktime/download/index.html"> </embed>';
		$('#mydisplay').append(data);
		
		rtsp = url_second + ":" + port_second + "/web/11?" + username_second + ":" + password_second + "&";
		data='<embed src='+rtsp+' width='+w+' height='+h+' autoplay="true" controller="true" ShowStatusBar="false" type="video/quicktime"';
		data=data+' pluginspage="http://www.apple.com/quicktime/download/index.html"> </embed>';
		$('#mydisplay').append(data);
	}
	
	$('#l_config').panel('collapse');
	$('#mydisplay').panel('expand');
}

function video_reset(){
	$('#ipadress').val('');
	$('#portnum').val('');
	$('#username').val('');
	$('#password').val('');
	$('#ipadress_second').val('');
	$('#portnum_second').val('');
	$('#username_second').val('');
	$('#password_second').val('');
	var stopvalue = DHiMPlayer.Stop();
	var stopvalue = DHiMPlayerSecond.Stop();
}