function nextStep(){
	$("#step").val($("#step").val() - 0 + 1);
	$("#config_guide").attr("action", "../config_guide/config_guide.action").submit();
}
function prevStep(){
	$("#step").val($("#step").val() - 1);
	$("#config_guide").attr("action", "../config_guide/config_guide.action").submit();
}
function autoheight(){
	var height = document.documentElement.offsetHeight;
	height=height-50;
	document.getElementById("mainFrame").style.height=height + "px";
//	document.getElementById("mainFrame").src=document.getElementById("frameSrc").value;
//	setTimeout(setChildHeight,3000);
}
function setChildHeight(obj){
	if(obj.document.getElementById("right1")){
		//alert(obj.document.getElementById("right1").clientHeight);
		obj.document.getElementById("right1").style.height = (obj.document.getElementById("right1").clientHeight + 100) + "px";
	}
}
