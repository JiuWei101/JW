function operate(str,id){
	if(str=="edit"){ 
    	if(!checkOne()){//请单选编辑
    		return;
    	}
    	wopen("../line_config/line_edit.action?data.id="+getCheckChkValue(),"_blank",800,480);
	}else if(str=="create"){ 
        	wopen("../line_config/line_create.action","_blank",800,480);   	
    }else if(str=="alledit"){ 
    	wopen("../line_config/line_alledit.action","_blank",800,480);   
    }else if(str=="setdef"){
    	$("#boardNo").val("0");
    	$("#port").val("0");
    	$("#stationAddr").val("1");
    	var brlist = document.getElementById("data.baudRate");
    	brlist.value="500K";
    	$("#mask").val("255");
    }else if(str=="list"){ 
    	document.listform.action = "../line_config/line_list.action";
		document.listform.submit();
    }else if(str=="back"){
		winClose();
    }else if(str=="delete"){
    	
    	if(!checkChk()){
    		alert($("#alert_please_select_a_record").val());	//请先进行选择
    		return;
    	}
    	
    	var rs=window.confirm($("#alert_delete").val());	//你确定删除此记录吗
    	
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../line_config/line_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					}else{
						alert(msg.ex);
					}
				},
				error:function(msg){
					alert('error:'+msg);
				}
			});
	    }
	}else if(str=="save"){
		var ip = trim($("#ip").val());//去除所有空格并重新赋值
		$("#ip").val(ip);
		if(document.getElementById("ip").value==""){
			alert($("#alert_please_input_a_lineaddress").val());
			return;
		}
		
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../line_config/line_save.action",
			data: $("#line_create").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					window.close();
				}else{
					alert($('#alert_line_already_exists').val());
					return;
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
	}else if(str=="update"){
		var ip = trim($("#ip").val());//去除所有空格并重新赋值
		$("#ip").val(ip);
		if(document.getElementById("ip").value==""){
			alert($("#alert_please_input_a_lineaddress").val());
			return;
		}
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../line_config/line_update.action",
				data: $("#line_edit").formSerialize(),
				success: function(msg){
					if(msg.success){
						window.opener.operate('list');
						winClose();
					}else{
						alert(msg.ex);
					}
				},
				error:function(msg){
					alert(msg.ex);
				}
			});
	}else if(str=="allupdate"){
	
	$.ajax({
	    async: false,
		type: "POST",
		dataType: "json",
		url: "../line_config/line_allupdate.action",
		data: $("#line_alledit").formSerialize(),
		success: function(msg){
			if(msg.success){
				window.opener.operate('list');
				window.close();
			}else{
				alert($("#alert_line_to_be_allocated_cant_disable").val());
				window.opener.operate('list');
				window.close();
			}
		},
		error:function(msg){
			alert('error'+msg);
		}
	});
	}
}
