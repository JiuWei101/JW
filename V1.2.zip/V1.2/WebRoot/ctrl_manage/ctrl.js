
var http_request;
//mothod 请求类型，url请求路径，content发送参数，fName页面里的属性名
function send_request(method,url,content,fName){
     if(window.XMLHttpRequest){
	    http_request= new XMLHttpRequest();
		if(http_request.overrideMimeType){
		   http_request.overrideMimeType("text/xml");}
	 }else if(window.ActiveXObject){
	    try{
		   http_request=new ActiveXObject("Msxml12.XMLHTTP");
		}catch(e){
		   try{
		      http_request=new ActiveXObject("Microsoft.XMLHTTP");
		   }catch(e){}
		}
	 }else{
	    alert("浏览器没有实现XMLHttpRequest组件对象"); 
	 }
	 if(!http_request){
	    alert("创建对象实例失败");
		return;
	 }
	 if(fName!=""){
	     http_request.onreadystatechange=function(){
     		if(http_request.readyState==4){    	
			    if(http_request.status==200){
			       	var resText=http_request.responseText;
	    			var resXml=http_request.responseXML;;//从服务器获得
			       	responseMethod(resText,fName);
				}
			 }   
		   };
	 }else{
	     alert("相应类别参数错误");
		 return;
	 }
	 if(method.toLowerCase()=="get"){
	     http_request.open(method,url,false);
	 }else if(method.toLowerCase()=="post"){
	     http_request.open(method,url,false);
		 http_request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	 }else{
	    alert("http请求类别参数错误");
		return;
	 }
     http_request.send(content);
 }

function operate(str,id){
    if(str=="create"){
    	wopen("../user/user_create.action","_blank",800,480);
    }else if(str=="delete"){
    	var rs=window.confirm("您确定要删除此记录吗？");
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../user/user_delete.action",
				data: {'user.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	wopen("../user/user_edit.action?id="+getCheckChkValue(),"_blank",800,480);   	
    }else if(str=="list"){ 
    	document.listform.action = "../user/user_list.action";
		document.listform.submit();
    }else if(str=="read"){ 
    	wopen("../user/user_read.action?id="+getCheckChkValue(),"_blank",600,400);
    }else if(str=="invalid"){ 
    	document.listform.id.value = id;
    	document.listform.action = "../user/user_invalid.action";
		document.listform.submit();
    }else if(str=="valid"){ 
    	document.listform.id.value = id;
    	document.listform.action = "../user/user_valid.action";
		document.listform.submit();
    }else if(str=="back"){
		window.close();
	}else if(str=="save"){
 		if(document.user_create.user_name.value == ''){
 			alert("用户名不能为空！");
 			return;
 		}
 		if(document.user_create.password.value == ''){
 			alert("密码不能为空！");
 			return;
 		}
		if(document.user_create.password.value != document.user_create.qr_password.value){
 			alert("确认密码与密码不一致！");
 			return;
 		}
 		if(document.getElementsByName("user.state")[0].checked == document.getElementsByName("user.state")[1].checked){
 			alert("用户状态不能为空！");
 			return;
 		}
 		//alert($("#user_create").formSerialize())
 		var flag = false;
 		$.ajax({
		    async: false,
			type: "POST",
			url: "../user/user_check.action",
			data: encodeURI(encodeURI("user_name="+$("#user_name").val())),
			success: function(msg){
				if(msg=="yes"){
					alert("此用户名称已存在！");
				}else{
					flag = true;
				}						
			}
		});
	
		if(flag){
   			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../user/user_save.action",
				data: $("#user_create").formSerialize(),
				success: function(msg){
					if(msg.success){
						window.opener.operate('list');
						window.close();
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
    	}
 	}else if(str=="update"){
   		if(document.user_edit.user_name.value == ''){
   			alert("用户名不能为空！");
   			return;
   		}
		if(document.user_edit.password.value != document.user_edit.qr_password.value){
   			alert("确认密码与密码不一致！");
   			return;
   		}
   		if(document.getElementsByName("user.state")[0].checked == document.getElementsByName("user.state")[1].checked){
   			alert("用户状态不能为空！");
   			return;
   		}
   		
   		var flag = false;
   		
   		$.ajax({
		    async: false,
			type: "POST",
			url: "../user/user_check.action",
			data: encodeURI(encodeURI("user_name="+$("#user_name").val()))+"&id="+$("#id").val(),
			success: function(msg){
				if(msg=="yes"){
					alert("此用户名称已存在！");
				}else{
					flag = true;
				}						
			}
		});
   		
   		if(flag){
   			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../user/user_update.action",
				data: $("#user_edit").formSerialize(),
				success: function(msg){
					if(msg.success){
						window.opener.operate('list');
						window.close();
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
    	}
   	}
}