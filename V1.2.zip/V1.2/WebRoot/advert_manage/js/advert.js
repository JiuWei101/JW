var ALLOWEDTYPE = ".png,.bmp,.pjpeg,.jpg,.jpeg,.swf,.gif";	// 允许上传的类型

//更新广告是否启用 解决IE问题
function checkBoxClick($this){
	var $id = $($this).val();
	var $checked = $($this).is(':checked');
	var $inuse = $checked ? 1 : 0;
	$.getJSON(
		"advert/modifyAdvert.action?random=" + new Date().getTime() + Math.random(),
		{"advert.advertId" : $id, "advert.inuse" : $inuse},
		function(data){
		}
	);
}

/**
 * 修改广告的播放时间
 * @param $this	
 * @param id
 */
function modifyPlayTime(index, position){
	var playTimeText, id, statusImg;
	if(position == '0'){		//寻车首页的广告
		playTimeText = "adPlayTime_" + index;
		id = "adId_" + index;
		statusImg = "statusImg_" + index;
	} else if (position == '1'){		//查询页下方的广告
		playTimeText = "adPlayTime1_" + index;
		id = "adId1_" + index;;
		statusImg = "statusImg1_" + index;
	}	
	var $playTime = $("#" + playTimeText);
	var $id = $("#" + id);
	var $statusImg = $("#" + statusImg);
	if(!checkNumber($playTime.val())){		//校验
//		alert($("#checkNumber").val());
		return false;
	}
	if($playTime.val() < 0 || $playTime.val() > 600){
//		alert($("#checkValLimit").val();
		alert("输入的时间大小必须在[0-600]秒之间");
		return false;
	}
	$.getJSON(
		"advert/modifyPlayTime.action?random=" + new Date().getTime() + Math.random(),
		{"advert.advertId" : $id.val(), "advert.playTime" : $playTime.val()},
		function(data){
			if(data.flag){
				$playTime.removeClass("playTimeChange");		//去掉输入框的样式
				$statusImg.attr("src", "./images/start.png").fadeIn(500);
				setTimeout(function(){
					$statusImg.fadeOut(500);
				}, 1500);
			} else{
				$statusImg.attr("src", "./images/stop.png").fadeIn(500);
				setTimeout(function(){
					$statusImg.fadeOut(500);
				}, 1500);
			}
		}
	);
}

/**
 * 点击广告名称查看广告
 * @param $this
 * @param position
 */
function viewClick($this, position){
	var i, src, type, padding = '0px';
	if(position == '0'){
		i = $("td.viewDetail").index($this);	
		src = "adSrc_" + i;
		type = "adType_" + i;
	} else if (position == '1'){
		i = $("td.viewDetail1").index($this);
		src = "adSrc1_" + i;
		type = "adType1_" + i;
		padding = '10%';
	}
	var $src = $("#" + src);
	var $type = $("#" + type);
	var $img = $("#popDiv img");
	$("#playerIE").remove();
	$("#image").remove();
	if($type.val() == 'application/x-shockwave-flash'){
		var $object = "<object id='playerIE' classid='CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95'" +
		" codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,0,02,902'" +
		" standby='Loading Microsoft Windows Media Player...' type='application/x-oleobject' width='800px' height='570px'>" +
		"<param name='FileName' value='" + $src.val() + "' />" + 
	    "<param name='showControls' value='false'>" +
		"<embed id='playerFF' src='" + $src.val() + "' width='800px' height='570px' " +
		"type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer'>" +
		"</embed></object>";
		$("#popDiv").html($object);
	} else{
		var $img = "<img id='image' alt='' src='" + $src.val() + "'width='50%' height='auto' style='padding-top: " + padding + "'>";
		$("#popDiv").html($img);
	}
	showDiv();
}

/******Start遮罩层*********************************************************/	
function showDiv(){
	$("#fg").fadeIn();
	$("#popDiv").fadeIn();
	$("#popIframe").fadeIn();
	$("#bg").fadeIn();
}

function closeDiv(){
	$("#fg").fadeOut();
	$("#popDiv").fadeOut();
	$("#popIframe").fadeOut();
	$("#bg").fadeOut();
}
/******End遮罩层*********************************************************/

$(function(){
	if($("#isTextType").val() == '1'){
		$("#alink1").removeClass("clicked");
		$("#alink2").addClass("clicked");
		$("#right1").hide();
		$("#right2").show();
	}
	
	$("#popDiv, #bg, #fg").click(function(){
		closeDiv();
	});
	/******End遮罩层*********************************************************/
}); 
	
function operate(str, id) {
	if (str == "list") {
		$("#qaf").submit();
	} else if(str == 'listText'){
		$("#qafText").submit();
	} else if (str == "save") {			//保存图片等广告
		var $filepath = $("#f").val(); 
        var extStart = $filepath.lastIndexOf(".");
        var ext = $filepath.substring(extStart, $filepath.length).toLowerCase();
        var $allowTypes = new Array();
        $allowTypes = ALLOWEDTYPE.split(",");
        var flag = false;
        for(var i = 0; i < $allowTypes.length; i++){		//校验上传文件的类型
        	if(ext == $allowTypes[i]){
        		flag = true;
        	}
        }
        if(!flag){
        	alert($("#notallowtype").html());
        	return false;
        } else{
			$.ajaxFileUpload({
				url : "./advert/insertAdvert.action?random=" + new Date().getTime() + Math.random(),//用于文件上传的服务器端请求地址  
				secureuri : false,//一般设置为false  
				fileElementId : 'f',//文件上传空间的id属性  <input type="file" id="file" name="file" />  
				dataType : 'json',//返回值类型 一般设置为json  
				data: {"advert.advertPosition":"0"},		//1表示
				success : function(data, status) //服务器成功响应处理函数  
				{
					if (data.success) {
						window.operate('list');
						winClose();
					} else {
						
					}
				},
				error : function(data, status, e)//服务器响应失败处理函数  
				{
					alert(e);
				}
			});
		}
	} else if(str == "savePosition1"){		//保存文本广告
		//===================================================
		var $filepath = $("#fp1").val(); 
        var extStart = $filepath.lastIndexOf(".");
        var ext = $filepath.substring(extStart, $filepath.length).toLowerCase();
        var $allowTypes = new Array();
        $allowTypes = ALLOWEDTYPE.split(",");
        var flag = false;
        for(var i = 0; i < $allowTypes.length; i++){		//校验上传文件的类型
        	if(ext == $allowTypes[i]){
        		flag = true;
        	}
        }
        if(!flag){
        	alert($("#notallowtype").html());
        	return false;
        } else{
			$.ajaxFileUpload({
				url : "./advert/insertAdvert.action?random=" + new Date().getTime() + Math.random(),//用于文件上传的服务器端请求地址  
				secureuri : false,//一般设置为false  
				fileElementId : 'fp1',//文件上传空间的id属性  <input type="file" id="file" name="file" />  
				dataType : 'json',//返回值类型 一般设置为json  
				data: {"advert.advertPosition":"1"},		//1表示
				success : function(data, status) //服务器成功响应处理函数  
				{
					if (data.success) {
						window.operate('listText');
						winClose();
					} else {
						
					}
				},
				error : function(data, status, e)//服务器响应失败处理函数  
				{
					alert(e);
				}
			});
		}
	}
}

//显示选定的界面
function show(showId, hiddenId){
	if(showId == 'right2'){
		$("#qafText").submit();
	} else{
		$("#qaf").submit();
	}
}

/**
 * 当广告播放时间的输入框改变时的事件
 * @param $this
 */
function playTimeChange($this){
	$($this).addClass("playTimeChange");
}