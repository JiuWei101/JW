function operate(str,id){
    if(str=="reset"){//
    	$("#name").val('');
    	$("#person").val('');
    	$("#telephone").val('');
    	$("#addr").val('');
		$("#timeOut").val('');
	}else if(str=="save"){
		var name = trim($("#name").val());//去除所有空格并重新赋值
		$("#name").val(name);
		var person = trim($("#person").val());//去除所有空格并重新赋值
		$("#person").val(person);
		var addr = trim($("#addr").val());//去除所有空格并重新赋值
		$("#addr").val(addr);
		if($("#name").val() == ""){
			alert($("#alert_parking_name").val() + $("#alert_is_not_null").val());
			return;
		};
		if(!fIsPhone($("#telephone").val()) && !fIsMobile($("#telephone").val()) && $("#telephone").val() != ""){
			alert($("#telPhone").val() + $("#alert_field_format_error").val());
			return;
		}
		if($("#spacingInterval").val() == ""){
			alert($("#alert_spacing_interval").val() + $("#alert_is_not_null").val());
			return;
		}
		if(!isInt($("#spacingInterval").val())){
			alert($("#alert_spacing_interval").val() + $("#alert_only_number").val());
			return;
		}
		if($("#refreshTime").val() == ""){
			alert($("#alert_refresh_time").val() + $("#alert_is_not_null").val());
			return;
		}
		if(!isInt($("#refreshTime").val())){
			alert($("#alert_refresh_time").val() + $("#alert_only_number").val());
			return;
			}
		if($("#faultJudgmentInterval").val() == ""){
			alert($("#alert_fault_judgment_interval").val() + $("#alert_is_not_null").val());
			return;
		}
		if(!isInt($("#faultJudgmentInterval").val())){
			alert($("#alert_fault_judgment_interval").val() + $("#alert_only_number").val());
			return;
		}
		if($("#faultJudgmentNum").val() == ""){
			alert($("#alert_fault_judgment_num").val() + $("#alert_is_not_null").val());
			return;
		}
		if(!isInt($("#faultJudgmentNum").val())){
			alert($("#alert_fault_judgment_num").val() + $("#alert_only_number").val());
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../base_info/base_save.action",
			data: $("#base_create").formSerialize(),
			success: function(msg){
				if(msg.success){
					alert($("#process_success").val());	//操作成功
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
	}
}