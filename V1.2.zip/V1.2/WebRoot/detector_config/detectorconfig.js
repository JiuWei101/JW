function operate(str,id){
	if(str=="create"){
    	wopen("../detector_config/detector_create.action","_blank",800,480);
	}else if(str=="edit"){
    	if(!checkChk()){
    		alert($("#alert_please_select_a_record").val());	//请先进行选择
    		return;
    	}
    	var ids = getCheckChkValue();
    	if(ids.indexOf(";") == -1){
    		wopen("../detector_config/detector_edit.action?data.id="+ids,"_blank",800,480);
    	} else {
    		wopen("../detector_config/detector_alledit.action?type=batch&data.id="+ids,"_blank",800,480);
    	}
    }else if(str=="alledit"){
    	wopen("../detector_config/detector_alledit.action?type=all","_blank",800,480);   	
    }else if(str=="list"){
    	document.listform.action = "../detector_config/detector_list.action";
		document.listform.submit();
    }else if(str=="back"){
		winClose();
    }else if(str=="delete"){
    	if(!checkChk()){
    		alert($("#alert_please_select_a_record").val());	//请先进行选择
    		return;
    	}
    	var rs=window.confirm($("#alert_delete").val());	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../detector_config/detector_delete.action",
				data: {'data.id':getCheckChkValue("chk_record"),
					   'data.mapId':getmapId()
					},
				success: function(msg){
					if(msg.success){
						operate('list');
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
	}else if(str=="update"){
			
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../detector_config/detector_update.action",
				data: $("#detector_edit").formSerialize(),
				success: function(msg){
					if(msg.success){
						window.opener.operate('list');
						window.close();
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	}else if(str=="allupdate"){
		if(!getSelectChk()){
			alert($("#alert_please_check_the_box_to_confirm").val());
			return;
		}
// 		if(getCheckChkValue("field") == ""){
// 			alert(document.getElementById("modify_content").value + $("#alert_is_not_null").val());
// 			return;
// 		}   //不知道在判断什么
	
	$.ajax({
	    async: false,
		type: "POST",
		dataType: "json",
		url: "../detector_config/detector_allupdate.action",
		data: $("#detector_alledit").formSerialize(),
		success: function(msg){
			if(msg.success){
				window.opener.operate('list');
				window.close();
			}
		},
		error:function(msg){
			alert('error'+msg);
		}
	});
	}else if(str=="detector_add"){
		if (getFieldValue('mapList') == '') {//选择地图不能为空
			var alertmess = getFieldValue("mapName_list") + getFieldValue("alert_is_not_null");
			alert(alertmess);
			return;
		}
		if (getFieldValue('myFile') == '') {//更新地图不能为空
			alert(getFieldValue("myFile_text") + getFieldValue("alert_is_not_null"));
			return;
		}
//		if(testsuffix(getFieldValue('myFile'))==false)//判断文件后缀名
//			{
//			alert(getFieldValue("alert_map_file_is_not_correct"));
//			return;
//			}
		$.ajaxFileUpload({
			url : '../detector_config/detector_add.action',//用于文件上传的服务器端请求地址  
			secureuri : false,//一般设置为false  
			fileElementId : 'myFile',//文件上传空间的id属性  <input type="file" id="file" name="file" />  
			dataType : 'JSON',//返回值类型 一般设置为json  
			data : {
				'data.id' : $("#mapId").val()
			},
			success : function(data, status){ //服务器成功响应处理函数  
				if (data.success == true) {
						alert($("#process_success").val());
						wopen("../detector_config/detector_import.action?map_id=" + id, "_self",
								screen.availWidth / 3 * 2, screen.availHeight / 3 * 2);
				}else{
						if(data.message!=''){
							alert($("#alert_map_already_exists").val());
						}else{
							alert(data.ex);
						}
						return;
					 }
			},
			error : function(data, status, e)//服务器响应失败处理函数  
			{
				alert(e);
			}
		});
	
	}else if(str=='detector_insert'){
		try {
			getFlashEqNo();
		} catch (e) {
			alert(getFieldValue("alert_map_file_is_not_correct"));
			return;
		}
		var dbays = verifybays(getFlashEqNo());
		var sbays = verifybays(getFlashScreenNo());
		if(dbays!="" && sbays!=""){
			alert("探测器："+ dbays +"重复" + "</br>" + "引导屏："+sbays+"重复");
			return;
		}
		if(dbays!=""){
			alert("探测器："+ dbays +"重复" );
			return;
		}
		if(sbays!=""){
			alert("引导屏："+sbays+"重复");
			return;
		}
		//执行探测器插入方法
		$.ajax({
			async : false,
			type : "POST",
			dataType : "json",
			timeout : 30000,
			url : "../detector_config/detector_insert.action",
			data : {
				'data.mapId' : $('#mapId').val(),
				'data.imp_data_de' :  getFlashEqNo(),
				'data.imp_data_sc' :  getFlashScreenNo()
			},
			success : function(msg) {//返回数据验证结果
				if (msg.success) {//打印数据验证结果
					alert($("#process_success").val());
					if(msg.result != ""){
						alert(msg.result);
					}
					if (msg.message) { //message为false 说明注册已过期
						//TODO
					}
				} else {
					if(msg.ex != ""){
						alert(msg.ex);
						return;
					}else{
						alert($("#alert_map_file_is_not_correct").val());
						return;
					}
				}
			},
			error : function(msg) {
				alert('error' + msg);
				return;
			}
		});
		window.close();
		window.opener.operate('list');
	}
}
function getSelectChk()
{
	var field_code =  new Array("enable");
	for(var i=0;i<field_code.length;i++){
		if(document.getElementsByName("data.field")[i].checked){
			return true;			
		}
	}
	return false;
}

function checkNumber(value,e)
{
    var key = window.event?e.keyCode:e.which;  
    if( (key > 95 && key < 106) ||  
        (key > 47 && key < 60) ||  
        (key == 110 && value.indexOf(".") < 0 )||  
        (key == 190 && value.indexOf(".") < 0 )){  
    }else if(key !=8){
        if (window.event) //IE  
        {  
            e.returnValue = false;   //event.returnValue=false 效果相同.  
        }  
        else //Firefox  
        {  
            e.preventDefault();  
        }  
    }
}

function onChange(args){
	//alert(args.value);
	if(args.value==""){
		location='../detector_config/detector_create.action';
	}else{
		location='../detector_config/map_show.action?map_id='+args.value;
	}
}

function showMap(file, width, height) {
	document.write("<object  classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"
					+ width
					+ "' height='"
					+ height
					+ "' id='regionMap' name='regionMap'>");
	document.write("<param name='allowScriptAccess' value='always' />");
	document.write("<param name='movie' value='" + file + "'>");
	document.write("<param name='quality' value='high'>");
	document.write("<embed src='"
					+ file
					+ "' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"
					+ width + "' height='" + height
					+ "' id='regionMap' name='regionMap'></embed></object>");
	document.getElementById("regionMap").movie = encodeURI(file);
}

//获得所有超声波探测器信息
function getFlashEqNo() {
	var obj = getRegionMap("regionMap");//获取Object
	var bays = obj.CallFunction(
					"<invoke name=\"GetCarList\" returntype=\"xml\"><arguments></arguments></invoke>");
	if (bays.length > 0) {
		bays = bays.replace("<string>", "").replace("</string>", "");

		var baysArr = bays.split(",");
		for ( var i = 0; i < baysArr.length; i++) {
			updateBays(obj,baysArr[i], 9);
		}
	}
	return bays;
}

//获得所有引导屏信息
function getFlashScreenNo() {
	var obj = getRegionMap("regionMap");//获取Object
	var bays = obj.CallFunction("<invoke name=\"GetScreenList\" returntype=\"xml\"><arguments></arguments></invoke>");
	if (bays.length > 0) {
		bays = bays.replace("<string>", "").replace("</string>", "");

		var baysArr = bays.split(",");
		for ( var i = 0; i < baysArr.length; i++) {
			updateBays(obj,baysArr[i], 9);
		}
	}
	return bays;
}
//探头及引导屏编码查重
function verifybays(bays){
	var rbays = "";
	var args = bays.split(",");
	for(var i = 0; i < args.length; i++){//检测地图文件内部重复编码
		for(var j = i+1; j < args.length; j++){
			if(args[i] == args[j]){
				rbays = args[i] + ",";
			}
		}
	}
	if(rbays != ""){
		rbays = rbays.substring(0, rbays.length-1);
	}
	return rbays;
}

//根据选中的探测器记录，获取探测器所属的地图id
function getmapId(){
	var str = '';
	var arr = new Array();
	$('.checkbox').each(function(){
		if(this.checked == true){
			var mapId = $(this).next('input').val();
			if(arr.length != 0){
				var flag = 0;
				for(var i=0;i < arr.length; i++){
					if(arr[i] == mapId){
						flag = 1;
					}
				}
				if(flag == 0){
					arr.push(mapId);
				}
			}
			else{
				arr.push(mapId);
			}
		}
	});
	str = arr.join(";");
	return str;
}
