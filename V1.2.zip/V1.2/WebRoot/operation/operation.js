function operate(str,id,pid){
	if(str=="updata"){
		document.forms[0].id.value=id;
		document.forms[0].action="../maintain/operation_update.action?id="+id;
		document.forms[0].submit();
	  	self.parent.refresh();
   	}else if(str=="delete"){
   		var rs=window.confirm("您确实要删除吗？");
   		if(rs){
   			document.forms[0].id.value=id;
			document.forms[0].action="../maintain/operation_delete.action?id="+id;
			document.forms[0].submit();
			self.parent.refresh();
   		}
    }else if(str=="edit"){
	    document.forms[0].action="../maintain/operation_edit.action?id="+id;
	    document.forms[0].submit();  
    }else if(str=="add"){
    	document.forms[0].action="../maintain/operation_add.action";
    	document.forms[0].submit();
    }else if(str=="create"){
		document.forms[0].action="../maintain/operation_add.action?id="+id;
    	document.forms[0].submit();
    }
}
function operat(str,id){
	if(str=="save"){
		document.forms[0].action="../maintain/operation_save.action?parent_id="+id;
		document.forms[0].submit();
	    self.parent.refresh();

    }else if(str=="back"){
    	document.forms[0].action="../maintain/operation_edit.action?parent_id="+id;
    	document.forms[0].submit();
    }else if(str=="create"){
		document.forms[0].action="../maintain/operation_add.action?parent_id="+document.getElementById("parent_id").value;
    	document.forms[0].submit();
    }
}

