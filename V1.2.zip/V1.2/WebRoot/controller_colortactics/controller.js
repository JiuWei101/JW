function operate(str,id){
    if(str=="create"){
    	wopen("../controller_config/controller_create.action","_blank",800,480);
	}else if(str=="delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../controller_config/controller_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					} else {
						alert(msg.msg);
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var ids = getCheckChkValue();
    	if(ids.indexOf(";") == -1){
    		wopen("../controller_config/controller_edit.action?data.id="+ids,"_blank",800,480);
    	} else {
    		wopen("../controller_config/controller_multiedit.action?data.id="+ids,"_blank",800,480);
    	}
    }else if(str=="editall"){ 
    	wopen("../controller_config/controller_multiedit.action","_blank",800,480);
    }else if(str=="check_color_task"){ 
    	wopen("../controller_config/check_color_task.action","_blank",800,480);
	}else if(str=="config_task_delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 
    	var rst = window.confirm(document.getElementById("alert_will_delete_controller_settings").value);

    	if(rst){
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
			if(rs){
				$.ajax({
				    async: false,
					type: "POST",
					dataType: "json",
					url: "../controller_config/config_task_delete.action",
					data: {'data.id':getCheckChkValue("chk_record")},
					success: function(msg){
						if(msg.success){
					    	document.listform.start.value=1;
					    	document.listform.action = "../controller_config/config_task.action";
							document.listform.submit();
						} else {
							alert(msg.msg);
						}
					},
					error:function(msg){
						alert('error'+msg);
					}
				});
		    }
    	}
    	
    }else if(str=="config_history"){ 
    	wopen("../controller_config/config_history.action","_blank",800,480);
    }else if(str=="inifile"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	
    	var flag = false;
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/check_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(!msg.line){
					alert($('#alert_line_cant_for_empty').val());
					flag = true;
					return;
				}
				if(!msg.success){
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
					flag = true;
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
		if(flag){
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(msg.success){
					alert($('#alert_ini_file_task_established').val());  //下发配置文件提示信息 “任务建立成功”  add by shenlk 2012-08-03
				} else {
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }else if(str=="list"){ 
    	document.listform.start.value=1;
    	document.listform.action = "../controller_config/controller_list_for_color_tactics.action";
		document.listform.submit();
    }else if(str=="back"){
		winClose();
	}else if(str=="save"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_save.action",
			data: $("#controller_create").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($("#process_success").val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="update"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_update.action",
			data: $("#controller_edit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($('#alert_again_issued_config_file').val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="multiupdate"){
 		if(getCheckChkValue("field") == ""){
 			alert(document.getElementById("modify_content").value + document.getElementById("alert_is_not_null").value);
 			return;
 		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/controller_multiupdate.action",
			data: $("#controller_multiedit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($('#alert_again_issued_config_file').val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
		
   	}else if(str=="screen_list"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
//    	if(document.getElementById("red_count").value == ""){
//			alert($("#alert_red_count").val() + $("#alert_is_not_null").val());//红色临界不能为空。");
//			return;
//		}
// 		if(document.getElementById("yellow_percent").value == ""){
//			alert($("#alert_yellow_percent").val() + $("#alert_is_not_null").val());//黄色百分比临界不能为空。");
//			return;
//		}
 		wopen("../controller_config/colortactics_screen_list.action?data.id="+getCheckChkValue(),"_blank",800,480);
 		
    }else if(str=="create_color_task"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}else if(!verifyInputValues()){
    		alert($("#alert_red_count").val() + $("#alert_is_not_null").val());//红色临界不能为空。");
			return;
    	}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_config/create_color_task.action",
			data: {'data.id':$('#id').val(),
				   'data.field':getCheckedValues()},
			success: function(msg){
				if(msg.success){
					alert($('#alert_ini_file_task_established').val());  //下发配置文件提示信息 “任务建立成功”  add by shenlk 2012-08-03
				} else {
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }else if(str=="color_task_delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 
    	var rst = window.confirm(document.getElementById("alert_will_delete_controller_settings").value);

    	if(rst){
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
			if(rs){
				$.ajax({
				    async: false,
					type: "POST",
					dataType: "json",
					url: "../controller_config/color_task_delete.action",
					data: {'data.id':getCheckChkValue("chk_record")},
					success: function(msg){
						if(msg.success){
					    	document.listform.start.value=1;
					    	document.listform.action = "../controller_config/check_color_task.action";
							document.listform.submit();
						} else {
							alert(msg.msg);
						}
					},
					error:function(msg){
						alert('error'+msg);
					}
				});
		    }
    	}
    	
    }else if(str=="color_task_history"){ 
    	wopen("../controller_config/color_task_history.action","_blank",800,480);
    }
}
var field_code = new Array("lineId","port","status","notes");
function changeOptions(obj){
	for(var i = 0; i < field_code.length; i++){
		if(field_code[i] == obj.value){
			document.getElementById("div_" + field_code[i]).style.display = "block";
		} else {
			document.getElementById("div_" + field_code[i]).style.display = "none";
		}
	}
}
/**
 * 判断变红色临界值和变黄色临界百分比的输入值是否均为0或正整数
 * @returns {Boolean}
 */
function verifyInputValues(){
	var flag = true;
	$('.chkbox').each(function(){
		if(this.checked){
			var tds = $(this).parent('td').nextAll('td');
			var rvalue = tds.eq(3).children('input').val();
			var yvalue = tds.eq(4).children('input').val();
			if(testNaturalNum(rvalue) && testNaturalNum(yvalue)){
				flag = true;
			}else{
				flag = false;
			}
			
		}
	});
	return flag;
}
/**
 * 
 * @returns {String}
 */
function getCheckedValues(){
	var chks = $('.chkbox:checked');
	var rStr = "";
	chks.each(function(){
		var crtlid = $(this).val();
		var tds = $(this).parent('td').nextAll('td');
		var scode = tds.eq(2).html();
		var rvalue = tds.eq(3).children('input').val();
		var yvalue = tds.eq(4).children('input').val();
		rStr += crtlid+";"+scode+";"+rvalue+","+yvalue+"]";
	});
	if(rStr != ""){
		rStr = rStr.substring(0, rStr.length-1);
	}
	return rStr;
}
function testNaturalNum(num){
	var reg = /^\d+$/;
	return reg.test(num);
}
