
function operate(str,id){
	/*if(document.getElementsByName("statisticsData.s_type")[0].checked){//年
		if(document.getElementById("s_year").value == ''){
			alert(document.getElementById("alert_year").value);
			return;
 		}
	}*/
	//if(document.getElementsByName("statisticsData.s_type")[1].checked){//月
	if(document.getElementsByName("statisticsData.s_type")[0].checked){//月
		if(document.getElementById("s_year").value == ''){
			alert(document.getElementById("alert_year").value);
			return;
 		}
 		if(document.getElementById("s_month").value == ''){
 			alert(document.getElementById("alert_month").value);
 			return;
 		}
	}
	
	//if(document.getElementsByName("statisticsData.s_type")[2].checked){//日
	if(document.getElementsByName("statisticsData.s_type")[1].checked){//日
		if(document.getElementById("s_date").value == ''){
			alert(document.getElementById("alert_date").value );
			return;
 		}
	}
	
	if(list_type=="logical_used"){//显示停车占有率图表
    	document.listform.action = "../parking_statistics/logical_used_list.action?list_type="+list_type;
		document.listform.submit();
    }

	
	
	
}

	/**
	*Excel导出
	*/
	function exportToExcel(){
    	//wopen("../parking_statistics/export_excel.action?list_type="+list_type,"_blank",820,530);
    	document.listform.list_type.value="logical_used";
    	//document.listform.file_name.value=ptitle;
    	document.listform.action = "../parking_statistics/export_excel.action";
		document.listform.submit();
	}
	/**
	*打印
	*/
	function exportToPrint(){
    	wopen("../parking_statistics/export_print.action?list_type="+list_type,"_blank",840,530);
	}

/**
*显示和隐藏 年月日啥的
*/
function showOrHide(){
//	if(document.getElementsByName("statisticsData.s_type")[0].checked){//年
//		document.getElementById('div_sy').style.display="inline";
//		document.getElementById('div_sm').style.display="none";
//		document.getElementById('div_sd').style.display="none";
//		document.getElementById('query_btn').style.display="none";
//		ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_year").value+ps_type_year;// 停车场使用情况/使用率：2012
//	}
	//if(document.getElementsByName("statisticsData.s_type")[1].checked){//月
	if(document.getElementsByName("statisticsData.s_type")[0].checked){//月
		document.getElementById('div_sy').style.display="inline";
		document.getElementById('div_sm').style.display="inline";
		document.getElementById('div_sd').style.display="none";
		document.getElementById('query_btn').style.display="inline";
		ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_year").value+ps_type_year+document.getElementById("s_month").value+ps_type_month;
	}

	//if(document.getElementsByName("statisticsData.s_type")[2].checked){//日
	if(document.getElementsByName("statisticsData.s_type")[1].checked){//日
		document.getElementById('div_sy').style.display="none";
		document.getElementById('div_sm').style.display="none";
		document.getElementById('div_sd').style.display="inline";
		document.getElementById('s_date').style.readonly=true;
		console.log(document.getElementById('s_date'));
		document.getElementById('query_btn').style.display="inline";
		ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_date").value+ps_type_day;
	}
	
}
//级联
function nextLogic(phy){
	
	$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: '../parking_statistics/nextLogic.action',
			data: {
				phyId:phy.value
			},
			success: function(msg){
				if(msg.success){
					var arr = msg.list;
	            	$('#s_logic_id').empty();
	            	$('#s_logic_id').append("<option value=''>   </option>");  //添加一项option
	            	for(s in arr){
	            		if(arr[s].code_name!='undefined'&&arr[s].code_name!=undefined)
	            	    	$('#s_logic_id').append("<option value='"+arr[s].code_id+"'>"+arr[s].code_name+"</option>");  //添加一项option
	            	}
				}
				
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
}