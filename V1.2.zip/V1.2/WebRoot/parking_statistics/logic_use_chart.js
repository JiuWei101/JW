/**
 * 
 */
var store;
var strNow ='month';
var chart_graph,chart_histogram;

function open_flash_chart_data()
{
	var ofc_data;
	var year,month,date;
	
	year = document.getElementById("alert_year").value;
	month = document.getElementById("alert_month").value;
	day = document.getElementById("alert_date").value;
	
	if(strNow=='year'&&document.getElementById("s_year").value==''){
	 	alert(year);
	 	return;
	 }
	 if(strNow=='month'&&document.getElementById("s_month").value==''){
	 	alert(month);
	 	return;
	 }
	 
	 if(strNow=='day'&&document.getElementById("s_date").value==''){
	 	alert(day);
	 	return;
	 }
	 var s_year,s_date,s_month;
	 if(strNow=='month'){
	 	s_year = document.getElementById("s2_year").value;  //年
	 	s_date = '';    //日期 含年月日
	 }else if(strNow=='year'){
	 	s_year = document.getElementById("s_year").value;  //年
	 	s_date = '';    //日期 含年月日
	 }else{
	 	s_year = document.getElementById("s_year").value;  //年
	 	s_date = document.getElementById("s_date").value;    //日期 含年月日
	 }
	 s_month = document.getElementById("s_month").value;  //月
	 var chart_type;
	 if(document.getElementsByName("statisticsData.chart_type")[0].checked)//曲线
	 	chart_type = 'line';
	 else
	 	chart_type = 'bar';
//	 $.ajax({
//		    async: false,
//			type: "POST",
//			dataType: "json",
//			url: '../parking_statistics/logic_use_chart.action',
//			data: {
//				"statisticsData.s_logic_id":$("#s_logic_id").val(),
//				"statisticsData.s_physical_id":$("#s_physical_id").val(),
//				"statisticsData.s_spot_type":$("#s_spot_type").val(),
//				"statisticsData.s_month":s_month,
//				"statisticsData.s_year":s_year,
//				"statisticsData.s_type":strNow,
//				"statisticsData.s_date":s_date,
//				"statisticsData.s_b_date":s_date,
//				"statisticsData.chart_type":chart_type,
//				"statisticsData.s_e_date":s_date
//			},
//			success: function(msg){
//				var s = document.getElementById("PrintA");//alert(msg.toJSONString())
//				ofc_data = msg.toJSONString();
//				
//			},
//			error:function(msg){
//				var s = document.getElementById("PrintA");//alert(msg.toJSONString())
//				ofc_data = msg.responseText;
//				//s.load(ofc_data)
//			}
//		});
		dwr.engine.setAsync(false);
		ChartData.logic_use_chart($("#s_logic_id").val(),$("#s_physical_id").val(),$("#s_spot_type").val(),
				s_month,s_year,strNow,s_date,chart_type,
				function(json){
			ofc_data = json.toJSONString();
		});	
		return ofc_data;
}
function search(){
	 var year,month,date;
	
	year = document.getElementById("alert_year").value;
	month = document.getElementById("alert_month").value;
	day = document.getElementById("alert_date").value;
	
	if(strNow=='year' && document.getElementById("s_year").value==''){
	 	alert(year);
	 	return;
	 }
	 if(strNow=='month' && document.getElementById("s_month").value==''){
	 	alert(month);
	 	return;
	 }
	 
	 if(strNow=='day' && document.getElementById("s_date").value==''){
	 	alert(day);
	 	return;
	 }
	 
	 var s_year,s_date,s_month;
	 if(strNow=='month'){
	 	s_year = document.getElementById("s2_year").value;  //年
	 	s_date = '';    //日期 含年月日
	 }else if(strNow=='year'){
	 	s_year = document.getElementById("s_year").value;  //年
	 	s_date = '';    //日期 含年月日
	 }else{
	 	s_year = document.getElementById("s_year").value;  //年
	 	s_date = document.getElementById("s_date").value;    //日期 含年月日
	 }
	 s_month = document.getElementById("s_month").value;  //月
	 var chart_type;
	 if(document.getElementsByName("statisticsData.chart_type")[0].checked)//曲线
	 	chart_type = 'line';
	 else
	 	chart_type = 'bar';
//	 $.ajax({
//		    async: false,
//			type: "POST",
//			dataType: "json",
//			url: '../parking_statistics/logic_use_chart.action',
//			data: {
//				"statisticsData.s_physical_id":$("#s_physical_id").val(),
//				"statisticsData.s_logic_id":$("#s_logic_id").val(),
//				"statisticsData.s_spot_type":$("#s_spot_type").val(),
//				"statisticsData.s_month":s_month,
//				"statisticsData.s_year":s_year,
//				"statisticsData.s_type":strNow,
//				"statisticsData.s_date":s_date,
//				"statisticsData.s_b_date":s_date,
//				"statisticsData.chart_type":chart_type,
//				"statisticsData.s_e_date":s_date
//			},
//			success: function(msg){
//				var s = document.getElementById("PrintA");//alert(msg.toJSONString())
//				var ofc_data = msg.toJSONString();
//				s.load(ofc_data);
//			},
//			error:function(msg){
//				var s = document.getElementById("PrintA");//alert(msg.toJSONString())
//				ofc_data = msg.responseText;
//				s.load(ofc_data);
//				
//			}
//		});
		dwr.engine.setAsync(false);
		ChartData.logic_use_chart($("#s_logic_id").val(),$("#s_physical_id").val(),$("#s_spot_type").val(),
				s_month,s_year,strNow,s_date,chart_type,
				function(json){
						var s = document.getElementById("PrintA");
						ofc_data = json.toJSONString();
						s.load(ofc_data);
		});	
}

function myprint(){
	window.parent.frames["rightFrame"].focus();//选中需要打印的frame
	window.parent.frames["rightFrame"].print();//打印此frame
}