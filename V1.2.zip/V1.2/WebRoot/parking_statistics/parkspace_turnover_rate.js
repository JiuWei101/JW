var _date;
$(function (){
	$("#only_input_day").val(getNowFormatDate());
	_date = $("#only_input_day").val();
	
	operate($("#only_input_day").val());
	
	$("#searchBtn").click(function(){
		_date = $("#only_input_day").val();
		operate(_date);
	});	
});

function operate(_date){
	$.ajax({
		async:false,
		type:'post',
		dataType:'json',
		url:'parkspaceturnoverrate/get_turnover_rate.action',
		data:{'date':_date},
		success:function(msg){
			if(msg.success){
				showGraph(msg);
			}else{
			}
		},
		error:function(){}
	});
}

function showGraph(msg){
	Highcharts.setOptions(GrayTheme);
	$('#container').highcharts({
		credits: {
			enabled: false
		},
		exporting: {
			enabled: false
		},
	    chart: {
	    	type: 'column'
	    },
	    title: {
	    	text: msg["potTotalTitle"]
	    },
	    tooltip: {
	    	shared: true
	    },
	    legend: {
	    	enabled: true
	    },
	    plotOptions: {
	    	column: {
	            pointInterval: 1,
	            pointStart: 1,
	            threshold: null
            }
	    },
	    xAxis: {
	    	title: {
	    		text: msg["xunit"]
	    	}
	    },
	    yAxis: {
	    	title: {
	    		text: msg["yunit"],
	    		rotation: 270
	    	},
	    	min: 0
	    },
	    series: [{
	    	type: 'column',
	    	name: msg["series"],
	    	data:msg["item"]
	    }]
	});
}

/**
*打印
*/
function exportToPrint(){
	window.parent.frames[0].focus();//选中需要打印的frame
	window.parent.frames[0].print();//打印此frame
}

/**
 * 导出excel
 */
function exprotToExcel(){
	var form = $("<form>");   //定义一个form表单
    form.attr('style','display:none');   //在form表单中添加查询参数
    form.attr('target','');
    form.attr('method','post');
    form.attr('action',"parkspaceturnoverrate/dataExportToExcel.action");

    var dateInput = $('<input>'); 
    dateInput.attr('type','hidden'); 
    dateInput.attr('name','date'); 
    dateInput.attr('value',_date); 
   
    $('body').append(form);  //将表单放置在web中
    form.append(dateInput);   		//将参数控件提交到表单上
    form.submit();   //表单提交
}

/**
 * 获取当前日期的方法:yyyy-MM-dd
 * @returns {String}
 */
function getNowFormatDate() {
	var day = new Date();
	var Year = 0;
	var Month = 0;
	var Day = 0;
	var CurrentDate = "";
	Year = day.getFullYear();//支持IE和火狐浏览器.
	Month = day.getMonth() + 1;
	Day = day.getDate();
	CurrentDate += Year + "-";
	if (Month >= 10) {
		CurrentDate += Month + "-";
	} else {
		CurrentDate += "0" + Month + "-";
	}
	if (Day >= 10) {
		CurrentDate += Day;
	} else {
		CurrentDate += "0" + Day;
	}
	return CurrentDate;
}

//===========================================================================
/**
 * Grid theme for Highcharts JS
 * @author Torstein Honsi
 */
var GrayTheme = {
	colors: ['#058DC7', '#54C85D', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
	chart: {
		backgroundColor: {
			linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
			stops: [
				[0, 'rgb(255, 255, 255)'],
				[1, 'rgb(240, 240, 255)']
			]
		},
		borderWidth: 2,
		plotBackgroundColor: 'rgba(255, 255, 255, .9)',
		plotShadow: true,
		plotBorderWidth: 1
	},
	title: {
		style: {
			color: '#000',
			font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
		}
	},
	subtitle: {
		style: {
			color: '#666666',
			font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
		}
	},
	xAxis: {
		gridLineWidth: 1,
		lineColor: '#000',
		tickColor: '#000',
		labels: {
			style: {
				color: '#000',
				font: '11px Trebuchet MS, Verdana, sans-serif'
			}
		},
		title: {
			style: {
				color: '#333',
				fontWeight: 'bold',
				fontSize: '12px',
				fontFamily: 'Trebuchet MS, Verdana, sans-serif'

			}
		}
	},
	yAxis: {
		minorTickInterval: 'auto',
		lineColor: '#000',
		lineWidth: 1,
		tickWidth: 1,
		tickColor: '#000',
		labels: {
			style: {
				color: '#000',
				font: '11px Trebuchet MS, Verdana, sans-serif'
			}
		},
		title: {
			style: {
				color: '#333',
				fontWeight: 'bold',
				fontSize: '12px',
				fontFamily: 'Trebuchet MS, Verdana, sans-serif'
			}
		}
	},
	legend: {
		itemStyle: {
			font: '9pt Trebuchet MS, Verdana, sans-serif',
			color: 'black'

		},
		itemHoverStyle: {
			color: '#039'
		},
		itemHiddenStyle: {
			color: 'gray'
		}
	},
	labels: {
		style: {
			color: '#99b'
		}
	},

	navigation: {
		buttonOptions: {
			theme: {
				stroke: '#CCCCCC'
			}
		}
	}
};
//===========================================================================
