
function operate(str,id){
	if(document.getElementsByName("statisticsData.s_type")[0].checked){//年
		if(document.getElementById("s_year").value == ''){
			alert(document.getElementById("alert_year").value);
			return;
 		}
	}
	if(document.getElementsByName("statisticsData.s_type")[1].checked){//月
		if(document.getElementById("s_year").value == ''){
			alert(document.getElementById("alert_year").value);
			return;
 		}
 		if(document.getElementById("s_month").value == ''){
 			alert(document.getElementById("alert_month").value);
 			return;
 		}
	}
	
	if(document.getElementsByName("statisticsData.s_type")[2].checked){//日
		if(document.getElementById("s_b_date").value == ''){
			alert(document.getElementById("alert_date").value );
			return;
 		}
	}
    if(list_type=="inout"){
    	document.listform.action = "../parking_statistics/inout_list.action?list_type="+list_type;
		document.listform.submit();
    }
    if(list_type=="used"){
    	document.listform.action = "../parking_statistics/used_list.action?list_type="+list_type;
		document.listform.submit();
    }
}

	/**
	*Excel导出
	*/
	function exportToExcel(){
    	wopen("../parking_statistics/export_excel.action","_blank",800,530);
	}
	/**
	*打印
	*/
	function exportToPrint(){
    	wopen("../parking_statistics/export_print.action","_blank",800,530);
	}

/**
*显示和隐藏 年月日啥的
*/
function showOrHide(){
	if(document.getElementsByName("statisticsData.s_type")[0].checked){//年
		document.getElementById('div_sy').style.display="inline";
		document.getElementById('div_sm').style.display="none";
		document.getElementById('div_sbd').style.display="none";
		strNow = 'year';
		//ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_year").value+ps_type_year;// 停车场使用情况/使用率：2012
	}
	if(document.getElementsByName("statisticsData.s_type")[1].checked){//月
		document.getElementById('div_sy').style.display="none";
		document.getElementById('div_sm').style.display="inline";
		document.getElementById('div_sbd').style.display="none";
		document.getElementById('div_sed').style.display="none";
		strNow = 'month';
		//ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_year").value+ps_type_year+document.getElementById("s_month").value+ps_type_month;
	}
	
	if(document.getElementsByName("statisticsData.s_type")[2].checked){//日
		document.getElementById('div_sy').style.display="none";
		document.getElementById('div_sm').style.display="none";
		document.getElementById('div_sbd').style.display="inline";
		strNow = 'day';
		//ptitle=(list_type=="inout"?plist_type_inout:(plist_type_used+":"))+document.getElementById("s_b_date").value+ps_type_day;
	}
	
}
function showOrHidePanel(){
	if(document.getElementsByName("statisticsData.chart_type")[0].checked){//曲线
		//chart_graph.render();
		document.getElementById('PrintA').style.display="none";
		document.getElementById('PrintB').style.display="block";
		
	}else{ //柱状
		document.getElementById('PrintA').style.display="block";
		document.getElementById('PrintB').style.display="none";
		
	}
}

function thisprint(){
	window.focus();
	//cgchide();
	window.print();	
	//unhide();
	return false;
}
//级联
function nextLogic(phy){
//	
//	$.ajax({
//		    async: false,
//			type: "POST",
//			dataType: "json",
//			url: '../parking_statistics/nextLogic.action',
//			data: {
//				phyId:phy.value
//			},
//			success: function(msg){
//				if(msg.success){
//					var arr = msg.list;
//	            	$('#s_logic_id').empty();
//	            	$('#s_logic_id').append("<option value=''>   </option>");  //添加一项option
//	            	for(s in arr){
//	            		if(arr[s].code_name!='undefined'&&arr[s].code_name!=undefined)
//	            	    	$('#s_logic_id').append("<option value='"+arr[s].code_id+"'>"+arr[s].code_name+"</option>");  //添加一项option
//	            	}
//				}
//				
//			},
//			error:function(msg){
//				alert('error'+msg);
//			}
//		});
	dwr.engine.setAsync(false);
	ChartData.nextLogic(phy.value,
			function(msg){
		if(msg.success){
			var arr = msg.list;
        	$('#s_logic_id').empty();
        	$('#s_logic_id').append("<option value=''>   </option>");  //添加一项option
        	for(s in arr){
        		if(arr[s].code_name!='undefined'&&arr[s].code_name!=undefined)
        	    	$('#s_logic_id').append("<option value='"+arr[s].code_id+"'>"+arr[s].code_name+"</option>");  //添加一项option
        	}
		}
	});	
}
