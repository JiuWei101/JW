function operate(str,id){
    if(str=="delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var flag = true;
    	//检查是否可以删除，如果在屏分区表中已经有引导区的引用，不允许删除
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../guideregion_manage/check_refrence_delete.action",
			data: {'data.id':getCheckChkValue("chk_record")},
			success: function(msg){
				if(msg.success){
				} else {
					flag = false;
				}
			},
			error:function(msg){
			
				alert('error'+msg);
			
			}
		});
    	if(!flag){
    	
    		alert($("#alert_guideregion_in_screenregion").val());
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../guideregion_manage/guideregion_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					} else {
						
						alert(msg.ex);
					}
				},
				error:function(msg){
					
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	if(checkOne()){
    		var guide_id = getCheckChkValue();
    		$("#id").val(guide_id);
    		$("#code").val($("#code" + "_" + guide_id).val());
    		$("#name").val($("#name" + "_" + guide_id).val());
    		$("#notes").val($("#notes" + "_" + guide_id).val());
    		document.getElementsByName("data.notes")[0].value = $("#notes" + "_" + guide_id).val();
    		if(document.getElementsByName("data.regionType")[0].value == $("#type" + "_" + guide_id).val()){
    			document.getElementsByName("data.regionType")[0].checked = true;
    		} else if(document.getElementsByName("data.regionType")[1].value == $("#type" + "_" + guide_id).val()){
    			document.getElementsByName("data.regionType")[1].checked = true;
    		} 
//    		document.getElementsByName("data.notes")[0].disabled = true;
//    		document.getElementsByName("data.regionType")[1].disabled = true;
    	}
    }else if(str=="clear"){ 
		$("#id").val("");
		$("#code").val("");
		$("#name").val("");
		$("#notes").val("");
		document.getElementsByName("data.regionType")[0].checked = true;
//		document.getElementsByName("data.notes")[0].disabled = false;
//		document.getElementsByName("data.regionType")[0].disabled = false;
//		document.getElementsByName("data.regionType")[1].disabled = false;
    }else if(str=="list"){ 
    	operate("clear");
    	document.listform.action = "../guideregion_manage/guideregion_list.action";
		document.listform.submit();
    }else if(str=="return"){
		winClose();
    }else if(str=="refresh_parent"){
    	opener.replaceRegion("guide");
	}else if(str=="save"){
		var name = trim($("#name").val());//去除所有空格并重新赋值
		$("#name").val(name);
		var code = trim($("#code").val());//去除所有空格并重新赋值
		$("#code").val(code);
		if($("#code").val() == ""){
			alert($("#alert_code").val() + $("#alert_is_not_null").val());
			return;
		}
		if($("#name").val() == ""){
			alert($("#alert_name").val() + $("#alert_is_not_null").val());
			return;
		}
		if(getCheckChkValue("data.regionType")==""){
			alert($("#alert_type").val() + $("#alert_is_not_null").val());
			return;
		}
    	var flag = true;
    	//检查是否可以更改编号，如果在屏分区表中已经有引导区的引用，不允许更新
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../guideregion_manage/check_refrence_update.action",
			data: $("#guideregion_list").formSerialize(),
			success: function(msg){
				if(msg.success){
				} else {
					flag = false;
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
		
    	if(!flag){
    		alert($("#alert_guideregion_in_screenregion").val());
    		return;
    	}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../guideregion_manage/guideregion_save.action",
			data: $("#guideregion_list").formSerialize(),
			success: function(msg){
				if(msg.success){
					operate('list');
				} else {
					//alert($('#alert_guide_regional_name_repeat').val());
					alert($("#alert_code").val()+$("#alert_is_exist").val());
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}
}