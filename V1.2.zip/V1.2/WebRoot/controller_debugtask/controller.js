function operate(str,id){
    if(str=="create"){
    	wopen("../controller_debugtask/controller_create.action","_blank",800,480);
	}else if(str=="delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../controller_debugtask/controller_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('list');
					} else {
						alert(msg.msg);
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="edit"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var ids = getCheckChkValue();
    	if(ids.indexOf(";") == -1){
    		wopen("../controller_debugtask/controller_edit.action?data.id="+ids,"_blank",800,480);
    	} else {
    		wopen("../controller_debugtask/controller_multiedit.action?data.id="+ids,"_blank",800,480);
    	}
    }else if(str=="editall"){ 
    	wopen("../controller_debugtask/controller_multiedit.action","_blank",800,480);
    }else if(str=="check_color_task"){ 
    	wopen("../controller_debugtask/check_color_task.action","_blank",800,480);
	}else if(str=="config_task_delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 
    	var rst = window.confirm(document.getElementById("alert_will_delete_controller_settings").value);

    	if(rst){
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
    	
			if(rs){
				$.ajax({
				    async: false,
					type: "POST",
					dataType: "json",
					url: "../controller_debugtask/config_task_delete.action",
					data: {'data.id':getCheckChkValue("chk_record")},
					success: function(msg){
						if(msg.success){
					    	document.listform.start.value=1;
					    	document.listform.action = "../controller_debugtask/config_task.action";
							document.listform.submit();
						} else {
							alert(msg.msg);
						}
					},
					error:function(msg){
						alert('error'+msg);
					}
				});
		    }
    	}
    	
    }else if(str=="config_history"){ 
    	wopen("../controller_debugtask/config_history.action","_blank",800,480);
    }else if(str=="inifile"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	
    	var flag = false;
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/check_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(!msg.line){
					alert($('#alert_line_cant_for_empty').val());
					flag = true;
					return;
				}
				if(!msg.success){
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
					flag = true;
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
		if(flag){
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/controller_ini.action?data.id="+getCheckChkValue(),
			data: $("#controller_listt").formSerialize(),
			success: function(msg){
				if(msg.success){
					alert($('#alert_ini_file_task_established').val());  //下发配置文件提示信息 “任务建立成功”  add by shenlk 2012-08-03
				} else {
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }else if(str=="list"){ 
    	document.listform.start.value=1;
    	document.listform.action = "../controller_debugtask/controller_list_for_color_tactics.action";
		document.listform.submit();
    }else if(str=="back"){
		winClose();
	}else if(str=="save"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/controller_save.action",
			data: $("#controller_create").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($("#process_success").val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="update"){
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/controller_update.action",
			data: $("#controller_edit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($('#alert_again_issued_config_file').val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="multiupdate"){
 		if(getCheckChkValue("field") == ""){
 			alert(document.getElementById("modify_content").value + document.getElementById("alert_is_not_null").value);
 			return;
 		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/controller_multiupdate.action",
			data: $("#controller_multiedit").formSerialize(),
			success: function(msg){
				if(msg.success){
					window.opener.operate('list');
					alert($('#alert_again_issued_config_file').val());
					window.close();
				} else {
					alert(msg.msg);
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
   	}else if(str=="create_color_task"){ 
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 		if(document.getElementById("debugTaskId").value == ""){
			alert($("#alert_taskname").val() + $("#alert_is_not_null").val());//
			return;
		}
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/create_color_task.action?data.id="+getCheckChkValue()
			     +"&data.debugTaskId="+document.getElementById("debugTaskId").value,
			data: {},
			success: function(msg){
				if(msg.success){
					alert($('#alert_ini_file_task_established').val());  //下发配置文件提示信息 “任务建立成功”  add by shenlk 2012-08-03
				} else {
					if(msg.msg != "null" && typeof(msg.msg) != "undefined"){
						alert(msg.msg);
					} else {
						alert(document.getElementById("alert_ini_file_save_error").value);
					}
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
    }else if(str=="color_task_delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
 
    		var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
	
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../controller_debugtask/color_task_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
				    	document.listform.start.value=1;
				    	document.listform.action = "../controller_debugtask/check_color_task.action";
						document.listform.submit();
					} else {
						alert(msg.msg);
					}
				},
				error:function(msg){
					alert('error'+msg);
				}
			});
	    }
    	
    	
    }else if(str=="color_task_history"){ 
    	wopen("../controller_debugtask/color_task_history.action","_blank",800,480);
    }else if(str=="custom_debug_task_list"){ 
    	wopen("../controller_debugtask/custom_debug_task_list.action","_blank",800,480);
    }else if(str=="custom_debug_task_list2"){ 
    	operate("todefault");
    	document.listform.action = "../controller_debugtask/custom_debug_task_list.action";
		document.listform.submit();
	}else if(str=="todefault"){ 
		$("#taskname").val("");
		$("#funcode").val("0");
		$("#senddata1").val("00");
		$("#senddata2").val("00");
		$("#senddata3").val("00");
		$("#senddata4").val("00");
		$("#senddata5").val("00");
		$("#senddata6").val("00");
		$("#senddata7").val("00");
		$("#senddata8").val("00");
		$("#returndata1").val("00");
		$("#returndata2").val("00");
		$("#returndata3").val("00");
		$("#returndata4").val("00");
		$("#returndata5").val("00");
		$("#returndata6").val("00");
		$("#returndata7").val("00");
		$("#returndata8").val("00");
		$("#notes").val("");
    }else if(str=="custom_debug_task_save"){
		var name = trim($("#taskname").val());//去除所有空格并重新赋值
		$("#taskname").val(name);
		if($("#taskname").val() == ""){
			alert($("#alert_name").val() + $("#alert_is_not_null").val());
			return;
		}	
		$.ajax({
		    async: false,
			type: "POST",
			dataType: "json",
			url: "../controller_debugtask/custom_debug_task_save.action",
			data: $("#custom_debug_task_list").formSerialize(),
			success: function(msg){
				if(msg.success){
					operate('custom_debug_task_list2');				
				} else {
					alert($("#alert_code").val()+$("#alert_is_exist").val());
				}
			},
			error:function(msg){
				alert('error'+msg);
			}
		});
 	}else if(str=="custom_debug_task_edit"){ 
    	if(checkOne()){
    		var taskid = getCheckChkValue();
    		$("#id").val(taskid);
    		$("#taskname").val($("#taskname" + "_" + taskid).val());
    		$("#funcode").val($("#funcode" + "_" + taskid).val());
    		$("#senddata1").val($("#senddata1" + "_" + taskid).val());
    		$("#senddata2").val($("#senddata2" + "_" + taskid).val());
    		$("#senddata3").val($("#senddata3" + "_" + taskid).val());
    		$("#senddata4").val($("#senddata4" + "_" + taskid).val());
    		$("#senddata5").val($("#senddata5" + "_" + taskid).val());
    		$("#senddata6").val($("#senddata6" + "_" + taskid).val());
    		$("#senddata7").val($("#senddata7" + "_" + taskid).val());
    		$("#senddata8").val($("#senddata8" + "_" + taskid).val());
    		$("#returndata1").val($("#returndata1" + "_" + taskid).val());
    		$("#returndata2").val($("#returndata2" + "_" + taskid).val());
    		$("#returndata3").val($("#returndata3" + "_" + taskid).val());
    		$("#returndata4").val($("#returndata4" + "_" + taskid).val());
    		$("#returndata5").val($("#returndata5" + "_" + taskid).val());
    		$("#returndata6").val($("#returndata6" + "_" + taskid).val());
    		$("#returndata7").val($("#returndata7" + "_" + taskid).val());
    		$("#returndata8").val($("#returndata8" + "_" + taskid).val());
    		$("#notes").val($("#notes" + "_" + taskid).val());
    	}
    }else if(str=="custom_debug_task_delete"){
    	if(!checkChk()){
    		alert(document.getElementById("alert_please_select_a_record").value);	//请先进行选择
    		return;
    	}
    	var rs=window.confirm(document.getElementById("alert_delete").value);	//你确定删除此记录吗
		if(rs){
			$.ajax({
			    async: false,
				type: "POST",
				dataType: "json",
				url: "../controller_debugtask/custom_debug_task_delete.action",
				data: {'data.id':getCheckChkValue("chk_record")},
				success: function(msg){
					if(msg.success){
						operate('custom_debug_task_list2');
					} else {
						
						alert(msg.ex);
					}
				},
				error:function(msg){
					
					alert('error'+msg);
				}
			});
	    }
    }else if(str=="custom_debug_task_return"){
    	winClose();
    }  
}
var field_code = new Array("lineId","port","status","notes");
function changeOptions(obj){
	for(var i = 0; i < field_code.length; i++){
		if(field_code[i] == obj.value){
			document.getElementById("div_" + field_code[i]).style.display = "block";
		} else {
			document.getElementById("div_" + field_code[i]).style.display = "none";
		}
	}
}