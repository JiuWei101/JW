package com.ie.jofc;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;

public class LineElement extends AChart{
	
	public ArrayList values;

	public LineElement(){
		
		super();
		this.type = "line";
		
	}

	@Override
	void addData(List li) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addData(List li, String color) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addData(List li, String color, String text ,int id) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public ArrayList getValues() {
		return values;
	}

	public void setValues(ArrayList values) {
		this.values = values;
	}

	@Override
	void addData(JSONArray li, String color, String text, int id) throws Exception {
		// TODO Auto-generated method stub
		
	}

	
}
