package com.ie.jofc;

import jofc2.model.elements.BarChart.Bar;

public class SubBar extends Bar {

	private String tip;
	
	public SubBar(Number arg0, String arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public SubBar(Number arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

}
