package com.ie.jofc;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public abstract class AChart {
	
	public List<JSONObject> elements = new ArrayList<JSONObject>();
	public String type;//      "bar_glass",
	public double alpha = 0.5;
	public String colour = "#9933CC";
	public String text = "";
	public int id;
	public String on_click;
	public String key_on_click = "toggle_visibility";
	
	public int font_size = 10;
	
	
	abstract void addData(List li) throws Exception;
	abstract void addData(List li,String color) throws Exception;
	abstract void addData(List li,String color, String text ,int id) throws Exception;
	abstract void addData(JSONArray li,String color, String text, int id) throws Exception;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAlpha() {
		return alpha;
	}
	public void setAlpha(double alpha) {
		this.alpha = alpha;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKey_on_click() {
		return key_on_click;
	}
	public void setKey_on_click(String key_on_click) {
		this.key_on_click = key_on_click;
	}
	public int getFont_size() {
		return font_size;
	}
	public void setFont_size(int font_size) {
		this.font_size = font_size;
	}
	

	public List<JSONObject> getElements() {
		return elements;
	}

	public void setElements(List<JSONObject> elements) {
		this.elements = elements;
	}
	public String getOn_click() {
		return on_click;
	}
	public void setOn_click(String on_click) {
		this.on_click = on_click;
	}
	
	 
    
    
}
