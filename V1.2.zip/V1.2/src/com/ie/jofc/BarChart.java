package com.ie.jofc;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class BarChart extends AChart{
	
	private JOFCUtils jutil  = new JOFCUtils();
	private BarElement bar = new BarElement();
	private JSONObject jo = new JSONObject();
	private Title title = new Title();	
	public  BarChart(){
		
	}
	public  BarChart(int i){
		this.id = 2;
	}
	@SuppressWarnings("unchecked")
	public void addData(List li, String color) throws Exception{
		bar.colour = color;
		bar.values = new JSONArray();
		for(int i = 0; i < li.size(); i++){
			bar.values.add(li.get(i));
		}
		jo = jutil.appendJson(jo, bar);
		jo.remove("elements");
		elements.add(jo);
	}

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}
	@Override
	@SuppressWarnings("unchecked")
	void addData(List li) throws Exception {
		bar.values = new JSONArray();
		for(int i = 0; i < li.size(); i++){
			Number number = (Number) li.get(i);
			if(li.size() != 24){
				bar.values.add(number);
			} else{				//如果按时查询就给出刻度
				SubBar barChartBar = new SubBar(number, "0x9933CC");
				barChartBar.setTip(number + "\nTime: " + i + ":00:00-" + i + ":59:59");
				bar.values.add(barChartBar);
			}
		}
		jo = jutil.appendJson(jo, bar);
		jo.remove("elements");
		elements.add(jo);
		
	}
	@Override
	void addData(List li, String color, String text,int id) throws Exception {
		if( color == null || color.equals("")){
			;
		}else{
			bar.colour = color;
		}
		bar.id = id;
		bar.text = text;
		bar.on_click = "barClicked";
		bar.values = new JSONArray();
		for(int i = 0; i < li.size(); i++){
			Number number = (Number) li.get(i);
			if(li.size() != 24){
				bar.values.add(number);
			} else{				//如果按时查询就给出刻度
				SubBar barChartBar = new SubBar(number, color);
				barChartBar.setTip(number.intValue() + "\nTime: " + i + ":00:00-" + i + ":59:59");
				bar.values.add(barChartBar);
			}
		}
		jo = jutil.appendJson(jo, bar);
		jo.remove("elements");
		elements.add(jo);
	}
	
	void addData(JSONArray arr, String color, String text,int id) throws Exception {
		if( color == null || color.equals("")){
			;
		}else{
			bar.colour = color;
		}
		bar.text = text;
		bar.on_click = "barClicked";
		bar.values = new JSONArray();
		for(int i = 0; i < arr.size(); i++){
			JSONObject json = arr.getJSONObject(i);
			bar.values.add(json);
		}
		jo = jutil.appendJson(jo, bar);
		jo.remove("elements");
		elements.add(jo);
	}
}