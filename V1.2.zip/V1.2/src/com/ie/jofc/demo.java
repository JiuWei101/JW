package com.ie.jofc;

import net.sf.json.JSONObject;

public class demo {
	public static void main(String[] args) throws Exception {
		//String data_S = "{\"type\":\"double\",\"arr\":[{\"name\":\"f1\",\"use_number\":1200},{\"name\":\"f2\",\"use_number\":100}]}";
		String data_S = "{\"type\":\"double\",\"arr\":[{\"name\":\"f1\",\"use_number\":1200,\"use_number_2\":1700},{\"name\":\"f2\",\"use_number\":1100,\"use_number_2\":1200}]}";
    	
		JSONObject jo = JSONObject.fromObject(data_S);
    	//[{"use_number":"0.00000000","name":"14"},{"use_number":"7.81250000","name":"15"},{"use_number":"7.81250000","name":"16"},{"use_number":"7.81250000","name":"17"},{"use_number":"7.81250000","name":"18"},{"use_number":"7.81250000","name":"19"},{"use_number":"7.81250000","name":"20"},{"use_number":"7.81250000","name":"21"},{"use_number":"7.81250000","name":"22"},{"use_number":"7.81250000","name":"23"}]
		LineChart lc = new LineChart();
		//BarChart bar = new BarChart();
		BarChart bar = new BarChart(2);
		BuilderChart bc = new BuilderChart();
		//JSONObject jsonString = bc.getBuilder(jo, bar, true, "My Chart");
		JSONObject jsonString = bc.getBuilder(jo, bar, "M1", "M2");
		System.out.println(jsonString);
	}
}
