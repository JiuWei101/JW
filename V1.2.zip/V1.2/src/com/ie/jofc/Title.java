package com.ie.jofc;

public class Title {
	public String text;
	public String style = "{font_size: 20px; color:#0000ff; font_family: Verdana; text_align: center}";
    
    public Title(){
    	
    }

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}
}
