package com.ie.jofc;
import net.sf.json.JSONString;



public abstract class JChart implements JSONString {
	
	
	private double yaxisSteps;
	
	private double yaxisMax;
	
	private double yaxisMin;
	
	private boolean autoFitYaxis;
	
   /**
     * 将Y轴自动分为多行，行数是gridNum，坐标原点的Y值设置为min，Y值最大值不小于max，使用的精度为precise，比如1(个位)的精度为0，100(百位 )的精度为2，0.001的精度为-3<br>
     * gridNum如果为null，则根据y轴上坐标值的范围和数量级自动计算格数，最多分为10格<br>
     * 计算最大数量级的方法（仅支持整数）：{@link JOFCUtils#getMaxPrecise(List)}<br>
     * 计算最小数量级的方法：{@link JOFCUtils#getMinPrecise(double[])}<br>
     * 
     * @param newGridNum
     * @param min
     * @param max
     * @param precise
     */
    public void fitYaxis(Integer gridNum, double min, double max, int precise) {
        double newMin = min;
        Integer newGridNum = gridNum;
        double p = Math.pow(10, Math.abs(precise) - 1);
        double gap = Math.abs(max - newMin);
        if (newMin < 0) {
            newMin = newMin % p == 0 ? newMin : ((int) (newMin / p) - 1) * p;
        } else {
            newMin = newMin % p == 0 ? newMin : ((int) (newMin / p)) * p;
        }
        int devide = (gap / p % 1) == 0 ? (int) (gap / p) : (int) (gap / p) + 1;
        if (newGridNum == null) {// 自动计算格数，最多10格
            newGridNum = (int) (gap / p + (gap % p == 0 ? 0 : 1));
            newGridNum = newGridNum > 10 ? 10 : newGridNum;
        }
        max = (((int) (devide % newGridNum == 0 ? 0 : newGridNum - devide % newGridNum)) + devide) * p + newMin;
        double step = Math.abs(max - newMin) / newGridNum;

        this.setYaxisSteps(step);
        this.setYaxisMax(max);
        this.setYaxisMin(newMin);
        
        this.autoFitYaxis = false;
        
    }

	public double getYaxisSteps() {
		return yaxisSteps;
	}
	
	public void setYaxisSteps(double yaxisSteps) {
		this.yaxisSteps = yaxisSteps;
	}
	
	public double getYaxisMax() {
		return yaxisMax;
	}
	
	public void setYaxisMax(double yaxisMax) {
		this.yaxisMax = yaxisMax;
	}
	
	public double getYaxisMin() {
		return yaxisMin;
	}
	
	public void setYaxisMin(double yaxisMin) {
		this.yaxisMin = yaxisMin;
	}

}