package com.ie.jofc;

import jofc2.model.elements.LineChart.Dot;

public class SubDot extends Dot {

	public SubDot(Number arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	private String tip;
	public SubDot(Number arg0, String arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}
	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

}
