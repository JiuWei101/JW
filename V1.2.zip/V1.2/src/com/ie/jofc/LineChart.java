package com.ie.jofc;

import java.util.ArrayList;
import java.util.List;

import jofc2.model.elements.LineChart.Dot;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.util.JSONUtils;

public class LineChart  extends AChart{
	
	private JOFCUtils jutil  = new JOFCUtils();
	private LineElement line = new LineElement();
	private JSONObject jo = new JSONObject();
	private Title title = new Title();	
	
	public LineChart(){
		
	}
	
	@SuppressWarnings("unchecked")
	public void addData(List li) throws Exception{
		line.values = new ArrayList();
		for(int i = 0; i < li.size(); i++){
			Number number = (Number) li.get(i);
			if(li.size() != 24){
				line.values.add(number);
			} else{				//如果按日查询就给出提示
				SubDot lineDot = new SubDot(number, null);
				lineDot.setTip(number + "\nTime: " + i + ":00:00-" + i + ":59:59");
				line.values.add(lineDot);
			}
		}
		jo = jutil.appendJson(jo, line);
		jo.remove("elements");
		elements.add(jo);
	}

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}

	@Override
	void addData(List li, String color) throws Exception {
		line.values = new ArrayList();
		line.colour = color;
		for(int i = 0; i < li.size(); i++){
			Number number = (Number) li.get(i);
			if(li.size() != 24){
				line.values.add(number);
			} else{				//如果按日查询就给出提示
				SubDot lineDot = new SubDot(number, color);
				lineDot.setTip(number.intValue() + "\nTime: " + i + ":00:00-" + i + ":59:59");
				line.values.add(lineDot);
			}
		}
		jo = jutil.appendJson(jo, line);
		jo.remove("elements");
		elements.add(jo);
		
	}

	@Override
	void addData(List li, String color, String text, int id) throws Exception {
		if( color == null || color.equals("")){
			;
		}else{
			line.colour = color;
		}
		line.id = id;
		line.text = text;
		line.values = new ArrayList();
		for(int i = 0; i < li.size(); i++){
			Number number = (Number) li.get(i);
			if(li.size() != 24 || id != 1){
				line.values.add(number);
			} else{				//如果按日查询就给出提示
				SubDot lineDot = new SubDot(number, color);
				lineDot.setTip(number.intValue() + "\nTime: " + i + ":00:00-" + i + ":59:59");
				line.values.add(lineDot);
			}
		}
		jo = jutil.appendJson(jo, line);
		jo.remove("elements");
		elements.add(jo);
		
	}

	@Override
	void addData(JSONArray li, String color, String text, int id) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
}
