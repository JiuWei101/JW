package com.ie.jofc;

import java.util.List;

import net.sf.json.JSONArray;

public class BarElement extends AChart{
	
	public JSONArray values;

	public BarElement(){
		
		super();
		this.type = "bar";
		
	}

	@Override
	void addData(List li) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addData(List li, String color) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	void addData(List li, String color, String text ,int id) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public JSONArray getValues() {
		return values;
	}

	public void setValues(JSONArray values) {
		this.values = values;
	}

	@Override
	void addData(JSONArray li, String color, String text, int id) throws Exception {
		// TODO Auto-generated method stub
		
	}

	
}