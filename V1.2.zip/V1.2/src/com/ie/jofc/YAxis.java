package com.ie.jofc;

public class YAxis {
	
	public int stroke = 4;
	public int tick_length = 3;
	public String colour = "#d000d0";
	public String grid_colour = "#00ff00";
    public double min = 0;
    public double max = 200;
    public double steps =  20;
    
    public YAxis(){
    	
    }
	public int getStroke() {
		return stroke;
	}
	public void setStroke(int stroke) {
		this.stroke = stroke;
	}
	public int getTick_length() {
		return tick_length;
	}
	public void setTick_length(int tick_length) {
		this.tick_length = tick_length;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getGrid_colour() {
		return grid_colour;
	}
	public void setGrid_colour(String grid_colour) {
		this.grid_colour = grid_colour;
	}
	
	
	
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getSteps() {
		return steps;
	}
	public void setSteps(double steps) {
		this.steps = steps;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
}
