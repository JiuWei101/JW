package com.ie.jofc;

import java.util.ArrayList;
import java.util.List;

import com.ie.common.Log;
import com.ie.common.Util;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * @author wanghuan
 *
 */
public  class BuilderChart {
	
	public XAxis x_axis ;
	
	public Tags tags;
	
	private Title title ;
	private int ci_shu = 2;
	JOFCUtils jofc = new com.ie.jofc.JOFCUtils();
	
	/**
	 * @param jo
	 * @param lc
	 * @param tags_bool
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public JSONObject getBuilder(JSONObject jo, AChart lc, boolean tags_bool, String text) throws Exception{
		
		JSONArray arr = jo.getJSONArray("arr");
		List labelList = new ArrayList();  //labels
		
		JSONObject json = new JSONObject();
		List y_values = new ArrayList();
		//Number[] y_values = new Number[arr.size()];   //数据
		
		JSONArray labelArr = (JSONArray) arr.getJSONObject(0).get("label");
		if(labelArr!=null){
			for(int i=0; i<labelArr.size(); i++){
				JSONObject ject = labelArr.getJSONObject(i);
				labelList.add(ject.get("name").toString());
				/*if(!ject.getString("use_number").equals(""))
					y_values.add(ject.getDouble("use_number"));
				else*/
					y_values.add(0d);
			}
		}
		else{
			for(int i=0;i<arr.size();i++){
				JSONObject ject = arr.getJSONObject(i);
				labelList.add(ject.getString("name"));
				if(!ject.getString("use_number").equals(""))
					y_values.add(ject.getDouble("use_number"));
				else
					y_values.add(0d);
			}
		}
		
		if(y_values.size() == 0){
			y_values.add(0d);
		}
		lc.addData(y_values);
		
		double[] minAndMax = JOFCUtils.getMinAndMax(y_values);//返回y轴上界和下界
		YAxis y_axis = jofc.fitYaxis(null, minAndMax[1], 
				JOFCUtils.getMaxPrecise(y_values));	//设置y轴
		//第一部分 x_axis
		x_axis = new XAxis(labelList);
		jo.clear();
		json = jofc.appendJson(json, x_axis);
		jo.element("x^axis", json);
		//第二部分 elements  
		if(tags_bool){  //可以没有
			tags = new Tags(y_values, ci_shu);
			lc.elements.add(jofc.appendJson(new JSONObject(), tags));
		}
		
		jo.element("elements", lc.elements);
		//第三部分  y_axis
		jo.element("y^axis", jofc.appendJson(new JSONObject(), y_axis));
		//第四部分  可以没有
		if(text != null && !text.equals("")){
			title = new Title();
			title.setText(text);
			jo.element("title", jofc.appendJson(new JSONObject(), title));
		}
		
		return JOFCUtils.toJsonString(jo);
	}
	
	/**
	 * 双图形
	 * @param jo
	 * @param lc
	 * @param text
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public JSONObject getBuilder(JSONObject jo, AChart lc, String text1, String text2) throws Exception{
		
		JSONArray arr = jo.getJSONArray("arr");
		//定义数据集
		List labelList = new ArrayList();  //labels
		JSONObject json = new JSONObject();
//		List y_values = new JSONArray();
//		List y_values_2 = new JSONArray();
		
		List y_values = new ArrayList();
		List y_values_2 = new ArrayList();
		JSONArray y_arr_1 = new JSONArray();
		JSONArray y_arr_2 = new JSONArray();
		//针对有跳转的情况
		for(int i=0;i<arr.size();i++){
			JSONObject jt = arr.getJSONObject(i);
			if(jt != null && !jt.isEmpty()){
				if(jt.getString("use_number").trim().equals("")){
					jt.element("use_number", 0d);
				}
				if(jt.getString("use_number_2").trim().equals("")){
					jt.element("use_number_2", 0d);
				}
				if(jo.get("click") != null){
					JSONObject js =  new JSONObject();
					js.element("top", jt.getDouble("use_number"));
					js.element("on-click-text", "../mapmonitor/monitor^main.action?map^id=" + jt.getString("map_id"));
					y_arr_1.add(js);
					js.element("top", jt.getDouble("use_number_2"));
					js.element("on-click-text", "../mapmonitor/monitor^main.action?map^id=" + jt.getString("map_id"));
					y_arr_2.add(js);
					
				}
				
				labelList.add(jt.getString("name"));
				y_values.add(jt.getDouble("use_number"));
				y_values_2.add(jt.getDouble("use_number_2"));
			}
			
		}
		//组装数据
		if(y_values.size() == 0){
			y_values.add(0d);
		}
		if(y_values_2.size() == 0){
			y_values_2.add(0d);
		}
		AChart newInstance = lc.getClass().newInstance();
		if(jo.get("click") != null){
			lc.addData(y_arr_1, "#CC9933", text1, 1);
			newInstance.addData(y_arr_2, "#9933CC", text2, 2);
		}else{
			lc.addData(y_values, "#CC9933", text1, 1);
			newInstance.addData(y_values_2, "#9933CC", text2 ,2);
		}
		
		
		//第一部分 x_axis
		x_axis = new XAxis(labelList);
		jo.clear();
		json = jofc.appendJson(json, x_axis);
		jo.element("x^axis", json);
		//第二部分 elements  
		
//		tags = new Tags(y_values, ci_shu, "left", "#CC9933");
//		ci_shu --;
//		lc.elements.add(jofc.appendJson(new JSONObject(), tags));
//		tags = new Tags(y_values_2, ci_shu, "right", "#9933CC");
//
//		lc.elements.add(jofc.appendJson(new JSONObject(), tags));
		
		lc.elements.add(newInstance.elements.get(0));
		jo.element("elements", lc.elements);
		//第三部分  y_axis
		double max = JOFCUtils.getWhoMax(y_values, y_values_2);
		
//		YAxis y_axis = jofc.fitYaxis(null, max, 
//				JOFCUtils.getMaxPrecise(y_values_2));
		YAxis y_axis = jofc.newFiYAxis(null, max, JOFCUtils.getMaxPrecise(y_values_2));
		jo.element("y^axis", jofc.appendJson(new JSONObject(), y_axis));
		return JOFCUtils.toJsonString(jo);
	}
	
	/**
	 * 
	 * @param jo
	 * @param lc
	 * @return
	 */
	public JSONObject getBuilder(JSONObject jo,AChart lc) throws Exception{
		//[{"label":[{"name":0},{"name":1},{"name":2},{"name":3},{"name":4},{"name":5},{"name":6},{"name":7},{"name":8},{"name":9},{"name":10},{"name":11},{"name":12},{"name":13},{"name":14},{"name":15},{"name":16},{"name":17},{"name":18},{"name":19},{"name":20},{"name":21},{"name":22},{"name":23},{"name":24},{"name":25},{"name":26},{"name":27},{"name":28},{"name":29},{"name":30},{"name":31}]},
		//{"logicname":"A","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]},
		//{"logicname":"B","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]},
		//{"logicname":"C","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]},
		//{"logicname":"D","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]},
		//{"logicname":"E","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]},
		//{"logicname":"F","data":[{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0},{"use_number":0}]}]
		
		//[{"label":[{"name":0},{"name":1},{"name":2},{"name":3},{"name":4},{"name":5},{"name":6},{"name":7},{"name":8},{"name":9},{"name":10},{"name":11},{"name":12},{"name":13},{"name":14},{"name":15},{"name":16},{"name":17},{"name":18},{"name":19},{"name":20},{"name":21},{"name":22},{"name":23},{"name":24},{"name":25},{"name":26},{"name":27},{"name":28},{"name":29},{"name":30},{"name":31}]},
		//{"logicname":"A","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]},
		//{"logicname":"B","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]},
		//{"logicname":"C","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]},
		//{"logicname":"D","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]},
		//{"logicname":"E","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]},
		//{"logicname":"F","data":[[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]]}]
		JSONArray arr = jo.getJSONArray("arr");
		List<List> lList = new ArrayList<List>();//保存Y轴值
		//定义数据集
		List<String> labelList = new ArrayList<String>();  //labels,生成X轴所需要的数据
		JSONArray labelArr = (JSONArray) arr.getJSONObject(0).get("label");
		for(int i=0; i<labelArr.size(); i++){
			labelList.add(labelArr.getJSONObject(i).get("name").toString());
		}
		
		for(int j=1; j<arr.size(); j++){
			AChart newInstance = lc.getClass().newInstance();
			JSONObject obj = arr.getJSONObject(j);
			List list = (List)obj.getJSONArray("data");
			lList.add(list);
			newInstance.addData((List<Double>)list.get(0), JOFCUtils.getColorStr(), obj.getString("logicname"), j);
			lc.elements.add(newInstance.elements.get(0));
		}
		//第一部分 x_axis
		x_axis = new XAxis(labelList);
		jo.clear();
		jo.element("x^axis", jofc.appendJson(new JSONObject(),x_axis));
		jo.element("elements", lc.elements);
		double max = JOFCUtils.getWhoMax(lList);
		List<Double> fList = (List<Double>)lList.get(0).get(0);
		YAxis y_axis = jofc.fitYaxis(null, max, 
				JOFCUtils.getMaxPrecise(fList));	
		jo.element("y^axis", jofc.appendJson(new JSONObject(), y_axis));
		return JOFCUtils.toJsonString(jo);
	}
}
