package com.ie.jofc;

import java.util.List;

import net.sf.json.JSONObject;

public class XAxis {
	public int stroke = 1;
	public int tick_height = 10;
    public String colour = "#d000d0";
    public String grid_colour = "#00ff00";
    public JSONObject labels; 
      //"labels": ["January\n2008","February\n2008","March\n2008","April\n2008","May\n2008","June\n2008","July\n2008","August\n2008","September\n2008"]
    public XAxis(List<String> li){
    	labels = new JSONObject();
    	labels.element("labels", li);
    }
	public int getStroke() {
		return stroke;
	}
	public void setStroke(int stroke) {
		this.stroke = stroke;
	}
	public int getTick_height() {
		return tick_height;
	}
	public void setTick_height(int tick_height) {
		this.tick_height = tick_height;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getGrid_colour() {
		return grid_colour;
	}
	public void setGrid_colour(String grid_colour) {
		this.grid_colour = grid_colour;
	}
	public JSONObject getLabels() {
		return labels;
	}
	public void setLabels(JSONObject labels) {
		this.labels = labels;
	}
}
