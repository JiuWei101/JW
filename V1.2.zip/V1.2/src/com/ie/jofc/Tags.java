package com.ie.jofc;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class Tags {
	
	public Tags(List li, int k){
		values =  new JSONArray();
		for(int i=0;i<li.size();i++){
			JSONObject json = new JSONObject();
			json.element("x", i);
			json.element("y", li.get(i));
			values.add(json);
		}
		id = k;
	}
	public Tags(List li, int k, String alx,String color){
		this.setAlign_x(alx);
		this.setColour(color);
		values =  new JSONArray();
		for(int i=0;i<li.size();i++){
			JSONObject json = new JSONObject();
			json.element("x", i);
			json.element("y", li.get(i));
			values.add(json);
		}
		id = k;
	}
	public String type = "tags";
	public int id;
	public String font = "Verdana";
	public int font_size = 10;
	public String colour = "#000000";
	public int pad_x = 0;
	public int pad_y = 0;
	public int rotate = 0;
	public String align_x = "center";
	public String align_y = "above";
	public String text = "#y#";
	public JSONArray values;
	  
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFont() {
		return font;
	}
	public void setFont(String font) {
		this.font = font;
	}
	public int getFont_size() {
		return font_size;
	}
	public void setFont_size(int font_size) {
		this.font_size = font_size;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public int getPad_x() {
		return pad_x;
	}
	public void setPad_x(int pad_x) {
		this.pad_x = pad_x;
	}
	public int getPad_y() {
		return pad_y;
	}
	public void setPad_y(int pad_y) {
		this.pad_y = pad_y;
	}
	public int getRotate() {
		return rotate;
	}
	public void setRotate(int rotate) {
		this.rotate = rotate;
	}
	public String getAlign_x() {
		return align_x;
	}
	public void setAlign_x(String align_x) {
		this.align_x = align_x;
	}
	public String getAlign_y() {
		return align_y;
	}
	public void setAlign_y(String align_y) {
		this.align_y = align_y;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public JSONArray getValues() {
		return values;
	}
	public void setValues(JSONArray values) {
		this.values = values;
	}
}
