
package com.ie.jofc;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.aspectj.weaver.ast.Var;


/**
 * 工具方法类
 * 
 */
public class JOFCUtils {

    /**
     * 添加属性用的方法，根据value的类型做一些判断，决定是否添加进来
     * 
     * @param jo
     * @param key
     * @param value
     */
    public JSONObject appendJson(JSONObject json, Object data) throws Exception{
    	
		Field[] field = data.getClass().getFields();
		
		for(int k = 0; k < field.length; k++){
			String key = field[k].getName();
			String param = "get" + key.substring(0, 1).toUpperCase() + key.substring(1, key.length());
			Method m = data.getClass().getMethod(param);
			json.element(field[k].getName(), m.invoke(data));
			
		}

		return json;
    }   

    /**
     * 使用反射机制递归调用，将任意维数的对象转换成符合javaScript规范的字符串<br>
     * （例如，格式为[["1","2"],["3","4"]]）
     * 
     * @param array
     * @return String
     */
    public static String getJsArray(Object array) {
        if (array == null) {
            return "";
        }
        if (array.getClass().isArray()) {
            JSONArray result = new JSONArray();
            int length = Array.getLength(array);
            for (int i = 0; i < length; i++) {
                result.add(getJsArray(Array.get(array, i)));
            }
            return result.toString();
        } else {
            return array.toString();
        }
    }

    /**
     * 返回最小值和最大值
     * 
     * @param values
     * @return
     */
    public static double[] getMinAndMax(List<Double> values) {
    	
    	double min = 0d;
        double max = 80d;
    	if(values.size()!=0){
    		min = values.get(0);
            max = values.get(0);
    	}
        
        for (double value : values) {
            if (value < min) {
                min = value;
            } else if (value > max) {
                max = value;
            }
        }
        return new double[] {
            min, max
        };
    }
    
    /**
     * 
     * 
     * @param values
     * @return
     */
    public static Double getWhoMax(List<Double> v1, List<Double> v2) {
    	if(v1.size()==0)
    		return 0d;
        double m1 = v1.get(0);
        double m2 = v2.get(0);
        for (double value : v1) {
            if (value > m1) {
                m1 = value;
            }
        }
        for (double value : v2) {
            if (value > m2) {
                m2 = value;
            }
        }
        return m1>m2?m1:m2;
    }
    /**
     * 返回一组List<Double>中的最大值
     * @param lList
     * @return
     */
    public static Double getWhoMax(List<List> lList){
    	List<Double> dList = new ArrayList<Double>();
    	List<Double> test = (List<Double>) lList.get(0).get(0);
    	double kk = test.get(0).doubleValue();
    	for(int i=0; i<lList.size(); i++){
    		if(lList.get(0).size() == 0){
    			return 0d;
    		}else{
    			List<Double> temp = (List<Double>) lList.get(i).get(0);
    			double v = temp.get(0).doubleValue();
//    			for(int j=1; j<lList.get(i).size(); j++){
//    				if((Double) lList.get(i).get(j) > v){
//    					v = (Double) lList.get(i).get(j);
//    				}
//    			}
    			for(double value : temp){
    				if(value > v){
    					v = value;
    				}
    			}
    			dList.add(v);
    		}
    	}
    	if(dList.size() > 0){
        	double tv = dList.get(0);
        	for(double value : dList){
        		if(value > tv){
        			tv = value;
        		}
        	}
        	return tv;
    	}else{
    		return 0d;
    	}
    }
    /**
     * 返回输入的数据的最大数量级，该方法只对y轴坐标值大于1时有效
     * 
     * @param jchart
     * @return int 数量级对10的开方，如果Y轴上的最大值的数量级是n(n>2)，则返回n-2，如果n<=2，返回n
     */
    public static int getMaxPrecise(List<Double> values) {
        int max = 0;
        for (double value : values) {
            String str = ("" + value).split("\\.")[0];
            int lv = str.length() - 1;
            max = max > lv ? max : lv;
        }
//        max = max > 2 ? max - 2 : max;
        return max;
    }
    
    /**
     * 将Y轴自动分为多行，行数是gridNum，坐标原点的Y值设置为min，Y值最大值不小于max，使用的精度为precise，比如1(个位)的精度为0，100(百位 )的精度为2，0.001的精度为-3<br>
     * gridNum如果为null，则根据y轴上坐标值的范围和数量级自动计算格数，最多分为10格<br>
     * 计算最大数量级的方法（仅支持整数）：{@link JOFCUtils#getMaxPrecise(List)}<br>
     * 计算最小数量级的方法：{@link JOFCUtils#getMinPrecise(double[])}<br>
     * 
     * @param newGridNum
     * @param min
     * @param max
     * @param precise
     */
    public YAxis fitYaxis(Integer gridNum, double max, int precise) {
    	if(max==0d){
    		max = 80d;
    	}
    	
        double newMin = 0;
        Integer newGridNum = gridNum;
        double p = Math.pow(10, Math.abs(precise) - 1);
        double gap = Math.abs(max - newMin);
        if (newMin < 0) {
            newMin = newMin % p == 0 ? newMin : ((int) (newMin / p) - 1) * p;
        } else {
            newMin = newMin % p == 0 ? newMin : ((int) (newMin / p)) * p;
        }
        int devide = (gap / p % 1) == 0 ? (int) (gap / p) : (int) (gap / p) + 1;
        if (newGridNum == null) {// 自动计算格数，最多10格
            newGridNum = (int) (gap / p + (gap % p == 0 ? 0 : 1));
            newGridNum = newGridNum > 10 ? 10 : newGridNum;
        }
        
        max = (((int) (devide % newGridNum == 0 ? 0 : newGridNum - devide % newGridNum)) + devide) * p;
        if(newMin == 0 && max != 200){
        	max += max * 0.25;
        }else{
        	max += newMin;
        }
        double step = Math.abs(max - newMin) / newGridNum;
        
        YAxis y_axis = new YAxis();
        y_axis.setSteps(step);
        y_axis.setMax(max);
        y_axis.setMin(0);
        return y_axis;
    }
    
    public YAxis newFiYAxis(Integer gridNum, double max, int precise){
    	if(max == 0d){
    		max = 100d;
    	}
    	double m = max % 10;
    	if(m != 0){
    		max = max + 10 - m;
    	}
    	double step = max / 10;
        YAxis y_axis = new YAxis();
        y_axis.setSteps(step);
        y_axis.setMax(max);
        y_axis.setMin(0);
        return y_axis;
    }
    
    /**
     * @param num
     * @return
     */
    public List<Double> getListDouble(Number[] num){
    	List<Double> li = new ArrayList<Double>();
    	for(int i = 0; i < num.length; i++){
    		li.add(Double.parseDouble(num[i].toString()));
    	}
    	return li;
    }
    
    /**
     * @param json
     * @return
     */
    public static JSONObject toJsonString(JSONObject json){
    	String replace = json.toString().replace("_", "-").replace("^", "_");
    	return JSONObject.fromObject(replace);
    }
    /**
     * 
     * @return
     */
    public static String getColorStr(){
		Random rom = new Random();
		String rstr = "#";
		for(int i=0; i<6; i++){
			rstr += Integer.toHexString(rom.nextInt(16)).toUpperCase();
		}
		return rstr;
    }
}
