package com.ie.alarm;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.stereotype.Component;

import com.ie.alarm.SinglealarmClient;
import com.ie.common.Log;
import com.ie.its.monitor.MonitorData;
import com.ie.its.monitor.MonitorService;
import com.ie.its.monitor.MonitorSql;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;
import com.ie.its.monitor.MonitorAction;

@Component("SendMessage")
public class SendMessage extends ExtendService{
	//private static String password = "577955";
	private MonitorSql monitorSql;
	private MonitorData mdata;
	@Resource
	private  DataSource ds;
	
	public MonitorData getMdata() {
		return mdata;
	}
	public void setMdata(MonitorData mdata) {
		this.mdata = mdata;
	}
	public SendMessage(){
		monitorSql = new MonitorSql();
		if(mdata == null){
			mdata = new MonitorData();
		}
	}
	
	//一个号码发送一条短信
	public int SendSMS(String[] mobiles,String smsContent,int smsPriority,DataSource ds)
	{
		int result = -1;
		try{
			MonitorData data = getInfor(ds);
			if(data.getAttribute1()!=null || data.getAttribute2()!=null)
			{
				result = SinglealarmClient.getClient((String)data.getAttribute1(),(String)data.getAttribute2()).sendSMS(mobiles, smsContent, smsPriority);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	//注册软件服务
	public int RegisterSoftware(DataSource ds)
	{
		MonitorData data = getInfor(ds);
		//String str = data.getAttribute1();
		if(data.getAttribute1()!=null && data.getAttribute2()!=null)
		{
			return SinglealarmClient.getClient((String)data.getAttribute1(),(String)data.getAttribute2()).registEx((String)data.getAttribute2());
		}
		else
			return 10;
	}
	
	//批量发送短信
	public  void BatchSendSMS(DataSource ds)
	{
		
		//@SuppressWarnings("unchecked")
		JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
		ArrayList <MonitorData>rows = jt.queryForListExt(monitorSql.alarmmessage_list("all"),MonitorData.class);
		if(rows.size()!=0)
		{
			for(MonitorData data:rows)
			{
				//判断是否需要发送、是否已发送、是否采用网络
				if((data.getS_isneedsend().equalsIgnoreCase("1")) && (data.getS_alreadysend().equalsIgnoreCase("0")) && (data.getS_noticeway().equalsIgnoreCase("2")) && (data.getS_status().equalsIgnoreCase("1")))
				{
					String devicetype = getDevice(Integer.parseInt(data.getS_devicetype()));
					String status = getStatus(Integer.parseInt(data.getS_status()));
					String message = "温馨提示："+ devicetype+data.getS_code()+status;//发送的信息内容 = 设备类型 + 设备编号 + 设备状态
					if(SendSMS(new String[]{data.getS_mobilephone()}, message, 5,ds) == 0)
						{
							Log.log(message+"已发送");
							data.setS_alreadysend("1");
							jt.update(monitorSql.alarm_update(data));
						}
				}
			}
		}
		else{
			Log.log("--无故障数据，不发短信--");
		}
	}
	
	//以下为不规范转化
	public String getDevice(int devicecode)
	{
		String result = "";
		switch(devicecode)
		{
		case 1: 
			result +="管理器";
			break;
		case 2: 
			result +="显示屏";
			break;
		case 3: 
			result +="探测器";
			break;
		}
		return result;
	}
	
	public String getStatus(int status)
	{
		String result ="";
		switch(status)
		{
		case 0:
			result +="正常";
			break;
		case 1:
			result +="离线";
			break;
		}
		return result;
	}
	
	public MonitorData getInfor(DataSource ds)
	{
		JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
		MonitorData data = new MonitorData();
		data = jt.queryForObjectExt(monitorSql.getAlarmBaseInfor(), MonitorData.class);
		return data;
	}
}
