package com.ie.alarm;

import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import cn.emay.sdk.client.api.Client;

//同步实例化一个client
public class SinglealarmClient {
	
	private static Client client = null;
	
	private SinglealarmClient(){
		
	}
	public synchronized static Client getClient(String serialNo, String key)
	{
		if(client == null)
		{
			try{
				client = new Client(serialNo,key);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return client;
	}
	
	public synchronized static Client getClient()
	{
		ResourceBundle bundle = PropertyResourceBundle.getBundle("config");
		if(client == null)
		{
			try{
					client = new Client(bundle.getString("softwareSerialNo"),bundle.getString("key"));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return client;
	}
}
