/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 对密码进行MD5加密
 * Version                  : 1.0
 * create date              : 2008.3.31
 * author                   ：jl
 * Modified By              : ghc
*/
package com.ie.common;

import java.util.ArrayList;

public class OperateScList {

	/**
	 * Description :根据编码的名字取得编码列表
	 * @param name :列表名称
	 * @return     :
	 */
	public static ArrayList getScList(String name){
		SclistInfo scInfo = (SclistInfo)ConfigInfo.getSclistmap().get(name);
		return scInfo.getSclist();
	}
	
	/**
	 * Description :根据编码的名字和id值 得到其对应的语义
	 * @param name :列表名称
	 * @param id   :键值
	 * @return     :键值对应汉语意思
	 */
	public static String getSclistInfoName(String name, String id){
		String rtn = "null";
		
		SclistInfo scInfo = (SclistInfo)ConfigInfo.sclistmap.get(name);
		int size = scInfo.getSclist().size();
		for(int i=0; i<size; i++){
			SclistDATA dto = (SclistDATA)scInfo.getSclist().get(i);
			if(id!=null && id.equalsIgnoreCase(dto.getId())){
				rtn = dto.getName();
			}
		}

		return rtn;
	}
	
	/**
	 * Description :根据编码的名字和id值 得到其对应的语义
	 * @param name :列表名称
	 * @param text :键值对应汉语意思
	 * @return     :键值
	 */
	public static String getSclistInfoId(String name, String text){
		String rtn = "null";
		
		SclistInfo scInfo = (SclistInfo)ConfigInfo.sclistmap.get(name);
		int size = scInfo.getSclist().size();
		for(int i=0; i<size; i++){
			SclistDATA dto = (SclistDATA)scInfo.getSclist().get(i);
			Log.log("text=="+text);
			if(text.equalsIgnoreCase(dto.getName())){
				rtn = dto.getId();
			}
		}

		return rtn;
	}
	
}
