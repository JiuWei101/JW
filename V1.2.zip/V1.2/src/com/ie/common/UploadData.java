
package com.ie.common;

public class UploadData {
	
	private String[]   myFile;           

	public static void main(String[] args) {

	}

	public String[] getMyFile() {
		return myFile;
	}

	public void setMyFile(String[] myFile) {
		this.myFile = myFile;
	}
}
