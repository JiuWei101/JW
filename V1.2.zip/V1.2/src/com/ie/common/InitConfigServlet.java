/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 读取配置文件XML信息，装载到Application中。
 *                            Application状态为应用程序提供了一个全局的状态。所有客户都可以使用该状态。
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   : 
 * Modified By              : ghc
*/
package com.ie.common;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InitConfigServlet extends HttpServlet implements Servlet {

	/**
	 * Description :自动初始化读取配置文件config.xml标签为<page>的信息装载到Application中。
	 *              属性name的值作为key;PageInfo对象实例作为value。
	 */
	public void init() throws ServletException {
		super.init();
		
		Map map = ConfigInfo.getPagermap();  //获取页面信息的Map
		int size = map.size();
		Iterator keyValuePairs = map.entrySet().iterator();
		for (int i = 0; i < size; i++){
			Map.Entry entry = (Map.Entry) keyValuePairs.next();
			Object key = entry.getKey();
			Object value = entry.getValue();
			this.getServletContext().setAttribute((String)key,value);
		}
		
		//初始化下拉列表标准编码
		initSclistContext();
	}
	
	/**
	 * Description :读取配置文件config.xml标签为<sclist>的信息装载到Application中。
	 *              属性name的值作为Map的key;SclistInfo实例作为value。
	 *              并且SclistInfo中的sclist属性装载的是Sclist_DATA实例
	 */
	public void initSclistContext(){
		Map listMap = ConfigInfo.getSclistmap();  //获取下拉列表信息Map
		int listSize = listMap.size();
		Iterator listKeyValuePairs = listMap.entrySet().iterator();
		for (int i = 0; i < listSize; i++){
			Map.Entry entry = (Map.Entry) listKeyValuePairs.next();
			Object key = entry.getKey();
		  	Object value = entry.getValue();
		  	this.getServletContext().setAttribute((String)key,value);
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		init();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		init();
	}
	

}