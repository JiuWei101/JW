/*
 * Created on 2005-7-12
 * 在application中查找特定的标准编码表。
 */
package com.ie.common;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.beanutils.DynaBean;

import com.ie.frame.JdbcTemplateExtend;


import static com.ie.common.Util.*;



public class DisposalCode
{
    private static List codes = new ArrayList();
    private static List userList = new ArrayList();
    private DisposalCode(){
    	
    }
    
    public static List makeCodes(DataSource dataSource){
  
    	JdbcTemplateExtend jt = new JdbcTemplateExtend(dataSource);
    	List codes = new ArrayList();
    	Log.log("dataSource="+dataSource);
    	Log.log("jt="+jt);
   
       codes = jt.queryForList("select code_key as code_id,code_value as code_name,code_type,lang  from sys_lang_switch order by code_type,orderby,code_key,lang") ;
               

        
        return codes;
    }
    public static void setCodes(List codes)
    {
        DisposalCode.codes = codes;
        
    }
    public static List getCode(String codeType,String lang)
    {
        Iterator i = codes.iterator();
        List retVal = new ArrayList();
        
        //增加请选择到下拉列表
//        HashMap temp_default =  new LinkedHashMap();
//        temp_default.put("code_id", "");
//        temp_default.put("code_name", "请选择");
//        temp_default.put("parent_code_id", "");
//		retVal.add(temp_default);
		
        while (i.hasNext())
        {
        	HashMap<String,String> temp = (HashMap) i.next();
            String value1 =  temp.get("code_type");
            String lang1 = temp.get("lang");
            if (value1.equals(codeType) && lang1.equals(lang))
            {
                retVal.add(temp);
            }
        }
        
        return retVal;
    }
    
    public static List getCodeNoDefault(String codeType,String lang)
    {
        Iterator i = codes.iterator();
        List retVal = new ArrayList();
        
        //增加请选择到下拉列表
        HashMap temp_default =  new LinkedHashMap();
 
		
        while (i.hasNext())
        {
        	HashMap<String,String> temp = (HashMap) i.next();
            String value1 =  temp.get("code_type");
            String lang1 = temp.get("lang");
            if (value1.equals(codeType) && lang1.equals(lang))
            {
                retVal.add(temp);
            }
        }
        
        return retVal;
    }
    /**
     * 通过传入编码表中的codeId和codeType返回编码实际意义
     * @param String 编码值 
     * @param String 编码类型
     * @return String 编码实际意义
     */
    public static String getCodeName(String codeId,String codeType,String lang){
    	List li = codes;
    	String codeName = "";
    	if(!isCon(codeId) && !isCon(codeType)){
    		return codeName;
    	}
    	Iterator i = codes.iterator();
    	

        while (i.hasNext())
        {
	     	HashMap<String,String>temp = (HashMap) i.next();
	        
	     	if(codeId.equals(temp.get("code_id")) && codeType.equals(temp.get("code_type"))
	     			&& lang.equals(temp.get("lang"))){
	     		codeName = temp.get("code_name");
	     	}
          
        }
         
    	return codeName;
    }
    
    /**
     * 通过传入编码表中的typeid返回json对象
     * @param typeId
     * @param codeId
     * @return
     */
    public static net.sf.json.JSONArray getJsonCode(String codeType,String lang){
    	net.sf.json.JSONArray jsonArry = net.sf.json.JSONArray.fromObject(DisposalCode.getCode(codeType,lang));
    	net.sf.json.JSONObject json = new net.sf.json.JSONObject();
    	return jsonArry;
    }
    
    public static String getCodeName(String codeId,String codeType){
    	String codeName = "";
    	if(!isCon(codeId) && !isCon(codeType)){
    		return codeName;
    	}
    	Iterator i = codes.iterator();
        while (i.hasNext())
        {
	     	HashMap<String,String>temp = (HashMap) i.next();
	     	if(codeId.equals(temp.get("code_id")) && codeType.equals(temp.get("code_type"))){
	     		codeName = temp.get("code_name");
	     	}
          
        }
         
    	return codeName;
    }
    
    
    /**
     * 通过传入编码表中的codeType、传值id以及默认选中的项数组返回符合extcheckbox以及radio格式的json对象
     * @param codeType
     * @param checked
     * @return
     */
    public static net.sf.json.JSONArray getJsonCodeCheck(String codeType,String id,String[] checked,String lang){


    	List codes = DisposalCode.getCode(codeType,lang);
    	
    	if(codes == null){
    		return null;
    	}
    	net.sf.json.JSONArray jsonArry = new net.sf.json.JSONArray();
    	Iterator i = codes.iterator();
        while (i.hasNext())
        {
        	LinkedHashMap temp = (LinkedHashMap) i.next();
            net.sf.json.JSONObject json = new net.sf.json.JSONObject();
            if(Util.isCon(temp.get("code_id"))){
	            if(temp.get("code_id").equals("0")){
	            	json.element("inputValue",Integer.parseInt(temp.get("code_id").toString()));
	            }else if(temp.get("code_id").equals("1")){
	                	json.element("inputValue",Integer.parseInt(temp.get("code_id").toString()));
	            }else{
	            	json.element("inputValue",temp.get("code_id"));
	            }
	            json.element("boxLabel",temp.get("code_name"));
	            json.element("name",id);
	            
	            if( checked != null){
		            //查找选中项
		            for(int j = 0;j < checked.length;j++){
		            	if(temp.get("code_id").equals(checked[j])){
		            		  json.element("checked",true);
		            	}
		            }
	            }
	            jsonArry.add(json);      
            }
        }
    	return jsonArry;
    }
    
  

}
