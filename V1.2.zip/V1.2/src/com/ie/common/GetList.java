/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 获得下拉列表
 * Version                  : 1.0
 * create date              : 2008.5.5
 * author                   ：ghc
*/
package com.ie.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;


public class GetList {

	public static final String RET_LIST = "LIST";        //返回List对象
	public static final String RET_MAP = "MAP";          //返回Map对象
	public static final String RET_STR = "STR";          //返回Ajax输出字符串对象
	
	JdbcTemplate jt;
	
	public GetList(JdbcTemplate jt){
		this.jt = jt;
	}
	
	public GetList() {
	}

	
	//岗位
	public ArrayList getPost(String org_id){
		return getPost(org_id,true);
	}
	
	public ArrayList getPost(String org_id,boolean flag){
		String sql = sqlPost(org_id);
		return (ArrayList) getObject(RET_LIST,sql,flag);
	}
	
	public String getAjaxPost(String org_id){
		String sql = sqlPost(org_id);
		return (String) getObject(RET_STR,sql,false);
	}
	
	public String getPostName(String id){
		String str = "";
		String sql = "SELECT id,post_name name FROM sys_post WHERE id='"+id+"'";
		Map map = (Map) getObject(RET_MAP,sql,false);
		str = (String) map.get(id);
		return str;
	}
	
	public String sqlPost(String org_id){
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT a.id id,post_name name FROM sys_post a ,");
		sb.append("(SELECT id FROM sys_org c,(SELECT SUBSTR(level_code,1,4) code FROM sys_org ");
		sb.append(" WHERE id = '"+org_id+"') d WHERE c.level_code = d.code) b ");
		sb.append(" WHERE a.top_org_id = b.id");
		return sb.toString();
	}
	
	//职务
	public ArrayList getDuty(String org_id){
		return getDuty(org_id,true);
	}
	
	public ArrayList getDuty(String org_id,boolean flag){
		String sql = sqlDuty(org_id);
		return (ArrayList) getObject(RET_LIST,sql,flag);
	}
	
	public String getAjaxDuty(String org_id){
		String sql = sqlDuty(org_id);
		return (String) getObject(RET_STR,sql,false);
	}
	
	public String getDutyName(String id){
		String str = "";
		String sql = "SELECT id,duty_name name FROM sys_duty WHERE id='"+id+"'";
		Map map = (Map) getObject(RET_MAP,sql,false);
		str = (String) map.get(id);
		return str;
	}
	
	public String sqlDuty(String org_id){
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT a.id id,duty_name name FROM sys_duty a ,");
		sb.append("(SELECT id FROM sys_org c,(SELECT SUBSTR(level_code,1,4) code FROM sys_org ");
		sb.append(" WHERE id = '"+org_id+"') d WHERE c.level_code = d.code) b ");
		sb.append(" WHERE a.top_org_id = b.id ORDER BY grade ");
		return sb.toString();
	}
	

	//顶层单位
	public ArrayList getToporg(String domainCode){
		return getToporg(domainCode,true);
	}
	
	public ArrayList getToporg(String domainCode,boolean flag){
		int size = domainCode.length();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT id,org_name name FROM sys_org ");
		sb.append(" WHERE type = '01' AND LENGTH(level_code) = 4 AND SUBSTR(level_code,1,"+size+") = '"+domainCode+"'");
		return (ArrayList) getObject(RET_LIST,sb.toString(),flag);
	}
	
	//顶层客户单位
	public ArrayList getTopCustorg(String domainCode){
		return getTopCustorg(domainCode,true);
	}
	
	public ArrayList getTopCustorg(String domainCode,boolean flag){
		int size = domainCode.length();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT id,org_name name FROM sys_org ");
		sb.append(" WHERE type = '03' AND LENGTH(level_code) = 4 AND SUBSTR(level_code,1,"+size+") = '"+domainCode+"'");

		return (ArrayList) getObject(RET_LIST,sb.toString(),flag);
	}
	
	//全部顶层单位
	public ArrayList getAllToporg(String domainCode){
		return getAllToporg(domainCode,true);
	}
	
	public ArrayList getAllToporg(String domainCode,boolean flag){
		int size = domainCode.length();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT id,org_name name FROM sys_org ");
		sb.append(" WHERE type in ('01','03') AND LENGTH(level_code) = 4 AND SUBSTR(level_code,1,"+size+") = '"+domainCode+"'");
		return (ArrayList) getObject(RET_LIST,sb.toString(),flag);
	}
	
	//所在地区
	public ArrayList getDqbm(){
		return getDqbm(true);
	}
	
	public ArrayList getDqbm(boolean flag){
		String sql = "SELECT zip_code id,zip_name name FROM au_zip_code order by zip_code ";
//		System.out.println("sql=="+sql);
		return (ArrayList) getObject(RET_LIST,sql,flag);
	}
	
	/**
	 * Description :具体查询获得数据
	 * @param  ret_type ：返回对象类型
	 * @param  sql ：SQL语句
	 * @param  flag ：true第一项有(--请选择--) ,false没有(--请选择--)
	 * @return Object
	 */
	public Object getObject(String ret_type,String sql,boolean flag){
		ArrayList al = new ArrayList();
		Map map = new HashMap();
		String str = "";
		SclistDATA scdata = null;
		if(flag){
			scdata = new SclistDATA();
			scdata.setId("");
			scdata.setName("请选择");
			al.add(scdata);
			
		}
		List rows = jt.queryForList(sql);
		Iterator it = rows.iterator();
		while(it.hasNext()){
			Map m = (Map)it.next();
			if(ret_type.equals(RET_LIST)){
				scdata = new SclistDATA();
				scdata.setId(String.valueOf(m.get("ID")));
				scdata.setName((String)m.get("NAME"));
				al.add(scdata);
			}else if(ret_type.equals(RET_MAP)){
				map.put((String)m.get("ID"), (String)m.get("NAME"));
			}else if(ret_type.equals(RET_STR)){
				str+=";"+(String)m.get("ID")+"|"+(String)m.get("NAME");
			}
		}
		if(ret_type.equals(RET_LIST)){
			return al;
		}else if(ret_type.equals(RET_MAP)){
			return map;
		}else{
			return str;
		}
	}
	

	public static void main(String[] args) {
	}

}
