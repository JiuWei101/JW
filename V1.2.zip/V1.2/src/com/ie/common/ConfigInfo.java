/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 配置信息类
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：
*/
package com.ie.common;

import java.util.Map;

public class ConfigInfo {
	static Map pagermap;  //页面翻页信息
	static Map initmap;	
	static Map pathmap;
	static Map rightmap;
	static Map sclistmap; //标准编码（standard code list）

	public ConfigInfo() {		
	}

	public static Map getPagermap() {
		if(pagermap == null){
			setPagermap(OperateXML.readxml());
		}
		return pagermap;
	}

	private static void setPagermap(Map map) {
		pagermap = map;
	}
	
	public static Map getSclistmap() {
		try{
			if(sclistmap == null){
				setSclistmap(OperateXML.readxml_sclist());
				//setSclistmap_fromDB();	//从数据库里读取
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return sclistmap;
	}

	public static void setSclistmap(Map sclistmap) {
		ConfigInfo.sclistmap = sclistmap;
	}
	
	public static PageInfo getDefaultPageInfo() {		
		Object ob = getPagermap().get("default");
		return (PageInfo)ob;
	}
	public static PageInfo getPageInfo(String str) {		
		Object ob = getPagermap().get(str);
		return (PageInfo)ob;
	}

	public static Map getInitmap() {
		return initmap;
	}
	public static void setInitmap(Map initmap) {
		ConfigInfo.initmap = initmap;
	}

	public static Map getPathmap() {
		if(pathmap == null){
			setPathmap(OperateXML.readxml_path());
		}
		return pathmap;
	}
	public static void setPathmap(Map pathmap) {
		ConfigInfo.pathmap = pathmap;
	}
	public static Map getRightmap() {
		return rightmap;
	}
	public static void setRightmap(Map rightmap) {
		ConfigInfo.rightmap = rightmap;
	}
	
}
