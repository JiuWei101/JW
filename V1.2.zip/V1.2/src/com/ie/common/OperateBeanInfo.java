/**
 * Copy Right Information   : Forsoft 
 * Project                  : KJGL
 * JDK version used         : jdk1.5
 * Comments                 : 设置和取得bean属�??
 * Version                  : 1.0
 * create date              : 2008.5.15
 * author					: huangmingwei
*/
package com.ie.common;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;

import net.sf.json.JSONObject;

import com.ie.frame.exception.ExtendUnCheckException;


public class OperateBeanInfo {

	public OperateBeanInfo() {
		super();
	}
	
	public static void setPropertyValue(Object ob,String property ,Object va){
		BeanInfo info;
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();			
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					pds[i].getWriteMethod().invoke(ob,new Object[] {va});
					break;
				}
			}
		} catch (Exception e) {
			// TODO 自动生成 catch �?			
			throw new ExtendUnCheckException("设置bean属�?�出�?");
		}
	}

	public static Object getPropertyValue(Object ob,String property){
		BeanInfo info;
		Object rob=null;
		
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();			
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					rob=pds[i].getReadMethod().invoke(ob,null);
					break;
					//pds[i].getWriteMethod().invoke(ob,new Object[] {va});
				}
			}
		} catch (Exception e) {		
			throw new ExtendUnCheckException("ȡ��bean���Գ��");
		}
		return rob;
	}
	/**
	 * @param ob 			formbean
	 * @param module		reqJson下一级自定义key
	 * @param property		module下一级参数key
	 * 
	 * */
	public static Object getJsonValue(Object ob,String module,String property){
		BeanInfo info;
		Object rob=null;
		net.sf.json.JSONObject reqJson=null;
		net.sf.json.JSONObject reqJson_=null;
		net.sf.json.JSONObject json_module=null;
		net.sf.json.JSONObject json_module_=null;
		
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();			
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals("reqJson")){
					if(pds[i].getReadMethod().invoke(ob,null)!=null){
						reqJson=JSONObject.fromObject(pds[i].getReadMethod().invoke(ob,null)) ;
						if(reqJson.get(module)!=null){
							json_module=JSONObject.fromObject(reqJson.get(module));
							rob=json_module.get(property);
						}else{
							System.out.println("------------------"+module+"为空-----------------");
						}
					}else{
						System.out.println("------------------reqJson为空-----------------");
					}
					break;
				}
				//pds[i].getWriteMethod().invoke(ob,new Object[] {va});
			}
		} catch (Exception e) {		
			e.printStackTrace();
			throw new ExtendUnCheckException("取得bean属�?�出�?");
		}
		return rob==null?"":rob;
	}
	public static void setPropertyValue(Object ob,String property ,Object va,String tag,String rep){
		BeanInfo info;
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();	
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					if(pds[i].getPropertyType().equals(String.class)) {
						String str = StringManager.replaceAll((String)va,tag,rep);
						pds[i].getWriteMethod().invoke(ob,new Object[] {str.trim()});
					}else if(pds[i].getPropertyType().equals(Array.class)) {
						Array ar=(Array)pds[i].getReadMethod().invoke(va,null);									
						if(ar!=null){
							for(int j=0 ;j<Array.getLength(ar);j++){	
								Array.set(ar,j,StringManager.replaceAll((String)Array.get(ar,j),tag,rep).trim());
							}
							pds[i].getWriteMethod().invoke(ob,new Object[] {ar});
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			// TODO 自动生成 catch �?			
			throw new ExtendUnCheckException("设置bean属�?�出�?");
		}
	}

	public static Object getPropertyValue(Object ob,String property,String tag,String rep){
		BeanInfo info;
		Object rob=null;
		Object nrob=null;
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();			
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					if(pds[i].getPropertyType().equals(String.class)) {
						rob=pds[i].getReadMethod().invoke(ob,null);
						if(rob!=null) {
							nrob=StringManager.replaceAll((String)rob,tag,rep);
						}
					}else if(pds[i].getPropertyType().equals(Array.class)) {
						Array ar=(Array)pds[i].getReadMethod().invoke(ob,null);									
						if(ar!=null){
							for(int j=0 ;j<Array.getLength(ar);j++){	
								Array.set(ar,j,StringManager.replaceAll((String)Array.get(ar,j),tag,rep).trim());
							}
							nrob = ar;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			// TODO 自动生成 catch �?			
			throw new ExtendUnCheckException("取得bean属�?�出�?");
		}
		return nrob;
	}

	public static void setPropertyReValue(Object ob,String property ,String va){
		String tag = "'";
		String rep = "''";
		BeanInfo info;
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();	
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					if(pds[i].getPropertyType().equals(String.class)) {
						String str = StringManager.replaceAll((String)va,tag,rep);
						pds[i].getWriteMethod().invoke(ob,new Object[] {str.trim()});
					}else if(pds[i].getPropertyType().equals(Array.class)) {
						Array ar=(Array)pds[i].getReadMethod().invoke(va,null);									
						if(ar!=null){
							for(int j=0 ;j<Array.getLength(ar);j++){	
								Array.set(ar,j,StringManager.replaceAll((String)Array.get(ar,j),tag,rep).trim());
							}
							pds[i].getWriteMethod().invoke(ob,new Object[] {ar});
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			// TODO 自动生成 catch �?			
			throw new ExtendUnCheckException("设置bean属�?�出�?");
		}
	}

	public static Object getPropertyReValue(Object ob,String property){
		String tag = "'";
		String rep = "''";
		BeanInfo info;
		Object rob=null;
		Object nrob=null;
		try {
			info = Introspector.getBeanInfo(ob.getClass());		
			PropertyDescriptor[] pds=info.getPropertyDescriptors();			
			for (int i = 0; i < pds.length; i++) {
				if(pds[i].getDisplayName().equals(property)){
					if(pds[i].getPropertyType().equals(String.class)) {
						rob=pds[i].getReadMethod().invoke(ob,null);
						if(rob!=null) {
							nrob=StringManager.replaceAll((String)rob,tag,rep);
						}
					}else if(pds[i].getPropertyType().equals(Array.class)) {
						Array ar=(Array)pds[i].getReadMethod().invoke(ob,null);									
						if(ar!=null){
							for(int j=0 ;j<Array.getLength(ar);j++){	
								Array.set(ar,j,StringManager.replaceAll((String)Array.get(ar,j),tag,rep).trim());
							}
							nrob = ar;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			throw new ExtendUnCheckException("取得bean属�?�出�?");
		}
		return nrob;
	}
}
