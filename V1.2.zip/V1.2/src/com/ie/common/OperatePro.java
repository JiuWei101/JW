package com.ie.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Properties;
/**
 * 用于操作properties文件
 * @author Administrator
 */
public class OperatePro {
	public final static String CONFIGPROPERTIES = "config.properties";	//配置文件名
	public final static String DATEFORMAT = "dateFormat";	//时期时间格式
	public final static String BACKTIME = "backTime";	//时期时间格式
	public final static String VERSION = "version";			//版本号
	public final static String DATEPARAM = "dateParam";		//图片存储参数
	public final static String INVERSIONINDEX = "inversionParam";		//寻车子系统首页的文字
	public final static String PGSSERVERIP = "pgsServerIP";
	public final static String PGSSERVERPORT = "pgsServerPort";
	
	/**
	 * 获取config.properties参数的方法
	 */
	public String queryProperty(String file, String params){
		FileInputStream fis = null;
		String param = "";
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + file);
			Properties prop = new Properties();
			prop.load(fis);
			param = (String) prop.get(params);
		} catch (URISyntaxException e) {
			Log.log(e);
		} catch (FileNotFoundException e) {
			Log.log(e);
		} catch (IOException e) {
			Log.log(e);
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return param;
	}

	public String queryProperty(String params){
		return queryProperty(CONFIGPROPERTIES, params);
	}
	
}
