/**
 * 功能：将文件夹或文件打包成zip文件。
 * 说明：使用JAVA本身的ZIP API打包带有中文名称的文件(目录)会出现乱码,且winzip无法解压,
 * 		如果要解决此问题,可以将
 *	import java.util.zip.ZipOutputStream;
 *	import java.util.zip.ZipEntry;
 *  换为ant.jar中的API
 *	import org.apache.tools.zip.ZipEntry;
 *	import org.apache.tools.zip.ZipOutputStream;
 */
package com.ie.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.tools.zip.ZipFile;
public class ZipUtil {


	/**
	 * 功能：将文件或文件夹打包成zip文件。
	 * 参数：param1：待压缩的文件或文件夹路径；
	 *      param2：压缩包路径及文件名；
	 *      param3：是否保留下级文件夹；
	 * 返回值："success"执行成功；"failed"执行失败
	 */
	public static String CreateZipFile(String filePath, String zipFilePath, boolean isContainSubDir) {
		FileOutputStream fos = null;
	    ZipOutputStream zos = null;
	    try{
		    fos = new FileOutputStream(zipFilePath);
		    zos = new ZipOutputStream(fos);
		    return writeZipFile(new File(filePath), zos, "", isContainSubDir);
	    }
	    catch(FileNotFoundException e){
	    	e.printStackTrace();
	    	return "Msg_FileNotFoundException in ZipUtil.CreateZipFile()";
	    }
	    finally{
	    	try{
	    		if(zos != null){
	    			zos.close();
	    		}
		    }
	    	catch(IOException e){
	    		e.printStackTrace();
		    	return "Msg_IOException in ZipUtil.CreateZipFile().finally";
		    }
	    	
		    try{
		    	if(fos != null){
		    		fos.close();
		    	}
		    }
		    catch(IOException e){
		    	e.printStackTrace();
		    	return "Msg_IOException2 in ZipUtil.CreateZipFile().finally";
		    }
	   }
	}

	
	
	/**
	 * 功能：将文件或文件夹打包成zip文件。
	 * 参数：param1：待压缩的文件或文件夹路径；
	 *      param2：压缩包文件生成流；
	 *      param3：压缩包内文件夹路径前缀；
	 *      param4：是否保留下级文件夹；
	 */
	private static String writeZipFile(File f, ZipOutputStream zos, String hiberarchy, boolean isContainSubDir) {
		try{
			//对打包对象进行合法性校验
			if(f.exists()){//文件或文件夹存在
				if(f.isDirectory()){//是文件夹
					//对文件夹压缩时，压缩包内不含最外层的文件夹，传入false
					if(isContainSubDir){
						hiberarchy += f.getName() + "/";
					}
				    File[] fif = f.listFiles();
				    String tmp="";
				    for(int i = 0; i<fif.length; i++){
				    	tmp = writeZipFile(fif[i], zos, hiberarchy, true);//保留下层文件夹
				    	if(tmp.length()>0){
				    		return tmp;
				    	}
				    }
			    }
				else{//单个文件打包
					FileInputStream fis = null;
			        try{
				      fis = new FileInputStream(f);
				      ZipEntry ze = new ZipEntry(hiberarchy + f.getName());
				      zos.putNextEntry(ze);
				      
				      /* byte[] b = new byte[1024];//这种写法当最后一次读取的不足1024时仍然会写入1024造成加密后的文件与源文件有差异
				      while (fis.read(b) != -1) {
				       zos.write(b);
				       b = new byte[1024];
				      }*/
				      
				      byte[] b = new byte[1024];
				      int count = 0; 
				      while( (count = fis.read(b))!=-1){
				      	zos.write(b,0,count); //处理最后一次写入不足1024的情况，避免打包失真
				      	b = new byte[1024];
				      }
				      
				      /*
				      int c = 0;
				      while( (c = fis.read()) != -1){ //这种写法读入的太慢
				    	  zos.write(c); 
				      }
				      */
				      
				      
				    }
			        catch (FileNotFoundException e) {
				    	e.printStackTrace();
				    	return "Msg_FileNotFoundException:向zip包中写入文件"+f.getName()+"时异常！";
				    }
			        catch (IOException e) {
				    	e.printStackTrace();
				    	return "Msg_IOException:向zip包中写入文件"+f.getName()+"时异常！";
				    }
			        finally{
				    	try{
					    	if(fis != null){
					    		fis.close();
				    		}
					    	/*
					    	if(zos != null){
					    		zos.close();
				    		}*/
					    	
					    }catch(IOException e) {
					    	e.printStackTrace();
					    	return "Msg_IOException:向zip包中写入文件"+f.getName()+"的finally处理时异常！";
					    }
				    }
			   }
			}
			else{
		    	return "要打包成zip文件的文件或文件夹"+f.getName()+"不存在";//"Msg_FileOrDirNotExist";
			}
		}
		catch (Exception e) {
	    	e.printStackTrace();
	    	return "Msg_Exception:向zip包中写入文件"+f.getName()+"时异常！";
	    }
		return "";
	}
	
	
	
	
	/**
	 * 功能：将本地的zip包解压到指定路径下。
	 * 参数：param1：解压到的文件夹；
	 *      param2：待解压的文件*.zip,带路径；
	 * 返回：list，list0=压缩包中的文件名信息的list；list1=压缩包中的文件路径信息的list；
	 */
	public static List UnzipFile(String destDir, String zipFilePath) throws Exception
	{		        	System.out.println("=====in UnzipFile,destDir="+destDir);

	    List reList = new ArrayList();//返回信息
		List photoFileNameList = new ArrayList();//返回压缩包中的文件名信息
		List photoFilePathList = new ArrayList();//返回压缩包中的文件路径信息
	    try
	    {
			File zipfile = new File(zipFilePath); 
			if(!zipfile.exists()){
	            throw new Exception("创建待解压的文件[" +zipfile+ "]失败!");
			}

	        File parent = new File(destDir);
	        if(!parent.exists() && !parent.mkdirs()){ 
	            throw new Exception("创建解压目录[" +parent.getAbsolutePath()+ "]失败!");
	        }
	        
	        ZipInputStream zis = new ZipInputStream(new FileInputStream(zipfile));
	        ZipEntry ze = zis.getNextEntry();  
	       // String subDirName="";
	        while(ze!=null){ System.out.println("=====ze="+ze);
        		String name = ze.getName(); //图片文件名，不含路径
        		System.out.println("=====name="+name);
	        	if(ze.isDirectory()){ 
		        	name = name.substring(0, name.length()-1); 
		        	
		        	System.out.println("=====ze.isDirectory()="+destDir + name);
		        	File f = new File(destDir + name); 
		        	try { 
		        		f.mkdirs(); 
		        	}catch (Exception e) { 
		        		e.printStackTrace(); 
		        	} 
	        	} 
	        	else{ 
	        		if(name.indexOf("/") > 0){ 
	        			//System.out.println("=====jjjj="+destDir + name.substring(0, name.lastIndexOf("/")));
		        		File folder = new File(destDir + name.substring(0, name.lastIndexOf("/"))); 
		        		if(!folder.exists()){
		        			System.out.println("=====!folder.exists()");
			        		try{ 
			        			folder.mkdirs(); 
			        		} 
			        		catch (Exception e) { 
			        			e.printStackTrace(); 
			        		} 
		        		} 
		        		else{
		        			
		        		}
	        		}
	        	}
	        	
	        
	        
	        
//	        	String name = ze.getName(); //图片文件名，不含路径
	            photoFileNameList.add(name); //图片文件名
	            photoFilePathList.add(destDir + name); 

	            File child = new File(parent, name);
	            FileOutputStream output = new FileOutputStream(child);
	            byte[] buffer = new byte[1024];//10240
	            int bytesRead = 0;
	            while((bytesRead = zis.read(buffer)) > 0){
	                output.write(buffer, 0, bytesRead);
	            }
	            output.flush();
	            output.close();
	            ze = zis.getNextEntry();
	         }
	         zis.close();
	         if(photoFileNameList!=null && photoFileNameList.size()>0){
	     	    reList.add(photoFilePathList);
	    	    reList.add(photoFileNameList);
	         }
	    }
	    catch (IOException e)
	    {
	    	 e.printStackTrace();
	    }
	    return reList;
	}
	
	/**
	 * 解压缩功能. 将ZIP_FILENAME文件解压到ZIP_DIR目录下.
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static void upZipFile(String ZIP_FILENAME,String ZIP_DIR) throws Exception {
		ZipFile zfile = new ZipFile(ZIP_FILENAME);
		Enumeration zList = zfile.getEntries();
		org.apache.tools.zip.ZipEntry ze = null;
		byte[] buf = new byte[1024];
		while (zList.hasMoreElements()) {
			ze = (org.apache.tools.zip.ZipEntry) zList.nextElement();
			if (ze.isDirectory()) {
				File f = new File(ZIP_DIR + ze.getName());
				f.mkdir();
				continue;
			}
			OutputStream os = new BufferedOutputStream(new FileOutputStream(
					getRealFileName(ZIP_DIR, ze.getName())));
			InputStream is = new BufferedInputStream(zfile.getInputStream(ze));
			int readLen = 0;
			while ((readLen = is.read(buf, 0, 1024)) != -1) {
				os.write(buf, 0, readLen);
			}
			is.close();
			os.close();
		}
		zfile.close();
	}
	
	
	/**
	 * 给定根目录，返回一个相对路径所对应的实际文件名.
	 * 
	 * @param baseDir
	 *            指定根目录
	 * @param absFileName
	 *            相对路径名，来自于ZipEntry中的name
	 * @return java.io.File 实际的文件
	 */
	private static File getRealFileName(String baseDir, String absFileName) {
		String[] dirs = absFileName.split("/");
		File ret = new File(baseDir);
		if (dirs.length > 1) {
			for (int i = 0; i < dirs.length - 1; i++) {
				ret = new File(ret, dirs[i]);
			}
			if (!ret.exists())
				ret.mkdirs();
			ret = new File(ret, dirs[dirs.length - 1]);
			return ret;
		}
		ret = new File(ret, dirs[dirs.length - 1]);
		return ret;
	}	

	
}

