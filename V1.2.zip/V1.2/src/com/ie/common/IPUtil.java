package com.ie.common;

public class IPUtil {
	
	public IPUtil(){
		
	}
	
	/**
	 * 将ip转化为4字节整数
	 * @param ip
	 * @return
	 */
	public static String IptoInt(String ip){
		String ipInt = "";
		byte[] temp = new byte[4];
		try{
			String[] ipArr = ip.split("\\.");
			temp[0] = (byte)(Integer.parseInt(ipArr[0]) & 0xFF);
			temp[1] = (byte)(Integer.parseInt(ipArr[1]) & 0xFF);
			temp[2] = (byte)(Integer.parseInt(ipArr[2]) & 0xFF);
			temp[3] = (byte)(Integer.parseInt(ipArr[3]) & 0xFF);
			long addr = temp[3] & 0xFF;
		    addr |= ((temp[2] << 8) & 0xFF00);
		    addr |= ((temp[1] << 16) & 0xFF0000);
		    System.out.println(addr);
		    addr |= ((temp[0] << 24) & 0xFF000000);
		    //System.out.print(addr);
		    ipInt = String.valueOf(addr);
		}catch(Exception e){
			e.printStackTrace();
		}
		return ipInt;
	}
	
    /**  
     * ipInt -> byte[]  
     * @param ipInt  
     * @return byte[]  
     */  
    public static byte[] intToBytes(int ipInt) {   
        byte[] ipAddr = new byte[4];   
        ipAddr[0] = (byte) ((ipInt >>> 24) & 0xFF);   
        ipAddr[1] = (byte) ((ipInt >>> 16) & 0xFF);   
        ipAddr[2] = (byte) ((ipInt >>> 8) & 0xFF);   
        ipAddr[3] = (byte) (ipInt & 0xFF);   
        return ipAddr;   
    }   
  
    /**  
     * 把int->ip地址  
     * @param ipInt  
     * @return String  
     */  
    public static String intToIp(int ipInt) {   
        return new StringBuilder().append(((ipInt >> 24) & 0xff)).append('.')   
                .append((ipInt >> 16) & 0xff).append('.').append(   
                        (ipInt >> 8) & 0xff).append('.').append((ipInt & 0xff))   
                .toString();   
    } 
	public static void main(String[] args) {
		System.out.println(IptoInt("192.168.11.11"));
		//System.out.println();
	}
}
