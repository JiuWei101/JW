/**
 * Copy Right Information   : Forsoft 
 * Project                  : KJGL
 * JDK version used         : jdk1.5
 * Comments                 : �߼����ID����ࣨʱ�䣫�����
 * Version                  : 1.0
 * create date              : 2008.5.15
 * author                   ��
*/
package com.ie.common;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PrimaryId {
	
	/**
	 * Description :����߼����ID
	 * @return String
	 */
    private static SimpleDateFormat df=new SimpleDateFormat("yyyyMMddHHmmss");
    private static SimpleDateFormat yyyymmdd=new SimpleDateFormat("yyyy-MM-dd");
    private static SimpleDateFormat yyyymm=new SimpleDateFormat("yyyyMM");
    private static NumberFormat nf = NumberFormat.getInstance();
    static{
        //������С����λ
        nf.setMinimumIntegerDigits(6);
        nf.setGroupingUsed(false);
    }
    private static long postfix = 0;//������3λ
	public static synchronized String getId(){
		String id="";
		Date date=new Date();
		id=df.format(date);
		
		if(postfix==999999)
		{
		    postfix = 0;
		}else
		{
		    postfix++;
		}
//		double x = Math.random();
//		double y = Math.random();		
//		id=id+((Double.toString(x)).substring(2,5)+Double.toString(y).substring(2,5));		
		return id+nf.format(postfix);
	}
	public static synchronized String getKeyId(){
		String id="";
		Date date=new Date();
		id=df.format(date);
		
		if(postfix==999999)
		{
		    postfix = 0;
		}else
		{
		    postfix++;
		}
//		double x = Math.random();
//		double y = Math.random();		
//		id=id+((Double.toString(x)).substring(2,5)+Double.toString(y).substring(2,5));		
		return id+nf.format(postfix);
	}
	/**
     * Description :取当天日期格式  yyyy-MM-dd
     * @param  :
     * @return :当天日期格式  yyyy-MM-dd
     * @throws :Exception
     */
	public static String getToday(){
		String today="";
		Date date=new Date();
		today=yyyymmdd.format(date);
		return today;
	}
	/**
     * Description :取当月日期格式  yyyymm
     * @param  :
     * @return :当天日期格式  yyyymm
     * @throws :Exception
     */
	public static String getMonth(){
		String month="";
		Date date=new Date();
		month=yyyymm.format(date);
		return month;
	}
	
	/**
	 * Description :����������ID
	 */
	public static void main(String[] args){
		/*for(int i=0;i<2000;i++){
			System.out.println(i+":"+PrimaryId.getId());	
			//System.out.println(PrimaryId.getId().length());	
		}*/
	/*	 SimpleDateFormat   myFormatter   =   new   SimpleDateFormat("yyyy-MM-dd");   
		    
		  java.util.Date date;
		  java.util.Date mydate;
		try {
			date = myFormatter.parse("2003-05-1");
			mydate = myFormatter.parse("2003-05-02");
			long     day=(date.getTime()-mydate.getTime())/(24*60*60*1000);   
			Date tomorrow  =new   java.util.Date(date.getTime()+(1000*60*60*24));
			System.out.println("相差的日期:"   +   tomorrow);   
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    */ 
		    
		System.out.println(PrimaryId.getId());	    
		    				
	}
}
