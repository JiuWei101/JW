package com.ie.common;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateCompare {

	/**
	 * 
	 * @Description : 比较两个String格式的时间
	 * @param : @param sDate
	 * @param : @param eDate
	 * @param : @return  
	 * @return : int 
	 * @throws : 
	 * @author : 0917
	 */
	public boolean dateCompare(String sDate,String eDate){
		
		java.text.DateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
		java.util.Calendar c1=java.util.Calendar.getInstance();
		java.util.Calendar c2=java.util.Calendar.getInstance();

		try{
			c1.setTime(df.parse(sDate));
			c2.setTime(df.parse(eDate));
		}
		catch(java.text.ParseException e){
			System.err.println("格式不正确");
		}

		int result = c1.compareTo(c2);
		if(result>0)
			return true;
		else
			return false;
	}
	
	/**
	 * 计算两个String格式的时间的时间差
	 */
	public long dateDelay(String sDate,String eDate) throws ParseException{
		java.text.DateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d1 = df.parse(sDate);
		Date d2 = df.parse(eDate);
		long diff = d1.getTime() - d2.getTime();
		
		return diff;
	}
	
	/**
	 * @Description : 将毫秒转化为hour类型,不超过一天
	 * @param : @param data
	 * @param : @return  
	 * @return : long 
	 * @throws : 
	 * @author : 0917
	 */
	public String msToTime(double data){
		DecimalFormat df=new DecimalFormat("0.00");
		String hour=df.format(data/(60*60*1000));
		return hour;
	}
	
	/**
	 * 
	 * @Description : 将date转化为毫秒
	 * @param : @param date
	 * @param : @return
	 * @param : @throws ParseException  
	 * @return : long 
	 * @throws : 
	 * @author : 0917
	 */
	public long TimeToMS(String date) throws ParseException{
		java.text.DateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar calendar = new GregorianCalendar();
		Date d = df.parse(date);
		calendar.setTime(d);
		
		return calendar.getTimeInMillis()+8*60*60*1000;
	}
	
	public long TimeToMSDay(String date) throws ParseException{
		java.text.DateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd");
		Date d = df.parse(date);
		return d.getTime();
	}
	
	/**
	 * 
	 * @Description : 将时分秒转换为毫秒
	 * @param : @param date
	 * @param : @return  
	 * @return : long 毫秒
	 * @throws : 
	 * @author : mingm
	 * @throws ParseException 
	 */
	public long getMSTime(String date){
		int hour = Integer.parseInt(date.substring(11,13));
		int minute = Integer.parseInt(date.substring(14,16));
		int second = Integer.parseInt(date.substring(17,19));
		
		long ms = (hour*60*60 + minute*60 + second)*1000;
		return ms;
	}
	
	/**
	 * 
	 * @Description : 将毫秒转化为日期
	 * @param : @param date
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 1964919885@qq.com
	 */
	public String MSToTime(long date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sb = sdf.format(date);
		return sb;
	}
	
	/**
	 * 
	 * @Description : 当前时间加5分钟
	 * @param : @param _sDate
	 * @param : @return
	 * @param : @throws ParseException  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String addTime(String _sDate) throws ParseException{
		java.text.DateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d1 = df.parse(_sDate);
		long diff = d1.getTime() + 300000;

		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(diff);
		
		return df.format(calendar.getTime());
	}
}
