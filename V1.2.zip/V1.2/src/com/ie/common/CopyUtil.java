package com.ie.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class CopyUtil {
	
	//深拷贝2:序列化|反序列化方法
    public static Object copyBySerialize(Object src) throws IOException, ClassNotFoundException{
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(byteOut);
        out.writeObject(src);
    
        ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray());
        ObjectInputStream in =new ObjectInputStream(byteIn);
        Object dest = in.readObject();
        return dest;
    }
    
    //深拷贝1：递归方法
    public void copy(List src,List dest){
        for (int i = 0 ;i < src.size() ; i++) {
            Object obj = src.get(i);            
            if (obj instanceof List){
                dest.add(new ArrayList());
                    copy((List)obj,(List)((List)dest).get(i));
            }else{
                dest.add(obj);
            }
        }
        
    }
    /**
     * 求两个字符串数组的差集
     * @param src
     * @param des
     * @return
     */
    public static Map minusTwoStrArr(String[] src, String[] des){
    	Map map = new HashMap();
    	LinkedList<String> list = new LinkedList<String>();
    	LinkedList<String> comm = new LinkedList<String>();
    	LinkedList<String> desl = new LinkedList<String>();
    	for(String s : src){
    		if(!list.contains(s)){
    			list.add(s);
    		}
    	}
    	for(String d : des){
    		if(list.contains(d)){
    			comm.add(d);
    			list.remove(d);
    		}else{
    			if(!comm.contains(d)){
    				desl.add(d);
    			}
    		}
    	}
    	map.put("srcl", list.toArray(new String[]{}));
    	map.put("desl", desl.toArray(new String[]{}));
    	return map;
    }
    
    public static String generateStr(String[] src,String space){
    	StringBuffer sb = new StringBuffer();
    	if(src.length > 0){
    		for(String s : src){
    			sb.append(s).append(space);
    		}
    	}
    	if(sb.length() > 0){
    		sb = sb.deleteCharAt(sb.length() - 1);	
    	}
    	return sb.toString();
    }
}
