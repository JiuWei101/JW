/*
 * Created on 2005-7-12
 * 将标准编码取出存入application中。
 */

package com.ie.common;


import java.io.IOException;
import javax.annotation.Resource;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;
import com.ie.its.monitor.MonitorService;
import com.ie.alarm.SendMessage;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.ie.its.udworkingstatisticsgraph.UDWorkingStatisticsGraphService;

@Component("LoadCodesTimerServlet")
public class LoadCodesTimerServlet extends HttpServlet implements ServletContextAware
{
	private SendMessage sendmess = new SendMessage();
	private static final long serialVersionUID = 1L;
	@Resource
	private DataSource ds;
	
	private UDWorkingStatisticsGraphService udWorkingStatistics;
	
	public LoadCodesTimerServlet(){
		udWorkingStatistics = new UDWorkingStatisticsGraphService();
	}

	
    /**
     * @return 
     * @see HttpServlet#HttpServlet()
     */
    public void InitialServlet() {
       // super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		getRateTimer();
		getRateTimer2();
		getRateTimer3();
		getSeachMachineStaTimer();
		try {
			getRateTimer4();
			getRateTimer5();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //---by:0917
	}
	/**
	 * 定时遍历查询机状态
	 */
	private void getSeachMachineStaTimer() {
		// TODO Auto-generated method stub
		Util.timerMachine.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				getRateMachine();
			}
		}, 1000* 10, 1*30*1000 );
	}

	protected void getRateMachine() {
		try{
			Log.log("-读取查询机状态--");
			MonitorService.searchMachineTask(ds);
		}catch(Exception e){
			e.printStackTrace();
			Log.log("[读取查询机状态进程异常]"+e);
		}
	}

	//	private final Timer timer = new Timer(false);
	private final Timer messTimer = new Timer(false);
	private final Timer logToHisTimer = new Timer(false);
	private final Timer hisToStatisticsTimer = new Timer(false);
	private void getRateTimer() {
		logToHisTimer.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				getRateDo();
			}
		}, 1000* 60, 60*60*1000 );
	}
	private void getRateTimer2() {
		hisToStatisticsTimer.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				getRateDo2();
			}
		}, 3000 * 60, 60*60*1000 );
	}
	
	private void getRateTimer3() {
		messTimer.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				Alarm();
			}
		}, 1000*10*60, 1000*60*60);
	}
	
	private void getRateTimer4() throws ParseException {    //将探测器状态从p_controller保存到p_ctrlerstatus表中---getRateTimer()---by:0917
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		String curDate = DateUtil.getCurDateTime();
		final Date startDate = df.parse(curDate);
		
		OperatePro op = new OperatePro();
		String timeStr = op.queryProperty("statisticsTime");
		
		long time = Long.valueOf(timeStr);
		
		Util.timer.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				long excuteTime = this.scheduledExecutionTime();
				getRateDo4(excuteTime);
			}
		}, startDate, time);   //从当前时间开始开始，没隔5分钟执行一次保存数据
	}
	private void getRateTimer5() throws ParseException {   //每天零点采集探测器运行状态
		String curDate = DateUtil.getNextDay(DateUtil.getCurDate(), "1");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		final Date startDate = df.parse(curDate);
		Util.timer.scheduleAtFixedRate(new TimerTask(){
			public void run(){
				long excuteTime = this.scheduledExecutionTime();
				getRateDo5(excuteTime);
			}
		}, startDate, 1000*60*60*24);
	}
	
	protected void getRateDo() {
		try{
			Log.log("-从LOG到HIS--"+ds);
			MonitorService.moveLogToHis(ds);
			
		}catch(Exception e){
			e.printStackTrace();
			Log.log("[后台进程异常]"+e);
		}
	}
	protected void getRateDo2() {
		try{
			Log.log("--从HIS到明细-"+ds);
			MonitorService.rateTask(ds);
		}catch(Exception e){
			Log.log("[后台进程异常]"+e.getMessage());
		}
	}
	
	protected void getRateDo4(long _excuteTime) {//将探测器状态从p_controller保存到p_ctrlerstatus表中---getRateDo()---by:0917
		try{
			Log.log("--从HIS到明细-"+ds);
			udWorkingStatistics.makeStatusData(ds,_excuteTime);
		}catch(Exception e){
			Log.log("[后台进程异常]"+e.getMessage());
		}
	}
	protected void getRateDo5(long _excuteTime) {//每天零点采集探测器运行状态---getRateDo()---by:0917
		try{
			Log.log("--从HIS到明细-"+ds);
			udWorkingStatistics.makeWorkingData(ds,_excuteTime);
		}catch(Exception e){
			Log.log("[后台进程异常]"+e.getMessage());
		}
	}
	
	@Override
	public void setServletContext(ServletContext arg0) {
		// TODO Auto-generated method stub
		
	}

	protected void Alarm(){
		try{
			int i= sendmess.RegisterSoftware(ds);
			if(i==0)
			{
				Log.log("--发送报警短信--");
				sendmess.BatchSendSMS(ds);
			}
			else{
				Log.log(new Date()+"短信服务故障:"+ Convert(i));
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public String Convert(int err){
		String rstr = "";
			switch(err){
			case 10: rstr = "注册序列号失败";break;
			case 303: rstr = "网络超时或者网络故障";break;
			case 305: rstr = "错误返回值";break;
			case 999: rstr = "操作太频繁了";break;
			}
			return rstr;
	}
}
