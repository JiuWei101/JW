/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 扩展运行时异常类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：huangmingwei
 * Modified By              : ghc
*/
package com.ie.common;

public class ForKeyException extends RuntimeException {

	public ForKeyException() {
		super();
	}

	public ForKeyException(String s) {
		super(s);
	}

}
