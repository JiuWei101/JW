/**  
 * @Project : ParkConector
 * @Title: CommonUtil.java
 * @Package : com.ake.util
 * @Description: 
 * @author: xingzq@ake.com.cn
 * @Date: 2014-9-3 上午10:11:11
 * @version V1.0.0
 * Copyright (c) 2014,ake All Rights Reserved
 */
package com.ie.common;

import java.util.Date;

/**
 * @Description: 通用工具类
 * @auth: xingzq@ake.com.cn
 * @data: 2014-9-3 上午10:11:11
 * @version:
 * 
 */
public class CommonUtil {

	private static String DEVICE_ID = null;
	private static String PARK_ID=null;
	/**
	 * 
	 * @Description : 16进制字符串转byte数组
	 * @param : @param hexString
	 * @param : @return
	 * @return : byte[]
	 * @throws :
	 * @author : xingzq@ake.com.cn
	 */
	public static byte[] hexStr2ByteArray(String hexString) {
		hexString = hexString.toLowerCase();
		final byte[] byteArray = new byte[hexString.length() / 2];
		int k = 0;
		for (int i = 0; i < byteArray.length; i++) {
			byte high = (byte) (Character.digit(hexString.charAt(k), 16) & 0xff);
			byte low = (byte) (Character.digit(hexString.charAt(k + 1), 16) & 0xff);
			byteArray[i] = (byte) (high << 4 | low);
			k += 2;
		}
		return byteArray;
	}

	/**
	 * 
	 * @Description : 字符串转ASCII码(16进制表示)
	 * @param : @param value
	 * @return : String
	 * @throws :
	 * @author : xingzq@ake.com.cn
	 */
	public static String stringToAscii(String value) {
		StringBuffer sbu = new StringBuffer();
		char[] chars = value.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			sbu.append(Integer.toHexString((int) chars[i]));
		}
		return sbu.toString();
	}

	/**
	 * 
	 * @Description : ASCII码(16进制表示)转STRING
	 * @param : @param value
	 * @param : @return
	 * @return : String
	 * @throws :
	 * @author : xingzq@ake.com.cn
	 */
	public static String asciiToString(String value) {
		String changeData = "";
		try {
			String hexData = value;
			int i;
			char stringData;
			int intData;

			for (i = 0; i < hexData.length(); i = i + 2) {
				String tempData = hexData.substring(i, i + 2);
				intData = Integer.parseInt(tempData, 16);
				stringData = (char) intData;
				changeData += (new Character(stringData)).toString();
			}
			return changeData;
		} catch (RuntimeException e) {
			return changeData = e.getMessage();
		}
	}

	public static void main(String[] args) {
		System.out.println(CommonUtil.stringToAscii("58002426536"));
		System.out.println(CommonUtil.asciiToString("3538303032343236353336"));
	}

	/**
	 * 
	 * @Description : 拼装成符合停车场上传数据格式的字符串
	 * @param : @param book
	 * @param : @param booked_remainder
	 * @param : @param normal
	 * @param : @param normal_remainder
	 * @param : @return
	 * @return : String
	 * @throws :
	 * @author : xingzq@ake.com.cn
	 */
	public static String concatenateParkString(int book,
			int booked_remainder, int normal, int normal_remainder, String park_id) {
		String milliseconds = String.valueOf(new Date().getTime());
		if (milliseconds.length() % 2 == 1) {
			milliseconds = "0" + milliseconds;
		}
		// 停车点id(16个字节) VIP总车位(3个字节) VIP剩余车位(3个字节) 对外开放的车位(3个字节) 对外开放的剩余车位(3个字节)
		// 当前毫秒数(7个字节)
		String result = "DD" + park_id + str2Hex(book)
				+ str2Hex(booked_remainder)
				+ str2Hex(normal)
				+ str2Hex(normal_remainder) + milliseconds
				+ "DD";
		return result;
	}
	
	public static String concatenateDTUString(String parkString, String deviceId) {
		// 7B（总体开始符号） 09（表示上报） 0035（表示数据长度） 3532383230303033303137
		// （设备号）DD（停车场数据开始符号） 7781222830A57095286C0B18589D52D4（UUID）
		// 000001(VIP总车位数) 000000（VIP剩余车位数） 000176（停车场总车位数） 000115
		// （停车场剩余车位数）01409625428500（上报时间） DD（停车场数据结束符号） 7B（总体结束符号）
		String result = "7B090035" + CommonUtil.stringToAscii(deviceId) + parkString + "7B";
		return result;
	}

	/**
	 * 转换成3个字节的16进制数
	 * 
	 * @param num
	 * @return
	 * 
	 * @author xieyj
	 * @date:Created on 2014-5-9 上午10:53:45
	 */
	public static String str2Hex(int num) {
		String hex = Integer.toHexString(num);
		if (6 - hex.length() > 0) {
			int leng = 6 - hex.length();
			for (int i = 0; i < leng; i++) {
				hex = "0" + hex;
			}
		}
		return hex;
	}
}
