package com.ie.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

public class GetFileInfo {
	/**
	 * 获取文件内容
	 * @param infoPath 文件路径
	 * @return 内容
	 */
	public static ByteArrayOutputStream getInfo(String infoPath) {
		ByteArrayOutputStream bout = null;
		try{
			File file  = new File(infoPath);
			FileInputStream is = new FileInputStream(file);
			bout = new ByteArrayOutputStream();
			byte[] tmpbuf = new byte[1024];
			int count = 0;
			while ((count = is.read(tmpbuf)) != -1){
				bout.write(tmpbuf, 0, count);
				tmpbuf = new byte[1024];
			}
			is.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return bout;
	}
	
	/**
	 * 获取文件内容
	 * @param infoPath 文件路径
	 * @return 内容
	 */
	public static String getInfos(String infoPath) {
		ByteArrayOutputStream bout = null;
		try{
			File file  = new File(infoPath);
			FileInputStream is = new FileInputStream(file);
			bout = new ByteArrayOutputStream();
			byte[] tmpbuf = new byte[1024];
			int count = 0;
			while ((count = is.read(tmpbuf)) != -1){
				bout.write(tmpbuf, 0, count);
				tmpbuf = new byte[1024];
			}
			is.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return bout.toString();
	}
}
