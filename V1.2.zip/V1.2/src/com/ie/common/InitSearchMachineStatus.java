/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 读取配置文件XML信息，装载到Application中。
 *                            Application状态为应用程序提供了一个全局的状态。所有客户都可以使用该状态。
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   : 
 * Modified By              : ghc
 */
package com.ie.common;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import com.ie.frame.JdbcTemplateExtend;
import com.ie.its.inversionsearch.SerachMachineOperation;

public class InitSearchMachineStatus extends HttpServlet implements Servlet {
	public void init() throws ServletException {
		super.init();
		SerachMachineOperation searchMachine = new SerachMachineOperation();
		JdbcTemplateExtend jt = new JdbcTemplateExtend(searchMachine.getDataSource());
		String sqls = "select IP from p_pathnodeinfohead where IP is not NULL";
		JSONArray arr = jt.queryForJSONArrayExt(sqls);  
		for(int i=0;i<arr.size();i++){
			String machineId=arr.getJSONObject(i).getString("IP").toString();
			Log.log("--将machineId放进SearchMachineStatus中------"+machineId);
			SerachMachineOperation.getSearchMachineStatus().put(machineId, 1);
		}
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
	}

}

