/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 读取配置文件XML信息，装载到Application中。
 *                            Application状态为应用程序提供了一个全局的状态。所有客户都可以使用该状态。
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   : 
 * Modified By              : ghc
*/
package com.ie.common;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ie.frame.ExtendData;
import com.ie.its.login.LanguageData;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

public class InitLangServlet extends HttpServlet implements Servlet {

	public void init() throws ServletException {
		super.init();
		
		initMapContext();
	}
	
	public static void initMapContext() throws ServletException {
//		super.init();
		Connection conn = null;
		Statement stmt = null;
		try {
//			Class.forName("com.mysql.jdbc.Driver"); 			
//		    conn=  DriverManager.getConnection("jdbc:mysql://10.5.31.251:3306/its","its","its"); //获得连接
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
			BasicDataSource bds = (BasicDataSource) applicationContext.getBean("dataSource");
//			JdbcTemplate jdbc = bds.getConnection();  
			conn = bds.getConnection();
			stmt=  conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE); //创建statement
			String sql = "SELECT distinct(lang) lang FROM sys_lang_switch";
			ResultSet rs = stmt.executeQuery(sql);
			List langlist = new ArrayList();
			while(rs.next()){
				langlist.add(rs.getString("lang"));
			}
			
	//		ExtendData.setLang_list(langlist);
			Map map = new HashMap();
			for(int i=0;i<langlist.size();i++){
				List type_list = new ArrayList();
				String sql1 = "select distinct(code_type) code_type from sys_lang_switch where lang='"+langlist.get(i)+"'";
				ResultSet rs1 = stmt.executeQuery(sql1);
				while(rs1.next()){
					type_list.add(rs1.getString("code_type"));
				}
				Map map1 = new HashMap();
				for(int j=0;j<type_list.size();j++){
					List list = new ArrayList();
					String sql2 = "select code_key,code_value from sys_lang_switch where lang='"+langlist.get(i)+"' and code_type = '"+type_list.get(j)+"'";
					ResultSet rs2 = stmt.executeQuery(sql2);
					Map map2 = new HashMap();
					while(rs2.next()){
						map2.put(rs2.getString("code_key"), rs2.getString("code_value"));
					}
					map1.put(type_list.get(j), map2);
				}
				map.put(langlist.get(i), map1);
			}
			
			ExtendData.setLang_switch(map);
			System.out.println("map=="+map);
			
			String sqls = "select code_id,code_name,remark,lang_img,login_img,username_img,password_img,logout_img from sys_language";
			System.out.println("slqs=="+sqls);
			ResultSet rss = stmt.executeQuery(sqls);
			List lists = new ArrayList();
			while(rss.next()){
				LanguageData cd = new LanguageData();
				cd.setCode_id(rss.getString("code_id"));
				cd.setCode_name(rss.getString("code_name"));
				cd.setRemark(rss.getString("remark"));
				cd.setLang_img(rss.getString("lang_img")); 
				cd.setLogin_img(rss.getString("login_img"));
				cd.setUsername_img(rss.getString("username_img"));
				cd.setPassword_img(rss.getString("password_img"));
				cd.setLogout_img(rss.getString("logout_img"));
				lists.add(cd);
			}
			ExtendData.setLang_list(lists);
			stmt.close();
			conn.close();
		//	request.getSession().setAttribute("map", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(stmt != null){
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
			}
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
			}
		}
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		init();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		init();
	}

}