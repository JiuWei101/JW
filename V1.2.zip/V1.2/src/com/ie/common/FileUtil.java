/**
 * 功能：复制文件或文件夹；删除文件或文件夹；
 * 
 * 【复制文件或文件夹】
 * 利用Java复制文件到处都可以用到，这里总结了一个类供大家参考。里面总共有两个方法： 
 * public static boolean copyFile(String srcFileName, String destFileName,boolean overlay); 
 * public static boolean copyDirectory(String srcDirName, String destDirName,boolean overlay) ; 
 * 其中： 
 * srcFileName 待复制的文件名 
 * descFileName  目标文件名 
 * overlay  如果目标文件存在，是否覆盖 
 * 如果复制成功返回true，否则返回false 
 */
package com.ie.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;

//import javax.swing.JOptionPane;

public class FileUtil {


	public static String MESSAGE = "";
	
	
	/**
	 * 功能：创建文件夹
	 * @return
	 * @throws Exception
	 */
	public static void mkdir(String mkdirName)
    {
		try{
			File   dirFile = new File(mkdirName);
			boolean bFile   = dirFile.exists();
			if( bFile == true ){
				System.out.println("The folder exists."+mkdirName);
			}else{
				System.out.println("The folder["+mkdirName+"] do not exist,now trying to create a one...");
				bFile = dirFile.mkdir();
				if( bFile == true ){
					System.out.println("Create successfully!");
					
				}else{
					System.out.println("Disable to make the folder,please check the disk is full or not.");
				}
			}
		}
		catch(Exception err){
			System.err.println("ELS - Chart : ");
			err.printStackTrace();
		}
    }
	
	
	
	

 	/**
 	 * 复制单个文件
 	 * 
 	 * @param srcFileName
 	 *            待复制的文件名
 	 * @param descFileName
 	 *            目标文件名
 	 * @param overlay
 	 *            如果目标文件存在，是否覆盖
 	 * @return 如果复制成功返回空串""，否则返回错误信息串
 	 */
 	public static String copyFile(String srcFileName, String destFileName, boolean overlay){
 		String reMsg = ""; //返回信息串
 		File srcFile = new File(srcFileName);

 		// 判断源文件是否存在
 		if(!srcFile.exists()){
 			reMsg = "源文件不存在：" + srcFileName + "！";
 			System.out.println(reMsg);
 			return reMsg;
 		}else if(!srcFile.isFile()){
 			reMsg = "复制文件失败，源文件不是一个文件：" + srcFileName + "！";
 			System.out.println(reMsg);
 			return reMsg;
 		}

 		// 判断目标文件是否存在
 		File destFile = new File(destFileName);
 		if(destFile.exists()){
 			// 如果目标文件存在并允许覆盖
 			if(overlay){
 				// 删除已经存在的目标文件，无论目标文件是目录还是单个文件
 				new File(destFileName).delete();
 			}
 		}else{
 			// 如果目标文件所在目录不存在，则创建目录
 			if(!destFile.getParentFile().exists()){
 				// 目标文件所在目录不存在
 				if(!destFile.getParentFile().mkdirs()){
 					// 复制文件失败：创建目标文件所在目录失败
 		 			reMsg = "复制文件失败：创建目标文件所在目录失败！";
 		 			System.out.println(reMsg);
 		 			return reMsg;
 				}
 			}
 		}

 		//复制文件
 		int byteread = 0; // 读取的字节数
 		InputStream in = null;
 		OutputStream out = null;

 		try{
 			in = new FileInputStream(srcFile);
 			out = new FileOutputStream(destFile);
 			byte[] buffer = new byte[1024];

 			while((byteread = in.read(buffer)) != -1){
 				out.write(buffer, 0, byteread);
 			}
 			return "";
 		}catch(FileNotFoundException e){
 			reMsg = "复制文件失败：FileNotFoundException！";
		 	System.out.println(reMsg);
		 	return reMsg;
 		}catch(IOException e){
	 		reMsg = "复制文件失败：IOException！";
		 	System.out.println(reMsg);
		 	return reMsg;
 		}finally{
 			try{
 				if(out != null)
 					out.close();
 				if(in != null)
 					in.close();
 			}catch(IOException e){
 				e.printStackTrace();
		 		reMsg = "复制文件失败：finally IOException！";
 		 		System.out.println(reMsg);
 		 		return reMsg;
 			}
 		}
 	}
 	
 	
 	

 	/**
 	 * 复制整个目录的内容
 	 * 
 	 * @param srcDirName
 	 *            待复制目录的目录名
 	 * @param destDirName
 	 *            目标目录名
 	 * @param overlay
 	 *            如果目标目录存在，是否覆盖
 	 * @return 如果复制成功返回""，否则返回错误信息串。
 	 */
 	public static String copyDirectory(String srcDirName, String destDirName, boolean overlay , boolean isCopyDir){
 		String reMsg = ""; //返回信息串
 		
 		// 判断源目录是否存在
 		File srcDir = new File(srcDirName);
 		if(!srcDir.exists()){
 			reMsg = "复制目录失败：源目录不存在" + srcDirName + "！";
 			System.out.println(reMsg);
 			return reMsg;
 		}
 		else if(!srcDir.isDirectory()){
 			reMsg = "复制目录失败：不是目录" + srcDirName + "！";
 			System.out.println(reMsg);
 			return reMsg;
 		}

 		// 如果目标目录名不是以文件分隔符结尾，则加上文件分隔符
 		if(!destDirName.endsWith(ConstantClass.MyFile_Separator)){
 			destDirName = destDirName + ConstantClass.MyFile_Separator;
 		}
 		File destDir = new File(destDirName);
 		// 如果目标文件夹存在
 		if(destDir.exists()){
 			// 如果允许覆盖则删除已存在的目标目录
 			if(overlay){
 				new File(destDirName).delete();
 			}else{
 				reMsg = "复制目录失败：不允许目录覆盖，但是目的目录已存在" + destDirName + "！";
 	 			System.out.println(reMsg);
 	 			return reMsg;
 			}
 		}else{
 			// 创建目的目录
 			System.out.println("copyDirectory(),目的目录不存在，准备创建。。。");
 			if(!destDir.mkdirs()){
 				reMsg = "复制目录失败：创建目的目录失败！";
 	 			System.out.println(reMsg);
 	 			return reMsg;
 			}
 		}

 		String flagMsg = "";
 		File[] files = srcDir.listFiles();
 		for(int i=0; i<files.length; i++){
 			// 复制文件
 			if(files[i].isFile()){
 				flagMsg = FileUtil.copyFile(files[i].getAbsolutePath(),
 						destDirName + files[i].getName(), overlay);
 				if(flagMsg.length()>0)
 					break;
 			}else if(files[i].isDirectory() && isCopyDir){//首次调用时传入isCopyDir=false，则不copy顶层文件夹
 				flagMsg = FileUtil.copyDirectory(files[i].getAbsolutePath(),
 						destDirName + files[i].getName(), overlay , true); //如果下层文件夹完全copy，这里=true而不是=isCopyDir
 				if(flagMsg.length()>0)
 					break;
 			}
 		}
 		if(flagMsg.length()>0){
 			reMsg = "复制目录失败，从" + srcDirName + "至" + destDirName + "！";
 			System.out.println(reMsg);
 			return reMsg;
 		}else{
 			return "";
 		}
 	}
 	
 	
	
	
	/**
	* 功能：删除单个文件。
	* @param fileName 要删除的文件的文件名
	* @return String:单个文件删除成功返回""，否则返回错误信息串。
	*/
	public static String deleteFile(String fileName) {
		String reMsg="";
//		System.out.println("======deleteFile="+fileName);
//		String sFileFullPath = new File(fileName).getAbsolutePath();//相对路径转绝对路径
		//File file = new File(sFileFullPath);
		File file = new File(fileName);
		// 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
		if(file.exists() && file.isFile()) {
			if(file.delete()) {
				System.out.println("删除单个文件成功"+fileName+"！");
				return "";
			} 
			else{
				return "删除单个文件失败"+fileName+"！无法删除，可能使用中。";
			}
		} 
		else{
			return "删除单个文件失败：不存在文件" + fileName + "！";
		}
	}



	

	/**
	* 功能：删除目录及目录下的文件。如果其中有一个文件删除失败则中断操作。
	* @param dir 要删除的目录的文件路径
	* @return String:删除成功返回""，否则返回错误信息串。
	*/
	public static String deleteDirectory(String dir) {
		// 如果dir不以文件分隔符结尾，自动添加文件分隔符
/*		if(!dir.endsWith(File.separator)){
			dir = dir + File.separator;
		}*/
		//由于本系统特别使用的文件分隔符是/，因此这里特别处理如下
		if(!dir.endsWith(ConstantClass.MyFile_Separator)){
			dir = dir + ConstantClass.MyFile_Separator;
		}
		
		File dirFile = new File(dir);
		// 如果dir对应的文件不存在，或者不是一个目录，则退出
		if((!dirFile.exists()) || (!dirFile.isDirectory())) {
			return "删除目录失败：不存在目录" + dir + "！";
//			return false;
		}

		String tmp="";
		// 删除文件夹中的所有文件包括子目录
		File[] files = dirFile.listFiles();
		for(int i=0; i<files.length; i++){
			// 删除子文件
			if(files[i].isFile()) {
				tmp = deleteFile(files[i].getAbsolutePath());
				if(tmp.length()>0){
					return "失败：删除目录" + dir + "失败！由于"+tmp;
				}
			}
			//删除子目录
			else if(files[i].isDirectory()){
				tmp = deleteDirectory(files[i].getAbsolutePath());
				if(tmp.length()>0){
					return "失败：删除目录" + dir + "失败！由于"+tmp;
				}
			}
		}

		//删除当前目录
		if(dirFile.delete()) {
			System.out.println("删除目录成功" + dir + "！");
			return "";
		}else{
			return "删除目录失败" + dir + "！无法删除，可能使用中。";
			//return false;
		}
	}

	
	 /**
	   * java获取文件大小的类 四舍五入保留两位小数
	   * @param file
	   * @return
	   * @throws Exception
	   */
	public static double getFileSize(File file) throws Exception{//取得文件大小
		double size=0;
        if (file.exists()){
             FileInputStream fis = null;
             fis = new FileInputStream(file);
             size= fis.available();//字节
             System.out.println("getFileSize=" + size );
        } 
        else{ System.out.println("file.exists() error" );
           return 0;
        }
        size = size/1024.00;
        size=Double.parseDouble(size+"");
        BigDecimal b = new BigDecimal(size); //KB
        double y1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue(); 
        java.text.DecimalFormat df = new java.text.DecimalFormat("#.00"); 
        return Double.parseDouble(df.format(y1));
	}	
	
	 	

 	public static void main(String[] args) {
 		String srcDirName = "C:/test/test0/test1";
 		String destDirName = "c:/ttt";
 		FileUtil.copyDirectory(srcDirName, destDirName, true ,true);
 	}
}
	 
