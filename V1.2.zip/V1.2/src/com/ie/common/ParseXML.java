package com.ie.common;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.Properties;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


public class ParseXML {

	// 定义一个Properties 用来存放 dbhost dbuser dbpassword的值
	private static Properties props = null;

	// 这里的props
	public static Properties getProps() {
		try {
			// 防止多次解析
			if (props == null) {
				parse();
			} else {
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return props;
	}

	public static void parse() throws Exception {
		String ip = "";
		;
		String config_file_name = "config_forsoft.xml";
		/**
		 * 根据服务器IP的不同取不同得配置文件
		 * 如果使用InetAddress.getLocalHost().getHostAddress()方法在linux只能取到127.0.0.1
		 */

		Enumeration<NetworkInterface> netInterfaces = null;
		netInterfaces = NetworkInterface.getNetworkInterfaces();
		while (netInterfaces.hasMoreElements()) {
			NetworkInterface ni = netInterfaces.nextElement();
			Enumeration<InetAddress> ips = ni.getInetAddresses();	//这么取得的ip也会包含hosts中的127.0.0.1
			while (ips.hasMoreElements()) {
				ip = ips.nextElement().getHostAddress();
			}
			
		}
		
		Log.log("---------app use"+config_file_name);

		// 将我们的解析器对象化
		ConfigParser handler = new ConfigParser();
		// 获取SAX工厂对象
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(false);
		factory.setValidating(false);
		// 获取SAX解析
		SAXParser parser = factory.newSAXParser();

		try {
			parser.parse(Thread.currentThread().getContextClassLoader()
					.getResourceAsStream(config_file_name), handler);
			props = handler.getProps();
		} finally {
			factory = null;
			parser = null;
			handler = null;
		}

	}

}
