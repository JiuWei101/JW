/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 下拉列表select信息对象
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   :
*/
package com.ie.common;

public class SclistDATA{
	
	private String id;
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	} 
	
}
