/**
 *EnDecrypt.java
 *Copyright 2011-2-22
 */
package com.ie.common;

import java.io.*;
import java.security.*;
import java.util.Random;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;

public class EnDecrypt{
	
	/**
	 * 私钥签名
	 * @param pri_keypath 私钥路径
	 * @param infoname 文件路径
	 * @throws Exception 
	 */
	public static void signatureKey(String pri_keypath, String infoPath, String retPath) {
		try{
			File file = new File(pri_keypath);
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
			PrivateKey myprikey=(PrivateKey)in.readObject(); 
			in.close(); 
			
	//		byte[] ret = GetFileInfo.getInfo(infoPath).toString().getBytes("UTF8");
			String ret = GetFileInfo.getInfos(infoPath);
//			in = new ObjectInputStream(new FileInputStream(infoPath));
			
			//	初始一个Signature对象,并用私钥对信息签名 
			Signature signet = Signature.getInstance("DSA"); 
			signet.initSign(myprikey); 
			signet.update(ret.getBytes());	
			byte[] signed=signet.sign(); 
			//把信息和签名保存在一个文件中 
			if(retPath==null || retPath.equals("")){
				retPath = infoPath + ".enc";
			}
			file = new File(retPath);
			ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file)); 
//			out.write(ret); 
//			out.write(signed); 
			out.writeObject(ret);
			out.writeObject(signed);
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * 公钥验证
	 * @param pub_keypath 公钥路径
	 * @param infoname	文件路径
	 * @param infoname	结果路径
	 * @return 成功or失败
	 * @throws Exception 
	 */
	public static boolean verificationKey(String pub_keypath, String infoPath, String retPath){
		boolean ret = false;
		try {
			//读入公钥  
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(pub_keypath));
			PublicKey pubkey=(PublicKey)in.readObject();  
			in.close();  
	
			//读入签名和信息  
//			in=new ObjectInputStream(new FileInputStream(infoPath));  
//	
//			String info=in.readObject().toString();  
//			byte[] signed=(byte[])in.readObject();  
//			in.close();  
//			byte[] info = GetFileInfo.getInfo(infoPath).toString().getBytes("UTF8");
			in = new ObjectInputStream(new FileInputStream(infoPath));
			String info = (String)in.readObject();
			byte[] signed = (byte[])in.readObject();
			in.close();
			
			//初始一个Signature对象,并用公钥和签名进行验证  
			Signature signetcheck=Signature.getInstance("DSA");  
			signetcheck.initVerify(pubkey);  
			signetcheck.update(info.getBytes()); 
			if (signetcheck.verify(signed)) { 
				System.out.println("签名正常");
				//保存签名正常信息 
				if(retPath==null || retPath.equals("")){
					retPath = infoPath + ".enc";
				}
		//		File file = new File(retPath);
			//	ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file)); 
			//	out.writeObject(info.getBytes("utf-8")); 
				FileOutputStream out = new FileOutputStream(retPath);
				out.write(info.getBytes("utf-8"));
				out.close();
				ret = true;
			}else{
				System.out.println("签名错误");
				ret = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}  
		return ret;
	}
	/**
	 * 生成key对
	 * @param path 生成文件路径
	 * @param prefix  文件名前缀
	 * @param type key类型（签名：0 ,加密：1）
	 * @return
	 */
	public static String Gen_sigkey(String path, int type,String prefix){
		KeyPairGenerator keyGen;
		String filename = null;
		try {
			String types = "";
			if(type==0){
				types = "DSA";
			}else if(type ==1){
				types = "RSA";
			}
			keyGen = KeyPairGenerator.getInstance(types);
			keyGen.initialize(1024);
			KeyPair key=keyGen.generateKeyPair();
			
			PublicKey pub_key = key.getPublic();
			PrivateKey pri_key = key.getPrivate();
			if(prefix == null){
				filename = PrimaryId.getKeyId();
			}else{
				filename = prefix;
			}
			
			File file = new File(path+"/"+filename+"_pubkey");
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
			
			out.writeObject(pub_key);
			
			file = new File(path+"/"+filename+"_prikey");
			out = new ObjectOutputStream(new FileOutputStream(file));
			out.writeObject(pri_key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return path+"/"+filename;
	}
	
	/**
	 * 生成随机密码
	 * @param path 
	 * @return
	 */
	public static String GetRan_key(String path){
		String filename = null;
		
		try{
			final int maxNum = 60;
			int i;
			int count = 0;
			char[] str = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
					'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w',
					'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'!','@','#','$','%','^','&','*','(',')','_','+','-','=','[',']',
					'{','}','|',';',':','.','<','>'};
			StringBuffer pwd = new StringBuffer("");
			Random r = new Random();
			while(count < 50){
				//生成随机数，取绝对值，防止生成负数，
				i = Math.abs(r.nextInt(maxNum));  //生成的数最大为36-1
				if (i >= 0 && i < str.length) {
					pwd.append(str[i]);
					count ++;
				}
			}
			filename = PrimaryId.getKeyId();
			File file = new File(path+"/"+filename+"_pass");
			FileOutputStream out = new FileOutputStream(file);	
			out.write(pwd.toString().getBytes());
			out.close();
			
			file = new File(path+"/"+filename+"_pass_md5");
			out = new FileOutputStream(file);	
			out.write(Encrypt.EncryptString(pwd.toString()).getBytes());
			out.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return path + "/" + filename+"_pass";
	}
	
//	/**
//	 * 生成对称加密用key
//	 * @param path 
//	 * @return
//	 */
//	public static String GetPass_key(String path){
//		KeyGenerator keyGen;
//		String filename = null;
//		try {
//			keyGen=KeyGenerator.getInstance("DES");
//			keyGen.init(56);
//			Key key=keyGen.generateKey();
//			
//			filename = PrimaryId.getKeyId();
//			File file = new File(path+"/"+filename+"_pass");
//			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));	
//			out.writeObject(key);
//			out.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return path + "/" + filename+"_pass";
//	}
	/**
	 * 公钥加密
	 * @param pub_keypath 公钥路径
	 * @param infoPath 文件路径
	 * @param retPath 生成文件路径
	 * @param retPath
	 */
	public static void encByPubKey(String pub_keypath, String infoPath, String retPath) {
		try {
			//读入公钥  
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(pub_keypath));
			PublicKey pubkey=(PublicKey)in.readObject();  
			in.close();  
			
			// 读入需加密文件
		//	ByteArrayOutputStream bout = GetFileInfo.getInfo(infoPath);
			
			byte[] bout = GetFileInfo.getInfos(infoPath).getBytes("utf-8");
	//		System.out.println(new String(bout));			
			// 加密
			Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.ENCRYPT_MODE,pubkey);
			byte[] cipherText=cipher.doFinal(bout);
			// 生成加密后文件
			if(retPath==null || retPath.equals("")){
				retPath = infoPath + ".enc";
			}
			
//			File file = new File(retPath);
//			ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file)); 
//			out.writeObject(cipherText); 
			FileOutputStream out = new FileOutputStream(retPath);
			out.write(cipherText);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}   
	}
	
	/**
	 * 私钥解密
	 * @param pub_keypath 公钥路径
	 * @param infoPath 文件路径
	 * @param retPath 生成文件路径
	 * @param retPath
	 */
	public static String decByPriKey(String pri_keypath, String infoPath, String retPath) {
		try {
			//读入私钥  
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(pri_keypath));
			PrivateKey prikey=(PrivateKey)in.readObject();  
			in.close();  
			
			byte[] signed=GetFileInfo.getInfo(infoPath).toByteArray();		
		//	byte[] signed = GetFileInfo.getInfos(infoPath).getBytes();
		//	System.out.println(new String(signed));
			// 解密
			Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.DECRYPT_MODE,prikey);
			byte[] cipherText=cipher.doFinal(signed);
	//		System.out.println(new String(cipherText,"utf-8"));
			// 生成解密后文件
			if(retPath==null || retPath.equals("")){
				retPath = infoPath + ".dec";
			}
			File file = new File(retPath);
//			ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file)); 
//			out.writeObject(cipherText); 
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(cipherText);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}   
		return retPath;
	}
	
	/**  
	 * 对称加密  （加密文件用）
	 *   
	 * @param filePath 需要加密的文件路径  
	 * @param passPath  加密密钥文件路径 
	 * @param retPath  加密后文件路径 
	 * @return  
	 */  
	public static void encrypt(String filePath, String passPath, String retPath) {   
        try {                  	
            KeyGenerator kgen = KeyGenerator.getInstance("AES");   
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG" );   
            secureRandom.setSeed(GetFileInfo.getInfo(passPath).toByteArray());
            kgen.init(128, secureRandom);
          //  kgen.init(128, new SecureRandom(GetFileInfo.getInfo(passPath).toByteArray()));   
            SecretKey secretKey = kgen.generateKey();   
            byte[] enCodeFormat = secretKey.getEncoded();   
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");   
            Cipher cipher = Cipher.getInstance("AES");// 创建密码器  
            cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化        
            
            CipherInputStream  cis = new CipherInputStream(new FileInputStream(filePath),cipher);
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
			byte[] tmpbuf = new byte[1024];
			int count = 0;
			while ((count = cis.read(tmpbuf)) != -1){
				bout.write(tmpbuf, 0, count);
				tmpbuf = new byte[1024];
			}
			cis.close();
			
			cipher.init(Cipher.DECRYPT_MODE, key);
            // 生成加密后文件
			if(retPath==null || retPath.equals("")){
				retPath = filePath + ".enc";
			}
			
            File file = new File(retPath);
            FileOutputStream out = new FileOutputStream(file);
			out.write(bout.toByteArray());
			out.close();
        } catch (Exception e) {   
            e.printStackTrace();   
        } 
	}  

    /**对称解密  
     * @param filePath  待解密文件路径  
     * @param passPath 解密密钥文件路径  
     * @param retPath   解密后文件路径
     * @return  
     */  
    public static String decrypt(String filePath, String passPath, String retPath) {   
        try {   
        	//String rePath = ""
            KeyGenerator kgen = KeyGenerator.getInstance("AES");   
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG" );   
            secureRandom.setSeed(GetFileInfo.getInfo(passPath).toByteArray());
            kgen.init(128, secureRandom);
        //    kgen.init(128, new SecureRandom(GetFileInfo.getInfo(passPath).toByteArray()));   
            SecretKey secretKey = kgen.generateKey();   
            byte[] enCodeFormat = secretKey.getEncoded();   
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");               
            Cipher cipher = Cipher.getInstance("AES");// 创建密码器   
            cipher.init(Cipher.DECRYPT_MODE, key);// 初始化   
            
            byte[] ret = GetFileInfo.getInfo(filePath).toByteArray();
            // 生成解密后文件
			if(retPath==null || retPath.equals("")){
				retPath = filePath + ".dec";
			}
			CipherOutputStream cos = new CipherOutputStream(new FileOutputStream(retPath), cipher);
			cos.write(ret);
			cos.close();
        } catch (Exception e) {   
        	e.printStackTrace();   
        }  
        return retPath;
    } 
	
    public static void main(String[] args) throws Exception{
    	// 生成key
   // 	String keypath = GetPass_key("d:\\test");
  //  	String keypath = GetRan_key("/home/tomcat/yc_test");
    	// 加密包
  //  	encrypt("d:\\test\\0.zip", keypath,"d:\\test\\0.zip.enc"); 	
    	// 生成加密key对
 //   	String keypath1 = Gen_sigkey("d:\\test", 1,null);  	
    	// 生成签名用key对
 //   	String keypath2 = Gen_sigkey("d:\\test", 0,null); 
    	// key公钥加密
 //   	encByPubKey(keypath1+"_pubkey", keypath, "d:\\test\\enckey");
    	// key私钥签名(只能给字符串签名,暂时想给密码的md5码进行签名)
//    	signatureKey(keypath2+"_prikey", keypath+"_md5", "d:\\test\\sig");
//    	// key公钥验证
//    	verificationKey(keypath2+"_pubkey", "d:\\test\\sig", "d:\\test\\2.txt");
    	// key 私钥解密
 //   	decByPriKey(keypath1+"_prikey", "d:\\test\\enckey", "d:\\test\\finalkey");
		
    	// 解密包
		decrypt("d:\\test\\0.zip.enc", "d:\\test\\1.txt","d:\\test\\00.zip");	
	
    }
}




