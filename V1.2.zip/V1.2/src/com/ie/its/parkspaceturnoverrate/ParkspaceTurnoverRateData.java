package com.ie.its.parkspaceturnoverrate;

public class ParkspaceTurnoverRateData {

	private String parkingSpaceCode;   //车位编号
	private String inTime;             //入车时间
	private String outTime;            //出车时间
	private String putOut;             //是否已出车
	private int label=0;               //标记是否已遍历
	private int count=0;               //车位周转次数	
	
	protected static final String WINEXCELPATH = "f:/excel";
	protected static final String LINUXEXCELPATH = "/usr/its/excel";
	
	public void setParkingSpaceCode(String parkingSpaceCode) {
		this.parkingSpaceCode = parkingSpaceCode;
	}
	
	public String getParkingSpaceCode() {
		return parkingSpaceCode;
	}
	
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	
	public String getInTime() {
		return inTime;
	}
	
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	
	public String getOutTime() {
		return outTime;
	}
	
	public void setPutOut(String putOut) {
		this.putOut = putOut;
	}
	
	public String getPutOut() {
		return putOut;
	}

	public void setLabel(int label) {
		this.label = label;
	}

	public int getLabel() {
		return label;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}
	
}
