package com.ie.its.parkspaceturnoverrate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.parkingstatistics.ParkingStatisticsData;

@Namespace("/parkspaceturnoverrate")
public class ParkspaceTurnoverRateAction extends ExtendActionSupport{

	private ParkingStatisticsData statisticsData;   //处理多语言
	
	@Autowired
	private ParkspaceTurnoverRateService parkspaceTurnoverRateService;
	
	private String date;   //查询时间
	private Object excelData;	//要导出excel的数据
	private String downFileName;
	protected InputStream inputStream;
	
	public String getDownFileName() {
		return downFileName;
	}

	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}

	public ParkingStatisticsData getStatisticsData() {
		return statisticsData;
	}

	public void setStatisticsData(ParkingStatisticsData statisticsData) {
		this.statisticsData = statisticsData;
	}

	public ParkspaceTurnoverRateAction(){
		statisticsData = new ParkingStatisticsData();
	}
	
	@Action(value="parkspace_turnover_rate",results={@Result(name="success",location="/parking_statistics/parkspace_turnover_rate.jsp")})
	public String parkspace_turnover_rate(){
		this.setLang(statisticsData);
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		return SUCCESS;
	}
	
	@Action(value="get_turnover_rate",results={@Result(type="json")})
	public void get_turnover_rate(){
		JSONObject json = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)statisticsData.getLang_switch().get(lang)).get("common");
			
			json = parkspaceTurnoverRateService.getTurnoverRateData(map,date);
			json.element("success", true);
		}catch(Exception e){
			e.printStackTrace();
			json.element("success", false);
		}

		setJsonRes(json);
	}
	
	//=======start导出excel==============================================================================================
	@Action(value="dataExportToExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportToExcel(){
		try{
			File file  = parkspaceTurnoverRateService.exportToExcel(date);
			downFileName = file.getName();
		}catch(Exception e){
			Log.log(e.getMessage());
		}
		
		return SUCCESS;
	}
	
	/**
	 * 文件下载流
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 */
	public InputStream getInputStream() throws UnsupportedEncodingException, FileNotFoundException {
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = ParkspaceTurnoverRateData.WINEXCELPATH;
		} else {
			path = ParkspaceTurnoverRateData.LINUXEXCELPATH;
		}
		
		return new FileInputStream(path + "/" + downFileName);
	}
	//=======end导出excel==============================================================================================
	
	public void setDate(String date) {
		this.date = date;
	}

	public String getDate() {
		return date;
	}

	public void setExcelData(Object excelData) {
		this.excelData = excelData;
	}

	public Object getExcelData() {
		return excelData;
	}
}
