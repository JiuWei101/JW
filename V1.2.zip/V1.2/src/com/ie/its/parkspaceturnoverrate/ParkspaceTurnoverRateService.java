package com.ie.its.parkspaceturnoverrate;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.FileUtil;
import com.ie.common.Log;
import com.ie.frame.ExtendService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Scope("prototype")
@Service
public class ParkspaceTurnoverRateService extends ExtendService{
	
	private ParkspaceTurnoverRateSql parkspaceTurnoverRateSql;

	public ParkspaceTurnoverRateService(){
		parkspaceTurnoverRateSql = new ParkspaceTurnoverRateSql();
	}
	
	public JSONObject getTurnoverRateData(Map map,String _date){
		JSONObject json = new JSONObject();
		JSONArray item = new JSONArray();
		
		String lotNumberLang = map.get("parking_lot_number").toString();
		String turnoverNumLang = map.get("turnover_number").toString();
		String yUnitLang = map.get("turnover_rate").toString() + "（"
						+ map.get("unit").toString()+ "：%）";
		String xUnitLang = map.get("pot").toString() + "（"
						+ map.get("unit").toString()+ "："
						+ map.get("unit_mess").toString() + "）";
		String seriesNameLang = map.get("turnover_rate").toString();
		
		String spaceTotalSql = parkspaceTurnoverRateSql.getParkspaceTotalSql();
		String hisCountSql = parkspaceTurnoverRateSql.getTurnoverRateSql(_date);
		String logCountSql = parkspaceTurnoverRateSql.getTurnoverRateFromLog(_date);
		List<ParkspaceTurnoverRateData> hisCountList = this.getJt().<ParkspaceTurnoverRateData>queryForListExt(hisCountSql,ParkspaceTurnoverRateData.class);
		List<ParkspaceTurnoverRateData> logCountList = this.getJt().<ParkspaceTurnoverRateData>queryForListExt(logCountSql,ParkspaceTurnoverRateData.class);
		List<String> allSpaceList = this.getJt().queryForList(spaceTotalSql,String.class);
		
		int total = hisCountList.size()+logCountList.size();  //整个停车场所有车位一天的周转数
		
		if(hisCountList.size() != 0 || logCountList.size() != 0){
			for(String spaceData : allSpaceList){
				if("".equals(spaceData)|| spaceData == null){
					continue;
				}
				int inTimes = 0;
				JSONObject rateItem = new JSONObject();
				
				for(ParkspaceTurnoverRateData hisData : hisCountList){
					if(hisData.getLabel()==0 && spaceData.equals(hisData.getParkingSpaceCode())){
						hisData.setLabel(1);
						inTimes++;
					}
				}
				for(ParkspaceTurnoverRateData logData : logCountList){
					if(logData.getLabel()==0 && spaceData.equals(logData.getParkingSpaceCode())){
						logData.setLabel(1);
						inTimes++;
					}
				}
				//计算周转率
				double turnoverRate = this.calculatorRate(inTimes, total);
				String nameStr = lotNumberLang + "：" + spaceData + " " + turnoverNumLang + "：" + inTimes;
				rateItem.put("name", nameStr);   //保存name显示字段
				rateItem.put("y", turnoverRate);   //保存周转率
				if(spaceData.contains("A")){
					rateItem.put("color", "#058DC7");  //针对不同的区域，添加不同的颜色
				}
				else if(spaceData.contains("B")){
					rateItem.put("color", "#54C85D");  //针对不同的区域，添加不同的颜色
				}
				else if(spaceData.contains("C")){
					rateItem.put("color", "#ED561B");  //针对不同的区域，添加不同的颜色
				}
				else if(spaceData.contains("D")){
					rateItem.put("color", "#DDDF00");  //针对不同的区域，添加不同的颜色
				}
				else if(spaceData.contains("E")){
					rateItem.put("color", "#FF9655");  //针对不同的区域，添加不同的颜色
				}
				else{}    //如果还有其他区域，则使用默认色
				
				item.add(rateItem);
			}
		}
		String title = map.get("parking_total").toString() + "：" + allSpaceList.size();
		
		json.put("item", item);
		json.put("potTotalTitle", title);
		json.put("xunit", xUnitLang);
		json.put("yunit", yUnitLang);
		json.put("series", seriesNameLang);
		
		return json;
	}
	
	/**
	 * @Description : 计算周转率
	 * @param : @param _inTimes
	 * @param : @param _total
	 * @param : @return  
	 * @return : double
	 * @author : 0917
	 */
	public double calculatorRate(int _inTimes,int _total){
		DecimalFormat df = new DecimalFormat("0.00");
		return Double.parseDouble(df.format((double)_inTimes/(double)_total*100));
	}
	
	//=======start导出excel=========================================================================================
	/**
	 * 导出Excel
	 * @param searchType 查询方式
	 * @param obj 要导出的数据
	 */
	public File exportToExcel(String _date) {
		// TODO Auto-generated method stub
		File file = null;
		try {
			file = createFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dateIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("车位周转率", 0);
			
			String spaceTotalSql = parkspaceTurnoverRateSql.getParkspaceTotalSql();
			String hisCountSql = parkspaceTurnoverRateSql.getTurnoverRateSql(_date);
			String logCountSql = parkspaceTurnoverRateSql.getTurnoverRateFromLog(_date);
			List<ParkspaceTurnoverRateData> hisCountList = this.getJt().<ParkspaceTurnoverRateData>queryForListExt(hisCountSql,ParkspaceTurnoverRateData.class);
			List<ParkspaceTurnoverRateData> logCountList = this.getJt().<ParkspaceTurnoverRateData>queryForListExt(logCountSql,ParkspaceTurnoverRateData.class);
			List<String> allSpaceList = this.getJt().queryForList(spaceTotalSql,String.class);
			
			int total = hisCountList.size()+logCountList.size();  //整个停车场所有车位一天的周转数
			
			if(hisCountList.size() != 0 || logCountList.size() != 0){	
				for(String spaceData : allSpaceList){
					int inTimes = 0;
					
					for(ParkspaceTurnoverRateData hisData : hisCountList){
						if(hisData.getLabel()==0 && spaceData.equals(hisData.getParkingSpaceCode())){
							hisData.setLabel(1);
							inTimes++;
							total++;
						}
					}
					for(ParkspaceTurnoverRateData logData : logCountList){
						if(logData.getLabel()==0 && logData.getParkingSpaceCode().equals(spaceData)){
							logData.setLabel(1);
							inTimes++;
							total++;
						}
					}
					//计算周转率
					double turnoverRate = this.calculatorRate(inTimes, total);
						
					Label sequence = new Label(0, dateIndex, " " + dateIndex);		//添加序号
					sheet.addCell(sequence);
					Label space = new Label(1, dateIndex, spaceData);
					sheet.addCell(space);
					Label inTimesLabel = new Label(2, dateIndex, String.valueOf(inTimes));
					sheet.addCell(inTimesLabel);
					Label rateLabel = new Label(3, dateIndex, String.valueOf(turnoverRate));
					sheet.addCell(rateLabel);
						
					++dateIndex;
				}
			}
				
			//添加表头
			Label title1 = new Label(0, 0, "序号");
			sheet.addCell(title1);
			Label title2 = new Label(1, 0, "车位编号");
			sheet.addCell(title2);
			Label title3 = new Label(2, 0, "周转次数");
			sheet.addCell(title3);
			Label title4 = new Label(3, 0, "周转率");
			sheet.addCell(title4);
		
			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 创建文件
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public File createFile() throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calender = Calendar.getInstance();
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = ParkspaceTurnoverRateData.WINEXCELPATH;
		} else {
			path = ParkspaceTurnoverRateData.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + sdf.format(calender.getTime()) + ".xls");
		file.createNewFile();
		
		return file;
	}
	//=======end导出excel=========================================================================================
}
