package com.ie.its.parkspaceturnoverrate;

import static com.ie.common.Util.isCon;

import org.apache.ibatis.jdbc.SqlBuilder;

import com.ie.common.DateUtil;

public class ParkspaceTurnoverRateSql {

	/**
	 * @Description : 从p_parkingspaceoperationhis表中获取停车数据
	 * @param : @param _date
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String getTurnoverRateSql(String _date){
		String sqlStr = "select parkingSpaceCode,inTime,outTime,putOut from p_parkingspaceoperationhis where 1=1";
		if(isCon(_date)){
			sqlStr += " and inTime like '" + _date + "%'";
		}
		sqlStr += " ORDER BY parkingSpaceCode";
		
		return sqlStr;
	}
	
	public String getTurnoverRateFromLog(String _date){
		String nextDay = DateUtil.getNextDay(_date, "1");
		String sqlStr = "select parkingSpaceCode,inTime,outTime,putOut from p_parkingspaceoperationlog where 1=1";
		if(isCon(_date)){
			sqlStr += " and inTime<'" + nextDay + "'";
		}
		sqlStr += " ORDER BY parkingSpaceCode";
		
		return sqlStr;
	}
	
	/**
	 * 从p_parkingspace表中获取所有车位编号
	 * @author : 0917
	 */
	public String getParkspaceTotalSql(){
		String sqlStr = "select distinct code from p_parkingspace order by code";
		
		return sqlStr;
	}
}
