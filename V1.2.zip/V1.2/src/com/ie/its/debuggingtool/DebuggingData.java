/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.debuggingtool;

import java.util.List;

import com.ie.frame.ExtendData;

public class DebuggingData extends ExtendData{
	
	
	
	/**
	 * 视屏探测器ip
	 */
	private String videoIp;
	/**
	 * 视屏探测器端口号
	 */
	private String videoPort;
	/**
	 * 视屏探测器状态
	 */
	private String videoStatus;
	/**
	 * 车位编号
	 */
	private String carParkNumber;
	/**
	 * 车位类型
	 */
	private String carParkType;
	/**
	 * 车位状态(使能)
	 */
	private String carParkStatus;
	/**
	 * 当前状态
	 */
	private String carParkCurrStatus;
	/**
	 * 图片字节总数
	 */
	private String carPictueBytes;
	
	
	
	
	public String getVideoIp() {
		return videoIp;
	}
	public void setVideoIp(String videoIp) {
		this.videoIp = videoIp;
	}
	public String getVideoPort() {
		return videoPort;
	}
	public void setVideoPort(String videoPort) {
		this.videoPort = videoPort;
	}
	public String getVideoStatus() {
		return videoStatus;
	}
	public void setVideoStatus(String videoStatus) {
		this.videoStatus = videoStatus;
	}
	public String getCarParkNumber() {
		return carParkNumber;
	}
	public void setCarParkNumber(String carParkNumber) {
		this.carParkNumber = carParkNumber;
	}
	public String getCarParkType() {
		return carParkType;
	}
	public void setCarParkType(String carParkType) {
		this.carParkType = carParkType;
	}
	public String getCarParkStatus() {
		return carParkStatus;
	}
	public void setCarParkStatus(String carParkStatus) {
		this.carParkStatus = carParkStatus;
	}
	public String getCarParkCurrStatus() {
		return carParkCurrStatus;
	}
	public void setCarParkCurrStatus(String carParkCurrStatus) {
		this.carParkCurrStatus = carParkCurrStatus;
	}
	public String getCarPictueBytes() {
		return carPictueBytes;
	}
	public void setCarPictueBytes(String carPictueBytes) {
		this.carPictueBytes = carPictueBytes;
	}
	public static String parkInfo_list(DebuggingData debuggin, String string) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
