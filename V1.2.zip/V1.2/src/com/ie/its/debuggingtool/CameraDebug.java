package com.ie.its.debuggingtool;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ie.common.Log;

public class CameraDebug extends CommonMethod{
	
	private final String A0 = "a0";	 //命令A0--AA AB AC B1-B3
	private final String A1 = "a1";
	private final String A2 = "a2";
	private final String A3 = "a3";
	private final String A4 = "a4";
	private final String A5 = "a5";
	private final String A6 = "a6";
	private final String A7 = "a7";
	private final String A8 = "a8";
	private final String A9 = "a9";
	private final String AA = "aa";
	private final String AB = "ab";
	private final String AC = "ac";
	private final String AD = "ad";
	private final String AE=  "ae";
	private final byte READOPERATE = 0;
	private final byte SETOPERATE = 1;
	private List<CarData> list = new ArrayList<CarData>();
	private final int TIMEOUT = 10 * 60 * 10000;			//10分钟超时
	private final String DISCONNECT = "failer IP Cameras has been disconnected....";
	private final String TIMEOUTSTRING = "failer Time out";
	
	//读取B命令
	public String readB1(String ip){
		SocketChannel channel = ServerSocketListener.socketMap.get(ip);
		if(channel != null){
			try {	
				byte[] buff = new byte[2];
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) { // 读取
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nRead B cmd: Return CMD is ( " + cmd + " )");
							// B2，B3命令传过来
						readB1B2B3(channel, cmd);
						break;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			} // 写命令
			StringBuilder sb = new StringBuilder();
			return sb.append(list.size() > 0 ? list.get(0) : " ").toString();
		}
		else{
			return DISCONNECT;
		}
	}
	
	/** 
	 * A0命令 读取视频探测器下单个车位的当前状态
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @param carCode 车位编号
	 * @return 车位编号 车位状态 车位类型	车牌号长度 车牌号数据 图片数据长度 图片数据
	 */
	public String getSingleCarCodeA0(String ip, byte carCode,String path) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip);
		ByteBuffer buffer = null;
		if(channel != null){
			try {	
				buffer = ByteBuffer.wrap(new byte[]{1, (byte) 0xA0, carCode});
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) { // 读取
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA0 cmd: Return CMD is ( " + cmd + " )");
						if (cmd.equalsIgnoreCase(A0)) {
							Log.log("A0==============================");
							list = getListCarData(channel, 1,path);
							Log.log("A0==============================");
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
						long end = new Date().getTime();
						if ((end - start) > TIMEOUT) {
							return TIMEOUTSTRING;
						}
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			} // 写命令
			return packString(buffer).append(",").append(list.size() > 0 ? list.get(0) : " ").toString();	
			}else {
				return DISCONNECT;		
			}
		
	}
	
	/**
	 * A1 读取视频探测器下所有使能车位的当前状态
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @return [车位编号 车位状态 车位类型	车牌号长度 车牌号数据 图片数据长度 图片数据],...
	 */
	public List<CarData> getMulitCarDataA1(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip);
		ByteBuffer buffer = null;
		if(channel != null){
			try {
				buffer = ByteBuffer.wrap(new byte[]{1, (byte) 0xA1});
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA1 cmd: Return CMD is ( " + cmd + " )");
						if (cmd.equalsIgnoreCase(A1)) {
							Log.log("A1==============================");
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							list = getListCarData(channel, buff[0],"");
							Log.log("A1==============================");
							break;
						} else if (cmd.equalsIgnoreCase(A0)) {
							Log.log("A0==============================");
							list = getListCarData(channel, 1,"");
							Log.log("A0==============================");
							break;
						}else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return null;
					}
				}
			}  catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return null;
			} // 写命令
			return list;
		}
		else {
			return null;
		}
		
	}

	/**
	 * A2命令
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @param carCode 车位编号
	 * @param carType 车位类型（长度为1Byte，0：临时；1：预定；2固定）
	 * @return 状态（0x55成功；0x11失败）
	 */
	public String setupCarTypeA2(String ip, byte carCode, byte carType) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;	
		if (channel != null) {
			// 数据格式 type,cmd,carCode, carType
			try {
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA2,
						carCode, carType });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA2 cmd: Return CMD is " + cmd
								+ "=====================================");
						if (cmd.equalsIgnoreCase(A2)) {
							Log.log("A2==============================");
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status = "update success!"+ip+"-->"+carCode+"-->"+Integer.toHexString(Integer
									.valueOf(buff[0]));
							Log.log("A2==============================");
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
				}
				long end = new Date().getTime();
				if ((end - start) > TIMEOUT) {
					return TIMEOUTSTRING;
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			} // 写命令
			return packString(buffer).append(",").append(status).toString();}
		else {
			return DISCONNECT;
		}
	}

	/**
	 * A3命令 
	 * @param ip要往这个终端机发送数据的ＩＰ
	 * @param carCode 车位编号
	 * @param enabled 车位使能位（0禁用；1使能)
	 * @return 状态（0x55成功；0x11失败)
	 */
	public String setupCarEnabledA3(String ip, byte carCode, byte enabled) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;	
		if (channel != null) {
			// 数据格式 type,cmd,carCode, enabled
			try {
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA3,
						carCode, enabled });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA3 cmd: Return CMD is " + cmd
								+ "=====================================");
						if (cmd.equalsIgnoreCase(A3)) {
							Log.log("A3==============================");
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status = "update success!"+ip+"-->"+Integer.toHexString(Integer
									.valueOf(buff[0]));
							Log.log("A3==============================");
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
			return packString(buffer).append(",").append(status).toString();
		}
		else {
			return DISCONNECT;
		}
	}

	/**
	 * A4命令更改终端机IP地址及网关地址
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @param newIp IP第一部分（1Byte)	IP第二部分（1Byte)	IP第三部分（1Byte)	IP第四部分（1Byte)
	 * @param newNetwork 网关地址第一级 1Byte	网关地址第二级 1Byte	网关地址第三级 1Byte	网关地址第四级 1Byte
	 * @param port 端口号（2字节无符号整型)
	 * @return 状态（0x55成功；0x11失败)
	 */
	public String changeTerminalIpNetWrokA4(String ip, String newIp, String ipMask,
			String newNetwork, int port) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式
			// type,cmd,Segment1,Segment2,Segment3,Segment4,G-Segment1,G-Segment2,G-Segment3,G-Segment4,port
			try {// 发送命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xA4 }),
						ByteBuffer.wrap(stringToBytes(newIp)),
						ByteBuffer.wrap(stringToBytes(ipMask)),
						ByteBuffer.wrap(stringToBytes(newNetwork)),
						ByteBuffer.wrap(intToBytes(port, 2)) };
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA4 cmd: Return CMD is " + cmd
								+ "=====================================");
						if (cmd.equalsIgnoreCase(A4)) {
							Log.log("A4==============================");
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status = "update success!"+ newIp+"-->"+Integer.toHexString(Integer
									.valueOf(buff[0]));
							Log.log("A4==============================");
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						status= TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= DISCONNECT;
			}
			
		}else
			status=DISCONNECT;
		
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A5读取终端机的集中器IP地址和端口号
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @return IP第一部分（1Byte)	IP第二部分（1Byte)	IP第三部分（1Byte)	IP第四部分（1Byte)	端口号（2Byte)
	 */
	public String readDetectorIpA5(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String returnNetwork = "";
		int port = 0;
		ByteBuffer buffer = null;
		String status="";
		if (channel != null) {
			// 数据格式 type,cmd
			try {
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA5 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						Log.log("\nA5 cmd: Return CMD is " + cmd
								+ "=====================================");
						if (cmd.equalsIgnoreCase(A5)) {
							Log.log("A5==============================");
							buff = new byte[4];
							channel.read(ByteBuffer.wrap(buff));
							returnNetwork = ipPackage(buff);
							buff = new byte[2];
							channel.read(ByteBuffer.wrap(buff));
							Log.log("port: " + buff[0] + " , " + buff[1]);
							port = bytesToInt(buff, 2);
							Log.log("A5==============================");
							status="jizhongipaddr:"+returnNetwork + "," +"jizhongport:"+ port;
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						status= TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= DISCONNECT;
			}
			
		}
		else 
			status= DISCONNECT;
		
			return packString(buffer).append(",").append(status).toString();
		
	}

	/**
	 * A６更改终端机的集中器IP地址和端口号
	 * @param ip	要往这个终端机发送数据的ＩＰ
	 * @param newIp	要更改的ＩＰ地址
	 * @param port 要更改的端口号
	 * @return 状态（0x55成功；0x11失败）
	 */
	public String changeDetectorIpNetWrokA6(String ip, String newIp, int port) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,Segment1,Segment2,Segment3,Segment4,port
			try {// 发送命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xA6 }),
						ByteBuffer.wrap(stringToBytes(newIp)),
						ByteBuffer.wrap(intToBytes(port, 2)) };
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(A6)) {
							Log.log("A6==============================");
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status = "success!"+ip+"-->"+Integer.toHexString(Integer
									.valueOf(buff[0]));
							Log.log("A6==============================");
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) { // 如果超过'TIMEOUT'仍未接收到正确的数据就返回TimeOut
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
			return packString(buffer).append(",").append(status).toString();
			}else {
				return DISCONNECT;
			}
		
		
	}

	/**
	 * A7命令更改车位ID对应的车位编号
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @param carId 车位ID（1-4）
	 * @param carCode 车位编号
	 * @return 状态（0x55成功；0x11失败） 
	 */
	public String changeCarCodeA7(String ip, byte carId, byte carCode) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,carId, carCode
			try { // 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA7, carId,
						carCode });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(A7)) {
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status =  "update success!"+ip+"-->"+ Integer.toHexString(Integer
									.valueOf(buff[0]));
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
			return packString(buffer).append(",").append(status).toString();
		}else {
			return DISCONNECT;
		}
		
	}

	/**
	 * A8读取终端机IP地址、网关地址、端口
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @return IP第一部分（1Byte)	IP第二部分（1Byte)	IP第三部分（1Byte)	IP第四部分（1Byte)	网关地址第一级 1Byte	网关地址第二级 1Byte	网关地址第三级 1Byte	网关地址第四级 1Byte	端口号（2字节无符号整型)
	 */
	public String readTreminalIpA8(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String returnIp = "", ipMask = "", returnNetwork = "";
		int port = 0;
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA8 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(A8)) {
							buff = new byte[4];
							channel.read(ByteBuffer.wrap(buff));
							returnIp = ipPackage(buff);
							channel.read(ByteBuffer.wrap(buff));
							ipMask = ipPackage(buff);
							channel.read(ByteBuffer.wrap(buff));
							returnNetwork = ipPackage(buff);
							buff = new byte[2];
							channel.read(ByteBuffer.wrap(buff));
							port = bytesToInt(buff, 2);
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
			return packString(buffer).append(",\nReturnIp: ").append(returnIp).append(",\nIpMask: ").append(ipMask).
					append(",\nReturnNetwork: ").append(returnNetwork).append(",\nPort: ").append(port).toString();
		}
		else{
			return DISCONNECT;
		}
	}

	/**
	 * A9命令 读取终端机拍照周期
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @return 拍照周期，单位秒 （2Byte无符号整型)
	 */
	public String readPictureCycleA9(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String period = "";
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA9 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(A9)) {
							buff = new byte[2];
							channel.read(ByteBuffer.wrap(buff));
							period = bytesToInt(buff, buff.length) + "";
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
			return packString(buffer).append(",").append("phototime:"+period).toString();
		}
		else {return DISCONNECT;}
	}

	/**
	 * AA命令
	 * @param ip 要往这个终端机发送数据的ＩＰ
	 * @param period 拍照周期，单位秒（2Byte无符号整型)
	 * @return 状态（0x55成功；0x11失败
	 */
	public String setupPictureCycleAA(String ip, int period) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,period
			try {// 写命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xAA }),
						ByteBuffer.wrap(intToBytes(period, 2)) };
				Log.log(buffer);
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(AA)) {
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff));
							status = Integer.toHexString(Integer
									.valueOf(buff[0]));
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
		}
		return packString(buffer).append(",").append(status).toString();
	}
	
	/**
	 * AB 读取终端机信号强度
	 * @param ip 
	 * @return
	 */
	public String readSignalStrengthAB(String ip){
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		ByteBuffer buffer = null;							//用于读写数据
		StringBuilder sb = new StringBuilder();				//用于返回读取到的数据
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xAB });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(AB)) {
							buff = new byte[1];		//先读取数据的总长度
							channel.read(ByteBuffer.wrap(buff));
							int totalLength = buff[0], otherLen = 0;
							Log.log("终端机信号强度,返回数据总长度: " + totalLength);
							sb.append("TotalLength:").append(totalLength);
/*							buff = new byte[totalLength];
							Log.log("===================Byte=======================================");
							StringBuilder sbLog = new StringBuilder();
							for (int i = 0; i < buff.length; i++) {
								sbLog.append("Buff[").append(i).append("]: ").append(buff[i]).append("\n");
							}
							Log.log(sbLog);
							Log.log("===================Byte=======================================");
*/							while(otherLen < totalLength){
								buff = new byte[1];			//设置读取的AP名称长度为1byte	
								channel.read(ByteBuffer.wrap(buff));	//读取AP名称长度
								otherLen += 1;				//统计读了多少个数据
								int apNameLen = buff[0];	//AP名称长度
								Log.log("ApNameLen: " + apNameLen);						//把AP名称长度写到log文件
								sb.append(",ApNameLen: ").append(apNameLen);				//把AP名称长度加到StringBuilder
								buff = new byte[apNameLen];	//设置AP名称要读取的长度
								int l = channel.read(ByteBuffer.wrap(buff));
								Log.log("===================ApName=======================================");
								StringBuilder sbLog = new StringBuilder();
								for (int i = 0; i < l; i++) {
									sbLog.append("Buff[").append(i).append("]: ").append(buff[i]).append("\n");
								}
								Log.log(sbLog);
								Log.log("===================ApName=======================================");
								otherLen += apNameLen;		//统计读了多少个数据
								String apName = new String(buff, 0, l, "UTF-8");	//Byte类型的AP名称转成String字符串
								Log.log("ApName: " + apName);						//把AP名称写到log文件
								sb.append(", ApName: ").append(apName);				//把AP名称加到StringBuilder
								buff = new byte[1];			//设置读取的信号强度为1byte
								otherLen += 1;				//统计读了多少个数据
								channel.read(ByteBuffer.wrap(buff));								//读取信号强度
								Log.log("SignalIntensity: " + buff[0]);								//把信号强度写到log文件
								sb.append(", SignalIntensity: ").append(buff[0]).append("\n");		//把信号强度加到StringBuilder
							}
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						sb.append( TIMEOUTSTRING);
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				sb.append(DISCONNECT) ;
			}
		}
		else{
			sb.append(DISCONNECT) ;
		}
		return packString(buffer).append(",").append(sb).toString();
	}
	
	/**
	 * AC 读取终端机程序版本号
	 * @param ip 
	 * @return
	 */
	public String readVersionAC(String ip){
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String version = "";
		StringBuilder status=new StringBuilder();
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xAC });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						Log.log("buff[0]::::" + buff[0]);
						Log.log("Len: " + len);
						Log.log("buff[1]::::" + buff[1]);
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(AC)) {
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff)); // 版本号内容长度
							len = buff[0];
							Log.log("VersionContent Len: " + len);
							status.append("VersionContentLen:").append(len);
							buff = new byte[len];
							len = channel.read(ByteBuffer.wrap(buff)); // 根据版本号内容长度,读取版本号内容
							for (int i = 0; i < buff.length; i++) {
								Log.log("Buff[" + i + "]: " + buff[i]);
							}
							version = new String(buff, 0, len, "UTF-8");
							status.append(",Version:").append(version);
							Log.log("Version: " + version);
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
							buff = new byte[2];
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						status.append(TIMEOUTSTRING) ;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status.append( DISCONNECT);
			}
		}else{
			status.append( DISCONNECT);
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * AD 读取和设置Mac地址的协议
	 * @param ip 
	 * @return
	 */
	public String readSetMacipAD(String ip, byte operateType, byte macLength, String macContent){
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				if(operateType == READOPERATE){
					buffer = new ByteBuffer[]{ByteBuffer.wrap(new byte[] { 1, (byte) 0xAD, operateType})};
					channel.write(buffer);
				} else{
					buffer = new ByteBuffer[]{ByteBuffer.wrap(new byte[] { 1, (byte) 0xAD, operateType, macLength}), ByteBuffer.wrap(macContent.getBytes())};
					channel.write(buffer);
				}
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(AD)) {
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff)); // 版本号内容长度
							len = buff[0];
							if (len == READOPERATE) {
								channel.read(ByteBuffer.wrap(buff));
								len = buff[0];
								buff = new byte[len];
								len = channel.read(ByteBuffer.wrap(buff, 0, len));
								status = new String(buff, 0, len, "UTF-8");
								// ==================================================
							} else if (len == SETOPERATE) {
								channel.read(ByteBuffer.wrap(buff));
								status = Integer.toHexString(Integer
										.valueOf(buff[0]));
							}
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
							buff = new byte[2];
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
		}
		else{
			return DISCONNECT;
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * AE 读取和更改首选网络标识
	 * @param ip 
	 * @return
	 */
	public String readSetNetworkAE(String ip, byte operateType, String apName, byte encryptType, String secretKey){
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				if(operateType == READOPERATE){
					buffer = new ByteBuffer[]{ByteBuffer.wrap(new byte[] { 1, (byte) 0xAE, operateType})};
					for (int i = 0; i < buffer.length; i++) {
						Log.log("\n[READOPERATE]Write Buffer:[" + i + "]: " + buffer[i]);
					}
					channel.write(buffer);
				} else{
					buffer = new ByteBuffer[]{ByteBuffer.wrap(new byte[] { 1, (byte) 0xAE, operateType, (byte) apName.length()}),
							ByteBuffer.wrap(apName.getBytes()), ByteBuffer.wrap(new byte[]{encryptType, (byte) secretKey.length()}), ByteBuffer.wrap(secretKey.getBytes())};
					for (int i = 0; i < buffer.length; i++) {
						Log.log("\n[SetOperate]Write Buffer:[" + i + "]: " + buffer[i]);
					}
					channel.write(buffer);
				}
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				int len;
				while ((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
					if (len != 0) {
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if (cmd.equalsIgnoreCase(AE)) {
							buff = new byte[1];
							channel.read(ByteBuffer.wrap(buff)); // 操作类型
							len = buff[0];
							if (len == READOPERATE) {				//进行读取首选网络标识操作
								Log.log("\n==========READOPERATE=======================================================");
								channel.read(ByteBuffer.wrap(buff));		//读取首选AP名称长度
								len = buff[0];								//首选AP名称长度
								Log.log("\n[首选AP名称长度]: " + len);
								status+="firstAPLength: " + len;
								buff = new byte[len];						//设置首选AP名称长度
								len = channel.read(ByteBuffer.wrap(buff, 0, len));	//读取首选AP名称
								apName = new String(buff, 0, len, "UTF-8");		//转化成AP名称String
								Log.log("\n[AP名称String]: " + apName);
								status+=",apName: " + apName;
								buff = new byte[2];
								len = channel.read(ByteBuffer.wrap(buff));	//读取WEP/WAP
								Log.log("\nWEP len: " + len);
								status+=",WEPlen: " + len;
								encryptType = buff[0];			//WEP/WAP
								Log.log("\n[WEP-WAP]: " + encryptType);
								status+=",WEP-WAP: " + encryptType;
								byte secretKeyLen = buff[1];			//密钥字符串长度
								Log.log("\n密钥字符串长度: " + secretKeyLen);
								status+=",secretKeyLen: " + secretKeyLen;
								buff = new byte[secretKeyLen];
								len = channel.read(ByteBuffer.wrap(buff));	//读取密钥
								for (int i = 0; i < buff.length; i++) {
									Log.log("\n读取密钥 Buff:[" + i + "]: " + buff[i]);
									
								}
								secretKey = new String(buff, 0, len, "UTF-8");
								Log.log("\nSecretKey: " + secretKey);
								status+=",SecretKey: " + secretKey;
								Log.log("\n==========READOPERATE=======================================================");
							} else if (len == SETOPERATE) {				//进行设置首选网络标识操作
								channel.read(ByteBuffer.wrap(buff));
								Log.log("\n==========SetOperate=======================================================");
								status = Integer.toHexString(Integer
										.valueOf(buff[0]));
								Log.log("\nStatus: " + status);
								Log.log("\n==========SetOperate=======================================================");
							}
							break;
						} else {
							// B2，B3命令传过来
							readB1B2B3(channel, cmd);
							buff = new byte[2];
						}
					}
					long end = new Date().getTime();
					if ((end - start) > TIMEOUT) {
						return TIMEOUTSTRING;
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return DISCONNECT;
			}
		}
		return packString(buffer).append(",").append(status).toString();
	}
	
	/**
	 * 获取所有的探头
	 * @return
	 */
	public String getConnectCameras(){
		StringBuilder sb = new StringBuilder();
		for(String str : ServerSocketListener.socketMap.keySet()){
			sb.append(str).append(" | ");
		}
		return sb.toString();
	}
	
//	public static void main(String[] args) {
//		JFrame jFrame = new JFrame();
//		jFrame.setBounds(500, 200, 800, 600);
//		JButton jbutton = new JButton("GetSingleCarCodeA0");
//		jbutton.setBounds(0, 0, 10, 10);
//		final JTextField ipField = new JTextField("", 10);
//		final JTextField carCodeField = new JTextField("", 10);
//		JPanel jPanel = new JPanel();
//		jPanel.setBounds(0, 0, 200, 200);
//		jPanel.add(ipField);
//		jPanel.add(carCodeField);
//		jPanel.add(jbutton);
//		
//		jbutton.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				Log.log(ipField.getText().toString());
//			}
//		});
//		jFrame.add(jPanel);
//		
//		jFrame.setVisible(true);
//		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	}
}
