package com.ie.its.debuggingtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.ie.frame.ExtendData;

public class DebuggingDataMerge extends ExtendData {
	private String videoIpAddr;// 视频探测器/终端机 IP
	private String videoPort;// 视频探测器/终端机 端口
	private String videoStatus;// 视频探测器/终端机 状态
	private String videoGateWayAddr;//视频探测器/终端机 网关地址
	private String jizhongIpAddr;// 集中器 ip
	private String jizhongPort;// 集中器 端口
	private String videoPhotoTime;//拍照週期
	private String carParkNumber;//停車位編號
    private String menu;//菜单选项
	private String videoMaskAddr;//子网掩码

	

	private String carParkEnable;//停車位使能
	private String carParkType;//停車位类型
	private String carParkId;//車位ID
	
	private String totalLengthData;//数据总长度
	private String APNameLen="";//AP名称长度
	private String APName="";//AP名称
	private String singalStrong;//信号强度
	private String version;//版本号
	
	private String encryptType="";//加密類型
    private String keyStrLen="";//密鈅字符串changdu
    private String keyStr="";//密鈅
    
    
	private String versionLen;//版本内容长度
	private String macAddr;//Mac地址内容
   private String macLenth;//Mac地址内容长度
	private String plateData;//车牌号数据

	private List<String> APNameLenList;//AP名称长度list
	private List<String> APNameList;//AP名称长度list
	private List<String> singalStrongList;//AP名称长度list
    private List<String> versionList;//版本号内容list
    private List<String> versionLengthList;//版本号内容长度list

	

	

	private String sendData;//發送數據
	private String returnData;//返回數據
	private List<String> carParkNumbers;
	private List<String> carParkTypes;
	private List<String> carParkStatues;
	private List<String> carParkCurrStates;
	private List<String> carParkPictureBytes;
	private List<String> operations;
	private int pageIndex = 1; // 页码
	private int total; // 总的页数
	private int pageSize = 4; // 每页显示的条数, 默认为5条
	
	public String getMacLenth() {
		return macLenth;
	}

	public void setMacLenth(String macLenth) {
		this.macLenth = macLenth;
	}
	public String getMacAddr() {
		return macAddr;
	}

	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getVersionLen() {
		return versionLen;
	}

	public void setVersionLen(String versionLen) {
		this.versionLen = versionLen;
	}
	public List<String> getVersionLengthList() {
		if(versionLengthList==null){
			versionLengthList=new ArrayList<String>();
		}
		return versionLengthList;
	}

	public void setVersionLengthList(List<String> versionLengthList) {
		this.versionLengthList = versionLengthList;
	}
	public List<String> getVersionList() {
		if(versionList==null){
			versionList=new ArrayList<String>();
		}
		return versionList;
	}

	public void setVersionList(List<String> versionList) {
		this.versionList = versionList;
	}
	public List<String> getAPNameLenList() {
		if(APNameLenList==null){
			APNameLenList=new ArrayList<String>();
		}
		return APNameLenList;
	}

	public void setAPNameLenList(List<String> aPNameLenList) {
		
		APNameLenList = aPNameLenList;
	}

	public List<String> getAPNameList() {
		if(APNameList==null){
			APNameList=new  ArrayList<String>();
		}
		return APNameList;
	}

	public void setAPNameList(List<String> aPNameList) {
		APNameList = aPNameList;
	}

	public List<String> getSingalStrongList() {
		if(singalStrongList==null){
			singalStrongList=new ArrayList<String>();
		}
		return singalStrongList;
	}

	public void setSingalStrongList(List<String> singalStrongList) {
		this.singalStrongList = singalStrongList;
	}
	public String getTotalLengthData() {
		return totalLengthData;
	}

	public void setTotalLengthData(String totalLengthData) {
		this.totalLengthData = totalLengthData;
	}

	public String getAPNameLen() {
		return APNameLen;
	}

	public void setAPNameLen(String aPNameLen) {
		APNameLen = aPNameLen;
	}

	public String getAPName() {
		return APName;
	}

	public void setAPName(String aPName) {
		APName = aPName;
	}

	public String getSingalStrong() {
		return singalStrong;
	}

	public void setSingalStrong(String singalStrong) {
		this.singalStrong = singalStrong;
	}
	public String getVideoMaskAddr() {
		return videoMaskAddr;
	}

	public void setVideoMaskAddr(String videoMaskAddr) {
		this.videoMaskAddr = videoMaskAddr;
	}
	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getCarParkType() {
		return carParkType;
	}

	public void setCarParkType(String carParkType) {
		this.carParkType = carParkType;
	}

	public String getCarParkNumber() {
		return carParkNumber;
	}

	public void setCarParkNumber(String carParkNumber) {
		this.carParkNumber = carParkNumber;
	}

	public String getCarParkEnable() {
		return carParkEnable;
	}

	public void setCarParkEnable(String carParkEnable) {
		this.carParkEnable = carParkEnable;
	}

	public String getVideoPhotoTime() {
		return videoPhotoTime;
	}

	public void setVideoPhotoTime(String videoPhotoTime) {
		this.videoPhotoTime = videoPhotoTime;
	}

	public String getSendData() {
		return sendData;
	}

	public void setSendData(String sendData) {
		this.sendData = sendData;
	}

	public String getReturnData() {
		return returnData;
	}

	public void setReturnData(String returnData) {
		this.returnData = returnData;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public List<String> getCarParkNumbers() {
		return carParkNumbers;
	}

	public void setCarParkNumbers(List<String> carParkNumbers) {
		this.carParkNumbers = carParkNumbers;
	}

	public List<String> getCarParkTypes() {
		return carParkTypes;
	}

	public void setCarParkTypes(List<String> carParkTypes) {
		this.carParkTypes = carParkTypes;
	}

	public List<String> getCarParkStatues() {
		return carParkStatues;
	}

	public void setCarParkStatues(List<String> carParkStatues) {
		this.carParkStatues = carParkStatues;
	}

	public List<String> getCarParkCurrStates() {
		return carParkCurrStates;
	}

	public void setCarParkCurrStates(List<String> carParkCurrStates) {
		this.carParkCurrStates = carParkCurrStates;
	}

	public List<String> getCarParkPictureBytes() {
		return carParkPictureBytes;
	}

	public void setCarParkPictureBytes(List<String> carParkPictureBytes) {
		this.carParkPictureBytes = carParkPictureBytes;
	}

	public void setOperations(List<String> operations) {
		this.operations = operations;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getVideoIpAddr() {
		return videoIpAddr;
	}

	public void setVideoIpAddr(String videoIpAddr) {
		this.videoIpAddr = videoIpAddr;
	}

	public String getVideoPort() {
		return videoPort;
	}

	public void setVideoPort(String videoPort) {
		this.videoPort = videoPort;
	}

	public String getVideoStatus() {
		return videoStatus;
	}

	public void setVideoStatus(String videoStatus) {
		this.videoStatus = videoStatus;
	}

	public List<String> getOperations() {
		return operations;
	}

	public String getCarParkId() {
		return carParkId;
	}

	public void setCarParkId(String carParkId) {
		this.carParkId = carParkId;
	}

	public String getJizhongIpAddr() {
		return jizhongIpAddr;
	}

	public void setJizhongIpAddr(String jizhongIpAddr) {
		this.jizhongIpAddr = jizhongIpAddr;
	}

	public String getJizhongPort() {
		return jizhongPort;
	}

	public void setJizhongPort(String jizhongPort) {
		this.jizhongPort = jizhongPort;
	}
    
	public void setVideoGateWayAddr(String videoGateWayAddr) {
		this.videoGateWayAddr = videoGateWayAddr;
	}

	public String getVideoGateWayAddr() {
		// TODO Auto-generated method stub
		return videoGateWayAddr;
	}

	public String getPlateData() {
		return plateData;
	}

	public void setPlateData(String plateData) {
		this.plateData = plateData;
	}

	public String getEncryptType() {
		return encryptType;
	}

	public void setEncryptType(String encryptType) {
		this.encryptType = encryptType;
	}

	public String getKeyStrLen() {
		return keyStrLen;
	}

	public void setKeyStrLen(String keyStrLen) {
		this.keyStrLen = keyStrLen;
	}

	public String getKeyStr() {
		return keyStr;
	}

	public void setKeyStr(String keyStr) {
		this.keyStr = keyStr;
	}
}
