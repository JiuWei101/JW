/**
 * Copy Right Information   : 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.debuggingtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ie.frame.ExtendData;

public class BootScreen extends ExtendData {

	private String groupAddr="";// 组地址
	private String screenAddr="";// 屏地址
	private String versionNo="";// 版本号

	//基礎參數設置
	   //串口设置
	private String serialPort="";//串口
	private List<Object>  baudRate =new ArrayList<Object>();//波特率
	private String dataBits="";//數據位
	private  List<Object> parity=new ArrayList<Object>();;//校驗位
	private String stopBit="";//停止位
	    //條屏參數設置
	private String scrrenWidth="";// 宽度
	private String scrrenHeight="";// 高度
	private String xOff="";// x偏移
	private String yoff="";// y偏移
	private String showContent="";// 顯示内容
	private String enableReverse="";//使能反向
	private String anti_color_display="";//反色显示
	private List<Object> scanning=new ArrayList<Object>();;//扫描方式
	//标准发送
	private String moveSpeed="";//移动速度
	private String stayTime="";//停留时间
	private String screenBright="";//亮度
	private String dutyCycle="";//占空比
	private List<Object> colorList=new ArrayList<Object>();//颜色列表
	private String font="";//字体
	private String comOld="";//兼容旧款
	private String scanningMethod="";//扫描方式
	private String sendTime="";//发送次数
	private String waitTime="";//等待时间
	private String interTime="";//间隔时间
	private String sendContent="";//发送内容
	private String successNumber;//成功次数
	
	private String successRatio;//成功率
	private String sendData="";
	
	private String returnData="";
	
	private String driveSelect;//驱动选择
	private String colorDisplay;//反色显示
	private String menu;//菜单操作
	
	private List<Object>displayStyleList=new ArrayList<Object>(); //显示方式集合
	
	
	
	private int pageIndex = 1; // 页码
	private int total; // 总的页数
	private int pageSize = 4; // 每页显示的条数, 默认为5条
	public int getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getGroupAddr() {
		return groupAddr;
	}
	public void setGroupAddr(String groupAddr) {
		this.groupAddr = groupAddr;
	}
	public String getScreenAddr() {
		return screenAddr;
	}
	public void setScreenAddr(String screenAddr) {
		this.screenAddr = screenAddr;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public String getSerialPort() {
		return serialPort;
	}
	public void setSerialPort(String serialPort) {
		this.serialPort = serialPort;
	}
	public List<Object>getBaudRate() {
		if(baudRate==null||baudRate.size()==0){
			int start=300;
			char ch='a';
			for(int i=0;i<12;i++){
				BootScreen bot=new BootScreen();
				 start=2*start;
				if(i==0){
					start=300;
				}
				bot.setCode_id(ch++ +"");
				bot.setCode_name(start+"");
				baudRate.add(bot);
			}
		}
		
		
		return baudRate;
	}
	public void setBaudRate(List<Object> baudRate) {
		this.baudRate = baudRate;
	}
	public String getDataBits() {
		
		
		return dataBits;
	}
	public void setDataBits(String dataBits) {
		this.dataBits = dataBits;
	}
	public List <Object>getParity() {
		if(parity==null||parity.size()==0){
			for (int i=0;i<5; i++){
				BootScreen bot=new BootScreen();
				switch (i){
				case 0:{bot.setCode_id("a");bot.setCode_name("None");};break;
				case 1:{bot.setCode_id("b");bot.setCode_name("Old");};break;
				case 2:{bot.setCode_id("c");bot.setCode_name("Even");};break;
				case 3:{bot.setCode_id("d");bot.setCode_name("Mark");};break;
				case 4:{bot.setCode_id("e");bot.setCode_name("Space");};break;
				}
				parity.add(bot);
			}
			
			
		}
		return parity;
	}
	public void setParity(List<Object> parity) {
		this.parity = parity;
	}
	public String getStopBit() {
		return stopBit;
	}
	public void setStopBit(String stopBit) {
		this.stopBit = stopBit;
	}
	public String getScrrenWidth() {
		return scrrenWidth;
	}
	public void setScrrenWidth(String scrrenWidth) {
		this.scrrenWidth = scrrenWidth;
	}
	public String getScrrenHeight() {
		return scrrenHeight;
	}
	public void setScrrenHeight(String scrrenHeight) {
		this.scrrenHeight = scrrenHeight;
	}
	public String getxOff() {
		return xOff;
	}
	public void setxOff(String xOff) {
		this.xOff = xOff;
	}
	public String getYoff() {
		return yoff;
	}
	public void setYoff(String yoff) {
		this.yoff = yoff;
	}
	public String getShowContent() {
		return showContent;
	}
	public void setShowContent(String showContent) {
		this.showContent = showContent;
	}
	public String getEnableReverse() {
		return enableReverse;
	}
	public void setEnableReverse(String enableReverse) {
		this.enableReverse = enableReverse;
	}
	public String getAnti_color_display() {
		return anti_color_display;
	}
	public void setAnti_color_display(String anti_color_display) {
		this.anti_color_display = anti_color_display;
	}
	public List<Object> getScanning() {
		
		return scanning;
	}
	public void setScanning(List<Object> scanning) {
		this.scanning = scanning;
	}

	
	public String getSendData() {
		return sendData;
	}
	public void setSendData(String sendData) {
		this.sendData = sendData;
	}
	public String getReturnData() {
		return returnData;
	}
	public void setReturnData(String returnData) {
		this.returnData = returnData;
	}
	
	public String getDriveSelect() {
		return driveSelect;
	}
	public void setDriveSelect(String driveSelect) {
		this.driveSelect = driveSelect;
	}
	public String getColorDisplay() {
		return colorDisplay;
	}
	public void setColorDisplay(String colorDisplay) {
		this.colorDisplay = colorDisplay;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public List<Object> getDisplayStyleList() {
		
		
		return displayStyleList;
	}
	public void setDisplayStyleList(List<Object> displayStyleList) {
		this.displayStyleList = displayStyleList;
	}
	public String getMoveSpeed() {
		return moveSpeed;
	}
	public void setMoveSpeed(String moveSpeed) {
		this.moveSpeed = moveSpeed;
	}
	public String getStayTime() {
		return stayTime;
	}
	public void setStayTime(String stayTime) {
		this.stayTime = stayTime;
	}
	public String getScreenBright() {
		return screenBright;
	}
	public void setScreenBright(String screenBright) {
		this.screenBright = screenBright;
	}
	public String getDutyCycle() {
		return dutyCycle;
	}
	public void setDutyCycle(String dutyCycle) {
		this.dutyCycle = dutyCycle;
	}
	public List<Object> getColorList() {
		return colorList;
	}
	public void setColorList(List<Object> colorList) {
		this.colorList = colorList;
	}
	public String getFont() {
		return font;
	}
	public void setFont(String font) {
		this.font = font;
	}
	public String getComOld() {
		return comOld;
	}
	public void setComOld(String comOld) {
		this.comOld = comOld;
	}
	public String getScanningMethod() {
		return scanningMethod;
	}
	public void setScanningMethod(String scanningMethod) {
		this.scanningMethod = scanningMethod;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}
	public String getWaitTime() {
		return waitTime;
	}
	public void setWaitTime(String waitTime) {
		this.waitTime = waitTime;
	}
	public String getInterTime() {
		return interTime;
	}
	public void setInterTime(String interTime) {
		this.interTime = interTime;
	}
	public String getSendContent() {
		return sendContent;
	}
	public void setSendContent(String sendContent) {
		this.sendContent = sendContent;
	}
	public String getSuccessNumber() {
		return successNumber;
	}
	public void setSuccessNumber(String successNumber) {
		this.successNumber = successNumber;
	}
	public String getSuccessRatio() {
		return successRatio;
	}
	public void setSuccessRatio(String successRatio) {
		this.successRatio = successRatio;
	}
}
