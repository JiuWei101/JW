/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.debuggingtool;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Map;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;

import org.springframework.stereotype.Service;

import com.ie.frame.ExtendService;

@Scope("prototype")
@Service
public class DebugginService extends ExtendService {
	private DebugginSql debugSql;

	public DebugginService() {
		debugSql = new DebugginSql();
	}

	/*
	 * 列表查询 (non-Javadoc)
	 * 
	 * @see com.forsoft.xzl.common.ExtendService#listData(java.lang.Object)
	 */

	public Object listData(Object o) {
		DebuggingDataMerge debuggingDataMer = (DebuggingDataMerge) o;
		List<DebuggingData> degugList = null;
		if(debuggingDataMer.getId()!=null&&(!debuggingDataMer.getId().equals(""))){
			
			degugList=debugSql.parkInfo_list(debuggingDataMer.getId());
		}else{
			degugList=debugSql.parkInfo_list("count");
		}
		//封装数据
		List<DebuggingDataMerge> debuggingDataMerges = new ArrayList<DebuggingDataMerge>();
		for (int i = 0; i < degugList.size(); i++) {
			DebuggingData debugData = degugList.get(i);
			DebuggingDataMerge tempDebuggDataMerge = null;
			if (debuggingDataMerges.size() == 0
					|| recordExits(debugData, debuggingDataMerges)) {
				List<String> carParkNumbers = new ArrayList<String>();
				List<String> carParkTypes = new ArrayList<String>();
				List<String> carParkStatues = new ArrayList<String>();
				List<String> carParkCurrStates = new ArrayList<String>();
				List<String> carParkPictureBytes = new ArrayList<String>();
				List<String> operations = new ArrayList<String>();
				tempDebuggDataMerge = new DebuggingDataMerge();
				tempDebuggDataMerge.setVideoIpAddr(debugData.getVideoIp());
				tempDebuggDataMerge.setVideoPort(debugData.getVideoPort());
				tempDebuggDataMerge.setVideoStatus(debugData.getVideoStatus());
				carParkNumbers.add(debugData.getCarParkNumber());
				tempDebuggDataMerge.setCarParkNumbers(carParkNumbers);
				carParkTypes.add(debugData.getCarParkType());
				tempDebuggDataMerge.setCarParkTypes(carParkTypes);
				carParkStatues.add(debugData.getCarParkStatus());
				tempDebuggDataMerge.setCarParkStatues(carParkStatues);
				carParkCurrStates.add(debugData.getCarParkCurrStatus());
				tempDebuggDataMerge.setCarParkCurrStates(carParkCurrStates);
				carParkPictureBytes.add(debugData.getCarPictueBytes());
				tempDebuggDataMerge.setCarParkPictureBytes(carParkPictureBytes);
				/*operations.add("operation");
				tempDebuggDataMerge.setOperations(operations);*/
				debuggingDataMerges.add(tempDebuggDataMerge);
				// tempDebuggDataMerge.set
			}

		}
		
		int temp = debuggingDataMerges.size() % debuggingDataMer.getPageSize();

		// 每页显示的整数倍
		if (debuggingDataMerges.size() >= debuggingDataMer.getPageSize()
				&& temp == 0) {
			debuggingDataMer.setTotal(debuggingDataMerges.size()
					/ debuggingDataMer.getPageSize());
			// 没有1页
		} else if (debuggingDataMerges.size() <= debuggingDataMer.getPageSize()
				&& temp != 0) {
			debuggingDataMer.setTotal(1);
			// 不是每页显示的整数倍
		} else {
			debuggingDataMer.setTotal(debuggingDataMerges.size()
					/ debuggingDataMer.getPageSize() + 1);
		}

		// 调用方法设置分页信息 需要参数count
		debuggingDataMer.setStartExt(debuggingDataMerges.size());

		ArrayList<DebuggingDataMerge> rows = null;
		int pageIndex = debuggingDataMer.getPageIndex();
		int pageSize = debuggingDataMer.getPageSize();
		if (pageIndex != -1 && pageSize != -1) {
			int start = pageIndex * pageSize - pageSize;
			int end = pageIndex * pageSize - 1;
			if (rows == null) {
				rows = new ArrayList<DebuggingDataMerge>();
			}
			while (start <= end && start < debuggingDataMerges.size()) {

				rows.add(debuggingDataMerges.get(start++));

			}
		}
		debuggingDataMer.setPer_data(rows);
		return debuggingDataMer;
	}
	//取得所有条屏的信息
	public Object listScrrenData(Object o) {
		BootScreen bootScreen = (BootScreen) o;
		List<BootScreen> screenList = debugSql.screen_list("count");
		int temp = screenList.size() % bootScreen.getPageSize();

		// 每页显示的整数倍
		if (screenList.size() >= bootScreen.getPageSize()
				&& temp == 0) {
			bootScreen.setTotal(screenList.size()
					/ bootScreen.getPageSize());
			// 没有1页
		} else if (screenList.size() <= bootScreen.getPageSize()
				&& temp != 0) {
			bootScreen.setTotal(1);
			// 不是每页显示的整数倍
		} else {
			bootScreen.setTotal(screenList.size()
					/ bootScreen.getPageSize() + 1);
		}

		// 调用方法设置分页信息 需要参数count
		bootScreen.setStartExt(screenList.size());

		ArrayList<BootScreen> rows = null;
		int pageIndex = bootScreen.getPageIndex();
		int pageSize = bootScreen.getPageSize();
		if (pageIndex != -1 && pageSize != -1) {
			int start = pageIndex * pageSize - pageSize;
			int end = pageIndex * pageSize - 1;
			if (rows == null) {
				rows = new ArrayList<BootScreen>();
			}
			while (start <= end && start < screenList.size()) {

				rows.add(screenList.get(start++));

			}
		}
		bootScreen.setPer_data(rows);
		return bootScreen;
		
	}
	// 检查记录是否存在,没有就新建.
	public boolean recordExits(DebuggingData debugData,
			List<DebuggingDataMerge> debuggingDataMerges) {
		boolean flag = false;
		if (debuggingDataMerges.size() == 0) {
			flag = true;
		} else {
			flag = true;
			for (int i = 0; i < debuggingDataMerges.size(); i++) {
				if (debuggingDataMerges.get(i).getVideoIpAddr()
						.equals(debugData.getVideoIp())) {
					flag = false;
					DebuggingDataMerge tempData = debuggingDataMerges.get(i);
					tempData.getCarParkNumbers().add(
							debugData.getCarParkNumber());
					tempData.getCarParkTypes().add(debugData.getCarParkType());
					tempData.getCarParkStatues().add(
							debugData.getCarParkStatus());
					tempData.getCarParkCurrStates().add(
							debugData.getCarParkCurrStatus());
					tempData.getCarParkPictureBytes().add(
							debugData.getCarPictueBytes());
					//tempData.getOperations().add("operation");
					// debuggingDataMerges.add(tempData);
					break;
				}

			}

		}
		return flag;
	}

	// 调试工具的一系列命令
	public DebuggingDataMerge updateDebugTool(DebuggingDataMerge data,
			String ids, String meus) {
		String[] oldip = ids.split(";");
		String sendData = "";
		String returnData = "";
		String returnFrom = "";
		String ips = "";
		for (int i = 0; i < oldip.length; i++) {
			if (meus.equals("final")) {//A4命令更改终端机IP地址及网关地址
				returnFrom += new CameraDebug().changeTerminalIpNetWrokA4(oldip[i],data.getVideoIpAddr(), data.getVideoMaskAddr(),data.getVideoGateWayAddr(),
						Integer.parseInt(data.getVideoPort())) + ":";
				if(returnFrom.indexOf(",")!=-1){
					if (returnFrom.split(",")[1].startsWith("update success")) {
						ips += oldip[i] + ",";
					}
				}
				
			} else if (meus.equals("jizhong")) {//A６更改终端机的集中器IP地址和端口号
				returnFrom += new CameraDebug().changeDetectorIpNetWrokA6(oldip[i],data.getJizhongIpAddr(),
						Integer.parseInt(data.getJizhongPort()))
						+ ":";
			} else if (meus.equals("phototime")) {//AA命令更改终端机拍照周期
				returnFrom += new CameraDebug().setupPictureCycleAA(oldip[i],Integer.parseInt(data.getVideoPhotoTime()))
						+ ":";
			} else if (meus.equals("carenable")) {//A3命令禁用或使能车位
				String ip = oldip[i].split("-")[0];
				String carNumber = oldip[i].split("-")[1];
				returnFrom += new CameraDebug().setupCarEnabledA3(ip,Byte.parseByte(carNumber),Byte.parseByte(data.getCarParkEnable()))
						+ ":";
				if(returnFrom.indexOf(",")!=-1){
					if (returnFrom.split(",")[1].startsWith("update success!")) {
						ips += ip + "," + carNumber + "," + data.getCarParkEnable()
								+ ";";
					}
				}
				

			} else if (meus.equals("cartype")) {//A2命令设置车位类型
				String ip = oldip[i].split("-")[0];
				String carNumber = oldip[i].split("-")[1];
				returnFrom += new CameraDebug().setupCarTypeA2(ip, Byte.parseByte(carNumber),Byte.parseByte(data.getCarParkType())) + ":";
				if(returnFrom.indexOf(",")!=-1){
					if (returnFrom.split(",")[1].startsWith("update success!")) {
						ips += ip + "," + carNumber + "," + data.getCarParkType()
								+ ";";
					}
				}
				
			} else if (meus.equals("carNumber")) {//A7更改车位ID对应的车位编号
				String ip = oldip[i].split("-")[0];
				String carNumber = oldip[i].split("-")[1];
				returnFrom += new CameraDebug().changeCarCodeA7(ip,(byte) (Byte.parseByte(carNumber) - Byte.parseByte("1")), Byte.parseByte(data.getCarParkNumber()))
						+ ":";
				if(returnFrom.indexOf(",")!=-1){
					if (returnFrom.split(",")[1].startsWith("update success!")) {
						ips += ip + "," + carNumber + "," + data.getCarParkNumber()
								+ ";";
					}
				}
				
			} else if(meus.equalsIgnoreCase("setNetWork")){
				//returnFrom += new CameraDebug().readSetNetworkAE(oldip[i], Byte.parseByte("1"), apName, encryptType, secretKey)+ ":";
			}
		}

		returnFrom = returnFrom.substring(0, returnFrom.length() - 1);
		String[] returnArr = null;
		if (returnFrom.indexOf(":") != -1) {
			returnArr = returnFrom.split(":");
			for (int j = 0; j < returnArr.length; j++) {
				sendData += returnArr[j].split(",")[0] + "\n";
				returnData += returnArr[j].split(",")[1] + "\n";
			}
		} else {
			returnArr = returnFrom.split(",");
			sendData += returnArr[0];
			returnData += returnArr[1];
		}
		// 重新读取xml文件
		if (!ips.equals("")) {
			if (meus.equals("final")) {
				debugSql.updateXmlFile(ips.substring(0, ips.length() - 1),
						data.getVideoIpAddr(), data.getVideoPort());
			} else {
				debugSql.updateXmlFile(ips.substring(0, ips.length() - 1), meus);
			}
		}

		data.setReturnData(returnData);
		data.setSendData(sendData);
		
		return data;
	}

	// 显示车位图片
	public DebuggingDataMerge getCarPictures(
			DebuggingDataMerge debuggingDataMerge,String path) {
	    String ips[]=debuggingDataMerge.getId().split("-");
		String ip = ips[0];
		String returnMess="";
		JSONObject json=Check_Connect(ip);
		if(!json.getBoolean("success")){
			returnMess=json.getString("mx");
			debuggingDataMerge.setReturnData("failer,"+returnMess);
		}else  {
			byte carCode = Byte.parseByte(ips[1]);
			CameraDebug camerDebug=new CameraDebug();
			returnMess= camerDebug.getSingleCarCodeA0(ip, carCode,path);//A0命令读取视频探测器下单个车位的当前状态
			camerDebug=null;//释放掉,方便GC回收
			String tempStr = "";
			if (returnMess.startsWith("failer")) {
				debuggingDataMerge.setReturnData(returnMess);

			} else {
				String retur[] = returnMess.split(",");
				for (int i = 0; i < retur.length; i++) {
					String str[] = retur[i].split("=");
					if (str[0].trim().equalsIgnoreCase("filePath")) {
						tempStr = str[1].trim();
						tempStr = tempStr.substring(0, tempStr.length() - 1);
						break;
					}else if(str[0].trim().equalsIgnoreCase("plateData")){
						if(str.length!=1){
							tempStr=str[1].trim();
						}
						else 
							{
							tempStr="No car data!";
							}
						debuggingDataMerge.setPlateData(tempStr);
					}
				}
				debuggingDataMerge.setReturnData(tempStr);
				String splitArr[] = tempStr.split("/");
				for (int i = 0; i < splitArr.length; i++) {
					if (splitArr[i].indexOf(".jpg") != -1) {
						debuggingDataMerge.setReturnData(splitArr[i]);
						break;
					}
				}
			}
		}
		

		return debuggingDataMerge;
	}
    //增加组地址和屏地址
	public JSONObject addScreen(String groupAddr, String screenAddr) {
		List<BootScreen> screenList = debugSql.screen_list("count");
		JSONObject json = new JSONObject();
		JSONArray jsonArrTemp=null;
		String str="";
		for(int i=0;i<screenList.size();i++){
			BootScreen bootsc=screenList.get(i);
			if(bootsc.getGroupAddr().equals(groupAddr)&&(bootsc.getScreenAddr().equals(screenAddr))){
				str="group address and screenAddress repeat!";
				json.element("success", false);
				break;
			}
		}
		if(str.equals("")){
			BootScreen boot=new BootScreen();
			boot.setId(screenList.size()+1+"");
			boot.setGroupAddr(groupAddr);
			boot.setScreenAddr(screenAddr);
			screenList.add(boot);
			debugSql.updateScreenXml("", screenList);
			jsonArrTemp = new JSONArray();
			jsonArrTemp.add(screenList.size()+1);
			jsonArrTemp.add(groupAddr);
			jsonArrTemp.add(screenAddr);
			json.element("data", jsonArrTemp);
			json.element("success", true);
			str="add success!";
		}
		json.element("ms", str);
		return json;
		//return jsonArrTemp;
	}
//A8命 令  读取终端机IP地址、掩码地址、网关地址、端口
	public DebuggingDataMerge readA8(DebuggingDataMerge debuggingDataMerge) {
		
		String ip=debuggingDataMerge.getId();
		String returnStr = new CameraDebug().readTreminalIpA8(ip);
		String retur[]=returnStr.split(",");
		for(int i=0;i<retur.length;i++){
			if(retur[i].replaceAll("n", "").indexOf(":")!=-1){
			String str []=	retur[i].split(":");
			 if(str[0].startsWith("\nReturnIp")){
				 debuggingDataMerge.setVideoIpAddr(str[1]);
			 }	else if(str[0].startsWith("\nIpMask")){
				 debuggingDataMerge.setVideoMaskAddr(str[1]);
			 }else if(str[0].startsWith("\nReturnNetwork")){
				 debuggingDataMerge.setVideoGateWayAddr(str[1]);
			 }else if(str[0].startsWith("\nPort")){
				 debuggingDataMerge.setVideoPort(str[1]);
			 }
			}
		}
		return debuggingDataMerge;
	}
//A5读取终端机的集中器IP地址和端口号
	public DebuggingDataMerge readDetectorIpA5(
			DebuggingDataMerge debuggingDataMerge) {
		String ip=debuggingDataMerge.getId();
		String returnStr = new CameraDebug().readDetectorIpA5(ip);
		String retur[]=returnStr.split(",");
		for(int i=0;i<retur.length;i++){
			if(retur[i].indexOf(":")!=-1){
				String str []=	retur[i].split(":");
				if(str[0].startsWith("jizhongipaddr")){
					debuggingDataMerge.setJizhongIpAddr(str[1]);
				}
				else if(str[0].startsWith("jizhongport")){
					debuggingDataMerge.setJizhongPort(str[1]);
				}
			}
			
		}
		
		return debuggingDataMerge;
	}
	//A9命令 读取终端机拍照周期
	public DebuggingDataMerge readPictureCycleA9(
			DebuggingDataMerge debuggingDataMerge) {
		String ip=debuggingDataMerge.getId();
		String returnStr = new CameraDebug().readPictureCycleA9(ip);
		String retur[]=returnStr.split(",");
		for(int i=0;i<retur.length;i++){
			if(retur[i].indexOf(":")!=-1){
				String str []=	retur[i].split(":");
				if(str[0].startsWith("phototime")){
					debuggingDataMerge.setVideoPhotoTime(str[1]);
				}
				
			}
			
		}
		return debuggingDataMerge;
	}
	//AB读取终端机信号强度
	public DebuggingDataMerge getFinallSignalStrong(DebuggingDataMerge debuggingDataMerge) {
		String ipArr[]=getStrArr(debuggingDataMerge);
		List<DebuggingDataMerge> debugList=new ArrayList<DebuggingDataMerge>();
		String res;
		CameraDebug camer=new CameraDebug();
			for(String ip:ipArr){
				res=camer.readSignalStrengthAB(ip);
				DebuggingDataMerge debug=delwithRes(res,ip);
				if(debug!=null)
				debugList.add(debug);
		    }
		
			debuggingDataMerge.setPer_data(debugList);
		return debuggingDataMerge;
	}
  
	public String [] getStrArr(DebuggingDataMerge debuggingDataMerge){
	  String ips=debuggingDataMerge.getId();
		String ipArr[];
		if(ips.indexOf(";")==-1){
			ips+=";";
			}
		ipArr=ips.split(";");
	  return ipArr;
	  
  }
	//读取终端机信号强度 封装数据
	public DebuggingDataMerge delwithRes(String res,String ip) {
		
		String tem[]=res.split(",");
		DebuggingDataMerge tempDebugdata=null;
		if(!tem[1].startsWith("failer")){
			tempDebugdata=new DebuggingDataMerge();
			tempDebugdata.setVideoIpAddr(ip);
			tempDebugdata.setSendData(tem[0]);
			tempDebugdata.setTotalLengthData(tem[1].split(":")[1]);
			for(int i=2;i<tem.length;i++){
				String data[]=tem[i].split(":");
			     if(data[0].trim().equalsIgnoreCase("ApNameLen")){
			    	tempDebugdata.getAPNameLenList().add(data[1]);
			    }else if(data[0].trim().equalsIgnoreCase("ApName")){
			    	tempDebugdata.getAPNameList().add(data[1]);
			    }else if(data[0].trim().equalsIgnoreCase("SignalIntensity")){
			    	tempDebugdata.getSingalStrongList().add(data[1]);
			    }
			}
			//debugList.add(tempDebugdata);
		}
		return tempDebugdata;
	}
	//读取版本号 封装数据
public DebuggingDataMerge getVersion(String res,String ip) {
		
		String tem[]=res.split(",");
		DebuggingDataMerge tempDebugdata=null;
		
		
		if(!tem[1].startsWith("failer")){
			tempDebugdata=new DebuggingDataMerge();
			tempDebugdata.setVideoIpAddr(ip);
			tempDebugdata.setSendData(tem[0]);
			
			for(int i=1;i<tem.length;i++){
				String data[]=tem[i].split(":");
			     if(data[0].trim().equalsIgnoreCase("VersionContentLen")){
			    	tempDebugdata.getVersionLengthList().add(data[1]);
			    }else if(data[0].trim().equalsIgnoreCase("Version")){
			    	tempDebugdata.getVersionList().add(data[1]);
			    }
			}
			//debugList.add(tempDebugdata);
		}
		return tempDebugdata;
	}
//AC读取终端机程序版本号
	public DebuggingDataMerge getFinallversion(DebuggingDataMerge debuggingDataMerge) {
		String ipArr[]=getStrArr(debuggingDataMerge);
		String res;
		List<DebuggingDataMerge> debugList=new ArrayList<DebuggingDataMerge>();
		CameraDebug camer=new CameraDebug();
		for(String ip:ipArr){
			res=camer.readVersionAC(ip);
			DebuggingDataMerge debug=getVersion(res,ip);
			debugList.add(debug);
		}
		debuggingDataMerge.setPer_data(debugList);
		return debuggingDataMerge;
	}
 //检查是否能连接上
	public JSONObject Check_Connect(String id){
		JSONObject json=new JSONObject();
	  String ips[] = null;
		String tempStr = "";
		if (id.indexOf(";") != -1) {// 有多个ip需要连接
			ips = id.split(";");
			if (ips[0].indexOf("-") != -1) {// 对车位进行的操作192.36.27.31-002;192.36.27.31-001
											// 形式
				for (int i = 0; i < ips.length; i++) {
					tempStr += ips[i].split("-")[0] + ",";
				}
			} else {// 对探测器进行的操作 192.36.27.31;192.36.27.32
				for (int i = 0; i < ips.length; i++) {
					tempStr += ips[i] + ",";
				}
			}
		} else {
			if (id.indexOf("-") != -1) {// 192.36.27.31-002形式
				tempStr += id.split("-")[0] + ",";
			} else {// 192.36.27.31形式
				tempStr += id + ",";
			}
		}
		tempStr = tempStr.substring(0, tempStr.length() - 1);
		Map<String, SocketChannel> con = ServerSocketListener.socketMap;
		if (tempStr.indexOf(",") != -1) {
			ips = tempStr.split(",");
			int k = 0;
			for (int i = 0; i < ips.length; i++) {
				if(ServerSocketListener.getInstance().getSocketThreadStatus()!=null){
					SocketChannel channel = con.get(ips[i]);
					if (channel == null) {
						json.element("success", false);
						json.element("mx", ips[i] + "is disconnected!");
						k++;
						break;
					}
				}else{
					json.element("success", false);
					json.element("mx",  "please open debugToolService!");
				}
				
			}
			if (k == 0) {
				json.element("success", true);
			}
		} else {
			SocketChannel channel = null;
			if (ServerSocketListener.getInstance().getSocketThreadStatus()!=null) {
				channel = con.get(tempStr);
				if (channel != null) {
					json.element("success", true);

				} else {
					json.element("success", false);
					json.element("mx", tempStr + "is disconnected!");
				}
			} else {
				json.element("success", false);
				json.element("mx",  "please open debugToolService!");
			}

		}
		return json;
	} 
  //读取和设置Mac地址的协议
	public DebuggingDataMerge getAndSetMacAddr(DebuggingDataMerge debuggingDataMerge) {
		String menu=debuggingDataMerge.getMenu();
		String ip=debuggingDataMerge.getId();
		CameraDebug camdebug=new CameraDebug();
		if(menu.equals("readmacaddr")){
			String res[]=camdebug.readSetMacipAD(ip, Byte.parseByte("0"), Byte.parseByte("0"), "").split(",");
			debuggingDataMerge.setSendData(res[0]);
			debuggingDataMerge.setMacAddr(res[1]);
			debuggingDataMerge.setReturnData(res[1]);
		}else{
			String res[]=camdebug.readSetMacipAD(ip, Byte.parseByte("1"),  Byte.parseByte(debuggingDataMerge.getMacLenth()), debuggingDataMerge.getMacAddr()).split(",");
			debuggingDataMerge.setSendData(res[0]);
			debuggingDataMerge.setReturnData(res[1]);
		}
		return debuggingDataMerge;
		
		
	}
//一系列下拉框的集合
	public List<Object> getDropDownList(String lang,int length,String operation) {
		List <Object>objectList=new ArrayList<Object>();
		
		for (int i=0;i<length; i++){
			BootScreen bot=new BootScreen();
			if(lang.equals("44")){//英语
				if(operation.equals("scanning")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("1/16 scan mode A mode");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("1/16 scan mode B mode");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("1/8 scan mode ");};break;
					case 3:{bot.setCode_id(i+"");bot.setCode_name("1/4 scan mode A mode");};break;
					case 4:{bot.setCode_id(i+"");bot.setCode_name("1/4 scan mode B mode");};break;
					case 5:{bot.setCode_id(i+"");bot.setCode_name("1/4 scan mode C mode");};break;
					case 6:{bot.setCode_id(i+"");bot.setCode_name("1/4 scan mode D mode");};break;
					
					}
				}else if(operation.equals("display")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("That is remarkable");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("shift up ");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("descending development");};break;
					case 3:{bot.setCode_id(i+"");bot.setCode_name("ascending development");};break;
					case 4:{bot.setCode_id(i+"");bot.setCode_name("left shift");};break;
					case 5:{bot.setCode_id(i+"");bot.setCode_name("scroll arrow");};break;
					}
				}else if(operation.equals("color")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("Red");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("Green");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("Yellow");};break;
					
					}
				}
				
			}else if(lang.equals("86")){//中文
				if(operation.equals("scanning")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("1/16 扫描方式A模式");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("1/16 扫描方式B模式");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("1/8 扫描方式");};break;
					case 3:{bot.setCode_id(i+"");bot.setCode_name("1/4 扫描方式A模式");};break;
					case 4:{bot.setCode_id(i+"");bot.setCode_name("1/4 扫描方式B模式");};break;
					case 5:{bot.setCode_id(i+"");bot.setCode_name("1/4 扫描方式C模式");};break;
					case 6:{bot.setCode_id(i+"");bot.setCode_name("1/4 扫描方式D模式");};break;
					
					}
				} else if(operation.equals("display")) {

					switch(i){
					case 0 :{bot.setCode_id(i+"");bot.setCode_name("即显");};break;
					case 1 :{bot.setCode_id(i+"");bot.setCode_name("上移");};break;
					case 2 :{bot.setCode_id(i+"");bot.setCode_name("下展开");};break;
					case 3 :{bot.setCode_id(i+"");bot.setCode_name("上展开");};break;
					case 4 :{bot.setCode_id(i+"");bot.setCode_name("左移");};break;
					case 5 :{bot.setCode_id(i+"");bot.setCode_name("动态箭头");};break;
					}
				}else if(operation.equals("color")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("红");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("绿");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("黄");};break;
					
					}
				}
				
			}else {//中文繁体
				if(operation.equals("scanning")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("1/16 掃描方式A模式");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("1/16 掃描方式B模式");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("1/8 掃描方式");};break;
					case 3:{bot.setCode_id(i+"");bot.setCode_name("1/4 掃描方式A模式");};break;
					case 4:{bot.setCode_id(i+"");bot.setCode_name("1/4 掃描方式B模式");};break;
					case 5:{bot.setCode_id(i+"");bot.setCode_name("1/4 掃描方式C模式");};break;
					case 6:{bot.setCode_id(i+"");bot.setCode_name("1/4 掃描方式D模式");};break;
					
					}
				}else if(operation.equals("display")) {
					switch(i){
					case 0 :{bot.setCode_id(i+"");bot.setCode_name("即顯");};break;
					case 1 :{bot.setCode_id(i+"");bot.setCode_name("上移");};break;
					case 2 :{bot.setCode_id(i+"");bot.setCode_name("下展開");};break;
					case 3 :{bot.setCode_id(i+"");bot.setCode_name("上展開");};break;
					case 4 :{bot.setCode_id(i+"");bot.setCode_name("左移");};break;
					case 5 :{bot.setCode_id(i+"");bot.setCode_name("動態箭頭");};break;
					}
				}else if(operation.equals("color")){
					switch (i){
					case 0:{bot.setCode_id(i+"");bot.setCode_name("紅");};break;
					case 1:{bot.setCode_id(i+"");bot.setCode_name("綠");};break;
					case 2:{bot.setCode_id(i+"");bot.setCode_name("黃");};break;
					
					}
				}
				
			}
			
				objectList.add(bot);
		}
		
		
		return objectList;
		
	}


	//读取和更改網絡標示AE
	public DebuggingDataMerge getAndSetNetWork(DebuggingDataMerge debuggingDataMerge) {
		String menu=debuggingDataMerge.getMenu();
		String ip=debuggingDataMerge.getId();
		CameraDebug camdebug=new CameraDebug();
		if(menu.trim().equalsIgnoreCase("readNetWork")){
		 String res[]=	camdebug.readSetNetworkAE(ip, Byte.parseByte("0"), "", Byte.parseByte("0"), "").split(",");
		 for(int i=0;i<res.length;i++){
             if(res[i].indexOf(":")!=-1){
            	 String str[]=res[i].split(":");
            	 if(str[0].trim().equalsIgnoreCase("firstAPLength")){
                 	debuggingDataMerge.setAPNameLen(str[1].trim());
                 }else if(str[0].trim().equalsIgnoreCase("apName")){
                 	debuggingDataMerge.setAPName(str[1].trim());
                 }else if(str[0].trim().equalsIgnoreCase("WEP-WAP")){
                 	debuggingDataMerge.setEncryptType(str[1].trim());
                 }else if(str[0].trim().equalsIgnoreCase("secretKeyLen")){
                 	debuggingDataMerge.setKeyStrLen(str[1].trim());
                 }else if(str[0].trim().equalsIgnoreCase("SecretKey")){
                 	debuggingDataMerge.setKeyStr(str[1].trim());
                 }	
             }else{
            	 debuggingDataMerge.setSendData(res[i].trim());
             }
			 		 
		 }
		
		}
		
		return debuggingDataMerge;
	}

	/*
	 * public Object saveData(Object o) { UserData user = (UserData) o; String
	 * id = PrimaryId.getId(); List list = new ArrayList();
	 * if(user.getState().equals("1")){ user.setState("01"); }else
	 * if(user.getState().equals("0")){ user.setState("00"); } StringBuffer sb =
	 * new StringBuffer();
	 * sb.append("insert into sys_user(id,user_name,password,state) ");
	 * sb.append(" values('"); sb.append(id); sb.append("','");
	 * sb.append(StringManager.reSingleQuote(user.getUser_name()));
	 * sb.append("','"); sb.append(Encrypt.EncryptString(user.getPassword()));
	 * sb.append("','"); sb.append(user.getState()+"')");
	 * list.add(sb.toString()); if(user.getCheck1() != null){ String[] sqls =
	 * new String[user.getCheck1().length]; for(int
	 * i=0;i<user.getCheck1().length;i++){
	 * sqls[i]="insert into sys_user_role(id,role_id,user_id) " +
	 * "values('"+PrimaryId.getId()+"','"+user.getCheck1()[i]+"'," +
	 * "'"+id+"')"; list.add(sqls[i]); } } String[] sqlArr = new
	 * String[list.size()]; getJt().batchUpdate((String[])
	 * list.toArray(sqlArr)); // jt.update(sb.toString()); return o; }
	 */

	/*
	 * 用户详细信息查询 (non-Javadoc)
	 * 
	 * @see com.forsoft.xzl.common.ExtendService#readData(java.lang.Object)
	 */

	/*
	 * public Object updateData(Object o) { UserData user = (UserData) o; List
	 * list = new ArrayList(); if(user.getState().equals("1")){
	 * user.setState("01"); }else if(user.getState().equals("0")){
	 * user.setState("00"); } StringBuffer sb = new StringBuffer();
	 * sb.append("update sys_user set user_name = '" ); sb.append(
	 * StringManager.reSingleQuote(user.getUser_name()) ); sb.append( "',");
	 * if(user.getPassword() != null && !"".equals(user.getPassword())){
	 * sb.append(" password = '");
	 * sb.append(Encrypt.EncryptString(user.getPassword())); sb.append("',"); }
	 * sb.append(" state = '"); sb.append(user.getState());
	 * sb.append("' where id = '" ); sb.append( user.getId() ); sb.append( "'");
	 * list.add(sb.toString());
	 * 
	 * String delsql =
	 * "delete from sys_user_role where user_id = '"+user.getId()+"'";
	 * list.add(delsql);
	 * 
	 * if(user.getCheck1() != null){ String[] sqls = new
	 * String[user.getCheck1().length]; for(int
	 * i=0;i<user.getCheck1().length;i++){
	 * sqls[i]="insert into sys_user_role(id,role_id,user_id) " +
	 * "values('"+PrimaryId.getId()+"','"+user.getCheck1()[i]+"'," +
	 * "'"+user.getId()+"')"; list.add(sqls[i]); } } String[] sqlArr = new
	 * String[list.size()]; getJt().batchUpdate((String[])
	 * list.toArray(sqlArr));
	 * 
	 * return o; }
	 */

	/*
	 * public Object deleteData(Object o){ UserData user = (UserData) o;
	 * String[] id= user.getId().split(";"); String [] sql = new
	 * String[id.length]; for(int i = 0;i < id.length;i++){
	 * sql[i]="delete from sys_user where id = "+Util.toSqlVal(id[i]); }
	 * getJt().batchUpdate(sql); return user; }
	 * 
	 * public Object elseData(Object o) { UserData user = (UserData) o; String
	 * sql = "select count(*) from sys_user where user_name = '" +
	 * user.getUser_name() + "'"; if(user.getId() != null &&
	 * !"".equals(user.getId())){ sql += " and id <> '"+user.getId()+"'"; } int
	 * count = getJt().queryForInt(sql); if (count > 0) { return "yes"; } return
	 * "no"; }
	 * 
	 * public void updateData(UserData user, String str) {
	 * 
	 * String sql = " update sys_user set state='"+str+"' where id = " +
	 * Util.toSqlVal(user.getId());
	 * 
	 * getJt().update(sql);
	 * 
	 * }
	 * 
	 * public String conditions(UserData user){ StringBuffer sb = new
	 * StringBuffer(); sb.append(" from sys_user u  ");
	 * sb.append(" where 1=1 ");
	 * 
	 * if(user.getUser_name() != null &&
	 * !"".equals(user.getUser_name().trim())){
	 * sb.append(" and u.user_name like '%"
	 * +StringManager.reSingleQuote(user.getUser_name().trim())+"%' "); }
	 * if(user.getState() != null && !"".equals(user.getState().trim())){
	 * sb.append
	 * (" and u.state = '"+StringManager.reSingleQuote(user.getState().trim
	 * ())+"'"); }
	 * 
	 * return sb.toString(); }
	 * 
	 * public Object rolelist(UserData user){ StringBuffer sb = new
	 * StringBuffer(); sb.append("select id,role_name from sys_role");
	 * user.setRoleslist(getJt().queryForList(sb.toString())); return user; }
	 * 
	 * public Object rolestr(UserData user){ StringBuffer sb = new
	 * StringBuffer(); sb.append("select role_id from sys_user_role ");
	 * sb.append(" where user_id = '"+user.getId()+"'"); List list =
	 * getJt().queryForList(sb.toString()); Iterator it = list.iterator();
	 * String rolestr = null; while(it.hasNext()){ Map map = (Map)it.next();
	 * if(rolestr==null){ rolestr=(String)map.get("role_id"); }else{ rolestr +=
	 * ","+(String)map.get("role_id"); } } user.setRolestr(rolestr); return
	 * user; }
	 * 
	 * public Object rolename(UserData user){ StringBuffer sb = new
	 * StringBuffer();
	 * sb.append("select r.role_name as role_name from sys_user_role u, sys_role r "
	 * ); sb.append(" where u.role_id=r.id and u.user_id = '"+user.getId()+"'");
	 * List list = getJt().queryForList(sb.toString()); Iterator it =
	 * list.iterator(); String rolename = null; while(it.hasNext()){ Map map =
	 * (Map)it.next(); if(rolename==null){
	 * rolename=(String)map.get("role_name"); }else{ rolename +=
	 * ","+(String)map.get("role_name"); } } user.setRolestr(rolename); return
	 * user; }
	 */
}
