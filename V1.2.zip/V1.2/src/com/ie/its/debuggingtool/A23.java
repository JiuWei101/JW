package com.ie.its.debuggingtool;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Date;

public class A23 {
	private final static String A2 = "a2";
	private final static String A3 = "a3";
	private final static String A4 = "a4";
	private final String A5 = "a5";
	private final static String A6 = "a6";
	private final static String A7 = "a7";
	private final String A8 = "a8";
	private final String A9 = "a9";
	private final static String AA = "aa";

	/**
	 * A2命令设置车位类型
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String setupCarType(String ip, byte carCode, byte carType) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;	
		if (channel != null) {
			// 数据格式 type,cmd,carCode, carType
			try {
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA2,
						carCode, carType });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A2)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status = "update success!"+ip+"-->"+carCode+"-->"+Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						status= "failer !"+ip+"-->"+carCode+"Connect time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= "failer !"+ip+"-->"+carCode+ "IP Cameras has been disconnected";
			} // 写命令
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status= ""+ip+"-->"+carCode+"failer ! Cameras has been disconnected";
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A3命令禁用或使能车位
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String setupCarEnabled(String ip, byte carCode, byte enabled) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;	
		if (channel != null) {
			// 数据格式 type,cmd,carCode, enabled
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA3,
						carCode, enabled });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A3)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status = "update success!"+ip+"-->"+carCode+"-->"+Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						status= "failer !"+ip+"-->"+carCode+"Connect time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= ""+ip+"-->"+carCode+"failer !  Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status= ""+ip+"-->"+carCode+"failer ! Cameras has been disconnected....";
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A4命令更改终端机IP地址及网关地址
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String changeTerminalIpNetWrok(String ip, String newIp,
			String newNetwork, int port) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// type,cmd,Segment1,Segment2,Segment3,Segment4,G-Segment1,G-Segment2,G-Segment3,G-Segment4,port
			try {// 发送命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xA4 }),
						ByteBuffer.wrap(stringToBytes(newIp)),
						ByteBuffer.wrap(stringToBytes(newNetwork)),
						ByteBuffer.wrap(intToBytes(port, 2)) };
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A4)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status ="update success!"+ newIp+"-->"+Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						status= "failer !"+ip+"-->11 Time out failure";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= "failer !"+ip+"--> 11 Cameras has been disconnected failure";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status="failer !"+ ip+"--->11 Cameras has been disconnected failure";
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A5读取终端机的集中器IP地址和端口号
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public String readDetectorIp(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String returnNetwork = "";
		int port = 0;
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA5 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A5)) {
						buff = new byte[4];
						channel.read(ByteBuffer.wrap(buff));
						returnNetwork = ipPackage(buff);
						buff = new byte[2];
						channel.read(ByteBuffer.wrap(buff));
						port = bytesToInt(buff, 2);
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						return "Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return "IP Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			return "IP Cameras has been disconnected....";
		}
		return packString(buffer).append(",").append(returnNetwork + " " + port).toString();
	}

	/**
	 * A６更改终端机的集中器IP地址和端口号
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String changeDetectorIpNetWrok(String ip, String newIp, int port) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,Segment1,Segment2,Segment3,Segment4,port
			try {// 发送命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xA6 }),
						ByteBuffer.wrap(stringToBytes(newIp)),
						ByteBuffer.wrap(intToBytes(port, 2)) };
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A6)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status ="success!"+ip+"-->"+ Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) { // 如果超过５秒仍未接收到正确的数据就返回ＴＩＭＥＯＵＴ
						status ="failer!"+ip+"Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status ="failer!"+ip+ " Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status ="failer!"+ip+ " Cameras has been disconnected....";
		}
		
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A7更改车位ID对应的车位编号
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String changeCarCode(String ip, byte carId, byte carCode) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,carId, carCode
			try { // 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA7, carId,
						carCode });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A7)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status = "update success!"+ip+"-->"+ Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						status= "failer!"+ip+ "Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status= "failer!"+ip+" Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status= "failer!"+ip+" Cameras has been disconnected....";
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * A8读取终端机IP地址、网关地址、端口
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public String readTreminalIp(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String returnIp = "";
		String returnNetwork = "";
		int port = 0;
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA8 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A8)) {
						buff = new byte[4];
						channel.read(ByteBuffer.wrap(buff));
						returnIp = ipPackage(buff);
						channel.read(ByteBuffer.wrap(buff));
						returnNetwork = ipPackage(buff);
						buff = new byte[2];
						channel.read(ByteBuffer.wrap(buff));
						port = bytesToInt(buff, 2);
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						return "Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return "IP Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			return "IP Cameras has been disconnected....";
		}
		return packString(buffer).append(",").append(returnIp + " " + returnNetwork + " " + port).toString();
	}

	/**
	 * A9命令
	 * 读取终端机拍照周期
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public String readPictureCycle(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String period = "";
		ByteBuffer buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd
			try {// 写命令
				buffer = ByteBuffer.wrap(new byte[] { 1, (byte) 0xA9 });
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(A9)) {
						buff = new byte[2];
						channel.read(ByteBuffer.wrap(buff));
						period = bytesToInt(buff, buff.length) + "";
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						return "Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return "IP Cameras has been disconnected....";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			return "IP Cameras has been disconnected....";
		}
		return packString(buffer).append(",").append(period).toString();
	}

	/**
	 * AA命令更改终端机拍照周期
	 * 
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String setupPictureCycle(String ip, int period) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip); // 根据ＩＰ获取对应的channel
		String status = "";
		ByteBuffer[] buffer = null;
		if (channel != null) {
			// 数据格式 type,cmd,period
			try {// 写命令
				buffer = new ByteBuffer[] {
						ByteBuffer.wrap(new byte[] { 1, (byte) 0xAA }),
						ByteBuffer.wrap(intToBytes(period, 2)) };
				channel.write(buffer);
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while (true) { // 读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if (cmd.equalsIgnoreCase(AA)) {
						buff = new byte[1];
						channel.read(ByteBuffer.wrap(buff));
						status = Integer.toHexString(Integer.valueOf(buff[0]));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						status="failer!"+ ip+"Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				status="failer!"+ ip+" Cameras has been disconnected";
			}
		} else {
			ServerSocketListener.socketMap.remove(ip);
			status="failer!"+ ip+" Cameras has been disconnected";
		}
		return packString(buffer).append(",").append(status).toString();
	}

	/**
	 * IP地址的包装
	 * @param buff
	 * @return
	 */
	private String ipPackage(byte[] buff) {
		StringBuilder sb = new StringBuilder();
		if(buff!=null){
			for (byte b : buff) {
				Integer i = Integer.parseInt(
						Integer.toHexString(Integer.valueOf(b) & 0xFF), 16);
				sb.append(i).append(".");
			}
		}
		
		return sb.substring(0, sb.length() - 1);
	}

	/**
	 * String 转成 byte[]
	 * 
	 * @param address
	 * @return
	 */
	private static byte[] stringToBytes(String address) {
		String[] addrs = address.split("\\.");
		byte[] buff = new byte[addrs.length];
		for (int i = 0; i < addrs.length; i++) {
			buff[i] = (byte) Integer.parseInt(addrs[i]);
		}
		return buff;
	}

	/**
	 * int类型转换成byte[]
	 * 
	 * @param num
	 * @return byte[]
	 */
	private static byte[] intToBytes(int num, int length) {
		byte[] b = new byte[length];
		for (int i = 0; i < length; i++) {
			b[i] = (byte) (num >>> ((length * 4) - i * 8));
		}
		return b;
	}

	/**
	 * 将byte数组bRefArr转为一个整数,字节数组的低位是整型的低字节位
	 * 
	 * @param bRefArr
	 * @return
	 */
	private static int bytesToInt(byte[] bRefArr, int length) {
		int iOutcome = 0;
		byte bLoop;
		if(bRefArr!=null){
			for (int i = 0; i < length; i++) {
				bLoop = bRefArr[i];
				iOutcome += (bLoop & 0xFF) << (8 * (length - i - 1));
			}
		}
		
		return iOutcome;
	}
	
	/**
	 * 封装返回到前台的数据
	 * @param buffer	发送到终端的数据格式
	 * @param status	返回的结果
	 * @return
	 */
	private static StringBuilder packString(ByteBuffer buffer){
		StringBuilder sb = new StringBuilder();
		if(buffer!=null){
			for(byte buff : buffer.array()){
				String hexStr = Integer.toHexString(buff & 0xFF);	//转成16进制
				sb.append(hexStr.length() == 1 ? 0 + hexStr : hexStr).append(" ");
			}
		}
		
		return sb;
	}
	
	/**
	 * 封装返回到前台的数据
	 * @param buffer
	 * @param status
	 * @return
	 */
	private static StringBuilder packString(ByteBuffer[] buffer){
		StringBuilder sb = new StringBuilder();
		if(buffer!=null){
			for(ByteBuffer buff : buffer){
				sb.append(packString(buff));
			}
				
		}
		return sb;
	}
}

