package com.ie.its.debuggingtool;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.ie.common.Log;

public class ServerSocketListener extends CommonMethod{
	private SocketThread socketThread;
	protected static Map<String, SocketChannel> socketMap = new HashMap<String, SocketChannel>();
	private static ServerSocketListener instance = new ServerSocketListener();  
	private String path = "";
	private ServerSocketListener(){
	     
	}
	
	public static ServerSocketListener getInstance() {
		if (instance == null) {
			instance = new ServerSocketListener();
		}
		return instance;
	}
	public  SocketThread  getSocketThreadStatus(){
		return socketThread;
	}
	
	//关闭线程
	public void contextDestroyed() {
		socketThread.closeServerSocket();
		socketThread = null;
	}

	public void contextInitialized() {
		System.out.println("Listener Start............");
		if(socketThread == null){
			socketThread = new SocketThread();
			socketThread.start();
		}
	}
	
	class SocketThread extends Thread{
		private ServerSocketChannel serverSocket;
		private Selector selector;
		private boolean flag;
		public SocketThread(){
			flag = true;
			int port = 5234;		//从web
			if(serverSocket == null){
				try{
					this.serverSocket = ServerSocketChannel.open();
					selector = Selector.open();						//打开selector
					serverSocket.socket().setReuseAddress(true);	//使得关闭服务器后再次启动服务器程序可以顺利绑定相同的端口
					serverSocket.socket().bind(new InetSocketAddress(port));		//绑定监听端口
					serverSocket.configureBlocking(false);							//设置为非阻塞式
					serverSocket.register(selector, SelectionKey.OP_ACCEPT);		//注册监听器,当有接受到连接时
				} catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}
		
		@Override
		public void run() {
			System.out.println("ServerSocket服务器启动......");
			while(flag){
				try {
					this.selector.select();			//监听连接
					if(this.selector.isOpen()){		//如果selector打开的情况下监听到连接执行下面的程序,否则因为selector关闭就不执行
						Iterator<SelectionKey> iter = selector.selectedKeys().iterator();
						while(iter.hasNext()){
							SelectionKey key = (SelectionKey) iter.next();
							iter.remove();
							if(key.isAcceptable()){
								ServerSocketChannel ssc = (ServerSocketChannel) key.channel();
								SocketChannel channel = ssc.accept();
								channel.configureBlocking(false);
								InetAddress addr = channel.socket().getInetAddress();
								putSocketMap(addr.getHostAddress(), channel);	//将连接添加到socketMap中
								System.out.println("HashMap: " + socketMap);
								channel.register(this.selector, SelectionKey.OP_READ);
							}
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println("Selector err....");
				}
			}
			System.out.println("ServerSocket服务器运行结束,正在退出线程......");
		}
		
		/**
		 * 将指定的连接添加到Map里去
		 * @param hostAddr
		 */
		public void putSocketMap(String hostAddr, SocketChannel channel){
			try {
				path = (getClass().getClassLoader().getResource("").toURI())
				.getPath();		//获取src的绝对路径　
				String file = path + "/debugTool/CarParkInfoXml.xml";
				List<DebuggingData> list = CommonMethod.parserCarParkXml(file);	//解析CarParkInfoXml.xml文件
				for(DebuggingData dd : list){
					if(dd.getVideoIp().equalsIgnoreCase(hostAddr)){		//判断连接上来的探测器是否在配置文件里有记录
						if(!socketMap.containsKey(hostAddr)){		//如果在配置文件里有记录,并且socketMap里没有就直接添加到socketMap里
							socketMap.put(hostAddr, channel);	   //把连接保存在一个map里
						} else{									//否则先将原来的hostAddr对应的channel去掉,再往socketMap里添加.防止出现重复的ip
							socketMap.remove(hostAddr);
							socketMap.put(hostAddr, channel);	   //把连接保存在一个map里
						}
						//设备连接后读取B命令==============================================================
						byte[] buff = new byte[2];
						int len;
						if((len = channel.read(ByteBuffer.wrap(buff))) != -1) {
							if (len != 0) { // 读取
								String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
								Log.log("\nB cmd: Return CMD is ( " + cmd + " )");
								// B2，B3命令传过来
								readB1B2B3(channel, cmd);
							}
						}
						//==============================================================						
					}
				}
			} catch (URISyntaxException e) {
				System.out.println("URISyntaxException...");
			} catch (IOException e) {
				Log.log("[" + hostAddr + "]: 读取B命令出错.");
			}
		}
		
		/**
		 * 关闭线程
		 */
		public void closeServerSocket(){
			socketMap = new HashMap<String, SocketChannel>();		//将socketMap所占的内存清掉
			flag = false;			//将flag置为false用于退出循环
			try {
				if (this.selector.isOpen()) {		//关闭selector退出监听的阻塞状态
					this.selector.close();
				}
				if (this.serverSocket != null){		//关闭socket
					this.serverSocket.socket();
					this.serverSocket.close();
					this.serverSocket = null;
				}
			} catch (IOException e) {
				Log.log("CloseServerSocket exception...");
			}
		}
	}
}
