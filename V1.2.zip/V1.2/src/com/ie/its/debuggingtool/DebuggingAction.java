package com.ie.its.debuggingtool;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.channels.SocketChannel;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.frame.ExtendActionSupport;

@SuppressWarnings("serial")
@Namespace("/debug")
@Results({
		@Result(name = "editFinalMachineIpGateway", location = "/system_manage/editFinalMachine.jsp"),
		@Result(name = "editJizhongMachineIpPort", location = "/system_manage/editGizhongMachine.jsp"),
		@Result(name = "editFinalMachinePhotoTime", location = "/system_manage/editPhotoTime.jsp"),
		@Result(name = "editCarParkEnable", location = "/system_manage/editEnable.jsp"),
		@Result(name = "editCarParkType", location = "/system_manage/editCarPrkType.jsp"),
		@Result(name = "editCarParkNumber", location = "/system_manage/editCarPrkNumber.jsp"),
		@Result(name = "showCarPictures", location = "/system_manage/showCarPictures.jsp"),
		//最後四個命令
		@Result(name = "readFinalSingal", location = "/system_manage/readFinalSingal.jsp"),
		@Result(name = "readFinalVersion", location = "/system_manage/readFinalVersion.jsp"),
		@Result(name = "readSetMacAddr", location = "/system_manage/readSetMacAddr.jsp"),
		@Result(name = "changeFirstNetwork", location = "/system_manage/changeFirstNetwork.jsp"),
		
		@Result(name = "refresh", location = "debug_index.action", type = "redirect"),
		
      //條屏的參數設置
		@Result(name = "parmeterSetup", location = "/system_manage/boot_screen/parmeterSetup.jsp"),
		@Result(name = "standDataSend", location = "/system_manage/boot_screen/standDataSend.jsp"),
		@Result(name = "groupAddrSet", location = "/system_manage/boot_screen/groupAddrSet.jsp")

})
public class DebuggingAction extends ExtendActionSupport {
	private DebuggingDataMerge debuggingDataMerge;
	private BootScreen bootScreen;

	@Autowired
	private DebugginService debuggingService;

	// private List<DebuggingData> debuggingList;//封装数据的list
	public BootScreen getBootScreen() {
		return bootScreen;
	}

	public void setBootScreen(BootScreen bootScreen) {
		this.bootScreen = bootScreen;
	}

	public DebuggingAction() {
		if (debuggingDataMerge == null) {
			debuggingDataMerge = new DebuggingDataMerge();
		}
		if (bootScreen == null) {
			bootScreen = new BootScreen();
		}
	}

	public DebuggingDataMerge getDebuggingDataMerge() {
		return debuggingDataMerge;
	}

	public void setDebuggingDataMerge(DebuggingDataMerge debuggingDataMerge) {
		this.debuggingDataMerge = debuggingDataMerge;
	}

	@Action(value = "debug_index", results = { @Result(name = "success", location = "/system_manage/debuggingtool.jsp") })
	public String debuggIndex() {
		debuggingDataMerge = (DebuggingDataMerge) debuggingService
				.listData(debuggingDataMerge);
		setLang(debuggingDataMerge);
		bootScreen = (BootScreen) debuggingService.listScrrenData(bootScreen);
		setLang(bootScreen);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA,
				debuggingDataMerge.getPer_data());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA,
				bootScreen.getPer_data());
		return SUCCESS;

	}

	
	@Action(value = "debug_edit")
	public String debuggEdit() {

		// debuggingDataMerge.setId(request.getParameter("id"));
		String menu = debuggingDataMerge.getMenu();

		setLang(debuggingDataMerge);
		if (menu.equals("final")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.readA8(debuggingDataMerge);
			return ConstantClass.DEBUG_FINALGATEWAY;
		} else if (menu.equals("jizhong")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.readDetectorIpA5(debuggingDataMerge);
			return ConstantClass.DEBUG_JIZHONGMACHINE;
		} else if (menu.equals("phototime")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.readPictureCycleA9(debuggingDataMerge);
			return ConstantClass.DEBUG_PHOTOTIME;
		} else if (menu.equals("enable")) {
			return ConstantClass.DEBUG_CARPARKENABLE;
		} else if (menu.equals("cartype")) {
			return ConstantClass.DEBUG_CARPARKTYPE;
		} else if (menu.equals("carnumber")) {
			return ConstantClass.DEBUG_CARPARKNUMBER;
		} else if (menu.equals("showPicture")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.getCarPictures(debuggingDataMerge,request.getRealPath("/"));
			return ConstantClass.DEBUG_CARPARKPICTURE;
		} else if (menu.equals("readsingal")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.getFinallSignalStrong(debuggingDataMerge);
			return ConstantClass.DEBUG_READ_FINAL_SINGAL;
		} else if (menu.equals("readversion")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.getFinallversion(debuggingDataMerge);
			return ConstantClass.DEBUG_READ_FINAL_VERSION;
		} else if (menu.equals("readmacaddr")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.getAndSetMacAddr(debuggingDataMerge);
			return ConstantClass.DEBUG_READ_SET_MACADDRESS;
		}else if (menu.equals("readNetWork")) {
			debuggingDataMerge = (DebuggingDataMerge) debuggingService.getAndSetNetWork(debuggingDataMerge);
			return ConstantClass.DEBUG_CHANGE_FIRST_NETWORK;
		}else {
			return ConstantClass.DEBUG_REFRESH;
		}

	}

	// 检查是否能建立连接
	@Action(value = "debug_checkCon", results = { @Result(type = "json") })
	public void checkConnection() {
		
		JSONObject json = new JSONObject();
			
			try {
				String id = URLDecoder.decode(request.getParameter("id"), "UTF-8");
				json=debuggingService.Check_Connect(id);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			setJsonRes(json);
	}

	@Action(value = "debug_update", results = { @Result(type = "json") })
	public void debuggUpadate() {
		String id = request.getParameter("id");
		String menu = request.getParameter("menu");
		JSONObject json = new JSONObject();
		DebuggingDataMerge dataMerge = null;
		try {
			if (menu.equals("final")) {
				String videoIpAddr = URLDecoder.decode(request.getParameter("ipAddress"), "UTF-8");
				String gataAWay = URLDecoder.decode(request.getParameter("gataAWay"), "UTF-8");
				String airPort = URLDecoder.decode(request.getParameter("airPort"), "UTF-8");
				String subMask = URLDecoder.decode(request.getParameter("subMask"), "UTF-8");
				dataMerge = new DebuggingDataMerge();
				dataMerge.setVideoIpAddr(videoIpAddr);
				dataMerge.setVideoGateWayAddr(gataAWay);
				dataMerge.setVideoPort(airPort);
				dataMerge.setVideoMaskAddr(subMask);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			} else if (menu.equals("jizhong")) {
				dataMerge = new DebuggingDataMerge();
				String jizhongIpAddr = URLDecoder.decode(request.getParameter("jizhongIpAddr"), "UTF-8");
				String jizhongPort = URLDecoder.decode(request.getParameter("jizhongPort"), "UTF-8");
				dataMerge.setJizhongIpAddr(jizhongIpAddr);
				dataMerge.setJizhongPort(jizhongPort);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			} else if (menu.equals("phototime")) {
				dataMerge = new DebuggingDataMerge();
				String videoPhotoTime = URLDecoder.decode(request.getParameter("videoPhotoTime"), "UTF-8");
				dataMerge.setVideoPhotoTime(videoPhotoTime);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			} else if (menu.equals("carenable")) {
				dataMerge = new DebuggingDataMerge();
				String carParkEnable = URLDecoder.decode(request.getParameter("carParkEnable"), "UTF-8");
				dataMerge.setCarParkEnable(carParkEnable);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			} else if (menu.equals("cartype")) {
				dataMerge = new DebuggingDataMerge();
				String carParkType = URLDecoder.decode(request.getParameter("carParkType"), "UTF-8");
				dataMerge.setCarParkType(carParkType);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			} else if (menu.equals("carNumber")) {
				dataMerge = new DebuggingDataMerge();
				String carParkNumber = URLDecoder.decode(request.getParameter("carParkNumber"), "UTF-8");
				dataMerge.setCarParkNumber(carParkNumber);
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			}else if (menu.equals("setNetWork")) {
				dataMerge = new DebuggingDataMerge();
				String APNameLen = URLDecoder.decode(request.getParameter("APNameLen"), "UTF-8");
				
				dataMerge = (DebuggingDataMerge) debuggingService.updateDebugTool(dataMerge, id, menu);
			}
			if (dataMerge != null) {
				json.element("success", true);
				json.element("sm", dataMerge);
			} else {
				json.element("success", false);
				json.element("fm", "the data is null!");
			}
			setJsonRes(json);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Action(value = "add_screen", results = { @Result(type = "json") })
	public void add_screen() {
		try {
			String groupAddr = URLDecoder.decode(
					request.getParameter("groupAddr"), "UTF-8");
			String screenAddr = URLDecoder.decode(
					request.getParameter("screenAddr"), "UTF-8");
			// JSONObject json = new JSONObject();
			JSONObject json = debuggingService.addScreen(groupAddr, screenAddr);

			setJsonRes(json);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Action(value = "screen_edit")
	public String screen_edit() {

		String menu = null;
		String res = "";
		try {
			menu = URLDecoder.decode(bootScreen.getMenu(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//获得扫描方式下拉框
		bootScreen.setScanning(debuggingService.getDropDownList(request.getSession().getAttribute("lang").toString(),6,"scanning"));
		//获得显示方式下拉框
		bootScreen.setDisplayStyleList(debuggingService.getDropDownList(request.getSession().getAttribute("lang").toString(),5,"display"));
		bootScreen.setColorList(debuggingService.getDropDownList(request.getSession().getAttribute("lang").toString(), 3, "color"));
		setLang(bootScreen);
		
		if (menu != null && !menu.equals("")) {
			
			if (menu.trim().equals("parme")) {
				res = ConstantClass.DEBUG_SCREEN_PAR;
			} else if (menu.trim().equals("standsend")) {
				res = ConstantClass.DEBUG_SCREEN_STNADSEND;
			} else {
				res = ConstantClass.DEBUG_SCREEN_GROUP_ADDR_SET;
			}
		}
		return res;

	}
}
