package com.ie.its.debuggingtool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.StringManager;

public abstract class CommonMethod {

	protected final String B1 = "b1";
	private final String B2 = "b2";
	private final String B3 = "b3";

	protected static int LENGTH_INDEX = 1024;
	protected List<CarData> list = new ArrayList<CarData>();
	protected final String WINPATH = "d:/pgs/carUploadImage/"; // Windows下图片的存储路径
	protected final String CENTOSPATH = "/usr/its/CameraDebug/carImage/"; //CentOS下图片的存储路径
	// 图片的存储路径

	/**
	 * IP地址的包装
	 * 
	 * @param buff
	 * @return
	 */
	protected String ipPackage(byte[] buff) {
		StringBuilder sb = new StringBuilder();
		for (byte b : buff) {
			Integer i = Integer.parseInt(
					Integer.toHexString(Integer.valueOf(b) & 0x000000FF), 16);
			sb.append(i).append(".");
		}
		return sb.substring(0, sb.length() - 1);
	}

	/**
	 * String 转成 byte[]
	 * 
	 * @param address
	 * @return
	 */
	protected byte[] stringToBytes(String address) {
		String[] addrs = address.split("\\.");
		byte[] buff = new byte[addrs.length];
		for (int i = 0; i < addrs.length; i++) {
			buff[i] = (byte) Integer.parseInt(addrs[i]);
		}
		return buff;
	}

	/**
	 * int类型转换成byte[]
	 * 
	 * @param num
	 * @return byte[]
	 */
	protected static byte[] intToBytes(int num, int length) {
		byte[] b = new byte[length];
		for (int i = 0; i < length; i++) {
			b[i] = (byte) (num >>> ((length * 4) - i * 8));
		}
		return b;
	}

	/**
	 * 将byte数组bRefArr转为一个整数,字节数组的低位是整型的低字节位
	 * 
	 * @param bRefArr
	 * @return
	 */
	protected static int bytesToInt(byte[] bRefArr, int length) {
		int iOutcome = 0;
		byte bLoop;
		for (int i = 0; i < length; i++) {
			bLoop = bRefArr[i];
			iOutcome += (bLoop & 0x000000FF) << (8 * (i)); // 高8位在前,低8位在后
		}
		return iOutcome;
	}

	/**
	 * 封装返回到前台的数据
	 * 
	 * @param buffer
	 *            发送到终端的数据格式
	 * @param status
	 *            返回的结果
	 * @return
	 */
	protected StringBuilder packString(ByteBuffer buffer) {
		StringBuilder sb = new StringBuilder();
		if (buffer != null) {
			for (byte buff : buffer.array()) {
				String hexStr = Integer.toHexString(buff & 0x000000FF); // 转成16进制
				sb.append(hexStr.length() == 1 ? 0 + hexStr : hexStr).append(
						" ");
			}
		}
		return sb;
	}

	/**
	 * 封装返回到前台的数据
	 * 
	 * @param buffer
	 * @param status
	 * @return
	 */
	protected StringBuilder packString(ByteBuffer[] buffer) {
		StringBuilder sb = new StringBuilder();
		if(buffer!=null){
			for (ByteBuffer buff : buffer) {
				sb.append(packString(buff));
			}
		}
		
		return sb;
	}

	/**
	 * 读取终端机发送过来的B2B3命令
	 * 
	 * @param channel
	 */
	protected void readB1B2B3(SocketChannel channel, String cmd) {
		try {
			if (cmd.equalsIgnoreCase(B1)) { // 终端机连接上主机后主动上传所有使能车位状态
				Log.log("B1==============================");
				byte[] buff = new byte[1]; // 读取一个字节获取上传几组车位状态
				channel.read(ByteBuffer.wrap(buff));
				Log.log(buff[0]);
				Log.log("\n" + getListCarData(channel, buff[0],""));
				Log.log("B1==============================");
			} else if (cmd.equalsIgnoreCase(B2)) {
				Log.log("B2==============================");
				Log.log("\n" + getListCarData(channel, 1,""));
				Log.log("B2==============================");
			} else if (cmd.equalsIgnoreCase(B3)) {
				Log.log("B3==============================");
				Log.log("\n" + getListCarData(channel, 1,""));
				Log.log("B3==============================");
			}
		} catch (IOException e) {
			Log.log("读取B2B3命令时发生错误...");
		}
	}

	/**
	 * 获取探测器下多个车位的信息列表
	 * 
	 * @param channel
	 *            SocketChannel
	 * @param carCount
	 * @return
	 * @throws IOException
	 */
	protected List<CarData> getListCarData(SocketChannel channel, int carCount,String path)
			throws IOException {
		List<CarData> listCar = new ArrayList<CarData>();
		while (carCount-- > 0) {
			byte[] buff = new byte[4];
			channel.read(ByteBuffer.wrap(buff));
			CarData car = new CarData();
			car.setCarCode(buff[0]);
			car.setStatus(buff[1]);
			car.setCarType(buff[2]);
			car.setPlateLen(buff[3]);
			buff = new byte[car.getPlateLen()]; // 读取车牌号码============================================
			channel.read(ByteBuffer.wrap(buff, 0, car.getPlateLen())); // 读取车牌号码============================================
			car.setPlateData(new String(buff, 0, car.getPlateLen(), "UTF-8")); // 设置车牌号码====================================
			listCar.add(car);
		}
		Log.log("\n==================================================================================================");
		Log.log("\n" + listCar);
		Log.log("\n==================================================================================================");
		carCount = listCar.size();
		int index = 0;
		while (carCount-- > 0) {
			byte[] pbuff = new byte[4]; // 读取图片长度====================
			int pl;
			while ((pl = channel.read(ByteBuffer.wrap(pbuff))) != -1) {
				if (pl != 0) {
					String pl4 = Integer
							.toBinaryString((int) pbuff[0] & 0x000000FF); // 第四位
					Log.log("pl4: " + pl4);
					String pl3 = Integer
							.toBinaryString(((int) pbuff[1] & 0x000000FF) << 8); // 第三位
					Log.log("pl3: " + pl3);
					String pl2 = Integer
							.toBinaryString(((int) pbuff[2] & 0x000000FF) << 16); // 第二位
					Log.log("pl2: " + pl2);
					String pl1 = Integer
							.toBinaryString(((int) pbuff[3] & 0x000000FF) << 32); // 第一位
					Log.log("pl1: " + pl1);
					String pl5 = Integer.toBinaryString(Integer
							.parseInt(pl1, 2) | Integer.parseInt(pl2, 2));
					String pl6 = Integer.toBinaryString(Integer
							.parseInt(pl5, 2) | Integer.parseInt(pl3, 2));
					int pl7 = Integer.parseInt(pl6, 2)
							| Integer.parseInt(pl4, 2); // 读完
					int count = pl7 / LENGTH_INDEX; // 将图片的长度分成N部分来读取，每部分的长度为LENGTH_INDEX
					int surplus = pl7 % LENGTH_INDEX; // 标记剩余的部分
					Log.log("Pl7: " + pl7);
					int len = 0;
					FileOutputStream fos = null;
					SimpleDateFormat sdf = new SimpleDateFormat(
							"yyyyMMddHHmmss");
					String filePath="";
					// FilePath 要修改
					if(!path.equals("")){
						filePath = StringManager.replaceAll(path,"\\","/") + ConstantClass.MAP_DIR +"/car";
						createAndDeleteFile(filePath, true);	//删除文件夹里的图片
						filePath += "/"+ sdf.format(new Date()) + "-" + new Random().nextInt(100000) + ".jpg";
					}
					else{
						String osName = System.getProperty("os.name");
						String realPath = "";
						if(osName.startsWith("Windows")){	//判断当前操作系统是windows还是os
							realPath = WINPATH;
						} else{
							realPath = CENTOSPATH;
						}
						createAndDeleteFile(realPath, false);	//不删除文件夹里的图片
						filePath = realPath+ sdf.format(new Date()) + "-"
									+ new Random().nextInt(100000) + ".jpg";
					}
					try {
						fos = new FileOutputStream(new File(filePath));
						byte[] buff;
						while (count-- > 0) {
							buff = new byte[LENGTH_INDEX];
							len = channel.read(ByteBuffer.wrap(buff, 0,
									LENGTH_INDEX)); // 读图片
							fos.write(buff, 0, len); // 写到图片文件
							while (len < LENGTH_INDEX) { // 如果读取的长度不是LENGTH_INDEX就再读一次剩余的部分
								buff = new byte[LENGTH_INDEX - len];
								int i = channel.read(ByteBuffer.wrap(buff, 0,
										LENGTH_INDEX - len));
								fos.write(buff, 0, i);
								len += i;
							}
						}
						if (surplus > 0) {
							buff = new byte[surplus];
							len = channel.read(ByteBuffer
									.wrap(buff, 0, surplus));
							fos.write(buff, 0, len);
							while (len < surplus) { // 如果读取的长度不是surplus就再读一次剩余的部分
								buff = new byte[surplus - len];
								int i = channel.read(ByteBuffer.wrap(buff, 0,
										surplus - len));
								fos.write(buff, 0, i);
								len += i;
							}
						}
						fos.flush(); // 清空缓冲区
					} catch (IOException e) {

					} finally {
						if (fos != null) {
							fos.close();
						}
					}
					listCar.get(index).setCarCount(index+1);
					listCar.get(index).setPictureLen(pl7); // 设置图片长度====================
					listCar.get(index++).setFilePath(filePath); // 设置图片路径====================
					break;
				}
			}
		}
		return listCar;
	}
	
	/**
	 * 创建文件目录,如果有就删除里面的文件
	 * @param path
	 * @param flag	用于标识是否删除文件夹下的图片
	 */
	public void createAndDeleteFile(String path, boolean flag){
		 File file = new File(path);
		 if(!file.exists()){		//目录不存在就创建一个
			 file.mkdirs();
		 }
		 File[] files = file.listFiles();
		 if(files != null && flag){
			 for(File oldFile : files){		//删除目录下所有的文件
				 if(oldFile.isFile()){
					 oldFile.delete();
				 }
			 }
		 }
	}
	
	//解析探测器xml文件
	public static List<DebuggingData> parserCarParkXml(String fileName) {

		List<DebuggingData> debuggList = new ArrayList<DebuggingData>();
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(fileName);

			NodeList records = document.getChildNodes();
			//
			DebuggingData degugg = null;

			for (int i = 0; i < records.getLength(); i++) {
				Node record = records.item(i);
				NodeList recordInfo = record.getChildNodes();

				for (int j = 1; j < recordInfo.getLength(); j++) {
					Node node = recordInfo.item(j);
					NodeList recordInfoMeta = node.getChildNodes();
					if (node.getNodeName().equals("record")) {
						degugg = new DebuggingData();
						// System.out.println("<record>");
						for (int k = 1; k < recordInfoMeta.getLength(); k++) {

							String NodeName = recordInfoMeta.item(k)
									.getNodeName();
							String NodeValue = recordInfoMeta.item(k)
									.getTextContent();
							if (!NodeName.equals("#text")) {

								if (NodeName.equals("recordId")) {
									degugg.setId(NodeValue);
								} else if (NodeName.equals("videoAddr")) {
									degugg.setVideoIp(NodeValue);
								} else if (NodeName.equals("videoPort")) {
									degugg.setVideoPort(NodeValue);
								} else if (NodeName.equals("videoCurrState")) {
									degugg.setVideoStatus(NodeValue);
								} else if (NodeName.equals("carParkNumber")) {
									degugg.setCarParkNumber(NodeValue);
								} else if (NodeName.equals("carParkTyple")) {
									degugg.setCarParkType(NodeValue);
								} else if (NodeName.equals("carParkStatus")) {
									degugg.setCarParkStatus(NodeValue);
								} else if (NodeName.equals("caParkCurrStatus")) {
									degugg.setCarParkCurrStatus(NodeValue);
								} else if (NodeName.equals("carPictureBytes")) {
									degugg.setCarPictueBytes(NodeValue);
								}
							}

						}
						debuggList.add(degugg);
					}

				}

			}
			System.out.println("解析完毕");
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (ParserConfigurationException e) {
			System.out.println(e.getMessage());
		} catch (SAXException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return debuggList;
	}
}
