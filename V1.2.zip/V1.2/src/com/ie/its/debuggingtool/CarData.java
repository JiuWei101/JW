package com.ie.its.debuggingtool;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CarData implements Serializable {
	
	private int id;
	private int carCount;	//上传几组车位状态
	private int carCode;	//车位编号
	private int status;		//车位状态
	private int carType;	//车位类型
	private int plateLen;	//车牌号长度
	private String plateData;	//车牌号数据
	private long pictureLen;	//图片内容长度
	private String filePath;	//图片的路径
	public int getCarCount() {
		return carCount;
	}
	public void setCarCount(int carCount) {
		this.carCount = carCount;
	}
	public int getCarCode() {
		return carCode;
	}
	public void setCarCode(int carCode) {
		this.carCode = carCode;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getCarType() {
		return carType;
	}
	public void setCarType(int carType) {
		this.carType = carType;
	}
	public int getPlateLen() {
		return plateLen;
	}
	public void setPlateLen(int plateLen) {
		this.plateLen = plateLen;
	}
	public String getPlateData() {
		return plateData;
	}
	public void setPlateData(String plateData) {
		this.plateData = plateData;
	}
	public long getPictureLen() {
		return pictureLen;
	}
	public void setPictureLen(long pictureLen) {
		this.pictureLen = pictureLen;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "CarData [id=" + id + ", carCount=" + carCount + ", carCode="
				+ carCode + ", status=" + status + ", carType=" + carType
				+ ", plateLen=" + plateLen + ", plateData=" + plateData
				+ ", pictureLen=" + pictureLen + ", filePath =" + filePath + "]\n";
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
}
