package com.ie.its.debuggingtool;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;

import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DebugginSql {
	private Document document;
	// private int count = 0;
	List<DebuggingData> debuggList = new ArrayList<DebuggingData>();
    List <BootScreen>bootScreenList=new  ArrayList<BootScreen>();
    String path = "";
	String CarParkInfo = "/debugTool/CarParkInfoXml.xml";
    String ScreenInfo="/debugTool/BootScreemInfoXml.xml";
    
	// private Iterator<DebuggingData> debugg=null;
      //获取所有的车位信息 
	public List<DebuggingData> parkInfo_list(String str) {

		if (str.equals("count")) {

			if (debuggList.size() == 0) {
				try {
					path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
				} catch (URISyntaxException e) {
					System.out.println("DebuggingSql URISyntasxException");
				}
				debuggList=CommonMethod.parserCarParkXml(path + CarParkInfo);
			}

		}
		else{//刷新操作，调用A1命令
			String []ips=str.split(";");
			for(int i=0;i<ips.length;i++){
				List <CarData> carInfoList=new CameraDebug().getMulitCarDataA1(ips[i]);
				int record [] =new int [4];//记录上传了几组车位信息
				if(carInfoList==null){
					for(int j=0;j<record.length;j++){
						DebuggingData debugdata=new DebuggingData();
						debugdata.setId(j+"");//设置上传几组
						debugdata.setVideoIp(ips[i]);//设置ip地址
						debugdata.setVideoStatus("OFF");//设置视屏探测器状态
						debugdata.setVideoPort("");//设置视屏探测器端口 暂时这个端口没有什么作用,随便设置的
						debugdata.setCarParkNumber(j+"");//设置车位编号
						debugdata.setCarParkStatus("4");//设置车位状态(禁用 ，使能)
						debugdata.setCarParkCurrStatus("4");//设置车位状态（有车，无车）
						debugdata.setCarParkType("4");//设置车位类型
						debugdata.setCarPictueBytes("");//设置车位图片数据长度 
						debuggList.add(debugdata);	
					}
								
				}else {
					Iterator<CarData> iter=carInfoList.iterator();
					while(iter.hasNext()){
						CarData cardata=(CarData)iter.next();
						DebuggingData debugdata=new DebuggingData();
						debugdata.setId(cardata.getCarCount()+"");//设置上传几组
						debugdata.setVideoIp(ips[i]);//设置ip地址
						debugdata.setVideoStatus("ON");//设置视屏探测器状态
						debugdata.setVideoPort("");//设置视屏探测器端口 暂时这个端口没有什么作用,随便设置的
						record[cardata.getCarCount()-1]=cardata.getCarCount();//记录上传几组
						debugdata.setCarParkNumber(cardata.getCarCode()+"");//设置车位编号
						debugdata.setCarParkCurrStatus(cardata.getStatus()+"");//设置车位状态（有车，无车）
						debugdata.setCarParkStatus("1");//设置车位状态(禁用 ，使能)
						debugdata.setCarParkType(cardata.getCarType()+"");//设置车位类型
						debugdata.setCarPictueBytes(cardata.getPictureLen()+"");//设置车位图片数据长度 
						debuggList.add(debugdata);				
						}
				   
				    	for(int k=0;k<record.length;k++){
				    		if(record[k]==0){
				    			DebuggingData debugdata=new DebuggingData();
								debugdata.setId(k+"");//设置上传几组
								debugdata.setVideoIp(ips[i]);//设置ip地址
								debugdata.setVideoStatus("ON");//设置视屏探测器状态
								debugdata.setVideoPort("");//设置视屏探测器端口 暂时这个端口没有什么作用,随便设置的
								debugdata.setCarParkNumber("");//设置车位编号
								debugdata.setCarParkStatus("0");//设置车位状态(禁用 ，使能)
								debugdata.setCarParkCurrStatus("");//设置车位状态（有车，无车）
								debugdata.setCarParkType("");//设置车位类型
								debugdata.setCarPictueBytes("");//设置车位图片数据长度 
								debuggList.add(debugdata);	
				    		}
				    		
				    	}
				    	
				   
				}
				
			}
		}
		return debuggList;

		// return count;
	}
	 //获取所有引导屏信息 
	public List<BootScreen> screen_list(String str) {

		if (str.equals("count")) {

			if (bootScreenList.size() == 0) {
				parserScrreenXml(ScreenInfo);
			}

		}
		return bootScreenList;

		// return count;
	}
	public void init() {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			try {
				path = (getClass().getClassLoader().getResource("").toURI())
				.getPath();
			} catch (URISyntaxException e) {
				System.out.println("DebuggingSql URISyntasxException");
			}
			this.document = builder.newDocument();
		} catch (ParserConfigurationException e) {
			System.out.println(e.getMessage());
		}
	}
//更新视屏探测器xml文件
	public void createXml(String fileName, List<DebuggingData> debugdates) {
		init();
		Element root = this.document.createElement("xml-body");
		
		this.document.appendChild(root);
		for (int i = 0; i < debugdates.size(); i++) {
			Element record = this.document.createElement("record");

			Element recordId = this.document.createElement("recordId");
			recordId.appendChild(this.document.createTextNode(debugdates.get(i)
					.getId()));
			record.appendChild(recordId);

			Element videoAddr = this.document.createElement("videoAddr");
			videoAddr.appendChild(this.document.createTextNode(debugdates
					.get(i).getVideoIp()));
			record.appendChild(videoAddr);

			Element videoPort = this.document.createElement("videoPort");
			videoPort.appendChild(this.document.createTextNode(debugdates
					.get(i).getVideoPort()));
			record.appendChild(videoPort);

			Element videoCurrState = this.document
					.createElement("videoCurrState");
			videoCurrState.appendChild(this.document.createTextNode(debugdates
					.get(i).getVideoStatus()));
			record.appendChild(videoCurrState);

			Element carParkNumber = this.document
					.createElement("carParkNumber");
			carParkNumber.appendChild(this.document.createTextNode(debugdates
					.get(i).getCarParkNumber()));
			record.appendChild(carParkNumber);

			Element carParkTyple = this.document.createElement("carParkTyple");
			carParkTyple.appendChild(this.document.createTextNode(debugdates
					.get(i).getCarParkType()));
			record.appendChild(carParkTyple);

			Element carParkStatus = this.document
					.createElement("carParkStatus");
			carParkStatus.appendChild(this.document.createTextNode(debugdates
					.get(i).getCarParkStatus()));
			record.appendChild(carParkStatus);

			Element caParkCurrStatus = this.document
					.createElement("caParkCurrStatus");
			caParkCurrStatus.appendChild(this.document
					.createTextNode(debugdates.get(i).getCarParkCurrStatus()));
			record.appendChild(caParkCurrStatus);

			Element carPictureBytes = this.document
					.createElement("carPictureBytes");
			carPictureBytes.appendChild(this.document.createTextNode(debugdates
					.get(i).getCarPictueBytes()));
			record.appendChild(carPictureBytes);

			root.appendChild(record);
		}

		TransformerFactory tf = TransformerFactory.newInstance();
		try {
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(document);
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			PrintWriter pw = new PrintWriter(new FileOutputStream(path+fileName));
			StreamResult result = new StreamResult(pw);
			transformer.transform(source, result);
			System.out.println("生成carParkXML文件成功!");
		} catch (TransformerConfigurationException e) {
			System.out.println(e.getMessage());
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (TransformerException e) {
			System.out.println(e.getMessage());
		}
	}
   //更新条屏的xml文件
	public void updateScreenXml(String fileName, List<BootScreen> bootScreens) {
		init();
		Element root = this.document.createElement("xml-body");
		if(fileName.equals(""))fileName=ScreenInfo;
		this.document.appendChild(root);
		for (int i = 0; i < bootScreens.size(); i++) {
			Element record = this.document.createElement("record");

			Element recordId = this.document.createElement("recordId");
			recordId.appendChild(this.document.createTextNode(bootScreens.get(i)
					.getId()));
			record.appendChild(recordId);

			Element groupAddr = this.document.createElement("groupAddr");
			groupAddr.appendChild(this.document.createTextNode(bootScreens
					.get(i).getGroupAddr()));
			record.appendChild(groupAddr);

			Element screenAddr = this.document.createElement("screenAddr");
			screenAddr.appendChild(this.document.createTextNode(bootScreens
					.get(i).getScreenAddr()));
			record.appendChild(screenAddr);
			
			Element version = this.document.createElement("version");
			version.appendChild(this.document.createTextNode("001"));
			record.appendChild(version);
			
			root.appendChild(record);
		}

		TransformerFactory tf = TransformerFactory.newInstance();
		try {
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(document);
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			PrintWriter pw = new PrintWriter(new FileOutputStream(path+fileName));
			StreamResult result = new StreamResult(pw);
			transformer.transform(source, result);
			System.out.println("生成screenXML文件成功!");
		} catch (TransformerConfigurationException e) {
			System.out.println(e.getMessage());
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (TransformerException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//解析引导屏的xml
	public void parserScrreenXml(String fileName){
		try {
			String path = (getClass().getClassLoader().getResource("").toURI()).getPath();
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(path+fileName);

			NodeList records = document.getChildNodes();
			//
			BootScreen bootScreen = null;

			for (int i = 0; i < records.getLength(); i++) {
				Node record = records.item(i);
				NodeList recordInfo = record.getChildNodes();

				for (int j = 1; j < recordInfo.getLength(); j++) {
					Node node = recordInfo.item(j);
					NodeList recordInfoMeta = node.getChildNodes();
					if (node.getNodeName().equals("record")) {
						bootScreen = new BootScreen();
						// System.out.println("<record>");
						for (int k = 1; k < recordInfoMeta.getLength(); k++) {

							String NodeName = recordInfoMeta.item(k)
									.getNodeName();
							String NodeValue = recordInfoMeta.item(k)
									.getTextContent();
							if (!NodeName.equals("#text")) {

								if (NodeName.equals("recordId")) {
									bootScreen.setId(NodeValue);
								} else if (NodeName.equals("groupAddr")) {
									bootScreen.setGroupAddr(NodeValue);
								} else if (NodeName.equals("screenAddr")) {
									bootScreen.setScreenAddr(NodeValue);
								} 
							}

						}
						bootScreenList.add(bootScreen);
					}

				}

			}
			/*
			 * Iterator iter = debuggList.iterator(); while (iter.hasNext()) {
			 * DebuggingData de = (DebuggingData) iter.next();
			 * System.out.println(de.getId());
			 * System.out.println(de.getVideoIp());
			 * System.out.println(de.getVideoPort());
			 * System.out.println(de.getVideoStatus());
			 * 
			 * }
			 */

			System.out.println("解析完毕");
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (ParserConfigurationException e) {
			System.out.println(e.getMessage());
		} catch (SAXException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		}
	}
	//更新视屏探测器ip，端口
	public void updateXmlFile(String oldIps, String newIp, String videoPort) {

		try {
			path = (getClass().getClassLoader().getResource("").toURI())
			.getPath();
		} catch (URISyntaxException e) {
			System.out.println("DebuggingSql URISyntasxException");
		}
		debuggList=CommonMethod.parserCarParkXml(path + CarParkInfo);
		String ips[] = oldIps.split(",");

		for (int i = 0; i < debuggList.size(); i++) {
			DebuggingData debuggdate = (DebuggingData) debuggList.get(i);
			for (int j = 0; j < ips.length; j++) {
				String ip = ips[j];

				if (ip.equals(debuggdate.getVideoIp())) {
					debuggdate.setVideoIp(newIp);
					debuggdate.setVideoPort(videoPort);
					// newDebuggList.add(debuggdate);
				}

			}
		}

		/*
		 * while(debugg.hasNext()){ DebuggingData
		 * debuggdate=(DebuggingData)debugg.next();
		 * if(debuggdate.getVideoIp().equals(oldIps)){
		 * debuggdate.setVideoIp(newIp); debuggdate.setVideoPort(videoPort); }
		 * 
		 * }
		 */

		createXml(CarParkInfo, debuggList);

	}
   //更新车位信息 
	public void updateXmlFile(String sip, String meus) {
		try {
			path = (getClass().getClassLoader().getResource("").toURI())
			.getPath();
		} catch (URISyntaxException e) {
			System.out.println("DebuggingSql URISyntasxException");
		}
		debuggList=CommonMethod.parserCarParkXml(path + CarParkInfo);
		String ips[] = sip.split(";");

		for (int i = 0; i < debuggList.size(); i++) {
			DebuggingData debuggdate = (DebuggingData) debuggList.get(i);
			for (int j = 0; j < ips.length; j++) {
				String iparry[] = ips[j].split(",");
				String ip = iparry[0];
				String carNumber = iparry[1];
				String carvalue = iparry[2];
				if (ip.equals(debuggdate.getVideoIp())
						&& carNumber.equals(debuggdate.getCarParkNumber())) {
					if (meus.equals("carenable")) {// 设置车位使能
						debuggdate.setCarParkStatus(carvalue);
					} else if (meus.equals("cartype")) {// 设置车位类型
						debuggdate.setCarParkType(carvalue);
					} else {
						debuggdate.setCarParkNumber(carvalue);// 设置车位編號
					}
					// newDebuggList.add(debuggdate);
				}

			}
		}
		createXml(CarParkInfo, debuggList);
	}

}
