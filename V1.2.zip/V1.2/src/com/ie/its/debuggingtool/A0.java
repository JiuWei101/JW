package com.ie.its.debuggingtool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.directwebremoting.WebContextFactory;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;

/**
 * Ａ命令
 * @author Administrator
 *
 */
public class A0 {
	private static int LENGTH_INDEX = 1024;
	//private static final String ip = "127.0.0.1";
	private static List<CarData> list = new ArrayList<CarData>();
	/**
	 * A0命令读取视频探测器下单个车位的当前状态
	 * @param ip
	 * @param carCode
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String getSingleCarCode(String ip, byte carCode,String realPath) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip);
		if(channel != null){
			try {
				channel.write(ByteBuffer.wrap(new byte[]{1, (byte) 0xA0, carCode}));
				byte[] buff = new byte[2];
				long start = new Date().getTime();
				while(true){										//读取
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if(cmd.equalsIgnoreCase("a0")){
						list = getListCarData(channel, 1,realPath);
						System.out.println("CarData: " + list);
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						return "failer Time out";
					}
				}
			} catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return "failer IP Cameras has been disconnected....";
			} // 写命令
		} else {
			ServerSocketListener.socketMap.remove(ip);
			return "failer IP Cameras has been disconnected....";
		}
		return "Ip: " + ip + ", CarCode: " + carCode + " , CarList: " + list;
	}
	
	/**
	 * A1读取视频探测器下所有使能车位的当前状态
	 * @param ip
	 * @return
	 * @throws IOException
	 */
	public String getMulitCarData(String ip) {
		SocketChannel channel = ServerSocketListener.socketMap.get(ip);
		if(channel != null){
			try {
				channel.write(ByteBuffer.wrap(new byte[]{1, (byte) 0xA1}));
				byte[] buff = new byte[3];
				long start = new Date().getTime();
				while(true){
					channel.read(ByteBuffer.wrap(buff));
					String cmd = Integer.toHexString(buff[1] & 0xFF); // 读取CMD命令,转成十六进制
					if(cmd.equalsIgnoreCase("a1")){
						System.out.println("CarData: " + getListCarData(channel, buff[2],""));
						break;
					}
					long end = new Date().getTime();
					if ((end - start) > 5000) {
						return "Time out";
					}
				}
			}  catch (IOException e) {
				ServerSocketListener.socketMap.remove(ip);
				return "IP Cameras has been disconnected....";
			} // 写命令
		} else {
			ServerSocketListener.socketMap.remove(ip);
			return "IP Cameras has been disconnected....";
		}
		return "Ip: " + ip + " <br /> CarList: " + list;
	}
	
	private static List<CarData> getListCarData(SocketChannel channel, int carCount,String path) throws IOException{
		List<CarData> listCar = new ArrayList<CarData>();
		byte[] buff;
		while(carCount-- > 0){
			buff = new byte[4];
			channel.read(ByteBuffer.wrap(buff));
			CarData car = new CarData();
			car.setCarCode(buff[0]);
			car.setStatus(buff[1]);
			car.setCarType(buff[2]);
			car.setPlateLen(buff[3]);
			buff = new byte[car.getPlateLen()];
			channel.read(ByteBuffer.wrap(buff, 0, car.getPlateLen()));
			car.setPlateData(new String(buff, 0, car.getPlateLen(), "UTF-8"));
			listCar.add(car);
		}
		System.out.println(listCar);
		carCount = listCar.size();
		int index = 0;
		while(carCount-- > 0){
			buff = new byte[4]; // 读取图片长度====================
			channel.read(ByteBuffer.wrap(buff));
			String pl4 = Integer
			.toBinaryString((int) buff[0] & 0x000000FF);	//第四位
			String pl3 = Integer
					.toBinaryString(((int) buff[1] & 0x000000FF) << 8);	//第三位
			String pl2 = Integer
					.toBinaryString(((int) buff[2] & 0x000000FF) << 16);	//第二位
			String pl1 = Integer
					.toBinaryString(((int) buff[3] & 0x000000FF) << 32);	//第一位
			String pl5 = Integer.toBinaryString(Integer.parseInt(
					pl1, 2) | Integer.parseInt(pl2, 2));
			String pl6 = Integer.toBinaryString(Integer.parseInt(
					pl5, 2) | Integer.parseInt(pl3, 2));
			int pl7 = Integer.parseInt(pl6, 2)
					| Integer.parseInt(pl4, 2);	//读完
			int count = pl7 / LENGTH_INDEX;		//将图片的长度分成N部分来读取，每部分的长度为LENGTH_INDEX
			int surplus = pl7 % LENGTH_INDEX;	//标记剩余的部分
			int len = 0;
			System.out.println("PL7: " + pl7);
			FileOutputStream fos = null;	
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String filePath = StringManager.replaceAll(path,"\\","/") + ConstantClass.MAP_DIR +"/car/" + sdf.format(new Date()) + new Random().nextInt(100000) + ".jpg";
			System.out.println("FilePath: " + filePath);
			System.out.println("Write CarCount: " + carCount);
			try{
				fos = new FileOutputStream(new File(filePath));
				while(count-- > 0){
					buff = new byte[LENGTH_INDEX];
					len = channel.read(ByteBuffer.wrap(buff, 0, LENGTH_INDEX));	//读图片
					fos.write(buff, 0, len);		//写到图片文件
					while(len < LENGTH_INDEX){		//如果读取的长度不是LENGTH_INDEX就再读一次剩余的部分
						buff = new byte[LENGTH_INDEX - len];
						int i = channel.read(ByteBuffer.wrap(buff, 0, LENGTH_INDEX - len));
						fos.write(buff, 0, i);
						len += i;
					}
				}
				if(surplus > 0){
					buff = new byte[surplus];
					len = channel.read(ByteBuffer.wrap(buff, 0, surplus));
					fos.write(buff, 0, len);
					while(len < surplus){		//如果读取的长度不是surplus就再读一次剩余的部分
						buff = new byte[surplus - len];
						int i = channel.read(ByteBuffer.wrap(buff, 0, surplus - len));
						fos.write(buff, 0, i);
						len += i;
					}
				}
				fos.flush();		//清空缓冲区
			} catch (IOException e){
				
			} finally{
				if(fos != null){
					fos.close();
				}
			}
			listCar.get(index).setPictureLen(pl7); // 设置图片长度====================
			listCar.get(index++).setFilePath(filePath); // 设置图片路径====================
		}
		System.out.println(listCar);
		
		return listCar;
	}
}



































