/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导屏配置
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : zy
 */
package com.ie.its.screenconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class ScreenData extends ExtendData{
	private String mapId;				//停车场地图ID
	private String controllerId;		//管理器ID
	private String screenTypeCode;		//引导屏类型Code
	private String addr;				//引导屏地址
	private String grpAddr;				//引导屏组地址
	private String code;				//引导屏编号
	private String status;				//状态
	private String controllerPort;				//状态
	private String enable;				//是否启用
	private String contentFormat;		//内容格式(←1 ↑2 3→)注意，这里是非外键，仅里面的数字是关联P_ScreenRegion表的
	private String colorMode;			//颜色模式
	private String serialPort;			//串口号
	private String baudRate;			//波特率(默认500K)
	private String screenTemplateId;    //引导屏参数模板ID
	private String screenTemplateName;    //引导屏参数模板名称
	private List baudRateList;			//波特率下拉列表
	private String defBaudRate;			//缺省波特率500K
	private String isExit;              //是否入口屏
	private int esCarportNum;			//出口屏保护临界值
	private String esContent;			//出口屏保护内容
	private String ipaddress;			//ip地址
	private String ipport;				//ip端口
	private String macaddress;			//MAC地址
	
	private List mapList;				//停车场地图下拉框
	private List controllerList;		//管理器下拉框
	private List screenTypeList;		//引导屏类型下拉框
	private List screenRegionList;		//内容格式下拉框
	private List statusList;			//状态下拉框
	private List enableList;			//启用下拉框
	private List controllerPortList;	//控制器端口列表
	private List colorModeList;			//颜色模式列表
	private String optionalValue;
	private List optionalList;
	private String field;				//字段名
	private String value;				//值
	private List screenTemplateList;		//引导屏类型下拉框
	
	
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getIpport() {
		return ipport;
	}
	public void setIpport(String ipport) {
		this.ipport = ipport;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	public int getEsCarportNum() {
		return esCarportNum;
	}
	public void setEsCarportNum(int esCarportNum) {
		this.esCarportNum = esCarportNum;
	}
	public String getEsContent() {
		return esContent;
	}
	public void setEsContent(String esContent) {
		this.esContent = esContent;
	}
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	/**
	 * @return the controllerId
	 */
	public String getControllerId() {
		return controllerId;
	}
	/**
	 * @param controllerId the controllerId to set
	 */
	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}
	/**
	 * @return the screenTypeCode
	 */
	public String getScreenTypeCode() {
		return screenTypeCode;
	}
	/**
	 * @param screenTypeCode the screenTypeCode to set
	 */
	public void setScreenTypeCode(String screenTypeCode) {
		this.screenTypeCode = screenTypeCode;
	}
	/**
	 * @return the addr
	 */
	public String getAddr() {
		return addr;
	}
	/**
	 * @param addr the addr to set
	 */
	public void setAddr(String addr) {
		this.addr = addr;
	}
	/**
	 * @return the grpAddr
	 */
	public String getGrpAddr() {
		return grpAddr;
	}
	/**
	 * @param grpAddr the grpAddr to set
	 */
	public void setGrpAddr(String grpAddr) {
		this.grpAddr = grpAddr;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the enable
	 */
	public String getEnable() {
		return enable;
	}
	/**
	 * @param enable the enable to set
	 */
	public void setEnable(String enable) {
		this.enable = enable;
	}
	/**
	 * @return the contentFormat
	 */
	public String getContentFormat() {
		return contentFormat;
	}
	/**
	 * @param screenRegionId the screenRegionId to set
	 */
	public void setContentFormat(String contentFormat) {
		this.contentFormat = contentFormat;
	}
	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}
	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	/**
	 * @return the controllerList
	 */
	public List getControllerList() {
		return controllerList;
	}
	/**
	 * @param controllerList the controllerList to set
	 */
	public void setControllerList(List controllerList) {
		this.controllerList = controllerList;
	}
	/**
	 * @return the screenTypeList
	 */
	public List getScreenTypeList() {
		return screenTypeList;
	}
	/**
	 * @param screenTypeList the screenTypeList to set
	 */
	public void setScreenTypeList(List screenTypeList) {
		this.screenTypeList = screenTypeList;
	}
	/**
	 * @return the screenRegionList
	 */
	public List getScreenRegionList() {
		return screenRegionList;
	}
	/**
	 * @param screenRegionList the screenRegionList to set
	 */
	public void setScreenRegionList(List screenRegionList) {
		this.screenRegionList = screenRegionList;
	}
	/**
	 * @return the statusList
	 */
	public List getStatusList() {
		return statusList;
	}
	/**
	 * @param statusList the statusList to set
	 */
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}
	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}
	/**
	 * @return the enableList
	 */
	public List getEnableList() {
		return enableList;
	}
	/**
	 * @param enableList the enableList to set
	 */
	public void setEnableList(List enableList) {
		this.enableList = enableList;
	}
	/**
	 * @return the controllerPortList
	 */
	public List getControllerPortList() {
		return controllerPortList;
	}
	/**
	 * @param controllerPortList the controllerPortList to set
	 */
	public void setControllerPortList(List controllerPortList) {
		this.controllerPortList = controllerPortList;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return the colorModeList
	 */
	public List getColorModeList() {
		return colorModeList;
	}
	/**
	 * @param colorModeList the colorModeList to set
	 */
	public void setColorModeList(List colorModeList) {
		this.colorModeList = colorModeList;
	}
	/**
	 * @return the colorMode
	 */
	public String getColorMode() {
		return colorMode;
	}
	/**
	 * @param colorMode the colorMode to set
	 */
	public void setColorMode(String colorMode) {
		this.colorMode = colorMode;
	}
	public String getSerialPort() {
		return serialPort;
	}
	public void setSerialPort(String serialPort) {
		this.serialPort = serialPort;
	}
	public String getBaudRate() {
		return baudRate;
	}
	public void setBaudRate(String baudRate) {
		this.baudRate = baudRate;
	}
	public List getBaudRateList() {
		return baudRateList;
	}
	public void setBaudRateList(List baudRateList) {
		this.baudRateList = baudRateList;
	}
	public String getDefBaudRate() {
		return defBaudRate;
	}
	public void setDefBaudRate(String defBaudRate) {
		this.defBaudRate = defBaudRate;
	}
	/**
	 * @return the controllerPort
	 */
	public String getControllerPort() {
		return controllerPort;
	}
	/**
	 * @param controllerPort the controllerPort to set
	 */
	public void setControllerPort(String controllerPort) {
		this.controllerPort = controllerPort;
	}
	public List getOptionalList() {
		return optionalList;
	}
	public void setOptionalList(List optionalList) {
		this.optionalList = optionalList;
	}
	public String getOptionalValue() {
		return optionalValue;
	}
	public void setOptionalValue(String optionalValue) {
		this.optionalValue = optionalValue;
	}
	public String getScreenTemplateId() {
		return screenTemplateId;
	}
	public void setScreenTemplateId(String screenTemplateId) {
		this.screenTemplateId = screenTemplateId;
	}
	public List getScreenTemplateList() {
		return screenTemplateList;
	}
	public void setScreenTemplateList(List screenTemplateList) {
		this.screenTemplateList = screenTemplateList;
	}
	public String getScreenTemplateName() {
		return screenTemplateName;
	}
	public void setScreenTemplateName(String screenTemplateName) {
		this.screenTemplateName = screenTemplateName;
	}
	public String getIsExit() {
		return isExit;
	}
	public void setIsExit(String isExit) {
		this.isExit = isExit;
	}
	
	
	
	
	

}
