/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导屏配置
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : zy
 */
package com.ie.its.screenconfig;

import java.util.List;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;

//命名空间
@Namespace("/screen_config")
@Results({@Result(name="list",location="/screen_config/screen_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="screen_list",location="list.action",type="redirect")})
public class ScreenAction extends ExtendActionSupport {
	
	private ScreenData data;
	@Autowired
	private ScreenService screenService;
	
	public ScreenData getData() {
		return data;
	}
	public void setData(ScreenData data) {
		this.data = data;
	}
	public ScreenAction(){
		if(data == null){
			data = new ScreenData();
		}
	}
	/**
     * Description :引导屏初始化．
     * @throws :Exception
     */
	@Action(value="screen_list",results={@Result(name="success",location="/screen_config/screen_list.jsp")})
	public String screen_list(){
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data = screenService.screen_list(data);
		//获得停车场地图下拉框
		data.setMapList(screenService.get_mapCode());
		//获得管理器下拉框
		data.setControllerList(screenService.get_controllerCode());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status")); 
		//获得启用拉框
		data.setEnableList(Util.getCodeList(data, "enable"));
		//获取系统类型，决定界面显示哪几个字段
		String sysModel = screenService.queryForSystemModel();
		data.setSysModel(sysModel);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="screen_create",results={@Result(name="create",location="/screen_config/screen_create.jsp")})
	public String create(){
		data.setId("");
		//设置多语言
		setLang(data);
		
		//获得停车场地图下拉框
		data.setMapList(screenService.get_mapCode());
		//获得管理器下拉框
		data.setControllerList(screenService.get_controllerCode());
		//获得引导屏类型下拉框
		data.setScreenTypeList(screenService.get_screenTypeCode());
		//获得引导屏颜色模式下拉框
		data.setColorModeList(Util.getCodeList(data, "color_mode"));
		//获得波特率下拉框
		data.setBaudRateList(DisposalCode.getCode("scr_baudrate",request.getSession().getAttribute("lang").toString())); 
		
		return ConstantClass.ACTION_CREATE;
	}
	
	/**
	 * 编辑引导屏
	 * @return
	 */
	@Action(value="screen_edit",results={@Result(name="edit",location="/screen_config/screen_edit.jsp")})
	public String screen_edit(){
		screenService.screen_get(data);
		
		//设置多语言
		setLang(data);
		
		//获得停车场地图下拉框
		data.setMapList(screenService.get_mapCode());
		//获得管理器下拉框
		data.setControllerList(screenService.get_controllerCode());
		//获得管理器端口下拉框
		data.setControllerPortList(screenService.get_controllerPortCode());
		//获得引导屏类型下拉框
		data.setScreenTypeList(screenService.get_screenTypeCode());
		//获得引导屏参数值模板下拉框
		data.setScreenTemplateList(screenService.get_screenParaTemplate());
		//获得引导屏颜色模式下拉框
		data.setColorModeList(Util.getCodeList(data, "color_mode"));
		//获得波特率下拉框
		data.setBaudRateList(DisposalCode.getCode("scr_baudrate",request.getSession().getAttribute("lang").toString())); 

		//获得启用拉框
		data.setEnableList(Util.getCodeList(data, "enable")); 
		data.setSysModel(screenService.queryForSystemModel());
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="screen_multiedit",results={@Result(name="edit",location="/screen_config/screen_multiedit.jsp")})
	public String screen_multiedit(){
		screenService.screen_get(data);
		
		//设置多语言
		setLang(data);
		//获得引导屏类型下拉框
		data.setScreenTypeList(screenService.get_screenTypeCode());
		//获得引导屏参数值模板下拉框
		data.setScreenTemplateList(screenService.get_screenParaTemplate());
		//获得波特率下拉框
		data.setBaudRateList(DisposalCode.getCode("scr_baudrate",request.getSession().getAttribute("lang").toString())); 

		//获得管理器下拉框
		data.setControllerList(screenService.get_controllerCode());
		//获得引导屏颜色模式下拉框
		data.setColorModeList(Util.getCodeList(data, "color_mode"));
		//设置系统类型
		data.setSysModel(screenService.queryForSystemModel());
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="screenparavalue_config",results={@Result(name="success",location="/screen_config/screenparavalue_config.jsp")})
	public String screenparavalue_config(){
		//设置多语言
		setLang(data);
		screenService.screenparavalue_get(data, request.getSession().getAttribute("lang").toString());
		return "success";
	}
	
	@Action(value="screenparavalue_save",results={@Result(type="json")})
	public void screenparavalue_save(){
		JSONObject json =  new JSONObject();
		try{
			//设置多语言
			setLang(data);
			screenService.screenparavalue_save(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	/**
	 * 更新条屏信息
	 */
	@Action(value="screen_update",results={@Result(type="json")})
	public void screen_update(){		
		JSONObject json =  new JSONObject();
		try{
			screenService.screen_update(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="screen_multiupdate",results={@Result(type="json")})
	public void screen_multiupdate(){	
		if("".equals(data.getId())){
			JSONObject json =  new JSONObject();
			List<ScreenData> dataList = screenService.screen_getAll();//获取所有条屏id
			if(dataList.size() > 0){
				String[] ids = new String[dataList.size()];
				for(int i = 0; i < dataList.size(); i++){
					ids[i] = dataList.get(i).getId();
				}
				String idsWith = "";
				for(int i = 0; i < ids.length; i++){
					if(i != ids.length){
						idsWith += ids[i] + ";";	
					}else{
						idsWith += ids[i];
					}
				}
				data.setId(idsWith);
				try{
					screenService.screen_multiupdate(data);
					json.element("success", true);
				} catch(Exception e){
					json.element("success", false);
					json.element("msg", e.getMessage());
				}
			}else{
				json.element("success", true);
			}
			setJsonRes(json);
		}else{
			JSONObject json =  new JSONObject();
			try{
				screenService.screen_multiupdate(data);
				json.element("success", true);
			} catch(Exception e){
				json.element("success", false);
				json.element("msg", e.getMessage());
			}
			setJsonRes(json);
		}
	}
	
	@Action(value="screen_delete",results={@Result(type="json")})
	public void screen_delete(){		
		JSONObject json =  new JSONObject();
		try{
			screenService.screen_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="check_screentype",results={@Result(type="json")})
	public void check_screentype(){
		screenService.check_screentype(data);
		JSONObject json =  new JSONObject(); 

		json.element("success", data.getTotal() > 1 ? false : true);
		System.out.println(data.getTotal());
		setJsonRes(json);
	}
}
