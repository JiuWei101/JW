/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导屏配置
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : zy
 */
package com.ie.its.screenconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class ParamValueData extends ExtendData{
	private String id;				
	private String name;		
	private String value;
	private String defaultValue;
	private String optionalValue;
	private String lang_text;
	private List optionalList;
	private String code;
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue() {
		return defaultValue;
	}
	/**
	 * @param defaultValue the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getOptionalValue() {
		return optionalValue;
	}
	public void setOptionalValue(String optionalValue) {
		this.optionalValue = optionalValue;
	}
	public List getOptionalList() {
		return optionalList;
	}
	public void setOptionalList(List optionalList) {
		this.optionalList = optionalList;
	}
	public String getLang_text() {
		return lang_text;
	}
	public void setLang_text(String lang_text) {
		this.lang_text = lang_text;
	}	
}
