/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导屏配置
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : zy
 */
package com.ie.its.screenconfig;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class ScreenSql extends ExtendSql{
	/**
     * Description :查询引导屏．
     * @param  :ScreenData,String
     * @return :String
     */
	public String screen_list(ScreenData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{     
			querySql += "select  s.id,m.name as mapId,c.addr as controllerId,st.name as screenTypeCode,s.addr,s.grpAddr,s.code,";
			querySql += "s.serialPort,s.baudRate,s.status,s.enable,s.contentFormat,s.colorMode,s.isExit,s.esCarportNum,s.esContent,s.ipaddress,s.ipport,s.macaddress, ";
			querySql += "s.screenTemplateId,tpl.name as screenTemplateName,tpl.screenTypeCode as screenTemplTypeCode ";
		}
		
		querySql += " from p_screen s ";
		querySql += "left join p_map m on m.id = s.mapId ";
		querySql += "left join p_controller c on s.controllerId=c.id ";
		querySql += "left join p_screentype st on s.screenTypeCode=st.code ";
		querySql += "left join p_screenparatemplateheader tpl on s.screentemplateid=tpl.id ";
		
		querySql += " where 1=1 ";
		
		if(isCon(data.getMapId())){
			querySql += " and m.id = " + toSqlVal(data.getMapId());
		}
		if(isCon(data.getCode())){
			querySql += " and s.code like " + toSqlValLike(data.getCode(),"ALL");
		}
		if(isCon(data.getControllerId())){
			querySql += " and c.id = " + toSqlVal(data.getControllerId());
		}
		if(isCon(data.getStatus())){
			querySql += " and s.status = " + toSqlVal(data.getStatus());
		}
		if(isCon(data.getEnable())){
			querySql += " and s.enable = " + toSqlVal(data.getEnable());
		}
		
		if(!type.equals("count")){
			querySql += " order by s.id";
		}
		
		return querySql;
	}
	
	/**
     * Description :获得引导屏信息．
     * @param  :ScreenData
     * @return :String
     */
	public String screen_get(ScreenData data) {
		String querySql = "";
		
		querySql += "select * from p_screen where id=";
		querySql += Util.toSqlVal(data.getId());
		
		
		return querySql;
	}
	
	public String screen_getAll() {
		String querySql = "select id from p_screen";
		return querySql;
	}
	/**
     * Description :更新引导屏信息．
     * @param  :ScreenData
     * @return :String
     */
	public String screen_update(ScreenData data) {
		String updateSql = "";
		
		updateSql += "update p_screen set ";
		if(Util.isCon(data.getControllerId())){
			updateSql += "controllerId=" + Util.toSqlVal(data.getControllerId())+",";//前台返回管理器Id不为空，则更新
		}
		updateSql += " screenTypeCode= (select screenTypeCode from p_screenparatemplateheader where id =" + Util.toSqlVal(data.getScreenTemplateId()) + ")";
		updateSql += ",screenTemplateID=" + Util.toSqlVal(data.getScreenTemplateId());
		updateSql += ",colorMode=" + Util.toSqlVal(data.getColorMode());
		//青松屏的特有属性更新：串口号和波特率
//		if(data.getScreenTypeCode().equals("0001"))
//		{
//			updateSql += ",serialPort=" + Util.toSqlVal("");
//			updateSql += ",baudRate=" + Util.toSqlVal("");			
//		}else if(data.getScreenTypeCode().equals("0002"))
//		{
//			updateSql += ",serialPort=" + Util.toSqlVal(data.getSerialPort());
//			updateSql += ",baudRate=" + Util.toSqlVal(data.getBaudRate());			
//		}
		if(Util.isCon(data.getSerialPort())){
			updateSql += ",serialPort=" + Util.toSqlVal(data.getSerialPort());
		}
		if(Util.isCon(data.getBaudRate())){
			updateSql += ",baudRate=" + Util.toSqlVal(data.getBaudRate());
		}	
		updateSql += ",isExit=" + Util.toSqlVal(data.getIsExit());
		updateSql += ",esCarportNum=" + Util.toSqlVal(data.getEsCarportNum());
		updateSql += ",esContent=" + Util.toSqlVal(data.getEsContent());
		updateSql += ",ipaddress=" + Util.toSqlVal(data.getIpaddress());
		updateSql += ",ipport=" + Util.toSqlVal(data.getIpport());
		updateSql += ",macaddress=" + Util.toSqlVal(data.getMacaddress());
		updateSql += " where id =" + Util.toSqlVal(data.getId());
		Log.log("更新引导屏基础信息："+updateSql);
		return updateSql;
	}
	
	/**
     * Description :更新引导屏信息．
     * @param  :screenData
     * @return :String
     */
	public String screen_multiupdate(ScreenData data) {
		
		String updateSql = " update p_screen set ";
		updateSql += "";
		return updateSql;
	}
	
	/**
	 * Description :更新引导屏信息．
	 * @param data
	 * @param id
	 * @return
	 */
	public String screen_multiupdate(ScreenData data, String id) {
		
		String updateSql = "update p_screen set ";
		if(Util.isCon(data.getControllerId())){
			updateSql += "controllerId = " + Util.toSqlVal(data.getControllerId())+",";	
		}	
		updateSql += " screenTypeCode= (select screenTypeCode from p_screenparatemplateheader where id =" + Util.toSqlVal(data.getScreenTemplateId()) + ")";
		updateSql += ",screenTemplateID=" + Util.toSqlVal(data.getScreenTemplateId());
		updateSql += ",colorMode = " + Util.toSqlVal(data.getColorMode());
		if(Util.isCon(data.getSerialPort())){
			updateSql += ",serialPort = " + Util.toSqlVal(data.getSerialPort());
		}
		if(Util.isCon(data.getBaudRate())){
			updateSql += ",baudRate = " + Util.toSqlVal(data.getBaudRate());
		}
		if(Util.isCon(data.getIpport())){
			updateSql += ",ipport = " + Util.toSqlVal(data.getIpport());
		}
		if(isCon(id)){
			updateSql += " where id = " + Util.toSqlVal(id);
		}
		System.out.println("ooooooooo"+updateSql);
		return updateSql;
	}
	
	/**
     * Description :删除引导屏信息．
     * @param  :ScreenData
     * @return :String
     */
	public String screen_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screen where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	

	/**
     * Description :获得停车场地图list．
     * @param  :
     * @return :String
     */
	public String get_mapCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_map order  by id";
		
		return querySql;
	}
	/**
     * Description :获得管理器list．
     * @param  :
     * @return :String
     */
	public String get_controllerCode() {
		String querySql = "";
		
		querySql += "select id as code_id,addr as code_name from p_controller order  by id";
		
		return querySql;
	}
	/**
     * Description :获得引导屏类型list．
     * @param  :
     * @return :String
     */
	public String get_screenTypeCode() {
		String querySql = "";
		
		querySql += "select code as code_id,name as code_name from p_screentype order  by id";
		
		return querySql;
	}

	/**
	 * @param data
	 * @return
	 */
	public String check_screentype(ScreenData data) {
		String querySql = "";
		querySql += "select count(distinct screenTypeCode) from p_screen where id in ('" + data.getId().replaceAll(";", "','") + "')";
		System.out.println(querySql);
		return querySql;
	}

	/**
	 * @param id
	 * @param string
	 * @return
	 */
	public String paramvalue(String id, String type) {
//		String[] split = id.split(";");
//		StringBuffer ids = new StringBuffer();
//		for(int i = 0; i < split.length; i++){
//			ids.append("'");
//			ids.append(split[i]);
//			ids.append("',");
//		}
//		
//		if(ids.indexOf(",") != -1){
//			id = ids.substring(0, ids.length() - 1);
//		}
		String[] split = id.split(";");
		String querySql = "select tv.optionalValue,tv.id,tv.name," + (type.equals("1") ? "sv.value" : "'' as value") + ",tv.defaultValue,sv.describes " +
				"from p_screen s inner join p_screentypepara tv on tv.screenType=s.screenTypeCode " +
				"left join p_screenparavalue sv on sv.screenId=s.id and sv.screenTypeParaId=tv.id " +
				"where s.id = " + Util.toSqlVal(split[0]) + " order by tv.id+0";
		System.out.println("---------"+querySql);
		return querySql;
	}

	/**
	 * @param string
	 * @return
	 */
	public String screen_code(String id) {
		String querySql = "select code from p_screen where id= " + Util.toSqlVal(id) ;
		return querySql;
	}

	/**
	 * @param data
	 * @param string
	 * @return
	 */
	public String screenparavalue_update(String id, String field, String value) {
		String querySql = "update p_screenparavalue set value=" + Util.toSqlVal(value) + " where screenId=" + Util.toSqlVal(id) + 
				" and screenTypeParaId=" + Util.toSqlVal(field);
		System.out.println("$$$"+querySql);
		return querySql;
	}
	public String screenparavalue_save(String id, String field, String value) {
		String querySql = "insert into p_screenparavalue(id,screenId,screenTypeParaId,value) values(" +
				Util.toSqlVal(PrimaryId.getId()) + "," + Util.toSqlVal(id) + "," + Util.toSqlVal(field) + "," + Util.toSqlVal(value) + ")";
		return querySql;
	}

	public String getOldType(String id) {
		String querySql = "select screenTypeCode from p_screen where id = " + Util.toSqlVal(id);
		return querySql;
	}
	
	public String getOldTemplateID(String id) {
		String querySql = "select screenTemplateId from p_screen where id = " + Util.toSqlVal(id);
		return querySql;
	}
	
	/**
     * Description :获得引导屏参数值模板list．
     * @param  :
     * @return :String
     */
	public String get_screenParaTemplate() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_screenparatemplateheader order  by id";
		
		return querySql;
	}
	
	/**
     * Description :删除屏参数值表的信息．
     * @param  :id
     * @return :String
     */
	public String clearscreenparavalue(String screenid) {
		String deleteSql = "";
		deleteSql += "delete from p_screenparavalue where screenid = " + Util.toSqlVal(screenid);;
		return deleteSql;
	}
}
