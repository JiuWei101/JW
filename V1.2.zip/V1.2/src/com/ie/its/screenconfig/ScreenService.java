/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导屏配置
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : zy
 */
package com.ie.its.screenconfig;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.CodeData;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendService;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.screenlogic.ScreenLogicData;
import com.ie.its.screentypeparaconfig.ScreenTypeParaConfigSql;
import com.sun.org.apache.bcel.internal.generic.Select;
@Scope("prototype")
@Service
public class ScreenService extends ExtendService {
	private ScreenSql screenSql;
	private ScreenTypeParaConfigSql ScreenTypeParaConfigSql;
	
	public ScreenService(){
		screenSql = new ScreenSql();
		ScreenTypeParaConfigSql = new ScreenTypeParaConfigSql(); 
	}


	/**
     * Description :查询引导屏．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public ScreenData screen_list(ScreenData data) {
		//获得数量
		int count = this.getJt().queryForInt(screenSql.screen_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+screenSql.screen_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenData>rows = this.getJt().<ScreenData>queryForListExt(screenSql.screen_list(data, ""), 
				data.getStart(), data.getLimit(),ScreenData.class);
		
		//转换编码
		for(ScreenData tempData:rows){
			tempData.setStatus((String) ((HashMap)data.getCurrent_lang_switch().get("ctrl_status")).get(tempData.getStatus()));
			tempData.setEnable((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getEnable()));
			tempData.setColorMode((String) ((HashMap)data.getCurrent_lang_switch().get("color_mode")).get(tempData.getColorMode()));
			tempData.setIsExit((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getIsExit()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得引导屏信息．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public ScreenData screen_get(ScreenData data) {
		getJt().queryForObjectExt(screenSql.screen_get(data), data);
		
		return data;
	}
	@SuppressWarnings("unchecked")
	public List<ScreenData> screen_getAll() {//获得所有id
		List<ScreenData> dataList = getJt().queryForListExt(screenSql.screen_getAll(), ScreenData.class);
		return dataList;
	}
	
	/**
     * Description :获得修改字段list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_fieldCode(ScreenData data) {
		List codeList = new ArrayList();
		String[] field_code = {"controllerId","screenTypeCode","colorMode"};
		HashMap titles = (HashMap) data.getCurrent_lang_switch().get("common");
		String[] field_value = {(String) titles.get("controller"),(String) titles.get("screen_type"),
				(String) titles.get("controller_port"),(String) titles.get("color_mode")};
		for(int i = 0; i < 3; i++){
			CodeData cd = new CodeData();
			cd.setCode_id(field_code[i]);
			cd.setCode_name(field_value[i]);
			codeList.add(cd);
		}
		return codeList;
	}

	/**
     * Description :更新引导屏．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	@SuppressWarnings("unchecked")
	public ScreenData screen_update(ScreenData data) {
		String queryForObject = getJt().queryForObject(screenSql.getOldTemplateID(data.getId()), String.class);
		getJt().execute(screenSql.screen_update(data));
		ScreenData sd = new ScreenData();
		//屏参数模板改变自动重配屏参数值
		if(!data.getScreenTemplateId().equals(queryForObject)){
			templateparavalue_get(data, "86");
			ArrayList<ParamValueData> li = (ArrayList<ParamValueData>)data.getPer_data();
			StringBuffer sb_v = new StringBuffer(10);
			StringBuffer sb_f = new StringBuffer(10);
			for(int i = 0; i < li.size(); i++){
				if (li.get(i).getValue().length()==0) {
					li.get(i).setValue("00");
				}
				sb_v.append(li.get(i).getValue());
				sb_v.append(";");
				
				sb_f.append(li.get(i).getId());
				sb_f.append(";");
			}
			sd.setId(data.getId());
			if(sb_v.length() != 0)
				sd.setValue(sb_v.toString().substring(0, sb_v.toString().length() - 1));
			if(sb_f.length() != 0)
				sd.setField(sb_f.toString().substring(0, sb_f.toString().length() - 1));
			if(li.size() > 0)
				screenparavalue_save(sd);
		}
		return data;
	}
	
	/**
     * Description :更新引导屏．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	@SuppressWarnings("unchecked")
	public ScreenData screen_multiupdate(ScreenData data) {
		
		String[] sql = null;
		String[] id = data.getId().split(";");
		/*
		String[] fields = data.getField().split(",");
		String[] values = new String[fields.length];
		
		//if(data.getScreenTypeCode())
		for(int i = 0; i < fields.length; i++){
			if("controllerId".equals(fields[i].trim())){
				values[i] = data.getControllerId();
			} else if("colorMode".equals(fields[i].trim())){
				values[i] = data.getColorMode();
			}
		}
		*/
		if(!Util.isCon(id)){
			sql = new String[1];
			sql[0] = screenSql.screen_multiupdate(data);
		} else {
			sql = new String[id.length];
			for(int i = 0; i < id.length; i++){
				sql[i] = screenSql.screen_multiupdate(data, id[i]);
			}
		}
		//批量更新
		getJt().batchUpdate(sql);
		for(int j = 0; j < id.length; j++){
			String queryForObject = getJt().queryForObject(screenSql.getOldTemplateID(id[j]), String.class);
			ScreenData sd = new ScreenData();
			//屏类型改变自动重配屏参数值
//			if(!data.getScreenTemplateId().equals(queryForObject)){
				data.setId(id[j]);
				templateparavalue_get(data, "86");
				ArrayList<ParamValueData> li = (ArrayList<ParamValueData>)data.getPer_data();
				StringBuffer sb_v = new StringBuffer(10);
				StringBuffer sb_f = new StringBuffer(10);
				for(int k = 0; k < li.size(); k++){
					
					sb_v.append(li.get(k).getValue());
					sb_v.append(";");
					
					sb_f.append(li.get(k).getId());
					sb_f.append(";");
				}
				if(li.size() > 0){
				
					sd.setId(data.getId());
					if(sb_v.length() != 0)
						sd.setValue(sb_v.toString().substring(0, sb_v.toString().length() - 1));
					if(sb_f.length() != 0)
						sd.setField(sb_f.toString().substring(0, sb_f.toString().length() - 1));
					
					screenparavalue_save(sd);
				}
				
//			}
		}
		return data;
	}

	/**
     * Description :删除引导屏．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public ScreenData screen_delete(ScreenData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = screenSql.screen_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :获得停车场地图list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_mapCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenSql.get_mapCode(), ScreenData.class);
		return codeList;
	}
	/**
     * Description :获得管理器list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_controllerCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenSql.get_controllerCode(), ScreenData.class);
		return codeList;
	}
	/**
     * Description :获得引导屏类型list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_screenTypeCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenSql.get_screenTypeCode(), ScreenData.class);
		return codeList;
	}
	/**
     * Description :获得引导屏类型list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_controllerPortCode() {
		List codeList = new ArrayList();
		for(int i =1; i < 4; i++){
			CodeData cd = new CodeData();
			cd.setCode_id(String.valueOf(i));
			cd.setCode_name(String.valueOf(i));
			codeList.add(cd);
		}
		return codeList;
	}
	/**
	 * @param data
	 * @return
	 */
	public ScreenData check_screentype(ScreenData data) {
		//提交的数据中只会含有一种类型的探测器，所以只用第一个探测器判断
		int count = this.getJt().queryForInt(screenSql.check_screentype(data));
		data.setTotal(count);
		return data;
	}


	/**
	 * @param data
	 */
	public void screenparavalue_get(ScreenData data, String lang) {
		String[] ids = data.getId().split(";");
		ArrayList <ParamValueData>rows = new ArrayList<ParamValueData>();
		if(ids.length == 1){
			screen_get(data);
			//返回结果集 直接就是BookData 不用转换
			rows = this.getJt().<ParamValueData>queryForListExt(screenSql.paramvalue(data.getId(), "1"), ParamValueData.class);
			
		} else {
			String code = "";
			for(int i = 0; i < ids.length; i++){
				code += getJt().queryForMap(screenSql.screen_code(ids[i])).get("code");
			}
			if(code.length() > 0){
				code = code.substring(1);
			}
			data.setCode(code);
			//返回结果集 直接就是BookData 不用转换
			rows = this.getJt().<ParamValueData>queryForListExt(screenSql.paramvalue(data.getId(), "n"), ParamValueData.class);
			
		}
		for(int i=0;i<rows.size();i++){
			ParamValueData paramValueData = rows.get(i);
			String optionalValue = paramValueData.getOptionalValue();
			JSONArray arr = new JSONArray();
			if(optionalValue != null && !optionalValue.equals("")){
				String[] split = optionalValue.split(",");
				
				for(int j=0;j<split.length;j++){
					JSONObject js = new JSONObject();
					js.element("code_id", split[j]);
					js.element("code_name", split[j]);
					arr.add(js);
				}
			}
			if(lang.equals("44"))
				paramValueData.setLang_text("--- select ---");
			else
				paramValueData.setLang_text("--- 请选择 ---");
			paramValueData.setOptionalList(arr);
			
		}
		data.setPer_data(rows);
	}
	/**
	 * @param data
	 */
	public void screenparavalue_save(ScreenData data) {
		
		String[] ids = data.getId().split(";");
		String[] fields = data.getField().split(";");
		String[] values = data.getValue().split(";");
		System.out.println("clearscreenparavalue");
		System.out.println((screenSql.clearscreenparavalue(data.getId())));
		System.out.println(values.length);
		this.getJt().execute((screenSql.clearscreenparavalue(data.getId())));
		for(int i = 0; i < ids.length; i++){
			for(int j = 0; j < fields.length; j++){
				if(values[j].equals("!"))
					values[j] = "";
//				int count = this.getJt().update(screenSql.screenparavalue_update(ids[i], fields[j], values[j]));
//				if(count == 0){
				System.out.println(screenSql.screenparavalue_save(ids[i], fields[j], values[j]));
					this.getJt().update(screenSql.screenparavalue_save(ids[i], fields[j], values[j]));
//				}
			}
		}
		
	}
	
	/**
     * Description :获得引导屏参数值模板list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_screenParaTemplate() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenSql.get_screenParaTemplate(), ScreenData.class);
		return codeList;
	}
	
	/**
	 * @param data
	 */
	public void templateparavalue_get(ScreenData data, String lang) {
		System.out.println("data.getId()    ----"+data.getId());
		String[] ids = data.getId().split(";");
		ArrayList <ParamValueData>rows = new ArrayList<ParamValueData>();
		if(ids.length == 1){
			screen_get(data);
			//返回结果集 直接就是BookData 不用转换
			rows = this.getJt().<ParamValueData>queryForListExt(ScreenTypeParaConfigSql.paramvalue(data.getScreenTemplateId(), "1"), ParamValueData.class);
		} else {
			String code = "";
			for(int i = 0; i < ids.length; i++){
				code += getJt().queryForMap(screenSql.screen_code(ids[i])).get("code");
			}
			if(code.length() > 0){
				code = code.substring(1);
			}
			System.out.println("code:   "+code);
			data.setCode(code);
			//返回结果集 直接就是BookData 不用转换
			rows = this.getJt().<ParamValueData>queryForListExt(ScreenTypeParaConfigSql.paramvalue(data.getScreenTemplateId(), "1"), ParamValueData.class);
			
		}
		for(int i=0;i<rows.size();i++){
			ParamValueData paramValueData = rows.get(i);
			String optionalValue = paramValueData.getOptionalValue();
			JSONArray arr = new JSONArray();
			if(optionalValue != null && !optionalValue.equals("")){
				String[] split = optionalValue.split(",");
				
				for(int j=0;j<split.length;j++){
					JSONObject js = new JSONObject();
					js.element("code_id", split[j]);
					js.element("code_name", split[j]);
					arr.add(js);
				}
			}
			if(lang.equals("44"))
				paramValueData.setLang_text("--- select ---");
			else
				paramValueData.setLang_text("--- 请选择 ---");
			paramValueData.setOptionalList(arr);
			
		}
		data.setPer_data(rows);
	}
}
