/**
 * 
 */
package com.ie.its.inifile;

/**
 * @author zhaoyan
 *
 */
public class DetectorSet {
	int address;		//地址（16）
	int fileSign;		//文件标识（8）
	DetectorInfo[] dectors;	//探测器列表（128）
	/**
	 * @return the address
	 */
	public int getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(int address) {
		this.address = address;
	}
	/**
	 * @return the fileSign
	 */
	public int getFileSign() {
		return fileSign;
	}
	/**
	 * @param fileSign the fileSign to set
	 */
	public void setFileSign(int fileSign) {
		this.fileSign = fileSign;
	}
	/**
	 * @return the dectors
	 */
	public DetectorInfo[] getDectors() {
		return dectors;
	}
	/**
	 * @param dectors the dectors to set
	 */
	public void setDectors(DetectorInfo[] dectors) {
		this.dectors = dectors;
	}
	
}
