/**
 * 
 */
package com.ie.its.inifile;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.ie.common.CodeData;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.controllerconfig.ControllerService;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;

/**
 * @author zhaoyan
 *
 */
public class IniFileCreator {
	int address = 6;
	public boolean create(ControllerService ctrlServ,String controllerId, String filename){
		File file=new File(filename);
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		//第二部分
		LogicRegionSet lrSet = makeLogicRegion(ctrlServ, controllerId);
		//第一部分
		DetectorSet dSet = makeDetector(ctrlServ, controllerId);
		//第三部分
		ScreenSet sSet = makeScreen(ctrlServ, controllerId);
		if(sSet.getNum() == 0){
			sSet.setAddress(0xffff);
		}
		
		try {
			fos = new FileOutputStream(file);
			dos = new DataOutputStream(fos);
			
			//写三部分地址
			fileWrite2(dos, dSet.getAddress());
			fileWrite2(dos, lrSet.getAddress());
			fileWrite2(dos, sSet.getAddress());
			
			//写第二部分内容
			fileWrite1(dos,	lrSet.getFileSign());
			fileWrite2(dos, lrSet.getNum());
			for(int i = 0; i < lrSet.getNum(); i++){
				fileWrite2(dos, lrSet.getLogicRegionAddr()[i]);
				fileWrite2(dos, lrSet.getLogicRegionParkingNum()[i]);
			}
			
			//写第一部分内容
			fileWrite1(dos,	dSet.getFileSign());
			//先写地址
			for(int i = 0; i < 128; i++){
				fileWrite2(dos, dSet.getDectors()[i].getAddress());
			}
			//再写数据
			for(int i = 0; i < 128; i++){
				fileWrite2(dos, dSet.getDectors()[i].getSize());
				fileWrite1(dos, dSet.getDectors()[i].getEnable());
				fileWrite1(dos, dSet.getDectors()[i].getId());
				for(int j = 0; j < dSet.getDectors()[i].getSize(); j++){
					fileWrite2(dos, dSet.getDectors()[i].getRegionId()[j]);
				}
			}
			
			//第三部分内容
			fileWrite1(dos,	sSet.getFileSign());
			fileWrite1(dos,	sSet.getNum());
			//先写地址
			for(int i = 0; i < sSet.getNum(); i++){
				fileWrite2(dos,	sSet.getScreenInfo()[i].getAddress());
			}
			//再写数据
			for(int i = 0; i < sSet.getNum(); i++){
				fileWrite1(dos,	sSet.getScreenInfo()[i].getEnable());
				fileWrite1(dos,	sSet.getScreenInfo()[i].getScreenPort());
				fileWrite2(dos,	sSet.getScreenInfo()[i].getScreenAddress());
				fileWrite1(dos,	sSet.getScreenInfo()[i].getSize());
				for(int j = 0; j < 	sSet.getScreenInfo()[i].getSize(); j++){
					fileWrite1(dos,	sSet.getScreenInfo()[i].getContent()[j]);
				}
			}
			//文件长度不是16的整数倍，则补充00至16的整数倍
			System.out.println("文件长度:" + dos.size());
			long len = dos.size();
			while(len % 16 != 0){
				fileWrite1(dos,	0);
				len ++;
				System.out.println("文件长度=" + dos.size() + "len=" + len + "len%16=" + len%16);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(dos != null){
				try {
					dos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(fos != null){
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return true;
	}
	//写文件，一个字节的
	private void fileWrite2(DataOutputStream dos, int data) throws IOException{
		int[] nums = getWriteableHex(data, "2");
		dos.write(nums[0]);
		dos.write(nums[1]);
	}
	//写文件，两个字节的，高位在后
	private void fileWrite1(DataOutputStream dos, int data) throws IOException{
		dos.write(getWriteableHex(data, "1")[0]);
	}
	//生成第一部分内容：探测器对应区域配置表
	private DetectorSet makeDetector(ControllerService ctrlServ, String controllerId){
		DetectorSet ds = new DetectorSet();
		ds.setAddress(address);
		ds.setFileSign(1);
		address++;
		address += 128 * 2;
		DetectorInfo[] detectorInfoList = new DetectorInfo[128];
		
		//取配置
		DetectorConfigData ctrlData = ctrlServ.getDetectorConfigData(controllerId );
		int size = ctrlData.getTotal();
		
		for(int i = 0; i < 128; i++){
			detectorInfoList[i] = new DetectorInfo();
			DetectorInfo detectorInfo = detectorInfoList[i];
			boolean flag = true;
			detectorInfo.setAddress(address);
			for(int j = 0; j < size; j++){
				DetectorConfigData data = ((ArrayList <DetectorConfigData>)ctrlData.getPer_data()).get(j);
				if(data.getAddr() != null && i == Integer.parseInt(data.getAddr())){
					DetectorConfigData list = ctrlServ.getDetectorRegion(data.getId());
					detectorInfo.setSize(list.getTotal());
					address += 2;
					detectorInfo.setEnable(Integer.parseInt(data.getEnable() == null ? "0" : data.getEnable()));
					address++;
					detectorInfo.setId(Integer.parseInt(data.getAddr() == null ? "0" : data.getAddr()));
					address ++;
					int[] regionId = new int[list.getTotal()];
					for(int k = 0; k < list.getTotal(); k ++){
						DetectorConfigData region = ((ArrayList <DetectorConfigData>)list.getPer_data()).get(k);
						regionId[k] = Integer.parseInt(region.getId());
						address += 2;
					}
					detectorInfo.setRegionId(regionId);
					flag = false;
					break;
				}
			}
			if(flag){
				detectorInfo.setSize(0);
				address += 2;
				detectorInfo.setEnable(0);
				address++;
				detectorInfo.setId(i);
				address ++;
				int[] regionId = new int[0];
				detectorInfo.setRegionId(regionId);
			}
		}
		ds.setDectors(detectorInfoList);
		return ds;
	}
	//生成第二部分内容：区域逻辑地址(即ZDB_id)列表
	private LogicRegionSet makeLogicRegion(ControllerService ctrlServ, String controllerId){
		LogicRegionSet lrs = new LogicRegionSet();
		lrs.setAddress(address);
		lrs.setFileSign(2);
		address++;
		
		//取配置
		ControllerData ctrlData = ctrlServ.getLogicRegion(controllerId );
		int size = ctrlData.getTotal();
		lrs.setNum(size);
		address += 2;
		lrs.setLogicRegionAddr(new int[size]);
		lrs.setLogicRegionParkingNum(new int[size]);
		
		for(int i = 0; i < size; i++){
			lrs.getLogicRegionAddr()[i] = Integer.parseInt(((ArrayList<CodeData>)ctrlData.getPer_data()).get(i).getCode_id());
			address += 2;
			lrs.getLogicRegionParkingNum()[i] = Integer.parseInt(((ArrayList<CodeData>)ctrlData.getPer_data()).get(i).getCode_name());
			address += 2;
		}
		return lrs;
	}
	//生成第三部分内容：LED显示屏配置表
	private ScreenSet makeScreen(ControllerService ctrlServ, String controllerId){
		ScreenSet screenSet = new ScreenSet();
		screenSet.setAddress(address);
		screenSet.setFileSign(3);
		address++;
		//取配置
		ScreenData ctrlData = ctrlServ.getScreenSet(controllerId );
		int size = ctrlData.getTotal();
		screenSet.setNum(size);
		address++;
		screenSet.setScreenInfo(new ScreenInfo[size]);
		address += size * 2;
		for(int i = 0; i < size; i++){
			if(screenSet.getScreenInfo()[i] == null){
				screenSet.getScreenInfo()[i] = new ScreenInfo();
			}
			ScreenInfo screenInfo = screenSet.getScreenInfo()[i];
			ScreenData screenData = ((ArrayList<ScreenData>)ctrlData.getPer_data()).get(i);
			ArrayList<CodeData> paramValue = ctrlServ.getScreenTypeParamValue(screenData.getId());
			HashMap<String,String> paramValueMap = new HashMap<String,String>();
			for(int ind = 0; ind < paramValue.size(); ind++){
				paramValueMap.put(paramValue.get(ind).getCode_id().toLowerCase(), paramValue.get(ind).getCode_name());
			}
			screenInfo.setAddress(address);
			screenInfo.setEnable(Integer.parseInt(screenData.getEnable() == null ? "0" : screenData.getEnable()));
			address++;
			screenInfo.setScreenPort(Integer.parseInt(screenData.getControllerPort() == null ? "0" : screenData.getControllerPort().replaceAll("COM", "")));
			address++;
			//组地址在前，生成文件的时候组地址在后
			screenInfo.setScreenAddress(Integer.parseInt(screenData.getGrpAddr() == null ? "0" : screenData.getGrpAddr()) * 256 + 
					Integer.parseInt(screenData.getAddr() == null ? "0" : screenData.getAddr()));
			address += 2;
			//处理显示格式，把形如[A,B]格式的引导区域转换成[1:3]（[屏幕区域ID:显示车位数字长度（位数）]）格式的屏幕区域
			String content = screenData.getContentFormat() ;
			String tmpstr = content;
			String regionId;
			String str_old;
			String str_new;
			int fixLen = 0;
			for(;;){
				int start = -1;
				int end = -1;
				start = tmpstr.indexOf("[");
				end = tmpstr.indexOf("]");
				if(start == -1 || end == -1){
					break;
				}
				str_old = tmpstr.substring(start,end + 1);
				tmpstr = tmpstr.substring(end + 1);
				CodeData region = ctrlServ.getRegionId(screenData.getId(),str_old.substring(1,str_old.length() - 1));//获取屏分区id和车位数
				//以下备注部份是：艾能的，配置文件下发有错，by wenzr 2012.07.04
				//region.setCode_id(("00" + region.getCode_id()));
				//region.setCode_id(region.getCode_id().substring(region.getCode_id().length() - 2));
				
				//str_new = "[" + (char)Integer.parseInt(region.getCode_id().substring(1)) + 
				//		(char)Integer.parseInt(region.getCode_id().substring(0,1)) + ":" + (char)region.getCode_name().length() + "]";
				///*更改计算方法， by wenzr 2012.07.04*///
				int[] hexStr=getWriteableHex(Integer.parseInt(region.getCode_id()),"2");
				str_new="["+(char)hexStr[0]+(char)hexStr[1]+":"+(char)region.getCode_name().length() + "]";
				///end,by wenzr
				int pos = content.indexOf(str_old);
				content = content.substring(0,pos) + str_new + content.substring(pos+str_old.length());
				fixLen += str_new.length() - region.getCode_name().length();
//				content = content.replaceFirst(str_old, str_new);
			}
			//原来听王欢说第二个以后的颜色要加个{，后来唐金合说颜色不用替换，但用户在格式中输入了{，长度就要加1
//			content = content.replaceAll("\\\\R", "\\\\R{");
//			content = content.replaceAll("\\\\G", "\\\\G{");
//			content = content.replaceAll("\\\\Y", "\\\\Y{");
//			content = content.substring(0,content.indexOf("{")) + content.substring(content.indexOf("{") + 1);
			for(int j = 0; j < content.length(); j++){
				if("{".equals(content.substring(j,j+1))){
					//固定长度内容减少，相当于内容长度增加
					fixLen--;
				}
			}
			
			//处理GB2312无法转码的问题，当字符>127时
			byte[] bytestemp = null;
			byte[] bytesbuffer = new byte[500];
			int buffercount=0;
			String strtemp;
			try {
				for(int m=0;m<content.length();m++){
					strtemp= content.substring(m, m+1);
					bytestemp= strtemp.getBytes("GBK");//由gb2312改为GBK以支持繁体---modified by wangj 2013-10-16
					for(int n=0;n<bytestemp.length;n++){
						if (bytestemp[n]==63) //如果GB2312无法转码，则把对应字段强制转为byte
							bytestemp[n]=(byte)strtemp.charAt(0);
						bytesbuffer[buffercount++]=bytestemp[n];	
					}
				}
			}  
			catch (Exception e) {
				e.printStackTrace();
			}
			
			//把上面转化得到bytesbuffer的拷贝到bytes
			byte[] bytes = new byte[buffercount];
			for(int m=0;m<buffercount;m++){
				bytes[m]=bytesbuffer[m];
			}
			
			
			address += 22 + bytes.length;
			screenInfo.setSize(22 + bytes.length);
			address++;
			screenInfo.setContent(new int[22 + bytes.length]);
			//数据数组大小,不包括[0011:03]这种格式的长度，再加车位数字长度
				
			//使得青松屏也可以下发配置文件 
			if (paramValueMap.get("start")==null){
				paramValueMap.put("start", "00");
			}
			if (paramValueMap.get("cmd")==null){
				paramValueMap.put("cmd", "00");
			}
			if (paramValueMap.get("inout")==null){
				paramValueMap.put("inout", "00");
			}
			if (paramValueMap.get("move")==null){
				paramValueMap.put("move", "00");
			}
			if (paramValueMap.get("pause")==null){
				paramValueMap.put("pause", "00");
			}
			if (paramValueMap.get("append")==null){
				paramValueMap.put("append", "00");
			}
			if (paramValueMap.get("mode")==null){
				paramValueMap.put("mode", "00");
			}
			if (paramValueMap.get("reverse")==null){
				paramValueMap.put("reverse", "00");
			}
			if (paramValueMap.get("led_w")==null){
				paramValueMap.put("led_w", "00");
			}
			if (paramValueMap.get("led_h")==null){
				paramValueMap.put("led_h", "00");
			}
			if (paramValueMap.get("x_offset")==null){
				paramValueMap.put("x_offset", "00");
			}
			if (paramValueMap.get("y_offset")==null){
				paramValueMap.put("y_offset", "00");
			}
			if (paramValueMap.get("font")==null){
				paramValueMap.put("font", "00");
			}
			if (paramValueMap.get("light")==null){
				paramValueMap.put("light", "00");
			}
			if (paramValueMap.get("redretio")==null){
				paramValueMap.put("redretio", "00");
			}
			if (paramValueMap.get("end")==null){
				paramValueMap.put("end", "00");
			}
			  		
			
			screenInfo.getContent()[0] = 21 + bytes.length - fixLen;	//不包括本身，所以是21
			screenInfo.getContent()[1] = (int) Long.parseLong(paramValueMap.get("start"), 16);		//报文头
			screenInfo.getContent()[2] = Integer.parseInt(screenData.getGrpAddr());	//屏组地址低字节在前
			screenInfo.getContent()[3] = Integer.parseInt(screenData.getAddr());	//屏地址高字节在后
			screenInfo.getContent()[4] = 0x10;									//条屏类型符TYPE，长度1字节，本条屏值为0x10
			screenInfo.getContent()[5] = (int) Long.parseLong(paramValueMap.get("cmd"), 16);		//操作类型CMD，本指令固定为0xE1
			screenInfo.getContent()[6] = (int) Long.parseLong(paramValueMap.get("inout"), 16);	//显示方式CTRL0(Inout)，长度1字节；0为左移,1为上移,2为下拉,3为上拉,4为即显，5为动态箭头;
			screenInfo.getContent()[7] = (int) Long.parseLong(paramValueMap.get("move"), 16);		//移动速度CTRL1(Move) ,长度1字节
			screenInfo.getContent()[8] = (int) Long.parseLong(paramValueMap.get("pause"), 16);		//显示停留时间CTRL2(Pause)，长度1字节
			screenInfo.getContent()[9] = (int) Long.parseLong(paramValueMap.get("append"), 16);		//显示扩展方式CTRL3(Append)，长度1字节；1代表显示本幕前清除屏幕内容,
																					//2代表显示本幕后清除屏幕内容,4代表引出方式有效,8代表本幕内容不显示,
																					//用显示屏内置时间格式显示代替,这四种附加方式可组合显示,例如3表示前清和后清同时有效
			screenInfo.getContent()[10] = (int) Long.parseLong(paramValueMap.get("mode"), 16);		//扫描方式选择CTRL4(Mode)
			screenInfo.getContent()[11] = (int) Long.parseLong(paramValueMap.get("reverse"), 16);		//驱动选择CTRL5（Reverse），第一位为“使能反向”，1代表使能，0代表不使能；
																					//第二位为“反色显示”，1代表反色，0代表不反色
			// 更改原代码，屏宽度在参数值里填写的是16进制，add by shenlk 2012-08-09
			//screenInfo.getContent()[12] = (int) Long.parseLong(paramValueMap.get("led_w"));//, 16);		//11、	显示屏宽度CTRL6（Led_w）led_w，长度1字节
			screenInfo.getContent()[12] = (int) Long.parseLong(paramValueMap.get("led_w"),16);
			
			screenInfo.getContent()[13] = (int) Long.parseLong(paramValueMap.get("led_h"), 16);		//12、	显示屏高度CTRL7（Led_h），长度1字节
			screenInfo.getContent()[14] = (int) Long.parseLong(paramValueMap.get("x_offset"), 16);	//13、	X坐标的显示偏移量CTRL8（X_offset），代表显示内容向右偏移多少个点数
			screenInfo.getContent()[15] = (int) Long.parseLong(paramValueMap.get("x_offset"), 16);	//14、	Y坐标的显示偏移量CTRL9（X_offset），代表显示内容向上偏移多少个点数
			screenInfo.getContent()[16] = (int) Long.parseLong(paramValueMap.get("font"), 16);		//15、	字体CTRL10（font），长度1字节；0为16*16字体（选择字库芯片读取字体）,1为32*32字体
																					//（选择flash芯片读取字体）,2为24*24字体（选择flash芯片读取字体）；2为24*24字体
			screenInfo.getContent()[17] = (int) Long.parseLong(paramValueMap.get("light"), 16);		//16、	亮度CTRL11（lm），为显示亮度，范围为[1～20]。20、0代表最亮
			screenInfo.getContent()[18] = (int) Long.parseLong(paramValueMap.get("redretio"), 16);	//17、	红色占空比CTRL12（Red retio），为红色显示的占空比设置，主要应用在室内条屏，
																					//控制红色的对比度
			int index = 19;
			for(int j = 0; j < bytes.length; j++){
				screenInfo.getContent()[index] = bytes[j];							//18、	显示数据Data，不定长度，为Ascii或汉字内码；\R \G \Y为颜色控制符，
																					//该控制符影响它之后的文字显示的颜色，直到遇到下一个颜色控制符
				index++;
			}
//			screenInfo.getContent()[index] = 0;									//19、	其余显示模式及数据Mode/Data(内容已经加到18里了，这里的其余是指18里只写一条)
			screenInfo.getContent()[index] = 0;									//20、	校验和checksum，长度2字节（低）（小唐说不用在这边校验，由管理器来进行）
			screenInfo.getContent()[index + 1] = 0;									//20、	校验和checksum，长度2字节（高）（小唐说不用在这边校验，由管理器来进行）
			screenInfo.getContent()[index + 2] = (int) Long.parseLong(paramValueMap.get("end"), 16);	//21、	结束标志end，长度1字节，值为0xDD，报文发送结束标志
			
		}
		return screenSet;
	}
	
	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	private int[] getWriteableHex(int num, String type){
		if(type.equals("1")){
			//一字节
			int rt[] = {num%256};
			return rt;
		} else {
			//两字节，低位在前，高位超出部分截断
			int rt[] = {num%256, (num/256)%256};
			return rt;
		}
	}
	
	public static void main(String[] args){
		IniFileCreator ifc = new IniFileCreator();
		System.out.println(ifc.getWriteableHex(255,"1"));
		System.out.println(ifc.getWriteableHex(8,"2"));
		System.out.println(ifc.getWriteableHex(9,"2"));
		System.out.println(ifc.getWriteableHex(10,"2"));
		System.out.println(ifc.getWriteableHex(255,"2"));
		System.out.println(ifc.getWriteableHex(65535,"1"));
		System.out.println(ifc.getWriteableHex(65535,"2"));
		System.out.println(ifc.getWriteableHex(123,"1"));
		System.out.println(ifc.getWriteableHex(123,"2"));
		System.out.println(ifc.getWriteableHex(31,"1"));
		System.out.println(ifc.getWriteableHex(31,"2"));
		System.out.println(ifc.getWriteableHex(35,"1"));
		System.out.println(ifc.getWriteableHex(35,"2"));
	}
}
