/**
 * 
 */
package com.ie.its.inifile;

/**
 * @author zhaoyan
 *
 */
public class ScreenInfo {
	int address;		//地址（16）
	int enable;			//设备使能位（是否开启）（8）
	int screenPort;		//端口号(文档缺少)(8)
	int screenAddress;	//显示屏地址(16)
	int size;			//内容数组大小(8)
	int[] content;		//内容（8）
	/**
	 * @return the address
	 */
	public int getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(int address) {
		this.address = address;
	}
	/**
	 * @return the enable
	 */
	public int getEnable() {
		return enable;
	}
	/**
	 * @param enable the enable to set
	 */
	public void setEnable(int enable) {
		this.enable = enable;
	}
	/**
	 * @return the screenAddress
	 */
	public int getScreenAddress() {
		return screenAddress;
	}
	/**
	 * @param screenAddress the screenAddress to set
	 */
	public void setScreenAddress(int screenAddress) {
		this.screenAddress = screenAddress;
	}
	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}
	/**
	 * @return the content
	 */
	public int[] getContent() {
		return content;
	}
	/**
	 * @param content the content to set
	 */
	public void setContent(int[] content) {
		this.content = content;
	}
	/**
	 * @return the screenPort
	 */
	public int getScreenPort() {
		return screenPort;
	}
	/**
	 * @param screenPort the screenPort to set
	 */
	public void setScreenPort(int screenPort) {
		this.screenPort = screenPort;
	}
	
}
