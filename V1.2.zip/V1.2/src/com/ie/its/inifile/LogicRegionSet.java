/**
 * 
 */
package com.ie.its.inifile;

/**
 * @author zhaoyan
 *
 */
public class LogicRegionSet {
	int address;					//地址（16）
	int fileSign;					//文件标识（8）
	int num;						//拥有的逻辑区域数量(16）
	int[] logicRegionAddr;			//逻辑区域地址号(16)
	int[] logicRegionParkingNum;	//车位总数（16）
	/**
	 * @return the address
	 */
	public int getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(int address) {
		this.address = address;
	}
	/**
	 * @return the fileSign
	 */
	public int getFileSign() {
		return fileSign;
	}
	/**
	 * @param fileSign the fileSign to set
	 */
	public void setFileSign(int fileSign) {
		this.fileSign = fileSign;
	}
	/**
	 * @return the num
	 */
	public int getNum() {
		return num;
	}
	/**
	 * @param num the num to set
	 */
	public void setNum(int num) {
		this.num = num;
	}
	/**
	 * @return the logicRegionAddr
	 */
	public int[] getLogicRegionAddr() {
		return logicRegionAddr;
	}
	/**
	 * @param logicRegionAddr the logicRegionAddr to set
	 */
	public void setLogicRegionAddr(int[] logicRegionAddr) {
		this.logicRegionAddr = logicRegionAddr;
	}
	/**
	 * @return the logicRegionParkingNum
	 */
	public int[] getLogicRegionParkingNum() {
		return logicRegionParkingNum;
	}
	/**
	 * @param logicRegionParkingNum the logicRegionParkingNum to set
	 */
	public void setLogicRegionParkingNum(int[] logicRegionParkingNum) {
		this.logicRegionParkingNum = logicRegionParkingNum;
	}
	
}
