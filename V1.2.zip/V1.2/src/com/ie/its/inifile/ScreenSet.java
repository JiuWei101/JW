/**
 * 
 */
package com.ie.its.inifile;

/**
 * @author zhaoyan
 *
 */
public class ScreenSet {
	int address;				//地址（16）
	int fileSign;				//文件标识（8）
	int num;					//数量(8)
	ScreenInfo[] screenInfo;	//屏
	/**
	 * @return the address
	 */
	public int getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(int address) {
		this.address = address;
	}
	/**
	 * @return the fileSign
	 */
	public int getFileSign() {
		return fileSign;
	}
	/**
	 * @param fileSign the fileSign to set
	 */
	public void setFileSign(int fileSign) {
		this.fileSign = fileSign;
	}
	/**
	 * @return the num
	 */
	public int getNum() {
		return num;
	}
	/**
	 * @param num the num to set
	 */
	public void setNum(int num) {
		this.num = num;
	}
	/**
	 * @return the screenInfo
	 */
	public ScreenInfo[] getScreenInfo() {
		return screenInfo;
	}
	/**
	 * @param screenInfo the screenInfo to set
	 */
	public void setScreenInfo(ScreenInfo[] screenInfo) {
		this.screenInfo = screenInfo;
	}
	
}
