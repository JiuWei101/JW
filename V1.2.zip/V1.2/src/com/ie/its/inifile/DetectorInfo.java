/**
 * 
 */
package com.ie.its.inifile;

/**
 * @author zhaoyan
 * 探测器
 */
public class DetectorInfo {
	int address;		//地址（16）
	int size;			//列表大小（16）
	int enable;			//设备使能位（是否开启）（8）
	int id;				//设备id（8）
	int[] regionId;		//对应区域id(16)
	/**
	 * @return the address
	 */
	public int getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(int address) {
		this.address = address;
	}
	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the enable
	 */
	public int getEnable() {
		return enable;
	}
	/**
	 * @param enable the enable to set
	 */
	public void setEnable(int enable) {
		this.enable = enable;
	}
	/**
	 * @return the regionId
	 */
	public int[] getRegionId() {
		return regionId;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(int[] regionId) {
		this.regionId = regionId;
	}
	
}
