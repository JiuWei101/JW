/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 地图管理
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.task.screen;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageService;

//命名空间
@Namespace("/task_screen")
@Results({@Result(name="list",location="/task_screen/screen_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="screen_list",location="list.action",type="redirect")})
public class TaskScreenAction extends ExtendActionSupport {
	
	private TaskScreenData data;
	@Autowired
	private TaskScreenService taskScreenService;
	@Autowired
	private MapManageService mapService;
	
	public TaskScreenData getData() {
		return data;
	}
	public void setData(TaskScreenData data) {
		this.data = data;
	}
	public TaskScreenAction(){
		if(data == null){
			data = new TaskScreenData();
		}
	}
	
	
	/**
     * Description :查询引导屏计划．
     * @throws :Exception
     */
	@Action(value="list",results={@Result(name="success",location="/task_screen/screen_list.jsp")})
	public String list(){
		data = taskScreenService.list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("screen_task_type", request.getSession().getAttribute("lang").toString()));
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
     * Description :查询引导屏历史．
     * @throws :Exception
     */
	@Action(value="history",results={@Result(name="success",location="/task_screen/screen_history.jsp")})
	public String history(){
		
		data = taskScreenService.list_history(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("screen_task_type", request.getSession().getAttribute("lang").toString()));
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
     * Description :新建引导屏计划．
     * @throws :Exception
     */
	@Action(value="task_main",results={@Result(name="success",location="/task_screen/task_main.jsp")})
	public String task_main(){
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
     * Description :获得车位信息．
     * @throws :Exception
     */
	@Action(value="get_parking_mess",results={@Result(type="json")})
	public void get_parking_mess(){
		JSONObject json = new JSONObject();
		Log.log(data.getMap_name());
		try{
			json = taskScreenService.get_parking_mess(data);
		}catch(Exception e){
			Log.log(e);
			json.element("success", false);
			json.element("mess", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :获得屏信息．
     * @throws :Exception
     */
	@Action(value="get_screen_mess",results={@Result(type="json")})
	public void get_screen_mess(){
		JSONObject json = new JSONObject();
		Log.log(data.getMap_name());
		try{
			json = taskScreenService.get_screen_mess(data);
		}catch(Exception e){
			Log.log(e);
			json.element("success", false);
			json.element("mess", e.getMessage());
		}
		
		setJsonRes(json);
	}
	/**
     * Description :新建计划(包含车位和引导屏)．
     * @throws :Exception
     */
	@Action(value="task_create",results={@Result(name="success",location="/task_screen/task_create.jsp")})
	public String task_create(){
//		data = taskScreenService.list(data);
		MapManageData mapData = new MapManageData();
		data.setMapList(mapService.map_getMapCode(mapData));
		
//		//获得地图list
//		JSONArray jsonArr = JSONArray.fromObject(mapService.map_getMapCode(mapData));
		//this.request.setAttribute("map", jsonArr);
		
		
		this.request.setAttribute("def_id",mapData.getId());
		this.request.setAttribute("def_path", mapData.getPath());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	/**
     * Description :跳转到地图页面．
     * @throws :Exception
     */
	@Action(value="to_flash",results={@Result(name="success",location="/task_screen/flash_pub.jsp")})
	public String to_flash(){
		data.setMap_src(mapService.map_getSrc(data.getId()));
		//设置多语言
		setLang(data);
		
		this.request.setAttribute("map_src", data.getMap_src());
		Log.log("-----"+this.request.getAttribute("map_src"));
		return "success";
	}
	/**
     * Description :新建引导屏计划．
     * @throws :Exception
     */
	@Action(value="create",results={@Result(name="success",location="/task_screen/create.jsp")})
	public String create(){
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		Log.log("------"+data.getTaskData());
		taskScreenService.get_screenId(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		//this.request.setAttribute("mess", taskScreenService.get_screenId(data));
		data.setMoveList(DisposalCode.getCode("move", request.getSession().getAttribute("lang").toString()));
		data.setMoveMethod("04");//这里默认为静止方式-04
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("screen_task_type", request.getSession().getAttribute("lang").toString()));
		data.setWeekDayList(DisposalCode.getCodeNoDefault("weekday_type", request.getSession().getAttribute("lang").toString()));
		data.setFontList(DisposalCode.getCodeNoDefault("disp_color", request.getSession().getAttribute("lang").toString()));
		return "success";
	}
	
	
	/**
     * Description :编辑引导屏计划．
     * @throws :Exception
     */
	@Action(value="edit",results={@Result(name="success",location="/task_screen/edit.jsp")})
	public String edit(){
		//设置多语言
		setLang(data);
		data.setLang(this.request.getSession().getAttribute("lang").toString());
		taskScreenService.get_screenTask(data);
		
		
		String arg[] = new String[1];
		arg[0]="0";
		data.setMoveList(DisposalCode.getCode("move", request.getSession().getAttribute("lang").toString()));
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("screen_task_type", request.getSession().getAttribute("lang").toString()));
		data.setWeekDayList(DisposalCode.getCodeNoDefault("weekday_type", request.getSession().getAttribute("lang").toString()));
		data.setFontList(DisposalCode.getCodeNoDefault("disp_color", request.getSession().getAttribute("lang").toString()));
		//周几执行
//		this.request.setAttribute("screen_task_type", DisposalCode.getJsonCodeCheck("task_type","type",arg,request.getSession().getAttribute("lang").toString()));
		
		//周几执行
//		this.request.setAttribute("weekDay", DisposalCode.getJsonCodeCheck("weekday_type","weekDay",null,request.getSession().getAttribute("lang").toString()));
//		//车位类型
//		this.request.setAttribute("actNewType", DisposalCode.getJsonCode("parking_type",request.getSession().getAttribute("lang").toString()));
//		
//		//字体类型
//		this.request.setAttribute("fontColor", DisposalCode.getJsonCode("font_color",request.getSession().getAttribute("lang").toString()));
		return "success";
	}
	
	/**
     * Description :保存引导屏计划．
     * @throws :Exception
     */
	@Action(value="save",results={@Result(type="json")})
	public void save(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskScreenService.screen_save_plan(data);
			
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :获取地图的屏信息．
     * @throws :Exception
     */
	@Action(value="get_screen_all",results={@Result(type="json")})
	public void get_screen_all(){
		JSONObject json =  new JSONObject();
		String parameter = request.getParameter("map_id");
		try{
			json.element("data", taskScreenService.get_screen_all(parameter));
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	
	/**
     * Description :更新引导屏计划．
     * @throws :Exception
     */
	@Action(value="update",results={@Result(type="json")})
	public void update(){
		JSONObject json =  new JSONObject();
		
		try{
			taskScreenService.screenWork_update(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}
	
	/**
     * Description :删除引导屏计划．
     * @throws :Exception
     */
	@Action(value="delete",results={@Result(type="json")})
	public void delete(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskScreenService.delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}
	/**
     * Description :删除引导屏作业历史．
     * @throws :Exception
     */
	@Action(value="task_history_delete",results={@Result(type="json")})
	public void task_history_delete(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskScreenService.task_history_delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}
	
	/**
     * Description :终止引导屏计划．
     * @throws :Exception
     */
	@Action(value="terminate",results={@Result(type="json")})
	public void terminate(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskScreenService.terminate_update(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}
	
	
}
