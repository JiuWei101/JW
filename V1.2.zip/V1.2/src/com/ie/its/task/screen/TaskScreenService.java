/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.task.screen;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendRowMapperObj;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.task.parking.TaskParkingData;
@Scope("prototype")
@Service
public class TaskScreenService extends ExtendService {
	private TaskScreenSql taskScreenSql;
	
	public TaskScreenService(){
		taskScreenSql = new TaskScreenSql();
	}


	/**
     * Description :查询屏作业．
     * @param  :MapManageData
     * @return :MapManageData
     * @throws :Exception
     */
	public TaskScreenData list(TaskScreenData data) {
		//获得数量
		int count = this.getJt().queryForInt(taskScreenSql.list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <TaskScreenData>rows = this.getJt().<TaskScreenData>queryForListExt(taskScreenSql.list(data, ""), 
				data.getStart(), data.getLimit(),TaskScreenData.class);
		
		//转换编码
		for(TaskScreenData tempData:rows){
			if(Util.isCon(tempData.getType())){
				tempData.setType(DisposalCode.getCodeName(tempData.getType(), "screen_task_type", this.getUserinfo().getLang()));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得车位信息．
	 * @throws UnsupportedEncodingException 
     * @throws :Exception
     */
	public JSONObject get_parking_mess(TaskScreenData data) throws UnsupportedEncodingException{
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		
		String detector[] = data.getDetector().split(",");
		ArrayList<String> parkingList = new ArrayList<String>(Arrays.asList(detector)); 
		//add by jiangyf 取消重复选择
		for(int i=0;i<parkingList.size();i++){
			for(int j=i+1;j<parkingList.size();j++){
				if (parkingList.get(j).equals(parkingList.get(i))){
					parkingList.remove(j);
					j--;
				}
			}
		}
		Log.log(data.getTaskData());
		//如果之前表格有内容  则遍历是否选择的新屏 已经存在于表格 如果存在 则不添加
		if(Util.isCon(data.getTaskData())){
			JSONArray jsonArrTable = JSONArray.fromObject(data.getTaskData());

			for(int i = 0;i < jsonArrTable.size();i++){
				JSONArray temp = jsonArrTable.getJSONArray(i);

				if(parkingList.contains(temp.getString(1))){
					parkingList.remove(temp.getString(1));			
				}
				
			}
		}
		
		if(parkingList.size() > 0){
			ArrayList <TaskParkingData>rows = this.getJt().<TaskParkingData>queryForListExt(taskScreenSql.get_parking_mess(parkingList),TaskParkingData.class);
			
			for(TaskParkingData tempData:rows){
				JSONArray jsonArrTemp = new JSONArray();
				
				jsonArrTemp.add(tempData.getParkingSpaceId());
				jsonArrTemp.add(tempData.getDet_code());
				jsonArrTemp.add(new String(data.getMap_name().getBytes("ISO-8859-1"),"utf-8"));
				jsonArrTemp.add(tempData.getRegion());
				jsonArrTemp.add(tempData.getParking_code());
				
				
				jsonArr.add(jsonArrTemp);
			}
		}
		Log.log(jsonArr);
		json.element("data", jsonArr);
		json.element("success", true);
		return json;
	}
	
	/**
     * Description :获得屏信息．
	 * @throws UnsupportedEncodingException 
     * @throws :Exception
     */
	public JSONObject get_screen_mess(TaskScreenData data) throws UnsupportedEncodingException{
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		String screen[] = data.getScreen_code().split(",");
		ArrayList<String> screenList = new ArrayList<String>(Arrays.asList(screen)); 
		
		//如果之前表格有内容  则遍历是否选择的新屏 已经存在于表格 如果存在 则不添加
		if(Util.isCon(data.getTaskData())){
			JSONArray jsonArrTable = JSONArray.fromObject(data.getTaskData());

			for(int i = 0;i < jsonArrTable.size();i++){
				JSONArray temp = jsonArrTable.getJSONArray(i);

				if(screenList.contains(temp.getString(1))){
					screenList.remove(temp.getString(1));			
				}
				
			}
		}
		
		//经过过滤后的选择内容 如果还存在 则查询并传回页面
		if(screenList.size() > 0){
			ArrayList <TaskScreenData>rows = this.getJt().<TaskScreenData>queryForListExt(taskScreenSql.get_screen_mess(screenList),TaskScreenData.class);
			
			for(TaskScreenData tempData:rows){
				JSONArray jsonArrTemp = new JSONArray();
				
				jsonArrTemp.add(tempData.getId());
				jsonArrTemp.add(tempData.getScreen_code());
				jsonArrTemp.add(new String(data.getMap_name().getBytes("ISO-8859-1"),"utf-8"));
				
				jsonArr.add(jsonArrTemp);
			}
		}

		json.element("data", jsonArr);
		
		json.element("success", true);
		return json;
	}
	/**
     * Description :删除引导屏作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData delete(TaskScreenData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = taskScreenSql.delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :删除引导屏作业历史．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData task_history_delete(TaskScreenData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = taskScreenSql.task_history_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :获得屏id．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData get_screenId(TaskScreenData data) {
		JSONArray jsonArr = JSONArray.fromObject(data.getTaskData());
		List list = new ArrayList();
		
		
	
		for(int i = 0;i < jsonArr.size();i++){
			TaskScreenData tempData = new TaskScreenData();
			JSONArray jsonArrTemp = jsonArr.getJSONArray(i);
			
			tempData.setScreenId(jsonArrTemp.getString(0));
			tempData.setScreen_code(jsonArrTemp.getString(1));
			tempData.setMap_name(jsonArrTemp.getString(2));
			
			list.add(tempData);
		}

		data.setPer_data(list);
		
		return data;
	}
	
	/**
     * Description :获得屏作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData get_screenTask(TaskScreenData data) {
		getJt().queryForObjectExt(taskScreenSql.get_screenTask(data), data);
		//getJt().queryForObjectExt(taskScreenSql.getScreenMove(data), data);
		//转换编码taskScreenSql
		
		System.out.println("ddddddddddd:  "+data.getSwitchGap());
		System.out.println("getTimeOut:  "+data.getTimeOut());
		if(Util.isCon(data.getWeekDay())){
			data.setWeekDayArr(data.getWeekDay().split(","));
		}
		
		return data;
	}
	
	/**
     * Description :保存屏作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData screen_save_plan(TaskScreenData data) {
		JSONArray jsonArr = JSONArray.fromObject(data.getTaskData());
		String [] sql = new String[jsonArr.size()];
		
		for(int i = 0;i < jsonArr.size();i++){
			JSONArray temp = jsonArr.getJSONArray(i);
			Log.log(temp.get(0));
			data.setId(PrimaryId.getId());								//主键
			data.setScreenId(temp.getString(0));
			sql[i] = taskScreenSql.save(data);
//			if(Util.isCon(data.getMoveMethod()))
//				getJt().update(taskScreenSql.updateScreenMove(data));
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	

	/**
     * Description :更新屏作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public void screenWork_update(TaskScreenData data) {
		getJt().execute(taskScreenSql.update(data));
		//if(Util.isCon(data.getMoveMethod()))
			//getJt().update(taskScreenSql.updateScreenMove(data));
	}


	/**查询屏历史
	 * @param data
	 * @return
	 */
	public TaskScreenData list_history(TaskScreenData data) {
		//获得数量
		int count = this.getJt().queryForInt(taskScreenSql.list_history(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <TaskScreenData>rows = this.getJt().<TaskScreenData>queryForListExt(taskScreenSql.list_history(data, ""), 
				data.getStart(), data.getLimit(),TaskScreenData.class);
		
		//转换编码
		for(TaskScreenData tempData:rows){
			if(Util.isCon(tempData.getType())){
				tempData.setType(DisposalCode.getCodeName(tempData.getType(), "screen_task_type", this.getUserinfo().getLang()));
			}
			if(Util.isCon(tempData.getSuccess())){
				tempData.setSuccess(DisposalCode.getCodeName(tempData.getSuccess(), "success", this.getUserinfo().getLang()));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}


	/**
	 * @param parameter
	 * @return
	 */
	public JSONArray get_screen_all(String parameter) {
		JSONArray queryForJSONArrayExt = this.getJt().queryForJSONArrayExt(taskScreenSql.queryScreen(parameter));
		return queryForJSONArrayExt;
	}
	
	/**
     * Description :终止引导屏作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskScreenData terminate_update(TaskScreenData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = taskScreenSql.terminate(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}


}
