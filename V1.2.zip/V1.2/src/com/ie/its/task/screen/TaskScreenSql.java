package com.ie.its.task.screen;

import static com.ie.common.Util.*;

import java.util.ArrayList;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.task.parking.TaskParkingData;

public class TaskScreenSql extends ExtendSql{
	/**
     * Description :查询屏计划历史．
     * @param  :MapManageData,String
     * @return :String
     */
	public String list(TaskScreenData data, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  task.id,task.screenId,task.type,task.weekDay,task.content,task.runstate,task.forceTerminateFlag,";
			querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
			querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate,";
			querySql += "date_format(announceDate,'%Y-%m-%d %H:%i') as announceDate,";
			querySql += "map.number as map_number,map.name as map_name,screen.code as screen_code ";
		}
		
		querySql += " from p_screentask task,p_screen screen,p_map map ";
		querySql += " where task.screenId=screen.id and screen.mapId= map.id";
		querySql += " and task.forceTerminateFlag<>'1' ";
		if(Util.isCon(data.getType())){
			querySql += " and task.type= " + Util.toSqlVal(data.getType());
		}
		
		if(Util.isCon(data.getScreen_code())){
			querySql += " and screen.code like " + Util.toSqlValLike(data.getScreen_code(),"ALL");
		}
		
		if(Util.isCon(data.getStartDate())){
			querySql += " and startDate >=" + Util.toSqlVal(data.getStartDate());
		}
		
		if(Util.isCon(data.getEndDate())){
			querySql += " and endDate <=" + Util.toSqlVal(data.getEndDate());
		}
		
		Log.log(querySql);
		return querySql;
	}
	
	/**
     * Description :获得车位信息．
     * @param  :MapManageData,String
     * @return :String
     */
	public String get_parking_mess(ArrayList parkingList) {
		String querySql = "";
		
		querySql += "select  de.code as det_code,park.code as parking_code,lg.code as region"  ;
		querySql += ",park.id as parkingSpaceId"  ;
		querySql += " from p_detector de,p_parkingspace park left join p_logicregion lg on  park.logicId = lg.id"  ;
		querySql += " where park.detectorId=de.id  "  ;
		
		querySql += " and de.code in " + this.getInCond(parkingList);
		
		return querySql;
	}
	
	/**
     * Description :获得屏信息．
     * @param  :MapManageData,String
     * @return :String
     */
	public String get_screen_mess(ArrayList screenList) {
		String querySql = "";
		
		querySql += "select  id,code as screen_code from p_screen where code in " + this.getInCond(screenList);

		
		return querySql;
	}
	/**
     * Description :删除引导屏计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screentask where id= " + Util.toSqlVal(id);
		
		return deleteSql;
	}
	/**
     * Description :删除引导屏作业历史．
     * @param  :MapManageData,String
     * @return :String
     */
	public String task_history_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screentaskhistory where id= " + Util.toSqlVal(id);
		
		return deleteSql;
	}
	/**
     * Description :获得引导屏id．
     * @param  :MapManageData,String
     * @return :String
     */
	public String get_screenId(String code,String mapId) {
		String querySql = "";
		
		querySql += "select id as screenId from p_screen where code= " + Util.toSqlVal(code);
		querySql += " and mapId = " + Util.toSqlVal(mapId);
		
		return querySql;
	}
	
	/**
     * Description :获得引导屏计划信息．
     * @param  :MapManageData,String
     * @return :String
     */
	public String get_screenTask(TaskScreenData data) {
		String querySql = "";
		
		querySql += "select id,screenId,type,weekDay,timeOut,switchGap,content,notes,moveMethod,moveSpeed,moveWidth,";
		querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
		querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate ";
		querySql += " from p_screentask where id= " + Util.toSqlVal(data.getId());
		Log.log(querySql);
		return querySql;
	}
	
	/**
     * Description :保存屏作业计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String save(TaskScreenData data) {
		String insertSql = "";
		//2012-02-29 modify by jl 去掉状态1的写入 吕姐说在表中加默认值
		insertSql += "insert into p_screentask(id,screenId,type,weekDay,startDate,endDate,timeOut,content,announceDate,runState,notes,SwitchGap,moveMethod,moveSpeed,moveWidth) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getScreenId()) + ",";
		insertSql += Util.toSqlVal(data.getType()) + ",";
		insertSql += Util.toSqlVal(data.getWeekDay()) + ",";
		
		if(Util.isCon(data.getStartDate())){
			insertSql += Util.toSqlVal(data.getStartDate()) + ",";
		}else{
			insertSql +=  "NULL,";
		}
		
		if(Util.isCon(data.getEndDate())){
			insertSql += Util.toSqlVal(data.getEndDate()) + ",";
		}else{
			insertSql +=  "NULL,";
		}
		insertSql += data.getTimeOut() + ",";
		insertSql += Util.toSqlVal(data.getContent()) + ",";
		insertSql += "current_timestamp(),'0',";			//当前日期
		insertSql += Util.toSqlVal(data.getNotes()) + ",";
		insertSql += Util.toSqlVal(data.getSwitchGap()) + ",";
		insertSql += Util.toSqlVal(data.getMoveMethod()) + ",";
		insertSql += Util.toSqlVal(data.getMoveSpeed()) + ",";
		insertSql += Util.toSqlVal(data.getMoveWidth()) + ")";
		Log.log(insertSql);
		return insertSql;
	}
	
	
	/**
     * Description :更新屏作业计划．
     * @param  :MapManageData
     * @return :String
     */
	public String update(TaskScreenData data) {
		String updateSql = "";
		
		updateSql += "update p_screentask set type=";
		updateSql += Util.toSqlVal(data.getType());
		updateSql += ",weekDay=" + Util.toSqlVal(data.getWeekDay());
		
		if(Util.isCon(data.getStartDate())){
			updateSql += ",startDate=" + Util.toSqlVal(data.getStartDate());
		}else{
			updateSql +=  ",startDate=NULL";
		}
		if (data.getEndDate().equalsIgnoreCase("")){
		  updateSql += ",endDate=NULL";
		}else {
		  updateSql += ",endDate=" + Util.toSqlVal(data.getEndDate());	
		}
		updateSql += ",timeOut=" + data.getTimeOut();
		updateSql += ",content=" + Util.toSqlVal(data.getContent());
		updateSql += ",notes=" + Util.toSqlVal(data.getNotes());
		updateSql += ",SwitchGap=" + data.getSwitchGap();
		updateSql += ",moveMethod=" + Util.toSqlVal(data.getMoveMethod());
		updateSql += ",moveSpeed=" + Util.toSqlVal(data.getMoveSpeed());
		updateSql += ",moveWidth=" + Util.toSqlVal(data.getMoveWidth());
		updateSql += " where id = " + Util.toSqlVal(data.getId());
		
		Log.log(updateSql);
		
		return updateSql;
	}

	/**
	 * @param data
	 * @param type
	 * @return
	 */
	public String list_history(TaskScreenData data, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  task.id,task.screenId,task.type,task.weekDay,task.content,task.success,";
			querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
			querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate,";
			querySql += "date_format(announceDate,'%Y-%m-%d %H:%i') as announceDate,";
			querySql += "map.number as map_number,map.name as map_name,screen.code as screen_code ";
		}
		
		querySql += " from p_screentaskhistory task,p_screen screen,p_map map ";
		querySql += " where task.screenId=screen.id and screen.mapId= map.id";
		
		if(Util.isCon(data.getType())){
			querySql += " and task.type= " + Util.toSqlVal(data.getType());
		}
		
		if(Util.isCon(data.getScreen_code())){
			querySql += " and screen.code like " + Util.toSqlValLike(data.getScreen_code(),"ALL");
		}
		
		if(Util.isCon(data.getStartDate())){
			querySql += " and startDate >=" + Util.toSqlVal(data.getStartDate());
		}
		
		if(Util.isCon(data.getEndDate())){
			querySql += " and endDate <=" + Util.toSqlVal(data.getEndDate());
		}
		
		Log.log("------"+querySql);
		return querySql;
	}

	public String queryScreen(String parameter) {
		String querySql = "select p.id,p.code,m.name from p_screen p"
			+ " inner join p_map m on m.id = p.mapId "
			+ " where mapId = " + toSqlVal(parameter);
		return querySql;
	}

	public String updateScreenMove(TaskScreenData data) {
		String updateSql = "update p_screenparavalue set value = " + toSqlVal(data.getMoveMethod()) 
			+ " where 1=1 ";
		if(Util.isCon(data.getScreenId())){
			updateSql += " and screenid = " + toSqlVal(data.getScreenId()) ;
		}else{
			updateSql += " and screenid = (select screenId from p_screentask ";
			updateSql += " where id = " + toSqlVal(data.getId()) + ")";
		}
		
		updateSql += " and screenTypeParaId in (select id from p_screentypepara where name = '显示方式')";
		System.out.println(updateSql);
		return updateSql;
	}

	public String getScreenMove(TaskScreenData data) {
		String querySql = "select value as moveMethod from p_screenparavalue where screenid = "
			+ toSqlVal(data.getScreenId()) + " and screenTypeParaId in "
			+ " (select id from p_screentypepara where name = '显示方式')";
		return querySql;
	}
	
	/**
     * Description :终止引导屏计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String terminate(String id) {
		String terminateSql = "";
		
		terminateSql += " update p_screentask set forceTerminateFlag='1',runState='1' where id= " + Util.toSqlVal(id);
		
		return terminateSql;
	}
	
}
