/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.task.screen;

import java.util.List;

import com.ie.frame.ExtendData;

public class TaskScreenData extends ExtendData{
	private String screenId;			//引导屏id
	private String screenCode;			//屏编号
	private String type;				//执行类型
	private String weekDay;				//每周星期
	private String startDate;			//开始时间
	private String endDate;				//结束时间
	private int timeOut;				//超时
	private String content;				//发布内容
	private String announceDate;		//发布时间
	private String notes;				//备注
	private String detector;			//作业计划的时候 前台传过来的探测器code集合
	private String fontColor;			//字体颜色
	private String map_name;			//地图名
	private String success;
	private String moveMethod;
	private String SwitchGap;           //切换间隔
	private String forceTerminateFlag;  //强制终止标志
	private String moveSpeed;           //移动速度
	private String moveWidth;           //显示宽度
	
	private List moveList;
	private List taskTypeList;			//
	private List weekDayList;
	private List fontList;	
	private List mapList;			
	public List getMapList() {
		return mapList;
	}
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	private String []weekDayArr;		
	
	public String[] getWeekDayArr() {
		return weekDayArr;
	}
	public void setWeekDayArr(String[] weekDayArr) {
		this.weekDayArr = weekDayArr;
	}
	public List getFontList() {
		return fontList;
	}
	public void setFontList(List fontList) {
		this.fontList = fontList;
	}
	public String getScreenCode() {
		return screenCode;
	}
	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}
	public List getWeekDayList() {
		return weekDayList;
	}
	public void setWeekDayList(List weekDayList) {
		this.weekDayList = weekDayList;
	}
	public List getTaskTypeList() {
		return taskTypeList;
	}
	public void setTaskTypeList(List taskTypeList) {
		this.taskTypeList = taskTypeList;
	}
	public String getMap_name() {
		return map_name;
	}
	public void setMap_name(String map_name) {
		this.map_name = map_name;
	}
	public String getFontColor() {
		return fontColor;
	}
	public void setFontColor(String fontColor) {
		this.fontColor = fontColor;
	}
	private String map_number;			//地图号
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	private String screen_code;			//引导屏编号
	private String taskData;			
	private String mapId;				//地图id
	public String getTaskData() {
		return taskData;
	}
	public void setTaskData(String taskData) {
		this.taskData = taskData;
	}
	public String getMap_number() {
		return map_number;
	}
	public void setMap_number(String map_number) {
		this.map_number = map_number;
	}
	public String getScreen_code() {
		return screen_code;
	}
	public void setScreen_code(String screen_code) {
		this.screen_code = screen_code;
	}
	public String getScreenId() {
		return screenId;
	}
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public String getWeekDay() {
		return weekDay;
	}
	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {  
		 
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAnnounceDate() {
		return announceDate;
	}
	public void setAnnounceDate(String announceDate) {
		this.announceDate = announceDate;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String note) {
		this.notes = note;
	}
	public String getDetector() {
		return detector;
	}
	public void setDetector(String detector) {
		this.detector = detector;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public List getMoveList() {
		return moveList;
	}
	public void setMoveList(List moveList) {
		this.moveList = moveList;
	}
	public String getMoveMethod() {
		return moveMethod;
	}
	public void setMoveMethod(String moveMethod) {
		this.moveMethod = moveMethod;
	}
	public String getSwitchGap() {
		return this.SwitchGap;
	}
	public void setSwitchGap(String SwitchGap) {
		this.SwitchGap = SwitchGap;
	}
	public String getForceTerminateFlag() {
		return forceTerminateFlag;
	}
	public void setForceTerminateFlag(String forceTerminateFlag) {
		this.forceTerminateFlag = forceTerminateFlag;
	}
	public String getMoveSpeed() {
		return moveSpeed;
	}
	public void setMoveSpeed(String moveSpeed) {
		this.moveSpeed = moveSpeed;
	}
	public String getMoveWidth() {
		return moveWidth;
	}
	public void setMoveWidth(String moveWidth) {
		this.moveWidth = moveWidth;
	}
	
	
	
}
