/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.task.parking;

import java.util.List;

import com.ie.frame.ExtendData;

public class TaskParkingData extends ExtendData{
	private String parkingSpaceId;			//车位id
	private String type;				//执行类型
	private String actNewType;			//动作
	private String weekDay;				//每周星期
	private String startDate;			//开始时间
	private String endDate;				//结束时间
	private int timeOut;				//超时
	private String content;				//发布内容
	private String guide_name;			//引导区域
	
	private String announceDate;		//发布时间
	private String notes;				//备注
	private String mapId;				//
	
	private String map_number;			//地图号
	private String map_name;			//地图名
	private String screen_code;			//引导屏编号
	private String taskData;			//将列表信息传入到明细页面载体
	private String det_code;			//探测器表编号
	private String map_id;						//地图id
	private String region;		
	private String parking_code;
	private String success;
	private String dtc_model;		//探头模式
	private List dtcModelList;		//探头模式列表
	
	public String getDtc_model() {
		return dtc_model;
	}
	public void setDtc_model(String dtc_model) {
		this.dtc_model = dtc_model;
	}
	public List getDtcModelList() {
		return dtcModelList;
	}
	public void setDtcModelList(List dtcModelList) {
		this.dtcModelList = dtcModelList;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getParking_code() {
		return parking_code;
	}
	public void setParking_code(String parking_code) {
		this.parking_code = parking_code;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getMap_id() {
		return map_id;
	}
	public void setMap_id(String map_id) {
		this.map_id = map_id;
	}
	private List taskTypeList;			//
	private List weekDayList;
	private List actNewTypeList;	
	public List getActNewTypeList() {
		return actNewTypeList;
	}
	public void setActNewTypeList(List actNewTypeList) {
		this.actNewTypeList = actNewTypeList;
	}
	public List getTaskTypeList() {
		return taskTypeList;
	}
	public void setTaskTypeList(List taskTypeList) {
		this.taskTypeList = taskTypeList;
	}
	public List getWeekDayList() {
		return weekDayList;
	}
	public void setWeekDayList(List weekDayList) {
		this.weekDayList = weekDayList;
	}
	public String[] getWeekDayArr() {
		return weekDayArr;
	}
	public void setWeekDayArr(String[] weekDayArr) {
		this.weekDayArr = weekDayArr;
	}
	private String []weekDayArr;	
	
	public String getGuide_name() {
		return guide_name;
	}
	public void setGuide_name(String guide_name) {
		this.guide_name = guide_name;
	}
	public String getDet_code() {
		return det_code;
	}
	public void setDet_code(String det_code) {
		this.det_code = det_code;
	}
	public String getTaskData() {
		return taskData;
	}
	public void setTaskData(String taskData) {
		this.taskData = taskData;
	}
	public String getMap_number() {
		return map_number;
	}
	public String getActNewType() {
		return actNewType;
	}
	public void setActNewType(String actNewType) {
		this.actNewType = actNewType;
	}
	public void setMap_number(String map_number) {
		this.map_number = map_number;
	}
	public String getScreen_code() {
		return screen_code;
	}
	public void setScreen_code(String screen_code) {
		this.screen_code = screen_code;
	}

	public String getParkingSpaceId() {
		return parkingSpaceId;
	}
	public void setParkingSpaceId(String parkingSpaceId) {
		this.parkingSpaceId = parkingSpaceId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getWeekDay() {
		return weekDay;
	}
	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAnnounceDate() {
		return announceDate;
	}
	public void setAnnounceDate(String announceDate) {
		this.announceDate = announceDate;
	}
	public String getNotes() {
		return notes;
	}
	public String getMap_name() {
		return map_name;
	}
	public void setMap_name(String map_name) {
		this.map_name = map_name;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
}
