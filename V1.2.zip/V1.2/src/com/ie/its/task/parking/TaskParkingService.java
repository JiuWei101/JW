/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.task.parking;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendRowMapperObj;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.task.screen.TaskScreenData;
@Scope("prototype")
@Service
public class TaskParkingService extends ExtendService {
	private TaskParkingSql taskParkingSql;
	
	public TaskParkingService(){
		taskParkingSql = new TaskParkingSql();
	}


	/**
     * Description :查询车位作业．
     * @param  :MapManageData
     * @return :MapManageData
     * @throws :Exception
     */
	public TaskParkingData list(TaskParkingData data) {
		//获得数量
		int count = this.getJt().queryForInt(taskParkingSql.list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <TaskParkingData>rows = this.getJt().<TaskParkingData>queryForListExt(taskParkingSql.list(data, ""), 
				data.getStart(), data.getLimit(),TaskParkingData.class);
		
		//转换编码
		for(TaskParkingData tempData:rows){
			if(tempData.getType().equals("6")){
				String newtype = DisposalCode.getCodeName(tempData.getActNewType(), "dtc_model", this.getUserinfo().getLang());
				String type = (String)((Map)this.getUserinfo().getCurrent_lang_switch().get("common")).get("dtcmodel_task_title");
				tempData.setType(type);
				tempData.setActNewType(newtype);
			}else{
				tempData.setType(DisposalCode.getCodeName(tempData.getType(), "task_type", this.getUserinfo().getLang()));
				tempData.setActNewType(DisposalCode.getCodeName(tempData.getActNewType(), "parking_type", this.getUserinfo().getLang()));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :删除车位作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskParkingData taskParking_delete(TaskParkingData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = taskParkingSql.delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :删除车位作业历史．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskParkingData task_history_delete(TaskParkingData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = taskParkingSql.task_history_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :保存车位作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskParkingData save_parking_plan(TaskParkingData data) {
		JSONArray jsonArr = JSONArray.fromObject(data.getTaskData());
		String [] sql = new String[jsonArr.size()];
//		Log.log(data.getTaskData());
//		for(int i = 0;i < jsonArr.size();i++){
//			JSONObject temp = jsonArr.getJSONObject(i);
//			Log.log(temp);
//			data.setId(PrimaryId.getId());								//主键
//			data.setParkingSpaceId(temp.getString("parkingSpaceId")); 	//车位id
//			
//			sql[i] = taskParkingSql.save(data);
//		}
		
		for(int i = 0;i < jsonArr.size();i++){
			JSONArray temp = jsonArr.getJSONArray(i);
			Log.log(temp);
			data.setId(PrimaryId.getId());								//主键
			data.setParkingSpaceId(temp.getString(0).substring(0, 20)); 	//车位id
			
			sql[i] = taskParkingSql.save(data);
		}
	
		getJt().batchUpdate(sql);
		return data;
	}
	/**
	 * 
	 * @param data
	 * @return
	 */
	public TaskParkingData dtcModelSave(TaskParkingData data){
		JSONArray jsonArr = JSONArray.fromObject(data.getTaskData());
		String [] sql = new String[jsonArr.size()];
		
		for(int i = 0;i < jsonArr.size();i++){
			JSONArray temp = jsonArr.getJSONArray(i);
			Log.log(temp);
			data.setId(PrimaryId.getId());								//主键
			data.setParkingSpaceId(temp.getString(0).substring(0, 20)); 	//车位id
			
			sql[i] = taskParkingSql.dtcmodelsave(data);
		}
	
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :获得车位作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskParkingData get_parkingTask(TaskParkingData data) {
//		JSONObject json = new JSONObject();
//		json = getJt().queryForJSONArrayExt(taskParkingSql.get_parkingTask(data)).getJSONObject(0);
		getJt().queryForObjectExt(taskParkingSql.get_parkingTask(data), data);
		//转换编码taskScreenSql
		if(Util.isCon(data.getWeekDay())){
			data.setWeekDayArr(data.getWeekDay().split(","));
		}
		return data;
	}
	
	
	/**
     * Description :更新车位作业计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public void parking_update_plan(TaskParkingData data) {
		getJt().execute(taskParkingSql.update(data));
	}
	
	
	/**
     * Description :获得车位信息 用于新建计划．
     * @param  :TaskScreenData
     * @return :TaskScreenData
     * @throws :Exception
     */
	public TaskParkingData get_parkingAll(TaskParkingData data) {
		JSONArray jsonArr = JSONArray.fromObject(data.getTaskData());
		List list = new ArrayList();
		
		
		for(int i = 0;i < jsonArr.size();i++){
			JSONArray jsonArrTemp = jsonArr.getJSONArray(i);
			TaskParkingData tempData = new TaskParkingData();
			
			tempData.setParkingSpaceId(jsonArrTemp.getString(0));
			tempData.setDet_code(jsonArrTemp.getString(1));
			tempData.setMap_name(jsonArrTemp.getString(2));
			tempData.setRegion(jsonArrTemp.getString(3));
			tempData.setParking_code(jsonArrTemp.getString(4));
			
			list.add(tempData);
		}
		
		
	
		data.setPer_data(list);
		
		return data;
	}
	
	/**车位历史作业查询
	 * @param data
	 * @return
	 */
	public TaskParkingData list_history(TaskParkingData data) {
		//获得数量
		int count = this.getJt().queryForInt(taskParkingSql.list_history(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <TaskParkingData>rows = this.getJt().<TaskParkingData>queryForListExt(taskParkingSql.list_history(data, ""), 
				data.getStart(), data.getLimit(),TaskParkingData.class);
		
		//转换编码
		for(TaskParkingData tempData:rows){
			if(tempData.getType().equals("6")){
				String newtype = DisposalCode.getCodeName(tempData.getActNewType(), "dtc_model", this.getUserinfo().getLang());
				String type = (String)((Map)this.getUserinfo().getCurrent_lang_switch().get("common")).get("dtcmodel_task_title");
				tempData.setType(type);
				tempData.setActNewType(newtype);
			}else{
				tempData.setType(DisposalCode.getCodeName(tempData.getType(), "task_type", this.getUserinfo().getLang()));
				tempData.setActNewType(DisposalCode.getCodeName(tempData.getActNewType(), "parking_type", this.getUserinfo().getLang()));
			}
			if(Util.isCon(tempData.getSuccess())){
				tempData.setSuccess(DisposalCode.getCodeName(tempData.getSuccess(), "success", this.getUserinfo().getLang()));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}

}
