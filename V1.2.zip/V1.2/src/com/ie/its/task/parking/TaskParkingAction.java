/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 地图管理
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.task.parking;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;

//命名空间
@Namespace("/task_parking")
@Results({@Result(name="list",location="/task_parking/parking_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="parking_list",location="list.action",type="redirect")})
public class TaskParkingAction extends ExtendActionSupport {
	
	private TaskParkingData data;
	@Autowired
	private TaskParkingService taskParkingService;
	
	
	public TaskParkingData getData() {
		return data;
	}
	public void setData(TaskParkingData data) {
		this.data = data;
	}
	public TaskParkingAction(){
		if(data == null){
			data = new TaskParkingData();
		}
	}
	
	/**
     * Description :查询车位计划．
     * @throws :Exception
     */
	@Action(value="list",results={@Result(name="success",location="/task_parking/parking_list.jsp")})
	public String list(){
		data = taskParkingService.list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("task_type", request.getSession().getAttribute("lang").toString()));
		data.setDtcModelList(Util.getCodeList(data, "dtc_model"));
		return "success";
	}
	
	/**
     * Description :查询车位历史．
     * @throws :Exception
     */
	@Action(value="history",results={@Result(name="success",location="/task_parking/parking_history.jsp")})
	public String history(){
		data = taskParkingService.list_history(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("task_type", request.getSession().getAttribute("lang").toString()));
		return "success";
	}
	
	/**
     * Description :新建车位计划．
     * @throws :Exception
     */
	@Action(value="create",results={@Result(name="success",location="/task_parking/create.jsp")})
	public String create(){
		Log.log(data.getTaskData());
		
		taskParkingService.get_parkingAll(data);
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		data.setTimeOut(10);
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("task_type", request.getSession().getAttribute("lang").toString()));
		data.setWeekDayList(DisposalCode.getCodeNoDefault("weekday_type", request.getSession().getAttribute("lang").toString()));
		data.setActNewTypeList(DisposalCode.getCodeNoDefault("parking_type", request.getSession().getAttribute("lang").toString()));
		data.setDtcModelList(Util.getCodeList(data, "dtc_model"));
		
		//code_name暂时存储是否为超级用户登陆
		data.setCode_name(this.request.getSession().getAttribute("isSuper").toString());
//		
//		String arg[] = new String[1];
//		arg[0]="0";
//		
//		//周几执行
//		this.request.setAttribute("task_type", DisposalCode.getJsonCodeCheck("task_type","type",arg,request.getSession().getAttribute("lang").toString()));
//		
//		//周几执行
//		this.request.setAttribute("weekDay", DisposalCode.getJsonCodeCheck("weekday_type","weekDay",null,request.getSession().getAttribute("lang").toString()));
//		//车位类型
//		this.request.setAttribute("actNewType", DisposalCode.getJsonCode("parking_type",request.getSession().getAttribute("lang").toString()));
		return "success";
	}
	/**
	 * 
	 */
	@Action(value="dtcmodel_save",results={@Result(type="json")})
	public void dtcmodel_save(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskParkingService.dtcModelSave(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :保存车位计划．
     * @throws :Exception
     */
	@Action(value="save",results={@Result(type="json")})
	public void save(){
		JSONObject json =  new JSONObject();
		
		try{
			data = taskParkingService.save_parking_plan(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :编辑车位计划．
     * @throws :Exception
     */
	@Action(value="edit",results={@Result(name="success",location="/task_parking/edit.jsp")})
	public String edit(){
		Log.log(data.getTaskData());
		
		data = taskParkingService.get_parkingTask(data);
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		//this.request.setAttribute("mess", taskParkingService.get_parkingTask(data));
		
		
		data.setTaskTypeList(DisposalCode.getCodeNoDefault("task_type", request.getSession().getAttribute("lang").toString()));
		data.setWeekDayList(DisposalCode.getCodeNoDefault("weekday_type", request.getSession().getAttribute("lang").toString()));
		data.setActNewTypeList(DisposalCode.getCodeNoDefault("parking_type", request.getSession().getAttribute("lang").toString()));
		return "success";
	}
	
	/***
	 * 更新车位作业之前先判断作业类型
	 */
	@Action(value="before_edit",results={@Result(type="json")})
	public void beforeEdit(){
		JSONObject obj = new JSONObject();
		try{
			data = taskParkingService.get_parkingTask(data);
			obj.element("success", true);
			if(data.getActNewType().equals("3") || data.getActNewType().equals("4")){
				//data.setDtc_model(data.getActNewType());
				obj.element("type", true);
				obj.element("current_model", data.getActNewType());
			}else{
				obj.element("type", false);
			}
		}catch(Exception e){
			obj.element("success", false);
		}
		setJsonRes(obj);
	}
	/**
     * Description :更新车位计划．
     * @throws :Exception
     */
	@Action(value="update",results={@Result(type="json")})
	public void update(){
		JSONObject json =  new JSONObject();
		
		try{
			taskParkingService.parking_update_plan(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :删除车位计划．
     * @throws :Exception
     */
	@Action(value="delete",results={@Result(type="json")})
	public void delete(){		
		JSONObject json =  new JSONObject();
		
		try{
			data = taskParkingService.taskParking_delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	/**
     * Description :删除车位计划历史．
     * @throws :Exception
     */
	@Action(value="task_history_delete",results={@Result(type="json")})
	public void task_history_delete(){		
		JSONObject json =  new JSONObject();
		
		try{
			data = taskParkingService.task_history_delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
}
