package com.ie.its.task.parking;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.task.screen.TaskScreenData;

public class TaskParkingSql extends ExtendSql{
	/**
     * Description :查询车位作业计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String list(TaskParkingData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select task.id,task.parkingSpaceId,task.actNewType,task.type,task.weekDay,";
			querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
			querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate,";
			querySql += "task.timeOut,task.runState,det.code as det_code,map.number as map_number,map.name as map_name,guide.name as guide_name";
		}
		
		querySql += " from p_parkingspacetask task,p_parkingspace parking,p_map map,p_detector det left join p_guideregion guide on det.guideRegionId=guide.id";
		querySql += " where task.parkingSpaceId=parking.id and parking.detectorId= det.id and det.mapId=map.id ";
		
		
		if(Util.isCon(data.getType())){
			querySql += " and task.type= " + Util.toSqlVal(data.getType());
		}
		
		if(Util.isCon(data.getDet_code())){
			querySql += " and det.code like " + Util.toSqlValLike(data.getDet_code(),"ALL");
		}
		
		if(Util.isCon(data.getStartDate())){
			querySql += " and startDate >=" + Util.toSqlVal(data.getStartDate());
		}
		
		if(Util.isCon(data.getEndDate())){
			querySql += " and endDate <=" + Util.toSqlVal(data.getEndDate());
		}
		Log.log(querySql);
		return querySql;
	}
	
	/**
     * Description :删除车位作业计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_parkingspacetask where id= " + Util.toSqlVal(id);
		
		return deleteSql;
	}
	/**
     * Description :删除车位作业历史．
     * @param  :MapManageData,String
     * @return :String
     */
	public String task_history_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_parkingspacetaskhistory where id= " + Util.toSqlVal(id);
		
		return deleteSql;
	}
	
	/**
     * Description :保存车位作业计划．
     * @param  :MapManageData,String
     * @return :String
     */
	public String save(TaskParkingData data) {
		String insertSql = "";
		
		insertSql += "insert into p_parkingspacetask(id,parkingSpaceId,actNewType,type,weekDay,startDate,endDate,timeOut,runstate,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getParkingSpaceId()) + ",";
		insertSql += Util.toSqlVal(data.getActNewType()) + ",";
		insertSql += Util.toSqlVal(data.getType()) + ",";
		insertSql += Util.toSqlVal(data.getWeekDay()) + ",";
		
		if(Util.isCon(data.getStartDate())){
			insertSql += Util.toSqlVal(data.getStartDate()) + ",";
		}else{
			insertSql +=  "NULL,";
		}
		
		if(Util.isCon(data.getEndDate())){
			insertSql += Util.toSqlVal(data.getEndDate()) + ",";
		}else{
			insertSql +=  "NULL,";
		}
		
		insertSql += data.getTimeOut() + ",'0',";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		Log.log(insertSql);
		return insertSql;
	}
	/**
	 * 存储探测器模式作业
	 * @param data
	 * @return
	 */
	public String dtcmodelsave(TaskParkingData data){
		String insertSql = "";
		
		insertSql += "insert into p_parkingspacetask(id,parkingSpaceId,actNewType,type,weekDay,startDate,endDate,timeOut,runstate,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getParkingSpaceId()) + ",";
		insertSql += Util.toSqlVal(data.getDtc_model()) + ",";
		insertSql += " '6',";
		insertSql += " NULL,";
		insertSql += " NULL,";
		insertSql += " NULL,";
		insertSql += Util.toSqlVal(data.getTimeOut()) + ",'0',";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		Log.log(insertSql);
		return insertSql;
	}
	
	/**
     * Description :获得车位计划信息．
     * @param  :MapManageData,String
     * @return :String
     */
	public String get_parkingTask(TaskParkingData data) {
		String querySql = "";
		
		querySql += "select id,parkingSpaceId,type,weekDay,timeOut,actNewType,notes,";
		querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
		querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate ";
		querySql += " from p_parkingspacetask where id= " + Util.toSqlVal(data.getId());
		
		return querySql;
	}
	
	/**
     * Description :更新屏作业计划．
     * @param  :MapManageData
     * @return :String
     */
	public String update(TaskParkingData data) {
		String updateSql = "";
		
		updateSql += "update p_parkingspacetask set type=";
		updateSql += Util.toSqlVal(data.getType());
		updateSql += ",weekDay=" + Util.toSqlVal(data.getWeekDay());
		
		if(Util.isCon(data.getStartDate())){
			updateSql += ",startDate=" + Util.toSqlVal(data.getStartDate());
		}else{
			updateSql += ",startDate=NULL";
		}
		
		if(Util.isCon(data.getEndDate())){
			updateSql += ",endDate=" + Util.toSqlVal(data.getEndDate());
		}else{
			updateSql += ",endDate=NULL";
		}
		
		updateSql += ",timeOut=" + data.getTimeOut();
		updateSql += ",actNewType=" + Util.toSqlVal(data.getActNewType());
		updateSql += ",notes=" + Util.toSqlVal(data.getNotes());
		updateSql += " where id = " + Util.toSqlVal(data.getId());
		
		Log.log(updateSql);
		
		return updateSql;
	}
	
	/**查询车位历史作业 added by LLX 0817
	 * @param data
	 * @param type
	 * @return
	 */
	public String list_history(TaskParkingData data, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  task.id,task.parkingSpaceId,task.type,task.weekDay,task.actNewType,task.success,";
			querySql += "date_format(startDate,'%Y-%m-%d %H:%i') as startDate,";
			querySql += "date_format(endDate,'%Y-%m-%d %H:%i') as endDate,";
			//querySql += "date_format(announceDate,'%Y-%m-%d %H:%i') as announceDate,";//车位作业计划表里没有这个字段（发布时间）
			querySql += "map.number as map_number,map.name as map_name,detector.code as det_code,guide.name as guide_name ";
		}
		
		querySql += " from p_parkingspacetaskhistory task,p_map map,p_detector detector,p_guideregion guide,p_parkingspace AS p";
		querySql += " where task.parkingSpaceId=p.id and detector.mapId= map.id and detector.guideRegionId=guide.id and p.detectorId=detector.id";
		
		if(Util.isCon(data.getType())){
			querySql += " and task.type= " + Util.toSqlVal(data.getType());
		}
		
		if(Util.isCon(data.getDet_code())){
			querySql += " and detector.code like " + Util.toSqlValLike(data.getDet_code(),"ALL");
		}
		
		if(Util.isCon(data.getStartDate())){
			querySql += " and startDate >=" + Util.toSqlVal(data.getStartDate());
		}
		
		if(Util.isCon(data.getEndDate())){
			querySql += " and endDate <=" + Util.toSqlVal(data.getEndDate());
		}
		
		Log.log("------"+querySql);
		return querySql;
	}


}
