package com.ie.its.example;

import static com.ie.common.Util.*;

import com.ie.common.OperateScList;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
public class BookSql<T> extends ExtendSql{
	/**
     * Description :查询图书．
     * @param  :book,type
     * @return :String
     */
	public String book_list(BookData book,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*) from ics_book where 1=1 ";
		}else{
			querySql += "select id,name,sale_time,img_path,type1_id,type2 from ics_book where 1=1 ";
		}
		
		
		if(isCon(book.getCxId())){
			querySql += " and id like " + toSqlValLike(book.getCxId(), "ALL");
		}
		
		if(isCon(book.getCxName())){
			querySql += " and name like " + toSqlValLike(book.getCxName(), "ALL");
		}
		
		if(!type.equals("count")){
			querySql += " order by name";
		}
		return querySql;
	}
	
	/**
     * Description :检查图书名．
     * @param  :book
     * @return :String
     */
	public String book_check(BookData book){
		String querySql = "";
		
		querySql = "select count(*) from ics_book where (name = ";
		querySql += Util.toSqlVal(book.getName());
		querySql += " or id =";
		querySql += Util.toSqlVal(book.getId()) +")";
		
		return querySql;
	}
	
	/**
     * Description :保存图书．
     * @param  :book
     * @return :String
     */
	public String book_save(BookData book){
		String insertSql = "insert into ics_book(id,name,sale_time,img_path,type1_id,type1_name,type2) values (";
		insertSql += toSqlVal(book.getId()) + ",";
		insertSql += toSqlVal(book.getName()) + ",";
		insertSql += toSqlVal(book.getSale_time()) + ",";
		insertSql += toSqlVal(book.getImg_path()) + ",";
		insertSql += toSqlVal(book.getType1_id()) + ",";
		insertSql += toSqlVal(book.getType1_id()) + ",";
		insertSql += toSqlVal(book.getType2()) + ")";
		
		return insertSql;
	}
	
	/**
     * Description :查看图书．
     * @param  :book
     * @return :String
     */
	public String book_read(BookData book){
		String querySql = "";
		
		querySql += "select id,name,sale_time,img_path,type1_id,type2 from ics_book where id= ";
		querySql += toSqlVal(book.getId()+"111");
		
		return querySql;
	}
	
	/**
     * Description :更新图书．
     * @param  :book
     * @return :String
     */
	public String book_update(BookData book){
		String updateSql = "";
		
		updateSql += "update ics_book set name = " + toSqlVal(book.getName()) + ",";
		updateSql += "sale_time=" + toSqlVal(book.getSale_time()) + ",";
		updateSql += "img_path=" + toSqlVal(book.getImg_path()) + ",";
		updateSql += "type1_id=" + toSqlVal(book.getType1_id()) + ",";
		updateSql += "type1_name=" + toSqlVal(book.getType1_id()) + ",";
		updateSql += "type2=" + toSqlVal(book.getType2()) ;
		updateSql += " where id=" + toSqlVal(book.getId());
	
		return updateSql;
	}
	
	/**
     * Description :删除图书．
     * @param  :book
     * @return :String
     */
	public String book_delete(BookData book){
		String deleteSql = "";
		
		deleteSql += "delete from  ics_book where id = " + toSqlVal(book.getId());

		return deleteSql;
	}
}
