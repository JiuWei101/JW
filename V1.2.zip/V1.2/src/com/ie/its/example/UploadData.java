/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : �ϴ��ļ������
 * Version                  : 1.0
 * create date              : 2008.8.1
 * author                   ����곬
*/

package com.ie.its.example;

public class UploadData {
	
	private String[]   myFile;               //ϴ��ļ�
	private String[]   myFileContentType;    // �ļ�����������
    private String[]   myFileFileName;       // �ϴ��ļ���

	public static void main(String[] args) {

	}

	public String[] getMyFile() {
		return myFile;
	}

	public void setMyFile(String[] myFile) {
		this.myFile = myFile;
	}

	public String[] getMyFileContentType() {
		return myFileContentType;
	}

	public void setMyFileContentType(String[] myFileContentType) {
		this.myFileContentType = myFileContentType;
	}

	public String[] getMyFileFileName() {
		return myFileFileName;
	}

	public void setMyFileFileName(String[] myFileFileName) {
		this.myFileFileName = myFileFileName;
	}

}
