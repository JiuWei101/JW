package com.ie.its.example;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.IService;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.example.UploadData;

//命名空间
@Namespace("/example")
@Results({@Result(name="list",location="book_list.action",type="redirect")})
public class BookAction extends ExtendActionSupport {
	private File myFile;// 实际上传文件
    private String myFileContentType; // 文件的内容类型
    private String myFileFileName; // 上传文件名
    private static final int BUFFER_SIZE = 16 * 1024;



	public String getMyFileContentType() {
		return myFileContentType;
	}

	public void setMyFileContentType(String myFileContentType) {
		this.myFileContentType = myFileContentType;
	}

	public String getMyFileFileName() {
		return myFileFileName;
	}

	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}

	public File getMyFile() {
		return myFile;
	}

	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}


	public BookData getBook() {
		return book;
	}

	public void setBook(BookData book) {
		this.book = book;
	}
	private BookData book;
	//自动注入service
	@Autowired
	private BookService bookService;
	private UploadData udata;

	public UploadData getUdata() {
		return udata;
	}

	public void setUdata(UploadData udata) {
		this.udata = udata;
	}

	public BookAction(){
		if(book == null){
			book = new BookData();
		}
	}
	/**
     * Description :查询图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_list",results={@Result(name="success",location="/example/book_list.jsp")})
	public String book_list() throws DataAccessException, InstantiationException, IllegalAccessException{
		book = bookService.book_list(book);
		//设置多语言
		setLang(book);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, book.getPer_data());
		return SUCCESS;
	}
	
	/**
     * Description :新建图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_create",results={@Result(name="book_create",location="/example/book_create.jsp")})
	public String book_create(){
		book.setId("");
		
		//获得编码下拉框
		book.setBooklist(DisposalCode.getCode("cdddyfs","86"));
		
		return "book_create";
	}
	
	/**
     * Description :检查图书名是否重复．
     * @param  :book
     * @return :JSONObject
     * @throws :Exception
     */
	@Action(value="book_check",results={@Result(type="json")})
	public void book_check(){
		JSONObject json =  bookService.book_check(book);
		setJsonRes(json);
	}
	
	/**
     * Description :保存图书信息．
     * @param  :book
     * @throws :Exception
     */
	//返回类型为json 并且不要有返回值 一律为void
	@Action(value="book_save",interceptorRefs={@InterceptorRef("fileUpload"),@InterceptorRef("authStack")},results={@Result(type="json")})
	public void book_save() throws DataAccessException, InstantiationException, IllegalAccessException{		
//		String[] myFile = udata.getMyFile();
//		String[] fileName = udata.getMyFileFileName();
//		String[] contentType = udata.getMyFileContentType();
//		
//		File binaryFile = new File(myFile[0]);
//		try {
//			InputStream is = new  FileInputStream(binaryFile);
//		
//		//	String name = fileName[0];       // 文件名
//			String name = fileName[0];
//			
//			String type = contentType[0];    // 文件类型
//			int size = (int)binaryFile.length();   // 文件大小
//			String newdir = request.getRealPath("/")+"upload\\";
//		//	String path = request.getContextPath();
//		//	String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";
//	//		String newdir = basePath + "upload/";
//			System.out.println(newdir);
//			if(!new File(newdir).isDirectory()){
//	            new File(newdir).mkdirs();
//	        }
//			String fname = PrimaryId.getId()+name;
//			String newname = newdir+ fname;
//			OutputStream outfile = new FileOutputStream(newname);
//			int bytes = 0;
//			byte[] readbuffer = new byte[1048576];
//            while((bytes = is.read(readbuffer, 0, 8192))!=-1){
//                outfile.write(readbuffer, 0, bytes);
//            }
//            outfile.close();
//            newname  = "upload/"+ fname;
//            book.setImg_path(newname.replace("\\", "\\\\"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}  
	  //  book.setImg_path("");
		
//		 File imageFile = new File(ServletActionContext.getServletContext().getRealPath( " /Upload " ) + " / " + uploadFileName);
//	     copy(myFile, imageFile);

		bookService.book_save(book);
		
		JSONObject json = new JSONObject();
		json.element("success", true);
		setJsonRes(json);
	}


	private static void copy(File src, File dst)  {
        try  {
           InputStream in = null ;
           OutputStream out = null ;
            try  {                
               in = new BufferedInputStream( new FileInputStream(src), BUFFER_SIZE);
               out = new BufferedOutputStream( new FileOutputStream(dst), BUFFER_SIZE);
                byte [] buffer = new byte [BUFFER_SIZE];
                while (in.read(buffer) > 0 )  {
                   out.write(buffer);
               } 
            } finally  {
                if ( null != in)  {
                   in.close();
               } 
                 if ( null != out)  {
                   out.close();
               } 
           } 
        } catch (Exception e)  {
           e.printStackTrace();
       } 
   }
	public BookService getBookService() {
		return bookService;
	}

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

	/**
     * Description :修改图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_edit",results={@Result(name="book_edit",location="/example/book_edit.jsp")})
	public String book_edit(){
		book = bookService.book_edit(book);
		
		//获得编码下拉框
		book.setBooklist(DisposalCode.getCode("cdddyfs","86"));
		return "book_edit";
	}
	
	/**
     * Description :更新图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_update")
	public String update() throws DataAccessException, InstantiationException, IllegalAccessException{
		book = (BookData)bookService.update(book);
		return "list";
	}


	/**
     * Description :修改图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_delete")
	public String book_delete() throws DataAccessException, InstantiationException, IllegalAccessException{
		book = (BookData)bookService.book_delete(book);
		return "list";
	}
	/**
     * Description :查看图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="book_read",results={@Result(name="book_read",location="/example/book_read.jsp")})
	public String book_read(){
		book = (BookData)bookService.book_read(book);
		request.setAttribute("img_path", book.getImg_path());
		return "book_read";
		
	}

}
