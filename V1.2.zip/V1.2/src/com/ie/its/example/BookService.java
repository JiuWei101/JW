package com.ie.its.example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.OperateScList;
import com.ie.common.PrimaryId;
import com.ie.frame.ExtendService;

@Scope("prototype")
@Service
public class BookService extends ExtendService<BookData> {
	private BookSql bookSql;
	
	public BookService(){
		bookSql = new BookSql();
	}
	
	/**
     * Description :查询图书．
     * @param  :book
     * @return :book
     * @throws :SQLException
     */
	public BookData book_list(Object o) {
		BookData book = (BookData)o;

		//获得数量
		int count = this.getJt().queryForInt(bookSql.book_list(book, "count"));
		
		//调用方法设置分页信息 需要参数count
		book.setTotal(count);
		//book.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <BookData>rows = this.getJt().<BookData>queryForListExt(bookSql.book_list(book, ""), 
				book.getStart(), book.getLimit(),BookData.class);
		
		//转换编码
		for(BookData bookdata:rows){
			bookdata.setType2(DisposalCode.getCodeName(bookdata.getType2(), "cdddyfs"));
		}
		
		book.setPer_data(rows);
		return book;
	}
	
	/**
     * Description :检查图书名．
     * @param  :book
     * @return :JSONObject
     * @throws :SQLException
     */
	public JSONObject book_check(BookData book){
		JSONObject json = new JSONObject();

		int count = this.getJt().queryForInt(bookSql.book_check(book));
	
		if(count > 0){
			json.element("flag", "yes");
		}else{
			json.element("flag", "no");
		}
	
		return json;
	}
	
	/**
     * Description :保存图书．
     * @param  :book
     * @return :void
     */
	public void book_save(BookData book){
		getJt().update(bookSql.book_save(book));
	}
	
	/**
     * Description :编辑图书．
     * @param  :book
     * @return :book
     */
	public  BookData book_edit(BookData book){
		book = getJt().queryForObject(bookSql.book_read(book), BookData.class);
		return book;
	}
	
	/**
     * Description :更新图书．
     * @param  :book
     * @return :book
     */
	public BookData update(BookData book){
		getJt().update(bookSql.book_update(book));
		return book;
	}
	
	/**
     * Description :删除图书．
     * @param  :book
     * @return :book
     */
	public Object book_delete(BookData book){
		getJt().update(bookSql.book_delete(book));
		return book;
	}
	
	/**
     * Description :查看图书．
     * @param  :book
     * @return :book
     */
	public Object book_read(BookData book){
		book = getJt().queryForObject(bookSql.book_read(book), BookData.class);
		return book;
	}
	

}
