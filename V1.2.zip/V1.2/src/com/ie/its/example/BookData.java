package com.ie.its.example;

import java.util.List;

import com.ie.frame.ExtendData;
import com.ie.its.example.UploadData;

public class BookData extends ExtendData{
	
	private String id;
	private String name;
	private String sale_time;
	private String img_path;
	private String type1_id;
	private String type1_name;
	private String type2;
	private String type;
	
	private String cxId;
	private String cxName;
	
	private String sign;
	
	private List booklist;
	
	public List getBooklist() {
		return booklist;
	}
	public void setBooklist(List booklist) {
		this.booklist = booklist;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCxId() {
		return cxId;
	}
	public void setCxId(String cxId) {
		this.cxId = cxId;
	}
	public String getCxName() {
		return cxName;
	}
	public void setCxName(String cxName) {
		this.cxName = cxName;
	}
	public String getSale_time() {
		return sale_time;
	}
	public void setSale_time(String sale_time) {
		this.sale_time = sale_time;
	}
	public String getImg_path() {
		return img_path;
	}
	public void setImg_path(String img_path) {
		this.img_path = img_path;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getType1_id() {
		return type1_id;
	}
	public void setType1_id(String type1_id) {
		this.type1_id = type1_id;
	}
	public String getType1_name() {
		return type1_name;
	}
	public void setType1_name(String type1_name) {
		this.type1_name = type1_name;
	}
	public String getType2() {
		return type2;
	}
	public void setType2(String type2) {
		this.type2 = type2;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
