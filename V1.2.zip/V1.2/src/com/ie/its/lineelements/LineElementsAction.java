package com.ie.its.lineelements;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.frame.ExtendActionSupport;
@Namespace("/lineelementconfig")
public class LineElementsAction extends ExtendActionSupport{
	@Autowired
	private LineElementsService lineelementsservice;
	private LineElementsData data;
	
	
	public LineElementsData getData() {
		return data;
	}

	public void setData(LineElementsData data) {
		this.data = data;
	}
	public LineElementsAction(){
		if(data == null){
			data = new LineElementsData();
		}
	}
	@Action(value="getElements",results={@Result(type="json")})
	public void getElements(){
		JSONObject obj = new JSONObject();
		try{
			obj = lineelementsservice.getLineElements();
			obj.element("success", true);
		}catch(Exception e){
			e.printStackTrace();
			obj.element("success", false);
		}
		setJsonRes(obj);
	}
	
	@Action(value="setElements",results={@Result(type="json")})
	public void setElements(){
		JSONObject obj = new JSONObject();
		try{
			obj = lineelementsservice.setLineElements(data);
			obj.element("success", true);
		}catch(Exception e){
			e.printStackTrace();
			obj.element("success", false);
		}
		setJsonRes(obj);
	}
}
