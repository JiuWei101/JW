package com.ie.its.lineelements;

public class LineElementsData{
	private String thickness;	//线条宽度，有效值0到255
	private String rgb;	//线条颜色
	private String alpha;	//透明度，取值0到100,100表示不透明
	private String pixelhinting;	//指定是否提示笔触采用完整像素
	private String noscale;		//指定如何缩放笔触
	private String capsstyle;	//指定线条终点的端点类型
	private String jointstyle;	//指定用于拐角的连接外观的类型
	private String miterlimit;		//指示切断尖角的限制
	private String arrowlen;		//箭头长度
	private String arrowangle;		//箭头角度
	private String range;		//画线步长，0代表静态画线
	private String cratio;		//起终点图标是平均车位大小的倍数
	private String bratio;		//气泡是swf文件的倍数
	public String getThickness() {
		return thickness;
	}
	public void setThickness(String thickness) {
		this.thickness = thickness;
	}
	public String getRgb() {
		return rgb;
	}
	public void setRgb(String rgb) {
		this.rgb = rgb;
	}
	public String getAlpha() {
		return alpha;
	}
	public void setAlpha(String alpha) {
		this.alpha = alpha;
	}
	public String getPixelhinting() {
		return pixelhinting;
	}
	public void setPixelhinting(String pixelhinting) {
		this.pixelhinting = pixelhinting;
	}
	public String getNoscale() {
		return noscale;
	}
	public void setNoscale(String noscale) {
		this.noscale = noscale;
	}
	public String getCapsstyle() {
		return capsstyle;
	}
	public void setCapsstyle(String capsstyle) {
		this.capsstyle = capsstyle;
	}
	public String getJointstyle() {
		return jointstyle;
	}
	public void setJointstyle(String jointstyle) {
		this.jointstyle = jointstyle;
	}
	public String getMiterlimit() {
		return miterlimit;
	}
	public void setMiterlimit(String miterlimit) {
		this.miterlimit = miterlimit;
	}
	public String getArrowlen() {
		return arrowlen;
	}
	public void setArrowlen(String arrowlen) {
		this.arrowlen = arrowlen;
	}
	public String getArrowangle() {
		return arrowangle;
	}
	public void setArrowangle(String arrowangle) {
		this.arrowangle = arrowangle;
	}
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getCratio() {
		return cratio;
	}
	public void setCratio(String cratio) {
		this.cratio = cratio;
	}
	public String getBratio() {
		return bratio;
	}
	public void setBratio(String bratio) {
		this.bratio = bratio;
	}
	
}
