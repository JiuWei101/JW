package com.ie.its.lineelements;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.Log;
import com.ie.frame.ExtendService;
@Scope("prototype")
@Service
public class LineElementsService extends ExtendService{
	
	public  JSONObject getLineElements(){
		JSONObject obj = new JSONObject();
		FileInputStream fis = null;
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + "lineelements.properties");
			Properties prop = new Properties();
			prop.load(fis);
			obj.element("thickness",prop.get("thickness").toString());
			obj.element("rgb", prop.get("rgb").toString());
			obj.element("alpha", prop.get("alpha").toString());
			obj.element("pixelhinting", prop.get("pixelhinting").toString());
			obj.element("noscale", prop.get("noscale").toString());
			obj.element("capsstyle", prop.get("capsstyle").toString());
			obj.element("jointstyle", prop.get("jointstyle").toString());
			obj.element("miterlimit", prop.get("miterlimit").toString());
			obj.element("arrowlen", prop.get("arrowlen").toString());
			obj.element("arrowangle", prop.get("arrowangle").toString());
			obj.element("range", prop.get("range").toString());
			obj.element("cratio", prop.get("cratio").toString());
			obj.element("bratio", prop.get("bratio").toString());
		} catch (URISyntaxException e) {
			Log.log(e);
		} catch (FileNotFoundException e) {
			Log.log(e);
		} catch (IOException e) {
			Log.log(e);
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}		
		return obj;
	}
	
	public JSONObject setLineElements(LineElementsData data){
		JSONObject obj = new JSONObject();
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + "lineelements.properties");
			Properties prop = new Properties();
			prop.load(fis);
			prop.setProperty("thickness", data.getThickness());
			prop.setProperty("rgb", data.getRgb());
			prop.setProperty("alpha", data.getAlpha());
			prop.setProperty("pixelhinting", data.getPixelhinting());
			prop.setProperty("noscale", data.getNoscale());
			prop.setProperty("capsstyle", data.getCapsstyle());
			prop.setProperty("jointstyle", data.getJointstyle());
			prop.setProperty("miterlimit", data.getMiterlimit());
			prop.setProperty("arrowlen", data.getArrowlen());
			prop.setProperty("arrowangle", data.getArrowangle());
			prop.setProperty("range", data.getRange());
			prop.setProperty("cratio", data.getCratio());
			prop.setProperty("bratio", data.getBratio());
			fos = new FileOutputStream(path + "lineelements.properties");
			prop.store(fos, null);
		} catch (URISyntaxException e) {
			Log.log("获取path失败============>" + e);
		} catch (FileNotFoundException e) {
			Log.log("读取lineelements.properties失败=====>" + e);
		} catch (IOException e) {
			Log.log("加载lineelements.properties失败=====>" + e);
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return obj;
	}
	public static void main(String[] args){
		new LineElementsService().getLineElements();
	}
}
