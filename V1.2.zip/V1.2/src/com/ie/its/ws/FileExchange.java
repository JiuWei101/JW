package com.ie.its.ws;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.*;
import javax.jws.soap.SOAPBinding.*;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import com.ie.frame.exception.FileTransferException;

@WebService(targetNamespace = "http://www.ake.com.cn/")
@SOAPBinding(style=Style.RPC, use=Use.LITERAL)
public interface FileExchange {
	@WebMethod(operationName = "uploadFile")
	@RequestWrapper(targetNamespace="http://www.ake.com.cn/",
				className="com.ake.dccs.ws.MyFile")
	void uploadFile(@WebParam(name = "myFile", partName = "myFile")MyFile myFile) throws FileTransferException;

	@WebMethod(operationName = "downloadFile")
	@RequestWrapper(targetNamespace="http://www.ake.com.cn/",
				className="com.ake.dccs.ws.ws.MyFile")
    @ResponseWrapper(targetNamespace="http://www.ake.com.cn/",
    			className="com.ake.dccs.ws.MyFile")
	MyFile downloadFile(@WebParam(targetNamespace="http://www.ake.com.cn/",
					name = "myFile",partName = "myFile")MyFile myFile) throws FileTransferException;
}
