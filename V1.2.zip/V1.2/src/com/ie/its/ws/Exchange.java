package com.ie.its.ws;
import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import net.sf.json.JSONObject;
@WebService(targetNamespace = "http://www.ake.com.cn/",serviceName="Exchange")
public interface Exchange {
	@SuppressWarnings("rawtypes")
	@WebMethod(operationName = "exchangeSysInfo")
	List<Map> exchangeSysInfo(@WebParam(name = "list", partName = "list")List<Map> list);
	
	@SuppressWarnings("rawtypes")
	@WebMethod(operationName = "exchangeSysInfoOther")
	List<Map> exchangeSysInfoOther(@WebParam(name = "list", partName = "list")List<Map> list);	
	
	@WebMethod(operationName = "getLatestVersion")
	JSONObject getLatestVersion(@WebParam(name = "eqType", partName = "eqType")String eqType,
							@WebParam(name = "verNo", partName = "verNo")String verNo);	
	

}
