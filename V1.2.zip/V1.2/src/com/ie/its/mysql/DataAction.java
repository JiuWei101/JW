///实现数据库备份还原代码 ByLLX 0813
package com.ie.its.mysql;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletContext;
//import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.tools.ant.taskdefs.Execute;
import org.directwebremoting.io.FileTransfer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendService;
import com.ie.its.log.LogData;
import com.ie.its.log.LogService;
import com.ie.its.login.PasswdService;
import com.ie.its.login.UserInfo;
import com.ie.its.user.UserService;
import com.opensymphony.xwork2.ActionContext;
import com.thoughtworks.xstream.io.path.Path;

import uk.ltd.getahead.dwr.WebContext;
import uk.ltd.getahead.dwr.WebContextFactory;

@Namespace("/backup")
public class DataAction extends ExtendActionSupport {
	private String username;
	private String password;
	private String host;
	private String PORT;
	private String dbname;
	private File reductionFile;
	private ExtendData data;
	
	private LogService logService;
	public File getReductionFile() {
		return reductionFile;
	}

	public void setReductionFile(File reductionFile) {
		this.reductionFile = reductionFile;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPORT() {
		return PORT;
	}

	public void setPORT(String pORT) {
		PORT = pORT;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDbname() {
		return dbname;
	}

	public void setDbname(String dbname) {
		this.dbname = dbname;
	}

	public ExtendData getData() {
		return data;
	}

	public void setData(ExtendData data) {
		this.data = data;
	}

	// /**
	// * 删除
	// * */
	// public String delete(){
	// String fileName = request.getParameter("fileName");
	// System.out.println(fileName);
	// String backPath =
	// ServletActionContext.getServletContext().getRealPath("/")+"ewssite/back/"+fileName;
	// File file = new File(backPath);
	// file.delete();
	// return "delete";
	// }

	/**
	 * 配置 Mysql bin目录
	 * */
	public void getConfig() {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		BasicDataSource ba = (BasicDataSource) context.getBean("dataSource");
		setUsername(ba.getUsername());
		setPassword(ba.getPassword());
		String url = ba.getUrl();
		url = url.substring(13, url.length());
		if(url.indexOf("?") != -1){
			url = url.substring(0, url.indexOf("?"));
		}
		String[] temp = url.split("/");
		String[] temp1 = temp[0].split(":");
		setHost(temp1[0]);
		setPORT(temp1[1]);
		setDbname(temp[1]);
	}

	/**
	 * 备份数据库文件到服务器
	 * */
	public String backupToServer() {
		getConfig();
		// 得到配置文件
		String returnStr = "success";
		try {
			SimpleDateFormat simple = new SimpleDateFormat("yyyyMMDDhhmmss");
			java.util.Date date = new java.util.Date();
			String dateStr = simple.format(date);
			Runtime rt = Runtime.getRuntime();
			// String path = new File("WEB-INF").getAbsolutePath();
			// String pathValue =
			// path.substring(0,path.indexOf("bin")).replace("\\", "/") +
			// "webapps/pgs/upload/"+"backup";//备份数据文件存放目录
			String str = getClass().getProtectionDomain().getCodeSource()
					.getLocation().getPath();
			Log.log("DataAction类路径" + str);
			String pathValue = str.substring(1, str.indexOf("WEB-INF"))
					+ "upload/" + "backup";// 备份数据文件存放路径
			Log.log("备份数据文件存放路径" + pathValue);
			File filePath = new File(pathValue);
			if (!filePath.isDirectory()) {
				filePath.mkdirs();
			}
			pathValue += "/" + dateStr + ".sql";
			String mysql = "mysqldump -u" + getUsername() + " -p"
					+ getPassword() + " --default-character-set=utf8 -h"
					+ getHost() + " -P" + getPORT() + " " + getDbname() + " >"
					+ "\"" + pathValue + "\"";
			Process proc = rt.exec("cmd.exe /c " + mysql);// 设置导出编码为utf8。这里必须是utf8
			int tag = proc.waitFor();// 等待进程终止
		} catch (Exception e) {
			e.printStackTrace();
			returnStr = "fail";
		}
		return returnStr;
	}

	/**
	 * 备份数据库文件到本地
	 * 
	 * @throws UnsupportedEncodingException
	 * */
	public FileTransfer backupToLocal_update(HttpServletRequest request,
			HttpServletResponse response, ServletContext context)
			throws UnsupportedEncodingException {
		getConfig();
		// 得到配置文件
		String dateStr = "";
		String fileName = "";
		String zipName = "";
		// FileTransfer fileTran = null;
		// HttpServletResponse response =
		// (HttpServletResponse)ActionContext.getContext().get(org.apache.struts2.StrutsStatics.HTTP_RESPONSE);
		ByteArrayOutputStream out = null;
		
		String res="";
		try {
			SimpleDateFormat simple = new SimpleDateFormat("yyyyMMddHHmmss");// 24小时制，如2012-08-17
																				// 19:23:33
																				// 转为20120817192333
			java.util.Date date = new java.util.Date();
			dateStr = simple.format(date);
			fileName = dateStr + ".sql";
			Runtime rt = Runtime.getRuntime();
			String str = getClass().getProtectionDomain().getCodeSource()
					.getLocation().getPath();
			Log.log("DataAction类路径" + str);
			String pathValue = rebuildPath(str) + "upload/" + "backup";// 备份数据文件存放路径
			Log.log("备份数据文件存放路径" + pathValue);
			File filePath = new File(pathValue);// 检测是否有backup文件夹
			if (!filePath.isDirectory()) {
				filePath.mkdirs();
			}
			zipName = dateStr + ".zip";
			String zipPath = pathValue + getSeparator() + zipName;// 压缩文件路径
			pathValue += getSeparator() + fileName;
			String mysql = "mysqldump -u" + getUsername() + " -p"
					+ getPassword() + " --default-character-set=utf8 -h"
					+ getHost() + " -P" + getPORT() + " " + getDbname() + " > "
					+ "\"" + pathValue + "\"";
			Process proc = null;
			if (getSeparator().equalsIgnoreCase("\\")) {
				String cmd = "cmd.exe /c " + mysql;
				proc = rt.exec(cmd);// 设置导出编码为utf8。这里必须是utf8
				Log.log(cmd);
			} else {
				String[] ucmd = new String[] { "sh", "-c", mysql };
				proc = rt.exec(ucmd);// 设置导出编码为utf8。这里必须是utf8
				Log.log(mysql);
			}
			int tag = proc.waitFor();// 等待进程终止
			Log.log("备份数据库进程：" + tag);
			boolean zbool = zipFile(pathValue, zipPath);
			if (zbool) {
				File file = new File(zipPath);
				FileInputStream fis = null;
				BufferedInputStream bis = null;

				try {
					fis = new FileInputStream(file);
					bis = new BufferedInputStream(fis);
					out = new ByteArrayOutputStream();
					byte[] temp = new byte[1024];
					int size = 0;
					while ((size = bis.read(temp)) != -1) {
						out.write(temp, 0, size);
					}
				} catch (FileNotFoundException e) {
					
					res=e.getMessage();
					e.printStackTrace();
					
				}
			}
		} catch (Exception e) {
			
			res=e.getMessage();
			e.printStackTrace();
			
		}finally{
			//addLogRecord("备份数据库到本地",res);
		}
    
		return new FileTransfer(
				new String(zipName.getBytes("GBK"), "iso8859-1"), "text/plain",
				out.toByteArray());
		// return fileTran;
		
	}
	//日志记录add by jyf 因为spring的aop实现不了
	public void addLogRecord(String oper ,String res){
		ApplicationContext ctx = new ClassPathXmlApplicationContext("app*.xml");
		logService=(LogService)ctx.getBean("logService");
		LogData logdata=logService.getLogData();
	    String userName=logService.getUserService().getUserinfo().getUser_name();
		/*logdata.setUserName(userName);
		logdata.setCurrDate(DateUtil.getCurDateTime());
		logdata.setOperInfo(userName+oper);
		logdata.setOperation(oper);*/
		if(!res.equals("")){
			logdata.setExceptionInfo(res);
			//logdata.setRes("0");
		}
		logService.insertLogTab();
		
  }
	/**
	 * DWR文件下载
	 * 
	 * @param fileName
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	public FileTransfer downloadFile(String fileName,
			HttpServletRequest request, HttpServletResponse response,
			ServletContext context) {
		// String path = new File("WEB-INF").getAbsolutePath();
		// String pathValue =
		// path.substring(0,path.indexOf("bin")).replace("\\", "/") +
		// "webapps/pgs/upload/"+"backup/"+fileName;//备份数据文件存放路径
		String str = getClass().getProtectionDomain().getCodeSource()
				.getLocation().getPath();
		Log.log("DataAction类路径" + str);
		String pathValue = str.substring(1, str.indexOf("WEB-INF")) + "upload/"
				+ "backup";// 备份数据文件存放路径
		Log.log("备份数据文件存放路径" + pathValue);
		String realPath = context.getRealPath(pathValue + fileName);
		File file = null;
		FileInputStream fis = null;
		try {
			file = new File(realPath);
			fis = new FileInputStream(file);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// InputStreamFactory inputStreamFactory = new
		// SimpleInputStreamFactory(fileInputStream);
		String reportName = fileName.substring(0, fileName.length() - 6);
		return new FileTransfer(reportName + ".jrxml", "text/plain",
				file.length(), fis);
		// FileTransfer为DWR的一个接口。可以接受inputStream，inputStreamFactory和byte[]类型，相当的好用。
	}

	/**
	 * 数据库还原
	 * */
	public String recovery(String sqlPath) {
		getConfig();// 得到配置文件
		try {
			Runtime rt = Runtime.getRuntime();
			String createDb = "mysqladmin  --default-character-set=utf8 -u"
					+ getUsername() + " -p" + getPassword() + " create "
					+ getDbname();
			String mysql = "mysql -u" + getUsername() + " -p" + getPassword()
					+ " " + getDbname() + " <" + "\"" + sqlPath + "\"";
			Process proc = null;
			if (getSeparator().equalsIgnoreCase("\\")) {
				rt.exec("cmd.exe /c " + createDb);
				String cmd = "cmd.exe /c " + mysql;
				proc = rt.exec(cmd);// 设置导出编码为utf8。这里必须是utf8
				Log.log(cmd);
			} else {
				String[] ucreateDb = new String[] { "sh", "-c", createDb };
				rt.exec(ucreateDb);
				String[] ucmd = new String[] { "sh", "-c", mysql };
				proc = rt.exec(ucmd);// 设置导出编码为utf8。这里必须是utf8
				Log.log(ucmd.toString());
			}
			final InputStream is1 = proc.getInputStream();
			final InputStream is2 = proc.getErrorStream();
			PrintStream(is1).start();
			PrintStream(is2).start();
			int tag = proc.waitFor();// 等待进程终止
			Log.log("数据还原进程：" + tag);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "recovery";
	}

	/**
	 * 文件上传方法
	 **/
	@SuppressWarnings("deprecation")
	public String uploadFile_update(FileTransfer fileTransfer) {
		String str="";
		String res="";
		try {
			WebContext webContext = WebContextFactory.get();
			String oldName = fileTransfer.getFilename();
			
			if (oldName == "") {
				str= "typeNull";
			} else {
				// String type = oldName.substring(oldName.length()-3,
				// oldName.length());
				// if(!"SQL".equals(type.toUpperCase())){
				// return "typeError";
				// }
			}

			String saveurl = webContext.getHttpServletRequest().getSession()
					.getServletContext().getRealPath("/upload/recovery");// 存放上传的sql文件用于恢复数据库
			SimpleDateFormat simple = new SimpleDateFormat("yyyyMMddHHmmss");// 24小时制，如2012-08-17
																				// 19:23:33
																				// 转为20120817192333
			java.util.Date date = new java.util.Date();
			String dateStr = simple.format(date);
			String fileName = dateStr + ".sql";
			String zipFileName = dateStr + ".zip";
			// String fileName = fileTransfer.getFilename();//上传文件原文件名
			File file = new File(saveurl + "/" + zipFileName);
			File file2 = new File(saveurl + "/");
			if (!file2.isDirectory()) {// 判断是否存在recovery文件夹，如果不存在则新建目录。BY LLX
				file2.mkdirs();
			}
			String filePath = saveurl + "/" + fileName;
			InputStream uploadFile = fileTransfer.getInputStream();
			BufferedInputStream bis = new BufferedInputStream(uploadFile);
			int available = uploadFile.available();
			byte[] b = new byte[1024];
			int len;
			FileOutputStream foutput = new FileOutputStream(file);
			while ((len = bis.read(b)) != -1) {
				foutput.write(b, 0, len);
				foutput.flush();
			}
			// uploadFile.read(b);
			// foutput.write(b);
			// foutput.flush();
			foutput.close();
			bis.close();
			String rbool = unZipFile(file.getPath(), filePath);
			if (rbool.equals("success")) {
				recovery(filePath);// 数据库还原
				str="success";
			}
			else {
				str="typeError";
			}
		} catch (FileNotFoundException e) {
			str="filenotexist";
			res=e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			res=e.getMessage();
			e.printStackTrace();
		} catch (Exception e) {
			res=e.getMessage();
			e.printStackTrace();
		}finally{
			//addLogRecord("数据恢复", res);
		}
		return str;
	}

	@Action(value = "backup_read", results = { @Result(name = "read", location = "/system_manage/backup.jsp") })
	public String read() {
		data = new ExtendData();
		// 设置多语言
		setLang(data);
		return "read";
	}

	/**
	 * 压缩文件
	 * 
	 * @param filePath要压缩文件
	 * @param zipName压缩后文件
	 * @return
	 */
	public boolean zipFile(String filePath, String zipName) {
		boolean rbool = false;
		if (filePath != "" && filePath != null && zipName != ""
				&& zipName != null) {
			try {
				File file = new File(filePath);
				FileInputStream fis = new FileInputStream(file);
				BufferedInputStream bis = new BufferedInputStream(fis);
				byte[] buf = new byte[1024];
				int len;
				FileOutputStream fos = new FileOutputStream(zipName);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				ZipOutputStream zos = new ZipOutputStream(bos);
				ZipEntry ze = new ZipEntry(file.getName());
				zos.putNextEntry(ze);
				while ((len = bis.read(buf)) != -1) {
					zos.write(buf, 0, len);
					zos.flush();
				}
				bis.close();
				zos.close();
				rbool = true;
			} catch (Exception e) {
				e.printStackTrace();
				rbool = false;
			}
		} else {
			rbool = false;
		}
		return rbool;

	}

	/**
	 * 解压缩zip文件（只包含一个.sql文件的解压缩）
	 * 
	 * @param zipFilePath
	 *            原zip文件路径
	 * @param filePath
	 *            解压后文件路径
	 * @return
	 */
	public String unZipFile(String zipFilePath, String filePath) {
		String rbool = "failer";
		if (zipFilePath != "" && zipFilePath != null && filePath != ""
				&& filePath != null) {
			byte[] buf = new byte[1024];
			File zipfile = new File(zipFilePath);// 要解压的文件
			FileOutputStream fos = null;
			FileInputStream fis = null;
			BufferedInputStream bis = null;
			try {
				fis = new FileInputStream(zipfile);
				ZipInputStream zis = new ZipInputStream(fis);
				bis = new BufferedInputStream(zis);
				ZipEntry ze = zis.getNextEntry();
				if (ze != null) {
					File file = new File(filePath);// 解压后的文件
					fos = new FileOutputStream(file);
					int b;
					while ((b = bis.read(buf)) != -1) {
						fos.write(buf, 0, b);
						fos.flush();
					}

					rbool = "success";

				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (fos != null) {
						fos.close();
					}
					if (bis != null) {
						bis.close();
					}
					if (fis != null) {
						fis.close();
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		return rbool;
	}

	public Thread PrintStream(final InputStream is) {
		Thread td = null;
		td = new Thread() {
			public void run() {
				BufferedReader bfr = new BufferedReader(new InputStreamReader(
						is));
				try {
					String line = null;
					while ((line = bfr.readLine()) != null) {
						if (line != null) {

						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						bfr.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		};
		return td;
	}

	// 获取文件分隔符，Windows环境为“\”,Unix环境为“/”
	public String getSeparator() {
		return System.getProperties().getProperty("file.separator");
	}

	public String rebuildPath(String path) {
		String rPath = "";
		String os = System.getProperties().getProperty("os.name");
		if (os.indexOf("Windows") != -1) {
			rPath = path.substring(1, path.indexOf("WEB-INF"));
		} else {
			rPath = path.substring(0, path.indexOf("WEB-INF"));
		}
		return rPath;
	}
	
}