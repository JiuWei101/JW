package com.ie.its.screencolortactics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.CodeData;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendService;

@Scope("prototype")
@Service
public class ScreenColorTacticsService extends ExtendService {

	private ScreenColorTacticsSql sctSql;
	public ScreenColorTacticsService(){
		if(sctSql == null){
			sctSql = new ScreenColorTacticsSql();
		}
	}

	@SuppressWarnings("unchecked")
	public ScreenColorTacticsData screen_list(ScreenColorTacticsData data){
		int count = this.getJt().queryForInt(sctSql.screen_list(data, "count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		List<ScreenColorTacticsData> rows = this.getJt().queryForListExt(sctSql.screen_list(data, ""), 
				data.getStart(), data.getLimit(), ScreenColorTacticsData.class);
		int j=0;
		for(ScreenColorTacticsData tdata : rows){
			List<ScreenRegionData> srlist = this.getJt().queryForListExt(sctSql.get_screenregion_data(tdata.getId()), ScreenRegionData.class);
			JSONArray colorInfo=this.getJt().queryJson(sctSql.get_screenregion_info(tdata.getScreen()));
			int arrlen=colorInfo.size();
			Map map = new HashMap();
			String preview = "";
			String []colorArr=null;
			int len=0;
			if(arrlen>0){
				String info=colorInfo.getString(0);//{"colorvalues":"3,G,3,Y,5"}{"colorvalues":"1,Y,7,Y,9;2,Y,2,G,4"}
				String strColor=info.substring(info.indexOf(":")+2,info.indexOf("}")-1);
				colorArr=strColor.split(";");
				len=colorArr.length;
				j++;
			}
			if(srlist.size() > 0){ 
				if(len>0){
					map = manageSRList(srlist,colorArr);
				}else{
					map = manageSRList(srlist);
				}

				tdata.setSrlist((List<ScreenRegionData>)map.get("srlist"));
				tdata.setPreview(map.get("preview").toString());
			}else{
				tdata.setSrlist(srlist);
			}
		}
		data.setPer_data(rows);
		return data;
	}

	public Map manageSRList(List<ScreenRegionData> srlist,String[] colorInfo){
		Map map = new HashMap();
		String preview = "";
		if(srlist.size() > 0){
			int i=0;
			for(ScreenRegionData temp : srlist){
				temp = generateSRData(temp,colorInfo[i]);
				preview +=temp.getSrcontent();
				i++;
			}
		}
		map.put("srlist", srlist);
		map.put("preview", preview);
		return map;
	}
	public Map manageSRList(List<ScreenRegionData> srlist){
		Map map = new HashMap();
		String preview = "";
		if(srlist.size() > 0){
			for(ScreenRegionData temp : srlist){
				temp = generateSRData(temp);
				preview +=temp.getSrcontent();
			}
		}
		map.put("srlist", srlist);
		map.put("preview", preview);
		return map;
	}
	public ScreenRegionData generateSRData(ScreenRegionData srdata,String strinfo){
		String []infoArr=strinfo.split(",");
		String preDirection=srdata.getDirection();
		int num=srdata.getNum();
		String direction = get_arrow(preDirection);
		if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("R")){
			srdata.setSrcontent("<font class='sta' color='red'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='red'>"+direction+"</font>");
		}else if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("G")){
			srdata.setSrcontent("<font class='sta' color='green'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='green'>"+direction+"</font>");
		}else if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("Y")){
			srdata.setSrcontent("<font class='sta' color='yellow'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='yellow'>"+direction+"</font>");
		}
		String [] infoLaArr=new String [5];
		int infoArrLen=infoArr.length;
		for(int i=0;i<infoArrLen;i++){
			infoLaArr[i]=infoArr[i];
		}
		for(int i=0;i<5-infoArrLen;i++){
			infoLaArr[infoArrLen+i]="";
		}
		srdata.setMincolor(infoLaArr[1].toString());
		srdata.setMinvalue(infoLaArr[2].toString());
		srdata.setMaxcolor(infoLaArr[3].toString());
		srdata.setMaxvalue(infoLaArr[4].toString());
		return srdata;
	}
	//	 public static void main(String args[]) { 
	//		 
	//		 String nn="1,,,,5";
	//		 String []aa=nn.split(",");
	//		 for(int i=0;i<aa.length;i++){
	//	        System.out.println(aa.length+"---"+aa[i]); 
	//	    } 
	//	 }

	public ScreenRegionData generateSRData(ScreenRegionData srdata){
		String preDirection=srdata.getDirection();
		int num=srdata.getNum();
		String direction = get_arrow(preDirection);
		if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("R")){
			srdata.setSrcontent("<font class='sta' color='red'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='red'>"+direction+"</font>");
		}else if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("G")){
			srdata.setSrcontent("<font class='sta' color='green'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='green'>"+direction+"</font>");
		}else if(srdata.getColor()!=null && srdata.getColor().equalsIgnoreCase("Y")){
			srdata.setSrcontent("<font class='sta' color='yellow'>"+preDirection+num+"</font>");
			srdata.setDirection("<font class='sta oa' color='yellow'>"+direction+"</font>");
		}
		return srdata;
	}

	private String get_arrow(String str) {
		// TODO Auto-generated method stub
		String rStr = "";
		if(!"".equals(str)){
			if(str.indexOf("↑") != -1){
				rStr = "↑";
			}else if(str.indexOf("←") != -1){
				rStr = "←";
			}else if(str.indexOf("→") != -1){
				rStr = "→";
			}else if(str.indexOf("↓") != -1){
				rStr = "↓";
			}
		}
		return rStr;

	}

	public JSONObject save_screen_colortactics(String tactics){
		JSONObject obj = new JSONObject();
		String[] tacticsArr = tactics.split("\\|");
		for(int i=0; i<tacticsArr.length; i++){
			String temp = tacticsArr[i];
			String[] tempArr = temp.split("\\]");
			String screenId = tempArr[0];
			String colortactics = tempArr[1];

			ScreenColorTacticsData data = this.getJt().queryForObjectExt(sctSql.get_controllerId_screencode(screenId), ScreenColorTacticsData.class);
			this.getJt().update(sctSql.delete_colorstatics(data.getScreen()));
			this.getJt().update(sctSql.save_screen_colortatics(data.getControllerId(), data.getScreen(), colortactics, "5", "20", "", this.getUserinfo().getId()));

		}
		obj.element("success", true);
		return obj;
	}

	/**
	 * Description :获得地图list．
	 * @param  :ControllerData
	 * @return :ControllerData
	 * @throws :Exception
	 */
	public List get_mapCode() {
		List codeList = new ArrayList();		
		codeList = getJt().queryForListExt(sctSql.get_mapCode(), ScreenColorTacticsData.class);
		return codeList;
	}

	public List generateList(String lan){
		List list = new ArrayList();
		CodeData code1=null;
		CodeData code2=null;
		CodeData code3=null;
		switch(Integer.parseInt(lan)){
		case 86:
			code1= new CodeData("R", "红色");
			code2 = new CodeData("G", "绿色");
			code3 = new CodeData("Y", "黄色");
			break;
		case 44:
			code1 = new CodeData("R", "Red");
			code2 = new CodeData("G", "Green");
			code3 = new CodeData("Y", "Yellow");
			break;
		case 87:
			code1 = new CodeData("R", "紅色");
			code2 = new CodeData("G", "綠色");
			code3 = new CodeData("Y", "黃色");
			break;
		default:
			break;
		}
		list.add(code1);
		list.add(code2);
		list.add(code3);
		return list;
	}

	public ScreenColorTacticsData color_tactics_task(ScreenColorTacticsData data){
		int count = this.getJt().queryForInt(sctSql.color_tatics_task(data, "count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		@SuppressWarnings("unchecked")
		List<ScreenColorTacticsData> rows = this.getJt().queryForListExt(sctSql.color_tatics_task(data, ""),
				data.getStart(), data.getLimit(), ScreenColorTacticsData.class);
		for(ScreenColorTacticsData tdata : rows){
			List<ScreenRegionData> srlist = this.getJt().queryForListExt(sctSql.get_screenregion_data(tdata.getScreenId()), ScreenRegionData.class);
			tdata.setRunstate((String) ((HashMap)data.getCurrent_lang_switch().get("runstate")).get(tdata.getRunstate()));
			if(srlist.size() > 0){
				Map map = manageSRList(srlist);
				srlist = (List<ScreenRegionData>)map.get("srlist");
				srlist = generateTactics(tdata.getColorvalues(),srlist);
				tdata.setSrlist(srlist);
				tdata.setPreview(map.get("preview").toString());
			}else{
				tdata.setSrlist(srlist);
			}
		}
		data.setPer_data(rows);
		return data;
	}

	public ScreenColorTacticsData color_tactics_history(ScreenColorTacticsData data){
		int count = this.getJt().queryForInt(sctSql.color_tactics_history(data, "count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);

		List<ScreenColorTacticsData> rows = this.getJt().queryForListExt(sctSql.color_tactics_history(data, ""), 
				data.getStart(), data.getLimit(), ScreenColorTacticsData.class);
		for(ScreenColorTacticsData tdata : rows){
			List<ScreenRegionData> srlist = this.getJt().queryForListExt(sctSql.get_screenregion_data(tdata.getScreenId()), ScreenRegionData.class);
			tdata.setRunstate((String) ((HashMap)data.getCurrent_lang_switch().get("success")).get(tdata.getRunstate()));
			if(srlist.size() > 0){
				Map map = manageSRList(srlist);
				srlist = (List<ScreenRegionData>)map.get("srlist");
				srlist = generateTactics(tdata.getColorvalues(),srlist);
				tdata.setSrlist(srlist);
				tdata.setPreview(map.get("preview").toString());
			}else{
				tdata.setSrlist(srlist);
			}
		}
		data.setPer_data(rows);
		return data;
	}

	public List<ScreenRegionData> generateTactics(String colorvalues,List<ScreenRegionData> srlist){
		String[] cArr = colorvalues.split(";");
		for(int i=0; i<cArr.length; i++){
			String[] oArr = cArr[i].split(",",5);
			for(int j=0; j<srlist.size(); j++){
				ScreenRegionData temp = srlist.get(j);
				if(oArr[0].equalsIgnoreCase(temp.getId())){
					temp.setMincolor(oArr[1]);
					temp.setMinvalue(oArr[2]);
					temp.setMaxcolor(oArr[3]);
					temp.setMaxvalue(oArr[4]);
				}
			}
		}
		return srlist;
	}

	public JSONObject delete_colortactics_task(String id){
		JSONObject jobj = new JSONObject();
		if(id.length() > 0){
			String[] ids = id.split(";");
			String[] deleteSql = new String[ids.length];
			for(int i=0; i<ids.length; i++){
				deleteSql[i] = sctSql.delete_colortactics_task(ids[i]);
			}
			this.getJt().batchUpdate(deleteSql);
		}
		jobj.element("success", true);
		return jobj;
	}

	public JSONObject delete_colortactics_history(String id){
		JSONObject jobj = new JSONObject();
		if(id.length() > 0){
			String[] ids = id.split(";");
			String[] deleteSql = new String[ids.length];
			for(int i=0; i<ids.length; i++){
				deleteSql[i] = sctSql.delete_colortactics_history(ids[i]);
			}
			this.getJt().batchUpdate(deleteSql);
		}
		jobj.element("success", true);
		return jobj;
	}
}
