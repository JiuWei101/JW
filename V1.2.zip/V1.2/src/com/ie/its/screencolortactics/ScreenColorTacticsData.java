package com.ie.its.screencolortactics;

import java.util.List;

import com.ie.frame.ExtendData;

public class ScreenColorTacticsData extends ExtendData{
	private String id;//记录id
	private String mapId;
	private String mapName;//地图id
	private String controllerId;//管理器id
	private String screenId;//引导屏id
	private String screen;//引导屏编号
	private String preview;//引导屏预览值
	
	private int minvalue;//缺省时最小值
	private int maxval;//缺省时最大值
	private String colorvalues;//变色策略值
	private String operator;//操作人
	private String createtime;//操作时间
	private String runstate;//运行状态
	private String notes;//备注
	
	private String executeTime;//执行时间
	private int duration;//时长
	private List<ScreenRegionData> srlist;//引导屏分区列表

	private List mapList;//地图下拉列表


	private List colorList;//颜色列表
	
	private String dispLen;//格式化长度
	private String maxColor;
	private String minColor;
	private int lastMax;
	private int lastMin;
	private int lastDisLen;
	
	public String getMaxColor() {
		return maxColor;
	}

	public void setMaxColor(String maxColor) {
		this.maxColor = maxColor;
	}

	public String getMinColor() {
		return minColor;
	}

	public void setMinColor(String minColor) {
		this.minColor = minColor;
	}

	public int getLastMax() {
		return lastMax;
	}

	public void setLastMax(int lastMax) {
		this.lastMax = lastMax;
	}

	public int getLastMin() {
		return lastMin;
	}

	public void setLastMin(int lastMin) {
		this.lastMin = lastMin;
	}

	public int getLastDisLen() {
		return lastDisLen;
	}

	public void setLastDisLen(int lastDisLen) {
		this.lastDisLen = lastDisLen;
	}

	public List getColorList() {
		return colorList;
	}

	public void setColorList(List colorList) {
		this.colorList = colorList;
	}

	public List getMapList() {
		return mapList;
	}

	public void setMapList(List mapList) {
		this.mapList = mapList;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	public String getDispLen() {
		return dispLen;
	}

	public void setDispLen(String dispLen) {
		this.dispLen = dispLen;
	}
	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getControllerId() {
		return controllerId;
	}

	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}

	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public String getPreview() {
		return preview;
	}

	public void setPreview(String preview) {
		this.preview = preview;
	}

	public int getMinvalue() {
		return minvalue;
	}

	public void setMinvalue(int minvalue) {
		this.minvalue = minvalue;
	}

	public int getMaxval() {
		return maxval;
	}

	public void setMaxval(int maxval) {
		this.maxval = maxval;
	}

	public List<ScreenRegionData> getSrlist() {
		return srlist;
	}

	public void setSrlist(List<ScreenRegionData> srlist) {
		this.srlist = srlist;
	}

	public String getColorvalues() {
		return colorvalues;
	}

	public void setColorvalues(String colorvalues) {
		this.colorvalues = colorvalues;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public String getRunstate() {
		return runstate;
	}

	public void setRunstate(String runstate) {
		this.runstate = runstate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getExecuteTime() {
		return executeTime;
	}

	public void setExecuteTime(String executeTime) {
		this.executeTime = executeTime;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}	
	
}
