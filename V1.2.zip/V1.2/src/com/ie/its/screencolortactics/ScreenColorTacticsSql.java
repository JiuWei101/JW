package com.ie.its.screencolortactics;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class ScreenColorTacticsSql extends ExtendSql {

	public String screen_list(ScreenColorTacticsData data,String type){
		StringBuffer querySql = new StringBuffer();
		if(type.equalsIgnoreCase("count")){
			querySql.append("select count(*)");
		}else{
			querySql.append("select ps.id as id, ps.controllerId as controllerId, pm.name as mapName, ps.code as screen, ps.contentFormat as preview");
		}
		querySql.append(" from p_screen ps left join p_map pm on ps.mapId = pm.id where 1=1 ");
		if(Util.isCon(data.getScreen())){
			querySql.append("and ps.code like ").append(Util.toSqlValLike(data.getScreen(), "ALL"));
		}
		if(Util.isCon(data.getMapId())){
			querySql.append(" and ps.mapId = ").append(Util.toSqlVal(data.getMapId()));
		}
		querySql.append(" order by ps.code");
		Log.log(querySql.toString());
		return querySql.toString();
	}
	public String get_screenregion_data(String id){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select t.id as id, t.screenAreaName as direction, t.dispColor as color, t.num as num from (select psr.id, psr.screenAreaName, psr.dispColor, count(pd.id) as num from p_screenregion psr inner join p_screen ps on psr.screenId = ps.id ");
		querySql.append("inner join p_guideregion pgr on FIND_IN_SET(pgr.code, psr.guideRegionCodeList) > 0 ");
		querySql.append("inner join p_detector pd on pd.guideRegionId = pgr.id and pd.detectorTypeId<>'2' ");
		querySql.append("inner join p_parkingspace pps on pd.id = pps.detectorid ");
		querySql.append("where psr.screenId = ").append(Util.toSqlVal(id)).append(" group by psr.id ) t order by t.id+0");
		Log.log(querySql.toString());
		return querySql.toString();
	}
	public String get_controllerId_screencode(String id){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select pc.id as controllerId, ps.code as screen from p_screen ps left join p_controller pc on ps.controllerId = pc.id where ps.id = ");
		querySql.append(Util.toSqlVal(id));
		Log.log(querySql.toString());
		return querySql.toString();
	}

	public String delete_colorstatics(String code){
		StringBuffer querySql = new StringBuffer();
		querySql.append("delete from p_colortacticstask where screens = ").append(Util.toSqlVal(code));
		return querySql.toString();
	}

	public String save_screen_colortatics(String controllerId,String screens,String colorvalues,String redcount,String yellowpercent,String notes,String userId){
		StringBuffer querySql = new StringBuffer();		
		querySql.append("insert into p_colortacticstask(id,controllerId,screens,colorvalues,redcount,yellowpercent,notes,operator,createtime,runstate) values(");
		querySql.append(Util.toSqlVal(PrimaryId.getId())).append(",");
		querySql.append(Util.toSqlVal(controllerId)).append(",");
		querySql.append(Util.toSqlVal(screens)).append(",");
		querySql.append(Util.toSqlVal(colorvalues)).append(",");
		querySql.append(Util.toSqlVal(redcount)).append(",");
		querySql.append(Util.toSqlVal(yellowpercent)).append(",");
		querySql.append(Util.toSqlVal(notes)).append(",");
		querySql.append(Util.toSqlVal(userId)).append(",");
		querySql.append("sysdate()").append(",");
		querySql.append("'0'").append(")");
		return querySql.toString();
	}
	/**
	 * Description :获得地图列表
	 * @param  :
	 * @return :String
	 */
	public String get_mapCode() {
		StringBuffer querySql = new StringBuffer();
		querySql.append("select id as code_id,name as code_name from p_map order  by id");		
		return querySql.toString();
	}

	public String color_tatics_task(ScreenColorTacticsData data,String type){
		StringBuffer querySql = new StringBuffer();
		if(type.equalsIgnoreCase("count")){
			querySql.append("select count(*) ");
		}else{
			querySql.append("select pct.id as id, ps.id as screenId, pct.screens as screen, pct.colorvalues as colorvalues, pct.redcount as minvalue, pct.yellowpercent as maxval, ");
			querySql.append("su.user_name as operator, date_format(pct.createtime,'%Y-%m-%d %H:%i:%s') as createtime, pct.runstate as runstate, pct.notes as notes ");
		}
		querySql.append("from p_colortacticstask pct inner join p_screen ps on pct.screens = ps.code left join sys_user su on pct.operator = su.id where 1=1");
		querySql.append(" order by pct.createtime desc");
		return querySql.toString();
	}

	public String color_tactics_history(ScreenColorTacticsData data,String type){
		StringBuffer querySql = new StringBuffer();
		if(type.equalsIgnoreCase("count")){
			querySql.append("select count(*) ");
		}else{
			querySql.append("select pch.id as id, ps.id as screenId, pch.controllerId as controllerId, pch.screens as screen, pch.colorvalues as colorvalues, pch.redcount as minvalue, pch.yellowpercent as maxval, ");
			querySql.append("su.user_name as operator, date_format(pch.createtime,'%Y-%m-%d %H:%i:%s') as createtime, date_format(pch.executeTime,'%Y-%m-%d %H:%i:%s') as executeTime, pch.success as runstate, pch.notes as notes, pch.duration as duration ");
		}
		querySql.append("from p_colortacticstaskhistory pch inner join p_screen ps on pch.screens = ps.code left join sys_user su on pch.operator = su.id where 1=1");
		querySql.append(" order by pch.createtime desc, pch.executeTime asc");
		return querySql.toString();
	}

	public String delete_colortactics_task(String id){
		StringBuffer querySql = new StringBuffer();
		querySql.append("delete from p_colortacticstask where id = ").append(Util.toSqlVal(id));
		return querySql.toString();
	}

	public String delete_colortactics_history(String id){
		StringBuffer querySql = new StringBuffer();
		querySql.append("delete from p_colortacticstaskhistory where id = ").append(Util.toSqlVal(id));
		return querySql.toString();
	}

	public String update_displen(String screenId, String dispLen) {
		StringBuffer querySql = new StringBuffer();
		querySql.append("update  p_screenregion set dispLen =").append(Util.toSqlVal(dispLen))
		.append(" where id =").append(Util.toSqlVal(screenId));
		return querySql.toString();
	}

	public String get_screenregion_info(String id) {
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select col.colorvalues as colorvalues from p_colortacticstask col ");
		querySql.append(" inner join p_screen ps on ps.code= col.screens");
		querySql.append(" where ps.code = ").append(Util.toSqlVal(id));
		Log.log(querySql.toString());
		return querySql.toString();
	}
}
