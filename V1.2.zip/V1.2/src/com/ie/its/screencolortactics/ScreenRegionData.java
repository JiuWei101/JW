package com.ie.its.screencolortactics;

public class ScreenRegionData{
	private String id;//区域id
	private String srcontent;//区域内容
	private String direction;//方向
	private String color;//颜色
	private int num;//引导的车位数
	
	private String minvalue;//下临界值
	private String mincolor;//下临界值颜色
	private String maxvalue;	//上临界值
	private String maxcolor;//上临界值颜色
	private String dispLen;//
	public String getDispLen() {
		return dispLen;
	}
	public void setDispLen(String dispLen) {
		this.dispLen = dispLen;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getMinvalue() {
		return minvalue;
	}
	public void setMinvalue(String minvalue) {
		this.minvalue = minvalue;
	}
	public String getMincolor() {
		return mincolor;
	}
	public void setMincolor(String mincolor) {
		this.mincolor = mincolor;
	}
	public String getMaxvalue() {
		return maxvalue;
	}
	public void setMaxvalue(String maxvalue) {
		this.maxvalue = maxvalue;
	}
	public String getMaxcolor() {
		return maxcolor;
	}
	public void setMaxcolor(String maxcolor) {
		this.maxcolor = maxcolor;
	}
	public String getSrcontent() {
		return srcontent;
	}
	public void setSrcontent(String srcontent) {
		this.srcontent = srcontent;
	}
		
}
