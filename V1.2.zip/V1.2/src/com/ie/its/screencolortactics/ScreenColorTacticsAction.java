package com.ie.its.screencolortactics;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;

@SuppressWarnings("serial")
@Namespace("/screencolortactics")
public class ScreenColorTacticsAction extends ExtendActionSupport {
	
	@Autowired
	private ScreenColorTacticsService stservice;
	private ScreenColorTacticsData data;
	public ScreenColorTacticsData getData() {
		return data;
	}
	public void setData(ScreenColorTacticsData data) {
		this.data = data;
	}
	public ScreenColorTacticsAction(){
		if(data == null){
			data = new ScreenColorTacticsData();
		}
	}
	
	@Action(value="screen_list",results={@Result(name="success",location="/screen_colortactics/colortatics_list.jsp")})
	public String screen_list(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		data = stservice.screen_list(data);
		data.setMapList(stservice.get_mapCode());
		data.setColorList(stservice.generateList(lang));
		return SUCCESS;
	}
	
	@Action(value="save_screen_colortactics",results={@Result(type="json")})
	public void save_screen_colortactics(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		JSONObject jobj = stservice.save_screen_colortactics(data.getId());
		setJsonRes(jobj);
	}
	
	@Action(value="color_tactics_task",results={@Result(name="success",location="/screen_colortactics/colortactics_task.jsp")})
	public String color_tactics_task(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		data = stservice.color_tactics_task(data);
		data.setMapList(stservice.get_mapCode());
		data.setColorList(stservice.generateList(lang));
		return SUCCESS;
	}
	
	@Action(value="color_tactics_history",results={@Result(name="success",location="/screen_colortactics/colortactics_history.jsp")})
	public String color_tactics_history(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		data = stservice.color_tactics_history(data);
		return SUCCESS;
	}
	
	@Action(value="delete_colortactics_task",results={@Result(type="json")})
	public void delete_colortactics_task(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		JSONObject jobj = stservice.delete_colortactics_task(data.getId());
		setJsonRes(jobj);
	}
	
	@Action(value="delete_colortactics_history",results={@Result(type="json")})
	public void delete_colortactics_history(){
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		//设置多语言
		setLang(data);
		JSONObject jobj = stservice.delete_colortactics_history(data.getId());
		setJsonRes(jobj);
	}
}
