package com.ie.its.role;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.IService;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.login.UserInfo;
import com.ie.its.operation.OperationData;
import com.ie.its.operation.OperationService;
import com.ie.its.user.UserData;
import com.ie.its.user.UserService;
//命名空间
@Namespace("/role")
@Results({@Result(name="list",location="/role/role_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="role_list",location="role_list.action",type="redirect")})
public class RoleAction extends ExtendActionSupport {
	
	private RoleData data;
	@Autowired
	private RoleService roleService;
	private OperationData operation;
	@Autowired
	private OperationService operationService;
	private UserData user;
	@Autowired
	private UserService userService;
	private String[] checkname = new String[1000];
	private String leftlist;
	private String rightlist;
	private String[] left;
	private String[] right;
	private String id;
	
	
	private List stateList;		// 用户状态LIST
	private List list1;
	private List list2;
	
	public RoleAction(){
		if(data == null){
			data = new RoleData();
		}
	}
	
	@Action(value="role_list")
	public String list(){
		String bl = request.getParameter("flag");
		if(bl == null){
			data.setBl("");
		}else{
			data.setBl(bl);
		}
		data = (RoleData) roleService.listData(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		this.setTarget("role_list");
		
		//设置多语言
		setLang(data);
		return "list";
	}
	
	public String readlist(){
		data = (RoleData) roleService.listData(data);
		data = (RoleData)roleService.queryData(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		this.setTarget("experson_readlist");
		return SUCCESS;
	}
	@Action(value="role_save",results={@Result(type="json")})
	public void save(){
		JSONObject json =  new JSONObject();
		
		
		if(Util.isCon(rightlist)){
			right = rightlist.split(",");   
	        for(int i=0;i<right.length;i++){   
	        	right[i].getBytes(); 
	        }   
			data.setRightlist(right);
		}
		
		try{
			data.setCheckname(checkname);
			data = (RoleData) roleService.saveData(data);
			json.element("success", true);
		}catch(Exception e){
				json.element("success", false);
				json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}
	@Action(value="role_create",results={@Result(name="create",location="/role/role_create.jsp")})
	public String create(){
		data.setId("");
		
		data.setStateList(DisposalCode.getCodeNoDefault("state", request.getSession().getAttribute("lang").toString()));
		if(operation == null){
			operation = new OperationData();
		}
		operation.setFlag("bz");
		String lang = request.getSession().getAttribute("lang").toString();//根据lang显示不同的模块名 added by LLX 2012.09.10
		operation = (OperationData) operationService.createData(operation,lang);
		request.setAttribute(ConstantClass.RQ_PER_PAGE, operation.getPer_data());
		if(user == null){
			user = new UserData();
		}
		list1 = new ArrayList();
		user = (UserData) userService.listData(user);
		List list = (ArrayList)user.getPer_data();
		for(int i=0;i<list.size();i++){
			UserData temp = (UserData)list.get(i);
			list1.add(temp);
		}
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, user.getPer_data());
		return ConstantClass.ACTION_CREATE;
	}
	
	@Action(value="role_edit",results={@Result(name="edit",location="/role/role_edit.jsp")})
	public String edit(){
		
		this.setId(request.getParameter("id"));
		data.setId(request.getParameter("id"));
		stateList = new ArrayList();
		stateList.add("启用");
		stateList.add("停用");

		data = (RoleData)roleService.readData(data);
		if(operation == null){
			operation = new OperationData();
		}
		this.setCheckname(data.getCheckname());
		operation.setFlag("bz");
		operation.setRole_id(data.getId());
		String lang = request.getSession().getAttribute("lang").toString();//根据lang显示不同的模块名 added by LLX 2012.09.10
		operation = (OperationData) operationService.queryData(operation,lang);
		request.setAttribute(ConstantClass.RQ_PER_PAGE, operation.getPer_data());
		if(user == null){
			user = new UserData();
		}
		list1 = new ArrayList();
		list2 = new ArrayList();
		data.setFlag("right");
		data = (RoleData) roleService.queryData(data);
		List list_new = (ArrayList)data.getPer_data();
		for(int i=0;i<list_new.size();i++){
			RoleData temp1 = (RoleData)list_new.get(i);
			list2.add(temp1);
		}
		data.setFlag("left");
		data = (RoleData) roleService.queryData(data);
		List list = (ArrayList)data.getPer_data();
		for(int i=0;i<list.size();i++){
			RoleData temp = (RoleData)list.get(i);
			list1.add(temp);
		}
		
		data.setStateList(DisposalCode.getCodeNoDefault("state", request.getSession().getAttribute("lang").toString()));
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, user.getPer_data());
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="role_update",results={@Result(type="json")})
	public void update(){
		JSONObject json =  new JSONObject();
		
		right = rightlist.split(",");   
        for(int i=0;i<right.length;i++){   
        	right[i].getBytes(); 
        }   
        
        try{
			data.setRightlist(right);
			data.setCheckname(checkname);
			data.setId(request.getParameter("id"));
			data = (RoleData)roleService.updateData(data);
			json.element("success", true);
        }catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	@Action(value="role_delete")
	public String delete(){
		data.setChk_record(request.getParameterValues("chk_record"));
		data = (RoleData)roleService.deleteData(data);
		
		data.setId("");
		return list();
	}
	
	@Action(value="role_invalid")
	public String invalid(){
		data = (RoleData)roleService.elseData(data, "00");
		
		data.setId("");
		return list();
	}
	
	@Action(value="role_valid")
	public String valid(){
		data = (RoleData)roleService.elseData(data, "01");
		
		data.setId("");
		return list();
	}
	
	@Action(value="role_read",results={@Result(name="read",location="/role/role_read.jsp")})
	public String read(){
		data.setId(request.getParameter("id"));
		data = (RoleData)roleService.readData(data);
		return ConstantClass.ACTION_READ;
	}
	
	@Action(value="role_check")
	public void check(){
//		String name = request.getParameter("name");
//		data = new RoleData();
		try {
//			name = java.net.URLDecoder.decode(request.getParameter("name"),"UTF-8");
			PrintWriter out;
			out = response.getWriter();
//			data.setRole_name(name);
			String str = (String) roleService.elseData(data);
			Log.log(str);
			out.print(str);
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	public RoleData getData() {
		return data;
	}

	public void setData(RoleData data) {
		this.data = data;
	}

	public List getStateList() {
		return stateList;
	}

	public void setStateList(List stateList) {
		this.stateList = stateList;
	}

	public List getList1() {
		return list1;
	}

	public void setList1(List list1) {
		this.list1 = list1;
	}

	public List getList2() {
		return list2;
	}

	public void setList2(List list2) {
		this.list2 = list2;
	}

	public OperationData getOperation() {
		return operation;
	}

	public void setOperation(OperationData operation) {
		this.operation = operation;
	}

	public UserData getUser() {
		return user;
	}

	public void setUser(UserData user) {
		this.user = user;
	}

	public RoleService getRoleService() {
		return roleService;
	}

	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}

	public OperationService getOperationService() {
		return operationService;
	}

	public void setOperationService(OperationService operationService) {
		this.operationService = operationService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String[] getCheckname() {
		return checkname;
	}

	public void setCheckname(String[] checkname) {
		this.checkname = checkname;
	}

	public String getLeftlist() {
		return leftlist;
	}

	public void setLeftlist(String leftlist) {
		this.leftlist = leftlist;
	}

	public String getRightlist() {
		return rightlist;
	}

	public void setRightlist(String rightlist) {
		this.rightlist = rightlist;
	}

	public String[] getLeft() {
		return left;
	}

	public void setLeft(String[] left) {
		this.left = left;
	}

	public String[] getRight() {
		return right;
	}

	public void setRight(String[] right) {
		this.right = right;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
