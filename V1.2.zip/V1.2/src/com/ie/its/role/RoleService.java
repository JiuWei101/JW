package com.ie.its.role;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.user.UserData;
@Scope("prototype")
@Service
public class RoleService extends ExtendService {

	public Object listData(Object o) {
		RoleData roleData = (RoleData) o;
		StringBuffer sb = new StringBuffer();
		List list = new ArrayList();
		sb.append("select count(*) from sys_role o where 1=1");
		
		if(roleData.getRole_name() != null && !"".equals(roleData.getRole_name())){
			sb.append(" and role_name like '%"+roleData.getRole_name()+"%'");
		}
		
		if(roleData.getState()!=null && !"".equals(roleData.getState()) && !"0".equals(roleData.getState())){
			sb.append(" and state = '"+roleData.getState()+"'");
		}
		
		int count = getJt().queryForInt(sb.toString());
		roleData.setTotal(count);
		
		//调用方法设置分页信息 需要参数count
		roleData.setStartExt(count);
		
		
		sb = new StringBuffer();
		sb.append("select * from sys_role o where 1=1");
		if(roleData.getRole_name() != null && !"".equals(roleData.getRole_name())){
			sb.append(" and role_name like '%"+roleData.getRole_name()+"%'");
		}
		
		if(roleData.getState()!=null && !"".equals(roleData.getState()) && !"0".equals(roleData.getState())){
			sb.append(" and state = '"+roleData.getState()+"'");
		}
		roleData.setStartExt(count);
		ArrayList <RoleData>rows = this.getJt().<RoleData>queryForListExt(sb.toString(), 
				roleData.getStart(), roleData.getLimit(),RoleData.class);
		
		roleData.setPer_data(rows);
		
		
		
		return roleData;
	}

	public Object saveData(Object o) {
		RoleData roleData = (RoleData) o;
		roleData.setId(PrimaryId.getId());
		StringBuffer sb = new StringBuffer();
		if(roleData.getState().equals("0")){
			roleData.setState("00");
		}else {
			roleData.setState("01");
		}
		sb.append("insert into sys_role(id,role_name,sort,remark,state) values('");
		sb.append(roleData.getId());
		// type3为考点，父id为2是考试机构
		sb.append("','");
		sb.append(roleData.getRole_name());
		sb.append("','");
		sb.append(roleData.getSort());
		sb.append("','");
		sb.append(roleData.getRemark());
		sb.append("','");
		sb.append(roleData.getState()+"')");
		
		getJt().update(sb.toString());

		String checkname[] = roleData.getCheckname();
		if (checkname[0] != null) {
			for (int i = 0; i < checkname.length; i++) {
				StringBuffer sb_act = new StringBuffer();
				sb_act.append("insert into sys_role_act(id,role_id,act_id) values('");
				sb_act.append(PrimaryId.getId());
				sb_act.append("','");
				sb_act.append(roleData.getId());
				sb_act.append("','");
				sb_act.append(checkname[i]);
				sb_act.append("')");
				Log.log(sb_act.toString());
				getJt().update(sb_act.toString());
			}
		}

		String rightlist[] = roleData.getRightlist();
		Log.log("------>"+rightlist.length);
		if (Util.isCon(rightlist[0])) {
			for (int i = 0; i < rightlist.length; i++) {
				StringBuffer sb_user = new StringBuffer();
				sb_user.append("insert into sys_user_role(id,role_id,user_id) values('");
				sb_user.append(PrimaryId.getId());
				sb_user.append("','");
				sb_user.append(roleData.getId());
				sb_user.append("','");
				sb_user.append(rightlist[i]);
				sb_user.append("')");
				Log.log(sb_user.toString());
				getJt().update(sb_user.toString());
			}
		}
		return o;
	}

	public Object readData(Object o) {
		RoleData roleData = (RoleData) o;
		StringBuffer sb = new StringBuffer();
		sb.append("select id,role_name,sort,state,remark from sys_role where id = '");
		sb.append(roleData.getId());
		sb.append("'");
		Log.log(sb.toString());
		List list = getJt().queryForList(sb.toString());

		StringBuffer sql = new StringBuffer();
		sql.append("select act_id from sys_role_act where role_id = '"
				+ roleData.getId() + "'");
		Log.log(sql.toString());
		List list1 = getJt().queryForList(sql.toString());
		String checkname[] = new String[list1.size()];
		for (int i = 0; i < list1.size(); i++) {
			checkname[i] = (String) ((Map) (list1.get(i))).get("act_id");
		}
		Iterator it = list.iterator();
		if (it.hasNext()) {
			Map map = (Map) it.next();
			BeanUtil.setFieldValue(roleData, map);
			roleData.setSort(map.get("sort").toString());
			roleData.setCheckname(checkname);
		}

		return roleData;
	}

	public Object updateData(Object o) {

		RoleData roleData = (RoleData) o;
		StringBuffer sb = new StringBuffer();
		sb.append("update sys_role set role_name = '");
		sb.append(roleData.getRole_name());
		sb.append("',sort='");
		sb.append(roleData.getSort());
		sb.append("',state='");
		sb.append(roleData.getState());
		sb.append("',remark='");
		sb.append(roleData.getRemark());
		sb.append("' where id = '" + roleData.getId() + "'");
		Log.log(sb.toString());
		getJt().update(sb.toString());

		getJt().update("delete from sys_role_act where role_id='" + roleData.getId()
				+ "'");
		getJt().update("delete from sys_user_role where role_id='"
				+ roleData.getId() + "'");

		String checkname[] = roleData.getCheckname();
		if (checkname[0] != null) {
			for (int i = 0; i < checkname.length; i++) {
				StringBuffer sb_act = new StringBuffer();
				sb_act.append("insert into sys_role_act(id,role_id,act_id) values('");
				sb_act.append(PrimaryId.getId());
				sb_act.append("','");
				sb_act.append(roleData.getId());
				sb_act.append("','");
				sb_act.append(checkname[i]);
				sb_act.append("')");
				Log.log(sb_act.toString());
				getJt().update(sb_act.toString());
			}
		}

		String rightlist[] = roleData.getRightlist();
		if (!rightlist[0].equals("")) {
			for (int i = 0; i < rightlist.length; i++) {
				StringBuffer sb_user = new StringBuffer();
				sb_user.append("insert into sys_user_role(id,role_id,user_id) values('");
				sb_user.append(PrimaryId.getId());
				sb_user.append("','");
				sb_user.append(roleData.getId());
				sb_user.append("','");
				sb_user.append(rightlist[i]);
				sb_user.append("')");
				Log.log(sb_user.toString());
				getJt().update(sb_user.toString());
			}
		}
		return o;
	}

	public Object deleteData(Object o) {
		RoleData roledata = (RoleData) o;
		Log.log(roledata.getChk_record());
		String[] sql = new String[roledata.getChk_record().length];
		for (int i = 0; i < roledata.getChk_record().length; i++) {
			sql[i] = "delete from sys_role where id = '"
					+ roledata.getChk_record()[i] + "'";
			Log.log(sql[i]);
		}
		String[] sql1 = new String[roledata.getChk_record().length];
		for (int i = 0; i < roledata.getChk_record().length; i++) {
			sql1[i] = "delete from sys_role_act where role_id = '"
					+ roledata.getChk_record()[i] + "'";
			Log.log(sql1[i]);
		}
		String[] sql2 = new String[roledata.getChk_record().length];
		for (int i = 0; i < roledata.getChk_record().length; i++) {
			sql2[i] = "delete from sys_user_role where role_id = '"
					+ roledata.getChk_record()[i] + "'";
			Log.log(sql2[i]);
		}
		getJt().batchUpdate(sql1);
		getJt().batchUpdate(sql2);
		getJt().batchUpdate(sql);
		return roledata;
	}

	public Object elseData(Object o) {
		RoleData roleData = (RoleData) o;
		String sql = "select count(*) from sys_role where role_name = " + Util.toSqlVal(roleData.getRole_name());
		
		if(Util.isCon(roleData.getId())){
			sql += " and id !=" + Util.toSqlVal(roleData.getId());
		}
		Log.log(sql);
		int count = getJt().queryForInt(sql);
		if (count > 0) {
			return "yes";
		}
		return "no";
	}

	public Object queryData(Object o) {
		RoleData roleData = (RoleData) o;
		StringBuffer sb = new StringBuffer();
		System.out.println("------------"+roleData.getFlag());
		if (roleData.getFlag().equals("right")) {
			sb.append("select * from sys_user a,sys_user_role b where a.id = b.user_id and b.role_id = '"
							+ roleData.getId() + "'");
			Log.log(sb.toString());
		} else {
			sb.append("select * from sys_user where id not in (select a.id from sys_user a,sys_user_role b where a.id = b.user_id and b.role_id = '"
							+ roleData.getId() + "')");
			Log.log(sb.toString());
		}
		List rows = getJt().queryForList(sb.toString());
		Iterator it = rows.iterator();
		RoleData temp = new RoleData();
		List list = new ArrayList();
		while (it.hasNext()) {
			Map map = (Map) it.next();
			temp = new RoleData();
			BeanUtil.setFieldValue(temp, map);
			// temp.setUser_id((String) map.get("id"));
			// temp.setUser_name((String) map.get("name"));
			list.add(temp);
		}
		roleData.setPer_data(list);

		return roleData;
	}
	
	public Object elseData(Object o,String str){
		RoleData roledata = (RoleData)o;
		StringBuffer sb = new StringBuffer();
		
		//停用 00 启用01 -角色的启用停用 byLLX,2012-07-20
		//停用某角色时，将删除数据库中与该角色关联的用户权限记录，启用的时候插入数据库记录。
		//故每次停用某角色后再度启用之时必须重新编辑该角色下的用户分配，否则用户能进系统却查看不了相应模块
		sb.append("update sys_role set state = ");
		sb.append(Util.toSqlVal(str));
		sb.append(" where id = ");
		sb.append(Util.toSqlVal(roledata.getId()));
		getJt().update(sb.toString());
		
		if("00".equals(str)){
			StringBuffer sb1 = new StringBuffer();
			getJt().update("delete from sys_user_role where role_id='" + roledata.getId()
					+ "'");
		}
		else{
			StringBuffer sb2 = new StringBuffer();
			String rightlist[] = roledata.getRightlist();
			Log.log("------>"+rightlist.length);
			if (Util.isCon(rightlist[0])) {
				for (int i = 0; i < rightlist.length; i++) {
					sb2.append("insert into sys_user_role(id,role_id,user_id) values('");
					sb2.append(PrimaryId.getId());
					sb2.append("','");
					sb2.append(roledata.getId());
					sb2.append("','");
					sb2.append(rightlist[i]);
					sb2.append("')");
					Log.log(sb2.toString());
					getJt().update(sb2.toString());
				}
			}
		}
		
		
		
		
		
		return o;
	}
}
