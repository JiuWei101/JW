package com.ie.its.role;

import java.util.List;
import java.util.Map;

import com.ie.frame.ExtendData;


public class RoleData extends ExtendData{
	
	private String id;
	private String role_name;
	private String sort;
	private String state;
	private String remark;
	
	private String user_id;
	private String user_name;
	
	private String flag;
	private String left;
	private List stateList;
	
	public List getStateList() {
		return stateList;
	}
	public void setStateList(List stateList) {
		this.stateList = stateList;
	}
	public String getLeft() {
		return left;
	}
	public void setLeft(String left) {
		this.left = left;
	}
	private List list;
	private List nationalitylist;
	private Map sexmap;
	private Map typemap;
	
	private String bl;
	
	private String[] leftlist = new String[1000];
	private String[] rightlist = new String[1000];
	private String[] checkname = new String[1000];
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public List getNationalitylist() {
		return nationalitylist;
	}
	public void setNationalitylist(List nationalitylist) {
		this.nationalitylist = nationalitylist;
	}
	public Map getSexmap() {
		return sexmap;
	}
	public void setSexmap(Map sexmap) {
		this.sexmap = sexmap;
	}
	public Map getTypemap() {
		return typemap;
	}
	public void setTypemap(Map typemap) {
		this.typemap = typemap;
	}
	
	public String[] getLeftlist() {
		return leftlist;
	}
	public void setLeftlist(String[] leftlist) {
		this.leftlist = leftlist;
	}
	public String[] getRightlist() {
		return rightlist;
	}
	public void setRightlist(String[] rightlist) {
		this.rightlist = rightlist;
	}
	public String[] getCheckname() {
		return checkname;
	}
	public void setCheckname(String[] checkname) {
		this.checkname = checkname;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getBl() {
		return bl;
	}
	public void setBl(String bl) {
		this.bl = bl;
	}
	
}
