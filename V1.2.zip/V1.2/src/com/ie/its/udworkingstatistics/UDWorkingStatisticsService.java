package com.ie.its.udworkingstatistics;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import static com.ie.common.Util.isCon;

import com.ie.common.DateCompare;
import com.ie.common.FileUtil;
import com.ie.common.Log;
import com.ie.frame.ExtendService;


@Scope("prototype")
@Service
public class UDWorkingStatisticsService extends ExtendService<UDWorkingStatisticsData>{
	
	private UDWorkingStatisticsSql statisticsSql;
	
	private DateCompare dateCompare;
	
	public int tempd=100;
	
	public UDWorkingStatisticsService(){
		statisticsSql = new UDWorkingStatisticsSql();
		dateCompare = new DateCompare();
	}	
	
	/**
	 * 
	 * @Description : 根据条件得出统计结果
	 * @param : @param sDate  开始时间
	 * @param : @param eDate  结束时间
	 * @param : @param detectorId  探测器编号
	 * @param : @param onDate  在此时间之前上线
	 * @param : @param outDate 在此时间之前离线
	 * @param : @param onTimes 在线次数
	 * @param : @param outTimes 离线次数
	 * @param : @return
	 * @param : @throws ParseException  
	 * @return : List 统计结果
	 * @throws : 
	 * @author : 0917
	 */
	public List<UDWorkingStatisticsData> udWorkingStatisticsService(String sDate,String eDate,String detectorId,String onDate,
			String outDate,int onTimes,int outTimes) throws ParseException{
		
		//获取统计数据
		List<UDWorkingStatisticsData> udStatisticsDataList=this.getUDWorkingStatisticsData(sDate, eDate);
				
		//根据查询条件对原始数据进行处理
		List<UDWorkingStatisticsData> rtStatisticsDataList = new ArrayList<UDWorkingStatisticsData>();
		
		for(UDWorkingStatisticsData statisticsData : udStatisticsDataList){	
			if(isCon(detectorId) && statisticsData.getMacAddr().indexOf(detectorId)==-1){  //如果没有输入过滤条件探测器编号或探测器编号不对，则不显示当前记录
				continue ;
			}
			if(isCon(onDate) && dateCompare.dateCompare(statisticsData.getLastOnTime(), onDate)){//如果没有输入过滤条件开始时间或开始时间太大，则不显示当前记录
				continue;
			}
			if(isCon(outDate) && dateCompare.dateCompare(statisticsData.getLastOutTime(), outDate)){//如果没有输入过滤条件结束时间或结束时间太小，则不显示当前记录
				continue;
			}
			if(isCon(onTimes) && onTimes>statisticsData.getOnlineTimes()){//如果没有输入过滤条件上线次数或上线次数太大，则不显示当前记录
				continue;
			}
			if(isCon(outTimes) && outTimes>statisticsData.getOutlineTimes()){//如果没有输入过滤条件离线次数或离线次数太大，则不显示当前记录
				continue;
			}
			rtStatisticsDataList.add(statisticsData);
		}
		
		return rtStatisticsDataList;
	}
	
	public  UDWorkingStatisticsData udWorkingStatisticsServiceRt(UDWorkingStatisticsData udData,String sDate,String eDate,String detectorId,String onDate,
			String outDate,int onTimes,int outTimes,int pageIndex,int pageSize) throws ParseException{
		
		//根据分页情况，显示当前页数据
		List<UDWorkingStatisticsData> rtStatisticsDataList = udWorkingStatisticsService(sDate, eDate, detectorId, onDate, outDate, onTimes, outTimes);
		
		udData.setTotal(rtStatisticsDataList.size());
		udData.setStartExt(rtStatisticsDataList.size());
		
		List<UDWorkingStatisticsData> rtStatisticsDataListTo = new ArrayList<UDWorkingStatisticsData>();
		if(rtStatisticsDataList.size()>pageSize){
			for(int i=(pageIndex-1);i<(rtStatisticsDataList.size()>(pageIndex+pageSize-1) ? (pageIndex+pageSize-1) : rtStatisticsDataList.size());i++){
				rtStatisticsDataListTo.add(rtStatisticsDataList.get(i));
			}
		}
		else{
			for(int i=0;i<rtStatisticsDataList.size();i++){
				rtStatisticsDataListTo.add(rtStatisticsDataList.get(i));
			}
		}
		udData.setPer_data(rtStatisticsDataListTo);
		return udData;
	}
	
	/**
	 * 
	 * @Description : 获取统计数据总表
	 * @param : @param sDate  统计开始时间
	 * @param : @param eDate  统计结束时间
	 * @param : @return
	 * @param : @throws ParseException  
	 * @return : 统计总表
	 * @throws : 
	 * @author : 0917
	 */
	public List<UDWorkingStatisticsData> getUDWorkingStatisticsData(String sDate,String eDate) throws ParseException{
		//使用sql语句从数据库中获取数据
		String sqlStr = statisticsSql.udWorkingDataSql(sDate,eDate);   //获取sql语句
		DateCompare dateCompare = new DateCompare();
		
		List<UDWorkingStatisticsData> getudWorkingDataList = this.getJt().queryForListExt(sqlStr, UDWorkingStatisticsData.class);
		
		//对原始数据进行处理，得出统计总表
		List<UDWorkingStatisticsData> getudStatisticsDataList= new ArrayList();
		
		for(UDWorkingStatisticsData statisticsData : getudWorkingDataList){
			if(statisticsData.getLable()==0){
				statisticsData.setLable(1);
				if(statisticsData.getConnType().equals("0")){
					statisticsData.setOnlineTimes(statisticsData.getCount());
					statisticsData.setLastOnTime(statisticsData.getDateTime());
				}
				else if(statisticsData.getConnType().equals("1")){
					statisticsData.setOutlineTimes(statisticsData.getCount());
					statisticsData.setLastOutTime(statisticsData.getDateTime());
				}
				else if(statisticsData.getConnType().equals("2")){
					statisticsData.setOutlineTimes(statisticsData.getCount());
					statisticsData.setLastOutTime(statisticsData.getDateTime());
				}
				else if(statisticsData.getConnType().equals("3")){
					statisticsData.setOutlineTimes(statisticsData.getCount());
					statisticsData.setLastOutTime(statisticsData.getDateTime());
				}
				
				for(UDWorkingStatisticsData statisticsDataTo : getudWorkingDataList){
					if(statisticsDataTo.getLable()==0 && statisticsDataTo.getDetectorId().equals(statisticsData.getDetectorId())){
						statisticsDataTo.setLable(1);
						if(statisticsDataTo.getConnType().equals("0")){
							statisticsData.setOnlineTimes(statisticsDataTo.getCount()+statisticsData.getOnlineTimes());
							if(dateCompare.dateCompare(statisticsDataTo.getDateTime(),statisticsData.getLastOnTime())){
								statisticsData.setLastOnTime(statisticsDataTo.getDateTime());
							}
						}
						else if(statisticsDataTo.getConnType().equals("1")){
							statisticsData.setOutlineTimes(statisticsDataTo.getCount()+statisticsData.getOutlineTimes());
							if(dateCompare.dateCompare(statisticsDataTo.getDateTime(),statisticsData.getLastOutTime())){
								statisticsData.setLastOutTime(statisticsDataTo.getDateTime());
							}
						}
						else if(statisticsDataTo.getConnType().equals("2")){
							statisticsData.setOutlineTimes(statisticsDataTo.getCount()+statisticsData.getOutlineTimes());
							if(dateCompare.dateCompare(statisticsDataTo.getDateTime(),statisticsData.getLastOutTime())){
								statisticsData.setLastOutTime(statisticsDataTo.getDateTime());
							}
						}
						else if(statisticsDataTo.getConnType().equals("3")){
							statisticsData.setOutlineTimes(statisticsDataTo.getCount()+statisticsData.getOutlineTimes());
							if(dateCompare.dateCompare(statisticsDataTo.getDateTime(),statisticsData.getLastOutTime())){
								statisticsData.setLastOutTime(statisticsDataTo.getDateTime());
							}
						}
					}
				}
				getudStatisticsDataList.add(statisticsData);
			}
		}
		
		return getudStatisticsDataList;
	}	
	
	//====start导出Excel=================================================================================
	public File udExportToExcel(List<UDWorkingStatisticsData> udStatisticsDataList, Map<String, Object> common) {
		// TODO 创建列表
		// TODO Auto-generated method stub
		String[] titleList = new String[]{(String) common.get("sequence"), (String) common.get("detector_id"), (String) common.get("map_name"),
				(String) common.get("detector_mac_addr"), (String) common.get("online_last_time"), (String) common.get("outline_last_time"), 
				(String) common.get("online_times"),(String) common.get("outline_times"),(String) common.get("suggest_do_bug")};
		File file = null;
		try {
			file = createFile();   //调用createFile()来创建一个excel文件
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dataIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("视频探测器运行情况统计表", 0);
			sheet.setColumnView(4, 20);
			sheet.setColumnView(5, 20);
			for (UDWorkingStatisticsData udWorkingData : udStatisticsDataList) {
				Label sequence = new Label(0, dataIndex, " " + dataIndex);		//添加序号
				sheet.addCell(sequence);
				
				Label detectorId = new Label(1, dataIndex, udWorkingData.getDetectorId());		//探测器编号
				sheet.addCell(detectorId);
				Label map = new Label(2, dataIndex, udWorkingData.getMap());		//地图名称
				sheet.addCell(map);
				Label spotCode = new Label(3, dataIndex, udWorkingData.getMacAddr());		//物理地址
				sheet.addCell(spotCode);
				Label lastOnTime = new Label(4, dataIndex, udWorkingData.getLastOnTime());		//最后一次上线时间
				sheet.addCell(lastOnTime);
				Label lastOutTime = new Label(5, dataIndex, udWorkingData.getLastOutTime());		//最后一次离线时间
				sheet.addCell(lastOutTime);
				Label onTimes = new Label(6, dataIndex, String.valueOf(udWorkingData.getOnlineTimes()));		//在线次数
				sheet.addCell(onTimes);
				Label outTimes = new Label(7, dataIndex, String.valueOf(udWorkingData.getOutlineTimes()));		//离线次数
				sheet.addCell(outTimes);
				Label suggest = new Label(8, dataIndex, udWorkingData.getSuggest());		//故障处理建议
				sheet.addCell(suggest); 
				
				++dataIndex;
			}
			
			for(int i = 0; i < 9; i++){					//添加表头
				Label title = new Label(i, 0, titleList[i]);
				sheet.addCell(title);
			}
			
			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 创建文件
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	private File createFile() throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calender = Calendar.getInstance();
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = com.ie.its.udworkingstatistics.ExpExcel.WINEXCELPATH;
		} else {
			path = com.ie.its.udworkingstatistics.ExpExcel.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + sdf.format(calender.getTime()) + ".xls");
		file.createNewFile();
		return file;
	}
	//===end导出Excel=======================================================================================
}
