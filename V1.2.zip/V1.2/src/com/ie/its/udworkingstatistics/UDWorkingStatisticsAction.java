package com.ie.its.udworkingstatistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.parkingstatistics.ParkingStatisticsData;

@Namespace("/udworkingStatistics")
@Results({@Result(name="list",location="inout_list.action",type="redirect")})
public class UDWorkingStatisticsAction extends ExtendActionSupport{

	private ParkingStatisticsData statisticsData;   //处理多语言
	//自动注入service
	
	@Autowired
	private UDWorkingStatisticsService statisticsService;
	
	//来自前台的数据
	private String startDate;        // 统计开始时间
	private String endDate;        // 统计结束时间
	private String onDate;      //在此时间之前上线
	private String outDate;     //在此时间之前离线
	private int onTimes;     //时间段内在线次数
	private int outTimes;    //时间段内离线次数
	private String detectorId;   //探测器编号
	private String macAddr;      //探测器物理地址
	
	private int start=1;
	private int limit=10;
	
	private int pageIndex = 1;   // 页码
	private int pageSize = 15;   // 每页显示的条数
	private int total;           // 总的页数
	private Object excelData;	 //要导出excel的数据
	private String downFileName;
	protected InputStream inputStream;
	
	private UDWorkingStatisticsData udWorkingStatisticsData;
	

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	private List<UDWorkingStatisticsData> udWorkingStatisticsList;  //统计数据列表
	
	public UDWorkingStatisticsAction(){
		if(statisticsData == null){
			statisticsData = new ParkingStatisticsData();
		}
		udWorkingStatisticsData = new UDWorkingStatisticsData();
	}
	
	public ParkingStatisticsData getStatisticsData() {
		return statisticsData;
	}
	public void setStatisticsData(ParkingStatisticsData statisticsData) {
		this.statisticsData = statisticsData;
	}
	
	/**
	 * 
	 * @Description : 统计视频探测器运行记录
	 * @param : @return
	 * @param : @throws ParseException  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	@Action(value="ud_working_statistics",results={@Result(name="success",location="/parking_statistics/ud_working_statistics.jsp")})
	public String ud_working_statistics() throws ParseException{
		//设置多语言
		Log.log("--ud_working_statistics-----------------------");
		
		udWorkingStatisticsData = statisticsService.udWorkingStatisticsServiceRt(udWorkingStatisticsData,startDate, endDate, detectorId, onDate, outDate, onTimes, outTimes,udWorkingStatisticsData.getStart(),udWorkingStatisticsData.getLimit());
		udWorkingStatisticsData.setLang(request.getSession().getAttribute("lang").toString());
		setLang(udWorkingStatisticsData);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, udWorkingStatisticsData.getPer_data());
		
		Log.log("--ud_working_statistics-----------------------");
		return SUCCESS;
	}
	
	//===start导出Excel============================================================================
	@Action(value="exportUDWorkingStatisticsExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportUDWorkingStatisticsExcel(){
		
		this.setLang(statisticsData);   //设置多语言
		Map<String, Object> common = (Map<String, Object>) statisticsData.getCurrent_lang_switch().get("common");
		try{
			udWorkingStatisticsList = statisticsService.udWorkingStatisticsService(startDate, endDate, detectorId, onDate, outDate, onTimes, outTimes);
			
			File file = statisticsService.udExportToExcel(udWorkingStatisticsList, common);   //将记录全部保存到file中
		    downFileName = file.getName();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return SUCCESS;
	}
	
	/**
	 * 文件下载流
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 */
	public InputStream getInputStream() throws UnsupportedEncodingException, FileNotFoundException {
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = com.ie.its.udworkingstatistics.ExpExcel.WINEXCELPATH;
		} else {
			path = com.ie.its.udworkingstatistics.ExpExcel.LINUXEXCELPATH;
		}
		
		return new FileInputStream(path + "/" + downFileName);
	}
	//===end导出Excel============================================================================
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getTotal() {
		return total;
	}

	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}

	public String getDownFileName() {
		return downFileName;
	}

	public void setUdWorkingStatisticsList(List<UDWorkingStatisticsData> udWorkingStatisticsList) {
		this.udWorkingStatisticsList = udWorkingStatisticsList;
	}

	public List<UDWorkingStatisticsData> getUdWorkingStatisticsList() {
		return udWorkingStatisticsList;
	}
	
	public String getOnDate() {
		return onDate;
	}

	public void setOnDate(String onDate) {
		this.onDate = onDate;
	}

	public String getOutDate() {
		return outDate;
	}

	public void setOutDate(String outDate) {
		this.outDate = outDate;
	}

	public int getOnTimes() {
		return onTimes;
	}

	public void setOnTimes(int onTimes) {
		this.onTimes = onTimes;
	}

	public int getOutTimes() {
		return outTimes;
	}

	public void setOutTimes(int outTimes) {
		this.outTimes = outTimes;
	}

	public String getDetectorId() {
		return detectorId;
	}

	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}

	public String getMacAddr() {
		return macAddr;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getStart() {
		return start;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getLimit() {
		return limit;
	}

	public void setUdWorkingStatisticsData(UDWorkingStatisticsData udWorkingStatisticsData) {
		this.udWorkingStatisticsData = udWorkingStatisticsData;
	}

	public UDWorkingStatisticsData getUdWorkingStatisticsData() {
		return udWorkingStatisticsData;
	}
}
