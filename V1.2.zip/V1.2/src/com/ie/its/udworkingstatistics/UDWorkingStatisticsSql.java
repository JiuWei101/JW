package com.ie.its.udworkingstatistics;

import static com.ie.common.Util.isCon;
import static com.ie.common.Util.toSqlVal;

public class UDWorkingStatisticsSql {
	
	/**
	 * 
	 * @Description : 统计p_ctrlerconnstate表中的数据，得出包含上线和离线次数的统计总表。
	 * @param : @param sDate
	 * @param : @param eDate
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String udWorkingDataSql(String sDate,String eDate){
		String sqlStr = "select count(connType) as count, p.id as detectorId,m.name as map,date_format(max(c.dateTime),'%Y-%m-%d %T') as dateTime,c.connType,c.id as oid,c.macAddr as macAddr ";
		sqlStr += "from p_ctrlerconnstate as c INNER JOIN p_controller as p on c.macAddr=p.addr INNER JOIN p_map as m on p.mapId=m.id where 1=1";
		if(isCon(sDate)){
			sqlStr += " and c.dateTime>=" + toSqlVal(sDate);
		}
		if(isCon(eDate)){
			sqlStr += " and c.dateTime<=" + toSqlVal(eDate);
		}
		sqlStr += " group by macAddr, connType order by dateTime";
		
		return sqlStr;
	}
}
