package com.ie.its.udworkingstatistics;

import java.io.Serializable;
import com.ie.frame.ExtendData;

/**
 *  
 * @Description: 视频探测器运行记录统计分析数据
 * @auth: 0917
 * @data: 2014-9-29 下午02:09:55
 * @version:  
 *
 */
public class UDWorkingStatisticsData extends ExtendData implements Serializable{

	private String detectorId;   //探测器ID
	private String lastOnTime="0000-00-00 00:00:00";   //最后上线时间
	private String lastOutTime="0000-00-00 00:00:00";  //最后离线时间
	private int onlineTimes=0;  //在线次数
	private int outlineTimes=0; //离线次数
	 
	private String suggest;      //故障处理建议
	
	private String map;    //地图名称
	private String spotCode;  //车位编号
	private String dateTime;  //记录发生时间
	private String connType;  //连接类型
	private String macAddr;   //物理地址
	private int lable=0;    //标记该记录是否已经遍历
	private String oid;     //获取的记录id,在遍历时会使用
	private int count;   //上线或离线次数
	
	@Override
	public String toString() {
		return "UDWorkingStatisticsData [detectorId=" + detectorId + ", lastOnTime=" + lastOnTime
				+ ", lastOutTime=" + lastOutTime + ", onlineTimes="+ ", oid=" + oid
				+ onlineTimes + ", outlineTimes=" + outlineTimes + ", suggest="+ ", macAddr=" + macAddr
				+ suggest + "]";
	}
	
	
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}
	public String getDetectorId() {
		return detectorId;
	}
	public void setLastOnTime(String lastOnTime) {
		this.lastOnTime = lastOnTime;
	}
	public String getLastOnTime() {
		return lastOnTime;
	}
	public void setLastOutTime(String lastOutTime) {
		this.lastOutTime = lastOutTime;
	}
	public String getLastOutTime() {
		return lastOutTime;
	}
	public void setOnlineTimes(int onlineTimes) {
		this.onlineTimes = onlineTimes;
	}
	public int getOnlineTimes() {
		return onlineTimes;
	}
	public void setOutlineTimes(int outlineTimes) {
		this.outlineTimes = outlineTimes;
	}
	public int getOutlineTimes() {
		return outlineTimes;
	}
	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}
	public String getSuggest() {
		return suggest;
	}


	public void setMap(String map) {
		this.map = map;
	}


	public String getMap() {
		return map;
	}


	public void setSpotCode(String spotCode) {
		this.spotCode = spotCode;
	}


	public String getSpotCode() {
		return spotCode;
	}


	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}


	public String getDateTime() {
		return dateTime;
	}


	public void setConnType(String connType) {
		this.connType = connType;
	}


	public String getConnType() {
		return connType;
	}


	public void setLable(int lable) {
		this.lable = lable;
	}


	public int getLable() {
		return lable;
	}


	public void setOid(String oid) {
		this.oid = oid;
	}


	public String getOid() {
		return oid;
	}


	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}


	public String getMacAddr() {
		return macAddr;
	}


	public void setCount(int count) {
		this.count = count;
	}


	public int getCount() {
		return count;
	}
}
