package com.ie.its.debugtool;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.imageio.ImageIO;

import com.ie.common.Log;

public class ToolUtil {
	
	public static Map TASK_STATUS = new HashMap();	//值对<MAC地址后4位，任务执行状态>（没有记录表示无任务，1表示任务执行中，0表示任务执行完成）
	public static String SERVER_IP;
	public static int SERVER_PORT;
	protected static String bytePacketStr(byte[] buff, String splitStr) {
		StringBuilder sb = new StringBuilder();
		for (byte b : buff) {
			Integer i = Integer.parseInt(
					Integer.toHexString(Integer.valueOf(b) & 0x000000FF), 16);
			sb.append(i).append(splitStr);
		}
		return sb.substring(0, sb.length() - 1);
	}
	
	/**
	 * 封装返回到前台的数据
	 * @param buffer   发送到终端的数据格式
	 * @param status   返回的结果
	 * @return
	 */
	protected static String packString(byte[] buffer, String split) {
		StringBuilder sb = new StringBuilder();
		if (buffer != null) {
			for (byte buff : buffer) {
				String hexStr = Integer.toHexString(buff & 0x000000FF); // 转成16进制
				sb.append(hexStr.length() == 1 ? 0 + hexStr : hexStr).append(split);
			}
		}
		if(sb.length() > 0){
			sb = sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}
	
	protected static String byteToString(byte[] buff){
		StringBuffer sb = new StringBuffer();
		for(byte b : buff){
			String s = Integer.toHexString(Integer.valueOf(b) & 0x000000FF);
			sb.append(s);
		}
		return sb.toString();
	}
	
	/**
	 * String 转成 byte[]
	 * @param address
	 * @param radix 进制数
	 * @return
	 */
	protected static byte[] stringToBytes(String data, String split, int radix) {
		String[] datas = data.split(split);
		byte[] buff = new byte[datas.length];
		for (int i = 0; i < datas.length; i++) {
			buff[i] = (byte) Integer.parseInt(datas[i], radix);	//转10进制的字符串
		}
		return buff;
	}
	
	/**
	 * 组合两个byte数据
	 * @return
	 */
	protected static byte[] combineTwoByteArr(byte[] one,byte[] ano){
		int oneLen = one.length;
		int anoLen = ano.length;
		byte[] result = new byte[oneLen+anoLen];
		System.arraycopy(one, 0, result, 0, oneLen);
		System.arraycopy(ano, 0, result, oneLen, anoLen);
		return result;
	}
	
	/**
	 * 组合一组byte数组
	 * @param list
	 * @return
	 */
	protected static byte[] combineByteArrList(List<byte[]> list){
		int len = 0;//所有byte数组的总大小
		for(byte[] b : list){
			len += b.length;
		}
		byte[] result = new byte[len];
		int clen = 0;//当前已处理的byte数据大小
		for(byte[] b : list){
			System.arraycopy(b, 0, result, clen, b.length);
			clen += b.length;
		}
		return result;
	}
	
	/**
	 * 将byte数组bRefArr转为一个整数,字节数组的低位是整型的低字节位
	 * 高8位在后,低8位在前
	 * @param bRefArr
	 * @return
	 */
	protected static int bytesToIntLTH(byte[] bRefArr) {
		int iOutcome = 0;
		byte bLoop;
		for (int i = 0; i < bRefArr.length; i++) {
			bLoop = bRefArr[i];
			iOutcome += (bLoop & 0x000000FF) << (8 * (i)); // 高8位在后,低8位在前
		}
		return iOutcome;
	}
	
	/**
	 * int类型转换成byte[]
	 * @param num	要转换的数据
	 * @param length 要转成几位字节
	 * @return byte[]	高字节在前,低字节在后
	 */
	protected static byte[] intToBytes(int num, int length) {
		byte[] bytes = new byte[length];
		for (int i = 0; i < length; i++) {
			bytes[i] = (byte)((num >> (length - i - 1) * 8) & 0x000000FF);
		}
		return bytes;
	}
	
	/**
	 * 将byte数组bRefArr转为一个整数,字节数组的低位是整型的低字节位
	 * 高8位在前,低8位在后
	 * @param bRefArr
	 * @return
	 */
	protected static int bytesToIntHTL(byte[] bRefArr) {
		int iOutcome = 0, size = bRefArr.length - 1;
		byte bLoop;
		for (int i = 0; i < bRefArr.length; i++) {
			bLoop = bRefArr[i];
			int unsignedByte = bLoop >= 0 ? bLoop : (256 + bLoop);
			iOutcome += (unsignedByte & 0x000000FF) << (8 * (size--)); // 高8位在前,低8位在后
		}
		return iOutcome;
	}
	
	/**
	 * 将四个字节低位在前、高位在后的数据转变为整数
	 * @param src
	 * @return
	 */
	protected static int fourBytesToInt(byte[] src){
		int r = src[0] & 0xFF;
		r |= ((src[1] << 8) & 0xFF00);
		r |= ((src[2] << 16) & 0xFF0000);
		r |= ((src[3] << 24) & 0xFF000000);
		return r;
	}
	
	public static void main(String[] args) {
//		String mac = "68-9c-5e-e6-d7-6c";
//		byte[] macarr = stringToBytes(mac, "-", 16);
//		for(byte b : macarr){
//			System.out.println(b);
//		}
	}
	
	public static Map getProperties(String fname,String... args){
		Map map = new HashMap();
		FileInputStream fis = null;
		String path = "";
		try {
			path = Thread.currentThread().getContextClassLoader().getResource("").getPath();
			File file = new File(path + fname);
			fis = new FileInputStream(file);
			Properties pro = new Properties();
			pro.load(fis);
			for(String s:args){
				if(pro.containsKey(s)){
					map.put(s, pro.get(s).toString());
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Log.log(path+fname+"文件不存在");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(fis != null){
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public static boolean setProperties(String fname, Map map){
		boolean flag = false;
		String path = "";
		FileInputStream fis =null;
		FileOutputStream fos = null;
		try {
			path = Thread.currentThread().getContextClassLoader().getResource("").getPath()+fname;
			fis = new FileInputStream(path);
			Properties pro = new Properties();
			pro.load(fis);
			Iterator iter = map.keySet().iterator();
			boolean bflag = true;
			while(iter.hasNext()){
				String s = (String)iter.next();
				if(pro.containsKey(s)){
					pro.setProperty(s, (String) map.get(s));
				}else{
					bflag = false;
				}
			}
			if(bflag){
				flag = true;
			}
			fos = new FileOutputStream(path);
			pro.store(fos, null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			Log.log(path+"文件不存在");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * 获取图片的宽度和高度
	 * @param path 图片文件路径
	 * @return 宽度和高度组成的数组
	 */
	public static int[] getImageWidthHeight(String path){
		int[] r = new int[2];
		try {
			BufferedImage img = ImageIO.read(new File(path));
			r[0] = img.getWidth();
			r[1] = img.getHeight();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}
}
