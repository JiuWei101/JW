package com.ie.its.debugtool;

public class CarData {
	private int cameraId;					//所对应的摄像头id
	private int carCode;					//车位编号，目前为0或1
	private String parkingSpaceType;		//车位类型
	private String parkingSpaceStatus;		//车位状态
	private int plateLen;					//车牌号长度
	private String plateData;				//车牌号数据
	private long pictureLen;				//图片内容长度
	private String picPath;					//图片存储路径
	
	private int topLeftCornerX;				//左上角X坐标
	private int topLeftCornerY;				//左上角Y坐标
	private int bottomRightCornerX;			//右上角X坐标
	private int bottomRightCornerY;			//右上角Y坐标
	
	private int picWidth;
	private int picHeight;
	
	public CarData(){
		
	}
	public CarData(int carCode){
		this.carCode = carCode;
	}
	public int getCameraId() {
		return cameraId;
	}
	public void setCameraId(int cameraId) {
		this.cameraId = cameraId;
	}
	public int getCarCode() {
		return carCode;
	}
	public void setCarCode(int carCode) {
		this.carCode = carCode;
	}
	public String getParkingSpaceType() {
		return parkingSpaceType;
	}
	public void setParkingSpaceType(String parkingSpaceType) {
		this.parkingSpaceType = parkingSpaceType;
	}
	public String getParkingSpaceStatus() {
		return parkingSpaceStatus;
	}
	public void setParkingSpaceStatus(String parkingSpaceStatus) {
		this.parkingSpaceStatus = parkingSpaceStatus;
	}
	public int getPlateLen() {
		return plateLen;
	}
	public void setPlateLen(int plateLen) {
		this.plateLen = plateLen;
	}
	public String getPlateData() {
		return plateData;
	}
	public void setPlateData(String plateData) {
		this.plateData = plateData;
	}
	public long getPictureLen() {
		return pictureLen;
	}
	public void setPictureLen(long pictureLen) {
		this.pictureLen = pictureLen;
	}
	public String getPicPath() {
		return picPath;
	}
	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}
	public int getTopLeftCornerX() {
		return topLeftCornerX;
	}
	public void setTopLeftCornerX(int topLeftCornerX) {
		this.topLeftCornerX = topLeftCornerX;
	}
	public int getTopLeftCornerY() {
		return topLeftCornerY;
	}
	public void setTopLeftCornerY(int topLeftCornerY) {
		this.topLeftCornerY = topLeftCornerY;
	}
	public int getBottomRightCornerX() {
		return bottomRightCornerX;
	}
	public void setBottomRightCornerX(int bottomRightCornerX) {
		this.bottomRightCornerX = bottomRightCornerX;
	}
	public int getBottomRightCornerY() {
		return bottomRightCornerY;
	}
	public void setBottomRightCornerY(int bottomRightCornerY) {
		this.bottomRightCornerY = bottomRightCornerY;
	}
	public int getPicWidth() {
		return picWidth;
	}
	public void setPicWidth(int picWidth) {
		this.picWidth = picWidth;
	}
	public int getPicHeight() {
		return picHeight;
	}
	public void setPicHeight(int picHeight) {
		this.picHeight = picHeight;
	}
}
