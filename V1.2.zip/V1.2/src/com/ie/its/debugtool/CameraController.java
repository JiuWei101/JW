package com.ie.its.debugtool;

import java.util.List;

import com.ie.frame.ExtendData;

/**
 * 视频探测器
 * @author wangj
 * @date   2013-08-02
 */
public class CameraController extends ExtendData{
	private String ipaddress; 	//IP地址
	private String ipport;	  	//IP端口
	private String ipmask;		//子网掩码
	private String networkgate;  //默认网关
	private String macaddress;	//MAC地址
	private int shootperiod;	//拍照周期
	private String eqversion;	//设备版本号
	
	private String terminalIP;	//终端机IP
	private String terminalPort; //终端机Port
	
	private String preferAP;	//默认连接AP
	private String encryptType; //加密方式
	private String secretKey;   //秘钥
	
	
	private int minPlateWidth;//检测的最小车牌宽度，以像素为单位，默认80
	private int maxPlateWidth;//检测的最大车牌宽度，以像素为单位，默认200
	private int maxImageWidth;//实际图像最大宽度 最大2048 请勿修改，默认640
	private int maxImageHeight;//实际图像最大高度 最大1536 请勿修改，默认480
	private String isVertCompress;//是否垂直方向压缩1倍后识别，默认0
	private String isFieldImage;//是否是场图像 ，默认0
	private String isOptSimpleFrame;//是否视频图像中同一个车的多幅图像只输出一次结果，默认0
	private String isMovingImage;//识别运动or静止图像，默认0
	private String isNight;//是否夜间模式，默认0
	private int imageFormat;//NV21，默认6
	private String optOrder;//输出顺序选项 0-置信度 1-自上而下 2-自下而上，默认0
	private String isLeanCorrect;//是否启用倾斜校正功能，默认0
	private String movingOutputOpt;//0-内部推送+外部获取 1:外部获取，默认0
	private String identifyMode;//识别模式，0: 识别率优先 1:识别速度优先，默认0
	private String isEvaColor;//是否识别车辆颜色，默认0
	private String isVertFlip;//是否位图，默认0
	private String isDwordAligned;//是否位图，默认0
	private int provinceLen;//省份字符串长度，默认0
	private String provinces;//省份字符串，默认无
	private int plateLocateShre;//车牌定位阈值，默认5
	private int plateIdentShre;//车牌识别阈值，默认1
	private String indiviPlate;//个性化车牌，默认0
	private String doubleYelPlate;//双层黄色车牌
	private String armPolicePlate;//武警车牌，默认1
	private String doubleMilPlate;//双层军车
	private String farmPlate;//农用车
	private String emPlate;//使领馆车
	private String dbArmPoliPlate;//双层武警车
	private String isDetectCar;//是否检测车辆
	private String recognitionLibType;//识别库类型（0大陆，1台湾）
	private int reservedLen;//保留字符串长度
	private String reservedStr;//保留字符串
	
	private int cameraNum;	//视频探测器上带有的摄像头数量
	private int carCode;	//车位编号对应的探测器编号 
	private List<Camera> clist;	//视频探测器上带有的摄像头属性
	
	private String detectors;	//摄像头信息
	
	private List yesOrnoList;	//是或否下拉框
	private List movingOutputOptList; //获取方式下拉框
	private List improveSpeedList; //识别模式下拉框
	private List orderOptList; //输出顺序下拉框
	private List encryptTypeList; //加密类型下拉框
	private List exposureList;	  //曝光度下拉列表
	private List photoModeList;	  //拍照模式下拉列表
	private List parkingSpaceTypeList;	//车位类型下拉列表
	private List parkingSpaceStatusList;	//车位状态下拉列表
	private String shortmac;	//后四位MAC地址
	
	
	
	public String getShortmac() {
		return shortmac;
	}
	public void setShortmac(String shortmac) {
		this.shortmac = shortmac;
	}
	public List getYesOrnoList() {
		return yesOrnoList;
	}
	public void setYesOrnoList(List yesOrnoList) {
		this.yesOrnoList = yesOrnoList;
	}
	public List getMovingOutputOptList() {
		return movingOutputOptList;
	}
	public void setMovingOutputOptList(List movingOutputOptList) {
		this.movingOutputOptList = movingOutputOptList;
	}
	public List getImproveSpeedList() {
		return improveSpeedList;
	}
	public void setImproveSpeedList(List improveSpeedList) {
		this.improveSpeedList = improveSpeedList;
	}
	public List getOrderOptList() {
		return orderOptList;
	}
	public void setOrderOptList(List orderOptList) {
		this.orderOptList = orderOptList;
	}
	public String getDetectors() {
		return detectors;
	}
	public void setDetectors(String detectors) {
		this.detectors = detectors;
	}
	public int getCameraNum() {
		return cameraNum;
	}
	public void setCameraNum(int cameraNum) {
		this.cameraNum = cameraNum;
	}
	public List<Camera> getClist() {
		return clist;
	}
	public void setClist(List<Camera> clist) {
		this.clist = clist;
	}
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getIpport() {
		return ipport;
	}
	public void setIpport(String ipport) {
		this.ipport = ipport;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	public int getShootperiod() {
		return shootperiod;
	}
	public void setShootperiod(int shootperiod) {
		this.shootperiod = shootperiod;
	}
	public String getEqversion() {
		return eqversion;
	}
	public void setEqversion(String eqversion) {
		this.eqversion = eqversion;
	}
	public String getPreferAP() {
		return preferAP;
	}
	public void setPreferAP(String preferAP) {
		this.preferAP = preferAP;
	}
	public int getMinPlateWidth() {
		return minPlateWidth;
	}
	public void setMinPlateWidth(int minPlateWidth) {
		this.minPlateWidth = minPlateWidth;
	}
	public int getMaxPlateWidth() {
		return maxPlateWidth;
	}
	public void setMaxPlateWidth(int maxPlateWidth) {
		this.maxPlateWidth = maxPlateWidth;
	}
	public int getMaxImageWidth() {
		return maxImageWidth;
	}
	public void setMaxImageWidth(int maxImageWidth) {
		this.maxImageWidth = maxImageWidth;
	}
	public int getMaxImageHeight() {
		return maxImageHeight;
	}
	public void setMaxImageHeight(int maxImageHeight) {
		this.maxImageHeight = maxImageHeight;
	}
	public String getIsVertCompress() {
		return isVertCompress;
	}
	public void setIsVertCompress(String isVertCompress) {
		this.isVertCompress = isVertCompress;
	}
	public String getIsFieldImage() {
		return isFieldImage;
	}
	public void setIsFieldImage(String isFieldImage) {
		this.isFieldImage = isFieldImage;
	}
	public String getIsOptSimpleFrame() {
		return isOptSimpleFrame;
	}
	public void setIsOptSimpleFrame(String isOptSimpleFrame) {
		this.isOptSimpleFrame = isOptSimpleFrame;
	}
	public String getIsMovingImage() {
		return isMovingImage;
	}
	public void setIsMovingImage(String isMovingImage) {
		this.isMovingImage = isMovingImage;
	}
	public String getIsNight() {
		return isNight;
	}
	public void setIsNight(String isNight) {
		this.isNight = isNight;
	}
	public int getImageFormat() {
		return imageFormat;
	}
	public void setImageFormat(int imageFormat) {
		this.imageFormat = imageFormat;
	}
	public String getOptOrder() {
		return optOrder;
	}
	public void setOptOrder(String optOrder) {
		this.optOrder = optOrder;
	}
	public String getIsLeanCorrect() {
		return isLeanCorrect;
	}
	public void setIsLeanCorrect(String isLeanCorrect) {
		this.isLeanCorrect = isLeanCorrect;
	}
	public String getMovingOutputOpt() {
		return movingOutputOpt;
	}
	public void setMovingOutputOpt(String movingOutputOpt) {
		this.movingOutputOpt = movingOutputOpt;
	}
	public String getIdentifyMode() {
		return identifyMode;
	}
	public void setIdentifyMode(String identifyMode) {
		this.identifyMode = identifyMode;
	}
	public String getIsEvaColor() {
		return isEvaColor;
	}
	public void setIsEvaColor(String isEvaColor) {
		this.isEvaColor = isEvaColor;
	}
	public String getIsVertFlip() {
		return isVertFlip;
	}
	public void setIsVertFlip(String isVertFlip) {
		this.isVertFlip = isVertFlip;
	}
	public String getIsDwordAligned() {
		return isDwordAligned;
	}
	public void setIsDwordAligned(String isDwordAligned) {
		this.isDwordAligned = isDwordAligned;
	}
	public int getProvinceLen() {
		return provinceLen;
	}
	public void setProvinceLen(int provinceLen) {
		this.provinceLen = provinceLen;
	}
	public String getProvinces() {
		return provinces;
	}
	public void setProvinces(String provinces) {
		this.provinces = provinces;
	}
	public int getPlateLocateShre() {
		return plateLocateShre;
	}
	public void setPlateLocateShre(int plateLocateShre) {
		this.plateLocateShre = plateLocateShre;
	}
	public int getPlateIdentShre() {
		return plateIdentShre;
	}
	public void setPlateIdentShre(int plateIdentShre) {
		this.plateIdentShre = plateIdentShre;
	}
	public String getIndiviPlate() {
		return indiviPlate;
	}
	public void setIndiviPlate(String indiviPlate) {
		this.indiviPlate = indiviPlate;
	}
	public String getDoubleYelPlate() {
		return doubleYelPlate;
	}
	public void setDoubleYelPlate(String doubleYelPlate) {
		this.doubleYelPlate = doubleYelPlate;
	}
	public String getArmPolicePlate() {
		return armPolicePlate;
	}
	public void setArmPolicePlate(String armPolicePlate) {
		this.armPolicePlate = armPolicePlate;
	}
	public String getDoubleMilPlate() {
		return doubleMilPlate;
	}
	public void setDoubleMilPlate(String doubleMilPlate) {
		this.doubleMilPlate = doubleMilPlate;
	}
	public String getFarmPlate() {
		return farmPlate;
	}
	public void setFarmPlate(String farmPlate) {
		this.farmPlate = farmPlate;
	}
	public String getEmPlate() {
		return emPlate;
	}
	public void setEmPlate(String emPlate) {
		this.emPlate = emPlate;
	}
	public String getDbArmPoliPlate() {
		return dbArmPoliPlate;
	}
	public void setDbArmPoliPlate(String dbArmPoliPlate) {
		this.dbArmPoliPlate = dbArmPoliPlate;
	}
	public String getIsDetectCar() {
		return isDetectCar;
	}
	public void setIsDetectCar(String isDetectCar) {
		this.isDetectCar = isDetectCar;
	}
	public int getReservedLen() {
		return reservedLen;
	}
	public void setReservedLen(int reservedLen) {
		this.reservedLen = reservedLen;
	}
	public String getReservedStr() {
		return reservedStr;
	}
	public void setReservedStr(String reservedStr) {
		this.reservedStr = reservedStr;
	}
	public String getTerminalIP() {
		return terminalIP;
	}
	public void setTerminalIP(String terminalIP) {
		this.terminalIP = terminalIP;
	}
	public String getTerminalPort() {
		return terminalPort;
	}
	public void setTerminalPort(String terminalPort) {
		this.terminalPort = terminalPort;
	}
	public String getEncryptType() {
		return encryptType;
	}
	public void setEncryptType(String encryptType) {
		this.encryptType = encryptType;
	}
	public String getSecretKey() {
		return secretKey;
	}
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	public List getEncryptTypeList() {
		return encryptTypeList;
	}
	public void setEncryptTypeList(List encryptTypeList) {
		this.encryptTypeList = encryptTypeList;
	}
	public String getIpmask() {
		return ipmask;
	}
	public void setIpmask(String ipmask) {
		this.ipmask = ipmask;
	}
	public String getNetworkgate() {
		return networkgate;
	}
	public void setNetworkgate(String networkgate) {
		this.networkgate = networkgate;
	}
	public List getExposureList() {
		return exposureList;
	}
	public void setExposureList(List exposureList) {
		this.exposureList = exposureList;
	}
	public List getPhotoModeList() {
		return photoModeList;
	}
	public void setPhotoModeList(List photoModeList) {
		this.photoModeList = photoModeList;
	}
	public List getParkingSpaceTypeList() {
		return parkingSpaceTypeList;
	}
	public void setParkingSpaceTypeList(List parkingSpaceTypeList) {
		this.parkingSpaceTypeList = parkingSpaceTypeList;
	}
	public List getParkingSpaceStatusList() {
		return parkingSpaceStatusList;
	}
	public void setParkingSpaceStatusList(List parkingSpaceStatusList) {
		this.parkingSpaceStatusList = parkingSpaceStatusList;
	}
	@Override
	public String toString() {
		return "CameraController [ipaddress=" + ipaddress + ", ipport="
				+ ipport + ", ipmask=" + ipmask + ", networkgate="
				+ networkgate + ", macaddress=" + macaddress + ", shootperiod="
				+ shootperiod + ", eqversion=" + eqversion + ", terminalIP="
				+ terminalIP + ", terminalPort=" + terminalPort + ", preferAP="
				+ preferAP + ", encryptType=" + encryptType + ", secretKey="
				+ secretKey + ", minPlateWidth=" + minPlateWidth
				+ ", maxPlateWidth=" + maxPlateWidth + ", maxImageWidth="
				+ maxImageWidth + ", maxImageHeight=" + maxImageHeight
				+ ", isVertCompress=" + isVertCompress + ", isFieldImage="
				+ isFieldImage + ", isOptSimpleFrame=" + isOptSimpleFrame
				+ ", isMovingImage=" + isMovingImage + ", isNight=" + isNight
				+ ", imageFormat=" + imageFormat + ", optOrder=" + optOrder
				+ ", isLeanCorrect=" + isLeanCorrect + ", movingOutputOpt="
				+ movingOutputOpt + ", identifyMode=" + identifyMode
				+ ", isEvaColor=" + isEvaColor + ", isVertFlip=" + isVertFlip
				+ ", isDwordAligned=" + isDwordAligned + ", provinceLen="
				+ provinceLen + ", provinces=" + provinces
				+ ", plateLocateShre=" + plateLocateShre + ", plateIdentShre="
				+ plateIdentShre + ", indiviPlate=" + indiviPlate
				+ ", doubleYelPlate=" + doubleYelPlate + ", armPolicePlate="
				+ armPolicePlate + ", doubleMilPlate=" + doubleMilPlate
				+ ", farmPlate=" + farmPlate + ", emPlate=" + emPlate
				+ ", dbArmPoliPlate=" + dbArmPoliPlate + ", isDetectCar="
				+ isDetectCar + ", reservedLen=" + reservedLen
				+ ", reservedStr=" + reservedStr + ", cameraNum=" + cameraNum
				+ ", carCode=" + carCode + ", clist=" + clist + ", detectors="
				+ detectors + ", yesOrnoList=" + yesOrnoList
				+ ", movingOutputOptList=" + movingOutputOptList
				+ ", improveSpeedList=" + improveSpeedList + ", orderOptList="
				+ orderOptList + ", encryptTypeList=" + encryptTypeList
				+ ", exposureList=" + exposureList + ", photoModeList="
				+ photoModeList + ", parkingSpaceTypeList="
				+ parkingSpaceTypeList + ", parkingSpaceStatusList="
				+ parkingSpaceStatusList + ", shortmac=" + shortmac + "]";
	}
	public int getCarCode() {
		return carCode;
	}
	public void setCarCode(int carCode) {
		this.carCode = carCode;
	}
	public String getRecognitionLibType() {
		return recognitionLibType;
	}
	public void setRecognitionLibType(String recognitionLibType) {
		this.recognitionLibType = recognitionLibType;
	}	
}
