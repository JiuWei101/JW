package com.ie.its.debugtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.stereotype.Service;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.common.Util;
import com.ie.frame.ExtendService;

@SuppressWarnings("rawtypes")
@Service
public class DebugToolService extends ExtendService {
	private final String serverIp = new OperatePro().queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.PGSSERVERIP);
	private final int serverPort = Integer.parseInt(new OperatePro().queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.PGSSERVERPORT));
	
	public JSONArray getMapList(String mapId){
		String querySql = " select name ,id from p_map order by id";
		JSONArray jarr = this.getJt().queryJson(querySql);
		if(Util.isCon(mapId)){
			for(int i=0; i<jarr.size(); i++){
				JSONObject temp = jarr.getJSONObject(i);
				if(temp.getString("id").equals(mapId)){
					temp.element("selected", true);
				}
			}
		}else{
			for(int i=0; i<jarr.size(); i++){
				JSONObject temp = jarr.getJSONObject(i);
				if(0 == i){
					temp.element("selected", true);
				}
			}
		}
		return jarr;
	}
	
	public String getMapPath(String mapId){
		String rpath = "";
		String sql = "";
		if(Util.isCon(mapId)){
			sql = "select path from p_map where id ='"+mapId+"'";
		}else{
			sql = "select path from p_map order by id limit 1";
		}
		String path = null;
		try {
			path = this.getJt().queryForObject(sql, String.class);
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(Util.isCon(path)){
			rpath = splitMapSrc(path);
		}
		return rpath;
	}
	
	private String splitMapSrc(String path) {
		String src = "";
		String path_split[] = path.split(ConstantClass.MAP_DIR);
		src = "../" + ConstantClass.MAP_DIR + path_split[1];
		return src;
	}
	
	/**
	 * 获取车位状态
	 * @param cdata
	 * @return
	 */
	public JSONObject getAllCarStatus(CameraController cdata){
		
		JSONObject jobj = new JSONObject();
		String addr = cdata.getShortmac();//探测器mac地址后四位
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				JSONObject IPAndPort = cs.readDetectorIpA8(addr);
				if((Boolean) IPAndPort.get("success")){//第一个读取成功后才继续读取
					List<CarData> list = cs.readMultiCarStatusA1(addr);//读取所有车位状态
					JSONArray jarr = JSONArray.fromObject(list);
					System.out.println(jarr);
					jobj.element("carlist", jarr);
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "探测器通讯不正常");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
		}
		if(cs.getSocket() != null)
			cs.closeSocket();				//断开连接
		
		return jobj;
	}
	
	public JSONObject getAllCarStatustest(CameraController cdata){
		JSONObject jobj = new JSONObject();
		String addr = cdata.getShortmac();//探测器mac地址后四位
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				JSONObject IPAndPort = cs.readDetectorIpA8(addr);
				if((Boolean) IPAndPort.get("success")){//第一个读取成功后才继续读取
					List<CarData> list = cs.readMultiCarStatusA1(addr);//读取所有车位状态
					JSONArray jarr = JSONArray.fromObject(list);
					System.out.println(jarr);
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "探测器通讯不正常");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
		}
		if(cs.getSocket() != null)
			cs.closeSocket();				//断开连接
		return jobj;
	}
	
	/**
	 * 获取单个车位的状态和区域
	 * @param cdata
	 * @return
	 */
	public JSONObject getSingleCarService(CameraController cdata){
		JSONObject jobj = new JSONObject();
		String addr = cdata.getShortmac();//探测器mac地址后四位
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				JSONObject IPAndPort = cs.readDetectorIpA8(addr);
				if((Boolean) IPAndPort.get("success")){//第一个读取成功后才继续读取
					CarData carData = new CarData();
					carData.setCarCode(cdata.getCarCode());
					Map map = cs.readSingleCarStatusA0(1, carData, "", addr, "");			//先读取图片
					if(cs.getSocket() != null)
						cs.closeSocket();				//断开连接
					JSONObject json = getCycleJson(carData, addr);	//再读取识别区域
					groupMap(map, json);
					JSONArray jarr = JSONArray.fromObject(map);
					System.out.println(jarr);
					jobj.element("list", jarr);
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "探测器通讯不正常");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		
		return jobj;
	}
	
	/**
	 * 把两次读取的数据组合起来
	 * @param map
	 * @param json
	 */
	@SuppressWarnings({ "unchecked" })
	private void groupMap(Map map, JSONObject json) {
		// TODO Auto-generated method stub
		if(map.get("list") != null && ((List<CarData>)map.get("list")).get(0) != null){
			CarData temp = ((List<CarData>) map.get("list")).get(0);
			String path = temp.getPicPath();
			int[] wh = ToolUtil.getImageWidthHeight(path);
			temp.setPicWidth(wh[0]);
			temp.setPicHeight(wh[1]);
			System.out.println("图片宽度--"+temp.getPicWidth()+"图片宽度--"+temp.getPicHeight());
			temp.setBottomRightCornerX((Integer) json.get("bottomRightCornerX"));
			temp.setBottomRightCornerY((Integer) json.get("bottomRightCornerY"));
			temp.setTopLeftCornerX((Integer) json.get("topLeftCornerX"));
			temp.setTopLeftCornerY((Integer) json.get("topLeftCornerY"));
		}
	}

	/**
	 * 读取识别区域的设置 
	 * @param carData
	 * @param addr
	 * @return
	 */
	private JSONObject getCycleJson(CarData carData, String addr) {
		// TODO Auto-generated method stub
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				JSONObject IPAndPort = cs.readDetectorIpA8(addr);
				if((Boolean) IPAndPort.get("success")){//第一个读取成功后才继续读取
					jobj = cs.readOrSetIndentifyAreaC2((byte) 0, carData, addr);		//读取识别区域
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "探测器通讯不正常");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
		}
		if(cs.getSocket() != null)
			cs.closeSocket();				//断开连接
		return jobj;
	}

	/**
	 * 设置 识别区域的
	 * @param data
	 * @return
	 */
	public JSONObject setCarCycleService(CameraController cdata, CarData carData) {
		// TODO Auto-generated method stub
		JSONObject jobj = new JSONObject();
		String addr = cdata.getShortmac();//探测器mac地址后四位
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readOrSetIndentifyAreaC2((byte) 1, carData, addr);		//读取识别区域
				jobj.element("flag", true);
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
		}
		if(cs.getSocket() != null)
			cs.closeSocket();				//断开连接
		return jobj;
	}
	
	/**
	 * 获取车位编码
	 * @param dcode 探测器编号，如ac01_000
	 * @return
	 */
	public JSONObject getParkingSpaceNO(String dcode){
		JSONObject jobj = new JSONObject();
		dcode = dcode.replace("_", ".");
		String sql = "select p.code from p_parkingspace p inner join p_detector d on p.detectorId = d.id where d.code = '"+dcode+"'";
		try{
			String code  = this.getJt().queryForObject(sql, String.class);
			jobj.element("code", code);
		}catch(Exception ex){
			jobj.element("code", "");
		}
		return jobj;
	}
	
	/**
	 * 获取视频探测器基本信息
	 * @param addr
	 * @return
	 */
	public JSONObject getCamaraBasePara(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readDetectorIpA8(addr);
				JSONObject vobj = cs.readTerminalVersionAC(addr);
				if(vobj.containsKey("version")){
					jobj.element("version", vobj.getString("version"));
				}
				jobj.element("flag", true);
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject readIP(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readDetectorIpA8(addr);
				JSONObject vobj = cs.readTerminalVersionAC(addr);
				if(vobj.getBoolean("success")){
					jobj.element("version", vobj.getString("version"));
				}else{
					jobj.element("version", "获取版本号失败");
				}
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "读取失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject setIP(CameraController data){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() != null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(data.getShortmac());//发送校验信息
			if(b){
				jobj = cs.changeDetectorIPA4(data.getIpaddress(), data.getIpmask(), data.getNetworkgate(), Integer.valueOf(data.getIpport()), data.getShortmac());
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject readWifiSignalStrength(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readWifiSignalStrengthAB(addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "读取失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		System.out.println(jobj);
		return jobj;
	}
	
	public JSONObject readPreferAP(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readOrSetNetworkAE(cs.READ, "", (byte)0, "", addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "读取失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject setPreferAP(CameraController data){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(data.getShortmac());//发送校验信息
			if(b){
				jobj = cs.readOrSetNetworkAE(cs.SET, data.getPreferAP(), Byte.valueOf(data.getEncryptType()), data.getSecretKey(), data.getShortmac());
				if(jobj.containsKey("status") && jobj.getString("status").equals("55")){
					jobj.element("flag", true);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请确定是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject readAllCarPara(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				List<CarData> list = cs.readMultiCarStatusA1(addr);//读取所有车位状态
				JSONArray arr = new JSONArray();
				JSONObject tobj = new JSONObject();
				for(CarData tdata : list){
					tobj.element("cameraId", tdata.getCameraId());
					tobj.element("carCode", tdata.getCarCode());
					tobj.element("parkingSpaceType", tdata.getParkingSpaceType());
					if(tdata.getParkingSpaceStatus().equals("-1")){
						tobj.element("enable", "0");
						tobj.element("parkingSpaceStatus", "");
					}else{
						tobj.element("enable", "1");
						tobj.element("parkingSpaceStatus",tdata.getParkingSpaceStatus());
					}
					arr.add(tobj);
				}
				jobj.element("arr", arr);
				jobj.element("flag", true);
			}else{
				jobj.element("flag", false);
				jobj.element("message", "读取失败");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject setCarType(CarData data, String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.setCarTypeA2((byte)data.getCarCode(), Byte.valueOf(data.getParkingSpaceType()), addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject setCarEnable(CarData data, String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.setCarEnabledA3((byte)data.getCarCode(), Byte.valueOf(data.getParkingSpaceStatus()), addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			cs.closeSocket();//关闭socket连接
		}
		return jobj;
	}
	
	public JSONObject getLibPara(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readOrSetIdentificationC0(cs.READ, null, addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("message", "读取失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			
			cs.closeSocket();
		}
		return jobj;
	}
	
	public JSONObject setLibPara(CameraController data){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(data.getShortmac());//发送校验信息
			if(b){
				jobj = cs.readOrSetIdentificationC0(cs.SET, data, data.getShortmac());
				if(jobj.getBoolean("success")){
					jobj.element("flag", true);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			
			cs.closeSocket();
		}
		return jobj;
	}
	
	public JSONObject readCameraPara(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				Camera camera = new Camera();
				JSONArray jarr = new JSONArray();
				camera.setCameraId(0);
				JSONObject obj1 = cs.readOrSetCameraParaC1(cs.READ, camera, addr);
				jarr.add(obj1);
				camera.setCameraId(1);
				obj1 = cs.readOrSetCameraParaC1(cs.READ, camera, addr);
				jarr.add(obj1);
				jobj.element("arr", jarr);
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			
			cs.closeSocket();
		}
		return jobj;
	}
	/**
	 * OTA远程升级
	 * @param addr
	 * @return
	 */
	public JSONObject startOtaUpdate(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		} else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.startUpdateC3(addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", false);
					jobj.element("message", addr + "升级命令发送成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "发送升级命令失败");
				}
			} else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			cs.closeSocket();
		}
		jobj.element("ip", addr);
		return jobj;
	}
	
	/**
	 * 读取版本号
	 * @param addr
	 * @return
	 */
	public JSONObject readVersion(String addr){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启!");
		} else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readTerminalVersionAC(addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", false);
					jobj.element("message", jobj.get("version"));
				}else{
					jobj.element("flag", false);
					jobj.element("message", "发送读取版本号命令失败!");
				}
			} else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器!");
			}
			cs.closeSocket();
		}
		jobj.element("ip", addr);
		return jobj;
	}
	
	public JSONObject setCameraPara(String addr,Camera camera){
		JSONObject jobj = new JSONObject();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		if(cs.getSocket() == null){
			jobj.element("flag", false);
			jobj.element("message", "请查看PgsServer是否开启");
		}else{
			boolean b = cs.sendVerifyMSG(addr);//发送校验信息
			if(b){
				jobj = cs.readOrSetCameraParaC1(cs.SET, camera, addr);
				if(jobj.getBoolean("success")){
					jobj.element("flag", false);
					jobj.element("message", "设置成功");
				}else{
					jobj.element("flag", false);
					jobj.element("message", "设置失败");
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", "请查看是否存在此探测器");
			}
			
			cs.closeSocket();
		}
		return jobj;
	}
	
	/**
	 * 获取当前地图的所有车位状态
	 * @param mapId 地图id
	 * @return
	 */
	public String getParkingSpaceStatus(String mapId){
		StringBuilder sql = new StringBuilder("select pd.code as code ,pd.status as status, ps.inuse as inuse from p_detector pd inner join p_parkingspace ps on pd.id = ps.detectorId left join p_map pm on pd.mapId = pm.id where pm.id = ");
		if(Util.isCon(mapId)){
			sql.append("'").append(mapId).append("'");
		}else{
			sql.append("(select id from p_map order by id limit 1)");
		}
		ArrayList<ParkingSpaceStatus> list = (ArrayList<ParkingSpaceStatus>)this.getJt().queryForListExt(sql.toString(), ParkingSpaceStatus.class);
		StringBuilder rstr = new StringBuilder();
		if(list.size() > 0){
			for(ParkingSpaceStatus p : list){
				String code = p.getCode().replace(".", "_");
				if("1".equals(p.getStatus())){//探头离线
					rstr.append(code).append(",").append(6).append(";");//车位原件跳到第7帧
				}else{
					if("0".equals(p.getInuse())){//空闲
						rstr.append(code).append(",").append(9).append(";");//车位原件跳到第10帧
					}else{
						rstr.append(code).append(",").append(3).append(";");//车位原件跳到第4帧
					}
				}
			}
		}
		if(rstr.length() > 0){
			rstr.deleteCharAt(rstr.length() - 1);
		}
		return rstr.toString();
	}
	
	public JSONObject searchParkingSpace(String code, String type, String mapId){
		JSONObject jobj = new JSONObject();
		StringBuilder query = new StringBuilder();
		query.append("select pd.code as code ,pd.x_axis as xAxis, pd.y_axis as yAxis from p_detector pd ");
		if("c".equals(type)){//探头编码
			query.append("where left(pd.code, 4) = '").append(code).append("' and pd.mapId = '").append(mapId).append("'");
		}else if("p".equals(type)){//车位编码
			query.append("inner join p_parkingspace ps on pd.id = ps.detectorId ");
			query.append("where ps.code = '").append(code).append("' and pd.mapId = '").append(mapId).append("'");
		}
		ArrayList<ParkingSpaceStatus> list = this.getJt().queryForListExt(query.toString(), ParkingSpaceStatus.class);
		if(list.size() > 0){
			jobj.element("flag", true);
			StringBuilder rstr = new StringBuilder();
			ParkingSpaceStatus first = list.get(0);
			for(ParkingSpaceStatus p : list){
				rstr.append(p.getCode().replace(".", "_")).append(",");
			}
			rstr.deleteCharAt(rstr.length() - 1);
			rstr.append(";").append(first.getxAxis()).append(",").append(first.getyAxis());
			jobj.element("rstr", rstr.toString());
		}else{
			jobj.element("flag", false);
		}
		return jobj;
	}

	//-------------------------------------------------------------------------------------------------------
	/**
	 * OTA批量升级功能
	 * @param shortmac
	 * @return
	 */
	public JSONObject multiOTAUpdate(String shortmac) {
		// TODO Auto-generated method stub
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		JSONObject json = new JSONObject();
		ReturnValue returnValue = new ReturnValue();
		if(cs.getSocket() == null){	
			json.element("flag", false);
			json.element("message", "请查看PgsServer是否开启");
			return json;
		}
		cs.closeSocket();

		try {
			String[] macArr = shortmac.split(";");
			CountDownLatch cdl = new CountDownLatch(macArr.length);
			Thread[] thread = new Thread[macArr.length];
			for(int i = 0; i < macArr.length; i++) {
				OtaUpdateThread out = new OtaUpdateThread(cdl, macArr[i].trim(), returnValue);
				thread[i] = new Thread(out);
				thread[i].start();
			}
			cdl.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return returnJSON(returnValue);
	}
	
	//OTA升级线程
	class OtaUpdateThread implements Runnable{
		String addr;
		JSONObject json = new JSONObject();
		private final CountDownLatch cdl;
		ReturnValue returnValue;
		OtaUpdateThread(CountDownLatch cdl, String addr, ReturnValue returnValue){
			this.addr = addr;
			this.cdl = cdl;
			this.returnValue = returnValue;
		}
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ClientSocket cs = null;
			try{
				cs = new ClientSocket(serverIp, serverPort);
				boolean b = cs.sendVerifyMSG(addr);//发送校验信息
				if(b){
					json = cs.startUpdateC3(addr);
					if(json.getBoolean("success")){
						returnValue.setSuccessJson(addr);
					}else{
						returnValue.setFaileJson(addr);
					}
				} else{
					returnValue.setFaileJson(addr);
				}
				cdl.countDown();
			}catch(Exception ex){
				json.element("message", addr + ",发送升级命令失败");
			} finally{
				if(cs != null)
					cs.closeSocket();
			}
			json.remove("success");
		}
	}
	//-------------------------------------------------------------------------------------------------------

	/**
	 * 批量设置识别区域
	 */
	public JSONObject setMultiCycle(String shortmac, CarData carData) {
		// TODO Auto-generated method stub
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		JSONObject json = new JSONObject();
		ReturnValue returnValue = new ReturnValue();
		List<String> endWithZero = new ArrayList<String>();
		List<String> endWithOne = new ArrayList<String>();
		
		if(cs.getSocket() == null){
			json.element("flag", false);
			json.element("message", "请查看PgsServer是否开启");
			return json;
		}
		cs.closeSocket();

		try {
			String[] macArr = shortmac.split(";");
			for (String string : macArr) {				//先把同一个探头的0号摄像头找出来.
				if(string.endsWith("0")){
					endWithZero.add(string.trim());
				} else{
					endWithOne.add(string.trim());
				}
			}
			CountDownLatch cdl = new CountDownLatch(endWithZero.size());
			Thread[] thread = new Thread[endWithZero.size()];
			for(int i = 0; i < endWithZero.size(); i++) {
				MultiCycleThread out = new MultiCycleThread(cdl, endWithZero.get(i), carData, returnValue);
				thread[i] = new Thread(out);
				thread[i].start();
			}
			cdl.await();
			
			cdl = new CountDownLatch(endWithOne.size());
			thread = new Thread[endWithOne.size()];
			for(int i = 0; i < endWithOne.size(); i++) {
				MultiCycleThread out = new MultiCycleThread(cdl, endWithOne.get(i), carData, returnValue);
				thread[i] = new Thread(out);
				thread[i].start();
			}
			cdl.await();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			Log.log("DebugToolService.setMultiCycle: " + e.getMessage());
		}

		return returnJSON(returnValue);
	}
	
	class MultiCycleThread implements Runnable{
		String addr;
		CarData carData = new CarData();
		JSONObject json = new JSONObject();
		private final CountDownLatch cdl;
		ReturnValue returnValue;
		MultiCycleThread(CountDownLatch cdl, String addr, CarData carData, ReturnValue returnValue){
			this.addr = addr;
			this.cdl = cdl;
			this.carData = carData;
			this.returnValue = returnValue;
		}
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ClientSocket cs = null;
			try{
				String[] addrCode = addr.split("_");
				cs = new ClientSocket(serverIp, serverPort);
				boolean b = cs.sendVerifyMSG(addrCode[0].trim());//发送校验信息
				if(b){
					int carCode = addrCode.length == 2 ? Integer.parseInt(addrCode[1].trim()) : 0;
					carData.setCarCode(carCode);
					json = cs.readOrSetIndentifyAreaC2((byte) 1, carData, addrCode[0].trim());
					if(json.getBoolean("success")){
						returnValue.setSuccessJson(addr);
					}else{
						returnValue.setFaileJson(addr);
					}
				} else{
					returnValue.setFaileJson(addr);
				}
				cdl.countDown();
			}catch(Exception ex){
				json.element("message", addr);
			} finally{
				if(cs != null)
					cs.closeSocket();
			}
			json.remove("success");
		}
	}
	//-------------------------------------------------------------------------------------------------------

	/**
	 * 批量识别库参数设置
	 */
	public JSONObject setMultiParam(CameraController data) {
		// TODO Auto-generated method stub
		String shortmac = data.getShortmac();
		ClientSocket cs = new ClientSocket(serverIp, serverPort);
		JSONObject json = new JSONObject();
		ReturnValue returnValue = new ReturnValue();
		if(cs.getSocket() == null){	
			json.element("flag", false);
			json.element("message", "请查看PgsServer是否开启");
			return json;
		}
		cs.closeSocket();

		try {
			String[] macArr = shortmac.split(";");
			CountDownLatch cdl = new CountDownLatch(macArr.length);
			Thread[] thread = new Thread[macArr.length];
			for(int i = 0; i < macArr.length; i++) {
				MultiParamThread out = new MultiParamThread(cdl, macArr[i].trim(), data, returnValue);
				thread[i] = new Thread(out);
				thread[i].start();
			}
			cdl.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return returnJSON(returnValue);
	}

	//批量设置识别库参数命令
	class MultiParamThread implements Runnable{
		private String addr;
		private CameraController data;
		private JSONObject json = new JSONObject();
		private final CountDownLatch cdl;
		private ReturnValue returnValue;
		MultiParamThread(CountDownLatch cdl, String addr, CameraController data, ReturnValue returnValue){
			this.addr = addr;
			this.cdl = cdl;
			this.returnValue = returnValue;
			this.data = data;
		}
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ClientSocket cs = null;
			try{
				cs = new ClientSocket(serverIp, serverPort);
				boolean b = cs.sendVerifyMSG(addr);//发送校验信息
				if(b){
					json = cs.readOrSetIdentificationC0((byte)1, data, addr);
					if(json.getBoolean("success")){
						returnValue.setSuccessJson(addr);
					}else{
						returnValue.setFaileJson(addr);
					}
				} else{
					returnValue.setFaileJson(addr);
				}
				cdl.countDown();
			}catch(Exception ex){
				returnValue.setFaileJson(addr);
				Log.log("DebugToolService.MultiParamThread: " + ex.getMessage());
			} finally{
				if(cs != null)
					cs.closeSocket();
			}
			json.remove("success");
		}
	}
	//-------------------------------------------------------------------------------------------------------

	private JSONObject returnJSON(ReturnValue returnValue){
		JSONObject json = new JSONObject();
		json.element("message", "成功的Mac地址: " + returnValue.getSuccessJson() + ", <br />失败的Mac地址: " + returnValue.getFaileJson());
		json.element("flag", true);
		return json;
	}
	
	class ReturnValue{
		private JSONObject successJson = new JSONObject();
		private JSONObject faileJson = new JSONObject();
		
		public JSONObject getSuccessJson(){
			return successJson;
		}
		
		public void setSuccessJson(String msg){
			Object message = null == successJson.get("successMsg") ? "" : successJson.get("successMsg") + ";&nbsp;&nbsp;";
			this.successJson = successJson.element("successMsg", message + msg);
		}

		public JSONObject getFaileJson(){
			return faileJson;
		}
		
		public void setFaileJson(String msg){
			Object message = null == faileJson.get("faileMsg") ? "" : faileJson.get("faileMsg") + ";&nbsp;&nbsp;";
			this.faileJson = faileJson.element("faileMsg", message + msg);
		}
	}
}





































