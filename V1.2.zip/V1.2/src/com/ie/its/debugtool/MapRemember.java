package com.ie.its.debugtool;

import java.util.HashMap;

public class MapRemember {
	private static HashMap<String, String> maps = new HashMap<String, String>();
	
	public static void add(String ip, String mapId){
		maps.put(ip, mapId);
	}
	
	public static void remove(String ip){
		maps.remove(ip);
	}
	
	private static boolean isExist(String ip){
		if(maps.containsKey(ip)){
			return true;
		}else{
			return false;
		}
	}
	
	public static String getMapIdByIp(String ip){
		String mapId = "";
		if(isExist(ip)){
			mapId = maps.get(ip).toString();
		}
		return mapId;
	}
}
