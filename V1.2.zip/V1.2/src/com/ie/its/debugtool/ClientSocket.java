package com.ie.its.debugtool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.common.StringManager;
import com.ie.common.Util;

public class ClientSocket{
	
	private Socket socket;	
	private InputStream is;
	private OutputStream os;
	
	public final byte READ = 0;//读取操作
	public final byte SET = 1;//设置操作
	public final static byte DY = 1;//第I代探头
	private final static int LENGTH_PART = 1024;//每次读取图片的长度
	private final static long IMAGE_MAX = 1024*1024;//最大图片大小为1M
	
	protected final String WINPATH = "d:/pgs/carUploadImage/"; // Windows下图片的存储路径
	protected final String CENTOSPATH = "/usr/its/CameraDebug/carImage/"; // CentOS下图片的存储路径
	//A命令
	private enum CMDA{
		A0("a0"), A1("a1"), A2("a2"), A3("a3"), A4("a4"), A5("a5"), A6("a6"), A7("a7"), A8("a8"), A9("a9")
		, AA("aa"), AB("ab"), AC("ac"), AD("ad"), AE("ae"), AF("af");
		private final String value;
		CMDA(String value){
			this.value = value;
		}
		@Override
		public String toString() {
			return value;
		}
	}
	//B命令
	private enum CMDB{
		B1("b1"), B2("b2"), B3("b3"), B4("b4"), B5("b5"), B6("b6");
		private final String value;
		CMDB(String value){
			this.value = value;
		}
		@Override
		public String toString() {
			return value;
		}
	}
	//C命令
	private enum CMDC{
		C0("c0"), C1("c1"), C2("c2");
		private final String value;
		CMDC(String value){
			this.value = value;
		}
		@Override
		public String toString() {
			return value;
		}
	}
	private static FileWriter fw;
	static{
		try {
			fw = new FileWriter("/Debugtool.txt", true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void Msg(String msg){
		try {
			fw.write(msg);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ClientSocket(String hostname, int port){
		init(hostname, port);
	}
	
	private void init(String hostname, int port){
		try {
//			System.out.println("ClientSocket实例化---hostname:"+hostname+"--port:"+port);
			int timeout = 600000;
			OperatePro op = new OperatePro();
			try{
				timeout = Integer.parseInt(op.queryProperty(OperatePro.CONFIGPROPERTIES, "DebugTimeOut"));
			}catch(Exception ex){
				timeout = 600000;
			}
			socket = new Socket();
			socket.connect(new InetSocketAddress(hostname,port), timeout);
			//socket = new Socket(hostname,port);
			is = socket.getInputStream();
			os = socket.getOutputStream();
			socket.setSoTimeout(10000);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			socket = null;
			Log.warn("未知主机名");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			socket = null;
			Log.warn("IO异常");
		}finally{
			
		}
	}
	
	public Socket getSocket(){
		return socket;
	}
	//关闭socket输入流
	public void closeInputStream(){
		try {
			is.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//关闭socket输出流
	public void closeOutputStream(){
		try {
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//关闭socket
	public void closeSocket(){
		try {
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		ClientSocket cs = new ClientSocket("172.18.3.194", 5236);
		String addr = "ac00";
		boolean flag = cs.sendVerifyMSG(addr);
		if(flag){
			//JSONObject A8 = cs.readDetectorIpA8(addr); //模拟器不支持
			//JSONObject A5 = cs.readTerminalIpA5(addr);
			//JSONObject A9 = cs.readShootPeriodA9(addr);	//模拟器无返回
			//JSONObject AD = cs.readOrSetDetectorMacAD(READ, "", addr);
			//JSONObject C1_0 = cs.readOrSetCameraParaC1(READ, new Camera(0), addr);
			//JSONObject C1_1 = cs.readOrSetCameraParaC1(READ, new Camera(1), addr);
			//JSONObject AE = cs.readOrSetNetworkAE(READ, "", (byte)0, "", addr);
			//JSONObject AC = cs.readTerminalVersionAC(addr);
//			Map A0_0 = cs.readSingleCarStatusA0(1, new CarData(0), "",addr,""); //有问题
			//Map A0_1 = cs.readSingleCarStatusA0(1, new CarData(1), "",addr,"");
			//JSONObject C0 = cs.readOrSetIdentificationC0(READ, null, addr);
			List<CarData> list = cs.readMultiCarStatusA1(addr);
			System.out.println(list);
		}
		
	}
	
	/**
	 * 发送身份验证信息
	 * @param addr 视频探测器mac地址后四位
	 * @return
	 */
	public boolean sendVerifyMSG(String addr){
		boolean flag = false;
		int ad = Integer.valueOf(addr, 16);
		byte[] baddr = ToolUtil.intToBytes(ad,2);
		byte[] sbyte = new byte[]{0,0,(byte)0xF1,1,0,0,baddr[0],baddr[1]};
		try {
			if(socket != null && !socket.isClosed()){
				//os.flush();
				os.write(sbyte);
				byte[] buf = new byte[4];
				is.read(buf);
				String result = ToolUtil.byteToString(buf);
				System.out.println(addr+"返回结果："+result);
				if(result.equalsIgnoreCase("00f155")){
					flag = true;
				}else if(result.equalsIgnoreCase("00f111")){
					flag = false;
				}	
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * 读取某个摄像头下的某个车位的状态
	 * @param carNum 摄像头所对应的车位数
	 * @param car 车位对象
	 * @param basePath 图片存储基本路径
	 * @param addr 视频探测器的mac地址后四位
	 * @param type 类型，为mapmonitor则不获取图片
	 * @return
	 */
	public Map<String,Object> readSingleCarStatusA0(int carNum,CarData car,String basePath,String addr,String type){
		Map<String,Object> map = new HashMap<String,Object>();
		if(socket!=null && !socket.isClosed()){
			try {
				   byte[] sb = new byte[]{1, (byte)0xA0, (byte)car.getCarCode()};
				   os.write(sb);
				   byte[] buff = new byte[1];
				   int len;
				   while((len = is.read(buff)) != -1){
					   if(len > 0 && buff[0] == 1){
						   is.read(buff);
						   String cmd = Integer.toHexString(buff[0] & 0x000000FF); // 读取CMD命令,转成十六进制
						   if(cmd.equalsIgnoreCase(CMDA.A0.toString())){
							   Log.debug("A0命令===================================");
							   if(type.equalsIgnoreCase("mapmonitor")){
								   map.put("success", true);
							   }else{
								   List<CarData> list = getListCarData(carNum, basePath, addr);
								   map.put("list", list);
							   }
							   break;
						   }else{
							   readBCMD(cmd, addr);
						   }
					   }
				   }
				if(len == -1){//确实读到-1
					map.put("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				map.put("success", false);
			}
		}
		return map;
	}
	
	/**
	 * 读取探测器下所有车位状态
	 * @param addr
	 * @return
	 */
	public List<CarData> readMultiCarStatusA1(String addr){
		List<CarData> list = new ArrayList<CarData>();
		if(socket!=null && !socket.isClosed()){
			byte[] sb = new byte[]{1, (byte)0xA1};
			try {
				os.write(sb);
				 byte[] buff = new byte[2];
				 int len;
				 while((len = is.read(buff)) != -1){
					 if(len > 0){
						 String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						 if ((buff[0] == 1) && cmd.equalsIgnoreCase(CMDA.A1.toString())) {
							 byte[] rb = new byte[1];
							 is.read(rb);
							 list = getListCarData(rb[0], "", addr);
							 break;
						 }else{
							 readBCMD(cmd, addr);
						 }
					 }
				 }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		return list;
	}
	/**
	 * 设置车位类型
	 * @param carCode 车位编码
	 * @param carType 车位类型
	 * @return
	 */
	protected JSONObject setCarTypeA2(byte carCode, byte carType, String addr){
		JSONObject jobj = new JSONObject();
		if(socket!=null && !socket.isClosed()){
			try {
				byte[] sb = new byte[]{DY, (byte)0xA2, carCode, carType};
				os.write(sb);
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDA.A2.toString())){
							byte[] rb = new byte[1];
							is.read(rb);
							String status = Integer.toHexString(rb[0]);
							if(status.equalsIgnoreCase("55")){
								jobj.element("success", true);
							}else{
								jobj.element("success", false);
							}
							jobj.element("status", status);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 设置车位使能或禁用
	 * @param carCode 车位编号
	 * @param enable	禁用0或使能1
	 * @return
	 */
	protected JSONObject setCarEnabledA3(byte carCode,byte enable,String addr){
		JSONObject jobj = new JSONObject();
		if(socket!=null && !socket.isClosed()){
			try {
				byte[] buff = new byte[]{1,(byte)0xA3,carCode,enable};
				os.write(buff);
				buff = new byte[2];
				int len;
				while((len = is.read(buff))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDA.A3.toString())){
							byte[] rb = new byte[1];
							is.read(rb);
							String status = Integer.toHexString(Integer.valueOf(rb[0]));
							Log.debug("车位"+carCode+"设置:"+status);
							if(status.equalsIgnoreCase("55")){
								jobj.element("success", true);
							}else{
								jobj.element("success", false);
							}
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 设置视频探测器IP、子网掩码、网关地址、端口
	 * @param ip
	 * @param ipMask
	 * @param network
	 * @param port
	 * @return
	 */
	protected JSONObject changeDetectorIPA4(String ip,String ipMask,String network,int port, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				byte[] sb = null;
				//全部为空设置为DHCP模式
				if(!Util.isCon(ip) && !Util.isCon(ipMask) && !Util.isCon(network)){
					byte[] f = new byte[]{DY,(byte)0xA4,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF};
					byte[] s = ToolUtil.intToBytes(port, 2);
					sb = ToolUtil.combineTwoByteArr(f, s);
				}else{
					List<byte[]> l = new ArrayList<byte[]>();
					byte[] f = new byte[]{DY,(byte)0xA4};
					byte[] s = ToolUtil.stringToBytes(ip, "\\.", 10);
					byte[] t = ToolUtil.stringToBytes(ipMask, "\\.", 10);
					byte[] fr = ToolUtil.stringToBytes(network, "\\.", 10);
					byte[] fv = ToolUtil.intToBytes(port, 2);
					l.add(f);
					l.add(s);
					l.add(t);
					l.add(fr);
					l.add(fv);
					sb = ToolUtil.combineByteArrList(l);
				}
				os.write(sb);
				
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDA.A4.toString())){
							byte[] rb = new byte[1];
							is.read(rb);
							String status = Integer.toHexString(rb[0]);
							jobj.element("success", true);
							jobj.element("status", status);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取PgsServer所在服务器的IP和通讯端口
	 * @return
	 */
	protected JSONObject readTerminalIpA5(String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			byte[] sb = new byte[]{1,(byte)0xA5};//读取指令
			try {
				os.write(sb);
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);
						Log.debug("返回---"+cmd);
						if(rb[0]==1 && cmd.equalsIgnoreCase(CMDA.A5.toString())){
							byte[] ipbyte = new byte[4];
							is.read(ipbyte);
							String ip = ToolUtil.bytePacketStr(ipbyte,".");
							Log.debug("地址---"+ip);
							byte[] portbyte = new byte[2];
							is.read(portbyte);
							int port = ToolUtil.bytesToIntLTH(portbyte);
							Log.debug("端口---"+port);
							jobj.element("ip", ip);
							jobj.element("port", port);
							jobj.element("success", true);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (SocketTimeoutException e) {
				// TODO: handle exception
				e.printStackTrace();
				jobj.element("success", false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 设置"视频探测器"所要连接的服务器IP及端口
	 * @param ip
	 * @param port
	 * @return
	 */
	protected JSONObject setTerminalIPA6(String ip,int port, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
		 try {
			List<byte[]> l = new ArrayList<byte[]>();
			byte[] f = new byte[]{DY,(byte)0xA6};
			byte[] s = ToolUtil.stringToBytes(ip, "\\.", 10);
			byte[] t = ToolUtil.intToBytes(port, 2);
			l.add(f);
			l.add(s);
			l.add(t);
			byte[] sb = ToolUtil.combineByteArrList(l);
			os.write(sb);
			byte[] buff = new byte[2];
			int len;
			while((len = is.read(buff))!= -1){
				if(len > 0){
					String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
					if(buff[0] == DY && cmd.equalsIgnoreCase(CMDA.A6.toString())){
						byte[] rb = new byte[1];
						is.read(rb);
						String status = Integer.toHexString(rb[0]);
						jobj.element("success", true);
						jobj.element("status", status);
						break;
					}else{
						readBCMD(cmd, addr);
					}
				}
			}
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 更改车位Id对应的车位编号
	 * @param carId
	 * @param carCode
	 * @return
	 */
	protected JSONObject changeCarIdtoCarCodeA7(byte carId,byte carCode,String addr){
		JSONObject jobj = new JSONObject();
		if(socket!=null && !socket.isClosed()){
			try {
				byte[] sb = new byte[]{DY,(byte)0xA7, carId, carCode};
				os.write(sb);
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == DY && cmd.equalsIgnoreCase(CMDA.A7.toString())){
							byte[] rb = new byte[1];
							is.read(rb);
							String status = Integer.toHexString(rb[0]);
							jobj.element("success", true);
							jobj.element("status", status);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取视频探测器的IP、端口、子网掩码、默认网关
	 * @return
	 */
	public JSONObject readDetectorIpA8(String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			byte[] sb = new byte[]{1,(byte)0xA8};//读取指令
			try {
				os.write(sb);
				jobj.element("success", true);
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);
						Log.debug("返回---"+cmd);
						if(rb[0]==1 && cmd.equalsIgnoreCase(CMDA.A8.toString())){
							byte[] buff = new byte[4];
							is.read(buff);
							String ip = ToolUtil.bytePacketStr(buff,".");
							Log.debug("地址---"+ip);
							
							is.read(buff);
							String ipMask = ToolUtil.bytePacketStr(buff, ".");
							Log.debug("子网掩码---"+ipMask);
							
							is.read(buff);
							String returnNetwork = ToolUtil.bytePacketStr(buff, ".");
							Log.debug("网关地址---"+returnNetwork);
							
							byte[] portbyte = new byte[2];
							is.read(portbyte);
							int port = ToolUtil.bytesToIntLTH(portbyte);
							Log.debug("端口---"+port);
							jobj.element("ip", ip);
							jobj.element("ipMask", ipMask);
							jobj.element("returnNetwork", returnNetwork);
							jobj.element("port", port);
							jobj.element("success", true);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (SocketTimeoutException e) {
				// TODO: handle exception
				//e.printStackTrace();
				Log.warn("读取数据超过10s");
				jobj.element("success", false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Log.warn("读取视频探测器IP信息------IO错误");
				jobj.element("success", false);
			}
		}else{
			jobj.element("success", false);
		}
		return jobj;
	}

	/**
	 * 读取视频探测器的拍照周期
	 * @return
	 */
	protected JSONObject readShootPeriodA9(String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			byte[] sb = new byte[]{1,(byte)0xA9};
			try {
				os.write(sb);
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);
						if(rb[0]==1 && cmd.equalsIgnoreCase(CMDA.A9.toString())){
							rb = new byte[2];
							is.read(rb);
							int period = ToolUtil.bytesToIntLTH(rb);
							jobj.element("period", period);
							jobj.element("success", true);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 更改终端机拍照周期
	 * @param period
	 * @return
	 */
	protected JSONObject setShootPeriodAA(int period, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				byte[] f = new byte[]{DY,(byte)0xAA};
				byte[] s = ToolUtil.intToBytes(period, 2);
				byte[] sb = ToolUtil.combineTwoByteArr(f, s);
				
				os.write(sb);
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == DY && cmd.equalsIgnoreCase(CMDA.AA.toString())){
							byte[] rb = new byte[1];
							is.read(rb);
							String status = Integer.toHexString(rb[0]);
							jobj.element("success", true);
							jobj.element("status", status);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取终端机探测到的Wifi信号强度
	 * @return
	 */
	protected JSONObject readWifiSignalStrengthAB(String addr){
		JSONObject jobj = new JSONObject();
		JSONArray jarr = new JSONArray();
		if(socket != null && !socket.isClosed()){
			byte[] sb = new byte[]{1,(byte)0xAB};
			try {
				os.write(sb);
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);//获取返回指令
						Log.debug("返回---"+cmd);
						if(rb[0] == 1 && cmd.equalsIgnoreCase(CMDA.AB.toString())){
							byte[] buff = new byte[4];
							is.read(buff);
							int totalLen = ToolUtil.bytesToIntHTL(buff);
							int currLen = 0;
							int apLen = 0;
							JSONObject tobj = new JSONObject();
							while(currLen < totalLen){
								buff = new byte[1];			//设置读取的AP名称长度为1byte
								is.read(buff);
								currLen += 1;
								
								apLen = buff[0];
								buff = new byte[apLen];
								int l = is.read(buff);
								String apName = new String(buff, 0, l, "UTF-8");
								currLen += apLen;
								tobj.element("apName", apName);
								
								buff = new byte[1];
								is.read(buff);
								currLen += 1;
								tobj.element("signalStren", buff[0]);
								if(jarr.size() > 0){
									JSONObject t = (JSONObject) jarr.get(0);
									if(tobj.getInt("signalStren") >= t.getInt("signalStren")){
										jarr.add(0, tobj);
									}else{
										jarr.add(tobj);
									}
								}else{
									jarr.add(tobj);
								}
							}
							jobj.element("success", true);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				jobj.element("success", false);
				e.printStackTrace();
			}
		}
		jobj.element("arr", jarr);
		return jobj;
	}
	
	/**
	 * 读取视频探测器的版本号
	 * @return
	 */
	protected JSONObject readTerminalVersionAC(String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			byte[] sb = new byte[]{1,(byte)0xAC};
			try {
				os.write(sb);//发送AC指令
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);//获取返回指令
						Log.debug("返回---"+cmd);
						if(rb[0] == 1 && cmd.equalsIgnoreCase(CMDA.AC.toString())){
							byte[] fbyte = new byte[1];
							is.read(fbyte);
							len = fbyte[0];	//版本字符串长度
							Log.debug("版本字符串长度---"+len);
							fbyte = new byte[len];
							is.read(fbyte); //读取版本字符串
							String version = new String(fbyte, 0, len, "UTF-8");
							Log.debug("版本---"+version);
							jobj.element("vlen", len);
							jobj.element("version", version);
							jobj.element("success", true);
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取或设置视频探测器的MAC地址
	 * @param type 读取或设置
	 * @param macAddr	MAC地址
	 * @return
	 */
	protected JSONObject readOrSetDetectorMacAD(byte type,String macAddr, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				if(type == READ){
					byte[] sb = new byte[]{1,(byte)0xAD,READ};
					os.write(sb);
				}else if(type == SET){
					byte[] macArr = ToolUtil.stringToBytes(macAddr, "-", 16);
					byte[] fron = new byte[]{ 1, (byte) 0xAD, SET,(byte)macArr.length};
					byte[] sb = ToolUtil.combineTwoByteArr(fron, macArr);
					os.write(sb);
				}
				byte[] rb = new byte[2];
				int len;
				while((len = is.read(rb))!= -1){
					if(len > 0){
						String cmd = Integer.toHexString(rb[1] & 0x000000FF);//获取返回指令
						Log.debug("返回---"+cmd);
						if(rb[0] == 1 && cmd.equalsIgnoreCase(CMDA.AD.toString())){
							byte[] fb = new byte[1];
							is.read(fb);//获取操作类型，读为0，写为1
							len = fb[0];
							if(len == READ){
								is.read(fb);//读MAC地址长度
								len = fb[0];
								Log.debug("MAC地址内容长度---"+len);
								fb = new byte[len];
								is.read(fb);//读取MAC地址内容
								String macaddr = ToolUtil.packString(fb, "-");
								Log.debug("MAC地址内容---"+macaddr);
								jobj.element("macaddr", macaddr);
								jobj.element("success", true);
							}else if(len == SET){
								is.read(fb);//获取设置返回状态，55表示成功，11表示失败
								String status = Integer.toHexString(Integer.valueOf(fb[0]));
								jobj.element("status", status);
							}
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取及设置首选AP
	 * @param type 读或写
	 * @param apName AP名称
	 * @param encryptType	加密类型
	 * @param secretKey	加密秘钥
	 * @return
	 */
	protected JSONObject readOrSetNetworkAE(byte type,String apName, byte encryptType, String secretKey, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				if(type == READ){//读
					byte[] sb = new byte[]{1, (byte)0xAE, READ};
					os.write(sb);
				}else if(type == SET){//设置
					List<byte[]> list = new ArrayList<byte[]>();
					byte[] first = new byte[] { 1, (byte) 0xAE, SET, (byte) apName.length()};
					byte[] second = apName.getBytes();
					byte[] third = new byte[]{encryptType, (byte) secretKey.length()};
					byte[] fourth = secretKey.getBytes();
					list.add(first);
					list.add(second);
					list.add(third);
					list.add(fourth);
					byte[] sb = ToolUtil.combineByteArrList(list);
					os.write(sb);
				}
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if((buff[0] == 1) && cmd.equalsIgnoreCase(CMDA.AE.toString())){
							byte[] fb = new byte[1];
							is.read(fb);//读取操作类型，0为读取，1为设置
							len = fb[0];
							if(len == READ){
								is.read(fb); //读取首选AP名称长度
								len = fb[0];
								Log.debug("首选AP名称长度---"+len);
								jobj.element("firstAPLen", len);
								
								fb = new byte[len];
								is.read(fb); //读取首选AP名称
								apName = new String(fb, 0, len, "UTF-8");
								Log.debug("首选AP名称---"+apName);
								jobj.element("apName", apName);
								
								fb = new byte[2];
								len = is.read(fb);//读取WEP/WAP
								jobj.element("WEPLen", fb);
								
								encryptType = fb[0]; //加密类型
								Log.debug("加密类型---"+encryptType);
								jobj.element("encryptType", encryptType);
								byte secretKeyLen = fb[1];//密钥字符串长度
								Log.debug("密钥字符串长度---"+secretKeyLen);
								jobj.element("secretKeyLen", secretKeyLen);
								
								fb = new byte[secretKeyLen];
								len = is.read(fb);	//读取密钥
								secretKey = new String(fb, 0, len, "UTF-8");
								Log.debug("密钥字符串---"+secretKey);
								jobj.element("secretKey", secretKey);
								jobj.element("success", true);
							}else if(len == SET){
								is.read(fb); //读取设置返回状态，55表示成功，11表示失败
								String status = Integer.toHexString(Integer.valueOf(fb[0]));
								Log.debug("设置AP返回状态"+status);
								jobj.element("status", status);
							}
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				//e.printStackTrace();
				jobj.element("success", false);
			}
		}
		return jobj;
	}
	
	/**
	 * 读取或设置识别库参数
	 * @param type 读或写
	 * @param data 库参数
	 * @return
	 */
	protected JSONObject readOrSetIdentificationC0(byte type,CameraController data,String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				if(type == READ){
					byte[] sb = new byte[]{1,(byte)0xC0, READ};
					os.write(sb);
				}else if(type == SET){
					byte[] sb = generateCMDC0(data);
					os.write(sb);
				}
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF); // 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDC.C0.toString())){
							byte[] fb = new byte[1];
							is.read(fb);	//读取操作类型，0为读取，1为设置
							len = fb[0];
							if(len == READ){
								int Result;
								fb = new byte[4];
								is.read(fb);		//读取最小车牌宽度
								Result = ToolUtil.bytesToIntHTL(fb);
								Log.debug("车牌最小宽度---"+Result);
								jobj.element("nminPlateWidth", Result);
								
								fb = new byte[4];
								is.read(fb);		//读取最大车牌宽度
								Result = ToolUtil.bytesToIntHTL(fb);
								Log.debug("车牌最大宽度---"+Result);
								jobj.element("nmaxPlateWidth", Result);
								
								fb = new byte[4];
								is.read(fb);		//读取实际图像最大宽度
								Result = ToolUtil.bytesToIntHTL(fb);
								Log.debug("实际图像最大宽度---"+Result);
								jobj.element("nmaxImageWidth", Result);
								
								fb = new byte[4];
								is.read(fb);		//读取实际图像最大高度
								Result = ToolUtil.bytesToIntHTL(fb);
								Log.debug("实际图像最大高度---"+Result);
								jobj.element("nmaxImageHeight", Result);
								
								fb = new byte[1];
								is.read(fb);		//读取是否垂直方向压缩1倍后识别
								Log.debug("是否垂直方向压缩1倍后识别度---"+fb[0]);
								jobj.element("bvertCompress", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取是否是场图像
								Log.debug("是否是场图像---"+fb[0]);
								jobj.element("bisFieldImage", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取是否视频图像中同一个车的多幅图像只输出一次结果
								Log.debug("是否视频图像中同一个车的多幅图像只输出一次结果---"+fb[0]);
								jobj.element("boutputSingleFrame", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取识别运动or静止图像
								Log.debug("识别运动or静止图像---"+fb[0]);
								jobj.element("bmovingImage", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取夜间模式
								Log.debug("夜间模式---"+fb[0]);
								jobj.element("bisNight", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取NV21
								Log.debug("NV21---"+fb[0]);
								jobj.element("nimageFormat", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取输出顺序选项
								Log.debug("输出顺序选项---"+fb[0]);
								jobj.element("norderOpt", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取是否启用倾斜校正功能
								Log.debug("是否启用倾斜校正功能---"+fb[0]);
								jobj.element("bleanCorrection", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取内部推送+外部获取
								Log.debug("内部推送+外部获取---"+fb[0]);
								jobj.element("bmovingOutputOpt", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取识别率速度
								Log.debug("识别率速度---"+fb[0]);
								jobj.element("nimproveSpeed", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取是否识别车辆颜色
								Log.debug("bevaCarColor---"+fb[0]);
								jobj.element("bevaCarColor", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取bVertFlip
								Log.debug("bVertFlip---"+fb[0]);
								jobj.element("bVertFlip", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取bDwordAligned
								Log.debug("bDwordAligned---"+fb[0]);
								jobj.element("bDwordAligned", fb[0]);
								
								fb = new byte[1];
								is.read(fb);		//读取省份字符串长度
								Log.debug("省份字符串长度---"+fb[0]);
								jobj.element("sprovinceLen", fb[0]);
								
								fb = new byte[fb[0]];
								is.read(fb);		//读取省份字符串
								String pStr = new String(fb,"UTF-8");
								Log.debug("省份字符串---"+pStr);
								jobj.element("provinces", pStr);
								
								fb = new byte[12];
								is.read(fb);	//读取后续参数
								
								Log.debug("车牌定位阈值---"+fb[0]);
								jobj.element("plateLocateShre", fb[0]);
								Log.debug("车牌识别阈值---"+fb[1]);
								jobj.element("plateIdentShre", fb[1]);
								Log.debug("个性化车牌---"+fb[2]);
								jobj.element("indiviPlate", fb[2]);
								Log.debug("双层黄色车牌---"+fb[3]);
								jobj.element("doubleYelPlate", fb[3]);
								Log.debug("武警车牌---"+fb[4]);
								jobj.element("armPolicePlate", fb[4]);
								Log.debug("双层军车---"+fb[5]);
								jobj.element("doubleMilPlate", fb[5]);
								Log.debug("农用车---"+fb[6]);
								jobj.element("farmPlate", fb[6]);
								Log.debug("使领馆车---"+fb[7]);
								jobj.element("emPlate", fb[7]);
								Log.debug("双层武警车---"+fb[8]);
								jobj.element("dbArmPoliPlate", fb[8]);
								Log.debug("是否检测车辆---"+fb[9]);
								jobj.element("isDetectCar", fb[9]);
								Log.debug("识别库类型---"+fb[10]);
								jobj.element("recognitionLibType", fb[10]);
								Log.debug("保留字符串长度---"+fb[11]);
								jobj.element("reservedLen", fb[11]);
								
								fb = new byte[fb[11]];
								is.read(fb);		//读取保留字符串
								String reservedStr = new String(fb,"UTF-8");
								Log.debug("保留字符串---"+reservedStr);
								jobj.element("reservedStr", reservedStr);
								jobj.element("success", true);
							}else if(len == SET){
								is.read(fb);	//读取设置返回数据，55表示成功，11表示失败
								String status = Integer.toHexString(Integer.valueOf(fb[0]));
								Log.debug("识别库参数设置C0结果----"+status);
								if(status.equalsIgnoreCase("55")){
									jobj.element("success", true);
									jobj.element("message", "Code: " + data.getCarCode() + "识别库参数设置成功!");
								}else{
									jobj.element("success", false);
								}								
							}
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
				jobj.element("message", e.getMessage());
			}
		}
		return jobj;
	}
	
	public byte[] generateCMDC0(CameraController data){
		List<byte[]> list = new ArrayList<byte[]>();
		byte[] sb = new byte[]{1,(byte)0xC0, SET};
		byte[] nMinPlateWidth = ToolUtil.intToBytes(data.getMinPlateWidth(), 4);
		byte[] nMaxPlateWidth = ToolUtil.intToBytes(data.getMaxPlateWidth(), 4);
		byte[] nMaxImageWidth = ToolUtil.intToBytes(data.getMaxImageWidth(),4);
		byte[] nMaxImageHeight = ToolUtil.intToBytes(data.getMaxImageHeight(),4);
		byte[] provinces = new byte[]{};
		byte[] reservedStr = new byte[]{};
		try {
			provinces = data.getProvinces().getBytes("UTF-8");
			reservedStr = data.getReservedStr().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] paras = new byte[]{Byte.valueOf(data.getIsVertCompress(), 10),
				Byte.valueOf(data.getIsFieldImage(), 10),
				Byte.valueOf(data.getIsOptSimpleFrame(), 10),
				Byte.valueOf(data.getIsMovingImage(), 10),
				Byte.valueOf(data.getIsNight(), 10),
				(byte)data.getImageFormat(),
				Byte.valueOf(data.getOptOrder(), 10),
				Byte.valueOf(data.getIsLeanCorrect(), 10),
				Byte.valueOf(data.getMovingOutputOpt(), 10),
				Byte.valueOf(data.getIdentifyMode(), 10),
				Byte.valueOf(data.getIsEvaColor(), 10),
				Byte.valueOf(data.getIsVertFlip(), 10),
				Byte.valueOf(data.getIsDwordAligned(), 10),
				//(byte)data.getProvinceLen(),
				(byte)provinces.length
				};
		byte[] otherparas = new byte[]{
				(byte)data.getPlateLocateShre(),
				(byte)data.getPlateIdentShre(),
				Byte.valueOf(data.getIndiviPlate(), 10),
				Byte.valueOf(data.getDoubleYelPlate(), 10),
				Byte.valueOf(data.getArmPolicePlate(), 10),
				Byte.valueOf(data.getDoubleMilPlate(), 10),
				Byte.valueOf(data.getFarmPlate(), 10),
				Byte.valueOf(data.getEmPlate(), 10),
				Byte.valueOf(data.getDbArmPoliPlate(), 10),
				Byte.valueOf(data.getIsDetectCar(), 10),
				//(byte)data.getReservedLen()
				Byte.valueOf(data.getRecognitionLibType(),10),
				(byte)reservedStr.length
				};
		list.add(sb);
		list.add(nMinPlateWidth);
		list.add(nMaxPlateWidth);
		list.add(nMaxImageWidth);
		list.add(nMaxImageHeight);
		list.add(paras);
		list.add(provinces);
		list.add(otherparas);
		list.add(reservedStr);
		byte[] result = ToolUtil.combineByteArrList(list);
		return result;
	}
	
	/**
	 * 读取或设置单个摄像头的参数
	 * @param type
	 * @param camera
	 * @return
	 */
	protected JSONObject readOrSetCameraParaC1(byte type,Camera camera,String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				if(type == READ){
					byte[] sb = new byte[]{1, (byte)0xC1, READ, (byte)camera.getCameraId()};
					os.write(sb);
				}else if(type == SET){
					List<byte[]> list = new ArrayList<byte[]>();
					System.out.println("摄像头ID---"+camera.getCameraId());
					byte[] first = new byte[]{1, (byte)0xC1, SET, (byte)camera.getCameraId(), (byte)camera.getExposureValue(),(byte)camera.getPhotoMode().length()};
					byte[] second = camera.getPhotoMode().getBytes();
					list.add(first);
					list.add(second);
					byte[] sb = ToolUtil.combineByteArrList(list);
					os.write(sb);
				}
				byte[] buff = new byte[2];
				int len;
				while((len = is.read(buff)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF);// 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDC.C1.toString())){
							byte[] fb = new byte[1];
							is.read(fb);	//读取操作类型，0为读取，1为设置
							len = fb[0];
							if(len == READ){
								fb = new byte[3];
								is.read(fb);
								Log.log("摄像头ID： "+fb[0]);
								jobj.element("cameraId", fb[0]);
								
								Log.log("曝光度： "+fb[1]);
								jobj.element("exposureValue", fb[1]);//曝光度（-1～1）
								
								len = fb[2];	//拍照模式标识长度
								Log.log("拍照模式标识长度： "+len);
								jobj.element("photoModeLen", len);
								
								fb = new byte[len];
								is.read(fb);	//拍照模式标识内容
								String photoMode = new String(fb,"UTF-8");
								Log.log("拍照模式标识内容： "+photoMode);
								jobj.element("photoMode", photoMode);
							}else if(len == SET){
								fb = new byte[2];
								is.read(fb);	//读取设置返回，摄像头id及状态，55表示成功，11表示失败
								jobj.element("cameraId", Integer.valueOf(fb[0]));
								String status = Integer.toHexString(fb[1]);
								jobj.element("status",status);
								if(status.equals("55")){
									jobj.element("success",true);
								}else{
									jobj.element("success",false);
								}
								Log.debug("摄像头"+fb[0]+"设置"+status);
							}
							break;
						}else{
							readBCMD(cmd,addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return jobj;
	}
	
	/**
	 *  C2 读取和更改单个车位对应的车形识别区域参数
	 * @param type	操作类型
	 * @param car	输入的数据
	 * @param addr 	MAC地址
	 * @return
	 */
	public JSONObject readOrSetIndentifyAreaC2(byte type,CarData car, String addr){
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			try {
				if(type == READ){	//========发送数据======================
					byte[] sb = new byte[]{1, (byte)0xC2, READ, (byte)car.getCarCode()};
					os.write(sb);
				} else if(type == SET){
					byte[] sb = new byte[]{1, (byte)0xC2, SET, (byte)car.getCarCode()};
					byte[] leftTopRightBottom = groupCycle(car);
					byte[] holeByte = new byte[sb.length + 16];
					System.arraycopy(sb, 0, holeByte, 0, sb.length);
					System.arraycopy(leftTopRightBottom, 0, holeByte, sb.length, leftTopRightBottom.length);
					os.write(holeByte);
				}					//========发送数据======================
				byte[] buff = new byte[2];			//========读取数据======================
				int len;
				while((len = is.read(buff)) != -1){
					if(len > 0){
						String cmd = Integer.toHexString(buff[1] & 0x000000FF);// 读取CMD命令,转成十六进制
						if(buff[0] == 1 && cmd.equalsIgnoreCase(CMDC.C2.toString())){
							byte[] fb = new byte[1];
							is.read(fb);	//读取操作类型，0为读取，1为设置
							len = fb[0];
							if(len == READ){
								fb = new byte[1];
								is.read(fb);
								Log.debug("[车位编号]---"+fb[0]);
								jobj.element("carCode", fb[0]);
								
								fb = new byte[4];
								is.read(fb);
								Log.debug("[车形识别区域左上角X坐标]---" + bytesToIntHTL(fb));//车形识别区域左上角X坐标=======
								jobj.element("topLeftCornerX", bytesToIntHTL(fb));
								
								is.read(fb);
								Log.debug("[车形识别区域左上角Y坐标]---" + bytesToIntHTL(fb));//车形识别区域左上角Y坐标=======
								jobj.element("topLeftCornerY", bytesToIntHTL(fb));
								
								is.read(fb);
								Log.debug("[车形识别区域右下角X坐标]---" + bytesToIntHTL(fb));//车形识别区域右下角X坐标==============
								jobj.element("bottomRightCornerX", bytesToIntHTL(fb));
								
								is.read(fb);
								Log.debug("[车形识别区域右下角Y坐标]---" + bytesToIntHTL(fb));//车形识别区域右下角Y坐标=======
								jobj.element("bottomRightCornerY", bytesToIntHTL(fb));
								
							}else if(len == SET){
								fb = new byte[2];
								int rlen = is.read(fb);	//读取设置返回，摄像头id及状态，55表示成功，11表示失败
								String status = "";
								if(rlen == 2){
									status = Integer.toHexString(Integer.valueOf(fb[1]));
								}else if(rlen == 1){
									status = Integer.toHexString(Integer.valueOf(fb[0]));
								}
								jobj.element("success", true);
//								String status = Integer.toHexString(Integer.valueOf(fb[0]));
//								jobj.element("message", "ID: " + fb[1] + ", " + status);
								Log.debug("摄像头"+fb[1]+"设置"+status);
							}
							break;
						}else{
							readBCMD(cmd, addr);
						}
					}
				}
				if(len == -1){//确实读到-1
					jobj.element("success", false);
				}
			} catch (Exception e) {
				// TODO: handle exception
				jobj.element("success", false);
				jobj.element("message", e.getMessage());
			}
		}
		return jobj;
	}
	
	/**
	 * C3启动探测器的升级命令
	 * @param ip
	 * @return
	 */
	public JSONObject startUpdateC3(String ip) {
		// TODO Auto-generated method stub
		JSONObject jobj = new JSONObject();
		if(socket != null && !socket.isClosed()){
			byte[] fb = new byte[1];
			// 数据格式 type,cmd
			try {// 写命令	
				fb =new byte[] { 1, (byte) 0xC3, 0};
				os.write(fb);
				jobj.element("success", false);
				Log.log("[" + ip + "]: 发送C3命令.");
				byte[] buff = new byte[2];
				while(socket != null && !socket.isClosed() && is.read(buff) != -1){
					Log.log("进入读取B命令");
					String cmd = Integer.toHexString(buff[1] & 0x000000FF);// 读取CMD命令,转成十六进制
					JSONObject jother = readBCMD(cmd, ip);
					if(jother.get("message") != null){
						Log.log("[" + jother.get("mac") + "]B6返回的数据:[ " + jother.get("message") + "]");
						jobj = jother;
						jobj.element("success", true);
					} else{
						jobj.element("message", "升级命令已发送,探测器已断开!");
					}
					if(socket == null || socket.isClosed() 
							|| (jobj.get("message").toString().trim().startsWith("1") && jobj.get("message").toString().trim().endsWith("0"))){
						break;
					}
				}
			} catch (IOException e) {
				Log.log(e.getMessage());
				jobj.element("success", true);
			}
		} else{
			jobj.element("success", false);
		}
		return jobj;
	}
	
	private byte[] groupCycle(CarData car) {
		// TODO Auto-generated method stub
		byte[] topLeftX = intToBytes(car.getTopLeftCornerX(), 4);
		byte[] topLeftY = intToBytes(car.getTopLeftCornerY(), 4);
		byte[] bottomRightX = intToBytes(car.getBottomRightCornerX(), 4);
		byte[] bottomRightY = intToBytes(car.getBottomRightCornerY(), 4);
		byte[] holeByte = new byte[16];
		System.arraycopy(topLeftX, 0, holeByte, 0, topLeftX.length);
		System.arraycopy(topLeftY, 0, holeByte, 4, topLeftY.length);
		System.arraycopy(bottomRightX, 0, holeByte, 8, bottomRightX.length);
		System.arraycopy(bottomRightY, 0, holeByte, 12, bottomRightY.length);
		return holeByte;
	}

	protected JSONObject readBCMD(String cmd,String addr){
		JSONObject jobj = new JSONObject();
		try {
			if (cmd.equalsIgnoreCase(CMDB.B1.toString())) { // 终端机连接上主机后主动上传所有使能车位状态
				Log.debug("B1开始==============================");
				byte[] buff = new byte[6];
				is.read(buff);//读取MAC地址
				String mac = ToolUtil.packString(buff, "-");
				jobj.element("mac", mac);
				buff = new byte[1];
				is.read(buff);//读取上传几组车位状态
				List<CarData> list = getListCarData(buff[0], "", addr);
				Log.debug("B1结束==============================");
			}else if (cmd.equalsIgnoreCase(CMDB.B2.toString())) { // 入车主动上传
				Log.debug("B2开始==============================");
				List<CarData> list = getListCarData(1, "", addr);
				Log.debug("B2结束==============================");
			}else if(cmd.equalsIgnoreCase(CMDB.B3.toString())){ // 	出车主动上传
				Log.debug("B3开始==============================");
				List<CarData> list = getListCarData(1, "", addr);
				Log.debug("B3开始==============================");
			}else if(cmd.equalsIgnoreCase(CMDB.B4.toString())){// 运行中发现探测器故障主动上传
				byte[] buff = new byte[1];
				is.read(buff);
				List<CarData> list = getListCarData(buff[0]);
			}else if(cmd.equalsIgnoreCase(CMDB.B5.toString())){// 心跳
				byte[] buff = new byte[2];
				is.read(buff);
				Log.debug("时间为:[" + DateUtil.getCurDateTime() + "]接收到心跳值为: [" + ToolUtil.bytePacketStr(buff, "  ") + "]");
				buff = new byte[6];
				is.read(buff);
				Log.debug("Mac地址: ["+ToolUtil.packString(buff, "-")+"]");
				//接收到心跳不返回
//				buff = new byte[]{1, (byte) 0xB5, (byte) 0x77, (byte) 0x77};
//				os.write(buff);
			} else if (cmd.equalsIgnoreCase(CMDB.B6.toString())){		//OTA升级错误信息
				Log.log("开始接收B6==============================");
				//读取MAC地址====================
				byte[] buff = new byte[6];
				is.read(buff);//读取MAC地址
				String mac = ToolUtil.packString(buff, "-");
				jobj.element("mac", mac);
				//读取MAC地址====================
				buff = new byte[2]; 
				is.read(buff);
				jobj.element("message", ToolUtil.bytePacketStr(buff, "  "));
				Log.log("B6已经接收完毕==============================");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return jobj;
	}
	
	/**
	 * 读取车位状态
	 * @param carNum 车位数(一对一，一对二或是一对四)
	 * @param basePath	图片存储基本路径
	 * @return 车位状态的list
	 */
	protected List<CarData> getListCarData(int carNum,String basePath,String addr){
		List<CarData> list= new ArrayList<CarData>();
		int carCount = carNum;
		boolean flag = true;
		while(carCount -- >0){
			CarData car = new CarData();
			try {
				byte[] buff = new byte[5];
				is.read(buff);			//读取基本数据
				
				if(verifyCarData(buff[0],buff[1],buff[2],buff[3],buff[4])){
					car.setCameraId(buff[0]);//对应摄像头id,0或者1
					car.setCarCode(buff[1]);//车位编码
					car.setParkingSpaceStatus(Integer.toString(buff[2]));//车位状态
					car.setParkingSpaceType(Integer.toHexString(buff[3]));//车位类型
					car.setPlateLen(buff[4]);//车牌长度
					Log.debug("对应摄像头id:"+buff[0]+"车位编码:"+buff[1]+"车位状态:"+buff[2]+"车位类型:"+buff[3]+"车牌长度:"+buff[4]);
					int len = buff[4];
					buff = new byte[len];
					is.read(buff);
					String plateData = new String(buff,"UTF-8");
					Log.debug("车牌数据---"+plateData);
					car.setPlateData(plateData);
				}else{
					Log.warn("数据有误");
					Log.warn("对应摄像头id:"+buff[0]+"车位编码:"+buff[1]+"车位状态:"+buff[2]+"车位类型:"+buff[3]+"车牌长度:"+buff[4]);
					flag = false;
					break;
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				continue;
			}
			list.add(car);
		}
		
		if(flag){
			Log.debug("开始读取图片数据==============================");
			for(int pic = 0; pic < carNum; pic++){
				byte[] buff = new byte[4];
				int len;
				try {
					while((len = is.read(buff)) != -1){//读取图片长度
						if(len > 0){
							len = ToolUtil.fourBytesToInt(buff);
							Log.debug("图片文件的长度----"+len);
							if(len < IMAGE_MAX && len > 0){
								list.get(pic).setPictureLen(len);//图片大小
								int parts = len / LENGTH_PART;// 将图片的长度分成N部分来读取，每部分的长度为LENGTH_INDEX
								int left = len % LENGTH_PART;// 标记剩余的部分
								
								len = 0;
								FileOutputStream fos = null;
								StringBuilder filePath = new StringBuilder();

								// 生成图片文件夹和文件名.规则:探测器地址_探测器编号_(如果有车就加'车牌号码_')时间戳.jpg===========
								int cameraID = list.size() > 1 ? pic : list.get(0).getCameraId();
								filePath = createAndDeleteFile(basePath, list, addr, cameraID);
								// 生成图片文件夹和文件名完成===============================================
								
								list.get(pic).setPicPath(filePath.toString());//图片路径
								
								try {
									fos = new FileOutputStream(new File(filePath.toString()));
									while (parts-- > 0) {
										buff = new byte[LENGTH_PART];
										len = is.read(buff); // 读图片
										fos.write(buff, 0, len); // 写到图片文件
										while (len < LENGTH_PART) { // 如果读取的长度不是LENGTH_INDEX就再读一次剩余的部分
											buff = new byte[LENGTH_PART - len];
											int l = is.read(buff);
											fos.write(buff, 0, l);
											len += l;
										}
									}
									if (left > 0) {
										buff = new byte[left];
										len = is.read(buff);
										fos.write(buff, 0, len);
										while (len < left) { // 如果读取的长度不是surplus就再读一次剩余的部分
											buff = new byte[left - len];
											int l = is.read(buff);
											fos.write(buff, 0, l);
											len += l;
										}
									}
									fos.flush(); // 清空缓冲区
								} catch (IOException e) {

								} finally {
									if (fos != null) {
										fos.close();
									}
								}
							}
							else{
								list.get(pic).setPictureLen(0);//图片大小
								list.get(pic).setPicPath("");//图片路径
							}
							break;
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return list;
	}
	
	/**
	 * 校验返回的CarData数据
	 * @param data
	 * @return
	 */
	public boolean verifyCarData(byte cameraId,byte carCode, byte status, byte type, byte len){
		boolean flag = true;
		if(cameraId !=0 && cameraId != 1){
			flag = false;
		}else if(carCode !=0 && carCode !=1){
			flag = false;
		}else if(status != -1 && status != 0 && status !=1 && status !=2){
			flag = false;
		}else if(type != 0 && type != 1 && type != 2){
			flag = false;
		}else if(len > 20){
			flag = false;
		}
		return flag;
	}
	/**
	 * 创建文件目录,如果有就删除里面的文件
	 * @param path
	 * @param flag 用于标识是否删除文件夹下的图片
	 */
	public StringBuilder createAndDeleteFile(String path, List<CarData> listCar, String addr, int cameraID) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		StringBuilder filePath = new StringBuilder();
		// FilePath 要修改
		if (!path.equals("")) {
			filePath.append(StringManager.replaceAll(path, "\\", "/")).append("upload/car/");
		} else {
			String osName = System.getProperty("os.name");
			if (osName.startsWith("Windows")) { // 判断当前操作系统是windows还是os
				filePath.append(WINPATH);
			} else {
				filePath.append(CENTOSPATH);
			}
		}
		filePath.append(DateUtil.getCurDate()).append(ConstantClass.MyFile_Separator); // 创建当前日期文件夹
		filePath.append(addr).append(ConstantClass.MyFile_Separator);//以探测器的MAC地址后4位作为文件夹
		filePath.append(cameraID).append(ConstantClass.MyFile_Separator);//以摄像头的id作为文件夹
		File file = new File(filePath.toString());
		if (!file.exists()) { // 目录不存在就创建一个
			file.mkdirs();
		}else{
			deleteFile(file);
		}
		// 生成图片文件名.规则:探测器地址_探测器编号_(如果有车就加'车牌号码_')时间戳.jpg===========
		filePath.append(cameraID).append("_"); // 加探测器编号
		int pos = cameraID >= listCar.size() ? 0 : cameraID;
				
		if (!listCar.get(pos).getPlateData().equalsIgnoreCase("")) { // 如果有车就加'车牌号码_'
			filePath.append(listCar.get(pos).getPlateData());
		}
		filePath.append("_");
		
		filePath.append(sdf.format(new Date())).append(".jpg"); // 时间戳.jpg
		// 生成图片文件名完成===============================================
		Log.debug("生成的图片文件名: " + filePath);
		return filePath;
	}
	/**
	 * 递归删除文件
	 * @param dpath
	 */
	private void deleteFile(File f){
		if(f.isFile()){
			f.delete();
		}else{
			File[] files = f.listFiles();
			for(File file : files){
				deleteFile(file);
			}
		}
	}
	
	/**
	 * 运行中发现摄像头故障主动上传
	 * @param channel
	 * @param carCount
	 * @return 
	 * @throws IOException
	 */
	protected List<CarData> getListCarData(int carCount) throws IOException {
		List<CarData> listCar = new ArrayList<CarData>();
		while (carCount-- > 0) {
			byte[] buff = new byte[4];
			is.read(buff);
			CarData car = new CarData();
			car.setCameraId(buff[0]);
			car.setCarCode(buff[1]);
			car.setParkingSpaceStatus(Integer.toHexString(buff[2]));
			car.setParkingSpaceType(Integer.toHexString(buff[3]));
			listCar.add(car);
		}
		Log.debug("==================================================================================================");
		Log.debug("\n" + listCar);
		Log.debug("==================================================================================================");
		return listCar;
	}
	
	/**
	 * int类型转换成byte[]
	 * @param num	要转换的数据
	 * @param length 要转成几位字节
	 * @return byte[]	高字节在前,低字节在后
	 */
	protected static byte[] intToBytes(int num, int length) {
		byte[] bytes = new byte[length];
		for (int i = 0; i < length; i++) {
			bytes[i] = (byte)((num >> (length - i - 1) * 8) & 0x000000FF);
		}
		return bytes;
	}
	
	/**
	 * 将byte数组bRefArr转为一个整数,字节数组的低位是整型的低字节位
	 * 高8位在前,低8位在后
	 * @param bRefArr
	 * @return
	 */
	protected static int bytesToIntHTL(byte[] bRefArr) {
		int iOutcome = 0, size = bRefArr.length - 1;
		byte bLoop;
		for (int i = 0; i < bRefArr.length; i++) {
			bLoop = bRefArr[i];
			int unsignedByte = bLoop >= 0 ? bLoop : (256 + bLoop);
			iOutcome += (unsignedByte & 0x000000FF) << (8 * (size--)); // 高8位在前,低8位在后
		}
		return iOutcome;
	}
}
