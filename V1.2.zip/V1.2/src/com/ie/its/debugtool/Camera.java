package com.ie.its.debugtool;

public class Camera {
	private int cameraId;					//摄像头ID
	private String cameraStatus;			//摄像头状态，使能或禁用
	private int exposureValue;				//曝光度（-1～1）
	private int photoModeLen;				//拍照模式标识长度
	private String photoMode;				//拍照模式标识内容（可选值：auto, daylight, cloudy-daylight, fluorescent, incandescent, tungsten）
	
	private int carNum;						//一个摄像头对应几个车位，目前为1个
	private String status;					//摄像头状态，正常、故障或离线
	
	public Camera(){
		
	}
	public Camera(int cameraId){
		this.cameraId = cameraId;
	}
	public int getCameraId() {
		return cameraId;
	}
	public void setCameraId(int cameraId) {
		this.cameraId = cameraId;
	}
	public String getCameraStatus() {
		return cameraStatus;
	}
	public void setCameraStatus(String cameraStatus) {
		this.cameraStatus = cameraStatus;
	}
	public int getExposureValue() {
		return exposureValue;
	}
	public void setExposureValue(int exposureValue) {
		this.exposureValue = exposureValue;
	}
	public int getPhotoModeLen() {
		return photoModeLen;
	}
	public void setPhotoModeLen(int photoModeLen) {
		this.photoModeLen = photoModeLen;
	}
	public String getPhotoMode() {
		return photoMode;
	}
	public void setPhotoMode(String photoMode) {
		this.photoMode = photoMode;
	}
	public int getCarNum() {
		return carNum;
	}
	public void setCarNum(int carNum) {
		this.carNum = carNum;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
