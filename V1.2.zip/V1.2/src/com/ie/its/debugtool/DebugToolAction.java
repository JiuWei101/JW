package com.ie.its.debugtool;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
@SuppressWarnings("serial")
@Namespace("/debugtool")
public class DebugToolAction extends ExtendActionSupport {

	@Autowired
	private DebugToolService debugToolService;
	private CameraController data;
	private CarData carData;
	private Camera camera;
	
	public CameraController getData() {
		return data;
	}
	public void setData(CameraController data) {
		this.data = data;
	}
	public CarData getCarData() {
		return carData;
	}
	public void setCarData(CarData carData) {
		this.carData = carData;
	}
	public Camera getCamera() {
		return camera;
	}
	public void setCamera(Camera camera) {
		this.camera = camera;
	}
	public DebugToolAction(){
		if(data == null){
			data = new CameraController();
		}
	}
	@Action(value="debugtool_index",results={@Result(name="success",location="/debugtool/debugtool_index.jsp")})
	public String todebugtool_index(){
		String mapId = request.getParameter("mapId");
		if(!Util.isCon(mapId)){
			String ip = getIP();
			mapId = MapRemember.getMapIdByIp(ip);
		}
		data.setCode_id(mapId);
		data.setMap_src(debugToolService.getMapPath(mapId));
		data.setCode_name(debugToolService.getParkingSpaceStatus(mapId));
		return SUCCESS;
	}
	
	/**
	 * 更新车位状态
	 */
	@Action(value="loadStatus",results={@Result(type="json")})
	public void loadStatus(){
		String mapId = request.getParameter("mapId");
		String status = debugToolService.getParkingSpaceStatus(mapId);
		
		JSONObject jobj = new JSONObject();
		jobj.element("status", status);
		setJsonRes(jobj);
	}
	
	@Action(value="getmaplist",results={@Result(type="json")})
	public void getMapList(){
		String mapId = request.getParameter("mapId");
		JSONArray jarr = debugToolService.getMapList(mapId);
		setJsonRes(jarr);
	}

	/**
	 * OTA远程升级
	 */
	@Action(value="otaUpdate",results={@Result(type="json")})
	public void otaUpdate(){
		String addr = data.getShortmac();
		JSONObject jobj = debugToolService.startOtaUpdate(addr);
		setJsonRes(jobj);
	}
	
	/**
	 * 读取版本号
	 */
	@Action(value="readVersion",results={@Result(type="json")})
	public void readVersion(){
		String addr = data.getShortmac();
		JSONObject jobj = debugToolService.readVersion(addr);
		setJsonRes(jobj);
	}
	
	/**
	 * 获取所选探测器的所有状态
	 */
	@Action(value="getallcarstatus",results={@Result(type="json")})
	public void getAllCarStatus(){
		JSONObject jobj = debugToolService.getAllCarStatus(data);
		setJsonRes(jobj);
	}
	
	/**
	 * 获取单个摄像头的状态和区域
	 */
	@Action(value="getSingleCar", results={@Result(type="json")})
	public void getSingleCar(){
		JSONObject jobj = debugToolService.getSingleCarService(data);
		setJsonRes(jobj);
	}
	
	/**
	 * 设置单个摄像头的状态和区域
	 */
	@Action(value="setCarCycle", results={@Result(type="json")})
	public void setCarCycle(){
		JSONObject jobj = debugToolService.setCarCycleService(data, carData);
		setJsonRes(jobj);
	}

	@Action(value="getParkingSpaceNO", results={@Result(type="json")})
	public void getParkingSpaceNO(){
		JSONObject jobj = debugToolService.getParkingSpaceNO(data.getCode_name());
		setJsonRes(jobj);
	}
	
	@Action(value="getCamaraBasePara", results={@Result(type="json")})
	public void getCamaraBasePara(){
		JSONObject jobj = debugToolService.getCamaraBasePara(data.getShortmac());
		setJsonRes(jobj);
	}
	/**
	 * 获取探测器IP
	 */
	@Action(value="readIP", results={@Result(type="json")})
	public void readIP(){
		JSONObject jobj = debugToolService.readIP(data.getShortmac());
		setJsonRes(jobj);
	}
	
	/**
	 * 设置探测器IP
	 */
	@Action(value="setIP", results={@Result(type="json")})
	public void setIP(){
		JSONObject jobj = debugToolService.setIP(data);
		setJsonRes(jobj);
	}
	
	@Action(value="readPreferAP", results={@Result(type="json")})
	public void readPreferAP(){
		JSONObject jobj = debugToolService.readPreferAP(data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="setPreferAP", results={@Result(type="json")})
	public void setPreferAP(){
		JSONObject jobj = debugToolService.setPreferAP(data);
		setJsonRes(jobj);
	}
	
	@Action(value="setCarType", results={@Result(type="json")})
	public void setCarType(){
		JSONObject jobj = debugToolService.setCarType(carData, data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="setCarEnable", results={@Result(type="json")})
	public void setCarEnable(){
		JSONObject jobj = debugToolService.setCarEnable(carData, data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="readAllCarPara", results={@Result(type="json")})
	public void readAllCarPara(){
		JSONObject jobj = debugToolService.readAllCarPara(data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="getLibPara", results={@Result(type="json")})
	public void getLibPara(){
		JSONObject jobj = debugToolService.getLibPara(data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="setLibPara", results={@Result(type="json")})
	public void setLibPara(){
		JSONObject jobj = debugToolService.setLibPara(data);
		setJsonRes(jobj);
	}
	
	@Action(value="readCameraPara", results={@Result(type="json")})
	public void readCameraPara(){
		JSONObject jobj = debugToolService.readCameraPara(data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="setCameraPara", results={@Result(type="json")})
	public void setCameraPara(){
		JSONObject jobj = debugToolService.setCameraPara(data.getShortmac(), camera);
		setJsonRes(jobj);
	}
	
	@Action(value="searchParkingSpace", results={@Result(type="json")})
	public void searchParkingSpace(){
		JSONObject jobj = debugToolService.searchParkingSpace(data.getCode_id(), data.getCode_name(), data.getId());
		setJsonRes(jobj);
	}
	
	@Action(value="readWifiSignalStrength", results={@Result(type="json")})
	public void readWifiSignalStrength(){
		JSONObject jobj = debugToolService.readWifiSignalStrength(data.getShortmac());
		setJsonRes(jobj);
	}
	
	@Action(value="rememberMap", results={@Result(type="json")})
	public void rememberMap(){
		String ip = getIP();
		MapRemember.add(ip, data.getId());
	}
	
	/**
	 * OTA批量升级功能
	 */
	@Action(value="multiOTAUpdate", results={@Result(type="json")})
	public void multiOTAUpdate(){
		JSONObject json = debugToolService.multiOTAUpdate(data.getShortmac());
		setJsonRes(json);
	}
	
	/**
	 * 批量识别区域设置
	 * @return
	 */
	@Action(value="setMultiCycle", results={@Result(type="json")})
	public void setMultiCycle(){
		JSONObject json = debugToolService.setMultiCycle(data.getShortmac(), carData);
		setJsonRes(json);
	}
	
	/**
	 * 批量识别库参数设置
	 * @return
	 */
	@Action(value="setMultiParam", results={@Result(type="json")})
	public void setMultiParam(){
		JSONObject json = debugToolService.setMultiParam(data);
		setJsonRes(json);
	}
	
	private String getIP(){
		String hostIp = ServletActionContext.getRequest().getRemoteHost();
		hostIp = hostIp.equalsIgnoreCase("0:0:0:0:0:0:0:1") ? "127.0.0.1" : hostIp;
		return hostIp;
	}
}






























