package com.ie.its.monitor;

import static com.ie.common.Util.*;
import sun.util.logging.resources.logging;
import net.sf.json.JSONObject;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.baseinfo.BaseInfoData;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;
import com.jspsmart.upload.Request;

public class MonitorSql extends ExtendSql{
	/**
     * Description :查询地图．
     * @param  :MapManageData,String
     * @return :String
     */
	public String timeout_list(MonitorData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select round(substring(timediff(curtime(),p.useTime), 1," +
					" instr(timediff(curtime(),p.useTime),':')-1) + " +
					" datediff(curdate(),p.useDate) * 24 + " +
					" substring(timediff(curtime(),p.useTime), 4, 2)/60, 2) as userDate," +
					" m.number,m.name,d.code as detector_code, p.*,g.name as g_name,l.name as l_name ";
		}
		
		querySql += " from p_parkingspace p";
		querySql += " left join p_detector d on d.id=p.detectorId ";
		querySql += " left join p_guideregion g on d.guideRegionId=g.id ";
		querySql += " left join p_logicregion l on l.id=p.logicId ";
		querySql += " left join p_map m on m.id=d.mapId where d.status='0' and p.inuse='1' ";
		if(Util.isCon(data.getUserDateInt())){
			querySql += " and substring(timediff(curtime(),useTime),";
			querySql += " 1,instr(timediff(curtime(),useTime),':')-1) + ";
			querySql += " datediff(curdate(),useDate) * 24 + ";
			querySql += " substring(timediff(curtime(),p.useTime), 4, 2)/60  >= "+ data.getUserDateInt();
		}
		if(isCon(data.getMapId())){
			querySql += " and d.mapId = " + toSqlVal(data.getMapId());
		}
		if(isCon(data.getLogic_id())){
			querySql += " and p.logicId = " + toSqlVal(data.getLogic_id());
		}
		return querySql;
	}
	
   //edit by jiangyf at 2013-4-23 for 视屏探测器
	public String fault_list(MonitorData data, String type, String lang) {
		String query = "";
		if(type.equals("count")){
			query+="select count(*) from ( select sls.code_value as status,ss.* from (";
		}else{
			query+="select sls.code_value as status,ss.* from (";
		}
		query += "select status as status_com,pd.code as self_type,m.number,m.name,d.addr as fault_Arr,pl.name as l_name,"+
				" d.code as detector_code,pl.id as logicId,m.id as mapId " +
				" from p_detector d" +
				" inner join p_parkingspace p on d.id=p.detectorId" +
				" left join p_logicregion pl on pl.id=p.logicId" +
				" left join p_detectortype pd on d.detectorTypeId=pd.id" +
				" inner join p_map m on m.id=d.mapId where d.status<>0 and d.detectorTypeId<>4 " +
				//edit by jiangyf
				"union all select distinct d.status as status_com, pd. code AS self_type, m.number, m. NAME, d.addr AS fault_Arr, pl. NAME AS l_name, " +
				"pc.addr AS detector_code, pl.id AS logicId, m.id AS mapId FROM p_detector d " +
				"INNER JOIN p_parkingspace p ON d.id = p.detectorId " +
				"LEFT JOIN p_logicregion pl ON pl.id = p.logicId" +
				" LEFT JOIN p_detectortype pd ON d.detectorTypeId = pd.id " +
				"INNER JOIN p_map m ON m.id = d.mapId " +
				"INNER JOIN p_controller pc ON pc.id = d.controllerId WHERE d. STATUS <> 0 AND d.detectorTypeId = 4"+
				//end
				" union all select status as status_com,'5' AS self_type,m.number,m.name,s.addr as fault_Arr,'',s.code as detector_code,'',m.id as mapId " +
				" from p_screen s" +
				" " +
				" left join p_map m on m.id=s.mapId" +
				" left join p_screentype st on st.code=s.screenTypeCode" +
				" where s.status<>0 " ;
		
		query += "  ) ss ";
		query += " inner join sys_lang_switch sls on sls.code_key=ss.status_com and sls.code_type='ctrl_status' and sls.lang= " + Util.toSqlVal(lang);
		
		if(isCon(data.getMapId())){
			query += " and mapId = " + toSqlVal(data.getMapId());
		}
		if(isCon(data.getLogic_id())){
			query += " and logicId = " + toSqlVal(data.getLogic_id());
		}
		if(isCon(data.getDetector_code())){
			query += " and detector_code like " + toSqlValLike(data.getDetector_code(), "ALL");
		}
		if(isCon(data.getStatus())){
			query += " and status_com = " + toSqlVal(data.getStatus());
		}
		if(type.equals("count")){
			query += " ) t1";
		}
		query +="  ORDER BY self_type";
		Log.log(query);
		return query; 
	}


	public String chart_list() {
		String querySql = "select parkingSum as use_number_2,sum( case when p.inuse=1 or d.status=1 then 1 else 0 end ) as use_number,pm.name,pm.id as map_id from p_map pm ";
			querySql += " left join p_detector d on pm.id=d.mapId ";
			querySql += " inner join p_parkingspace p on p.detectorId=d.id";
			querySql += " group by parkingSum,pm.name,pm.id ";
		return querySql;
	}


	public static String updateStatus(String status,String machineId){
		String sql = "update p_pathnodeinfohead set status = '"+status+"' where IP= '"+machineId+ "'";
		return sql;
	}

	public static String getHisCount(String date) {
		
		String querySql = "select count(*) from p_parkingspacestatistics ";
			querySql += " where year =  " + date.substring(0, 4);
			querySql += " and month = " + date.substring(5, 7);
			querySql += " and day = " + date.substring(8, 10);
			System.out.println("---"+querySql);
		return querySql;
	}

	/**
	 * @param date
	 * @return
	 */
	public static String getHisData(String date) {//删去isin
		//physicalregionId,maplogicregionId
		//String lastDay = DateUtil.getNextDay(date, "-1");
		String querySql = " select ps.id,ps.parkingSpaceId,ps.parkingSpaceCode,ps.spotType,date_format(ps.inTime,'%Y-%m-%d %H:%i:%s') as inTime,date_format(ps.outTime,'%Y-%m-%d %H:%i:%s') as outTime,ps.putOut ";
			querySql += " ,pe.logicId as maplogicregionId, pe.physicalRegionId as physicalregionId ";
			querySql += " ,pr.physicalRegionName as physicalregionName, pl.name as maplogicregionName ";//zh
			querySql += " ,pe.id as parkingSpaceId, pe.code as parkingSpaceCode";//后加 车位Id和车位code
			querySql += " from p_parkingspaceoperationhis ps ";
			querySql += " left join p_parkingspace pe on pe.id = ps.parkingSpaceId ";  
		//****增加物理区域和逻辑区域名 by zh
			querySql += " left join p_physicalregion pr on pr.id = pe.physicalRegionId ";//物理
			querySql += " left join p_logicregion pl on pl.id = pe.logicId ";
			querySql += " where intime <= " + toSqlVal(date + " 23:59:59");
			querySql += " and intime >= " + toSqlVal(date + " 00:00:00");
		return querySql;
	}

	public static String getHisCountByConditions(String outTime,String id){
		String querySql = " select count(*) from p_parkingspaceoperationhis ps where ps.outTime = "+Util.toSqlVal(outTime)+" and ps.id ="+Util.toSqlVal(id);
		System.out.println(querySql);
		return querySql;
		
	}

	/**
	 * @param jo 基本信息
	 * @param json 算出来的 小时 时长 进出双数  共4个字段
	 * @param date 日期
	 * @return
	 */
	public static String InsertDataNor(String id, JSONObject jo, JSONObject json, String date) {
		String insertSql = "insert into p_parkingspacestatistics (id,physicalregionId,maplogicregionId";
			insertSql += ",year,month,day,hour,duration,inCount,outCount,spotType,status," +
					"physicalregionName,maplogicregionName,parkingSpaceId,parkingSpaceCode)";//zh
			insertSql += " values (" + Util.toSqlVal(id) + "," + Util.toSqlVal(jo.getString("physicalregionId")) ;
			insertSql += "," + Util.toSqlVal(jo.getString("maplogicregionId"));
			insertSql += "," + Util.toSqlVal(json.getString("year")) + "," + Util.toSqlVal(json.getString("month"));
			insertSql += "," + Util.toSqlVal(json.getString("day")) ;
			insertSql += "," + Util.toSqlVal(json.getString("hour")) ;
			insertSql += "," + Util.toSqlVal(json.getString("duration")) ;
			insertSql += "," + Util.toSqlVal(json.getString("inCount"));
			insertSql += "," + Util.toSqlVal(json.getString("outCount"));
			insertSql += "," + Util.toSqlVal(jo.getString("spotType")) + ",0";
			insertSql += "," + Util.toSqlVal(jo.getString("physicalregionName"));//zh
			insertSql += "," + Util.toSqlVal(jo.getString("maplogicregionName"));//zh
			insertSql += "," + Util.toSqlVal(jo.getString("parkingSpaceId"));//zh
			insertSql += "," + Util.toSqlVal(jo.getString("parkingSpaceCode"));//zh
			insertSql += ")";
		return insertSql;
	}
	
	/**
	 * 把P_ParkingSpaceOperationLog表数据导入到P_ParkingSpaceOperationHis表里
	 * @param date
	 * @return
	 */
	public static String MoveLogToHis1(String date){//以前有一个isin字段跟在putOut之后，经查数据库所有表都无此字段，故删去 deleted by LLX 2012.09.07
		//以前入车，lastday出车和lastday入车，lastday出车，两种情况数据的迁移
		String lastDay = DateUtil.getNextDay(date, "-1");
		String querySql = "insert into p_parkingspaceoperationhis (id,parkingSpaceId,parkingSpaceCode,spotType,inTime,outTime,putOut)" +
				" select id,parkingSpaceId,parkingSpaceCode,spotType," +
				" case when inTime <= '" + lastDay + " 00:00:00' then '" + lastDay + " 00:00:00' else intime end as intime ," + 
				" case when outTime > '" + date + " 00:00:00' then '" + lastDay + " 23:59:59' " + 
				" else outtime end as outtime," + 
				" case when outTime > '" + date + " 00:00:00' then 0 else 1 end" +
				" as putOut" +
				" from p_parkingspaceoperationlog " +
				" where putOut = 1 and intime < " + toSqlVal(date +" 00:00:00") ;				
		System.out.println("MoveLogToHis1----------" + querySql);
		return querySql;
	}
	
	/**
	 * 把P_ParkingSpaceOperationLog表数据导入到P_ParkingSpaceOperationHis表里
	 * @param date
	 * @return
	 */
	public static String MoveLogToHis2(String date){//同上  删去isin
		//以前入车，lastday未出和lastday入车，lastday未出，两种情况数据的迁移
		String lastDay = DateUtil.getNextDay(date, "-1");
		String querySql = "insert into p_parkingspaceoperationhis (id,parkingSpaceId,parkingSpaceCode,spotType,inTime,outTime,putOut)" +
				" select id,parkingSpaceId,parkingSpaceCode,spotType," +
				" case when inTime < '" + lastDay + " 00:00:00' then '" + lastDay + " 00:00:00' else intime end as intime ,'" + 
				lastDay + " 23:59:59'  as outtime,0"
				+ " from p_parkingspaceoperationlog " +
				" where putout = 0 and intime < " + toSqlVal(date +" 00:00:00");
		System.out.println("MoveLogToHis2----------" + querySql);
		return querySql;
	}
	
	public static String getOneFromHis(String id,String inTime,String outTime,String putout){
		String querySql = " select count(*) from p_parkingspaceoperationhis " +
				" where putout = "+ putout +" and inTime = " + toSqlVal(inTime)+" and outTime = " + toSqlVal(outTime)+" and id = " + toSqlVal(id);
		System.out.println("getOneFromHis----------" + querySql);
		return querySql;
	}
	
	public static String moveOneFromLogtoHis(String id,String parkingSpaceId,String parkingSpaceCode, String spotType ,String inTime, String outTime,String putout,String plateno,String picturepath){
		String querySql = "insert into p_parkingspaceoperationhis (id,parkingSpaceId,parkingSpaceCode,spotType,inTime,outTime,putOut,plateno,picturepath) values ("
				+toSqlVal(id)+", "
				+toSqlVal(parkingSpaceId)+", "
				+toSqlVal(parkingSpaceCode)+", "
				+toSqlVal(spotType)+", "
				+toSqlVal(inTime)+", "
				+toSqlVal(outTime)+", "
				+toSqlVal(putout)+","
				+toSqlVal(plateno)+","
				+toSqlVal(picturepath)+")";
		System.out.println("moveOneFromLogtoHis----------" + querySql);
		return querySql;
	}
	/**
	 * 计数Date日期前数据条数
	 * @param curDate 
	 * @param date
	 * @param type
	 * @return
	 */
	public static String getMoveCount(String curDate) {
		//String lastDay = DateUtil.getNextDay(curDate, "-1");
		String querySql = "select count(*) from p_parkingspaceoperationlog " 
			+ " where intime < " + toSqlVal(curDate + " 00:00:00"); 
			//+" and parkingSpaceId in (select id from p_parkingspace)";
		return querySql;
	}
	/**
	 * 获取所有入车时间小于当前日期0点的记录
	 * @param curDate
	 * @return
	 */
	public static String getAllInNotCurDate(String curDate){
		String querySql = " select id,parkingSpaceId,parkingSpaceCode,spotType,date_format(inTime,'%Y-%m-%d %H:%i:%s') as inTime,date_format(outTime,'%Y-%m-%d %H:%i:%s') as outTime,putOut,plateno,picturepath from p_parkingspaceoperationlog " 
			+ " where intime < " + toSqlVal(curDate + " 00:00:00") ;
			//+" and parkingSpaceId in (select id from p_parkingspace)";
		return querySql;
	}
	/**
	 * 删除所有parkingSpaceId不在p_parkingspace中的停车记录（即此车位已经删除，停车出入数据已无用）
	 * @return
	 */
	public static String deleteLogs(){
		String querySql = "delete from p_parkingspaceoperationlog where parkingSpaceId not in (select id from p_parkingspace)";
		return querySql;
	}
	/**
	 * 删除date日期前log表中数据
	 * @param date
	 * @return
	 */
	public static String deleteLog(String date){
		String querySql = "delete from p_parkingspaceoperationlog where outtime < " 
			+ Util.toSqlVal(date + " 00:00:00");
		return querySql;
	}


	public String chart_total(String lang) {
		String querySql = "select Sum(parkingSum) as use_number_2,(select Sum(case when p.inuse=1 or d.status=1 then 1 else 0 end )from p_parkingspace p left join p_detector d on p.detectorId = d.id) as use_number,";
		querySql += " (select code_value from sys_lang_switch sls where sls.lang = " + lang + " and sls.code_type='common' and sls.code_key='all') as name,'noCheckUrl' as map_id from p_map pm ";	
		return querySql;
	}
	
	//获取报警基本信息
	public String getAlarmBaseInfor() {
		String querySql = "select * from p_alarmservicebase limit 1";
		return querySql;
	}
	
	public String base_query(String id) {
		String querySql = "select count(*) from p_alarmservicebase where id = " + Util.toSqlVal(id);
		return querySql;
	}
	
	public String base_update(MonitorData data) {
		String updateSql = "update p_alarmservicebase set ";
		 	updateSql += " mobilephone = " + Util.toSqlVal(data.getMobilephone()) + ",";
		 	updateSql += " noticeway = " + Util.toSqlVal(data.getNoticeway()) + ",";
		 	updateSql += " enabledflag = " + Util.toSqlVal(data.getEnableflag()) + ",";
		 	updateSql += " describes = " + Util.toSqlVal(data.getDescribes()) + ",";
		 	updateSql += " attribute1 = " + Util.toSqlVal(data.getAttribute1()) + ",";
		 	updateSql += " attribute2 = " + Util.toSqlVal(data.getAttribute2()) + ",";
		 	updateSql += " attribute3 = " + Util.toSqlVal(data.getAttribute3()) ;
		 	
		 	updateSql += " where id = " + Util.toSqlVal(data.getBid());
		 	
		return updateSql;
	}
	
	public String base_save(MonitorData data) {
		String insertSql = "insert into p_alarmservicebase(id,mobilephone,noticeway,enabledflag,describes,attribute1,attribute2,attribute3) ";
			insertSql += " values(" + Util.toSqlVal(PrimaryId.getId());
			insertSql += "," + Util.toSqlVal(data.getMobilephone());
			insertSql += ","+ Util.toSqlVal(data.getNoticeway()) ;
			insertSql += "," + Util.toSqlVal(data.getEnableflag());
			insertSql += "," + Util.toSqlVal(data.getDescribes()) ;
			insertSql += "," + Util.toSqlVal(data.getAttribute1()) ;
			insertSql += "," + Util.toSqlVal(data.getAttribute2()) ;
			insertSql += "," + Util.toSqlVal(data.getAttribute3());
			insertSql += ")";
		return insertSql;
	}
	
	
	public String get_message_list(MonitorData data, String type, String lang) {
		String query = "";
		if(type.equals("count")){
			query+="select count(*) from (";
		}else{
			query+="select * from (";
		}
		query +=" select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           ctrl.addr s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           ctrl.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_controller ctrl "+
			    "     where alsc.devicetype = 1 "+
			    "       and alsc.deviceid = ctrl.id "+
			    "    union all "+
			    "    select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           scr.code s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           scr.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_screen scr "+
			    "     where alsc.devicetype = 2 "+
			    "       and alsc.deviceid = scr.id "+
			    "    union all "+
			    "    select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           detr.code s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           detr.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_detector detr "+
			    "     where alsc.devicetype = 3 "+
			    "       and alsc.deviceid = detr.id) t "+
			    "     order by t.s_devicetype, t.s_code ";
		Log.log(query);
		return query; 
		
	}
	
	public String alarmmessage_list(String type) {
		String query = "";
		if(type.equals("count")){
			query+="select count(*) from (";
		}else{
			query+="select * from (";
		}
		query +=" select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           ctrl.addr s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           ctrl.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_controller ctrl "+
			    "     where alsc.devicetype = 1 "+
			    "       and alsc.deviceid = ctrl.id "+
			    "    union all "+
			    "    select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           scr.code s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           scr.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_screen scr "+
			    "     where alsc.devicetype = 2 "+
			    "       and alsc.deviceid = scr.id "+
			    "    union all "+
			    "    select alsc.id s_id, "+
			    "           alsc.devicetype s_devicetype, "+
			    "           detr.code s_code, "+
			    "           alsc.alarmmessage s_alarmmessage, "+
			    "           alsc.mobilephone s_mobilephone, "+
			    "           alsc.noticeway s_noticeway, "+
			    "           alsc.isneedsend s_isneedsend, "+
			    "           detr.status s_status, "+
			    "           alsc.alreadysend s_alreadysend "+
			    "      from p_alarmservicecentre alsc, p_detector detr "+
			    "     where alsc.devicetype = 3 "+
			    "       and alsc.deviceid = detr.id) t "+
			    "     order by t.s_devicetype, t.s_code ";
		Log.log(query);
		return query; 
	}
	
	public String alarm_update(MonitorData data) {
		String updateSql = "update p_alarmservicecentre set ";
		 	updateSql += " alreadysend = " + Util.toSqlVal(data.getS_alreadysend()) ;
		 	
		 	updateSql += " where id = " + Util.toSqlVal(data.getS_id());
		 	
		return updateSql;
	}
	
	/**
	 * 获取p_parkingspacestatistics表的所有ID
	 * @return
	 */
	public static String queryStatisticsIdList() {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb.append("select id from p_parkingspacestatistics");
		return sb.toString();
	}
	
	/**
	 * 查找p_parkingspace的id
	 * @return
	 */
	public static String getParkingSpaceIdList() {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("select id from p_parkingspace;");
		return sb.toString();
	}
	
	/**
	 * 查询同一个车位多条未出车记录
	 * @param parkingSpaceId
	 * @return
	 */
	public static String queryForRepeatRecordId(String parkingSpaceId) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("select id from p_parkingspaceoperationlog where parkingSpaceId=")
			.append(Util.toSqlVal(parkingSpaceId)).append(" and putOut=0 ORDER BY inTime DESC limit 1, 1000");
		return sb.toString();
	}
	
	/**
	 * 把同一个车位多条未出车记录先出车.(错误的记录)
	 * @param parkingSpaceId
	 * @param inDate 
	 */
	public static String moveCardRecordOutWithRepeat(String parkingSpaceId, String inDate) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("update p_parkingspaceoperationlog set putOut=1, outTime=");
			sb.append(Util.toSqlVal(inDate)).append(" where id in ('")
			.append(parkingSpaceId).append("')");
		return sb.toString();
	}
}
