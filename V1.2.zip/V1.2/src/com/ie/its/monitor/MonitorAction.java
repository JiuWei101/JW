/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.monitor;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Map;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.jofc.BarChart;
import com.ie.jofc.BuilderChart;

//命名空间
@Namespace("/monitor")

public class MonitorAction extends ExtendActionSupport {
	
	private MonitorData data;
	@Autowired
	private MonitorService monitorService;
	
	
	public MonitorData getData() {
		return data;
	}
	public void setData(MonitorData data) {
		this.data = data;
	}
	public MonitorAction(){
		if(data == null){
			data = new MonitorData();
		}
	}
	
	/**
     * Description :超时监控．
     * @throws :Exception
     */
	@Action(value="chart_init",results={@Result(name="success",location="/monitor/chart.jsp")})
	public String chart_init(){
		setLang(data);
		return SUCCESS;
	}
	
	/**
     * Description :监控列表数据读取．
     * @throws :Exception
     */
	@Action(value="chart_list",results={@Result(type="json")})
	public void chart_list() throws Exception {
		String lang = request.getSession().getAttribute("lang").toString();
		JSONArray use_list = monitorService.chart_list(lang);
		JSONObject jo = new JSONObject();
		jo.element("click", "");
		jo.element("arr", use_list);
		BuilderChart bc = new BuilderChart();
		BarChart bar = new BarChart(2);
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("chart_title");
		jo = bc.getBuilder(jo, bar, map.get("use_number").toString(), map.get("total_number").toString());
		setJsonRes(jo);
	}
	
	public String getIpAddr() throws SocketException {
		Enumeration<NetworkInterface> netInterfaces = null;
		netInterfaces = NetworkInterface.getNetworkInterfaces();
		String ip = "";
		while (netInterfaces.hasMoreElements()) {
			NetworkInterface ni = netInterfaces.nextElement();
			Enumeration<InetAddress> ips = ni.getInetAddresses();	//这么取得的ip也会包含hosts中的127.0.0.1
			while (ips.hasMoreElements()) {
				InetAddress nextElement = ips.nextElement();
				ip = ips.nextElement().getHostAddress();
			}
		}
		return ip;
	}
	
	/**
     * Description :超时监控．
     * @throws :Exception
     */
	@Action(value="timeout_list",results={@Result(name="success",location="/monitor/timeout_list.jsp")})
	public String timeout_list(){
		
		if(!Util.isCon(data.getUserDateInt())){
			data.setUserDateInt("48");
		}
		data = monitorService.timeout_list(data);
		data.setLogicList(monitorService.getLogicRegionCode());
		data.setMapList(monitorService.get_mapCode());
		//设置多语言
		data.setLang(request.getSession().getAttribute("lang").toString());
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	/**
     * Description :故障监控．
     * @throws :Exception
     */
	@Action(value="fault_list",results={@Result(name="success",location="/monitor/fault_list.jsp")})
	public String fault_list(){
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		//取数据
		data = monitorService.fault_list(data,lang);
		data.setStatusList(monitorService.getStatusList(lang));
		data.setMapList(monitorService.get_mapCode());
		data.setLogicList(monitorService.getLogicRegionCode());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return SUCCESS;
	}

	/**
	 * 获取地图路径
	 * @throws Exception
	 */
	@Action(value="getFlashPath",results={@Result(type="json")})
	public void getFlashPath() throws Exception{
		JSONObject json = monitorService.getFlashPath(data.getMapId());
		setLang(data);
		setJsonRes(json);
	}
	
	/**
     * Description :短信报警服务
     * @throws :Exception
     */
	@Action(value="message_list",results={@Result(name="success",location="/monitor/message_list.jsp")})
	public String message_list(){
		
		String lang = request.getSession().getAttribute("lang").toString();
		//设置多语言
		setLang(data);
		data = monitorService.get_message_list(data,lang);

		//读取报警基本信息
		MonitorData alarm = new MonitorData();
		alarm = monitorService.getAlarmBaseInfor();
		data.setBid(alarm.getId());
		data.setMobilephone(alarm.getMobilephone());
		data.setNoticeway(alarm.getNoticeway());
		data.setEnableflag(alarm.getEnableflag());
		data.setDescribes(alarm.getDescribes());
		data.setAttribute1(alarm.getAttribute1());
		data.setAttribute2(alarm.getAttribute2());
		data.setAttribute3(alarm.getAttribute3());
		
		//获得是否开启下拉框
		data.setEnableList(DisposalCode.getCode("detector_enable",request.getSession().getAttribute("lang").toString()));
		//通知方式
		data.setNoticewayList(DisposalCode.getCode("notice_way",request.getSession().getAttribute("lang").toString()));
		
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());

		return SUCCESS;
	}
	
	/**
     * Description :报警基本信息保存．
     * @throws :Exception
     */
	@Action(value="base_save",results={@Result(type="json")})
	public void base_save() throws Exception{
		JSONObject json = monitorService.AlarmBaseInfor_save(data);
		//m.rateTask();
		setLang(data);
		setJsonRes(json);
	}
}
