/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.monitor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jxl.write.DateTime;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.ie.common.BeanUtil;
import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendRowMapperObj;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;
import com.ie.its.baseinfo.BaseInfoData;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.inversionsearch.SerachMachineOperation;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.parkingstatistics.ParkingStatisticsData;
import com.ie.its.screenconfig.ScreenData;

@Component("MonitorService")
public class MonitorService extends ExtendService {
	private  MonitorSql monitorSql;
	@Resource
	private  DataSource ds;
	public MonitorService(){
		monitorSql = new MonitorSql();
	}
	
	/**
     * Description :查询地图．
     * @param  :MapManageData
     * @return :MapManageData
     * @throws :Exception
     */
	public MonitorData timeout_list(MonitorData data) {
		//获得数量
		int count = this.getJt().queryForInt(monitorSql.timeout_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <MonitorData>rows = this.getJt().<MonitorData>queryForListExt(monitorSql.timeout_list(data, ""), 
				data.getStart(), data.getLimit(),MonitorData.class);
		
		for(int i=0;i<rows.size();i++){
			MonitorData monitorData = rows.get(i);
			String code = monitorData.getDetector_code();
			if(Util.isCon(code)){
				int len = code.length()/2;
				monitorData.setGArr(code.substring(0, len));
				monitorData.setTArr(code.substring(len, code.length()));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}


	public MonitorData fault_list(MonitorData data,String lang) {
		//获得数量
		int count  = this.getJt().queryForInt(monitorSql.fault_list(data, "count",lang));
		
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <MonitorData>rows = this.getJt().<MonitorData>queryForListExt(monitorSql.fault_list(data, "",lang), 
				data.getStart(), data.getLimit(),MonitorData.class);
		for(MonitorData temp:rows){
			temp.setSelf_type_Num(temp.getSelf_type());
			temp.setSelf_type((String) ((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(temp.getSelf_type()));
		}
		data.setPer_data(rows);
		return data;
	}


	public JSONArray chart_list(String lang) {
		JSONArray arr = new JSONArray();
		arr = this.getJt().queryForJSONArrayExt(monitorSql.chart_list());
		JSONObject jo = this.getJt().queryForJSONArrayExt(monitorSql.chart_total(lang)).getJSONObject(0);
		arr.add(jo);
		return arr;
	}

	/**
	 * 计划每天凌晨三点从
	 * P_ParkingSpaceOperationHis车位流水记录历史表中
	 * 分离数据到统计表P_ParkingSpaceStatistics
	 */
	@SuppressWarnings("unchecked")
	public static void rateTask(DataSource ds) {
		try{
			//当前时间
			String curHour = DateUtil.getCurHour();
			String curDate = DateUtil.getCurDate();
			//默认
			int numberDay = 3;  //设定计算哪几天;
			String dataAnalysisTime = "03"; //几点开始
			
			ArrayList<String> li = new ArrayList<String>();
			JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
			String sql = "select dataAnalysisTime,dataAnalysisDays from p_parking ";//停车场信息维护里填的 凌晨 01,02,03,04,05 （在00点之后，00点要执行从log到His表数据分离）
			BaseInfoData data = jt.queryForObjectExt(sql, BaseInfoData.class);
			
			//从数据库p_parking中取值
			if(Util.isCon(data.getDataAnalysisTime())){
				dataAnalysisTime = data.getDataAnalysisTime();
			}
			if(Util.isCon(data.getDataAnalysisDays())){
				numberDay = data.getDataAnalysisDays();
			}
			
			for(int i = 1; i <= numberDay; i++){
				li.add(DateUtil.getNextDay(curDate, (-i) + ""));
			}
			
			if(curHour.equals(dataAnalysisTime)){//3点执行
				List<String> statisticsIdList = new ArrayList<String>();					//获取p_parkingspacestatistics表的ID,防止ID重复
				statisticsIdList = jt.queryForListExt(MonitorSql.queryStatisticsIdList(), String.class);
				for (int i = 0; i < li.size(); i++) {
					//传进来的日期下 车位统计表里是否有数据
					int count = jt.queryForInt(MonitorSql.getHisCount(li.get(i)));
					if(count == 0){   //无数据就得生成 哎
						Log.log("+++++++++"+li.get(i)+" 此日期数据尚未拆分");
						Log.log("" + MonitorSql.getHisData(li.get(i)));
						JSONArray arr = jt.queryForJSONArrayExt(MonitorSql.getHisData(li.get(i)));
						for (int j = 0; j < arr.size(); j++) {
							JSONArray calDuration = new JSONArray();
							JSONObject jo = arr.getJSONObject(j);
							calDuration = beforeHourSplit(jo, li.get(i), jt);
							List<String> batchInsertSql = new ArrayList<String>();				//用于保存批量插入的语句,拆分的数据
							for (int k = 0; k < calDuration.size(); k++) {//TODO
								if(calDuration.getJSONObject(k).getString("duration").indexOf("-") == -1){
									String tempStr = getParimaryId(statisticsIdList);
									String insertData = MonitorSql.InsertDataNor(tempStr, jo, calDuration.getJSONObject(k), li.get(i));
									statisticsIdList.add(tempStr);		
									Log.log("需要插入的语句: " + insertData);
									batchInsertSql.add(insertData);
	//								jt.update(MonitorSql.InsertDataNor(jo, calDuration.getJSONObject(k), li.get(i)));
								}else{
									Log.log("------历史--to--明细------有问题----duration : "
											+ calDuration.getJSONObject(k).getString("duration"));
								}
							}
							int batchInsertSize = batchInsertSql.size();
							if(batchInsertSize > 0){
								try{
									Log.log("------插入拆分数据到数据库-------");
									String[] batchInsertArr = batchInsertSql.toArray(new String[batchInsertSize]);
									jt.batchUpdate(batchInsertArr);
								} catch(Exception ex){
									Log.log("插入拆分数据出错." + ex.getMessage());
								}
							}
						}
					}
					else
					{
						Log.log("+++++++++"+li.get(i)+" 此日期数据已拆分");
					}
				}
			}
		}catch(Exception e){
			Log.log(e.getMessage());
		}
	}
	
	/**
	 * 获取主键id, 防止重复ID  ---by mo 2014-10-13
	 * @return
	 */
	private static String getParimaryId(List<String> statisticsIdList){
		Random random = new Random();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		StringBuilder sb = new StringBuilder(sdf.format(new Date()));
		sb.append(random.nextInt(99));
		String tempStr = sb.toString();
		while(statisticsIdList.contains(tempStr)){
			sb.append(random.nextInt(99));
			tempStr = (sb.length() > 100 ? sb.toString().substring(sb.length() - 100, sb.length()) : sb.toString());
		}
		return sb.toString();
	}
	
	/**
	 * 每天凌晨0点
	 * 将车位流水记录Log表中数据导入到His表中
	 * @param ds
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void moveLogToHis(DataSource ds) throws Exception{
		//当前时间
		String curHour = DateUtil.getCurHour();
		final String curDate = DateUtil.getCurDate();
		WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
		TransactionTemplate tt = new TransactionTemplate((PlatformTransactionManager)wac.getBean("txManager"));//spring 事物管理模版
		final JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
		//删除p_parkingspaceoperationlog表中无效的记录（parkingSpaceId不在p_parkingspace表中的记录）
		int deleteLogCount = jt.update(MonitorSql.deleteLogs());
		Log.log("删除Log表中无效记录条数--------"+deleteLogCount);
		
		if(curHour.equals("23")){//23点执行curHour.equals("23")
			//先把同一个车位多条未出车记录先出车.(错误的记录)			---by mo 2014-10-13
			JSONArray parkingSpaceIdList = jt.queryForJSONArrayExt(MonitorSql.getParkingSpaceIdList());
			for (Object object : parkingSpaceIdList) {
				String parkingSpaceId = JSONObject.fromObject(object).getString("id");
				List<String> repeatRecordId = jt.queryForList(MonitorSql.queryForRepeatRecordId(parkingSpaceId), String.class);
				if(repeatRecordId != null && repeatRecordId.size() > 0){
					String newRecordId = repeatRecordId.toString().replace("[", "").replace("]", "").replace(", ", "\',\'");
					jt.execute(MonitorSql.moveCardRecordOutWithRepeat(newRecordId, DateUtil.getCurDate() + " 23:50:00"));
				}
			}
		}
		
		if(curHour.equals("00")){//0点执行
			try{
			//获取入车时间inTime小于curDate 00:00:00的停车记录数
			final int logCount = jt.queryForInt(MonitorSql.getMoveCount(curDate));
			if(logCount != 0){
			tt.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus ts){
					try{
						//获取所有入车时间小于当前00:00:00的记录
						JSONArray alljArr = jt.queryForJSONArrayExt(MonitorSql.getAllInNotCurDate(curDate));
						if(alljArr.size() > 0){
							for(int i=0; i<alljArr.size(); i++){
								JSONObject tempObj = alljArr.getJSONObject(i);
								String id = tempObj.getString("id");
								String parkingSpaceId = tempObj.getString("parkingSpaceId");
								String parkingSpaceCode = tempObj.getString("parkingSpaceCode");
								String spotType = tempObj.getString("spotType");
								String inTime = tempObj.getString("inTime");
								String outTime = tempObj.getString("outTime");
								String putOut = tempObj.getString("putOut");
								String plateno = tempObj.getString("plateno");
								String picturepath = tempObj.getString("picturepath");
								String inDate = inTime.substring(0, 10);//入车日期如2013-04-06
								if(putOut.equals("1")){//已出车记录
									String outDate = outTime.substring(0, 10);//出车日期如2013-04-12
									if(inDate.equals(outDate)){//同天入车出车
										final int sameDayInOutCount = jt.queryForInt(MonitorSql.getOneFromHis(id, inTime, outTime, putOut));
										if(sameDayInOutCount == 0){
											jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType, inTime, outTime, putOut,plateno,picturepath));
										}
									}else{//不同天入车出车
										//处理第一条迁移记录
										final int firstDiffrentDayInOutCount = jt.queryForInt(MonitorSql.getOneFromHis(id, inTime, inDate+" 23:59:59", "0"));
										if(firstDiffrentDayInOutCount == 0){
											jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType, inTime, inDate+" 23:59:59", "0",plateno,picturepath));
										}
										
										//处理中间迁移记录
										String tempDate = DateUtil.getNextDay(inDate, "1");
										while(!tempDate.equals(outDate)){
											final int betweenCount = jt.queryForInt(MonitorSql.getOneFromHis(id, tempDate +" 00:00:00", tempDate+" 23:59:59", "0"));
											if(betweenCount == 0){
												jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType, tempDate +" 00:00:00", tempDate+" 23:59:59", "0",plateno,picturepath));
											}
											tempDate = DateUtil.getNextDay(tempDate, "1");
										}
										//处理最后一条迁移记录
										if(outDate.equals(curDate)){//出车日期与迁移日期相等
											System.out.println("出车日期与当前日期相等");
										}else{
											final int lastDiffrentDayInOutCount = jt.queryForInt(MonitorSql.getOneFromHis(id, outDate +" 00:00:00",outTime, "1"));
											if(lastDiffrentDayInOutCount == 0){
												jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType,outDate +" 00:00:00",outTime, "1",plateno,picturepath));
											}
										}
									}
								}
								if(putOut.equals("0")){//未出车记录
									//处理第一条迁移记录
									final int firstInNotOutCount = jt.queryForInt(MonitorSql.getOneFromHis(id, inTime, inDate+" 23:59:59", "0"));
									if(firstInNotOutCount == 0){
										jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType, inTime, inDate+" 23:59:59", "0",plateno,picturepath));
									}
									
									//处理中间迁移记录
									String tempDate = DateUtil.getNextDay(inDate, "1");
									while(!tempDate.equals(curDate)){
										final int betweenInNotOutCount = jt.queryForInt(MonitorSql.getOneFromHis(id, tempDate +" 00:00:00", tempDate+" 23:59:59", "0"));
										if(betweenInNotOutCount == 0){
											jt.update(MonitorSql.moveOneFromLogtoHis(id, parkingSpaceId, parkingSpaceCode, spotType, tempDate +" 00:00:00", tempDate+" 23:59:59", "0",plateno,picturepath));
										}
										tempDate = DateUtil.getNextDay(tempDate, "1");
									}
								}
							}
						}
						final int dellog = jt.update(MonitorSql.deleteLog(curDate));
					}catch(Exception e){
						Log.log("----------Log to His---"+DateUtil.getNextDay(curDate, "-1")+"这天数据没有迁移和删除---");
					}
					return null;
					}
				});	
			}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
//		else{
//			int lognum = jt.queryForInt("select count(*) from p_parkingspaceoperationlog");
//			if(lognum !=0){
//				ArrayList<String> datelist = new ArrayList<String>();
//				int days = 3;
//				//获取Log表中所有入车记录的最小非当天日期
//				//BaseInfoData data = jt.queryForObjectExt(MonitorSql.getLogdates(), BaseInfoData.class);
//				
//				String sql = "select dataAnalysisTime,dataAnalysisDays from p_parking ";//停车场信息维护里填的 凌晨 01,02,03,04,05 （在00点之后，00点要执行从log到His表数据分离）
//				BaseInfoData data = jt.queryForObjectExt(sql, BaseInfoData.class);
//				if(Util.isCon(data.getDataAnalysisDays())){
//					days = data.getDataAnalysisDays();
//				}
//				for(int j=days;j>0;j--){
//					datelist.add(DateUtil.getNextDay(curDate, "" + (-j)));
//				}
//				if(!datelist.isEmpty()){
//					int ltcount = datelist.size();
//					for(int i=0;i<ltcount;i++){
//						if(Util.isCon(datelist.get(i))){
//							final String datestr = datelist.get(i).toString();
//							int verifylogcount = jt.queryForInt(MonitorSql.VerifyLog(datestr));//今天已出车记录条数
//							Log.log("Log表中"+datestr+"这天已出车记录条数--------"+verifylogcount);
//							int verifylog1count = jt.queryForInt(MonitorSql.VerifyLog1(datestr)); //今天23:59:59之前入车未出车记录条数
//							Log.log("Log表中"+datestr+" 23:59:59之前入车未出车记录条数--------"+verifylog1count);
//							int verifyhiscount = jt.queryForInt(MonitorSql.VerifyHis(datestr)); //his表中出车时间为今天23:59:59的记录
//							Log.log("His表中出车时间为"+datestr+" 23:59:59的记录条数--------"+verifyhiscount);
//							final String nextdate = DateUtil.getNextDay(datestr, "1");
//							if(verifylogcount!=0){
//								Log.log("Log表中存在++++"+datestr+"++++日出车未迁移的记录，需迁移");
//								tt.execute(new TransactionCallbackWithoutResult() {
//									public void doInTransactionWithoutResult(TransactionStatus ts){
//										try{
//											jt.update(MonitorSql.MoveLogToHis1(nextdate));//导入出车数据
//											jt.update(MonitorSql.deleteLog(nextdate));
//										}catch(Exception e){
//											Log.log("----------Log to His---"+datestr+"这天出车数据没有迁移和删除---");
//										}
//										}
//									});	
//							}else if(verifylog1count !=0){
//								if(verifyhiscount == 0){
//										Log.log("His表中不存在++++"+datestr+"++++日未出车的迁移记录，需迁移");
//										tt.execute(new TransactionCallbackWithoutResult() {
//											public void doInTransactionWithoutResult(TransactionStatus ts){
//												try{
//													jt.update(MonitorSql.MoveLogToHis2(nextdate));//导入未出车数据
//													jt.update(MonitorSql.deleteLog(nextdate));
//												}catch(Exception e){
//													Log.log("----------Log to His---"+datestr+"这天未出车数据没有迁移---");
//												}
//												}
//											});
//									}
//							}
//						}
//					}
//				}
//			}
//		}
	}
	
	/**
	 * 拆分时间片段
	 * @param d1 inTime
	 * @param d2 outTime
	 * @param inStatus 入车
	 * @param outStatus 出车
	 * @return
	 */
	public static JSONArray getHourSpilt(String d1,String d2,int inStatus,int outStatus){
		JSONArray arr = new JSONArray();//TODO
		//针对23:59:59  全部按 24:00:00  计算
		if(d2.indexOf("23:59:59") != -1){
			d2 = d2.substring(0, 10) + " 24:00:00";
		}
		try{
			boolean flag = true;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			d1=d1.substring(0,d1.length()-3).concat(":00");//取整//TODO
			d2=d2.substring(0,d2.length()-3).concat(":00");
			Date date1 = format.parse(d1);
			Date date2 = format.parse(d2);
			String firstHour = getNextHourDate(d1);//取d1的下一个小时的日期
			firstHour=firstHour.substring(0,firstHour.length()-5).concat("00:00");//取整
			Date firstHourData = format.parse(firstHour);//第一个整点日期
			long times = (date2.getTime()-date1.getTime())/(60*1000);//两个时间段分钟差
			long time1 = (firstHourData.getTime()-date1.getTime())/(60*1000);//第一个整点与开始时间差
			JSONObject json = new JSONObject();
			if(date2.getTime()-firstHourData.getTime()>0){//结束时间大于第一个整点时间
				json.element("year", d1.substring(0, 4));
				json.element("month", d1.substring(5, 7));
				json.element("day", d1.substring(8, 10));
				json.element("hour", d1.substring(11, 13));
				json.element("duration", time1);
				json.element("inCount", inStatus);//1
				json.element("outCount", 0);
				times = (date2.getTime()-firstHourData.getTime())/(60*1000);//时间差
			}else{//08:10:00   08:52:00
				json.element("year", d1.substring(0, 4));
				json.element("month", d1.substring(5, 7));
				json.element("day", d1.substring(8, 10));
				json.element("hour", d1.substring(11, 13));
				json.element("duration", times);
				json.element("inCount", inStatus);//1
				json.element("outCount", outStatus);//1
				times=0;
			}
			arr.add(json);
			while(times>0){
				JSONObject json2 = new JSONObject();
				times = (date2.getTime()-firstHourData.getTime())/(60*1000);
				String temp_date = format.format(firstHourData);
				
				if(times<60){//最后一条数据
					String lastHour = format.format(firstHourData);
					if(date2.getTime()-firstHourData.getTime()>0){
						JSONObject json3 = new JSONObject();
						long time4 = (date2.getTime()-firstHourData.getTime())/(60*1000);
						json3.element("year", lastHour.substring(0, 4));
						json3.element("month", lastHour.substring(5, 7));
						json3.element("day", lastHour.substring(8, 10));
						json3.element("hour", lastHour.substring(11, 13));
						json3.element("duration", time4);
						json3.element("inCount", 0);
						json3.element("outCount", outStatus);//1
						arr.add(json3);
						flag = false;
						break;
					}
					flag = false;
					break;
				}
				if(flag){
					json2.element("year", temp_date.substring(0, 4));
					json2.element("month", temp_date.substring(5, 7));
					json2.element("day", temp_date.substring(8, 10));
					json2.element("hour", temp_date.substring(11, 13));
					json2.element("duration", 60);
					json2.element("inCount", 0);
					json2.element("outCount", 0);
					arr.add(json2);
				}
				firstHourData.setTime(((firstHourData.getTime()/1000)+60*60)*1000);//整点加一个小时
				
			}
			
		}catch(Exception e){
			Log.log("[拆分his表错误]"+e.getMessage());
		}
		return arr;
	}
	
	/**
	 * @param d1 intime
	 * @param d2 outtime
	 * @param type
	 * @param curDay
	 * @return
	 */
	public static JSONArray beforeHourSplit(JSONObject jo, String curDay,JdbcTemplateExtend jt){//删去isin
		JSONArray arr = new JSONArray();//TODO
		
		try{
			if(Util.isCon(jo.get("inTime")) && Util.isCon(jo.get("outTime"))){
				String d1 = jo.getString("inTime");
				String d2 = jo.getString("outTime");
				
				String curDayBegin = curDay+" 00:00:00";
				Log.log("--入车时间--"+ d1 +" = "+ curDayBegin + "==" + d1.equals(curDayBegin));
				if(d1.equals(curDayBegin))
					//对于入车时间等于当前日期零点的数据，入车状态设置为0，表示未入车，modified by wj 2012-11-22
				{
					String outDate = DateUtil.getNextDay(d1.substring(0, 10), "-1");
					String outTime = outDate.concat(" 23:59:59");
					int count = jt.queryForInt(MonitorSql.getHisCountByConditions(outTime, jo.getString("id")));
					if(count > 0){//多天停车记录迁移所得
						arr = getHourSpilt(d1, d2, 0, jo.getInt("putOut"));//jo.getInt("isin")->1
					}else{//确为当天零点入车
						arr = getHourSpilt(d1, d2, 1, jo.getInt("putOut"));//jo.getInt("isin")->1
					}
				}
				else
					arr = getHourSpilt(d1, d2, 1, jo.getInt("putOut"));//jo.getInt("isin")->1,
				
			}
		}catch(Exception e){
			Log.log("[车位停放时间分类错误]"+e.getMessage());
		}
		return arr;

	}
	
	private static String getNextHourDate(String date) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date date1 = format.parse(date);
		date1.setTime(((date1.getTime()/1000)+60*60)*1000);
		return format.format(date1);
	}
	
	
	
	public static void main(String[] args) throws Exception {
//		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		Date d1 = format.parse("2012-06-28 00:00:00");
//		Date d2 = format.parse("2012-06-27 24:00:00");
//		boolean after = d1.after(d2);
//		System.out.println(after);
//		boolean equals = d1.equals(d2);
//		System.out.println(equals);
//		String curDay = "2012-06-28";
//		JSONObject jo = new JSONObject();
//		jo.element("inTime", "2012-06-28 00:00:00");
//		jo.element("outTime", "2012-06-28 23:59:59");
//		jo.element("isin", 1);
//		jo.element("putOut", 0);
//		JSONArray ss = beforeHourSplit(jo, curDay);
//		for(int i=0;i<ss.size();i++){
//			System.out.println(ss.get(i).toString());
//		}
		JSONArray jarr = getHourSpilt("2013-03-08 17:50:45","2013-03-08 18:00:46",1,1);
		System.out.println(jarr.toString());
	}

	public List getStatusList(String lang) {//添加code_key<>0.只取出状态不等于"正常"的记录 byLLX 0806
		String sql = "select code_key as code_id,code_value as code_name from sys_lang_switch "
			+ " where  code_key<>0 and code_type = 'ctrl_status' and lang = " + Util.toSqlVal(lang);
		Log.log(sql);
		return getJt().queryForList(sql);
		
	}
	/**
     * Description :获得逻辑区域list．
     * @throws :Exception
     */
	public List getLogicRegionCode(){
		
		return getJt().queryForList("select id code_id,name code_name from p_logicregion");
	}

	/**
     * Description :获得地图区域list．
     * @throws :Exception
     */
	public List get_mapCode() {
		return getJt().queryForList("select id code_id,name code_name from p_map");
		//List codeList = new ArrayList();
		//codeList = getJt().queryForListExt(monitorSql.get_mapCode(), MonitorData.class);
		//return codeList;
	}
	
	
	public MonitorData message_list(MonitorData data, String deName,String lang) {
		//获得数量
		int count  = this.getJt().queryForInt(monitorSql.fault_list(data, "count",lang));
		
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <MonitorData>rows = this.getJt().<MonitorData>queryForListExt(monitorSql.fault_list(data, "",lang), 
				data.getStart(), data.getLimit(),MonitorData.class);
		
		data.setPer_data(rows);
		return data;
	}
	
	//获取报警基本信息
	public MonitorData getAlarmBaseInfor()
	{
		MonitorData queryForObject = this.getJt().queryForObjectExt(monitorSql.getAlarmBaseInfor(), MonitorData.class);
		return queryForObject;
	}
	
	//保存或更新报警基本信息
	public JSONObject AlarmBaseInfor_save(MonitorData data) {
		int queryForInt = this.getJt().queryForInt(monitorSql.base_query(data.getBid()));
		if(queryForInt==0)   //新增
			this.getJt().update(monitorSql.base_save(data));
		else   //更新
			this.getJt().update(monitorSql.base_update(data));
		JSONObject json = new JSONObject();
		json.element("success", true);
		return json;
		
	}
	
	//获取地图上的路径
	public JSONObject getFlashPath(String id){
		JSONObject json = new JSONObject();
		String sql = "SELECT path FROM p_map where id=" + id;
		MapManageData map = this.getJt().queryForObjectExt(sql, MapManageData.class);
		String path = "";
		if (Util.isCon(map.getPath())) {
			path = splitMapSrc(map.getPath());
		}
		json.element("path", path);
		return json;
	}
	//处理ＦＬＡＳＨ地图上的路径
	private String splitMapSrc(String path) {
		String src = "";
		String path_split[] = path.split(ConstantClass.MAP_DIR);
		src = "../" + ConstantClass.MAP_DIR + path_split[1];
		// src = src.replaceAll("\\", "/");
		return src;
	}

	public MonitorData get_message_list(MonitorData data,String lang) {
	
		//获得数量
		
		int count  = this.getJt().queryForInt(monitorSql.get_message_list(data, "count",lang));
		
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <MonitorData>rows = this.getJt().<MonitorData>queryForListExt(monitorSql.get_message_list(data, "",lang), 
				data.getStart(), data.getLimit(),MonitorData.class);
		for(MonitorData tempData:rows){
			tempData.setS_devicetype((String) ((HashMap)data.getCurrent_lang_switch().get("device_object")).get(tempData.getS_devicetype()));
			tempData.setS_status((String)((HashMap)data.getCurrent_lang_switch().get("ctrl_status")).get(tempData.getS_status()));
			tempData.setS_noticeway((String) ((HashMap)data.getCurrent_lang_switch().get("notice_way")).get(tempData.getS_noticeway()));
			tempData.setS_isneedsend((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getS_isneedsend()));
			tempData.setS_alreadysend((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getS_alreadysend()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	/**
	 * 每隔10分钟，遍历
	 * p_pathnodeinfohead路径节点信息表
	 */
	@SuppressWarnings("rawtypes")
	public static void searchMachineTask(DataSource ds) throws Exception{
		//当前时间
		long curTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(DateUtil.getCurDateTime()).getTime();//根据字符串time得到毫秒数。
		int len=SerachMachineOperation.getSearchMachineTime().size();
		
		Iterator<?> it = SerachMachineOperation.getSearchMachineTime().entrySet().iterator();  
		String status="1";
		ArrayList<String> sqlChangeStatuslist=new ArrayList<String>();
		while(it.hasNext()){  
			Map.Entry machineTime=(Map.Entry)it.next(); 
			String machineLastTime=machineTime.getValue().toString();
			String machineId=machineTime.getKey().toString();
			Long lastTime=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(machineLastTime).getTime();//根据字符串time得到毫秒数。
			if(((curTime-lastTime)/60/1000)<1){
				status="0";
			}
			String lastStatus=SerachMachineOperation.getSearchMachineStatus().get(machineId).toString();
			if(!status.equals(lastStatus)){
				Integer istatus=new Integer(status);
				SerachMachineOperation.getSearchMachineStatus().put(machineId, istatus);
				String sql = MonitorSql.updateStatus(status,machineId);
				sqlChangeStatuslist.add(sql);
			}
		}
		String strsqlChangeStatus[]=new String[sqlChangeStatuslist.size()];
		for(int i=0,j=sqlChangeStatuslist.size();i<j;i++){
			strsqlChangeStatus[i]=sqlChangeStatuslist.get(i);
		}
		if(strsqlChangeStatus.length>0){
			JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
			jt.batchUpdate(strsqlChangeStatus);
			
		}
	}
}
