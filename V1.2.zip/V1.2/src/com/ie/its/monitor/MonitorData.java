/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.monitor;

import java.util.List;

import com.ie.frame.ExtendData;

public class MonitorData extends ExtendData{
	
	private String l_name;				//逻辑区域
	private String g_name;				//引导区域
	private String status;
	private String code;			//车位编号 
	private String number;				//地图号
	private String name;				//地图名
	private String userDateInt;				//超时时间
	private String userDate;			//占用时间
	private String gArr;			//管理器地址
	private String tArr;			//探测器地址
	private String self_type;	//设备类型
	private String self_type_Num;	//设备类型原始代码
	private String fault_Arr;
	private String detector_code;
	private String logic_id;
	private String mapId;
	private List   statusList;
	private List logicList;
	private List mapList;
	
	//以下为报警服务基本信息
	public String bid;
	
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	private String mobilephone;
	private String noticeway;
	private String enableflag;
	private String describes;
	private String attribute1;
	private String attribute2;
	private String attribute3;
	
	
	private String s_id;
	private String s_devicetype;
	private String s_code;
	private String s_alarmmessage;
	private String s_mobilephone;
	private String s_noticeway;
	private String s_isneedsend;
	private String s_alreadysend;
	private String s_status;
	

	private List noticewayList;//通知方式
	private List enableList;//是否启用
	public List getNoticewayList() {
		return noticewayList;
	}
	public void setNoticewayList(List noticewayList) {
		this.noticewayList = noticewayList;
	}
	public List getEnableList() {
		return enableList;
	}
	public void setEnableList(List enableList) {
		this.enableList = enableList;
	}
	public String getMobilephone() {
		return mobilephone;
	}
	public void setMobilephone(String mobilephone) {
		this.mobilephone = mobilephone;
	}
	public String getNoticeway() {
		return noticeway;
	}
	public void setNoticeway(String noticeway) {
		this.noticeway = noticeway;
	}
	public String getEnableflag() {
		return enableflag;
	}
	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}
	public String getDescribes() {
		return describes;
	}
	public void setDescribes(String describes) {
		this.describes = describes;
	}
	public String getAttribute1() {
		return attribute1;
	}
	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}
	public String getAttribute2() {
		return attribute2;
	}
	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}
	public String getAttribute3() {
		return attribute3;
	}
	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}
	
	public String getDetector_code() {
		return detector_code;
	}
	public void setDetector_code(String detector_code) {
		this.detector_code = detector_code;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		this.g_name = g_name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getGArr() {
		return gArr;
	}
	public void setGArr(String arr) {
		gArr = arr;
	}
	public String getTArr() {
		return tArr;
	}
	public void setTArr(String arr) {
		tArr = arr;
	}
	public String getUserDateInt() {
		return userDateInt;
	}
	public void setUserDateInt(String userDateInt) {
		this.userDateInt = userDateInt;
	}
	public String getSelf_type() {
		return self_type;
	}
	public void setSelf_type(String self_type) {
		this.self_type = self_type;
	}
	public String getFault_Arr() {
		return fault_Arr;
	}
	public void setFault_Arr(String fault_Arr) {
		this.fault_Arr = fault_Arr;
	}
	
	public String getUserDate() {
		return userDate;
	}
	public void setUserDate(String userDate) {
		this.userDate = userDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List getStatusList() {
		return statusList;
	}
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	public List getLogicList() {
		return logicList;
	}
	public void setLogicList(List logicList) {
		this.logicList = logicList;
	}
	public String getLogic_id() {
		return logic_id;
	}
	public void setLogic_id(String logic_id) {
		this.logic_id = logic_id;
	}
	public List getMapList() {
		return mapList;
	}
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getS_id() {
		return s_id;
	}
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	public String getS_devicetype() {
		return s_devicetype;
	}
	public void setS_devicetype(String s_devicetype) {
		this.s_devicetype = s_devicetype;
	}
	public String getS_code() {
		return s_code;
	}
	public void setS_code(String s_code) {
		this.s_code = s_code;
	}
	public String getS_alarmmessage() {
		return s_alarmmessage;
	}
	public void setS_alarmmessage(String s_alarmmessage) {
		this.s_alarmmessage = s_alarmmessage;
	}
	public String getS_mobilephone() {
		return s_mobilephone;
	}
	public void setS_mobilephone(String s_mobilephone) {
		this.s_mobilephone = s_mobilephone;
	}
	public String getS_noticeway() {
		return s_noticeway;
	}
	public void setS_noticeway(String s_noticeway) {
		this.s_noticeway = s_noticeway;
	}
	public String getS_isneedsend() {
		return s_isneedsend;
	}
	public void setS_isneedsend(String s_isneedsend) {
		this.s_isneedsend = s_isneedsend;
	}
	public String getS_alreadysend() {
		return s_alreadysend;
	}
	public void setS_alreadysend(String s_alreadysend) {
		this.s_alreadysend = s_alreadysend;
	}
	public String getS_status() {
		return s_status;
	}
	public void setS_status(String s_status) {
		this.s_status = s_status;
	}
	public String getSelf_type_Num() {
		return self_type_Num;
	}
	public void setSelf_type_Num(String self_type_Num) {
		this.self_type_Num = self_type_Num;
	}

	

}
