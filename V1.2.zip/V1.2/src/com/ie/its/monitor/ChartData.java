package com.ie.its.monitor;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.LocalSessionUtil;
import com.ie.its.login.UserInfo;
import com.ie.its.parkingstatistics.ParkingStatisticsData;
import com.ie.its.parkingstatistics.ParkingStatisticsService;
import com.ie.jofc.BarChart;
import com.ie.jofc.BuilderChart;
import com.ie.jofc.LineChart;

public class ChartData {

	private DataSource ds = null;
	private MonitorService monitorService = new MonitorService();
	private ParkingStatisticsService statisticsService = new ParkingStatisticsService();
	
	public DataSource getDataSource(){
		WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
		DataSource ds = (DataSource)wac.getBean("dataSource");		
		return ds;
	}

	public void setUserInfo(){
		Object current_user = WebContextFactory.get().getSession().getAttribute(ConstantClass.SESSION_USERNAME);
		LocalSessionUtil.setCurrentUserInfo((UserInfo)current_user);
	}
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public JSONObject getChartData() throws Exception {
		monitorService.setDataSource(getDataSource());
		String lang = WebContextFactory.get().getHttpServletRequest().getSession().getAttribute("lang").toString();
		JSONArray use_list = monitorService.chart_list(lang);
		JSONObject jo = new JSONObject();
		jo.element("click", "");
		jo.element("arr", use_list);
		BuilderChart bc = new BuilderChart();
		BarChart bar = new BarChart(2);
		//多语言
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("chart_title");
		jo = bc.getBuilder(jo, bar, map.get("use_number").toString(), map.get("total_number").toString());
		return jo;
	}
	
	
	/**
	 * 
	 * @param statisticsData
	 * @return
	 * @throws Exception
	 */
	public JSONObject chart_list(String s_logic_id,String s_physical_id, String s_spot_type,String s_month,String s_year,
			String s_type,String s_date,String chart_type) throws Exception{
		
		statisticsService.setDataSource(getDataSource());
		ParkingStatisticsData statisticsData  = new ParkingStatisticsData(s_logic_id,s_physical_id,s_spot_type,s_month,s_year,s_type,s_date,chart_type);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		List li = new ArrayList();
		statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		//车位类型
		setUserInfo();
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());		
		
		JSONArray chart_list = statisticsService.chart_list(statisticsData);
		
		JSONObject jo = new JSONObject();
		jo.element("arr", chart_list);
		BuilderChart bc = new BuilderChart();
		String in_park = "",out_park = "";
		String lang = WebContextFactory.get().getHttpServletRequest().getSession().getAttribute("lang").toString();
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("chart_title");
		in_park = map.get("in_park").toString();
		out_park = map.get("out_park").toString();
		if(statisticsData.getChart_type().equals("line")){
			jo = bc.getBuilder(jo, new LineChart(), in_park, out_park);
		}else if(statisticsData.getChart_type().equals("bar")){
			jo = bc.getBuilder(jo, new BarChart(), in_park, out_park);
		}
		//setLang(statisticsData);
		return jo;
	}
	/**
	 * 
	 * @param s_logic_id
	 * @param s_physical_id
	 * @param s_spot_type
	 * @param s_month
	 * @param s_year
	 * @param s_type
	 * @param s_date
	 * @param chart_type
	 * @return
	 * @throws Exception
	 */
	public JSONObject use_list(String s_logic_id,String s_physical_id, String s_spot_type,String s_month,String s_year,
			String s_type,String s_date,String chart_type) throws Exception{
		statisticsService.setDataSource(getDataSource());
		ParkingStatisticsData statisticsData  = new ParkingStatisticsData(s_logic_id,s_physical_id,s_spot_type,s_month,s_year,s_type,s_date,chart_type);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		List li = new ArrayList();
		statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		
		setUserInfo();
		
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());
		//统计数据
		
		JSONArray use_list = statisticsService.use_list(statisticsData);
		JSONObject jo = new JSONObject();
		
		jo.element("arr", use_list);
		BuilderChart bc = new BuilderChart();
		if(statisticsData.getChart_type().equals("line")){
			LineChart line = new LineChart();
			jo = bc.getBuilder(jo, line, true, null);
		}else if(statisticsData.getChart_type().equals("bar")){
			BarChart bar = new BarChart();
			jo = bc.getBuilder(jo, bar, true, null);
		}
		return jo;
	}
	
	public JSONObject logic_use_chart(String s_logic_id,String s_physical_id, String s_spot_type,String s_month,String s_year,
			String s_type,String s_date,String chart_type) throws Exception{
		statisticsService.setDataSource(getDataSource());
		ParkingStatisticsData statisticsData  = new ParkingStatisticsData(s_logic_id,s_physical_id,s_spot_type,s_month,s_year,s_type,s_date,chart_type);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		//statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
		List li = new ArrayList();
		statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
//		if(DateUtil.getMonth(new Date())<10)
//			statisticsData.setS_month("0"+DateUtil.getMonth(new Date()));
//		else
//			statisticsData.setS_month(""+DateUtil.getMonth(new Date()));
//		statisticsData.setS_type("day");
//		statisticsData.setS_date(DateUtil.getCurDate());
		setUserInfo();
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		//statisticsData.setChart_type("graph"); //graph histogram
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());
		//统计数据
		
		JSONArray logic_use_chart = statisticsService.logic_use_chart(statisticsData);
		JSONObject jo = new JSONObject();
		
		jo.element("arr", logic_use_chart);
		BuilderChart bc = new BuilderChart();
		if(statisticsData.getChart_type().equals("line")){
			LineChart line = new LineChart();
			jo = bc.getBuilder(jo, line, true, null);
		}else if(statisticsData.getChart_type().equals("bar")){
			BarChart bar = new BarChart();
			jo = bc.getBuilder(jo, bar, true, null);
		}
		return jo;
	}
	/**
	 * 
	 * @param phyId
	 * @return
	 * @throws Exception
	 */
	public JSONObject nextLogic(String phyId) throws Exception{
		statisticsService.setDataSource(getDataSource());
		List nextLogicList = statisticsService.nextLogicList(phyId);
		JSONObject jo = new JSONObject();
		jo.element("success", true);
		jo.element("list", nextLogicList);
		return jo;
	}
	
	public void updateProcess(){
		String osName = System.getProperty("os.name");
		try {
			Util.timer.cancel();
			//重启系统
			if (osName.matches("^(?i)Windows.*$")) {
				String cmd = "cmd.exe /c shutdown -r -t 0";
				Runtime.getRuntime().exec(cmd);
			} else {
				String sh = "reboot";
				Runtime.getRuntime().exec(new String[]{"/bin/bash","-c",sh});
			}
		} catch (Exception e) {

		}	
	}
}
