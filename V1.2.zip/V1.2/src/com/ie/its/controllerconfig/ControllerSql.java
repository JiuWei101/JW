/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.controllerconfig;

import static com.ie.common.Util.*;

import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;

public class ControllerSql extends ExtendSql{
	/**
     * Description :查询管理器．
     * @param  :ControllerData,String
     * @return :String
     */
	public String controller_list(ControllerData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  c.id,m.name as mapId,l.ip as lineId,c.addr,c.port,c.type,c.status,c.notes,c.ipport,c.isexist,c.macaddress ";
		}
		
		querySql += " from p_controller c left join p_line l on c.lineId=l.id left join p_map m on c.mapId=m.id";
		querySql += " where 1=1 ";
		
		if(isCon(data.getMapId())){
			querySql += " and m.id = " + toSqlVal(data.getMapId());
		}
		if(isCon(data.getAddr())){
			querySql += " and c.addr like " + toSqlValLike(data.getAddr(),"ALL");
		}
		if(isCon(data.getLineId())){
			querySql += " and l.id = " + toSqlVal(data.getLineId());
		}
		if(isCon(data.getStatus())){
			querySql += " and c.status = " + toSqlVal(data.getStatus());
		}
		
		if(!type.equals("count")){
			querySql += " order by c.addr";
		}
		
		return querySql;
	}
	
	/**
     * Description :保存管理器信息．
     * @param  :ControllerData
     * @return :String
     */
	public String controller_save(ControllerData data) {
		String insertSql = "";
		
		insertSql += "insert into p_controller(id,mapId,lineId,addr,type,status,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getMapId()) + ",";
		insertSql += Util.toSqlVal(data.getLineId()) + ",";
		insertSql += Util.toSqlVal(data.getAddr()) + ",";
		//insertSql += Util.toSqlVal(data.getPort()) + ",";
		insertSql += Util.toSqlVal(data.getType()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		
		
		return insertSql;
	}
	
	/**
     * Description :获得管理器信息．
     * @param  :ControllerData
     * @return :String
     */
	public String controller_get(ControllerData data) {
		String querySql = "";
		
		querySql += "select * from p_controller where id=";
		querySql += Util.toSqlVal(data.getId());
		
		
		return querySql;
	}
	
	/**
     * Description :更新管理器信息．
     * @param  :ControllerData
     * @return :String
     */
	public String controller_multiupdate(String id, String[] fields, String[] values) {
		String updateSql = "";
		updateSql += "update p_controller set ";
		for(int i = 0; i < fields.length; i++){
			if(i != 0){
				updateSql += ",";
			}
			updateSql += fields[i] + "=";
			updateSql += Util.toSqlVal(values[i]);
		}
		
		if(id != null){
			updateSql += " where id =" + Util.toSqlVal(id);
		}
		
		return updateSql;
	}
	
	/**
     * Description :更新管理器信息．
     * @param  :ControllerData
     * @return :String
     */
	public String controller_update(ControllerData data) {
		String updateSql = "";
		if(data.getLineId().equals(""))
			data.setLineId(null);
		updateSql += "update p_controller set lineId =";
		updateSql += Util.toSqlVal(data.getLineId());
//		updateSql += ",mapId =";
//		updateSql += Util.toSqlVal(data.getMapId());
//		updateSql += ",addr=" + Util.toSqlVal(data.getAddr());
		//updateSql += ",port=" + Util.toSqlVal(data.getPort());
		updateSql += ",type=" + Util.toSqlVal(data.getType());
		updateSql += ",status=" + Util.toSqlVal(data.getStatus());
		updateSql += ",notes=" + Util.toSqlVal(data.getNotes());
		updateSql += ",ipport=" + Util.toSqlVal(data.getIpport());
		updateSql += ",macaddress=" + Util.toSqlVal(data.getMacaddress());
		updateSql += ",isexist=" + Util.toSqlVal(data.getIsexist());
		updateSql += " where id =" + Util.toSqlVal(data.getId());
		
		return updateSql;
	}
	
	/**
     * Description :删除管理器信息．
     * @param  :ControllerData
     * @return :String
     */
	public String controller_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_controller where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	/**
     * Description :获得通讯线路．
     * @param  :
     * @return :String
     */
	public String get_lineCode() {
		String querySql = "";
		
		querySql += "select id as code_id,ip as code_name from p_line where status <> '0' order  by ip";
		
		return querySql;
	}

	/**
     * Description :获得通讯线路．
     * @param  :
     * @return :String
     */
	public String get_mapCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_map order  by id";
		
		return querySql;
	}

	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	public String detector_config(DetectorConfigData dcd, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  id,code,enable,addr ";
		}
		
		querySql += " from p_detector where controllerId = '" + dcd.getControllerId() + "'";
//		querySql += " from p_detector where detectorTypeId<>'2' and controllerId = '" + dcd.getControllerId() + "'";
		
		return querySql;
	}

	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	public String detector_region(DetectorConfigData dcd, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  sr.id ";
		}
		
		querySql += " from p_screenregion sr,p_guideregion gr,p_detector d ";
		querySql += "where d.id = '" + dcd.getId() + "' and d.guideRegionId=gr.id and FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0";
		
		return querySql;
	}

	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	public String logic_region(ControllerData dcd, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  t.id as code_id,t.num as code_name ";
		}
//	modified by wj 2013-04-09		
//		querySql += "from (select  sr.id,count(d.id) as num " + 
//			"from p_screenregion sr " + 
//			"inner join p_screen s on sr.screenId=s.id " + 
//			"left join p_guideregion gr on FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0 " + 
//			"left join p_detector d on d.guideRegionId=gr.id and d.detectorTypeId<>'2' " +
//			"left join p_parkingspace ps on d.id=ps.detectorid and ps.spotType='0' " + 
//			"where s.controllerId = '" + dcd.getId() + "' group by sr.id) t";
		
		querySql += "from (select  sr.id,count(d.id) as num " + 
		"from p_screenregion sr " + 
		"inner join p_screen s on sr.screenId=s.id " + 
		"inner join p_guideregion gr on FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0 " + 
		"inner join p_detector d on d.guideRegionId=gr.id and d.detectorTypeId<>'2' " +
		//"left join p_parkingspace ps on d.id=ps.detectorid and ps.spotType='0' " +
		"inner join p_parkingspace ps on d.id=ps.detectorid " +
		"where s.controllerId = '" + dcd.getId() + "' group by sr.id) t";
		
		return querySql;
	}

	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	public String screen(ScreenData dcd, String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(s.id)  ";
		}else{
//			querySql += "select s.id,s.grpAddr,s.addr,s.code,c.port as controllerPort,s.contentFormat,s.enable ";
			//端口号改为从引导屏表中取
			querySql += "select s.id,s.grpAddr,s.addr,s.code,s.serialPort as controllerPort,s.contentFormat,s.enable ";
		}
		
		querySql += " from p_screen s,p_controller c where c.id=s.controllerId and s.controllerId = '" + dcd.getControllerId() + "'";
		
		return querySql;
	}

	/**
	 * @param dcd
	 * @param string
	 * @return
	 */
	public String screen_param_value(String id) {
		String querySql = "";
		
		querySql += "select stp.code as code_id,spv.value as code_name " +
		"from p_screen s,p_screentypepara stp,p_screenparavalue spv where s.id = '" + id + 
		"' and s.screenTypeCode = stp.screenType and stp.id = spv.screenTypeParaId and spv.screenId=s.id";

//		querySql += "select stp.code as code_id,spv.value as code_name " +
//		"from p_screen s,p_screentypepara stp,p_screenparavalue spv where s.id = '" + id + 
//		"' and s.screenTypeCode = stp.screenType and stp.id = spv.screenTypeParaId";

		return querySql;
	}

	/**
	 * @param id
	 * @param str_old
	 * @return
	 */
	public String region_id(String id, String str_old) {
		String querySql = "";
//	modified by wj 2013-04-09		
//		querySql += "select  t.id as code_id,t.num as code_name from " +
//				"(select  sr.id,count(ps.id) as num from p_screenregion sr " + 
//				"left join p_guideregion gr on FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0 " + 
//				"left join p_detector d on d.guideRegionId=gr.id " +
//				"left join p_parkingspace ps on d.id=ps.detectorid and ps.spotType='0' " + 
//				"where sr.screenId = '" + id + "' and sr.guideRegionCodeList = '" + str_old + "' group by sr.id) t";
		
		querySql += "select  t.id as code_id,t.num as code_name from " +
		"(select  sr.id,count(ps.id) as num from p_screenregion sr " + 
		"inner join p_guideregion gr on FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0 " + 
		"inner join p_detector d on d.guideRegionId=gr.id " +
		//"left join p_parkingspace ps on d.id=ps.detectorid and ps.spotType='0' " +
		"inner join p_parkingspace ps on d.id=ps.detectorid " +
		"where sr.screenId = '" + id + "' and sr.guideRegionCodeList = '" + str_old + "' group by sr.id) t";
		
		return querySql;
	}

	/**
	 * @param data
	 * @param filePath
	 * @return
	 */
	public String plan_save(String controllerId, String filePath, String userId) {
		String querySql = "";
		
		querySql += "insert into p_configtask(id,controllerId,path,operator,createtime,runstate) values(";
		querySql += Util.toSqlVal(PrimaryId.getId()) + ",";
		querySql += Util.toSqlVal(controllerId) + ",";
		querySql += Util.toSqlVal(filePath) + ",";
		querySql += Util.toSqlVal(userId) + ",sysdate(),'0')";
		
		return querySql;
	}

	/**
	 * @param data
	 * @param filePath
	 * @return
	 */
	public String plan_delete(String controllerId) {
		String querySql = "";
		
		querySql += "delete from p_configtask where controllerId=";
		querySql += Util.toSqlVal(controllerId) + "";
		
		return querySql;
	}

	public String plan_update(){
		String querySql = " update p_configtask set createtime = sysdate(), runstate = '0' where runstate ='1'";
		return querySql;
	}
	
	public String plan_count(){
		String querySql = " select count(*) from p_configtask where runstate='1'";
		return querySql;
	}
	/**
	 * @param data
	 * @param filePath
	 * @return
	 */
	public String check_ini_status(String controllerId) {
		String querySql = "";
		querySql += "select count(id) from p_configtask where controllerId=";
		querySql += Util.toSqlVal(controllerId) + " and runstate='1'";
		return querySql;
	}

	/**
	 * @param data
	 * @param filePath
	 * @return
	 */
	public String check_ini_screenpara(String controllerId) {
		String querySql = "";
		querySql += "select count(t.id) from(select count(v.id) as num,s.id from p_screenparavalue v,p_screen s where s.controllerId=";
		querySql += Util.toSqlVal(controllerId) + " and s.id=v.screenId group by s.id) t where t.num < 16";
		return querySql;
	}

	/**
	 * @param id
	 * @return
	 */
	public String getControllerCode(String id) {
		String querySql = "";
		
		querySql += "select addr from p_controller where id=";
		querySql += Util.toSqlVal(id);
		
		return querySql;
	}
	/**
     * Description :查询下发任务．
     * @param  :ControllerData,String
     * @return :String
     */
	public String config_task(ControllerData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select t.id,c.addr,t.path,u.user_name as operator,t.createtime,t.runstate ";
		}
		
		querySql += " from p_configtask t,p_controller c,sys_user u";
		querySql += " where t.controllerId=c.id and t.operator=u.id ";
		
		if(!type.equals("count")){
			querySql += " order by t.id desc";
		}
		
		return querySql;
	}
	
	/**
     * Description :删除下发任务．
     * @param  :ControllerData
     * @return :String
     */
	public String config_task_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_configtask where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	/**
     * Description :删除下发历史．
     * @param  :ControllerData
     * @return :String
     */
	public String task_history_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_configtaskhistory where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	/**
     * Description :查询下发历史．
     * @param  :ControllerData,String
     * @return :String
     */
	public String config_history(ControllerData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select t.id,c.addr,t.executeTime,t.success,t.path,u.user_name as operator,t.createtime,t.duration ";
		}
		
		querySql += " from p_configtaskhistory t,p_controller c,sys_user u";
		querySql += " where t.controllerId=c.id and t.operator=u.id ";
		
		if(!type.equals("count")){
			querySql += " order by t.id desc";
		}
		
		return querySql;
	}

	public String getLineValue(String str) {
		String querySql = "select count(*) from p_controller where id = " + toSqlVal(str)
			+ " and lineid is not null";
		return querySql;
	}
	
	/**
	 * @param data
	 * @param filePath
	 * @return
	 */
	public String temp_task_delete(String controllerId) {
		String querySql = "";
		
		querySql += "delete from p_colortacticstask where controllerId in";
		querySql += Util.toSqlVal(controllerId) + "";
		
		return querySql;
	}
	
	public String color_task_save(String controllerId, String screens, String colorvalues, String redcount, String yellowpercent, String notes, String userId) {
		String querySql = "";
		
		querySql += "insert into p_colortacticstask(id,controllerId,screens,colorvalues,redcount,yellowpercent,notes,operator,createtime,runstate) values(";
		querySql += Util.toSqlVal(PrimaryId.getId()) + ",";
		querySql += Util.toSqlVal(controllerId) + ",";
		querySql += Util.toSqlVal(screens) + ",";
		querySql += Util.toSqlVal(colorvalues) + ",";
		querySql += Util.toSqlVal(redcount) + ",";
		querySql += Util.toSqlVal(yellowpercent) + ",";
		querySql += Util.toSqlVal(notes) + ",";
		querySql += Util.toSqlVal(userId) + ",sysdate(),'0')";
		return querySql;
	}
	
	public String check_color_task(ControllerData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select t.id,c.addr,t.screens,t.colorvalues,u.user_name as operator,t.createtime,t.runstate ";
		}
		
		querySql += " from p_colortacticstask t,p_controller c,sys_user u";
		querySql += " where t.controllerId=c.id and t.operator=u.id ";
		
		if(!type.equals("count")){
			querySql += " order by t.id desc";
		}
		
		return querySql;
	}
	
	public String color_task_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_colortacticstask where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	public String color_task_history(ControllerData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select t.id,c.addr,t.executeTime,t.success,t.screens,t.colorvalues,u.user_name as operator,t.createtime,t.duration ";
		}
		
		querySql += " from p_colortacticstaskhistory t,p_controller c,sys_user u";
		querySql += " where t.controllerId=c.id and t.operator=u.id ";
		
		if(!type.equals("count")){
			querySql += " order by t.id desc";
		}
		
		return querySql;
	}
	
	public String screen_list(String[] ctrlId,String type){
		String querySql = "";
		if("count" == type){
			querySql +=" select count(*)";
		}else{
			querySql +=" select pm.name as mapId,pc.addr as addr,ps.code as screencode,ps.controllerId as id";
		}
		querySql +=" from p_map as pm,p_screen as ps,p_controller as pc";
		querySql +=" where pm.id = ps.mapId and pc.id = ps.controllerId and";
		if(ctrlId.length > 0){
			querySql +=" (";
			for(int i=0;i<ctrlId.length;i++){
				if(i - ctrlId.length < -1){
					querySql +=" pc.id= '"+ctrlId[i]+"' or";
				}else{
					querySql +=" pc.id= '"+ctrlId[i]+"'";
				}
			}
			querySql +=" )";
		}else{
			querySql +=" 1=1";
		}

		return querySql;
	}
}
