/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.controllerconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class ControllerData extends ExtendData{
	private String mapId;				//地图ID
	private String lineId;				//通讯线路ID
	//private String port;				//端口
	private String type;				//类型
	private String status;				//状态
//	private String maxNum;				//最大管理探头书
	private String notes;				//备注
	private List lineList;				//物理区域下拉框
	private String addr;				//地址或IP地址
	private List mapList;				//地图下拉框
	private List statusList;			//状态下拉框
	private List controllerPortList;			//端口
	
	private String ipport;				//ip端口
	private String isexist;				//是否出入口摄像机
	private String macaddress;			//MAC地址
	private String path;				//配置文件路径
	private String operator;			//发布人
	private String createtime;			//发布时间
	private String runstate;			//任务执行状态
	private String executeTime;			//执行时间
	private String success;				//是否执行成功(1成功0失败)
	private String duration;			//执行时长

	private String field;				//字段名
	private String redcount;				//是否执行成功(1成功0失败)
	private String yellowpercent;			//执行时长
	
	private String screens;		//屏编码字符串，如P0001,P00117
	private String colorvalues;		//屏变色策略临界值字符串，如5,20%;10,50%
	
	private String screencode;	//引导屏编码
	
	private List isExistList;		//是否出入口列表
	
	public List getIsExistList() {
		return isExistList;
	}
	public void setIsExistList(List isExistList) {
		this.isExistList = isExistList;
	}
	public String getIpport() {
		return ipport;
	}
	public void setIpport(String ipport) {
		this.ipport = ipport;
	}
	public String getIsexist() {
		return isexist;
	}
	public void setIsexist(String isexist) {
		this.isexist = isexist;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	public String getScreencode() {
		return screencode;
	}
	public void setScreencode(String screencode) {
		this.screencode = screencode;
	}
	public String getScreens() {
		return screens;
	}
	public void setScreens(String screens) {
		this.screens = screens;
	}
	public String getColorvalues() {
		return colorvalues;
	}
	public void setColorvalues(String colorvalues) {
		this.colorvalues = colorvalues;
	}
	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}
	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}
	/**
	 * @return the lineId
	 */
	public String getLineId() {
		return lineId;
	}
	/**
	 * @param lineId the lineId to set
	 */
	public void setLineId(String lineId) {
		this.lineId = lineId;
	}
//	/**
//	 * @return the port
//	 */
//	public String getPort() {
//		return port;
//	}
//	/**
//	 * @param port the port to set
//	 */
//	public void setPort(String port) {
//		this.port = port;
//	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
//	/**
//	 * @return the maxNum
//	 */
//	public String getMaxNum() {
//		return maxNum;
//	}
//	/**
//	 * @param maxNum the maxNum to set
//	 */
//	public void setMaxNum(String maxNum) {
//		this.maxNum = maxNum;
//	}
	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the lineList
	 */
	public List getLineList() {
		return lineList;
	}
	/**
	 * @param lineList the lineList to set
	 */
	public void setLineList(List lineList) {
		this.lineList = lineList;
	}
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}
	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	/**
	 * @return the statusList
	 */
	public List getStatusList() {
		return statusList;
	}
	/**
	 * @param statusList the statusList to set
	 */
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	/**
	 * @return the controllerPortList
	 */
	public List getControllerPortList() {
		return controllerPortList;
	}
	/**
	 * @param controllerPortList the controllerPortList to set
	 */
	public void setControllerPortList(List controllerPortList) {
		this.controllerPortList = controllerPortList;
	}
	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}
	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}
	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * @param operator the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * @return the createtime
	 */
	public String getCreatetime() {
		return createtime;
	}
	/**
	 * @param createtime the createtime to set
	 */
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	/**
	 * @return the runstate
	 */
	public String getRunstate() {
		return runstate;
	}
	/**
	 * @param runstate the runstate to set
	 */
	public void setRunstate(String runstate) {
		this.runstate = runstate;
	}
	/**
	 * @return the executeTime
	 */
	public String getExecuteTime() {
		return executeTime;
	}
	/**
	 * @param executeTime the executeTime to set
	 */
	public void setExecuteTime(String executeTime) {
		this.executeTime = executeTime;
	}
	/**
	 * @return the success
	 */
	public String getSuccess() {
		return success;
	}
	/**
	 * @param success the success to set
	 */
	public void setSuccess(String success) {
		this.success = success;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getRedcount() {
		return redcount;
	}
	public void setRedcount(String redcount) {
		this.redcount = redcount;
	}
	public String getYellowpercent() {
		return yellowpercent;
	}
	public void setYellowpercent(String yellowpercent) {
		this.yellowpercent = yellowpercent;
	}
	
	
	
}
