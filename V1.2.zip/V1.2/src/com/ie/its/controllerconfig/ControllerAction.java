/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.controllerconfig;

import java.util.HashMap;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.inifile.IniFileCreator;

//命名空间
@Namespace("/controller_config")
@Results({@Result(name="list",location="/controller_config/controller_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="controller_list",location="list.action",type="redirect")})
public class ControllerAction extends ExtendActionSupport {
	
	private ControllerData data;
	@Autowired
	private ControllerService controllerService;
	
	public ControllerData getData() {
		return data;
	}
	public void setData(ControllerData data) {
		this.data = data;
	}
	public ControllerAction(){
		if(data == null){
			data = new ControllerData();
		}
	}
	/**
     * Description :查询管理器．
     * @throws :Exception
     */
	@Action(value="controller_list",results={@Result(name="success",location="/controller_config/controller_list.jsp")})
	public String controller_list(){
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data = controllerService.controller_list(data);
		//获得地图下拉框
		data.setMapList(controllerService.get_mapCode());
		//获得通讯线路下拉框
		data.setLineList(controllerService.get_lineCode());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status"));
		//获取系统类型
		String sysModel = controllerService.queryForSystemModel();
		data.setSysModel(sysModel);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	
	
	
	@Action(value="controller_create",results={@Result(name="create",location="/controller_config/controller_create.jsp")})
	public String create(){
		data.setId("");
		//设置多语言
		setLang(data);
		
		//获得物理区域下拉框
		data.setLineList(controllerService.get_lineCode());
		
		return ConstantClass.ACTION_CREATE;
	}
	
	@Action(value="controller_save",results={@Result(type="json")})
	public void controller_save(){
		JSONObject json =  new JSONObject();
		try{
			data = controllerService.controller_save(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="controller_edit",results={@Result(name="edit",location="/controller_config/controller_edit.jsp")})
	public String controller_edit(){
		controllerService.controller_get(data);
		
		//设置多语言
		setLang(data);
		
		//获得地图下拉框
		data.setMapList(controllerService.get_mapCode());
		//获得通讯线路下拉框
		data.setLineList(controllerService.get_lineCode());
		//获得管理器端口下拉框
		data.setControllerPortList(controllerService.get_controllerPortCode());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status"));
		data.setIsExistList(Util.getCodeList(data, "enable"));
		//获取系统类型
		String sysModel = controllerService.queryForSystemModel();
		data.setSysModel(sysModel);
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="controller_multiedit",results={@Result(name="edit",location="/controller_config/controller_multiedit.jsp")})
	public String controller_multiedit(){
		controllerService.controller_get(data);
		
		//设置多语言
		setLang(data);
		
		//获得修改字段下拉框
		data.setMapList(controllerService.get_fieldCode(data));
		//获得通讯线路下拉框
		data.setLineList(controllerService.get_lineCode());
		//获得管理器端口下拉框
		data.setControllerPortList(controllerService.get_controllerPortCode());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status"));
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="controller_update",results={@Result(type="json")})
	public void controller_update(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.controller_update(data);
			json.element("success", true);
			json.element("sysModel", controllerService.queryForSystemModel());//add by jiangyf  前台提示系统类型
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="controller_multiupdate",results={@Result(type="json")})
	public void controller_multiupdate(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.controller_multiupdate(data);
			json.element("success", true);
			json.element("sysModel", controllerService.queryForSystemModel());//add by jiangyf  前台提示系统类型
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="controller_delete",results={@Result(type="json")})
	public void controller_delete(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.controller_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="controller_ini",results={@Result(type="json")})
	public void controller_ini(){		
		JSONObject json =  new JSONObject();
		try{
			data.setMap_src(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
			//设置多语言
			setLang(data);
			controllerService.controller_ini(data);
			json.element("success", true);
		} catch(Exception e){
			e.printStackTrace();
			json.element("success", false);
			json.element("msg",((HashMap) data.getCurrent_lang_switch().get("common")).get("ini_file_save_error"));
		}
		setJsonRes(json);
	}
	
	@Action(value="check_ini",results={@Result(type="json")})
	public void check_ini(){		
		JSONObject json =  new JSONObject();
		boolean b = controllerService.getLineId(data);
		setLang(data);
		if(b){
			json.element("line", true);
			try{
				controllerService.check_ini(data);
				json.element("success", true);
			} catch(Exception e){
				json.element("success", false);
				json.element("msg", ((HashMap) data.getCurrent_lang_switch().get("common")).get("ini_file_save_error"));
			}
		}else{
			json.element("line", false);
		}
		setJsonRes(json);
	}
	
	@Action(value="config_task",results={@Result(name="success",location="/controller_config/config_task.jsp")})
	public String config_task(){
		
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		controllerService.config_task(data);
		return "success";
	}
	
	@Action(value="config_task_delete",results={@Result(type="json")})
	public void config_task_delete(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.config_task_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	@Action(value="task_history_delete",results={@Result(type="json")})
	public void task_history_delete(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.task_history_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	@Action(value="config_history",results={@Result(name="success",location="/controller_config/config_history.jsp")})
	public String config_history(){
		
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		controllerService.config_history(data);
		return "success";
	}
	
	/**
     * Description :查询管理器．
     * @throws :Exception
     */
	@Action(value="controller_list_for_color_tactics",results={@Result(name="success",location="/controller_colortactics/controller_list.jsp")})
	public String controller_list_for_color_tactics(){
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data = controllerService.controller_list(data);
		//获得地图下拉框
		data.setMapList(controllerService.get_mapCode());
		//获得通讯线路下拉框
		data.setLineList(controllerService.get_lineCode());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status"));
		//获取系统类型
		String sysModel = controllerService.queryForSystemModel();
		data.setSysModel(sysModel);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	/**
	 * 新建变色策略任务
	 */
	@Action(value="create_color_task",results={@Result(type="json")})
	public void create_color_task(){		
		JSONObject json =  new JSONObject();
		try{
			//设置多语言
			setLang(data);
			controllerService.create_color_task(data);
			json.element("success", true);
		} catch(Exception e){
			e.printStackTrace();
			json.element("success", false);
			json.element("msg",((HashMap) data.getCurrent_lang_switch().get("common")).get("ini_file_save_error"));
		}
		setJsonRes(json);
	}
	
	@Action(value="check_color_task",results={@Result(name="success",location="/controller_colortactics/colortactics_task.jsp")})
	public String check_color_task(){
		
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		controllerService.check_color_task(data);
		return "success";
	}
	
	@Action(value="color_task_delete",results={@Result(type="json")})
	public void color_task_delete(){		
		JSONObject json =  new JSONObject();
		try{
			controllerService.color_task_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="color_task_history",results={@Result(name="success",location="/controller_colortactics/colortactics_history.jsp")})
	public String color_task_history(){
		
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		controllerService.color_task_history(data);
		return "success";
	}
	
	/**
	 * 根据选中管理器id获取引导屏，并将结果映射到colortatic_screen_list.jsp
	 * @return
	 */
	@Action(value="colortactics_screen_list",results={@Result(name="success",location="/controller_colortactics/colortactics_screen_list.jsp")})
	public String colortactics_screen_list(){
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		String tt = request.getParameter("data.id").toString();
		data.setId(request.getParameter("data.id").toString());
		data = controllerService.screen_list(data);
		request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
}
