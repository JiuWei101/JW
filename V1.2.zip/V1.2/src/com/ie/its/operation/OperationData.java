package com.ie.its.operation;

import java.util.List;

import com.ie.frame.ExtendData;

public class OperationData extends ExtendData {

	private String id;
	private String module_url;
	private String sort;
	private String state;
	private String module_name;
	private String log_name;
	private List sub_module;
	private String is_model;
	private String parent_id;
	private String name;
	private String lang_key;
	private String flag;
	private String bz;
	private String role_id;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getModule_url() {
		return module_url;
	}

	public void setModule_url(String module_url) {
		this.module_url = module_url;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getModule_name() {
		return module_name;
	}

	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}

	public String getLog_name() {
		return log_name;
	}

	public void setLog_name(String log_name) {
		this.log_name = log_name;
	}

	public List getSub_module() {
		return sub_module;
	}

	public void setSub_module(List sub_module) {
		this.sub_module = sub_module;
	}

	public String getIs_model() {
		return is_model;
	}

	public void setIs_model(String is_model) {
		this.is_model = is_model;
	}

	public String getParent_id() {
		return parent_id;
	}

	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLang_key() {
		return lang_key;
	}

	public void setLang_key(String lang_key) {
		this.lang_key = lang_key;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	public String getRole_id() {
		return role_id;
	}

	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}

	

}
