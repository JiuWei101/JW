package com.ie.its.operation;

import java.util.ArrayList;
import java.util.List;

import com.ie.common.ConstantClass;
import com.ie.common.IService;
import com.ie.frame.ExtendActionSupport;

public class OperationAction extends ExtendActionSupport {

	private static final long serialVersionUID = 1L;
	private OperationData operation;
	private OperationService operationService;
	
	public OperationAction(){
		if (operation == null) {
			operation = new OperationData();
		}
	}

	public String index() {
		operation = null;
		this.setTarget("operation_index");
		return SUCCESS;
	}

	public String left() {
		operation.setFlag("1");
		operation = (OperationData) operationService.listData(operation);
		request.setAttribute(ConstantClass.RQ_PER_PAGE, operation.getPer_data());
		this.setTarget("operation_left");
		return SUCCESS;
	}
	
	public String edit() {
		String parent_id = null;
		String id = null;
		if (operation != null) {
			id = operation.getId();
		}
		if (request.getParameter("id") != null) {
			id = request.getParameter("id");
		}
		operation = (OperationData) operationService.listData(operation, id);
		this.setTarget("operation_edit");
		return SUCCESS;
	}

	public String add() {
		String id = null;
		if (operation != null) {
			id = operation.getParent_id();
		}
		if (request.getParameter("id") != "") {
			id = request.getParameter("id");
		}
		operation = new OperationData();
		operation.setId(id);
		
		this.setTarget("operation_create");
		return SUCCESS;
	}
	public String delete() {
		operation.setId(request.getParameter("id"));
		operationService.deleteData(operation);
		this.setTarget("operation_edit.action?id=" + operation.getId());
		return "action";
	}

	public String update() {
		operation.setId(request.getParameter("id"));
		operationService.updateData(operation);
		this.setTarget("operation_edit.action?id=" + operation.getId());
		return "action";
	}
	
	public String save() {
		if(request.getParameter("parent_id") == ""){
			operation.setParent_id("00");
		}else{
			operation.setParent_id(request.getParameter("parent_id"));
		}
		operation = (OperationData) operationService.saveData(operation);
		this.setTarget("operation_create");
		return SUCCESS;
	}
	
	public OperationService getOperationService() {
		return operationService;
	}

	public void setOperationService(OperationService operationService) {
		this.operationService = operationService;
	}

	public OperationData getOperation() {
		return operation;
	}
	public void setOperation(OperationData operation) {
		this.operation = operation;
	}

}
