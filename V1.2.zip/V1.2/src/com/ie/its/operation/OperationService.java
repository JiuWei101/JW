package com.ie.its.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.frame.ExtendService;
@Scope("prototype")
@Service
public class OperationService extends ExtendService {

	public Object createData(Object o,String lang) {
		OperationData operation= (OperationData) o;
		if (operation == null) {
			operation = new OperationData();
		}
		StringBuffer sb = new StringBuffer();
		if(operation.getFlag().equals("bz")){
			sb.append("SELECT * FROM sys_act_relation a,sys_act b,sys_lang_switch sls where a.act_id = b.id and b.is_model <>'2' and b.lang_key = sls.code_key and sls.code_type='common' and sls.lang =");
			sb.append("'"+lang+"'");
			sb.append(" ORDER BY sort");
		}else{
			sb.append("SELECT * FROM sys_act_relation a,sys_act b,sys_lang_switch sls where a.act_id = b.id and b.lang_key = sls.code_key and sls.code_type='common' and sls.lang =");
			sb.append("'"+lang+"'");
			sb.append(" ORDER BY sort");
		}
		ArrayList al = new ArrayList();
		ArrayList rows = (ArrayList) getJt().queryForList(sb.toString());
		Iterator it = rows.iterator();
		OperationData temp = null;
		while (it.hasNext()) {
			temp = new OperationData();
			Map map = (Map) it.next();
			temp.setId((String)map.get("id"));
			temp.setModule_url((String)map.get("module_url"));
			temp.setSort(map.get("sort").toString());
			temp.setStart(Integer.parseInt((String)map.get("state")));
			temp.setModule_name((String)map.get("module_name"));
			temp.setLog_name((String)map.get("log_name"));
			temp.setIs_model((String)map.get("is_model"));
			temp.setParent_id((String)map.get("parent_id"));
			temp.setName((String)map.get("code_value"));
			al.add(temp);
		}
        operation.setPer_data(al);
		return operation;
	}

	public Object listData(Object ob, String parent_id) {
		OperationData operation = (OperationData) ob;
		if (operation == null) {
			operation = new OperationData();
		}
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT * FROM sys_act_relation a,sys_act b where a.act_id = b.id ");
		if(parent_id != null){
			sb.append("and b.id='"+parent_id+"'");
		}
		sb.append(" order by sort ");
		ArrayList rows = (ArrayList) getJt().queryForList(sb.toString());
		Iterator it = rows.iterator();
		if (it.hasNext()) {
			Map map = (Map) it.next();
			operation.setId((String)map.get("ID"));
			operation.setId((String)map.get("id"));
			operation.setModule_url((String)map.get("module_url"));
			operation.setSort(map.get("sort").toString());
			operation.setStart(Integer.parseInt((String)map.get("state")));
			operation.setModule_name((String)map.get("module_name"));
			operation.setLog_name((String)map.get("log_name"));
			operation.setIs_model((String)map.get("is_model"));
			operation.setParent_id((String)map.get("parent_id"));
			operation.setName((String)map.get("name"));
		}else{
			operation =  new OperationData();
		}
		return operation;
	}

	public Object updateData(Object ob) {
		OperationData operation = (OperationData) ob;
		
		StringBuffer sb = new StringBuffer();
		sb.append("UPDATE sys_act SET module_url = '");
		sb.append(StringManager.reSingleQuote(operation.getModule_url()));
		sb.append("',sort = '");
		sb.append(StringManager.reSingleQuote(operation.getSort()));
		sb.append("',state = '");
		sb.append("1");
		sb.append("',module_name = '");
		sb.append(StringManager.reSingleQuote(operation.getModule_name()));
		sb.append("',log_name = '");
		sb.append(StringManager.reSingleQuote(operation.getLog_name()));
		sb.append("',is_model = '");
		sb.append(StringManager.reSingleQuote(operation.getIs_model()));
		sb.append("',name = '");
		sb.append(StringManager.reSingleQuote(operation.getName()));
		//sb.append("',lang_key = '");
		//sb.append(StringManager.reSingleQuote(operation.getLang_key()));
		sb.append("' WHERE id = '");
		sb.append(StringManager.reSingleQuote(operation.getId()));
		sb.append("'");

		getJt().update(sb.toString());

		return operation;
	}
	public Object saveData(Object ob) {
		OperationData operation = (OperationData) ob;
		operation.setId(PrimaryId.getId());
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO sys_act(id,module_url,sort,state,module_name,log_name,is_model,name)");
		sb.append("VALUES ('");
		sb.append(operation.getId());
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getModule_url()));
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getSort()));
		sb.append("','");
		sb.append(StringManager.reSingleQuote("1"));
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getModule_name()));
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getLog_name())); 
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getIs_model()));
		sb.append("','");
		sb.append(StringManager.reSingleQuote(operation.getName()));
//		sb.append("','");
//		sb.append(StringManager.reSingleQuote(operation.getLang_key()));
		sb.append("')");
		getJt().update(sb.toString());
		StringBuffer sb_relation = new StringBuffer();
		sb_relation.append("INSERT INTO sys_act_relation(id,act_id,parent_id)");
		sb_relation.append("VALUES ('");
		sb_relation.append(PrimaryId.getId());
		sb_relation.append("','");
		sb_relation.append(StringManager.reSingleQuote(operation.getId()));
		sb_relation.append("','");
		sb_relation.append(StringManager.reSingleQuote(operation.getParent_id()));
		sb_relation.append("')");
		Log.log(sb_relation.toString());
		getJt().update(sb_relation.toString());
		return operation;
	}
	public String delFlag(String node_level){
		String str = "";
		StringBuffer sb = new StringBuffer();
	    sb.append("SELECT count(*) FROM sys_operate_node WHERE operate_node_level LIKE '");
	    sb.append(node_level + "%' ");
	    sb.append(" AND LENGTH(operate_node_level) > " + node_level.length());
	    int count = this.getJt().queryForInt(sb.toString());
	    if(count == 0){
	    	str = "yesDel";
	    }else{
	    	str = "noDel";
	    }
	    return str;
	}
	public Object deleteData(Object ob) {
		OperationData operation = (OperationData) ob;
		String sql = "DELETE FROM sys_act_relation WHERE act_id = '"+operation.getId()+"'";
		getJt().update(sql);
		String sb = "DELETE FROM sys_act WHERE id = '"+operation.getId()+"'";
		getJt().update(sb);
		return operation;
	}

	public Object updateData(Object ob, String kind) {
		OperationData operation = (OperationData) ob;
		if (kind.equals("level_up")) {
			//operation = (OperationData) levelUp(operation);
		} else if (kind.equals("level_down")) {
			//operation = (OperationData) levelDown(operation);
		} else if (kind.equals("grade_up")) {
			//operation = (OperationData) gradeUp(operation);
		} else if (kind.equals("grade_down")) {
			//operation = (OperationData) gradeDown(operation);
		}
		return operation;
	}
	public Object queryData(Object o,String lang) {
		OperationData operation= (OperationData) o;
		if (operation == null) {
			operation = new OperationData();
		}
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT * FROM sys_act_relation a,sys_act b,sys_lang_switch sls where a.act_id = b.id and b.is_model <>'2' and b.lang_key = sls.code_key and sls.code_type='common' and sls.lang =");
		sb.append("'"+lang+"'");
		sb.append(" ORDER BY sort");
		ArrayList al = new ArrayList();
		System.out.print(sb);
		ArrayList rows = (ArrayList) getJt().queryForList(sb.toString());
		Iterator it = rows.iterator();
		OperationData temp = null;
		while (it.hasNext()) {
			temp = new OperationData();
			Map map = (Map) it.next();
			
			StringBuffer sql = new StringBuffer();
			sql.append("select * from sys_role_act where role_id = '"+operation.getRole_id()+"' and act_id = '"+(String)map.get("id")+"'");
			ArrayList row_role = (ArrayList) getJt().queryForList(sql.toString());
			if(row_role.size() == 0){
				temp.setBz("false");
			}else{
				temp.setBz("true");
			}
			temp.setId((String)map.get("id"));
			temp.setModule_url((String)map.get("module_url"));
			temp.setSort(map.get("sort").toString());
			temp.setStart(Integer.parseInt((String)map.get("state")));
			temp.setModule_name((String)map.get("module_name"));
			temp.setLog_name((String)map.get("log_name"));
			temp.setIs_model((String)map.get("is_model"));
			temp.setParent_id((String)map.get("parent_id"));
			temp.setName((String)map.get("code_value"));
			al.add(temp);
		}
        operation.setPer_data(al);
		return operation;
	}
	
	public static void main(String[] args) {
	}
}
