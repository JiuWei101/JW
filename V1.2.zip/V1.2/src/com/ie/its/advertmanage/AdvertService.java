package com.ie.its.advertmanage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
/**
 * 广告的Service
 * @author mo
 */
@SuppressWarnings("rawtypes")
@Service("advertService")
public class AdvertService extends ExtendService {
	private final String SAVEPATH = ConstantClass.MyFile_Separator + "advertupload" + ConstantClass.MyFile_Separator;	//文件保存的目录
	
	/**
	 * 添加一个广告信息
	 * @param advertData
	 */
	public String insertAdvert(AdvertData advertData, File file, String fileName, String fileType){
		String advertSrc = "";
		StringBuffer sb = new StringBuffer();
		sb.append("insert into p_advertbaseinfo (id, advertName, advertType, advertSrc, inuse, updateDate, playTime, advertPosition) values (")
			.append(PrimaryId.getId() + ",");
		advertSrc = saveFile(file, fileName);
		sb.append(Util.toSqlVal(fileName.split("\\.")[0]) + ",");
		if(advertSrc != null){
			sb.append(Util.toSqlVal(fileType)).append(",").append(Util.toSqlVal(advertSrc)).append(",")
			.append(Util.toSqlVal(0)).append(",").append(Util.toSqlVal(Util.sdfTime.format(new Date()))).append(",")	//默认为不启用并插入插入的时间
			.append(10).append(",")				//插入的时候默认插入的播放时候为10秒
			.append(Util.toSqlVal(advertData.getAdvertPosition() == null ? "0" : advertData.getAdvertPosition())).append(")");	//如果为空表示在首页显示的
		Log.log(sb);
		this.getJt().execute(sb.toString());
		}
		return "";
	}
	
	/**
	 * 保存文件到指定的目录
	 * @param file
	 * @return 文件保存的路径
	 */
	public String saveFile(File file, String fileName){
		String path = ServletActionContext.getServletContext().getRealPath(SAVEPATH);
		File savePath = new File(path); 	//advertupload目录是否存在,不在就创建
		if(!savePath.isDirectory()){
			boolean flag = savePath.mkdirs();
			Log.log("Mkdir: " + savePath + " is " + flag);
		}
		fileName = Util.sdfTime_14b.format(new Date()) + "." + getExtensionName(fileName);
		String saveFile = savePath.getAbsolutePath() + ConstantClass.MyFile_Separator + fileName;	//组成一个完成的文件目录路径
		System.out.println("SaveFile: " + saveFile);
		FileOutputStream fos = null;
		FileInputStream fis = null;
		try {
			if(file != null && file.isFile()){			//如果不是文件就不操作
				fos = new FileOutputStream(saveFile);
				fis = new FileInputStream(file);
				byte[] buff = new byte[1024];
				int len = 0;
				while((len = fis.read(buff)) > 0){
					fos.write(buff, 0, len);
				}
			}
		} catch (FileNotFoundException e) {
			Log.log("AdvertService.java FileInputStream \n" + e);
			return null;
		} catch (IOException e) {
			Log.log("InsertAdvert Read File error");
			return null;
		} finally{
			try {	//使用完就关闭IO,否则上传的文件会一直被占用，直到服务器停止..
				if (null != fis) {
					fis.close();
				}
				if (null != fos) {
					fos.close();
				}
			} catch (IOException e) {
				Log.log(e);
			}
		}
		return SAVEPATH + fileName;
	}
	
	/**
	 * 启用广告功能
	 * @param advertData
	 * @return
	 */
	public int modifyAdvert(AdvertData advertData){
		String sql = "update p_advertbaseinfo set inuse=" + Util.toSqlVal(advertData.getInuse()) + " where id=" + Util.toSqlVal(advertData.getAdvertId()) + ";";
		Log.log(sql);
		return this.getJt().update(sql);
	}
	
	/**
	 * 更改广告的播放时间
	 * @param advertData
	 * @return
	 */
	public int modifyPlayTime(AdvertData advertData){
		String sql = "update p_advertbaseinfo set playTime=" + advertData.getPlayTime() + " where id=" + Util.toSqlVal(advertData.getAdvertId()) + ";";
		Log.log(sql);
		return this.getJt().update(sql);
	}
	
	/**
	 * 删除广告信息
	 * @param advertData
	 */
	public void deleteAdvert(AdvertData advertData){
		String sql = "";
		sql += "delete from p_advertbaseinfo where id=";
		sql += Util.toSqlVal(advertData.getAdvertId()) + ";";		//先组合删除的sql语句
		Log.log(sql);
		String querySql = "select advertSrc from p_advertbaseinfo where id=" + Util.toSqlVal(advertData.getAdvertId()) + ";";
		advertData = this.getJt().queryForObjectExt(querySql, AdvertData.class);
		String realPath = ServletActionContext.getServletContext().getRealPath("");	//项目的根目录
		String filePath = realPath + advertData.getAdvertSrc();	//文件的路径
		File file = new File(filePath);
		if(file.isFile() && file.exists()){		//如果当前对象是文件并且存在就删除该文件
			file.delete();		//删除广告文件
		}
		this.getJt().execute(sql);		//当文件删除后就删除数据库的记录
	}
	
	/**
	 * 查询广告的service
	 * @param inuse	是否可用,为空时查询出所有在AdvertPosition的广告
	 * @param pageIndex	当前页,和pageSize都为-1时不分页.用于寻车界面的广告显示
	 * @param pageSize	每页显示和条数
	 * @param advertPosition	在那个为位置显示的
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<AdvertData> queryAdvert(String inuse, int pageIndex, int pageSize, String advertPosition){
		String sql = "select a.id as advertId, advertName, advertSrc, advertType, inuse, updateDate, playTime, advertPosition from" +
				" p_advertbaseinfo as a where a.advertPosition=" + Util.toSqlVal(advertPosition) + "";
		if(null != inuse && !inuse.equals("")){		//后台查询的时候inuse为空,所以不需要加inuse条件
			sql += " and inuse=" + Util.toSqlVal(inuse);
		}
		sql += " ORDER BY a.id DESC";		//排一下序吧..
		if(pageIndex != -1 && pageSize != -1){			//分页啦..
			int start = (pageIndex - 1) * pageSize;
			sql +=  " limit " + start + "," + pageSize + ";";
		}
		Log.log(sql);		//Log查询语句
		List<AdvertData> list = (ArrayList<AdvertData>)this.getJt().queryForListExt(sql, AdvertData.class);	//执行查询语句
		String contextPath = ServletActionContext.getRequest().getContextPath();	//获取项目的根目录
		for(AdvertData advertData : list){
			advertData.setAdvertSrc(contextPath + advertData.getAdvertSrc());	//设置图片显示的路径
			String date = advertData.getUpdateDate();
			advertData.setUpdateDate(date.substring(0, date.length() - 2));	//截掉时间小数点后的数
		}
		return list;
	}
	
	/**
	 * 查询JSON格式的数据, 不分页,用于寻车界面的广告显示
	 * @param type 广告类型　
	 * @return	
	 */
	public JSONArray queryAdvertJson(String advertPosition){
		JSONArray arr = new JSONArray();
		List<AdvertData> list = this.queryAdvert("1", -1, -1, advertPosition);
		arr = getJSONArrayData(list);
		return arr;
	}
	
	/**
	 * 文本广告或图片广告组合成ＡＲＲＡＹ格式数据
	 * @param list
	 * @return
	 */
	private JSONArray getJSONArrayData(List<AdvertData> list){
		JSONArray arr = new JSONArray();
		if(list.size() > 0){
			for(AdvertData advert : list){
				JSONObject json = new JSONObject();
				json.element("type", advert.getAdvertType());
				json.element("data", advert.getAdvertSrc());
				json.element("playTime", advert.getPlayTime());
				arr.add(json);
			}
		} else{		//当没有数据时要返回 [{"type": "", "data": "", "playTime": ""}] 类型这样的格式到前台
			JSONObject json = new JSONObject();
			json.element("type", "");
			json.element("data", "");
			json.element("playTime", "");
			arr.add(json);
		}
		return arr;
	}
	
	/**
	 * 获取总的页数
	 * @param pageSize
	 * @param type 广告类型　
	 * @return 
	 */
	public int getTotalPage(int pageSize, String advertPosition){
		StringBuilder countSql = new StringBuilder();
		countSql.append("select count(*) from p_advertbaseinfo WHERE advertPosition=")
					.append(Util.toSqlVal(advertPosition)).append(";");
		Log.log("\n[AdvertTotalPageSql]: " + countSql);
		int total = this.getJt().queryForInt(countSql.toString());
		int t = total / pageSize;
		return total % pageSize > 0 ? t + 1 : t;
	}
	
	/**
	 * 获取文件后缀名
	 * @param filename
	 * @return 
	 */
	public static String getExtensionName(String filename) {
		if ((filename != null) && (filename.length() > 0)) {
			int dot = filename.lastIndexOf('.');
			if ((dot > -1) && (dot < (filename.length() - 1))) {
				return filename.substring(dot + 1);
			}
		}
		return filename;
	} 

}
