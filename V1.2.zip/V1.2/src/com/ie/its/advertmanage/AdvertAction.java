package com.ie.its.advertmanage;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
/**
 * 广告的Action
 * @author mo
 */
@SuppressWarnings("serial")
@Namespace("/advert")
public class AdvertAction extends ExtendActionSupport {
	@Autowired
	private AdvertService advertService;
	private AdvertData advert;
	private List<AdvertData> listAdvert;
	private int pageIndex = 1;	//页码
	private int pageSize = 12;	//每页显示的条数, 默认为5条
	private int total;		//总的页数
	private File advertFile;		//上传的文件
	private String advertFileFileName;	//上传文件的文件名
	private String advertFileContentType;	//上传文件的类型
	private String message;	//返回信息
	private Map langMap;	//国际化
	private final long ALLOWEDFILESIZE = 20 * 1024 * 1024;	//允许上传的文件大小
	private final String ALLOWEDTYPE = "image/gif,image/png,image/bmp,image/pjpeg,image/jpg,image/jpeg," +
			"application/x-shockwave-flash";	//允许上传的类型
	private String position;
	
	/**
	 * 插入广告的Action
	 */
	@Action(value="insertAdvert", results={@Result(type="json")})
	public void insertAdvert(){
		response.setContentType("text/plain;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		//上面的检查都通过后才执行上传功能
		JSONObject jo = new JSONObject();
		advertService.insertAdvert(advert, advertFile, advertFileFileName, advertFileContentType);  
		jo.element("success", true);
		setJsonRes(jo);
	}

	/**
	 * 修改广告的Action
	 */
	@Action(value="modifyAdvert", results={@Result(type="json")})
	public void modifyAdvert(){
		int i = advertService.modifyAdvert(advert);
		
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("advert");
		JSONObject jo = new JSONObject();
		boolean flag = i == 1 ? true : false;
		jo.element("flag", flag);
		setJsonRes(jo);
	}
	
	/**
	 * 修改广告的播放时间
	 */
	@Action(value="modifyPlayTime", results={@Result(type="json")})
	public void modifyPlayTime(){
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("advert");
		int i = advertService.modifyPlayTime(advert);
		JSONObject jo = new JSONObject();
		boolean flag = i == 1 ? true : false;
		jo.element("flag", flag);
		setJsonRes(jo);
	}
	
	/**
	 * 删除广告的Action
	 */
	@Action(value="deleteAdvert",
			results={@Result(name="success", location="queryAdvert.action", type="redirectAction", params={"position", "${position}"})})
	public String deleteAdvert(){
		position = position == null ? "0" : position;
		advertService.deleteAdvert(advert);
		return SUCCESS;
	}
	
	/**
	 * 查询广告
	 * @return 查询后跳转到显示页面
	 */
	@Action(value="queryAdvert", results={@Result(name="success", location="/advert_manage/advertManage.jsp")})
	public String queryAdvert(){
		langMap = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		
		listAdvert = advertService.queryAdvert(null, pageIndex, pageSize, position == null ? "0" : position);
		this.total = advertService.getTotalPage(pageSize, position == null ? "0" : position);
		position = position == null ? "0" : position;
		
		return SUCCESS;
	}
	
	/**
	 * 检查是否允许上传的文件类型
	 * @param advertFileContentType	上传的文件类型
	 * @return true为该文件允许上传，false为不允许 
	 */
	public boolean checkAllowedType(String advertFileContentType){
		String[] allowedTypes = ALLOWEDTYPE.split(",");
		boolean flag = false;
		for(String allowed : allowedTypes){		//
			if(allowed.trim().equals(advertFileContentType.trim())){
				flag = true;
			}
		}
		return flag;
	}
	
	/**
	 * 检查是否允许上传的文件大小
	 * @param fileSize 文件的大小
	 * @return True为通过，False为不通过
	 */
	public boolean checkAllowedSize(long fileSize){
		boolean flag = false;
		if(fileSize <= ALLOWEDFILESIZE){
			flag = true;
		}
		return flag;
	}

	public List<AdvertData> getListAdvert() {
		return listAdvert;
	}

	public void setListAdvert(List<AdvertData> listAdvert) {
		this.listAdvert = listAdvert;
	}

	public AdvertData getAdvert() {
		return advert;
	}

	public void setAdvert(AdvertData advert) {
		this.advert = advert;
	}

	public File getAdvertFile() {
		return advertFile;
	}

	public void setAdvertFile(File advertFile) {
		this.advertFile = advertFile;
	}

	public String getAdvertFileFileName() {
		return advertFileFileName;
	}

	public void setAdvertFileFileName(String advertFileFileName) {
		this.advertFileFileName = advertFileFileName;
	}

	public String getAdvertFileContentType() {
		return advertFileContentType;
	}

	public void setAdvertFileContentType(String advertFileContentType) {
		this.advertFileContentType = advertFileContentType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public Map getLangMap() {
		return langMap;
	}

	public void setLangMap(Map langMap) {
		this.langMap = langMap;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
}
