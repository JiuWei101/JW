package com.ie.its.advertmanage;

import com.ie.frame.ExtendData;
/**
 * 广告类
 * @author mo
 */
public class AdvertData extends ExtendData {

	private String advertId;
	private String advertName; 	//广告名称
	private String advertSrc;	//广告路径
	private String advertType;	//广告类型
	private String inuse;	//是否启用
	private String updateDate;	//更新时间
	private int playTime;	//广告播放的时间
	private String advertPosition;	//广告显示的位置
	
	public String getAdvertName() {
		return advertName;
	}
	public void setAdvertName(String advertName) {
		this.advertName = advertName;
	}
	public String getAdvertSrc() {
		return advertSrc;
	}
	public void setAdvertSrc(String advertSrc) {
		this.advertSrc = advertSrc;
	}
	public String getInuse() {
		return inuse;
	}
	public void setInuse(String inuse) {
		this.inuse = inuse;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getAdvertId() {
		return advertId;
	}
	public void setAdvertId(String advertId) {
		this.advertId = advertId;
	}
	public String getAdvertType() {
		return advertType;
	}
	public void setAdvertType(String advertType) {
		this.advertType = advertType;
	}

	public String getAdvertPosition() {
		return advertPosition;
	}

	public void setAdvertPosition(String advertPosition) {
		this.advertPosition = advertPosition;
	}
	public int getPlayTime() {
		return playTime;
	}
	public void setPlayTime(int playTime) {
		this.playTime = playTime;
	}
	@Override
	public String toString() {
		return "AdvertData [advertId=" + advertId + ", advertName="
				+ advertName + ", advertSrc=" + advertSrc + ", advertType="
				+ advertType + ", inuse=" + inuse + ", updateDate="
				+ updateDate + ", playTime=" + playTime + ", advertPosition="
				+ advertPosition + "]";
	}
}
