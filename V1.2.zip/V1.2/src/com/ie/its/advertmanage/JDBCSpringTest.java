package com.ie.its.advertmanage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JDBCSpringTest {

	private static ApplicationContext getContext(String path){
		ApplicationContext act = new ClassPathXmlApplicationContext(path);
		return act;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AdvertService as = (AdvertService) getContext("applicationContext.xml").getBean("advertService");
//		AdvertData advertData = new AdvertData();
//		advertData.setAdvertId("20130428112528000001");
//		as.deleteAdvert(advertData);
		
		as.queryAdvertJson("0");
	}

}
