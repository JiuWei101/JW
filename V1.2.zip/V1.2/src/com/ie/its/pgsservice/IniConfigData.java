package com.ie.its.pgsservice;

import java.io.Serializable;
/**
 * ini配置文件类
 * @author Mo
 */
@SuppressWarnings("serial")
public class IniConfigData implements Serializable {
	
	public final static String APPOINTNAME = "[SYSTEM]";
	
	private String common_Log_Max_Bak_Num;
	private String common_Log_Max_Log_Size;
	private String dbop_Log_Max_Bak_Num;
	private String dbop_Log_Max_Log_Size;
	private String sr_Txt_Max_Bak_Num;
	private String sr_Txt_Max_Log_Size;
	private String gvA1SendPeriod;
	private String gvCallbackQueueThreadCount;
	private String gvEnabledTimeToReinitCache;
	private String gvPictureBufferSize;
	private String gvPictureDataPath;
	private String gbPictureReceiveThreadPoolSize;
	private String gvProxyPort;
	private String gvReceivePackageCount;
	private String gvTimeToReinitCache;
	private String gvVideoOffLineJudgementTime;
	private String fileName;
	public String getCommon_Log_Max_Bak_Num() {
		return common_Log_Max_Bak_Num;
	}
	public void setCommon_Log_Max_Bak_Num(String common_Log_Max_Bak_Num) {
		this.common_Log_Max_Bak_Num = common_Log_Max_Bak_Num;
	}
	public String getCommon_Log_Max_Log_Size() {
		return common_Log_Max_Log_Size;
	}
	public void setCommon_Log_Max_Log_Size(String common_Log_Max_Log_Size) {
		this.common_Log_Max_Log_Size = common_Log_Max_Log_Size;
	}
	public String getDbop_Log_Max_Bak_Num() {
		return dbop_Log_Max_Bak_Num;
	}
	public void setDbop_Log_Max_Bak_Num(String dbop_Log_Max_Bak_Num) {
		this.dbop_Log_Max_Bak_Num = dbop_Log_Max_Bak_Num;
	}
	public String getDbop_Log_Max_Log_Size() {
		return dbop_Log_Max_Log_Size;
	}
	public void setDbop_Log_Max_Log_Size(String dbop_Log_Max_Log_Size) {
		this.dbop_Log_Max_Log_Size = dbop_Log_Max_Log_Size;
	}
	public String getSr_Txt_Max_Bak_Num() {
		return sr_Txt_Max_Bak_Num;
	}
	public void setSr_Txt_Max_Bak_Num(String sr_Txt_Max_Bak_Num) {
		this.sr_Txt_Max_Bak_Num = sr_Txt_Max_Bak_Num;
	}
	public String getSr_Txt_Max_Log_Size() {
		return sr_Txt_Max_Log_Size;
	}
	public void setSr_Txt_Max_Log_Size(String sr_Txt_Max_Log_Size) {
		this.sr_Txt_Max_Log_Size = sr_Txt_Max_Log_Size;
	}
	public String getGvA1SendPeriod() {
		return gvA1SendPeriod;
	}
	public void setGvA1SendPeriod(String gvA1SendPeriod) {
		this.gvA1SendPeriod = gvA1SendPeriod;
	}
	public String getGvCallbackQueueThreadCount() {
		return gvCallbackQueueThreadCount;
	}
	public void setGvCallbackQueueThreadCount(String gvCallbackQueueThreadCount) {
		this.gvCallbackQueueThreadCount = gvCallbackQueueThreadCount;
	}
	public String getGvEnabledTimeToReinitCache() {
		return gvEnabledTimeToReinitCache;
	}
	public void setGvEnabledTimeToReinitCache(String gvEnabledTimeToReinitCache) {
		this.gvEnabledTimeToReinitCache = gvEnabledTimeToReinitCache;
	}
	public String getGvPictureBufferSize() {
		return gvPictureBufferSize;
	}
	public void setGvPictureBufferSize(String gvPictureBufferSize) {
		this.gvPictureBufferSize = gvPictureBufferSize;
	}
	public String getGvPictureDataPath() {
		return gvPictureDataPath;
	}
	public void setGvPictureDataPath(String gvPictureDataPath) {
		this.gvPictureDataPath = gvPictureDataPath;
	}
	public String getGbPictureReceiveThreadPoolSize() {
		return gbPictureReceiveThreadPoolSize;
	}
	public void setGbPictureReceiveThreadPoolSize(
			String gbPictureReceiveThreadPoolSize) {
		this.gbPictureReceiveThreadPoolSize = gbPictureReceiveThreadPoolSize;
	}
	public String getGvProxyPort() {
		return gvProxyPort;
	}
	public void setGvProxyPort(String gvProxyPort) {
		this.gvProxyPort = gvProxyPort;
	}
	public String getGvReceivePackageCount() {
		return gvReceivePackageCount;
	}
	public void setGvReceivePackageCount(String gvReceivePackageCount) {
		this.gvReceivePackageCount = gvReceivePackageCount;
	}
	public String getGvTimeToReinitCache() {
		return gvTimeToReinitCache;
	}
	public void setGvTimeToReinitCache(String gvTimeToReinitCache) {
		this.gvTimeToReinitCache = gvTimeToReinitCache;
	}
	public String getGvVideoOffLineJudgementTime() {
		return gvVideoOffLineJudgementTime;
	}
	public void setGvVideoOffLineJudgementTime(String gvVideoOffLineJudgementTime) {
		this.gvVideoOffLineJudgementTime = gvVideoOffLineJudgementTime;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public static String getAppointname() {
		return APPOINTNAME;
	}
	
}
