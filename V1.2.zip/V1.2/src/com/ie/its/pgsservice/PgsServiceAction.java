//实现pgsServer服务状态的监控和操作  added by LLX 2012.08.24

package com.ie.its.pgsservice;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.sql.DataSource;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.its.controllerconfig.ControllerService;
import com.ie.its.debuggingtool.ServerSocketListener;


//命名空间
@SuppressWarnings("serial")
@Namespace("/pgsservice")

public class PgsServiceAction extends ExtendActionSupport{
	private String debugSerStatus;
	private ExtendData data;
	private IniConfigData iniConfigData;
	
	private ControllerService controllerService = new ControllerService();
	
	public ExtendData getData() {
		return data;
	}

	public void setData(ExtendData data) {
		this.data = data;
	}

	public DataSource getDataSource(){
		WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
		DataSource ds = (DataSource)wac.getBean("dataSource");		
		return ds;
	}
	
	public String start(){//调用cmd启动服务
		String returnStr = "RUNNING";
		String serviceName = "pgsServer"; //服务名，此项目用的是pgsServer
		try{
			Runtime rt = Runtime.getRuntime();
			Process proc = null;
			if(getOS().indexOf("Windows")!= -1){
				String cmdStr = "cmd.exe /c "+" sc start " +serviceName+" ";
				proc = rt.exec(cmdStr);
			}
			else
			{
				String[] lcmdStr = new String[]{"sh","-c","service " + serviceName + " start"};
				proc = rt.exec(lcmdStr);
			}
			int tag = proc.waitFor();// 等待进程终止  
		}catch (Exception e) {
			   e.printStackTrace();
			   returnStr = "error";
			  }
		return returnStr;
	}
	
	public String stop(){//调用cmd关闭服务
		String returnStr = "STOPPED";
		String serviceName = "pgsServer"; //服务名，此项目用的是pgsServer
		try{
			Runtime rt = Runtime.getRuntime();
			Process proc  = null;
			if(getOS().indexOf("Windows")!= -1){
				String cmdStr = " sc stop "+serviceName+" ";
				proc = rt.exec("cmd.exe /c "+cmdStr);
			}else
			{
				String[] lcmdStr = new String[]{"sh","-c","service " + serviceName + " stop"};
				proc = rt.exec(lcmdStr);
			}
			int tag = proc.waitFor();// 等待进程终止
			updateControllerIni();
		}catch (Exception e) {
			   e.printStackTrace();
			   returnStr = "error";
			  }
		return returnStr;
	}
	
	public String query(){//查询服务状态
		String returnStr = "";
		String serviceName = "pgsServer"; //服务名，此项目用的是pgsServer
		try{
			Runtime rt = Runtime.getRuntime();//调用CMD命令查询服务状态
			Process proc = null;
			if(getOS().indexOf("Windows")!= -1){
				String cmdStr = " sc query "+serviceName+"|Findstr /i \"STATE\" ";
				proc = rt.exec("cmd.exe /c "+cmdStr);
			}else{
				String[] lcmdStr = new String[]{"sh","-c","service " + serviceName + " status"};
				Log.log(lcmdStr);
				proc = rt.exec(lcmdStr);
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			String result = br.readLine();
			if(Util.isCon(result)){
				Log.log("查询pgsServer返回结果："+result);
				int RUNNING = result.indexOf("RUNNING");
				int STOPPED = result.indexOf("STOPPED");
				if(RUNNING>0){
					returnStr = "RUNNING";
				}else if(STOPPED>0){
					returnStr = "STOPPED";
				}
			}else{
				returnStr = "STOPPED";
			}
		}catch (Exception e) {
			   e.printStackTrace();
			   returnStr = "STOPPED";
			  }
		Log.log("查询pgsServer处理结果："+returnStr);
		return returnStr;
	}
	
	
	@Action(value="pgsservice_read",results={@Result(name="read",location="/system_manage/pgs_service.jsp")})
	public String read(){
		data = new ExtendData();
		//设置多语言
		setLang(data);
		Log.log(11111);
 		return "read";
	}

	public String queryProcess(){
		String processName = "";//进程名
		processName = "PgsServer.exe";//本项目使用的是PgsServer.exe
		String returnStr = "";
		if(findProcess(processName)){
			returnStr = "RUNNING";
		}else{
			returnStr = "STOPPED";
		}
		return returnStr;
	}
		
	//查看系统进程的状态
	public static boolean findProcess(String processName){
		BufferedReader br=null;
		try{
			Runtime rt = Runtime.getRuntime();
			Process proc=null;
			if(new PgsServiceAction().getOS().indexOf("Windows")!=-1){
				String str = "tasklist /FI \"IMAGENAME eq " + processName +" \"";
				//下面这句是列出含有processName的进程图像名
				proc = rt.exec(str);
			}
			else{
				String[] lcmdStr = new String[]{"sh","-c","service pgsServer fprocess"};
				proc = rt.exec(lcmdStr);
			}
			br=new BufferedReader(new InputStreamReader(proc.getInputStream()));
			String line=null;
			while((line=br.readLine())!=null){
				//判断指定的进程是否在运行
				if(line.contains(processName)){
					return true;
				}
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			if(br!=null){
				try{
					br.close();
			    }catch(Exception ex){
				}
			}
			
		}
	}
	//查询服务状态
	public String  queryDebugSer(){
		
		WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
		debugSerStatus=(String) wac.getServletContext().getAttribute("debugSerStatus");
		if(debugSerStatus==null){
			debugSerStatus="STOPPED";
		}
		return debugSerStatus;
	}
	//开启服务状态
   public String startDebugTSer(){
	   debugSerStatus="RUNNING";
	   WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
	   wac.getServletContext().setAttribute("debugSerStatus", debugSerStatus);
	   ServerSocketListener. getInstance().contextInitialized();
	  // Map<String, Object> session= ActionContext.getContext().getSession();
	   
	   return debugSerStatus;
	   
   }
 //停止服务状态
   public String stopDebugTSer(){
	  
	   WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
	   debugSerStatus=(String) wac.getServletContext().getAttribute("debugSerStatus");
	   
	   if(debugSerStatus.equals("RUNNING")){
		   debugSerStatus="STOPPED";
		   wac.getServletContext().setAttribute("debugSerStatus", debugSerStatus);
	   }
	   ServerSocketListener. getInstance().contextDestroyed();
	   
	  // Map<String, Object> session= ActionContext.getContext().getSession();
	   
	   return debugSerStatus;
	   
   }
	//获取当前系统名称
	public String getOS(){
		return System.getProperties().getProperty("os.name");
	}
	
	public int getRunTaskCount(){
		controllerService.setDataSource(getDataSource());
		int count = controllerService.getRunTaskCount();
		return count;
	}
	
	public int updateControllerIni(){
		controllerService.setDataSource(getDataSource());
		int count = controllerService.updateControllerIni();
		return count;
	}
	
	/**
	 * 后台配置管理页面
	 * @return
	 */
	@Action(value="config_file_manage",results={@Result(name="success",location="/system_manage/configFileManage.jsp")})
	public String configFileManage(){
		data = new ExtendData();
		//设置多语言
		setLang(data);
		return SUCCESS;
	}
	
	/**
	 * 加载配置文件
	 * @return
	 */
	@Action(value="queryValueByini",results={@Result(type="json")})
	public void queryValueByini(){
		JSONObject json = new JSONObject();
		json = controllerService.queryValueByini(iniConfigData.getFileName());
		
		setJsonRes(json);
	}
	
	/**
	 * 修改配置文件
	 * @return
	 */
	@Action(value="updateIniValue",results={@Result(type="json")})
	public void updateIniValue(){
		JSONObject json = new JSONObject();
		json = controllerService.updateIniValue(iniConfigData);
		
		setJsonRes(json);
	}
	

	public IniConfigData getIniConfigData() {
		return iniConfigData;
	}

	public void setIniConfigData(IniConfigData iniConfigData) {
		this.iniConfigData = iniConfigData;
	}
}
























