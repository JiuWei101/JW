package com.ie.its.detectorconfig;

import static com.ie.common.Util.*;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.mapmanage.MapManageData;

public class DetectorConfigSql extends ExtendSql{
	/**
     * Description :查询探测器．
     * @param  :DetectorData,String
     * @return :String
     */
	public String detector_list(DetectorConfigData data,String type,String lang) {
		String querySql = "";
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select dtt.id,map.name as mapName,dtt.mapId,dtt.controllerId,ctl.addr as controllerAddr,dtt.addr,dtt.guideRegionId,gr.code as guideRegionCode,dct.code as detectorType,dtt.code,dtt.status,dtt.enable,pps.notes,dtt.detectorModel ";
		}
		
		if(isCon(data.getControllerAddrId())){
			querySql += " from p_detector dtt inner join p_parkingspace pps on dtt.id = pps.detectorId left join p_map map on dtt.mapId=map.id inner join p_controller ctl on dtt.controllerId=ctl.id left join p_guideregion gr on dtt.guideRegionId=gr.id left join p_detectortype dct on dtt.detectorTypeId=dct.id";
		}else{
			querySql += " from p_detector dtt inner join p_parkingspace pps on dtt.id = pps.detectorId left join p_map map on dtt.mapId=map.id left join p_controller ctl on dtt.controllerId=ctl.id left join p_guideregion gr on dtt.guideRegionId=gr.id left join p_detectortype dct on dtt.detectorTypeId=dct.id";
		}
		querySql += " where 1=1 ";
		
		if(isCon(data.getMapId())){
			querySql += " and dtt.mapId = " + toSqlVal(data.getMapId());
		}
		if(isCon(data.getDetectorTypeId())){
			querySql += " and dtt.detectorTypeId = " + toSqlVal(data.getDetectorTypeId());
		}
		if(isCon(data.getControllerAddrId())){
			querySql += " and ctl.addr = " + toSqlVal(data.getControllerAddrId());
		}
		if(isCon(data.getDetectorCode())){
			querySql += " and dtt.code like " + toSqlValLike(data.getDetectorCode(),"ALL");
		}
		if(isCon(data.getStatus())){
			querySql += " and dtt.status = " + toSqlVal(data.getStatus());
		}		
		if(isCon(data.getEnable())){
			querySql += " and dtt.enable = " + toSqlVal(data.getEnable());
		}
		if(isCon(data.getDetectorModel())){
			querySql += " and dtt.detectorModel = " + toSqlVal(data.getDetectorModel());
		}
		if("count" != type){
			querySql += " order by dtt.code";
		}
		return querySql;
	}
	
	/**
     * Description :获得探测器信息．
     * @param  :DetectorData
     * @return :String
     */
	public String detector_get(DetectorConfigData data, String lang) {
		String querySql = "";
		querySql = "select dtt.id,map.name as mapName,dtt.mapId,dtt.controllerId,ctl.addr as controllerAddr,dtt.addr,dtt.guideRegionId,gr.code as guideRegionCode,dct.code as detectorType,dtt.code,lang.code_value as status,dtt.enable,dtt.detectorModel";
		querySql += " from p_detector dtt left join p_map map on dtt.mapId=map.id left join p_controller ctl on dtt.controllerId=ctl.id left join p_guideregion gr on dtt.guideRegionId=gr.id left join p_detectortype dct on dtt.detectorTypeId=dct.id ";
		querySql += " left join sys_lang_switch lang on lang.code_type='ctrl_status' and dtt.status=lang.code_key ";
		querySql += " and lang.lang = " + Util.toSqlVal(lang) + " where dtt.id=";
		
		querySql += Util.toSqlVal(data.getId());
		
		
		return querySql;
	}

	/**
     * Description :更新地图信息．
     * @param  :DetectorData
     * @return :String
     */
	public String map_update(DetectorConfigData data) {
		String updateSql = "";
		updateSql += "update p_map set path=" + Util.toSqlVal(data.getPath() + data.getFileName());
		updateSql += " where id =" + Util.toSqlVal(data.getId());
		
		return updateSql;
	}	
	
	
	/**
	 * Description :检查地图路径是否重复．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_impcheck(DetectorConfigData data) {
		String updateSql = "";

		updateSql += "select count(*) from  p_map where path="
				+ Util.toSqlVal(data.getPath() + data.getFileName());

		if (Util.isCon(data.getId())) {
			updateSql += " and id != " + Util.toSqlVal(data.getId());
		}

		Log.log(updateSql);
		return updateSql;
	}
	
	/**
     * Description :更新探测器信息．
     * @param  :DetectorData
     * @return :String
     */
	public String detector_update(DetectorConfigData data) {
		String updateSql = "";
		
		updateSql += "update p_detector set enable=" + Util.toSqlVal(data.getEnable());
		updateSql += " where id =" + Util.toSqlVal(data.getId());
		
		return updateSql;
	}	

	/**
     * Description :全部更新探测器信息．
     * @param  :DetectorData
     * @return :String
     */
	public String detector_allupdate(String id, String[] fields, String[] values) {
		String updateSql = "";
		updateSql += "update p_detector set ";
		for(int i = 0; i < fields.length; i++){
			if(i != 0){
				updateSql += ",";
			}
			updateSql += fields[i] + "=";

			updateSql += Util.toSqlVal(values[i]);
		}
		
		if(id != null){
			updateSql += " where id =" + Util.toSqlVal(id);
		}
		
		return updateSql;
	}
	/**
     * Description :增加设备状态信息．
     * @param  :DetectorData
     * @return :String
     */
	public String insert_detectorchange(DetectorConfigData data){
		String insertSql ="";
		
		insertSql = "insert into p_equipmentchange(id,equipmentId,occurrenceTime,paramName,paramValue)";
		insertSql +=" values("+Util.toSqlVal(data.getEquipmentChangeId())+","+Util.toSqlVal(data.getId())+","+Util.toSqlVal(DateUtil.getCurDateTime())+",'denable',"+ Util.toSqlVal(data.getEnable())+")";
		
		return insertSql;
	}
	/**
     * Description :批量增加设备状态信息．
     * @param  :DetectorData
     * @return :String
     */
	public String insert_alldetectorchange(String id, String equipmentChangeId, String occurrenceTime, String paramName ,String paramValue){
		String insertSql ="";
		
		insertSql = "insert into p_equipmentchange(id,equipmentId,occurrenceTime,paramName,paramValue)";
		insertSql +=" values("+Util.toSqlVal(id)+","+Util.toSqlVal(equipmentChangeId)+","+Util.toSqlVal(occurrenceTime)+","+Util.toSqlVal(paramName)+","+ Util.toSqlVal(paramValue)+")";
		
		return insertSql;
	}	
	/**
     * Description :删除探测器信息．
     * @param  :DetectorData
     * @return :String
     */
	public String detector_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_detector where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	/**
     * Description :获取地图列表
     * @param  :
     * @return :String
     */
	public String get_mapCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_map order by id";
		
		return querySql;
	}
	
	/**
     * Description :获取地图路径
     * @param  :map_id
     * @return :String
     * @author LLX
     */
	public String get_map_src(String map_id) {
		String querySql = "";
		
		querySql += "select path from p_map where id=" + map_id;
		
		return querySql;
	}
	
	/**
     * Description :获取地图名
     * @param  :mapName
     * @return :String
     * @author LLX
     */
	public String get_mapName(String map_id) {
		String querySql = "";
		
		querySql += "select name from p_map where id=" + map_id;
		
		return querySql;
	}
	
	/**
     * Description :获取探测器类型列表
     * @param  :
     * @return :String
     */
	public String get_detectorType(String lang) {
		String querySql = "";
		querySql += "select id as code_id,sls.code_value as code_name from p_detectortype pdt left join sys_lang_switch sls on pdt.code = sls.code_key where sls.code_type = 'detector_type' and sls.lang = '"+lang+"' order by id";
		
		return querySql;
	}
	
	/**
     * Description :获取管理器地址列表
     * @param  :
     * @return :String
     */
	public String get_controllerAddr() {
		String querySql = "";
		
		querySql += "select id as code_id,addr as code_name from p_controller order by id";
		
		return querySql;
	}
	
	/**
     * Description :获取引导区域列表
     * @param  :
     * @return :String
     */
	public String get_guideRegion() {
		String querySql = "";
		
		querySql += "select id as code_id,code as code_name from p_guideregion order by id";
		
		return querySql;
	}
	
	/**
     * Description :获得是否开启．
     * @param  :
     * @return :String
     */
	public String get_enableCode() {
		String querySql = "";
		
		querySql += "select code_key as code_id,code_value as code_name,lang from sys_lang_switch where code_type='yes_or_no_enable' order by code_key";
		
		return querySql;
	}	
	
	/**
     * Description :获得全部探测器信息．
     * @param  :DetectorData
     * @return :String
     */
	public String get_alldetector() {
		String querySql = "";

		querySql = "select id from p_detector";
		
		return querySql;
	}
	/**
	 * 删除探测器时，更新p_map表的parkingNum字段
	 * @param mapId
	 * @return
	 */
	public String modifyMapNum(String mapId){
		String querySql = "";
		querySql = "update p_map as pm set pm.parkingSum = ( select count(*) from p_detector as pd where pd.mapId = '"+mapId+"' ) where pm.id = '"+mapId+"'";
		return querySql;
	}
}
