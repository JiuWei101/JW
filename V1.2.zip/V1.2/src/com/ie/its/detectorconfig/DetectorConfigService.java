/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-探测器配置
 * Version                  : 1.0
 * create date              : 2012.2.25
 * author                   : heliang
 */
package com.ie.its.detectorconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DateUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendService;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageSql;
import com.ie.its.mapmanage.ParkingSpaceData;
import com.ie.its.screenconfig.ScreenData;
import com.ie.its.user.UserData;
@Scope("prototype")
@Service
public class DetectorConfigService extends ExtendService {
	private DetectorConfigSql detectorSql;
	private MapManageSql mapSql;
	public DetectorConfigService(){
		detectorSql = new DetectorConfigSql();
		mapSql = new MapManageSql();
	}

	/**
     * Description :查询探测器．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_list(DetectorConfigData data,String lang) {
		//获得数量
		int count = this.getJt().queryForInt(detectorSql.detector_list(data, "count",lang));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//Log.log("----"+detectorSql.detector_list(data, "",lang));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <DetectorConfigData>rows = this.getJt().<DetectorConfigData>queryForListExt(detectorSql.detector_list(data, "",lang), 
				data.getStart(), data.getLimit(),DetectorConfigData.class);
		
		//转换编码
		for(DetectorConfigData tempData:rows){
			
			tempData.setStatus(DisposalCode.getCodeName(tempData.getStatus(), "ctrl_status", this.getUserinfo().getLang()));
			tempData.setEnable(DisposalCode.getCodeName(tempData.getEnable(), "enable", this.getUserinfo().getLang()));
			tempData.setDetectorType((String) ((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(tempData.getDetectorType()));
			tempData.setDetectorModel((String) ((HashMap)data.getCurrent_lang_switch().get("detector_model")).get(tempData.getDetectorModel()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得探测器信息．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_get(DetectorConfigData data, String lang) {
		//ses
		data = getJt().queryForObjectExt(detectorSql.detector_get(data, lang), data);
		return data;
	}
	
	/**
     * Description :更新探测器．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_update(DetectorConfigData data) {
		getJt().execute(detectorSql.detector_update(data));
		//2012-3-15 增加设备状态信息记录
		data.setEquipmentChangeId(PrimaryId.getId());
		getJt().execute(detectorSql.insert_detectorchange(data));
		return data;
	}
	
	/**
     * Description :更新地图．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_map_update(DetectorConfigData data) {
		getJt().execute(detectorSql.map_update(data));
		return data;
	}
	
	/**
	 * Description : 检查上传的文件名是否重复
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public boolean map_impcheck(DetectorConfigData data) {
		boolean flag = true;
		int count = this.getJt().queryForInt(detectorSql.map_impcheck(data));
		if (count > 0) {
			flag = false;
		}
		return flag;
	}
	/**
     * Description :批量更新探测器高度和状态．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_allupdate(DetectorConfigData data) {
		String[] sql = null;
		String[] fields = data.getField().split(",");
		String[] values = new String[fields.length];
		String[] id= data.getId().split(";");
		String paraValue = "";
		boolean enableUp = false; 
		
		for(int i = 0; i < fields.length; i++){
			if("mapId".equals(fields[i].trim())){
				values[i] = data.getMapId();
			} else if("enable".equals(fields[i].trim())){
				values[i] = data.getEnable();
			}
		}
		
		if(data.getId() == null || data.getId().equals("")){
			//如果id为空则表示更新全部
			sql = new String[1];
			sql[0] = detectorSql.detector_allupdate(null,fields,values);
	
		} else {
			//否则是更新部分
			sql = new String[id.length];
			for(int i = 0;i < id.length;i++){
				sql[i] = detectorSql.detector_allupdate(id[i],fields,values);
			}

		}
		getJt().batchUpdate(sql);
		
		//2012-3-15 增加设备状态记录
		//判断是否需要更新enable
		for(int i = 0; i < fields.length; i++){
			if("enable".equals(fields[i].trim())){
				enableUp = true;
				paraValue = values[i];
				break;
			}
		}
		if(enableUp){
			//如果有enable字段的更新则向设备状态信息表添加记录
			String occurrenceTime = DateUtil.getCurDateTime();
			String equipmentChangeId = "";
			
			if(data.getId() == null || data.getId().equals("")){
				//如果id为空则表示更新全部
				//获得数量
				sql = null;
				List equiIdList = new ArrayList<DetectorConfigData>();
				
				equiIdList = getJt().queryForListExt(detectorSql.get_alldetector(), DetectorConfigData.class);
				sql = new String[equiIdList.size()];

				//设置多语言
				
				for(int i = 0;i < equiIdList.size();i++){
					equipmentChangeId = PrimaryId.getId();
					DetectorConfigData tmplist = (DetectorConfigData)equiIdList.get(i);
					sql[i] = detectorSql.insert_alldetectorchange(equipmentChangeId, tmplist.getId(), occurrenceTime, "denable", paraValue);
				}
				
			}else{
				//否则是更新部分
				sql = null;
				sql = new String[id.length];
				
				for(int i = 0;i < id.length;i++){
					equipmentChangeId = PrimaryId.getId();
					sql[i] = detectorSql.insert_alldetectorchange(equipmentChangeId, id[i], occurrenceTime, "denable", paraValue);
				}
			}
			
			getJt().batchUpdate(sql);
		}
		
		return data;
	}
	/**
     * Description :删除探测器．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public DetectorConfigData detector_delete(DetectorConfigData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = detectorSql.detector_delete(id[i]);
		}
		getJt().batchUpdate(sql);
		
		if(!data.getMapId().isEmpty()){
			String[] mapId = data.getMapId().split(";");
			String[] mapSql = new String[id.length];
			for(int i=0; i<mapId.length; i++){
				mapSql[i] = detectorSql.modifyMapNum(mapId[i]);
			}
			getJt().batchUpdate(mapSql);
		}
		return data;
	}
	/**
     * Description :获得地图列表list
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_mapCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(detectorSql.get_mapCode(), DetectorConfigData.class);
		return codeList;
	}	
	
	@SuppressWarnings("rawtypes")
	public String get_map_src(String map_id) {//根据mapId获得地图路径
		String map_src=  getJt().queryForObject(detectorSql.get_map_src(map_id), String.class);
		return map_src;
	}	
	
	@SuppressWarnings("rawtypes")
	public String get_mapName(String map_id) {//根据mapId获得地图名
		String mapName=  getJt().queryForObject(detectorSql.get_mapName(map_id), String.class);
		return mapName;
	}	
	/**
     * Description :获得探测器类型list
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_detectorType(String lang) {
		List codeList = new ArrayList();
		codeList = getJt().queryForListExt(detectorSql.get_detectorType(lang), DetectorConfigData.class);
		return codeList;
	}	
	/**
     * Description :获得管理器地址list
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_controllerAddr() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(detectorSql.get_controllerAddr(), DetectorConfigData.class);
		return codeList;
	}	
	/**
     * Description :获得引导区域list
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_guideRegion() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(detectorSql.get_guideRegion(), DetectorConfigData.class);
		return codeList;
	}
	/**
     * Description :获得是否开启list．
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_enableCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(detectorSql.get_enableCode(), DetectorConfigData.class);
		return codeList;
	}		
	
	/**
	 * Description :导入地图数据．新增探头&引导屏
	 * @author LLX 20120903.    20120913增加新增引导屏功能
	 * @param :MapManageData
	 * @return :String
	 * @throws :Exception
	 */
	@SuppressWarnings("unchecked")
	public MapManageData detector_insert(HttpServletResponse response,HttpServletRequest request,MapManageData data, String lang)
			throws Exception {
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("dadd_mess");
		String argsCheck[]; // 存放新增的探测器id
		String argsScCheck[]; // 存放新增的引导屏id
		//String args[]; // 前台数据用,分割
		@SuppressWarnings("rawtypes")
		HashMap condMap = new HashMap();
		Set<String> conIdSet = new HashSet<String>();
		boolean flag = true;//验证探测器数据，如果信息无误则置为true 才执行插入语句
		List<String> sqlDeDetected = new ArrayList<String>();	//超声波探测器插入的sql语句List
		List<String> sqlParkingSpace = new ArrayList<String>(); // 插入车位的sql语句List
		List<String> sqlCon = new ArrayList<String>();			//插入管理器的sql语句List
		List<String> deList = new ArrayList<String>();//存放有问题的探测器列表
		List<String> deExistList = new ArrayList<String>();//存放已存在的探测器列表
		List<String> args = new ArrayList<String>();//存放新增的探测器列表
		List<String> argsSc = new ArrayList<String>();//存放新增的引导屏列表
		List<String> sqlScreen = new ArrayList<String>();	//屏信息插入的sql语句List
		List<String> screenList = new ArrayList<String>();//存放有问题的引导屏列表
		List<String> screenExistList = new ArrayList<String>();//存放已存在的引导屏列表
		// 首先处理探测器数据de//TODO
		if(data.getImp_data_de().equals("null")){
			argsCheck = null;			
		}else{
			argsCheck = data.getImp_data_de().split(",");// 前台数据用,分割
		//先剔除已存在数据库的探测器编号
		
		for (int i = 0; i< argsCheck.length ; i++){
			if(!isExit(argsCheck[i])){
				args.add(argsCheck[i]);
			}
		}
		
		// 解析参数
		for (int i = 0; i < args.size(); i++) {
			String con_id = ""; // 管理器id
			// 之所以除以2 是因为字符是由[管理器探测器]组成的 其中每个单元的长度可能变化 但是长度一致 所以先除以二再获取字符
			int len = args.get(i).length() / 2;
			con_id = args.get(i).substring(0, len);
			// 用set控制重复的管理器id
			conIdSet.add(con_id);
		}
		
		// 遍历管理器set 组成管理器插入语句
		for (Iterator<String> iter = conIdSet.iterator(); iter.hasNext();) {
			String con_id = iter.next();
			ControllerData controllerData = new ControllerData();
			controllerData.setId(PrimaryId.getId());
			controllerData.setAddr(con_id); // 管理器id
			controllerData.setMapId(data.getId()); // 地图id
			controllerData.setStatus("0"); // 状态默认为0
			/*
			 * edit by wenzr,2012.7.22 18:05
			 * 根据小莫的意见，厦门项目中，多个地图可能共用同一个管理器,如A:005;B:005 处理意见：
			 * 传入地图编号一起检查管理编号是否重复，如果管理器id重复但地图id不同，则取原来的序列号，地图号也用原来的？？？
			 */
			// 键值 key:控制器地址 value:控制器id
			// condMap.put(controllerData.getAddr(),
			// controllerData.getId());//该代码有问题，导致管理器ID丢失。by wenzr
			condMap.put(controllerData.getAddr(),
					getControllerSeqId(controllerData.getId(),controllerData.getAddr()));
			if (!isExitCon(controllerData.getAddr())) {
				sqlCon.add(mapSql.save_con(controllerData));
			}
		}
		
		// 解析参数
		for (int i = 0; i < args.size(); i++){
			if (args.get(i).length() != 6){//探测器地址长度为6位
				deList.add(args.get(i));
				flag=false;
			}else{
			String detected_id = "", con_id = ""; // 探测器id 管理器id
			DetectorConfigData detectorConfigData = new DetectorConfigData();
			ParkingSpaceData parkingSpaceData = new ParkingSpaceData();
			// 之所以除以2 是因为字符是由[管理器探测器]组成的 其中每个单元的长度可能变化 但是长度一致 所以先除以二再获取字符
			int len = args.get(i).length() / 2;
			con_id = args.get(i).substring(0, len);
			detected_id = args.get(i).substring(len, args.get(i).length());

			// 用set控制重复的管理器id
			conIdSet.add(con_id);
			// 探测器开始
			detectorConfigData.setId(PrimaryId.getId()); // 探测器id 现在用生成主键
			detectorConfigData.setMapId(data.getId()); // 地图id
			detectorConfigData.setControllerId(condMap.get(con_id).toString()); // 管理器id
			detectorConfigData.setAddr(detected_id); // 暂时存探测器id
			detectorConfigData.setDetectorTypeId("1"); // 默认写1代表超声波探测器
			// 而且flash无返回
			detectorConfigData.setCode(args.get(i)); // [管理器探测器]
			detectorConfigData.setStatus("1"); // 状态默认1
			detectorConfigData.setEnable("1"); // 默认1 启用
				if (!isExit(detectorConfigData.getCode())) {
					sqlDeDetected.add(mapSql.save_detector(detectorConfigData));
					parkingSpaceData.setId(PrimaryId.getId()); // 车位id
					parkingSpaceData.setDetectorId(detectorConfigData.getId()); // 探测器id
					parkingSpaceData.setCode(args.get(i)); // code
					parkingSpaceData.setPhysicalRegionId(data.getPhysicalRegionId());// 物理区域id
					sqlParkingSpace.add(mapSql.save_parkingSpace(parkingSpaceData));
				}else{//已存在的探测器地址
					deExistList.add(args.get(i));
					flag=false;
				}
			}
		}
	}
		// 再处理引导屏信息
		if(data.getImp_data_sc().equals("null")){
			argsScCheck = null;
		}else{
			argsScCheck = data.getImp_data_sc().split(",");// 前台数据用,分割
			//先剔除已存在数据库的引导屏编号
			
			for (int i = 0; i< argsScCheck.length ; i++){
				if(!isExitSc(argsScCheck[i])){
					argsSc.add(argsScCheck[i]);
				}
			}
			
			for (int i = 0; i < argsSc.size(); i++) {
				if (argsSc.get(i).length() != 6 || !argsSc.get(i).startsWith("P")){//不以大写"P"开头或者长度不为6位，报错 edit ByLLX 120806
					screenList.add(argsSc.get(i));
					flag = false;
				}else{
					ScreenData screenData = new ScreenData();
					// 屏编号组成 字母+3位组地址+2位屏地址
					screenData.setId(PrimaryId.getId()); // 引导屏id
					screenData.setMapId(data.getId()); // 引导屏地图id
					screenData.setCode(argsSc.get(i)); // code
					screenData.setGrpAddr(argsSc.get(i).substring(1, 4)); // 3位组地址
					screenData.setAddr(argsSc.get(i).substring(4, 6)); // 2位屏地址
					screenData.setStatus("1"); // 状态默认1
					if (!isExitSc(screenData.getCode())) {//判断code是否重复
						sqlScreen.add(mapSql.save_screen(screenData));
					}else{
						screenExistList.add(argsSc.get(i));
						flag = false;
					}
				}
			}
			
		}
	
		if(flag){
			
			//由于外键关系 先执行管理器插入 再插入探测器
			if(sqlCon.size()>0){
				for(int i = 0; i < sqlCon.size(); i++){
					getJt().update(sqlCon.get(i));
				}
			}
			if(sqlDeDetected.size() > 0){//超声波探测器插入sql
				for(int i = 0; i < sqlDeDetected.size(); i++){
						getJt().update(sqlDeDetected.get(i));
				}
			}
			if(sqlParkingSpace.size() > 0){//车位插入sql
				for(int i = 0; i < sqlParkingSpace.size(); i++){
						getJt().update(sqlParkingSpace.get(i));
				}
			}
			if(sqlScreen.size() > 0){//屏信息插入sql
				for(int i = 0; i < sqlScreen.size(); i++){
						getJt().update(sqlScreen.get(i));
				}
			}
			// 更新车位导入数量
			int parkingSum=this.getJt().queryForInt(mapSql.getParkingSum(data));
			data.setParkingSum(sqlParkingSpace.size()+parkingSum);
			// 更新屏导入数量
			int screenSum=this.getJt().queryForInt(mapSql.getScreenSum(data));
			data.setScreenSum(sqlScreen.size()+screenSum);
			// 更新导入数量
			getJt().execute(mapSql.update_impCount(data));
			// 将地图是否字段 置为1
			getJt().execute(mapSql.updateMap(data));
			
			//新增成功列表 返回前台
			String alertStr = "";
			if(args.size()>0){
				for(int i = 0; i < args.size(); i++){
					if(i != args.size()-1){
						alertStr += args.get(i) + ",";
					}else{
						alertStr += args.get(i);
					}
				}
				alertStr += (String)map.get("d_add") +args.size()+ (String)map.get("d_record");
			}
			if(argsSc.size()>0){
				for(int i = 0; i < argsSc.size(); i++){
					if(i != argsSc.size()-1){
						alertStr += argsSc.get(i) + ",";
					}else{
						alertStr += argsSc.get(i);
					}
				}
				alertStr += (String)map.get("s_add") +args.size()+ (String)map.get("d_record");
			}
			data.setDetectorError(alertStr);//增加成功 alert弹出导入的元件编号
		}else{//flag为false 说明地图文件有问题 抛出异常
			String exceptionStr = "";
			if(deList.size() > 0){
				for(int i = 0; i < deList.size(); i++){
					if(i != deList.size()){
						exceptionStr += deList.get(i) + ",";
					}else{
						exceptionStr += deList.get(i);
					}
				}
				exceptionStr += (String)map.get("d_error");
			}
			
			String exceptionStr2 = "";
			if(deExistList.size() > 0){
				for(int i = 0; i < deExistList.size(); i++){
					if(i != deExistList.size()){
						exceptionStr2 += deExistList.get(i) + ",";
					}else{
						exceptionStr2 += deExistList.get(i);
					}
				}
				exceptionStr2 += (String)map.get("d_exists");
			}
			
			String exceptionStr3 = "";
			if(screenList.size() > 0){
				for(int i = 0; i < screenList.size(); i++){
					if(i != screenList.size()){
						exceptionStr3 += screenList.get(i) + ",";
					}else{
						exceptionStr3 += screenList.get(i);
					}
				}
				exceptionStr3 += (String)map.get("s_perror");
			}
			
			String exceptionStr4 = "";
			if(screenExistList.size() > 0){
				for(int i = 0; i < screenExistList.size(); i++){
					if(i != screenExistList.size()){
						exceptionStr4 += screenExistList.get(i) + ",";
					}else{
						exceptionStr4 += screenExistList.get(i);
					}
				}
				exceptionStr4 += (String)map.get("s_exists");
			}
			throw new Exception(exceptionStr + exceptionStr2 + exceptionStr3 + exceptionStr4);

		}
		return data;
	}
	
	/**
	 * add by wenzr 2012.7.22
	 * 
	 * @param 传入管理器编号
	 * @return 管理对应的序列号
	 */
	private String getControllerSeqId(String id,String addr) {
		JSONArray jsonArray = getJt().queryForJSONArrayExt(
				mapSql.getConSeqId(addr));
		if (jsonArray.size() == 0) {// 不存在，产生新的序列号
			return id;
		} else {// 存在，返回上一地图的序列号
			JSONObject json = jsonArray.getJSONObject(0);
			return json.get("id").toString();
		}
	}
	
	/**
	 * 管理器
	 * @param addr
	 * @return
	 */
	private boolean isExitCon(String addr) {
		int queryForInt = getJt().queryForInt(mapSql.is_exit_con(addr));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}
	private boolean isExit(String code) throws Exception {
		int queryForInt = getJt().queryForInt(mapSql.is_exit_detector(code));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}
	private boolean isExitSc(String code) throws Exception {
		int queryForInt = getJt().queryForInt(mapSql.is_exit_screen(code));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}
}
