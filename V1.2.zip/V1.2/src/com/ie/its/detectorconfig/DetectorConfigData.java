/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-传感器配置
 * Version                  : 1.0
 * create date              : 2012.2.25
 * author                   : heliang
 */
package com.ie.its.detectorconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class DetectorConfigData extends ExtendData{
	

	private String id;					//探测器id
	private String mapId;				//地图id
	private String mapName;				//物理区域名称
	private String controllerId;		//管理器id
	private String controllerAddr;		//管理器地址
	private String controllerAddrId;	//管理器地址
	private String guideRegionId;		//引导区域id
	private String guideRegionCode;		//引导区域编码
	private String detectorTypeId;		//探测器类型id
	private String equipmentChangeId;	//设备状态信息id
	private String statusId;			//状态id
	private String enable;				//是否开启
	private String detectorType;		//探测器类型
	private String addr;				//地址
	private String detectorCode;		//探测器编码
	private String code;				//编码
	private String status;				//状态
	private List mapList;				//地图列表
	private List detectorTypeList;		//探测器类型列表
	private List controllerAddrList;	//管理器地址列表
	private List guideRegionList;		//引导区域列表
	private List enableList;			//是否开启下拉框
	private List statusList;			//状态列表
	private String field;				//字段名
	private String mapSrc;				//地图路径
	private String path;				//文件上传路径
	private String fileName;			//文件名
	private String imp_data_de;			//导入数据探测器
	private String imp_data_sc;			//导入数据引导屏
	private int parkingSum;          //车位数
 	private String notes;			//车位p_parkingspace的备注字段，用于判断超声波错误
 	
 	private double x_axis;			//车位x轴坐标
 	private double y_axis;			//车位y轴坐标
 	private String onepoint_id;		//车位可达边A端点ID
 	private String anopoint_id;		//车位可达边B端点ID
 	private double vertical_x_axis;	//可达边垂直点X坐标值
 	private double vertical_y_axis;	//可达边垂直点Y坐标值
 	
 	private String detectorModel;	//探测器模式（0为正常模式，1为异常模式）
 	private List detectorModelList;

 	private String parkingSpaceCode;	//车位编码
 	
	public String getParkingSpaceCode() {
		return parkingSpaceCode;
	}
	public void setParkingSpaceCode(String parkingSpaceCode) {
		this.parkingSpaceCode = parkingSpaceCode;
	}
	public double getX_axis() {
		return x_axis;
	}
	public void setX_axis(double x_axis) {
		this.x_axis = x_axis;
	}
	public double getY_axis() {
		return y_axis;
	}
	public void setY_axis(double y_axis) {
		this.y_axis = y_axis;
	}
	public String getOnepoint_id() {
		return onepoint_id;
	}
	public void setOnepoint_id(String onepoint_id) {
		this.onepoint_id = onepoint_id;
	}
	public String getAnopoint_id() {
		return anopoint_id;
	}
	public void setAnopoint_id(String anopoint_id) {
		this.anopoint_id = anopoint_id;
	}
	public double getVertical_x_axis() {
		return vertical_x_axis;
	}
	public void setVertical_x_axis(double vertical_x_axis) {
		this.vertical_x_axis = vertical_x_axis;
	}
	public double getVertical_y_axis() {
		return vertical_y_axis;
	}
	public void setVertical_y_axis(double vertical_y_axis) {
		this.vertical_y_axis = vertical_y_axis;
	}
		public String getDetectorModel() {
		return detectorModel;
	}
	public void setDetectorModel(String detectorModel) {
		this.detectorModel = detectorModel;
	}
	public List getDetectorModelList() {
		return detectorModelList;
	}
	public void setDetectorModelList(List detectorModelList) {
		this.detectorModelList = detectorModelList;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getDetectorType() {
		return detectorType;
	}
	public void setDetectorType(String detectorType) {
		this.detectorType = detectorType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getMapName() {
		return mapName;
	}
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	public String getControllerId() {
		return controllerId;
	}
	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}
	public String getControllerAddr() {
		return controllerAddr;
	}
	public void setControllerAddr(String controllerAddr) {
		this.controllerAddr = controllerAddr;
	}
	public String getControllerAddrId() {
		return controllerAddrId;
	}
	public void setControllerAddrId(String controllerAddrId) {
		this.controllerAddrId = controllerAddrId;
	}
	public String getGuideRegionId() {
		return guideRegionId;
	}
	public void setGuideRegionId(String guideRegionId) {
		this.guideRegionId = guideRegionId;
	}
	public String getGuideRegionCode() {
		return guideRegionCode;
	}
	public void setGuideRegionCode(String guideRegionCode) {
		this.guideRegionCode = guideRegionCode;
	}
	public String getDetectorTypeId() {
		return detectorTypeId;
	}
	public void setDetectorTypeId(String detectorTypeId) {
		this.detectorTypeId = detectorTypeId;
	}
	public String getEquipmentChangeId() {
		return equipmentChangeId;
	}
	public void setEquipmentChangeId(String equipmentChangeId) {
		this.equipmentChangeId = equipmentChangeId;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getDetectorCode() {
		return detectorCode;
	}
	public void setDetectorCode(String detectorCode) {
		this.detectorCode = detectorCode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusId() {
		return statusId;
	}
	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}
	public String getEnable() {
		return enable;
	}
	public void setEnable(String enable) {
		this.enable = enable;
	}
	public List getMapList() {
		return mapList;
	}
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	public List getDetectorTypeList() {
		return detectorTypeList;
	}
	public void setDetectorTypeList(List detectorTypeList) {
		this.detectorTypeList = detectorTypeList;
	}
	public List getControllerAddrList() {
		return controllerAddrList;
	}
	public void setControllerAddrList(List controllerAddrList) {
		this.controllerAddrList = controllerAddrList;
	}	
	public List getGuideRegionList() {
		return guideRegionList;
	}
	public void setGuideRegionList(List guideRegionList) {
		this.guideRegionList = guideRegionList;
	}
	public List getEnableList() {
		return enableList;
	}
	public void setEnableList(List enableList) {
		this.enableList = enableList;
	}
	public List getStatusList() {
		return statusList;
	}
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getMapSrc() {
		return mapSrc;
	}
	public void setMapSrc(String mapSrc) {
		this.mapSrc = mapSrc;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getImp_data_de() {
		return imp_data_de;
	}
	public void setImp_data_de(String imp_data_de) {
		this.imp_data_de = imp_data_de;
	}
	public String getImp_data_sc() {
		return imp_data_sc;
	}
	public void setImp_data_sc(String imp_data_sc) {
		this.imp_data_sc = imp_data_sc;
	}
	public int getParkingSum() {
		return parkingSum;
	}
	public void setParkingSum(int parkingSum) {
		this.parkingSum = parkingSum;
	}


	
}
