/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.25
 * author                   : heliang
 */
package com.ie.its.detectorconfig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.mapmanage.MapManageAction;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageService;

//命名空间
@Namespace("/detector_config")
@Results({@Result(name="list",location="/detector_config/detector_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="detector_list",location="list.action",type="redirect")})
public class DetectorConfigAction extends ExtendActionSupport {
	
	private DetectorConfigData data;
	@Autowired
	private DetectorConfigService detectorService;

	private File myFile;  
    private String myFileFileName;  
    private String myFileFileContentType;
  
	public File getMyFile() {
		return myFile;
	}
	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}
	public String getMyFileFileName() {
		return myFileFileName;
	}
	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}
	public String getMyFileFileContentType() {
		return myFileFileContentType;
	}
	public void setMyFileFileContentType(String myFileFileContentType) {
		this.myFileFileContentType = myFileFileContentType;
	}
	
	public DetectorConfigService getDetectorService() {
		return detectorService;
	}
	public void setDetectorService(DetectorConfigService detectorService) {
		this.detectorService = detectorService;
	}
	public DetectorConfigData getData() {
		return data;
	}
	public void setData(DetectorConfigData data) {
		this.data = data;
	}
	public DetectorConfigAction(){
		if(data == null){
			data = new DetectorConfigData();
		}
	}
	/**
     * Description :查询传感器．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="detector_list",results={@Result(name="success",location="/detector_config/detector_list.jsp")})
	public String detector_list(){
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		data = detectorService.detector_list(data,request.getSession().getAttribute("lang").toString());
		//获得地图，是否开启下拉框
		data.setMapList(detectorService.get_mapCode());
		//获得探测器类型
		data.setDetectorTypeList(detectorService.get_detectorType(request.getSession().getAttribute("lang").toString()));
		//获得管理器地址
		data.setControllerAddrList(detectorService.get_controllerAddr());
		//获得引导区域
		data.setGuideRegionList(detectorService.get_guideRegion());
		//获得状态拉框
		data.setStatusList(Util.getCodeList(data, "ctrl_status")); 
		//获得启用拉框
		data.setEnableList(Util.getCodeList(data, "enable"));
		//探测器模式下拉框
		data.setDetectorModelList(Util.getCodeList(data, "detector_model"));
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="detector_create",results={@Result(name="create",location="/detector_config/detector_create.jsp")})
	public String detector_create(){
		data.setId("");
		//设置多语言
		setLang(data);
		//获得物理区域下拉框
		data.setMapList(detectorService.get_mapCode());
		return ConstantClass.ACTION_CREATE;
	}
	
	//导入探头方法
	@Action(value="detector_import",results={@Result(name="import",location="/detector_config/detector_add.jsp")})
	public String detector_import(){
		String map_id = request.getParameter("map_id");
		data.setMapId(map_id);
		String path = detectorService.get_map_src(map_id);
		if(!path.equals("")){
			path = splitMapSrc(path);
		}
		data.setMapSrc(path);
		//设置多语言
		setLang(data);
		data.setMapName(detectorService.get_mapName(map_id));
		return "import";
	}
	
	/**获取地图路径 预览
     * Description :
     * @throws :Exception
     * @author LLX
     */
	@Action(value="map_show",results={@Result(name="show",location="/detector_config/detector_create.jsp")})
	public String map_show(){
		String map_id = request.getParameter("map_id");
		data.setMapId(map_id);
		String path = detectorService.get_map_src(map_id);
		if(!path.equals("")){
			path = splitMapSrc(path);
		}
		data.setMapSrc(path);
		//设置多语言
		setLang(data);
		data.setMapList(detectorService.get_mapCode());
		return "show";
	}
	
	private String splitMapSrc(String path) {//变绝对路径为相对路径
		String src = "";
		String path_split[] = path.split(ConstantClass.MAP_DIR);
		src = "../" + ConstantClass.MAP_DIR + path_split[1];
		// src = src.replaceAll("\\", "/");
		return src;
	}
	
	@Action(value="detector_edit",results={@Result(name="edit",location="/detector_config/detector_edit.jsp")})
	public String detector_edit(){
		String lang = request.getSession().getAttribute("lang").toString();
		detectorService.detector_get(data, lang);
		//设置多语言
		setLang(data);
		//获得是否开启下拉框
		data.setDetectorType((String) ((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(data.getDetectorType()));
		data.setEnableList(DisposalCode.getCode("detector_enable",request.getSession().getAttribute("lang").toString()));
		data.setDetectorModel((String) ((HashMap)data.getCurrent_lang_switch().get("detector_model")).get(data.getDetectorModel()));
		return ConstantClass.ACTION_EDIT;
	}
	
	//更新导入地图
	@Action(value="detector_add",results={@Result(type="json")})
	public void map_update(){
		JSONObject json =  new JSONObject();
		//保存的文件路径
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
		Log.log(data.getPath());
		data.setFileName(this.getMyFileFileName());
		//检查是否有重复文件 如果有 则返回错误
		if(detectorService.map_impcheck(data)){
			try{
				handleUploadFile(data);
				detectorService.detector_map_update(data);
			}catch(Exception e){
				//如果出现异常 则删除文件
				File file = new File(data.getPath());
				file.deleteOnExit();
				throw new ExtendUnCheckException(e);
			}
			json.element("success", true);
		}else{
			json.element("success", false);
			json.element("message", "file exist");
		}
		setJsonRes(json);
	}
	
	/**
     * Description :处理文件上传方法．
     * @param  :MapManageData
     * @throws :Exception
     */
	public void handleUploadFile(DetectorConfigData data)throws IOException{
		File newFile = new File(data.getPath()+this.getMyFileFileName());
		if(!new File(data.getPath()).isDirectory()){
            new File(data.getPath()).mkdirs();
        }
		if(!newFile.exists()){
			newFile.createNewFile();
		}
		
		FileInputStream inputStream = new FileInputStream(this.getMyFile());  
        FileOutputStream outputStream = new FileOutputStream(newFile);  
        byte[] buf = new byte[1024];  
        int length = 0;  
        while ((length = inputStream.read(buf)) != -1) {  
            outputStream.write(buf, 0, length);  
        }  
        inputStream.close();  
        outputStream.flush(); 
        outputStream.close();
	}
	
	@Action(value="detector_update",results={@Result(type="json")})
	public void detector_update(){		
		detectorService.detector_update(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}

	@Action(value="detector_alledit",results={@Result(name="alledit",location="/detector_config/detector_alledit.jsp")})
	public String detector_alledit(){
		
		//设置多语言
		setLang(data);

		//获得地图，是否开启下拉框
		data.setMapList(detectorService.get_mapCode());
		data.setEnableList(DisposalCode.getCode("detector_enable",request.getSession().getAttribute("lang").toString()));

		return "alledit";
	}	
	
	@Action(value="detector_allupdate",results={@Result(type="json")})
	public void detector_allupdate(){		
		detectorService.detector_allupdate(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}
	
	@Action(value="detector_delete",results={@Result(type="json")})
	public void detector_delete(){		
		System.out.println(data.getId());
		detectorService.detector_delete(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}
	
	/**
     * Description :导入flash数据页面．新增探头
     * @throws :Exception
     */
	@Action(value="detector_insert",results={@Result(type="json")})
	public void map_savedata(){
		String tmp = data.getImp_data_de();
		String tmpSc = data.getImp_data_sc();
		String id = data.getMapId();
		
		MapManageData data = new MapManageData();
		JSONObject json =  new JSONObject();
		setLang(data);
		data.setImp_data_de(tmp);
		data.setImp_data_sc(tmpSc);
		data.setId(id);
		
		try{
			detectorService.detector_insert(response,request,data, request.getSession().getAttribute("lang").toString());
			
			if(request.getSession().getAttribute("register").equals("0")){
				json.element("message", true);
			}else{
				json.element("message", false);
			}
			json.element("success", true);
			json.element("result", data.getDetectorError());//alert新增列表
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		setJsonRes(json);
	}
	
}
