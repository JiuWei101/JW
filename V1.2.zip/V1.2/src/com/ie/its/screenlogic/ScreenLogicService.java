/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : heliang
 */
package com.ie.its.screenlogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.CodeData;
import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.guideregionmanage.GuideRegionManageData;
import com.ie.its.guideregionmanage.GuideRegionManageSql;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.screenlogic.ScreenLogicData;
import com.ie.its.mapmonitor.MapMonitorSql;

@Scope("prototype")
@Service
public class ScreenLogicService extends ExtendService {
	private ScreenLogicSql screenLogicSql;

	public ScreenLogicService(){
		screenLogicSql = new ScreenLogicSql();
	}

	/**
	 * 获取条屏方向上车位编码及引导区域编码组成的字符串
	 * @param jarr
	 * @param type
	 * @return
	 */
	private String getDetectorsStr(JSONArray jarr, String type){
		StringBuilder sb = new StringBuilder();
		for(int i=0,len=jarr.size(); i<len; i++)
		{
			String str = jarr.getJSONObject(i).getString("guideRegionCodeList").toString();

			String[] areaStr = str.split(",");//引导区域字符串数组
			for(int j=0;j<areaStr.length; j++)
			{
				JSONArray array = this.getJt().queryForJSONArrayExt(new MapMonitorSql().getDetector(areaStr[j]));
				for(int k = 0,nlen=array.size(); k < nlen; k++){
					if(type.equals("screenLogic")){
						sb.append(array.getJSONObject(k).getString("code")).append(",");
					}else{
						sb.append(array.getJSONObject(k).getString("code")).append(",").append(areaStr[j]).append(";");
					}
				}

			}
		}
		if(sb.length() > 0){
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	/**
	 * Description : 根据引导屏编号查找与其关联的探测器
	 * @param data ：屏逻辑对象
	 * @param type ：引导屏逻辑或地图监控
	 * @return ：探测器JSONObject
	 */
	public JSONObject getDetectors(String screenCode,String type,String direction){
		JSONArray darray = new JSONArray();
		JSONObject json = new JSONObject();
		String dataStr = "";
		try{
			darray = getJt().queryJson(screenLogicSql.getGuideAreaByScreen(screenCode,direction));//引导屏引导区域
			if(darray.size()>0)
			{
				dataStr = getDetectorsStr(darray, type);
			}
			else
			{
				darray = getJt().queryJson(screenLogicSql.getGuideAreaByScreen(screenCode,""));
				dataStr = getDetectorsStr(darray, type);
				json.element("mess", true);
			}
			json.element("success", true);
			json.element("dataStr", dataStr);
		}catch(Exception e){
			e.printStackTrace();
		}
		return json;
	}



	/**
	 * Description :查询引导区域．
	 * @param  :ScreenLogicData
	 * @return :ScreenLogicData
	 * @throws :Exception
	 */
	public ScreenLogicData list(ScreenLogicData data) {
		//获得数量
		int count = this.getJt().queryForInt(screenLogicSql.list(data, "count"));

		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);


		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenLogicData>rows = this.getJt().<ScreenLogicData>queryForListExt(screenLogicSql.list(data, ""), 
				data.getStart(), data.getLimit(),ScreenLogicData.class);

		//转换编码
		for(ScreenLogicData tempData:rows){
			System.out.println(tempData.getId());
		}

		data.setPer_data(rows);
		return data;
	}

	/**
	 * Description :获得引导区域信息．
	 * @param  :ScreenLogicData
	 * @return :ScreenLogicData
	 * @throws :Exception
	 */
	public ScreenLogicData guideregion_get(ScreenLogicData data) {
		getJt().queryForObjectExt(screenLogicSql.get_GuideRegion(data), data);

		Log.log(data.getGuideRegionId());
		return data;
	}

	/**
	 * Description :获得逻辑区域信息．
	 * @param  :ScreenLogicData
	 * @return :ScreenLogicData
	 * @throws :Exception
	 */
	public ScreenLogicData logicregion_get(ScreenLogicData data) {
		getJt().queryForObjectExt(screenLogicSql.get_LogicRegion(data), data);

		return data;
	}

	/**
	 * @param string
	 * @return
	 */
	public List getList(String type, ScreenLogicData data,String lang) {
		List list = new ArrayList();
		if("DetectorType".equals(type)){
			//探测器类型
			list = getJt().queryForListExt(screenLogicSql.getDetectorType(), CodeData.class);
		} else if("Controller".equals(type)){
			//探测器类型
			list = getJt().queryForListExt(screenLogicSql.getController(), CodeData.class);
		} else if("Direction".equals(type)){
			//指引方向
			String[] direction = {"←","↑","→","↓"};
			for(int i = 0; i < 4; i++){
				CodeData cd = new CodeData();
				cd.setCode_id(direction[i]);
				cd.setCode_name(direction[i]);
				list.add(cd);
			}
		} else if("DispColor".equals(type)){
			//显示颜色
			String[] color_code = {"\\R","\\Y","\\G"};
			String[] color_value = {"红色","黄色","绿色"};
			for(int i = 0; i < 3; i++){
				CodeData cd = new CodeData();
				cd.setCode_id(color_code[i]);
				cd.setCode_name(color_value[i]);
				list.add(cd);
			}
		} else if("Map".equals(type)){
			//地图
			list = getJt().queryForListExt(screenLogicSql.getMap(), MapManageData.class);
			for(int i = 0;i < list.size();i++){
				MapManageData temp = (MapManageData) list.get(i);
				temp.setPath(splitMapSrc(temp.getPath()));
			}
		} else if("ScreenType".equals(type)){
			//屏幕类型
			list = getJt().queryForListExt(screenLogicSql.getScreenType(), CodeData.class);
		} else if("SpotType".equals(type)){
			//车位配置类型(0临时 1固定 2预订)
			String[] color_code = {"0","1","2"};
			String a,b,c;
			Map map = (HashMap)data.getCurrent_lang_switch().get("parking_type");
			a = map.get("0").toString();
			b = map.get("1").toString();
			c = map.get("2").toString();
			String[] color_value = {a,b,c};
			for(int i = 0; i < 3; i++){

				CodeData cd = new CodeData();
				cd.setCode_id(color_code[i]);
				cd.setCode_name(color_value[i]);
				list.add(cd);
			}
		} else if("GuideRegionList".equals(type)){
			//引导区域列表
			list = getJt().queryForListExt(screenLogicSql.get_GuideRegion(data), GuideRegionManageData.class);
			for(int i = 0; i < list.size(); i++){
				GuideRegionManageData grmd = (GuideRegionManageData)list.get(i);
				grmd.setCode_name(grmd.getCode_name() + "(" + 
						((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(grmd.getRegionType()) + ")");
			}
		} else if("LogicList".equals(type)){
			//逻辑区域列表
			list = getJt().queryForListExt(screenLogicSql.get_LogicRegion(data), CodeData.class);
		}
		return list;
	}

	/**
	 * @param string
	 * @return
	 */
	public JSONArray getJsonArray(String type, ScreenLogicData data) {
		JSONArray list = new JSONArray();
		if("GuideRegionList".equals(type)){
			//引导区域列表
			list = getJt().queryForJSONArrayExt(screenLogicSql.get_GuideRegion(data));
			//替换编码
			for(int i = 0; i < list.size(); i++){
				JSONObject json = list.getJSONObject(i);
				json.put("code_name", json.get("code_name") + "(" + 
						((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(json.getString("regionType")) + ")");
			}
		} else if("LogicList".equals(type)){
			//逻辑区域列表
			list = getJt().queryForJSONArrayExt(screenLogicSql.get_LogicRegion(data));
		}
		return list;
	}
	public JSONArray getParentCode(ScreenLogicData data){
		JSONArray list = getJt().queryForJSONArrayExt(screenLogicSql.get_ParentNode(data));
		return list;
	}
	private String splitMapSrc(String path){
		String src = "";
		String[] path_split = path.split(ConstantClass.MAP_DIR);
		src = "../" + ConstantClass.MAP_DIR + (path_split.length > 1 ? path_split[1] : "");
		//src = src.replaceAll("\\", "/");
		return src;
	}

	/**
	 * @param data
	 */
	public void setDetector(ScreenLogicData data,String lang) {
		getJt().queryForObjectExt(screenLogicSql.get_Detector(data,lang), data);
	}

	/**
	 * @param data
	 */
	public void setScreen(ScreenLogicData data) {
		getJt().queryForObjectExt(screenLogicSql.get_Screen(data), data);
	}

	/**
	 * @param data
	 * @return 
	 */
	public ScreenLogicData update_detector(ScreenLogicData data) {

		String[] detectorCodes = data.getDetectorCode().split(",");
		if(detectorCodes.length > 1 && ("".equals(data.getId()) || data.getId() == null)){
			Log.log("detectorCodes.length > 1");
			String [] sql = new String[detectorCodes.length * 2 + 1];
			for(int i = 0; i < detectorCodes.length; i ++){
				if(Util.isCon(data.getGuideRegionId()))//更新探头引导区域
					sql[i * 2] = screenLogicSql.update_detector(data, detectorCodes[i]);
				if(Util.isCon(data.getCode()) || Util.isCon(data.getLogicId()))//更新车位逻辑区域
					sql[i * 2 + 1] = screenLogicSql.update_parkingspace(data, detectorCodes[i]);
			}
			if(Util.isCon(data.getGuideRegionId()))//更新引导区域类型
				sql[detectorCodes.length * 2] = screenLogicSql.update_guideRegion(data, detectorCodes[0]);

			getJt().batchUpdate(sql);
		} else {
			Log.log("detectorCodes.length = 1");
			String [] sql = new String[3];
			if(Util.isCon(data.getGuideRegionId()))
				sql[0] = screenLogicSql.update_detector(data, null);
			//车位信息
			if(Util.isCon(data.getParkingSpaceCode()) || Util.isCon(data.getLogicId()))
				sql[1] = screenLogicSql.update_parkingspace(data);
			if(Util.isCon(data.getGuideRegionId()))
				sql[2] = screenLogicSql.update_guideRegion(data, null);

			getJt().batchUpdate(sql);
		}
		return data;

	}

	/**
	 * @param data
	 * @return 
	 */
	public ScreenLogicData update_screen(ScreenLogicData data) {
		getJt().execute(screenLogicSql.update_screen(data));
		getJt().execute(screenLogicSql.delete_colortask(data));
		getJt().execute(screenLogicSql.delete_screenregion(data));
		String dispLen=data.getShowDispLen();
		Log.log("---dispLen-----"+dispLen);
		String cf = data.getContentFormat();
		Log.log(cf);
		try{
//			String[] arr = cf.split("\\\\");
//			String[] dispArr=null;
//			int lenOfDisp=0;
//			if(Util.isCon(dispLen)){
//				dispArr= dispLen.substring(0,dispLen.length()-1).split("\\;");
//				lenOfDisp=dispArr.length;
//			}
//			int arrLen=arr.length;
//			if(arrLen > 0){
//				for(int i=0; i<arrLen; i++){
//					if(arr[i].length() > 0){
//						String color = arr[i].substring(0, 1);
//						String temp = arr[i];
//						if(temp.length() > 0){
//							int pos_end = -1;
//							
//							//处理如果一个颜色下 有多个引导方向的情况（add by mingm -2014.12.15）
//							while(temp.substring(pos_end+1,temp.length()).length() > 0){
//								String subStr = temp.substring(pos_end+1,temp.length());
//								pos_end = set_screenregion_data(data, lenOfDisp, i, subStr, color, dispArr[i-1]);
//								if(pos_end<0){
//									break;
//								}
//							}
//						}
//					}
//				}
//			}
			
			int lenOfDisp=0;
			String[] dispArr=null;
			if(Util.isCon(dispLen)){
				dispArr= dispLen.substring(0,dispLen.length()-1).split("\\;");
			}
			String[] arr = cf.split("\\\\");
			for (int i = 0; i < arr.length; i++) {
				if(!"".equalsIgnoreCase(arr[i])){
					String color = arr[i].substring(0, 1);
					String temp = arr[i];
					while (temp.length() > 0) {
						int index = screenregion_free_id();
						String arrow = null;
						int pos_start = temp.indexOf("[");
						String beforeArrow = "";
						int pos_end = temp.indexOf("]");
						String endArrow = "";
						if (pos_start == -1 || pos_end == -1) {
							break;
						} else {
							if (pos_start > 0) {
								beforeArrow = String.valueOf(temp.charAt(pos_start - 1));
								beforeArrow = get_arrow(beforeArrow);
							}
							if (pos_end < temp.length() - 1) {
								endArrow = String.valueOf(temp.charAt(pos_end + 1));
								endArrow = get_arrow(endArrow);
							}
							if (Util.isCon(beforeArrow)) {
								arrow = beforeArrow;
							} else if (Util.isCon(endArrow)) {
								arrow = endArrow;
							}
						}
						String region = temp.substring(pos_start + 1, pos_end);
						if(dispArr == null){
							getJt().execute( screenLogicSql.insert_screenregion(data, index, region, arrow, color, 3));
						}else{
							if(lenOfDisp < dispArr.length){
								getJt().execute( screenLogicSql.insert_screenregion(data, index, region, arrow, color, Integer.parseInt(dispArr[lenOfDisp])));
								lenOfDisp++;
							}else{
								getJt().execute( screenLogicSql.insert_screenregion(data, index, region, arrow, color, 3));
							}
						}
						temp = temp.substring(pos_end + 1);
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return data;
	}
	
	private int set_screenregion_data(ScreenLogicData data, int dispArrLen, int i, String subStr, String color, String displen){
		int index = screenregion_free_id();
		String arrow = null;
		int pos_start = subStr.indexOf("[");
		String beforeArrow = "";
		int pos_end = subStr.indexOf("]");
		String endArrow = "";
		if(pos_start == -1 || pos_end == -1){
			return -1;
		}else{
			beforeArrow =subStr.substring(pos_start-1,pos_start);
			arrow = get_arrow(beforeArrow);
//			if(Util.isCon(beforeArrow)){
//				arrow = beforeArrow;
//			}else if(Util.isCon(endArrow)){
//				arrow = endArrow;
//			}
		}
		String region = subStr.substring(pos_start+1,pos_end);
		if(dispArrLen+1-i>0){
			getJt().execute(screenLogicSql.insert_screenregion(data, index, region,arrow,color,Integer.parseInt(displen)));
		}else{
			getJt().execute(screenLogicSql.insert_screenregion(data, index, region,arrow,color,3));
		}
		
		return pos_end;
	}

	private String get_arrow(String str){
		String rStr = "";
		if(!"".equals(str)){
			if(str.indexOf("↑") != -1){
				rStr = "↑";
			}else if(str.indexOf("←") != -1){
				rStr = "←";
			}else if(str.indexOf("→") != -1){
				rStr = "→";
			}else if(str.indexOf("↓") != -1){
				rStr = "↓";
			}
		}
		
		return rStr;
	}

	private String[] getArrowAndIndex(String str){
		String[] arrowAndIndex = new String[2];
		int index = -1;
		String arrow = "";
		if((index = str.indexOf("↑")) != -1){
			arrow = "↑";
		}else if((index = str.indexOf("←")) != -1){
			arrow = "←";
		}else if((index = str.indexOf("→")) != -1){
			arrow = "→";
		}else if((index = str.indexOf("↓")) != -1){
			arrow = "↓";
		}
		arrowAndIndex[0] = String.valueOf(index);
		arrowAndIndex[1] = arrow;
		return arrowAndIndex;
	}
	/**
	 * @return
	 */
	private int screenregion_free_id() {

		CodeData cd = new CodeData();
		CodeData mcd = new CodeData();
		int index ;
		getJt().queryForObjectExt(screenLogicSql.screenregion_free_id(), cd);
		getJt().queryForObjectExt(screenLogicSql.screenregion_minfree_id(), mcd);
		if(!Util.isCon(cd.getCode_id())){
			cd.setCode_id("0");
		}
		if(mcd.getCode_id().equalsIgnoreCase("0")){
			index = 1;
		}else
		{
			index = Integer.parseInt(cd.getCode_id()) + 1;
		}
		Log.log("index=" + index);
		return index;
	}

	/**
	 * @param data
	 */
	public String setRegionDetector(ScreenLogicData data) {
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		StringBuffer r_sb = new StringBuffer();
		JSONArray jsonArray = this.getJt().queryForJSONArrayExt(screenLogicSql.getRegionDetector(data));
		for(int i=0; i<jsonArray.size(); i++){
			JSONObject temp = jsonArray.getJSONObject(i);
			String code = temp.get("detectorCode").toString();
			String regionCode = temp.get("regionCode").toString();
			r_sb.append(code).append(",").append(regionCode).append(";");
		}
		String r_str = r_sb.toString();
		if(!r_str.equals("")){
			r_str = r_str.substring(0, r_str.length() - 1);
		}
		return r_str;
	}

	/**
	 * @param data
	 * @return
	 */
	public JSONObject getScreen(ScreenLogicData data) {
		JSONArray array = getJt().queryJson(screenLogicSql.get_Screen(data));
		if(array.size() > 0){
			return array.getJSONObject(0);
		} else {
			return new JSONObject();
		}
	}
	/**
	 * 
	 * @param scode
	 * @return
	 */
	public JSONObject getScreenPara(String scode){
		JSONObject jobj = new JSONObject();
		JSONArray array = getJt().queryJson(screenLogicSql.getScreenPara(scode));
		if(array.size() > 0){
			for(int i=0;i<array.size();i++){
				if(array.getJSONObject(i).getString("code").equalsIgnoreCase("Led_w")){
					jobj.put("Led_w", array.getJSONObject(i).getString("value"));
				}
				if(array.getJSONObject(i).getString("code").equalsIgnoreCase("font")){
					jobj.put("font", array.getJSONObject(i).getString("value"));
				}
			}
		}

		return jobj;
	}
	/**
	 * @param data
	 * @return
	 */
	public String getParkingNum(ScreenLogicData data) {
		String[] codes = data.getCode().split(",");
		int num = 0;
		for(int i = 0; i < codes.length; i++){
			num += getJt().queryForInt(screenLogicSql.getParkingNum(codes[i]));
		}
		return String.valueOf(num);
	}

	/**
	 * @param data
	 * @return
	 */
	public JSONObject getDetector(ScreenLogicData data,String lang) {
		JSONArray array = getJt().queryJson(screenLogicSql.get_Detector(data,lang));
		if(array.size() > 0){
			JSONObject jObject = array.getJSONObject(0);
			jObject.put("detectorTypeId", ((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(jObject.getString("detectorTypeId")));
			if(jObject.getString("regionType") != null && jObject.getString("regionType") != ""){
				jObject.put("guideRegionId",  jObject.get("guideRegionId") + "(" + 
						((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(jObject.getString("regionType")) + ")");
			}
			return array.getJSONObject(0);
		} else {
			return new JSONObject();
		}
	}

	/**
	 * @param data
	 * @return
	 */
	public ScreenLogicData check_updateDetector(ScreenLogicData data) {
		String[] detectorCodes = data.getDetectorCode().split(",");
		ScreenLogicData judge = this.getJt().queryForObjectExt(screenLogicSql.isExistGuideRegion(data), ScreenLogicData.class);
		if(Util.isCon(judge.getCode_id())){//判断输入的引导区域是否存在
			data.setGuideRegionId(judge.getCode_id().toString());
		}else
		{//不存在则新建一个引导区域
			GuideRegionManageData gdata = new GuideRegionManageData();
			gdata.setId(PrimaryId.getId());
			gdata.setCode(data.getGuideRegionId());
			gdata.setName(data.getGuideRegionId());
			ScreenLogicData judge1 = this.getJt().queryForObjectExt(screenLogicSql.getTypeIdByD(detectorCodes[0]), ScreenLogicData.class);
			gdata.setRegionType(judge1.getCode_id());
			gdata.setNotes(data.getMapId());
			int re = this.getJt().update(new GuideRegionManageSql().guideregion_save(gdata));
			if(1 == re){
				data.setGuideRegionId(gdata.getId());
			}
		}
		//提交的数据中只会含有一种类型的探测器，所以只用第一个探测器判断
		int count = this.getJt().queryForInt(screenLogicSql.checkUpdateDetector(data,detectorCodes[0]));
		data.setTotal(count);
		return data;
	}

	public static void main(String[] args){
		String str = "\\R[A,B]";
		//System.out.println(str.codePointBefore(str.indexOf("[")));
		System.out.println(str.length()+"----"+str.indexOf("]"));
		//System.out.println(String.valueOf(str.charAt(str.indexOf("]")+1)));
		//System.out.println(str.indexOf("R"));
	}
}
