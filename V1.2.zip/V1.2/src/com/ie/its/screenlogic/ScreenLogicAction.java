/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : heliang
 */
package com.ie.its.screenlogic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.CodeData;
import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.guideregionmanage.GuideRegionManageData;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageService;

//命名空间
@Namespace("/screen_logic")
@Results({@Result(name="list",location="/screen_logic/screen_logic.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="screen_logic",location="list.action",type="redirect")})

public class ScreenLogicAction extends ExtendActionSupport {
	
	private ScreenLogicData data;
	@Autowired
	private ScreenLogicService screenLogicService;
	private MapManageService mapService;

	private File myFile;  
    private String myFileFileName;  
    private String myFileFileContentType;
	public File getMyFile() {
		return myFile;
	}
	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}
	public String getMyFileFileName() {
		return myFileFileName;
	}
	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}
	public String getMyFileFileContentType() {
		return myFileFileContentType;
	}
	public void setMyFileFileContentType(String myFileFileContentType) {
		this.myFileFileContentType = myFileFileContentType;
	}
	public ScreenLogicData getData() {
		return data;
	}
	public void setData(ScreenLogicData data) {
		this.data = data;
	}
	public ScreenLogicAction(){
		if(data == null){
			data = new ScreenLogicData();
		}
	}

	
	
	
	@Action(value="get_detectors",results={@Result(type="json")})
	public void get_detectors(){	
		
//		screenLogicService.setScreen(data);
		JSONObject json =  new JSONObject();
		try{
			JSONObject jsonData = screenLogicService.getDetectors(data.getCode(),"screenLogic","");
			//设置多语言
			setLang(data);
			//json.element("msg", jsonData);
			//json.element("success", true);
			json = jsonData;
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}

	/**
     * Description :查询引导区域逻辑．
     * @throws :Exception
     */
	@Action(value="list",results={@Result(name="success",location="/screen_logic/screen_logic.jsp")})
	public String list(){
		MapManageData mapData = new MapManageData();
//		data = screenLogicService.list(data);
		
		//获得地图list
		JSONArray jsonArr = JSONArray.fromObject(mapService.map_getMapCode(mapData));
		this.request.setAttribute("map", jsonArr);
		this.request.setAttribute("def_id", jsonArr.getJSONObject(0).getString("code_id"));
		this.request.setAttribute("def_path", jsonArr.getJSONObject(0).getString("path"));
		//设置多语言
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
     * Description :引导区域逻辑．
     * @throws :Exception
     */
	@Action(value="logic_main",results={@Result(name="success",location="/screen_logic/logic_main.jsp")})
	public String logic_main(){
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
     * Description :保存探测器．
     * @throws :Exception
     */
	@Action(value="update_detector",results={@Result(type="json")})
	public void update_detector(){
		JSONObject json =  new JSONObject();
		try{
			//替换传进来探测器值中"_"为"."
			data.setDetectorCode(data.getDetectorCode().replace('_', '.'));
			screenLogicService.update_detector(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	/**
     * Description :保存引导屏．
     * @throws :Exception
     */
	@Action(value="flash_pub",results={@Result(name="success",location="/screen_logic/flash_pub.jsp")})
	public String flash_pub() throws Exception{
		
		request.setAttribute("path", data.getMap_src());
		
		request.setAttribute("id", data.getMapId());
		
		request.setAttribute("import_", data.getImportOrNot());
		String lang = this.request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		//当前系统类型
		data.setSysModel(screenLogicService.queryForSystemModel());
		return "success";
	}
	
	/**
     * Description :保存引导屏．
     * @throws :Exception
     */
	@Action(value="update_screen",results={@Result(type="json")})
	public void update_screen(){
		JSONObject json =  new JSONObject();
		try{
			screenLogicService.update_screen(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	/**
     * Description :创建引导区域．
     * @throws :Exception
     */
	@Action(value="screen_create",results={@Result(name="create",location="/screen_logic/screen_create.jsp")})
	public String create(){
		//设置多语言
		setLang(data);
		String lang =request.getSession().getAttribute("lang").toString();
		data.setMapList(screenLogicService.getList("Map", data,lang));
		if(data.getMapList().size() > 0){
			data.setMapId(((MapManageData)data.getMapList().get(0)).getId()+"6666666");
			data.setImportOrNot((((MapManageData)data.getMapList().get(0)).getImportOrNot()));
		}
		//默认
		data.setDispColor("\\R");
		data.setContentFormat("\\R");
		
		data.setControllerList(screenLogicService.getList("Controller", data,lang));
		data.setDetectorTypeList(screenLogicService.getList("DetectorType", data,lang));
		data.setDirectionList(screenLogicService.getList("Direction", data,lang));
		data.setDispColorList(Util.getCodeList(data, "disp_color"));
		data.setScreenTypeList(screenLogicService.getList("ScreenType", data,lang));
		data.setSpotTypeList(screenLogicService.getList("SpotType", data,lang));
		data.setGuideRegionList(screenLogicService.getList("GuideRegionList", data,lang));
		data.setLogicList(screenLogicService.getList("LogicList", data,lang));
		//系统类型
		data.setSysModel(screenLogicService.queryForSystemModel());
		return ConstantClass.ACTION_CREATE;
	}
	
	@Action(value="map_region",results={@Result(type="json")})
	public void map_region(){
		JSONObject json =  new JSONObject();
		try{
			JSONObject jsonData = new JSONObject();
			JSONArray regionList = null;
			JSONArray parentList = null;
			setLang(data);
			if("logic".equals(data.getQueryMode())){
				regionList = screenLogicService.getJsonArray("LogicList", data);
			} else {
				regionList = screenLogicService.getJsonArray("GuideRegionList", data);
				parentList = screenLogicService.getParentCode(data);
			}
			jsonData.put("regionList", regionList);
			jsonData.put("parentList", parentList);
			json.element("data", jsonData);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="get_detector",results={@Result(type="json")})
	public void get_detector(){	

		JSONObject json =  new JSONObject();
		try{
			//设置多语言
			setLang(data);
			String lang = request.getSession().getAttribute("lang").toString();
			data.setDetectorId(data.getDetectorId().replace('_', '.'));  	//将前台取回的172_18_1_0_001格式换为172.18.1.0.001
			JSONObject jsonData = screenLogicService.getDetector(data,lang);
			
			json.element("data", jsonData);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="get_screen",results={@Result(type="json")})
	public void get_screen(){	
		JSONObject json =  new JSONObject();
		try{
			JSONObject jsonData = screenLogicService.getScreen(data);
			JSONObject pjsonData = screenLogicService.getScreenPara(data.getCode());
			json.element("data", jsonData);
			json.element("pdata", pjsonData);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="get_parking_num",results={@Result(type="json")})
	public void get_parking_num(){	
		
//		screenLogicService.setScreen(data);
		JSONObject json =  new JSONObject();
		try{
			String num = screenLogicService.getParkingNum(data);
			json.element("data", num);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	/**
	 * 初始化引导屏逻辑页面flash地图
	 */
	@Action(value="region_detector",results={@Result(type="json")})
	public void region_detector(){	
		JSONObject json =  new JSONObject();
		try{
			String jsonData = screenLogicService.setRegionDetector(data);
			json.element("data", jsonData);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	/**
	 * 校验所选引导区域类型是否和探测器类型一致
	 */
	@Action(value="check_update_detector",results={@Result(type="json")})
	public void check_update_detector(){	
		JSONObject json =  new JSONObject();
		data.setDetectorCode(data.getDetectorCode().replace('_', '.'));
		data = screenLogicService.check_updateDetector(data);
		json.element("success", data.getTotal() > 0 ? true : false);
		json.element("guideRegionId", data.getGuideRegionId());
		setJsonRes(json);
	}
}
