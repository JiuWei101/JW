/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 
 * Version                  : 1.0
 * create date              : 2012.2.27
 * author                   : heliang
 */
package com.ie.its.screenlogic;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.ie.frame.ExtendData;

public class ScreenLogicData extends ExtendData{
	
	private String mapId;				//地图id
	private List mapList;				//地图列表(code_id:地图地址,code_name:地图名称)
	private int importOrNot;
	private String code;				//引导屏编号
	private String screenId;				//引导屏ID
	private String addr;				//引导屏地址
	private String controllerId;		//引导屏管理器地址
	private List controllerList;		//引导屏管理器列表
	private String screenTypeCode;		//引导屏类型
	private List screenTypeList;		//引导屏类型列表
	private String dispColor;			//显示颜色
	private String colorMode;			//引导屏颜色模式
	private List dispColorList;			//引导屏类型列表
	private String direction;			//引导屏编号
	private List directionList;			//引导屏类型列表
	private String numLength;			//剩余车位数长度
	private String contentFormat;		//显示格式
	private String contentFormatCode;		//显示格式
	
	private String detectorId;			//探测器Id
	private String detectorCode;		//探测器编号
	private String detectorCtrlId;		//管理器地址
	private String detectorAddr;		//探测器地址
	private String parkingSpaceCode;	//车位编号
	private String detectorTypeId;		//探测器类型
	private List detectorTypeList;		//探测器类型列表
	private String spotType;			//车位类型
	private List spotTypeList;			//探测器类型列表
	private String guideRegionIdList;		//引导区域
	private String guideRegionId;		//引导区域
	private List guideRegionList;		//引导区域列表
	private String logicId;				//逻辑区域
	private List logicList;				//逻辑区域列表
	
	private String screenTemplateId;    //引导屏参数模板ID
	private String screenTemplateName;    //引导屏参数模板名称
	private List screenTemplateList;		//引导屏类型下拉框
	
	private String showDispLen;
	
	public String getShowDispLen() {
		return showDispLen;
	}

	public void setShowDispLen(String showDispLen) {
		this.showDispLen = showDispLen;
	}

	public String getScreenTemplateId() {
		return screenTemplateId;
	}

	public void setScreenTemplateId(String screenTemplateId) {
		this.screenTemplateId = screenTemplateId;
	}

	public String getScreenTemplateName() {
		return screenTemplateName;
	}

	public void setScreenTemplateName(String screenTemplateName) {
		this.screenTemplateName = screenTemplateName;
	}

	public List getScreenTemplateList() {
		return screenTemplateList;
	}

	public void setScreenTemplateList(List screenTemplateList) {
		this.screenTemplateList = screenTemplateList;
	}
	private String detector;			//前台传过来的探测器id集合

	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}

	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	/**
	 * @return the guideRegionId
	 */
	public String getGuideRegionId() {
		return guideRegionId;
	}

	/**
	 * @param guideRegionId the guideRegionId to set
	 */
	public void setGuideRegionId(String guideRegionId) {
		this.guideRegionId = guideRegionId;
	}

	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}

	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}

	/**
	 * @return the detector
	 */
	public String getDetector() {
		return detector;
	}

	/**
	 * @param detector the detector to set
	 */
	public void setDetector(String detector) {
		this.detector = detector;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the addr
	 */
	public String getAddr() {
		return addr;
	}

	/**
	 * @param addr the addr to set
	 */
	public void setAddr(String addr) {
		this.addr = addr;
	}

	/**
	 * @return the controllerId
	 */
	public String getControllerId() {
		return controllerId;
	}

	/**
	 * @param controllerId the controllerId to set
	 */
	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}

	/**
	 * @return the screenTypeCode
	 */
	public String getScreenTypeCode() {
		return screenTypeCode;
	}

	/**
	 * @param screenTypeCode the screenTypeCode to set
	 */
	public void setScreenTypeCode(String screenTypeCode) {
		this.screenTypeCode = screenTypeCode;
	}

	/**
	 * @return the screenTypeList
	 */
	public List getScreenTypeList() {
		return screenTypeList;
	}

	/**
	 * @param screenTypeList the screenTypeList to set
	 */
	public void setScreenTypeList(List screenTypeList) {
		this.screenTypeList = screenTypeList;
	}

	/**
	 * @return the dispColor
	 */
	public String getDispColor() {
		return dispColor;
	}

	/**
	 * @param dispColor the dispColor to set
	 */
	public void setDispColor(String dispColor) {
		this.dispColor = dispColor;
	}

	/**
	 * @return the dispColorList
	 */
	public List getDispColorList() {
		return dispColorList;
	}

	/**
	 * @param dispColorList the dispColorList to set
	 */
	public void setDispColorList(List dispColorList) {
		this.dispColorList = dispColorList;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * @return the directionList
	 */
	public List getDirectionList() {
		return directionList;
	}

	/**
	 * @param directionList the directionList to set
	 */
	public void setDirectionList(List directionList) {
		this.directionList = directionList;
	}

	/**
	 * @return the numLength
	 */
	public String getNumLength() {
		return numLength;
	}

	/**
	 * @param numLength the numLength to set
	 */
	public void setNumLength(String numLength) {
		this.numLength = numLength;
	}

	/**
	 * @return the contentFormat
	 */
	public String getContentFormat() {
		return contentFormat;
	}

	/**
	 * @param contentFormat the contentFormat to set
	 */
	public void setContentFormat(String contentFormat) {
		this.contentFormat = contentFormat;
	}

	/**
	 * @return the detectorId
	 */
	public String getDetectorId() {
		return detectorId;
	}

	/**
	 * @param detectorId the detectorId to set
	 */
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}

	/**
	 * @return the detectorCtrlId
	 */
	public String getDetectorCtrlId() {
		return detectorCtrlId;
	}

	/**
	 * @param detectorCtrlId the detectorCtrlId to set
	 */
	public void setDetectorCtrlId(String detectorCtrlId) {
		this.detectorCtrlId = detectorCtrlId;
	}

	/**
	 * @return the detectorAddr
	 */
	public String getDetectorAddr() {
		return detectorAddr;
	}

	/**
	 * @param detectorAddr the detectorAddr to set
	 */
	public void setDetectorAddr(String detectorAddr) {
		this.detectorAddr = detectorAddr;
	}

	/**
	 * @return the parkingSpaceCode
	 */
	public String getParkingSpaceCode() {
		return parkingSpaceCode;
	}

	/**
	 * @param parkingSpaceCode the parkingSpaceCode to set
	 */
	public void setParkingSpaceCode(String parkingSpaceCode) {
		this.parkingSpaceCode = parkingSpaceCode;
	}

	/**
	 * @return the detectorTypeId
	 */
	public String getDetectorTypeId() {
		return detectorTypeId;
	}

	/**
	 * @param detectorTypeId the detectorTypeId to set
	 */
	public void setDetectorTypeId(String detectorTypeId) {
		this.detectorTypeId = detectorTypeId;
	}

	/**
	 * @return the detectorTypeList
	 */
	public List getDetectorTypeList() {
		return detectorTypeList;
	}

	/**
	 * @param detectorTypeList the detectorTypeList to set
	 */
	public void setDetectorTypeList(List detectorTypeList) {
		this.detectorTypeList = detectorTypeList;
	}

	/**
	 * @return the spotType
	 */
	public String getSpotType() {
		return spotType;
	}

	/**
	 * @param spotType the spotType to set
	 */
	public void setSpotType(String spotType) {
		this.spotType = spotType;
	}

	/**
	 * @return the spotTypeList
	 */
	public List getSpotTypeList() {
		return spotTypeList;
	}

	/**
	 * @param spotTypeList the spotTypeList to set
	 */
	public void setSpotTypeList(List spotTypeList) {
		this.spotTypeList = spotTypeList;
	}

	/**
	 * @return the logicId
	 */
	public String getLogicId() {
		return logicId;
	}

	/**
	 * @param logicId the logicId to set
	 */
	public void setLogicId(String logicId) {
		this.logicId = logicId;
	}

	/**
	 * @return the guideRegionList
	 */
	public List getGuideRegionList() {
		return guideRegionList;
	}

	/**
	 * @param guideRegionList the guideRegionList to set
	 */
	public void setGuideRegionList(List guideRegionList) {
		this.guideRegionList = guideRegionList;
	}

	/**
	 * @return the logicList
	 */
	public List getLogicList() {
		return logicList;
	}

	/**
	 * @param logicList the logicList to set
	 */
	public void setLogicList(List logicList) {
		this.logicList = logicList;
	}

	/**
	 * @return the detectorCode
	 */
	public String getDetectorCode() {
		return detectorCode;
	}

	/**
	 * @param detectorCode the detectorCode to set
	 */
	public void setDetectorCode(String detectorCode) {
		this.detectorCode = detectorCode;
	}

	/**
	 * @return the guideRegionIdList
	 */
	public String getGuideRegionIdList() {
		return guideRegionIdList;
	}

	/**
	 * @param guideRegionIdList the guideRegionIdList to set
	 */
	public void setGuideRegionIdList(String guideRegionIdList) {
		this.guideRegionIdList = guideRegionIdList;
	}

	/**
	 * @return the controllerList
	 */
	public List getControllerList() {
		return controllerList;
	}

	/**
	 * @param controllerList the controllerList to set
	 */
	public void setControllerList(List controllerList) {
		this.controllerList = controllerList;
	}

	/**
	 * @return the screenId
	 */
	public String getScreenId() {
		return screenId;
	}

	/**
	 * @param screenId the screenId to set
	 */
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	/**
	 * @return the contentFormatCode
	 */
	public String getContentFormatCode() {
		return contentFormatCode;
	}

	/**
	 * @param contentFormatCode the contentFormatCode to set
	 */
	public void setContentFormatCode(String contentFormatCode) {
		this.contentFormatCode = contentFormatCode;
	}

	public int getImportOrNot() {
		return importOrNot;
	}

	public void setImportOrNot(int importOrNot) {
		this.importOrNot = importOrNot;
	}

	public String getColorMode() {
		return colorMode;
	}

	public void setColorMode(String colorMode) {
		this.colorMode = colorMode;
	}
	

}
