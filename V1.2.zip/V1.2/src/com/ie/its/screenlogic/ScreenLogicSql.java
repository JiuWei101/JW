package com.ie.its.screenlogic;

import static com.ie.common.Util.*;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class ScreenLogicSql extends ExtendSql{

	
	/**
	 * Description ：根据引导屏编号获取引导屏绑定区域
	 * @param data
	 * @param screen_code 引导屏编号
	 * @return
	 */
  public String getGuideAreaByScreen(String screenCode,String direction)
  {
	  String querySql = "select p_screenregion.guideRegionCodeList from p_screen , p_screenregion where p_screen.id = p_screenregion.screenId and p_screen.code="+"'"+screenCode+"'";
	  if(!direction.equals("")){
		  querySql += " and p_screenregion.screenAreaName = "+Util.toSqlVal(direction);
	  }
	  return querySql;
  }
	
	
	
	
	
	
	/**
     * Description :查询引导区．
     * @param  :ScreenLogicData,String
     * @return :String
     */
	public String list(ScreenLogicData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  task.*,map.number as map_number,screen.code as screen_code ";
		}
		
		querySql += " from p_screentask task,p_screen screen,p_map map ";
		querySql += " where task.screenId=screen.id and screen.mapId= map.id";
		
		return querySql;
	}
	
	/**
     * Description :获得引导区域信息．
     * @param  :ScreenLogicData
     * @return :String
     */
	public String get_GuideRegion(ScreenLogicData data) {
		String querySql = "select gr.id as code_id,gr.code as code_name,gr.regionType,gr.notes as mapId from p_guideregion gr order by gr.code";
//		String querySql = "select gr.id as code_id,gr.code as code_name,gr.regionType from p_guideregion gr where gr.deleteFlag<>'1' order by gr.code";
		return querySql;
	}
	public String get_ParentNode(ScreenLogicData data){
		String querySql = "select distinct(gr.notes) as mapId from p_guideregion gr";
		return querySql;
	}
	
	/**
     * Description :获得逻辑区域信息．
     * @param  :ScreenLogicData
     * @return :String
     */
	public String get_LogicRegion(ScreenLogicData data) {
		String querySql = "select lr.id as code_id,lr.code as code_name from p_logicregion lr order by lr.code";		
		return querySql;
	}

	/**
	 * @return
	 */
	public String getDetectorType() {
		String querySql = "select id as code_id,name as code_name from p_detectortype order by name";
		return querySql;
	}

	/**
	 * @return
	 */
	public String getController() {
		String querySql = "select id as code_id,addr as code_name from p_controller order by addr";
		return querySql;
	}

	/**
	 * @return
	 */
	public String getMap() {
		String querySql = "select id,path,name,importOrNot from p_map order by name";
		return querySql;
	}

	/**
	 * @return
	 */
	public String getScreenType() {
		String querySql = "select code as code_id,name as code_name from p_screentype order by name";
		return querySql;
	}
		
	/**
     * Description :获得地图下拉框信息．
     * @param  :ScreenLogicData
     * @return :String
     */
	public String sl_getMapCode(){
		String querySql = "";
		
		querySql += " select id as code_id,name as code_name,path from p_map order by name";
		
		return querySql;
	}	

	/**
     * Description :获得探测器信息．
	 * @param data 
     * @param  :
     * @return :String
     */
	public String get_Detector(ScreenLogicData data,String lang) {//dt.name 为中文名字 dt.ename为英文名字  By LLX
		String querySql = "";
		querySql += "select d.id as detectorId,d.code as detectorCode,c.addr as detectorCtrlId,d.addr as detectorAddr,ps.code as parkingSpaceCode, " +
				"dt.code as detectorTypeId,ps.spotType,pg.code as guideRegionId,pg.regionType as regionType,ps.logicId " +
				"from p_detector d left join p_parkingspace ps on d.id = ps.detectorId left join p_guideregion as pg on pg.id = d.guideRegionId  inner join p_controller c on d.controllerId = c.id " +
				"inner join p_detectortype dt on d.detectorTypeId=dt.id where d.code = '" + data.getDetectorId() + "'";

		return querySql;
	}
	
	/**
     * Description :获得屏幕信息．
	 * @param data 
     * @param  :
     * @return :String
     */
	public String get_Screen(ScreenLogicData data) {
		String querySql = "";
		
		querySql += "select s.id as screenId,concat(s.grpAddr,'-',s.addr) as addr,s.displen,s.controllerId,s.screenTypeCode,s.contentFormat,s.colorMode,pv.value " +
				"from p_screen s left join p_screentypepara tp on s.screenTypeCode=tp.screenType and tp.code='Led_w' " +
				"left join p_screenparavalue pv on pv.screenId=s.id and pv.screenTypeParaId=tp.id where s.code = '" + data.getCode() + "'";
		Log.log(querySql);
		return querySql;
	}
	/**
	 * 获取条屏的参数
	 * @param scode
	 * @return
	 */
	public String getScreenPara(String scode){
		String querySql = "";
		querySql += "select tp.code,pv.value from p_screen s left join p_screentypepara tp on s.screenTypeCode=tp.screenType " +
					"left join p_screenparavalue pv on pv.screenId=s.id and pv.screenTypeParaId=tp.id " +
					"where s.code = '" +scode + "'";
		return querySql;
	}
	/**
     * Description :获得引导区内车位数．
	 * @param data 
     * @param  :
     * @return :String
     */
	public String getParkingNum(String code) {
		String querySql = "";
		
		querySql += "select count(d.id) from p_detector d,p_guideregion g where g.code='" + code + "' and g.id=d.guideRegionId and d.detectorTypeId !='2'";
		Log.log(querySql);
		return querySql;
	}
	
	/**
     * Description :获得管理器．
     * @param  :
     * @return :String
     */
	public String get_controllerCode() {
		String querySql = "";
		
		querySql += "select id as code_id,id as code_name from p_controller order by id";
		
		return querySql;
	}

	/**
     * Description :获得探测器类型．
     * @param  :
     * @return :String
     */
	public String get_detectorTypeCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_detectorType order by id";
		
		return querySql;
	}

	/**
	 * @param data
	 * @return
	 */
	public String update_detector(ScreenLogicData data, String code) {
		String querySql = "";
		
		querySql += "update p_detector set guideRegionId = " + Util.toSqlVal(data.getGuideRegionId()) + 
				" where code = " + (code == null ? Util.toSqlVal(data.getDetectorCode()) : Util.toSqlVal(code));
		Log.log(querySql);
		return querySql;
	}	

	/**
	 * @param data
	 * @return
	 */
	public String update_parkingspace(ScreenLogicData data) {
		String querySql = "";
		
		querySql += "update p_parkingspace set logicId = " + Util.toSqlVal(data.getLogicId()) + 
				",code = " + Util.toSqlVal(data.getParkingSpaceCode()) + 
				//",spotType = " + Util.toSqlVal(data.getSpotType()) + 
				" where detectorId = " + Util.toSqlVal(data.getDetectorId());
		Log.log(querySql);
		return querySql;
	}	

	/**
	 * @param data
	 * @return
	 */
	public String update_parkingspace(ScreenLogicData data, String code) {
		String querySql = "";
		
		querySql += "update p_parkingspace set logicId = " + Util.toSqlVal(data.getLogicId()) + 
				//",spotType = " + Util.toSqlVal(data.getSpotType()) + 
				" where detectorId in (select id from p_detector where code = " + Util.toSqlVal(code) + ")";
		Log.log(querySql);
		return querySql;
	}	

	/**
	 * @param data
	 * @return
	 */
	public String update_guideRegion(ScreenLogicData data, String code) {
		String querySql = "";
		querySql += "update p_guideregion set regionType = (select detectorTypeId from p_detector where code = " + 
				(code == null ? Util.toSqlVal(data.getDetectorCode()) : Util.toSqlVal(code)) + ") where id = " + Util.toSqlVal(data.getGuideRegionId());
		Log.log(querySql);
		return querySql;
	}	

	/**
	 * @param data
	 * @return
	 */
	public String update_screen(ScreenLogicData data) {
		String querySql = "";
		querySql += "update p_screen set ";  
			if(Util.isCon(data.getControllerId())){
				querySql += "controllerId = " + Util.toSqlVal(data.getControllerId())+",";
			}
		querySql +=	" screenTypeCode = " + Util.toSqlVal(data.getScreenTypeCode()) + 
				",contentFormat = " + Util.toSqlVal(data.getContentFormat()) + 
				",dispLen = " + Util.toSqlVal(data.getShowDispLen()) + 
				" where id = " + Util.toSqlVal(data.getScreenId());
		Log.log(querySql);
		
		return querySql;
	}
	
	/**
	 * 
	 * @Description : 删除引导屏逻辑的时候同时删除变色策略
	 * @param : @param data
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : mingm
	 */
	public String delete_colortask(ScreenLogicData data){
		String querySql = "delete from p_colortacticstask where 1=1 ";
		if(Util.isCon(data.getControllerId())){
			querySql += " and controllerId=" + Util.toSqlVal(data.getControllerId());
		}
		querySql += " and screens=" + Util.toSqlVal(data.getCode());
		
		return querySql;
	}

	/**
	 * @param data
	 * @return
	 */
	public String delete_screenregion(ScreenLogicData data) {
		String sql = "";
		sql += "delete from p_screenregion where screenId  = " + Util.toSqlVal(data.getScreenId());
		Log.log(sql);
		return sql;
	}

	/**
	 * 返回当前引导屏引导区域的最小有间隔下界
	 * @return
	 */
	public String screenregion_free_id() {
		String sql = "";
		sql += "select min(id+0) as code_id from p_screenregion where id+1 not in (select id from p_screenregion)";
		return sql;
	}
	
	/**
	 * 返回当前引导屏引导区域的最小有间隔下界(screenregion_free_id无法处理每次都是删除了id最小的纪录后添加的情况,add by wj 20121109)
	 * @return
	 */
	public String screenregion_minfree_id() {
		String sql = "";
		sql += "select count(*) as code_id from p_screenregion where id = 1";
		return sql;
	}
	
//	/**
//	 * @param data
//	 * @param code_id
//	 * @return
//	 */
	public String insert_screenregion(ScreenLogicData data, int index, String region,String direction,String color,int dispLen) {
		String sql = "";
		sql += "insert into p_screenregion(id,screenId,screenAreaName,guideRegionCodeList,dispColor,dispLen) values(" +
		Util.toSqlVal(index) + "," + Util.toSqlVal(data.getScreenId()) + "," + Util.toSqlVal(direction) + "," + 
		Util.toSqlVal(region) + "," + Util.toSqlVal(color) + "," + Util.toSqlVal(dispLen)+ ")";
	//	System.out.println(sql);
		Log.log(sql);
		return sql;
	}
	public String update_screenregion(ScreenLogicData data, int index,String region,String direction,String color) {
		String sql = "";
		sql += "update p_screenregion set screenAreaName="+Util.toSqlVal(direction)+",guideRegionCodeList= "
		+Util.toSqlVal(region) + ",dispColor="+ Util.toSqlVal(color) + " where screenId= "+Util.toSqlVal(data.getScreenId())
		+" and id="	+Util.toSqlVal(index);
		Log.log(sql);
		return sql;
	}
	/**
	 * @param data
	 * @param code_id
	 * @return
	 */
	public String insert_screenregion(ScreenLogicData data, int index, String region) {
		String sql = "";
		sql += "insert into p_screenregion(id,screenId,screenAreaName,guideRegionCodeList) values(" +
		Util.toSqlVal(index) + "," + Util.toSqlVal(data.getScreenId()) + "," + Util.toSqlVal(data.getDirection()) + "," + 
		Util.toSqlVal(region) + ")";
		return sql;
	}

	/**
	 * @param data
	 * @return
	 */
	public String getRegionDetector(ScreenLogicData data) {
		String sql = "";
		sql += "select gr.code as regionCode,replace(d.code,'.','_') as detectorCode from p_guideregion gr,p_detector d " +
				"where d.guideRegionId = gr.id and d.mapId='" + data.getMapId() + "' and d.guideRegionId=gr.id";
		Log.log(sql);
		return sql;
	}

	/**
	 * @param string
	 * @return
	 */
	public String checkUpdateDetector(ScreenLogicData data, String code) {
		String sql = "";
		sql += "select count(g.id) from p_guideregion g,p_detector d where d.code=" + Util.toSqlVal(code) + 
				" and g.regionType=d.detectorTypeId and g.id=" + Util.toSqlVal(data.getGuideRegionId());
		Log.log(sql);
		return sql;
	}
	public String isExistGuideRegion(ScreenLogicData data){
		String querySql = "";
		querySql = "select g.id as code_id from p_guideregion g where g.id=" + Util.toSqlVal(data.getGuideRegionId()) + " or " + "g.code=" + Util.toSqlVal(data.getGuideRegionId());
		return querySql;
	}
	public String getTypeIdByD(String code){
		String querySql = "";
		querySql = "select d.detectorTypeId as code_id from p_detector d where d.code=" + Util.toSqlVal(code);
		return querySql;
	}






	public String searchRegion(ScreenLogicData data) {
		String sql = "";
		sql += "select count(*) from p_screenregion where screenId="+Util.toSqlVal(data.getScreenId());
		Log.log(sql);
		return sql;
	}


	public String searchRegionId(ScreenLogicData data) {
		// TODO Auto-generated method stub
		String sql = "";
		sql += "select id from p_screenregion where screenId="+Util.toSqlVal(data.getScreenId());
		Log.log(sql);
		return sql;
	}

	public String dealRegion(ScreenLogicData data,int index) {
		String sql = "";
		sql += "delete from p_screenregion where screenId="+Util.toSqlVal(data.getScreenId())+" and id ="+Util.toSqlVal(index);
		Log.log(sql);
		return sql;
	}
}
