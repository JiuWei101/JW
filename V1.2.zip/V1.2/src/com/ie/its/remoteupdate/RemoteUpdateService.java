package com.ie.its.remoteupdate;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.cxf.aegis.databinding.AegisDatabinding;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.Log;
import com.ie.common.MD5Hash;
import com.ie.common.Util;
import com.ie.common.ZipUtil;
import com.ie.frame.ExtendService;
import com.ie.frame.exception.FileTransferException;
import com.ie.its.register.RegisterData;
import com.ie.its.ws.Exchange;
import com.ie.its.ws.FileExchange;
import com.ie.its.ws.MyFile;

@SuppressWarnings("rawtypes")
@Scope("prototype")
@Service
public class RemoteUpdateService extends ExtendService {
	private RemoteUpdateSql remoteupdatesql;
		
	public RemoteUpdateService(){
		remoteupdatesql = new RemoteUpdateSql();
		}
	
	/**
	 * 获取可用的版本列表
	 * @param data
	 * @return
	 */
	@SuppressWarnings({ "unchecked"})
	public RemoteUpdateData version_list(RemoteUpdateData data){
		//获取数量
		int count = this.getJt().queryForInt(remoteupdatesql.version_list("count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		if(Util.isCon(getRemoteUrl())){//远程升级中心地址不为空时
			sendSystemInfoAndgetInfo();
		}
		ArrayList <RemoteUpdateData>rows = this.getJt().<RemoteUpdateData>queryForListExt(remoteupdatesql.version_list(""), 
				data.getStart(), data.getLimit(),RemoteUpdateData.class);
		data.setPer_data(rows);
		return data;
	}
	
	/**
	 * 获取更新历史
	 * @param data
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public RemoteUpdateData update_his_list(RemoteUpdateData data){
		//获取数量
		int count = this.getJt().queryForInt(remoteupdatesql.update_his_list("count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		ArrayList <RemoteUpdateData>rows = this.getJt().<RemoteUpdateData>queryForListExt(remoteupdatesql.update_his_list(""), 
				data.getStart(), data.getLimit(),RemoteUpdateData.class);
		data.setPer_data(rows);
		return data;
	}
	/**
	 * 获取远程更新地址
	 * @return
	 */
	public String getRemoteUrl(){
		String remoteUrl = "";
		RegisterData rdata = this.getJt().queryForObjectExt("select * from p_register", RegisterData.class);
		if(Util.isCon(rdata.getUpgradeUrl())){
			remoteUrl = rdata.getUpgradeUrl().toString();
		}
		return remoteUrl;
	}
	
	@SuppressWarnings("unchecked")
	public void sendSystemInfoAndgetInfo(){
		String url = getRemoteUrl();//获取更新地址
		if(Util.isCon(url)){
			try{
				//获取当前系统信息
				List<Map> list = (List)this.getJt().queryForList(remoteupdatesql.getSystemInfor(""));
				int size = list.size();
				for(int i=0; i<size; i++){
					Map temp = list.get(i);
					java.util.Date currentDt = (java.util.Date)temp.get("CurrentDt");
					temp.put("CurrentDt", currentDt==null?null:new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(currentDt));
					java.util.Date LastDt = (java.util.Date)temp.get("LastDt");
					temp.put("LastDt", currentDt==null?null:new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(LastDt));
					if(temp.get("SysType").equals("PGS01")){
						temp.put("Name", "PGSWeb系统");
					}else{
						temp.put("Name", "PGSServer服务");
					}
					Long SysID = (Long)temp.get("SysID");
					//获取历史更新记录信息
					JSONArray jArr = this.getJt().queryForJSONArrayExt(remoteupdatesql.getCurrentVersionMess(SysID));
					temp.put("upgrade", jArr.toString());
				}
				
				JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
				factory.setServiceClass(Exchange.class);
				factory.setAddress(url.concat("Exchange"));
				factory.getServiceFactory().setDataBinding(new AegisDatabinding());
				Exchange client = (Exchange) factory.create();
				List<Map> rList = client.exchangeSysInfo(list);
				System.out.println(rList);
				
				for(int i=0; i<rList.size(); i++){
					Map map = rList.get(i);
					RemoteUpdateData data = new RemoteUpdateData();
					String SysID = map.get("SysID").toString();
					data.setSysID(Integer.parseInt(SysID));
					String currentVerNo = String.valueOf(map.get("CurrentVerNo"));
					String waitingVerNo = String.valueOf(map.get("WaitingVerNo"));
					if(map.get("WaitingVerNo") == null && currentVerNo.compareTo(waitingVerNo) == 1){
						data.setState("等待更新");
					}
					data.setCurrentVerNo(map.get("CurrentVerNo").toString());
					data.setWaitingVerNo(map.get("WaitingVerNo").toString());
					this.getJt().update(remoteupdatesql.updateExtraInfor(data));//更新系统附加信息表
					JSONArray jarr = JSONArray.fromObject(map.get("upgrade"));
					for(int j=0; j<jarr.size(); j++){
						JSONObject jobj = jarr.getJSONObject(j);
						data.setVerNo(jobj.getString("VerNo"));
						data.setUploadState(jobj.getInt("UploadState"));
						this.getJt().update(remoteupdatesql.updateUpgradeHis(data));//更新系统升级历史记录
					}
					
				}
			}catch(Exception e){
				Log.log(e);
			}
		}else{
			
		}
	}
	
	/**
	 * 设置远程更新
	 * @param rdata
	 */
	public void setUpgradeUrl(RegisterData rdata){
//		if(Util.isCon(rdata.getUpgradeUrl())){
			this.getJt().update(remoteupdatesql.updateRegisterData(rdata));
//		}
	}
	/**
	 * 下载文件
	 * @param filename
	 * @return
	 * @throws FileTransferException 
	 */
	public JSONObject downloadFileHandle(String sysIDs){
		String result = "";
		if(Util.isCon(getRemoteUrl())){
			try{
				List<Map> list = getSystemInfoBySysID(sysIDs);
				for(Map temp:list){
					String sysType = (String)temp.get("SysType");
					String verNo = (String)temp.get("VerNo");
					JSONObject jObj = getUpdateFile(sysType,verNo);
					String sSHA1 = jObj.getString("hashCode").toUpperCase();
					String dSHA1 = MD5Hash.getFileSHA1(jObj.getString("clientFile")).toUpperCase();
					if(!sSHA1.equals(dSHA1)){
						if(sysType.equals("PGS01")){
							result += "PGS Web系统升级包文件下载成功！但文件哈希码与授权升级中心的不一致，请重新下载！";
						}else{
							result += "PGS Server系统升级包文件下载成功！但文件哈希码与授权升级中心的不一致，请重新下载！";
						}
					}else{
						if(sysType.equals("PGS01")){
							result += "PGS Web系统升级包文件下载成功！";
						}else{
							result += "PGS Server系统升级包文件下载成功！";
						}
					}
				}  		
			}catch(FileTransferException e){
				Log.log("异常信息:" + e);
				result = "下载文件产生异常，请重试！";
			}
		}
		else{
			result = "下载中心地址为空！";
		}
		JSONObject jobj = new JSONObject();
		jobj.element("done", true);
		jobj.element("result", result);
		return jobj;
		
	}
	
	
	@SuppressWarnings("unchecked")
	private List<Map> getSystemInfoBySysID(String sysIDs){
		List<Map> list = new ArrayList<Map>();
		if(Util.isCon(sysIDs)){
			list = (List)this.getJt().queryForList(remoteupdatesql.getSystemInfor(sysIDs));
		}
		return list;
	}
	
	/**
	 * 根据 系统类别 和 版本号 获取系统更新文件
	 * @param sysType 系统类别
	 * @param verNo  版本号
	 * @return
	 * @throws FileTransferException
	 */
	private JSONObject getUpdateFile(String sysType,String verNo) throws FileTransferException{
		
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(Exchange.class);
		factory.setAddress(getRemoteUrl().concat("Exchange"));
		factory.getServiceFactory().setDataBinding(new AegisDatabinding());
		Exchange client = (Exchange)factory.create();
		JSONObject jObj = client.getLatestVersion(sysType, verNo);
		
		String serverFile = jObj.getString("serverFile");
		String fileName = jObj.getString("archiveFile");
		
		if(sysType.equals("PGS01")){
			fileName = "PGS01.ake";
		}else{
			fileName = "PGS02.ake";
		}
		
		String path = Util.getEnv();
		String realpath = path.substring(0, path.indexOf("webapps"));
		File PGS = new File(realpath,"PGS");
		if (!PGS.exists()) PGS.mkdirs();
		String clientFile = realpath.concat("PGS").concat(File.separator).concat(fileName);
		downloadFile(serverFile,clientFile);
		jObj.put("clientFile", clientFile);
		return jObj;
	}



	private void downloadFile(String serverFile,String clientFile) throws FileTransferException {
		MyFile myFile = new MyFile();
		myFile.setServerFile(serverFile);
		long position = 0;
		while (true) {
			myFile.setPosition(position);
			myFile = downloadFile(myFile);
			if (myFile.getBytes().length <= 0) {
				break;
			}
			OutputStream os = null;
			try {
				if (position != 0) {
					os = FileUtils.openOutputStream(new File(clientFile), true);
				} else {
					os = FileUtils
							.openOutputStream(new File(clientFile), false);
				}
				os.write(myFile.getBytes());
			} catch (IOException e) {
				throw new FileTransferException(e.getMessage(), e);
			} finally {
				IOUtils.closeQuietly(os);
			}
			position += myFile.getBytes().length;
		}
	}
	
	private MyFile downloadFile(MyFile myFile) throws FileTransferException {
		JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
		factoryBean.setServiceClass(FileExchange.class);
		factoryBean.setAddress(getRemoteUrl().concat("FileExchange"));
		FileExchange service = (FileExchange) factoryBean.create();
		return service.downloadFile(myFile);
	}
	/**
	 * 执行更新
	 * @param sysIDs
	 * @return
	 */
	public void excuteUpdate(String sysIDs){
		JSONObject jobj = new JSONObject();
		String result = "";
		List<Map> list = getSystemInfoBySysID(sysIDs);
		Map map = list.get(0);
		updateProcess(map.get("SysType").toString());		//执行文件解压及重启工作
//		
//		for(Map temp:list){
//			if(Util.isCon(temp.get("WaitingVerNo"))){
//				if(fileIsExists("PGS",temp.get("SysType").toString())){	//判断更新文件是否存在
//					updateProcess(temp.get("SysType").toString());		//执行文件解压及重启工作
//				}else{
//					if(temp.get("SysType").equals("PGS01")){
//						result += "请先下载Pgs Web程序最新版本！";
//					}else{
//						result += "请先下载PgsServer程序最新版本！";
//					}
//				}
//			}else{
//				if(temp.get("SysType").equals("PGS01")){
//					result += "Pgs Web程序已是最新！";
//				}else{
//					result += "PgsServer程序已是最新！";
//				}
//			}
//		}
//		jobj.element("done", true);
//		jobj.element("result", result);
//		return jobj;
	}
	
	public boolean fileIsExists(String packageName, String sysType){
		boolean rbool = false;
		String path = Util.getEnv();
		String realpath = path.substring(0, path.indexOf("webapps"));
		File PGS = new File(realpath,packageName);
		if(PGS.exists()){
			String fileName = "";
			if(sysType.equals("PGS01")){
				fileName = "PGS01.ake";
			}else{
				fileName = "PGS02.ake";
			}
			String clientFile = realpath.concat(packageName).concat(File.separator).concat(fileName);
			File cFile = new File(clientFile);
			if(cFile.exists()){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	public void updateProcess(String sysType){
		//解压缩文件BEMS01.ake
		String path = Util.getEnv();
		String realpath = path.substring(0, path.indexOf("webapps"));
		String bashPath = realpath.concat("PGS").concat(File.separator);
    	String filepath = "";
		String osName = System.getProperty("os.name");
//    	if(sysType.equals("PGS01")){//PGS Web程序更新
    		filepath = bashPath.concat("PGS01.ake");
    		try {
    			ZipUtil.upZipFile(filepath, bashPath);
    			Util.timer.cancel();
    			//重启系统
    			if (osName.matches("^(?i)Windows.*$")) {
    				String cmd = " cmd /c shutdown -r -t 50";
    				Runtime.getRuntime().exec(cmd);
    			} else {
    				String sh = "reboot";
    				Runtime.getRuntime().exec(new String[]{"/bin/bash","-c",sh});
    			}
			} catch (Exception e) {
				// TODO: handle exception
				Log.log("异常信息："+e);
			}
//    	}else{	//PgsServer程序更新
//    		filepath = bashPath.concat("PGS02.ake");
//    		try {
//    			ZipUtil.upZipFile(filepath, bashPath);
//			} catch (Exception e) {
//				// TODO: handle exception
//				Log.log("异常信息："+e);
//			}
//    	}
	}
}
