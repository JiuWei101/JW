package com.ie.its.remoteupdate;

import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.register.RegisterData;

import static com.ie.common.Util.*;

public class RemoteUpdateSql extends ExtendSql{
	
	public String version_list(String type){
		String querySql = "";
		if("count" == type){
			querySql +=" select count(*)";
		}else{
			querySql +=" select sei.SysID as sysID, sei.SysCode as sysCode, sei.F_DataCenterID as f_DataCenterID, sei.SysType as sysType, sei.CurrentVerNo as currentVerNo, sei.WaitingVerNo as waitingVerNo, sei.State as state,";
			querySql +=" sei.CurrentDt as currentDt, sei.LastDt as lastDt";
		}
		querySql +=" from sysextrainfo as sei";
		querySql +=" where 1=1";
		return querySql;
	}
	/**
	 * 获取更新历史记录
	 * @param type
	 * @return
	 */
	public String update_his_list(String type){
		String querySql="";
		if("count" == type){
			querySql +=" select count(*)";
		}else{
			querySql +=" select ugh.VerID as verID, sei.SysType as sysType, ugh.VerNo as verNo, ugh.CreatedDt as createdDt, ugh.VerDes as verDes";
		}
		querySql +=" from upgradehis ugh left join sysextrainfo sei on ugh.SysID = sei.SysID";
		querySql +=" where 1=1";
		return querySql;
	}
	
	public String getCurrentVersionMess(long sysID){
		String querySql = "select uh.VerNo as verNo,uh.CreatedDt as createdDt";
		querySql +=" from upgradehis uh";
		querySql +=" where uh.UploadState = '0' and uh.SysID = "+ toSqlVal(sysID);
		return querySql;
	}
	
	public String getSystemInfor(String sysIDs){
		String querySql = "";
		querySql +=" select sei.SysID as SysID, sei.SysCode as SysCode, sei.F_DataCenterID as F_DataCenterID, sei.SysType as SysType, sei.CurrentVerNo as CurrentVerNo, sei.WaitingVerNo as WaitingVerNo, sei.State as State,";
		querySql +=" sei.CurrentDt as CurrentDt, sei.LastDt as LastDt";
		querySql +=" from sysextrainfo as sei where";
		if(Util.isCon(sysIDs)){
			String[] str = sysIDs.split(";");
			for(int i=0; i<str.length; i++){
				if(i - str.length == -1){
					querySql +=" sei.SysID = "+ toSqlVal(Integer.valueOf(str[i]));
				}else{
					querySql +=" sei.SysID = "+ toSqlVal(Integer.valueOf(str[i])) + " or";
				}
			}
		}else{
			querySql +=" 1=1";
		}
		return querySql;
	}
	
	/**
	 * 更新系统额外信息表sql
	 * @param data
	 * @return
	 */
	public String updateExtraInfor(RemoteUpdateData data){
		String querySql = "";
		querySql += " update sysextrainfo sei set sei.CurrentVerNo =" + toSqlVal(data.getCurrentVerNo()) +",";
		querySql +=" sei.WaitingVerNo =" + toSqlVal(data.getWaitingVerNo());
		querySql +=" where sei.SysID =" + toSqlVal(data.getSysID());
		return querySql;
	}
	
	/**
	 * 更新系统升级历史表sql
	 * @param data
	 * @return
	 */
	public String updateUpgradeHis(RemoteUpdateData data){
		String querySql = "";
		querySql +=" update upgradehis ugh set ugh.VerNo =" + toSqlVal(data.getVerNo()) + ", ugh.UploadState =" + toSqlVal(data.getUploadState());
		querySql +=" where ugh.SysID =" + data.getSysID();
		return querySql;
	}
	
	/**
	 * 更新p_register的upgradeUrl
	 * @param data
	 * @return
	 */
	public String updateRegisterData(RegisterData data){
		String querySql = "";
		querySql +=" update p_register pr set pr.upgradeUrl =" + toSqlVal(data.getUpgradeUrl());
		return querySql;
	}
}
