package com.ie.its.remoteupdate;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.ie.common.Util;
import com.ie.frame.ExtendData;

public class RemoteUpdateData extends ExtendData{
	private int sysID;				//系统ID
	private String sysCode;			//系统编码
	private String f_DataCenterID;	//数据中心代码
	private String sysType;			//系统类别
	private String currentVerNo;	//当前版本
	private String waitingVerNo;	//待更新版本
	private String state;			//更新状态
	private String currentDt;			//本次更新时间
	private String lastDt;			//上次更新时间
	
	private int verID;				//版本ID
	private String verNo;			//版本编号
	private int uploadState;		//上传状态
	private int upgradeState;		//更新状态
	private String createdDt;			//更新时间
	private String verDesc;			//更新描述
	
	public int getSysID() {
		return sysID;
	}
	public void setSysID(int sysID) {
		this.sysID = sysID;
	}
	public String getSysCode() {
		return sysCode;
	}
	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
	public String getF_DataCenterID() {
		return f_DataCenterID;
	}
	public void setF_DataCenterID(String f_DataCenterID) {
		this.f_DataCenterID = f_DataCenterID;
	}
	public String getSysType() {
		return sysType;
	}
	public void setSysType(String sysType) {
		this.sysType = sysType;
	}
	public String getCurrentVerNo() {
		return currentVerNo;
	}
	public void setCurrentVerNo(String currentVerNo) {
		this.currentVerNo = currentVerNo;
	}
	public String getWaitingVerNo() {
		return waitingVerNo;
	}
	public void setWaitingVerNo(String waitingVerNo) {
		this.waitingVerNo = waitingVerNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getVerID() {
		return verID;
	}
	public void setVerID(int verID) {
		this.verID = verID;
	}
	public String getVerNo() {
		return verNo;
	}
	public void setVerNo(String verNo) {
		this.verNo = verNo;
	}
	public int getUploadState() {
		return uploadState;
	}
	public void setUploadState(int uploadState) {
		this.uploadState = uploadState;
	}
	public int getUpgradeState() {
		return upgradeState;
	}
	public void setUpgradeState(int upgradeState) {
		this.upgradeState = upgradeState;
	}
	public String getVerDesc() {
		return verDesc;
	}
	public void setVerDesc(String verDesc) {
		this.verDesc = verDesc;
	}
	public String getCurrentDt() {
		return currentDt;
	}
	public void setCurrentDt(String currentDt) {
		this.currentDt = Util.cutStr(currentDt,".");
	}
	public String getLastDt() {
		return lastDt;
	}
	public void setLastDt(String lastDt) {
		this.lastDt = Util.cutStr(lastDt, ".");
	}
	public String getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(String createdDt) {
		this.createdDt = Util.cutStr(createdDt,".");
	}
}
