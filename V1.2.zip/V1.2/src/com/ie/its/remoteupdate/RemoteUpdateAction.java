package com.ie.its.remoteupdate;

import java.io.File;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.register.RegisterData;

@SuppressWarnings("serial")
@Namespace("/remote_update")
@Results({@Result(name="list",location="/remoteupdate/available_version_list.jsp"),
		  @Result(name="ok",location="/success.jsp")})
public class RemoteUpdateAction extends ExtendActionSupport {
		private RemoteUpdateData data;
		private RegisterData rdata;
		public RegisterData getRdata() {
			return rdata;
		}

		public void setRdata(RegisterData rdata) {
			this.rdata = rdata;
		}

		@Autowired
		private RemoteUpdateService remoteupdateservice;
		
		private File myFile;
		private String myFileFileName;
		private String myFileFileContentType;
		
		public File getMyFile() {
			return myFile;
		}

		public void setMyFile(File myFile) {
			this.myFile = myFile;
		}

		public String getMyFileFileName() {
			return myFileFileName;
		}

		public void setMyFileFileName(String myFileFileName) {
			this.myFileFileName = myFileFileName;
		}

		public String getMyFileFileContentType() {
			return myFileFileContentType;
		}

		public void setMyFileFileContentType(String myFileFileContentType) {
			this.myFileFileContentType = myFileFileContentType;
		}

		public RemoteUpdateData getData() {
			return data;
		}

		public void setData(RemoteUpdateData data) {
			this.data = data;
		}

		public RemoteUpdateService getRemoteupdateservice() {
			return remoteupdateservice;
		}

		public void setRemoteupdateservice(RemoteUpdateService remoteupdateservice) {
			this.remoteupdateservice = remoteupdateservice;
		}

		public RemoteUpdateAction(){
			if(data == null){
				data = new RemoteUpdateData();
			}
		}
		
		/**
		 * 获取可用的版本列表
		 * @return
		 */
		@Action(value="available_version_list",results={@Result(name="success",location="/remoteupdate/available_version_list.jsp")})
		public String available_version_list(){
			data.setLang(request.getSession().getAttribute("lang").toString());
			//设置多语言
			setLang(data);
			data = remoteupdateservice.version_list(data);
			this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
			return SUCCESS;
		}
		
		/**
		 * 下载更新包
		 */
		@Action(value="download_package",results={@Result(type="json")})
		public void download_package(){
			
			JSONObject json =  new JSONObject();
			json = remoteupdateservice.downloadFileHandle(data.getCode_id());
//			json.element("success", true);
//			json.element("result", result);
			setJsonRes(json);
		}
		
		/**
		 * 上传更新包
		 */
		@Action(value="upload_package",results={@Result(type="json")})
		public void upload_package(){
			String path = StringManager.replaceAll(request.getRealPath("/"),"\\","/");
			path = path.substring(0, path.indexOf("webapps"));
		}
		
		@Action(value="get_upgradeurl",results={@Result(type="json")})
		public void getUpgradeUrl(){
			JSONObject json =  new JSONObject();
			String upgradeUrl = remoteupdateservice.getRemoteUrl();
			//rdata.setUpgradeUrl(upgradeUrl);
			json.element("success", true);
			json.element("upgradeUrl", upgradeUrl);
			setJsonRes(json);
		}
		
		@Action(value="set_upgradeurl",results={@Result(type="json")})
		public void updateUpgradeUrl(){
			JSONObject json =  new JSONObject();
			remoteupdateservice.setUpgradeUrl(rdata);
			json.element("success", true);
			setJsonRes(json);
		}
		
		@Action(value="update_his_list",results={@Result(name="success",location="/remoteupdate/update_version_history.jsp")})
		public String update_his_list(){
			data.setLang(request.getSession().getAttribute("lang").toString());
			//设置多语言
			setLang(data);
			data = remoteupdateservice.update_his_list(data);
			this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
			return SUCCESS;
		}
		
		/**
		 * 执行更新
		 */
		@Action(value="excute_update",results={@Result(type="json")})
		public void excute_update(){
//			data.setLang(request.getSession().getAttribute("lang").toString());
			//设置多语言
//			setLang(data);
//			remoteupdateservice.excuteUpdate(data.getCode_id());
//			JSONObject jobj = new JSONObject();
//			setJsonRes(jobj);
			String osName = System.getProperty("os.name");
    		try {
    			Util.timer.cancel();
    			//重启系统
    			if (osName.matches("^(?i)Windows.*$")) {
    				String cmd = "cmd.exe /c shutdown -r -t 50";
    				Runtime.getRuntime().exec(cmd);
    			} else {
    				String sh = "reboot";
    				Runtime.getRuntime().exec(new String[]{"/bin/bash","-c",sh});
    			}
			} catch (Exception e) {

			}		
		}
}
