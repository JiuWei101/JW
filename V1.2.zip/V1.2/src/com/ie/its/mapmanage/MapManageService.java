/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.mapmanage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ie.common.ConstantClass;
import com.ie.common.CopyUtil;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;
import com.ie.reverse.Line;
import com.ie.reverse.PathHead;
import com.ie.reverse.Point;
import com.ie.reverse.ReverseCommon;
import com.ie.reverse.Segment;

@Scope("prototype")
@Service
public class MapManageService extends ExtendService {
	private MapManageSql mapSql;

	public MapManageService() {
		mapSql = new MapManageSql();
	}
	

	public String getMapName(String id){
		String sqlStr = "select path from p_map where id='" + id + "'";
		String nameList = this.getJt().queryForObject(sqlStr, String.class);
		
		return nameList;
	}

	/**
	 * Description :查询地图．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_list(MapManageData data) {
		// 获得数量
		int count = this.getJt().queryForInt(mapSql.map_list(data, "count"));

		// 调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);

		// 返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList<MapManageData> rows = this.getJt()
				.<MapManageData> queryForListExt(mapSql.map_list(data, ""),
						data.getStart(), data.getLimit(), MapManageData.class);

		// 转换编码
		// for(MapManageData tempData:rows){
		// System.out.println(tempData.getId());
		// }

		data.setPer_data(rows);
		return data;
	}

	/**
	 * Description :保存地图．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_save(MapManageData data) {// edited by LLX 20120821
		data.setId(PrimaryId.getId().substring(0, 16));// 按时间生成地图ID，只取前16位，因为导入向导传参数时候只能传到16位
		getJt().execute(mapSql.map_save(data));
		return data;
	}

	/**
	 * Description :获得地图信息．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_get(MapManageData data) {
		getJt().queryForObjectExt(mapSql.map_get(data), data);

		Log.log(data.getPhysicalRegionId());
		return data;
	}

	/**
	 * Description :更新地图．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_update(MapManageData data) {
		// 如果上传文件 则先删除原有文件
		if (Util.isCon(data.getPath())) {
			String path = map_getPath(data.getId());

			// 如果文件名不同 则删除原来的文件
			if (!path.equals(data.getPath() + data.getFilename())) {
				deleteFile(path);
			}
		}

		getJt().execute(mapSql.map_update(data));
		return data;
	}

	/**
	 * Description :删除地图．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_delete(MapManageData data) {
		String[] id = data.getId().split(";");
		String[] sqlP_MapLogicRegion = new String[id.length];
		String[] sqlP_MapGuideRegion = new String[id.length];
		String[] sqlP_DetectorParaValue = new String[id.length];
		String[] sqlP_ParkingSpaceTask = new String[id.length];
		String[] sqlP_ScreenTask = new String[id.length];
		String[] sqlP_ScreenRegion = new String[id.length];
		String[] sqlP_ScreenParaValue = new String[id.length];
		String[] sqlP_ConfigTask = new String[id.length];
		String[] sqlP_ParkingSpace = new String[id.length];
		String[] sqlP_Detector = new String[id.length];
		String[] sqlP_Screen = new String[id.length];
		String[] sqlP_Controller = new String[id.length];
		String[] sql = new String[id.length];
		String[] mapPath = new String[id.length];
		String[] sqlP_ParkingSpaceOperationLog = new String[id.length];

		String[] sqlPointsRelation = new String[id.length]; // 存储删除点关系的sql语句
		String[] sqlPoints = new String[id.length]; // 存储删除地图点的sql语句
		String[] sqlShortestHead = new String[id.length]; // 存储删除路径主记录sql语句
		String[] sqlShortestLine = new String[id.length]; // 存储删除路径从记录sql语句
		// 首选获得所有文件路径
		for (int i = 0; i < id.length; i++) {
			mapPath[i] = map_getPath(id[i]);
		}

		// 删除数据库记录
		for (int i = 0; i < id.length; i++) {
			sqlP_ParkingSpaceOperationLog[i] = mapSql
					.delete_ParkingSpaceOperationLog(id[i]); // 停车出入数据Log表中数据
			sqlP_MapLogicRegion[i] = mapSql.map_deleteP_MapLogicRegion(id[i]); // 地图逻辑区域关系表
			sqlP_MapGuideRegion[i] = mapSql.map_deleteP_MapGuideRegion(id[i]); // 地图引导区域关系表
			sqlP_DetectorParaValue[i] = mapSql.map_deleteP_DetectorParaValue(id[i]); // 探测器参数值表
			sqlP_ParkingSpaceTask[i] = mapSql.map_deleteP_ParkingSpaceTask(id[i]); // 车位作业计划表
			sqlP_ParkingSpaceTask[i] = mapSql.map_deleteP_Colortacticstask(id[i]); // 
			sqlP_ScreenTask[i] = mapSql.map_deleteP_ScreenTask(id[i]); // 引导屏作业计划表
			sqlP_ScreenRegion[i] = mapSql.map_deleteP_ScreenRegion(id[i]); // 引导屏所引导的区域组表
			sqlP_ScreenParaValue[i] = mapSql.map_deleteP_ScreenParaValue(id[i]); // 屏类型参数值表
			sqlP_ConfigTask[i] = mapSql.map_deleteP_ConfigTask(id[i]); // 下发配置任务表
			sqlP_ParkingSpace[i] = mapSql.map_deleteP_ParkingSpace(id[i]); // 车位信息表
			sqlP_Detector[i] = mapSql.map_deleteP_Detector(id[i]); // 探测器表
			sqlP_Screen[i] = mapSql.map_deleteP_Screen(id[i]); // 引导屏表
			sqlP_Controller[i] = mapSql.map_deleteP_Controller(id[i]); // 控制器表

			sqlPointsRelation[i] = mapSql.delete_headnodessubs(id[i]); // 删除点关系表中数据
			sqlPoints[i] = mapSql.delete_headnodes(id[i]); // 删除点数据
			sqlShortestLine[i] = mapSql.delete_shortestpathinofline(id[i]);
			sqlShortestHead[i] = mapSql.delete_p_shortestpathinofhead(id[i]);
			sql[i] = mapSql.map_delete(id[i]); // 地图表

		}

		getJt().batchUpdate(sqlP_ParkingSpaceOperationLog);
		getJt().batchUpdate(sqlP_MapLogicRegion);
		getJt().batchUpdate(sqlP_MapGuideRegion);
		getJt().batchUpdate(sqlP_DetectorParaValue);
		getJt().batchUpdate(sqlP_ParkingSpaceTask);
		getJt().batchUpdate(sqlP_ScreenTask);
		getJt().batchUpdate(sqlP_ScreenRegion);
		getJt().batchUpdate(sqlP_ScreenParaValue);
		getJt().batchUpdate(sqlP_ConfigTask);
		getJt().batchUpdate(sqlP_ParkingSpace);
		getJt().batchUpdate(sqlP_Detector);
		getJt().batchUpdate(sqlP_Screen);
		getJt().batchUpdate(sqlP_Controller);
		getJt().batchUpdate(sqlPointsRelation);
		getJt().batchUpdate(sqlPoints);
		getJt().batchUpdate(sqlShortestLine);
		getJt().batchUpdate(sqlShortestHead);
		getJt().batchUpdate(sql);

		// 删除文件
		for (int i = 0; i < mapPath.length; i++) {
			if (Util.isCon(mapPath[i])) {
				deleteFile(mapPath[i]);
			}
		}

		return data;
	}

	/**
	 * Description :检查地图是否已经导入文件
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public boolean check_mapIsImpFile(MapManageData data) {
		boolean flag = true;
		Log.log(map_getSrc(data.getId()));
		if (!Util.isCon(map_getSrc(data.getId()))) {
			flag = false;
		}
		Log.log(flag);
		return flag;
	}

	/**
	 * Description :检查地图是否已经导入数据
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public boolean check_mapIsImpData(MapManageData data) {
		boolean flag = true;
		int count = getJt().queryForInt(mapSql.map_getParkSum(data.getId()));

		if (count > 0) {
			flag = false;
		}
		return flag;
	}

	/**
	 * Description :获得地图文件全称 包含盘符路径．
	 * 
	 * @param :String
	 * @return :String
	 * @throws :Exception
	 */
	private String map_getPath(String id) {
		MapManageData data = new MapManageData();
		getJt().queryForObjectExt(mapSql.map_getSrc(id), data);

		return data.getPath();

	}

	/**
	 * Description :删除文件．
	 * 
	 * @param :String
	 * @return :
	 * @throws :Exception
	 */
	private void deleteFile(String path) {
		File file = new File(path);
		file.delete();
	}

	/**
	 * Description :获得物理区域list．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public List get_phyRegionCode() {
		List codeList = new ArrayList();

		codeList = getJt().queryForListExt(mapSql.get_phyRegionCode(),
				MapManageData.class);
		return codeList;
	}

	/**
	 * Description : 检查上传的文件名是否重复
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public boolean map_impcheck(MapManageData data) {
		boolean flag = true;

		int count = this.getJt().queryForInt(mapSql.map_impcheck(data));

		if (count > 0) {
			flag = false;
		}

		return flag;
	}

	/**
	 * Description :保存上传地图路径．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	public MapManageData map_impsave(MapManageData data) {
		getJt().execute(mapSql.map_impsave(data));
		return data;
	}

	/**
	 * Description :获得地图路径．
	 * 
	 * @param :MapManageData
	 * @return :String
	 * @throws :Exception
	 */
	public String map_getSrc(String id) {
		MapManageData data = new MapManageData();
		String path = data.getPath();
		getJt().queryForObjectExt(mapSql.map_getSrc(id), data);

		if (Util.isCon(data.getPath())) {
			path = splitMapSrc(data.getPath());
		} else {
			return "";
		}

		return path;
	}

	private String splitMapSrc(String path) {
		String src = "";
		String path_split[] = path.split(ConstantClass.MAP_DIR);
		src = "../" + ConstantClass.MAP_DIR + path_split[1];
		return src;
	}
	
	/**
	 * 处理“探测器”数据
	 * @param data 源数据
	 * @param sysModel	系统类型
	 * @param condMap	管理器Map
	 * @param conIdSet	管理器编码Set
	 * @param sqlCon	管理器插入Sql
	 * @param sList		线段集合
	 * @param linePointList 点集合
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map handleDetector(MapManageData data, String sysModel, HashMap condMap, Set<String> conIdSet, List<String> sqlCon, List<Segment> sList, List<Point> linePointList){
		Map rmap = new HashMap();
		List<Point> carPointList = new ArrayList<Point>(); // 车位点集合
		List<String> sqlDeDetected = new ArrayList<String>(); // 超声波探测器插入的sql语句List
		List<String> sqlParkingSpace = new ArrayList<String>(); // 插入车位的sql语句List
		List<String> drepeat = new ArrayList<String>();// 存放与数据库重复的探测器
		boolean flag = true;
		ControllerData controllerData = new ControllerData();
		String[] args = data.getImp_data_de().split(",");// 前台数据用,分割
		// 解析参数,获取管理器id
		for (int i = 0; i < args.length; i++) {
			String con_id = ""; // 管理器id
			con_id = getCtlCode(sysModel, args[i]);
			// 用set控制重复的管理器id
			conIdSet.add(con_id);
		}
		// 遍历管理器set 组成管理器插入语句
		for (Iterator<String> iter = conIdSet.iterator(); iter.hasNext();) {
			String con_id = iter.next();

			controllerData.setId(PrimaryId.getId());
			controllerData.setAddr(con_id); // 管理器id
			controllerData.setMapId(data.getId()); // 地图id
			//edit by jiangyf 修改状态为1，标示离线状态
			controllerData.setStatus("1"); // 状态默认为0
			
			/*
			 * edit by wenzr,2012.7.22 18:05
			 * 根据小莫的意见，厦门项目中，多个地图可能共用同一个管理器,如A:005;B:005 处理意见：
			 * 传入地图编号一起检查管理编号是否重复，如果管理器id重复但地图id不同，则取原来的序列号，地图号也用原来的？？？
			 */
			// 键值 key:控制器地址 value:控制器id
			// condMap.put(controllerData.getAddr(),
			// controllerData.getId());//该代码有问题，导致管理器ID丢失。by wenzr
			if (!condMap.containsKey(controllerData.getAddr())) {
				condMap.put(controllerData.getAddr(),getControllerSeqId(controllerData.getId(),controllerData.getAddr()));
				if (!isExitCon(controllerData.getAddr())) {
					sqlCon.add(mapSql.save_con(controllerData));
				}
			}

		}

		// 解析参数
		for (int i = 0; i < args.length; i++) {
			String detected_id = "", con_id = ""; // 探测器id 管理器id
			DetectorConfigData detectorConfigData = new DetectorConfigData();
			ParkingSpaceData parkingSpaceData = new ParkingSpaceData();
			con_id = getCtlCode(sysModel, args[i]);
			detected_id = getDetCode(sysModel, args[i]);
			// 用set控制重复的管理器id
			conIdSet.add(con_id);
			// 探测器开始
			detectorConfigData.setId(PrimaryId.getId()); // 探测器id
															// 现在用生成主键
			detectorConfigData.setMapId(data.getId()); // 地图id
			detectorConfigData.setControllerId(condMap.get(con_id).toString()); // 管理器id
			detectorConfigData.setAddr(detected_id); // 暂时存探测器id
			detectorConfigData.setDetectorTypeId(getEqmNO(sysModel)); // 1为超声波，2为地感，3为地磁，4为视频
			// 而且flash无返回
			String ctrDetCode = "";
			if (sysModel.equals("2")) { // 当前系统类型为视频
				ctrDetCode = args[i].substring(0, args[i].indexOf("|"));
				String x_Y = args[i].substring(args[i].indexOf("|") + 1, args[i].length());
				// System.out.println(x_Y);
				String[] axises = x_Y.split(";");
				double x_axis = Double.parseDouble(axises[0]);
				double y_axis = Double.parseDouble(axises[1]);
				detectorConfigData.setX_axis(x_axis);
				detectorConfigData.setY_axis(y_axis);
				if (sList.size() > 0) { // 当存在线段时，才进行车位的求垂直点和最短线段
					String formerCode = ctrDetCode.replace('.', '_');
					Point carPoint = new Point(x_axis, y_axis,formerCode, ctrDetCode);
					Map map = ReverseCommon.getNearestPoint(linePointList, carPoint);
					Point point = (Point) map.get("point");
					double len = (Double) map.get("len");
					Map lmap = ReverseCommon.getTheShortestDistanceOfLine(sList,carPoint); // 每个点的最近直线及距离
					Line shortestLine = (Line) lmap.get("line");
					double distance = (Double) lmap.get("distance");
					if (shortestLine == null || len < distance) {// “无垂直点”或者“距离最近点路径小于垂直点路径”
						detectorConfigData.setOnepoint_id(point.getId());
					} else {
						Point crossPoint = shortestLine.getpCross(); // 车位点在最近直线上的垂直点
						Point sPoint = shortestLine.getPs();
						Point ePoint = shortestLine.getPe();
						detectorConfigData.setOnepoint_id(sPoint.getId());
						detectorConfigData.setAnopoint_id(ePoint.getId());
						detectorConfigData.setVertical_x_axis(crossPoint.getX());
						detectorConfigData.setVertical_y_axis(crossPoint.getY());
					}
					carPointList.add(carPoint);
				}
			} else {
				ctrDetCode = args[i];
			}
			detectorConfigData.setCode(ctrDetCode); // [管理器探测器]
			detectorConfigData.setStatus("1"); // 状态默认1
			detectorConfigData.setEnable("1"); // 默认1 启用
			if (!isExit(detectorConfigData.getCode())) {
				sqlDeDetected.add(mapSql.save_detector(detectorConfigData));
				parkingSpaceData.setId(PrimaryId.getId()); // 车位id
				parkingSpaceData.setDetectorId(detectorConfigData.getId()); // 探测器id
				parkingSpaceData.setPhysicalRegionId(data.getPhysicalRegionId());// 物理区域id
				sqlParkingSpace.add(mapSql.save_parkingSpace(parkingSpaceData));
			} else {// 与数据库重复的探测器地址
				drepeat.add(get_exit_dmess(detectorConfigData.getCode()).getString("code"));
				flag = false;
			}
		}
		rmap.put("flag", flag);
		rmap.put("carPointList", carPointList);
		rmap.put("sqlDeDetected", sqlDeDetected);
		rmap.put("sqlParkingSpace", sqlParkingSpace);
		rmap.put("drepeat", drepeat);
		return rmap;
	}
	
	/**
	 * 处理“地感”数据
	 * @param data	源数据
	 * @param sysModel 系统类型
	 * @param condMap	管理器Map
	 * @param conIdSet	管理器编码Set
	 * @param sqlCon	管理器插入Sql语句
	 * @param flag		全局标识
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map handleGroundor(MapManageData data, String sysModel, HashMap condMap, Set<String> conIdSet, List<String> sqlCon){
		Map rmap = new HashMap();
		List<String> sqlGrDetected = new ArrayList<String>(); // 地感探测器插入的sql语句List
		List<String> grepeat = new ArrayList<String>();// 存放与数据库重复的地感
		boolean flag = true;
		ControllerData controllerData = new ControllerData();
		String[] args = data.getImp_data_gr().split(","); // 前台数据用,分割
		// 解析参数
		for (int i = 0; i < args.length; i++) {
			String con_id = ""; // 管理器id
			// 之所以除以2 是因为字符是由[管理器探测器]组成的 其中每个单元的长度可能变化 但是长度一致
			// 所以先除以二再获取字符
			/**
			 * 为兼容地磁管理器地址（6位）+地磁地址（3位），进行改动，add by wj 2013-01-29
			 */
			con_id = getCtlCode(sysModel, args[i]);
			// 用set控制重复的管理器id
			conIdSet.add(con_id);
		}
		// 遍历管理器set 组成管理器插入语句
		for (Iterator<String> iter = conIdSet.iterator(); iter.hasNext();) {
			String con_id = iter.next();
			controllerData.setId(PrimaryId.getId());
			controllerData.setAddr(con_id); // 管理器id
			controllerData.setMapId(data.getId()); // 地图id
			controllerData.setStatus("0"); // 状态默认为0
			if (!condMap.containsKey(controllerData.getAddr())) {
				condMap.put(controllerData.getAddr(),getControllerSeqId(controllerData.getId(),controllerData.getAddr()));
				if ((!isExitCon(controllerData.getAddr()))) {
					sqlCon.add(mapSql.save_con(controllerData));
				}
			}
		}

		for (int i = 0; i < args.length; i++) {
			String detected_id = "", con_id = ""; // 探测器id 管理器id
			DetectorConfigData detectorConfigData = new DetectorConfigData();
			// 之所以除以2 是因为字符是由[管理器探测器]组成的 其中每个单元的长度可能变化 但是长度一致
			// 所以先除以二再获取字符
			/**
			 * 为兼容地磁管理器地址（6位）+地磁地址（3位），进行改动，add by wj 2013-01-29
			 */
			con_id = getCtlCode(sysModel, args[i]);
			detected_id = getDetCode(sysModel, args[i]);
			if (!isExit(args[i]) && Util.isCon(args[i])) {
				// 探测器开始
				detectorConfigData.setId(PrimaryId.getId()); // 探测器id
				// 现在用生成主键
				detectorConfigData.setMapId(data.getId()); // 地图id
				detectorConfigData.setControllerId(condMap.get(con_id)
						.toString());
				detectorConfigData.setAddr(detected_id); // 暂时存探测器id
				detectorConfigData.setDetectorTypeId("2"); // 默认写2 代表是地感
				detectorConfigData.setCode(args[i]); // [管理器探测器]
				detectorConfigData.setStatus("1"); // 状态默认1
				detectorConfigData.setEnable("1"); // 默认1 启用
				sqlGrDetected.add(mapSql.save_detector(detectorConfigData));// 生成地感插入sql语句
			} else {// 保存与数据库重复的地感探测器列表
				grepeat.add(get_exit_dmess(args[i]).getString("code"));
				flag = false;
			}

		}
		rmap.put("flag", flag);
		rmap.put("sqlGrDetected", sqlGrDetected);
		rmap.put("grepeat", grepeat);
		return rmap;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map handleScreen(MapManageData data){
		Map rmap = new HashMap();
		boolean flag = true;
		List<String> sqlScreen = new ArrayList<String>(); // 屏信息插入的sql语句List
		List<String> srepeat = new ArrayList<String>();// 存放与数据库重复的引导屏
		String[] args = data.getImp_data_sc().split(","); // 前台数据用,分割
		for (int i = 0; i < args.length; i++) {
			ScreenData screenData = new ScreenData();
			// 屏编号组成 字母+3位组地址+2位屏地址
			screenData.setId(PrimaryId.getId()); // 引导屏id
			screenData.setMapId(data.getId()); // 引导屏地图id
			screenData.setCode(args[i]); // code
			screenData.setGrpAddr(args[i].substring(1, 4)); // 3位组地址
			screenData.setAddr(args[i].substring(4, 6)); // 2位屏地址
			screenData.setStatus("1"); // 状态默认1
			if (!isExitScreen(screenData.getCode())) {// 判断code是否重复
				sqlScreen.add(mapSql.save_screen(screenData));
			} else {// 保存与数据库重复的条屏编码
				srepeat.add(get_exit_smess(args[i]).getString("code"));
				flag = false;
			}
		}
		rmap.put("flag", flag);
		rmap.put("sqlScreen", sqlScreen);
		rmap.put("srepeat", srepeat);
		return rmap;
	}
	/**
	 * Description :导入地图数据．
	 * 
	 * @param :MapManageData
	 * @return :String
	 * @throws :Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public MapManageData map_savedata(MapManageData data, String lang)throws Exception {
		HashMap condMap = new HashMap();
		Set<String> conIdSet = new HashSet<String>();
		this.map_get(data); // 查询地图物理区域
		// TODO
		boolean flag = true;// 验证地图数据，如果信息无误则置为true LLX 0823
		List<String> sqlDeDetected = new ArrayList<String>(); // 超声波探测器插入的sql语句List
		List<String> sqlParkingSpace = new ArrayList<String>(); // 插入车位的sql语句List
		List<String> sqlCon = new ArrayList<String>(); // 插入管理器的sql语句List
		
		List<String> sqlGrDetected = new ArrayList<String>(); // 地感探测器插入的sql语句List
		
		List<String> sqlScreen = new ArrayList<String>(); // 屏信息插入的sql语句List

		List<String> drepeat = new ArrayList<String>();// 存放与数据库重复的探测器
		List<String> srepeat = new ArrayList<String>();// 存放与数据库重复的引导屏
		
		List<String> grepeat = new ArrayList<String>();// 存放与数据库重复的地感

		List errorArr = new ArrayList(); // 存放路径点，查询机点，电梯口点有误的数据
		String sysModel = queryForSystemModel(); // 获取系统的类型
		
		List<Point> carPointList = new ArrayList<Point>(); // 车位点集合
		List<Point> linePointList = new ArrayList<Point>(); // 路径点集合
		List<Segment> sList = new ArrayList<Segment>(); // 连通线段集合

		List<String> sqllinePointList = new ArrayList<String>(); // 路径点插入sql语句列表
		List<String> sqlPoint = new ArrayList<String>(); // 路径点关系插入sql语句列表
		
		String drpt = null;	//存放地图内探测器编码重复
		try {
			Map vmap = verifyPoint(data);//点数据校验
			flag = (Boolean)vmap.get("flag");
			errorArr = (List)vmap.get("errorArr");
			
			if (flag) {
				Map smap = handlePoints(data);	//处理点数据
				linePointList = (ArrayList)smap.get("linePointList");
				sList = (ArrayList)smap.get("sList");
				sqllinePointList = (ArrayList)smap.get("sqllinePointList");
				sqlPoint = (ArrayList)smap.get("sqlPoint");
			}

			// 首先处理探测器数据de
			if (Util.isCon(data.getImp_data_de())) {
				drpt = judgeRepeat(data.getImp_data_de().split(","), sysModel);
				if(Util.isCon(drpt)){
					flag = false;
				}else{
					if (sysModel.equals("2")) { // 当前系统类型为视频
						data.setImp_data_de(data.getImp_data_de().replace('_', '.'));
					}
					Map dmap = handleDetector(data, sysModel, condMap, conIdSet, sqlCon, sList, linePointList);
					if(!(Boolean)dmap.get("flag")){
						flag = (Boolean)dmap.get("flag");
					}
					carPointList = (ArrayList)dmap.get("carPointList");
					sqlDeDetected = (ArrayList)dmap.get("sqlDeDetected");
					sqlParkingSpace = (ArrayList)dmap.get("sqlParkingSpace");
					drepeat = (ArrayList)dmap.get("drepeat");
				}
			}

			/**
			 * 处理地感信息
			 */
			if (Util.isCon(data.getImp_data_gr())) {
				Map gmap = handleGroundor(data, sysModel, condMap, conIdSet, sqlCon);
				if(!(Boolean)gmap.get("flag")){
					flag = (Boolean)gmap.get("flag");
				}
				sqlGrDetected = (ArrayList)gmap.get("sqlGrDetected");
				grepeat = (ArrayList)gmap.get("grepeat");
			}
			/***
			 * 处理引导屏信息
			 */
			if (Util.isCon(data.getImp_data_sc())) {
				Map smap = handleScreen(data);
				if(!(Boolean)smap.get("flag")){
					flag = (Boolean)smap.get("flag");
				}
				sqlScreen = (ArrayList)smap.get("sqlScreen");
				srepeat = (ArrayList)smap.get("srepeat");
			}
			/**
			 * 批量执行sql
			 */
			if (flag) {
				// 由于外键关系 先执行管理器插入 再插入探测器
				if (sqlCon.size() > 0) {
					for (int i = 0; i < sqlCon.size(); i++) {
						getJt().update(sqlCon.get(i));
					}
				}
				// 路径点及查询机点插入
				if (sqllinePointList.size() > 0) {
					for (int i = 0; i < sqllinePointList.size(); i++) {
						getJt().update(sqllinePointList.get(i));
					}
				}
				// 路径点及查询机点关系插入
				if (sqlPoint.size() > 0) {
					for (int i = 0; i < sqlPoint.size(); i++) {
						getJt().update(sqlPoint.get(i));
					}
				}
				if (sqlDeDetected.size() > 0) {// 超声波探测器插入sql
					for (int i = 0; i < sqlDeDetected.size(); i++) {
						getJt().update(sqlDeDetected.get(i));
					}
				}
				if (sqlGrDetected.size() > 0) {// 地感探测器插入sql
					for (int i = 0; i < sqlGrDetected.size(); i++) {
						getJt().update(sqlGrDetected.get(i));
					}
				}
				if (sqlParkingSpace.size() > 0) {// 车位插入sql
					for (int i = 0; i < sqlParkingSpace.size(); i++) {
						getJt().update(sqlParkingSpace.get(i));
					}
				}
				if (sqlScreen.size() > 0) {// 屏信息插入sql
					for (int i = 0; i < sqlScreen.size(); i++) {
						getJt().update(sqlScreen.get(i));
					}
				}
				// 更新车位导入数量
				data.setParkingSum(sqlParkingSpace.size());
				// 更新屏导入数量
				data.setScreenSum(sqlScreen.size());
				// 更新导入数量
				getJt().execute(mapSql.update_impCount(data));
				// 将地图是否字段 置为1
				getJt().execute(mapSql.updateMap(data));
				// 如果系统是视频类型，计算最短路径和为条屏分配管理器
				if (sysModel.equals("2")) {
					Reassignment(data.getId());
					getAllShortestPaths(data.getId());
				}
			} else {// flag为false 说明地图文件有问题 抛出异常
				if (drepeat.size() > 0) {// 车位编码与数据库重复
					String dstr = "";
					for (int i = 0; i < drepeat.size(); i++) {
						dstr += drepeat.get(i) + ",";
					}
					dstr = dstr.substring(0, dstr.length() - 1);
					data.setDrepeat(dstr);
				}
				if (srepeat.size() > 0) {// 条屏编码与数据库重复
					String sstr = "";
					for (int i = 0; i < srepeat.size(); i++) {
						sstr += srepeat.get(i) + ",";
					}
					sstr = sstr.substring(0, sstr.length() - 1);
					data.setSrepeat(sstr);
				}
				if (grepeat.size() > 0) {// 地感编码与数据库重复
					String gstr = "";
					for (int i = 0; i < grepeat.size(); i++) {
						gstr += grepeat.get(i) + ",";
					}
					gstr = gstr.substring(0, gstr.length() - 1);
					data.setGrepeat(gstr);
				}
				if (errorArr.size() > 0) {
					String gstr = "";
					for (int i = 0; i < errorArr.size(); i++) {
						gstr += errorArr.get(i) + " ;";
					}
					gstr = gstr.substring(0, gstr.length() - 1);
					data.setPointsError(gstr);
				}
				if(Util.isCon(drpt)){
					data.setDetectorError(drpt);
				}
			}
			data.setErrorflag(flag);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	/**
	 * 将引导屏按管理器分组（视频类型和无线地磁类型）
	 * 
	 * @param map_id
	 */
	public void Reassignment(String mapId) {
		List<ControllerData> ctlList = this.getJt().queryForListExt(
				mapSql.get_Controllers(mapId), ControllerData.class);// 所有未使用管理器
		List<ScreenData> scrList = this.getJt().queryForListExt(
				mapSql.get_Screens(mapId), ScreenData.class);// 所有未绑定管理器的条屏
		if (ctlList.size() > 0 && scrList.size() > 0) {
			String[] updateScreenSql = new String[scrList.size()]; // 更新条屏的sql语句
			if (ctlList.size() * ConstantClass.CTR_SCR_NUM >= scrList.size()) { // 管理器数量乘以设置数量大于条屏数量情况
				int num = scrList.size() % ConstantClass.CTR_SCR_NUM == 0 ? scrList
						.size() / ConstantClass.CTR_SCR_NUM
						: scrList.size() / ConstantClass.CTR_SCR_NUM + 1;
				for (int i = 0; i < num; i++) {
					int templ = i * ConstantClass.CTR_SCR_NUM;
					int temp = (i + 1) * ConstantClass.CTR_SCR_NUM;
					for (int j = templ; j < temp; j++) {
						if (j < scrList.size()) {
							updateScreenSql[j] = mapSql.update_screen(scrList
									.get(j).getId(), ctlList.get(i).getId());
						} else {
							break;
						}
					}
				}
			} else {

			}
			this.getJt().batchUpdate(updateScreenSql); // 更新条屏管理器
		}
	}

	/**
	 * 处理生成所有的查询机点和车位点的最短路径，并存入数据库
	 * 
	 * @param map_id
	 *            地图id
	 * @throws IOException
	 */
	public void getAllShortestPaths(String map_id) throws IOException {
		List<Point> allPoints = this.getJt().queryForListExt(mapSql.get_headnodes(map_id), Point.class); // 获取所有的基础点（路径点和查询机点）
		// 获取所有的探测器信息
		String dmessSql = "select * from p_detector where mapId ="+ Util.toSqlVal(map_id);
		List<DetectorConfigData> allcarList = this.getJt().queryForListExt(dmessSql, DetectorConfigData.class);
		// 目前先只根据p_pathnodeinfohead算出所有的连通关系
		for (int i = 0; i < allPoints.size(); i++) {
			Point tempPoint = allPoints.get(i);
			String pName = tempPoint.getName();
			String[] pNameStr = pName.split("\\-");
			String flashName = pNameStr[1];
			List<Point> subPoints = new ArrayList<Point>();
			if (flashName.indexOf(",") != -1) {
				String[] subPointsStr = flashName.split(",");
				for (int j = 0; j < subPointsStr.length; j++) {
					Point subPoint = new Point(0, 0, "", subPointsStr[j]);
					subPoints.add(subPoint);
				}
			} else {
				Point subPoint = new Point(0, 0, "", flashName);
				subPoints.add(subPoint);
			}
			tempPoint.setSubPoints(subPoints);
		}

		for (int i = 0; i < allPoints.size(); i++) {
			Point aPoint = allPoints.get(i);
			List<Point> subPoints = aPoint.getSubPoints();
			for (int k = 0; k < subPoints.size(); k++) {
				Point subPoint = subPoints.get(k);
				for (int j = 0; j < allPoints.size(); j++) {
					Point linePoint = allPoints.get(j);
					if (subPoint.getCode().equals(linePoint.getCode())) {
						subPoint.setId(linePoint.getId());
						subPoint.setName(linePoint.getName());
						subPoint.setX(linePoint.getX());
						subPoint.setY(linePoint.getY());
					}
				}
			}
		}
		List<Point> allPointList = new ArrayList<Point>(); // 所有起始点，包括查询机点和电梯口点
		List<Point> machinePointList = new ArrayList<Point>(); // 获取所有的查询机点
		List<Point> liftEntranceList = new ArrayList<Point>(); // 获取所有的电梯口点
		for (int i = 0; i < allPoints.size(); i++) {
			String temp = allPoints.get(i).getIfcarsearchpc();
			//增加了“二维码点”，与“查询机点”性质一样
//			if (temp.equals("1")) {
//				machinePointList.add(allPoints.get(i));
//			} else if (temp.equals("2")) {
//				liftEntranceList.add(allPoints.get(i));
//			}
			if(temp.equals("1") || temp.equals("3")){
				machinePointList.add(allPoints.get(i));
			}else if(temp.equals("2")){
				liftEntranceList.add(allPoints.get(i));
			}
		}
		allPointList.addAll(machinePointList);
		allPointList.addAll(liftEntranceList);

		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter("/Result.txt", true);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int count = 0;
		for (int i = 0; i < allcarList.size(); i++) {
			String[] sqlShortLineHead = new String[allPointList.size()]; // 存储最短路径起终sql
			List<Point> copyOfallPoints = new ArrayList<Point>(); // 所有路径点和查询机点集合副本
			try {
				copyOfallPoints = (List<Point>) CopyUtil.copyBySerialize(allPoints); // 深层复制原始点集
			} catch (Exception e) {
				e.printStackTrace();
			}
			DetectorConfigData carMess = allcarList.get(i);

			Point carPoint = new Point(carMess.getX_axis(),carMess.getY_axis(), carMess.getCode().replace(".", "_"),carMess.getCode(), carMess.getMapId());
			List<Point> newCopy = null;
			if (Util.isCon(carMess.getAnopoint_id())&& Util.isCon(carMess.getOnepoint_id())) {// 有垂直点的车位点
				Point carCrossPoint = new Point(carMess.getVertical_x_axis(),carMess.getVertical_y_axis(), "", "cross",carMess.getMapId());
				String onepoint_id = carMess.getOnepoint_id();
				String anopoint_id = carMess.getAnopoint_id();
				// 添加了车位垂直点和连通关系的新矩阵
				newCopy = ReverseCommon.getNewPointList(copyOfallPoints,onepoint_id, anopoint_id, carCrossPoint, carPoint);
			} else {// 无垂直点的车位点
				String onepoint_id = carMess.getOnepoint_id();
				newCopy = ReverseCommon.getNewPointList(copyOfallPoints,onepoint_id, carPoint);
			}
			double[][] result = ReverseCommon.getMatrix(newCopy); // 权值矩阵

			for (int j = 0; j < allPointList.size(); j++) { // 遍历查询机及电梯口点集，即起点集
				double[][] resultCopy = null;
				try {
					resultCopy = (double[][]) CopyUtil.copyBySerialize(result); // 深层复制原始点集
				} catch (Exception e) {
					e.printStackTrace();
				}
				Point startPoint = allPointList.get(j);
				count++;
				Map map = ReverseCommon.Dijsktra(fileWriter, resultCopy,newCopy, startPoint, carPoint);
				// System.out.println(map.get("path"));
				List<Point> rlist = (List<Point>) map.get("list");
				double weight = (Double) map.get("path");
				PathHead ph = new PathHead(PrimaryId.getId(), map_id,startPoint.getId(), carMess.getId(), weight);
				String headSql = mapSql.save_shortlineheads(ph);
				this.getJt().update(headSql);
				/*
				 * for (int i1=0;i1<result.length;i1++){ for( int
				 * j1=0;j1<=result[1].length-1;j1++){ if(j==result[1].length-1){
				 * System.out.print(result[i1][j1]); } else
				 * System.out.print(result[i1][j1]+"  ,  "); }
				 * System.out.println(""); }
				 */
				StringBuilder sb = new StringBuilder();
				for (int k = 0; k < rlist.size(); k++) {
					Point temp = rlist.get(k);
					sb.append(temp.getCode() + "(" + temp.getMapId() + ")"+ "-->");
				}
				//Log.log(sb.toString());
				if (rlist.size() > 2) {
					String[] sqlPathSubs = new String[rlist.size() - 2];
					for (int l = 1; l < rlist.size() - 1; l++) {
						Point p = rlist.get(l);
						if (!p.getCode().equals("cross")) {
							PathHead pd = new PathHead(ph.getId(), p.getId(), l);
							sqlPathSubs[l - 1] = mapSql.save_shortlinesubs(pd);
						}
					}
					this.getJt().batchUpdate(sqlPathSubs);
				}
			}

		}
		for (int i = 0; i < liftEntranceList.size(); i++) {
			List<Point> copyOfallPoints = new ArrayList<Point>(); // 所有路径点和查询机点集合副本
			try {
				copyOfallPoints = (List<Point>) CopyUtil.copyBySerialize(allPoints); // 深层复制原始点集
			} catch (Exception e) {
				e.printStackTrace();
			}
			Point liftPoint = liftEntranceList.get(i);// 终点，即电梯入口点
			double[][] result = ReverseCommon.getMatrix(copyOfallPoints); // 权值矩阵
			for (int j = 0; j < machinePointList.size(); j++) {
				double[][] resultCopy = null;
				try {
					resultCopy = (double[][]) CopyUtil.copyBySerialize(result); // 深层复制原始点集
				} catch (Exception e) {
					e.printStackTrace();
				}
				Point startPoint = machinePointList.get(j); // 起点，即查询机点
				count++;
				Map map = ReverseCommon.Dijsktra(fileWriter, resultCopy,copyOfallPoints, startPoint, liftPoint);
				// System.out.println(map.get("path"));
				List<Point> rlist = (List<Point>) map.get("list");
				double weight = (Double) map.get("path");
				PathHead ph = new PathHead(PrimaryId.getId(), map_id,startPoint.getId(), liftPoint.getId(), weight);
				String headSql = mapSql.save_shortlineheads(ph);
				this.getJt().update(headSql);
				StringBuilder sb = new StringBuilder();
				for (int k = 0; k < rlist.size(); k++) {
					Point temp = rlist.get(k);
					sb.append(temp.getCode() + "(" + temp.getMapId() + ")"+ "-->");
				}
				//Log.log(sb.toString());
				if (rlist.size() > 2) {
					String[] sqlPathSubs = new String[rlist.size() - 2];
					for (int l = 1; l < rlist.size() - 1; l++) {
						Point p = rlist.get(l);
						PathHead pd = new PathHead(ph.getId(), p.getId(), l);
						sqlPathSubs[l - 1] = mapSql.save_shortlinesubs(pd);
					}
					this.getJt().batchUpdate(sqlPathSubs);
				}
			}
		}
		fileWriter.write("\r\n");
		fileWriter.write("总共测试车位点" + allcarList.size() + "个,查询机点+"
				+ machinePointList.size() + "个,总计测试路径" + count + "条");
		fileWriter.flush();
		fileWriter.close();
	}

	/**
	 * 引导屏
	 * 
	 * @param addr
	 * @return
	 */
	private boolean isExitScreen(String code) {// addr改code byLLX 0817
		int queryForInt = getJt().queryForInt(mapSql.is_exit_screen(code));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}

	/**
	 * 管理器
	 * 
	 * @param addr
	 * @return
	 */
	private boolean isExitCon(String addr) {
		int queryForInt = getJt().queryForInt(mapSql.is_exit_con(addr));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}

	/**
	 * add by wenzr 2012.7.22
	 * 
	 * @param 传入管理器编号
	 * @return 管理对应的序列号
	 */
	private String getControllerSeqId(String id, String addr) {
		JSONArray jsonArray = getJt().queryForJSONArrayExt(
				mapSql.getConSeqId(addr));
		if (jsonArray.size() == 0) {// 不存在，产生新的序列号
			return id;
		} else {// 存在，返回上一地图的序列号
			JSONObject json = jsonArray.getJSONObject(0);
			return json.get("id").toString();
		}
	}

	/**
	 * 探测器 地感
	 * 
	 * @param detectorConfigData
	 * @return
	 */
	private boolean isExit(String code){
		int queryForInt = getJt().queryForInt(mapSql.is_exit_detector(code));
		if (queryForInt == 0)
			return false;
		else if (queryForInt == 1)
			return true;
		else
			return true;
	}

	private JSONObject get_exit_dmess(String code) {
		JSONArray jarr = getJt().queryJson(mapSql.get_exit_dmess(code));
		if (jarr.size() > 0) {
			return jarr.getJSONObject(0);
		} else {
			return new JSONObject();
		}
	}

	private JSONObject get_exit_smess(String code) {
		JSONArray jarr = getJt().queryJson(mapSql.get_exit_smess(code));
		if (jarr.size() > 0) {
			return jarr.getJSONObject(0);
		} else {
			return new JSONObject();
		}
	}

	public boolean read(MapManageData data) {// 判断地图号和地图名是否重复
		String type = "";
		if (Util.isCon(data.getId())) {
			type = "update";
		}
		int queryForInt = getJt().queryForInt(mapSql.read(data, type));
		if (queryForInt == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Description :获得第一张地图路径．
	 * 
	 * @param :MapManageData
	 * @return :MapManageData
	 * @throws :Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List map_getMapCode(MapManageData data) {
		ArrayList<MapManageData> list = getJt()
				.<MapManageData> queryForListExt(mapSql.map_getMapCode(),
						MapManageData.class);

		for (int i = 0; i < list.size(); i++) {
			MapManageData temp = list.get(i);

			if (Util.isCon(temp.getPath())) {
				temp.setPath(splitMapSrc(temp.getPath()));
			}

			// 设置第一个地图的id和url等
			if (i == 0) {
				data.setId(temp.getCode_id());
				data.setPath(temp.getPath());
			}
		}
		return list;
	}

	public boolean readExits(MapManageData data) {// 判断地图文件是否重复
		int queryForInt = getJt().queryForInt(
				mapSql.readIsExits(data.getName()));
		if (queryForInt == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 根据系统类型获取管理器编号
	 * 
	 * @return
	 */
	public String getCtlCode(String sysModel, String source) {
		String str = "";
		if (Util.isCon(sysModel)) {
			int model = Integer.parseInt(sysModel);
			switch (model) {
			case 1:
				str = source.substring(0, 3);
				break;
			case 2:
				String temp = source.substring(0, source.indexOf("|"));
				str = temp.substring(0, temp.length() - 4);
				break;
			case 3:
				str = source.substring(0, 6);
				break;
			}
		} else {
			Log.log("系统类型为空");
		}
		return str;
	}

	/**
	 * 根据系统类型获取探测器编号
	 * 
	 * @param sysModel
	 * @param source
	 * @return
	 */
	public String getDetCode(String sysModel, String source) {
		String str = "";
		if (Util.isCon(sysModel)) {
			int model = Integer.parseInt(sysModel);
			switch (model) {
			case 1:
				str = source.substring(3, 6);
				break;
			// case 2: str = source.substring(source.indexOf("-")+1,
			// source.indexOf("|"));break;
			// case 2: str = source.substring(source.length() - 3,
			// source.length());break;
			case 2:
				String temp = source.substring(0, source.indexOf("|"));
				str = temp.substring(temp.length() - 3, temp.length());
				break;
			case 3:
				str = source.substring(6, 9);
				break;
			}
		} else {
			Log.log("系统类型为空");
		}
		return str;
	}

	public String getEqmNO(String sysModel) {
		String str = "";
		if (Util.isCon(sysModel)) {
			int model = Integer.parseInt(sysModel);
			switch (model) {
			case 1:
				str = "1";
				break;
			case 2:
				str = "4";
				break;
			case 3:
				str = "3";
				break;
			}
		} else {
			Log.log("系统类型为空");
		}
		return str;
	}

	public String getCtlDetCode(String sysModel, String source) {
		String str = "";
		if (Util.isCon(sysModel)) {
			if (sysModel.equals("2")) {
				str = source.substring(0, source.indexOf("|"));
			}
		} else {
			Log.log("系统类型为空");
		}
		return str;
	}

	/**
	 * 获取一个点
	 * 
	 * @param sourceStr
	 *            如L1-K1,E1|532.75,266.3]
	 * @param type
	 *            linepoint或machinepoint
	 * @param mapId
	 *            地图id
	 * @return
	 */
	public Point getAPoint(String sourceStr, String type, String mapId) {
		String[] tempStr = sourceStr.split("\\|");
		String pointName = tempStr[0]; // flash上点名称，如A1-B1,C1
		String[] frontStr = tempStr[0].split("\\-");
		String pointCode = frontStr[0]; // 实际点名称，如A1
		List<Point> subPoints = new ArrayList<Point>(); // 子节点
		if (frontStr[1].indexOf(",") != -1) {
			String[] subPointCodes = frontStr[1].split(",");
			for (int j = 0; j < subPointCodes.length; j++) {
				Point subPoint = new Point(0, 0, "", subPointCodes[j]);
				subPoints.add(subPoint);
			}
		} else {
			String subPointCode = frontStr[1];
			subPoints.add(new Point(0, 0, "", subPointCode));
		}
		String[] axises = tempStr[1].split(",");
		double x_axis = Double.parseDouble(axises[0]);
		double y_axis = Double.parseDouble(axises[1]);

		Point apoint = new Point(x_axis, y_axis, pointName, pointCode);
		apoint.setId(PrimaryId.getId()); // 设置基础点id
		apoint.setMapId(mapId); // 设置点的地图id
		apoint.setSubPoints(subPoints);
		if (type.equals("linepoint")) {
			apoint.setIfcarsearchpc("0");
		} else if (type.equals("machinepoint")) {// type为machinepoint
			apoint.setIfcarsearchpc("1");
			Point s = this.getJt().queryForObjectExt(mapSql.getSearchMachineIP(pointCode, mapId), Point.class);
			Log.log("查询机：" + pointCode + ", IP: " + s.getIp() +", note: " + s.getNote());
			apoint.setIp(s.getIp());
			apoint.setNote(s.getNote());
		} else if (type.equals("liftentrance")) {// type为liftentrance
			apoint.setIfcarsearchpc("2");
		} else if (type.equals("dimension")){
			apoint.setIfcarsearchpc("3");
		}
		return apoint;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map handlePoints(MapManageData data){
		Map rmap = new HashMap();
		String[] args = null;//分割数据用数组

		List<Point> linePointList = new ArrayList<Point>(); // 路径点集合
		List<Segment> sList = new ArrayList<Segment>(); // 连通线段集合
		List<String> sqllinePointList = new ArrayList<String>(); // 路径点插入sql语句列表
		List<String> sqlPoint = new ArrayList<String>(); // 路径点关系插入sql语句列表
		try {
			
			//处理路径点数据
			if (!Util.isCon(data.getImp_data_linepoint())) {
				args = null;
			} else {
				args = data.getImp_data_linepoint().split("]");
				for (int i = 0; i < args.length; i++) {
					Point apoint = getAPoint(args[i], "linepoint", data.getId());
					linePointList.add(apoint);
					sqllinePointList.add(mapSql.save_headnode(apoint)); // 生成添加路径基本点sql语句
				}
			}

			//处理查询机数据
			if (!Util.isCon(data.getImp_data_machinepoint())) {
				args = null;
			} else {
				args = data.getImp_data_machinepoint().split("]");
				for (int i = 0; i < args.length; i++) {
					Point apoint = getAPoint(args[i], "machinepoint",data.getId());
					linePointList.add(apoint);
					sqllinePointList.add(mapSql.save_headnode(apoint)); // 生成添加路径基本点sql语句
				}
			}

			 //处理电梯入口点数据
			if (!Util.isCon(data.getImp_data_liftentrance())) {
				args = null;
			} else {
				args = data.getImp_data_liftentrance().split("]");
				// liftentrance
				for (int i = 0; i < args.length; i++) {
					Point apoint = getAPoint(args[i], "liftentrance",data.getId());
					linePointList.add(apoint);
					sqllinePointList.add(mapSql.save_headnode(apoint));
				}
			}
			//处理二维码数据
			if(!Util.isCon(data.getImp_data_dimension())){
				args = null;
			}else{
				args = data.getImp_data_dimension().split("]");
				for(int i=0; i<args.length; i++){
					Point apoint = getAPoint(args[i], "dimension", data.getId());
					linePointList.add(apoint);
					sqllinePointList.add(mapSql.save_headnode(apoint));
				}
			}
			/**
			 * 处理各点的subPoints
			 */
			if (linePointList.size() > 0) {
				for (int i = 0; i < linePointList.size(); i++) {
					Point aPoint = linePointList.get(i);
					List<Point> subPoints = aPoint.getSubPoints();
					for (int k = 0; k < subPoints.size(); k++) {
						Point subPoint = subPoints.get(k);
						for (int j = 0; j < linePointList.size(); j++) {
							Point linePoint = linePointList.get(j);
							if (subPoint.getCode().equals(linePoint.getCode())) {
								subPoint.setId(linePoint.getId());
								subPoint.setName(linePoint.getName());
								subPoint.setHeadid(aPoint.getId());
								subPoint.setX(linePoint.getX());
								subPoint.setY(linePoint.getY());
								Segment aSegment = new Segment(aPoint, subPoint); // 父节点和子节点组成的线段
								subPoint.setPathweights(aSegment.getLength());
								sqlPoint.add(mapSql.save_childnode(subPoint));
								sList.add(aSegment); // 线段集合
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		rmap.put("linePointList", linePointList);
		rmap.put("sList", sList);
		rmap.put("sqllinePointList", sqllinePointList);
		rmap.put("sqlPoint", sqlPoint);
		return rmap;
	}
	/**
	 * 增量地图导入地图数据
	 * @param data
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public JSONObject updatemap_imp(MapManageData data) {
		Log.log("地图id---"+data.getId());
		JSONObject jobj = new JSONObject();// 返回数据用
		Map langMap = (HashMap)data.getCurrent_lang_switch().get("common");	//多语言map
		String args[]; // 前台数据用,分割
		HashMap condMap = new HashMap(); //<conCode,con_id>，<管理器编码,管理器id>键值对
		Set<String> conIdSet = new HashSet<String>();
		this.map_get(data); // 查询地图物理区域
		Log.log("地图id---"+data.getId());
		List<String> sqlUpdateDetector = new ArrayList<String>(); // 更新探测器信息sql语句
		List<String> sqlDeDetected = new ArrayList<String>(); // 探测器插入的sql语句List
		List<String> sqlParkingSpace = new ArrayList<String>(); // 插入车位的sql语句List
		
		List<String> sqlDeleteParkingSpace = new ArrayList<String>(); 	//删除车位Sql语句
		List<String> sqlDeleteDetector = new ArrayList<String>(); 		//删除探测器Sql语句
		
		List<String> sqlCon = new ArrayList<String>(); 			// 插入管理器的sql语句List
		List<String> sqlDeleteCon = new ArrayList<String>();    // 删除管理器sql语句list
		
		List<String> sqlGrDetected = new ArrayList<String>(); 	// 地感探测器插入的sql语句List
		List<String> sqlDeleteGr = new ArrayList<String>();     // 地感删除sql语句list
		
		List<String> sqlScreen = new ArrayList<String>(); 		// 屏信息插入的sql语句List
		List<String> sqlDeleteScreen = new ArrayList<String>();	// 屏信息删除Sql语句list
		List<String> sqlDeleteSRegion = new ArrayList<String>(); //删除屏分区sql语句list
		List<String> sqlDeleteSPara = new ArrayList<String>(); //删除屏分区sql语句list
		
		List<Point> linePointList = new ArrayList<Point>(); // 路径点集合
		List<Segment> sList = new ArrayList<Segment>(); // 连通线段集合
		List<String> sqllinePointList = new ArrayList<String>(); // 路径点插入sql语句列表
		List<String> sqlPoint = new ArrayList<String>(); // 路径点关系插入sql语句列表
		
		List<Point> carPointList = new ArrayList<Point>(); // 车位点集合
		String sysModel = queryForSystemModel(); // 获取系统的类型
		ControllerData controllerData = new ControllerData();
		
		String[] deleteCon = {}; //删除管理器数组
		String[] deleteDet = {}; //删除探测器数据
		String[] deleteGr = {};  //删除地感数据
		String[] deleteSc= {};   //删除条屏数据
		try {

			Map smap = handlePoints(data);	//处理点数据
			linePointList = (ArrayList)smap.get("linePointList");
			sList = (ArrayList)smap.get("sList");
			sqllinePointList = (ArrayList)smap.get("sqllinePointList");
			sqlPoint = (ArrayList)smap.get("sqlPoint");
			
			// 首先处理探测器数据de
			if (!Util.isCon(data.getImp_data_de())) {
				args = null;
			} else {
				if (sysModel.equals("2")) { // 当前系统类型为视频
					data.setImp_data_de(data.getImp_data_de().replace('_', '.'));
				}
				args = data.getImp_data_de().split(",");// 前台数据用,分割
				// 解析参数,获取管理器id
				for (int i = 0; i < args.length; i++) {
					String con_id = ""; // 管理器id
					//获取管理器编号，超声波前3位、视频前4位、地磁前6位
					con_id = getCtlCode(sysModel, args[i]);
					// 用set控制重复的管理器id
					conIdSet.add(con_id);
				}

				// 遍历管理器set 组成管理器插入语句
				for (Iterator<String> iter = conIdSet.iterator(); iter.hasNext();) {
					String con_id = iter.next();

					controllerData.setId(PrimaryId.getId());
					controllerData.setAddr(con_id); // 管理器id
					controllerData.setMapId(data.getId()); // 地图id
					controllerData.setStatus("0"); // 状态默认为0
					/*
					 * edit by wenzr,2012.7.22 18:05
					 * 根据小莫的意见，厦门项目中，多个地图可能共用同一个管理器,如A:005;B:005 处理意见：
					 * 传入地图编号一起检查管理编号是否重复，如果管理器id重复但地图id不同，则取原来的序列号，地图号也用原来的？？？
					 */
					// 键值 key:控制器地址 value:控制器id
					// condMap.put(controllerData.getAddr(),
					// controllerData.getId());//该代码有问题，导致管理器ID丢失。by wenzr
					if (!condMap.containsKey(controllerData.getAddr())) {
						condMap.put(controllerData.getAddr(),getControllerSeqId(controllerData.getId(),controllerData.getAddr()));
						if (!isExitCon(controllerData.getAddr())) {
							sqlCon.add(mapSql.save_con(controllerData));
						}
					}

				}

				/**
				 * 处理车位信息
				 */
				for (int i = 0; i < args.length; i++) {
					String detected_id = "", con_id = ""; // 探测器id 管理器id
					DetectorConfigData detectorConfigData = new DetectorConfigData();
					ParkingSpaceData parkingSpaceData = new ParkingSpaceData();
					
					//获取管理器编号，超声波前3位、视频前4位、地磁前6位
					con_id = getCtlCode(sysModel, args[i]);
					detected_id = getDetCode(sysModel, args[i]);
					// 用set控制重复的管理器id
					conIdSet.add(con_id);
					// 探测器开始
					detectorConfigData.setId(PrimaryId.getId()); // 探测器id 现在用生成主键
					detectorConfigData.setMapId(data.getId()); // 地图id
					detectorConfigData.setControllerId(condMap.get(con_id).toString()); // 管理器id
					detectorConfigData.setAddr(detected_id); // 暂时存探测器id
					detectorConfigData.setDetectorTypeId(getEqmNO(sysModel)); // 1为超声波，2为地感，3为地磁，4为视频
					// 而且flash无返回
					String ctrDetCode = "";
					if (sysModel.equals("2")) { // 当前系统类型为视频
						ctrDetCode = args[i].substring(0, args[i].indexOf("|"));
						String x_Y = args[i].substring(args[i].indexOf("|") + 1, args[i].length());
						String[] axises = x_Y.split(";");
						double x_axis = Double.parseDouble(axises[0]);
						double y_axis = Double.parseDouble(axises[1]);
						detectorConfigData.setX_axis(x_axis);
						detectorConfigData.setY_axis(y_axis);
						if (sList.size() > 0) { // 当存在线段时，才进行车位的求垂直点和最短线段
							String formerCode = ctrDetCode.replace('.', '_');
							Point carPoint = new Point(x_axis, y_axis,formerCode, ctrDetCode);
							Map map = ReverseCommon.getNearestPoint(linePointList, carPoint);
							Point point = (Point) map.get("point");
							double len = (Double) map.get("len");
							Map lmap = ReverseCommon.getTheShortestDistanceOfLine(sList,carPoint); // 每个点的最近直线及距离
							Line shortestLine = (Line) lmap.get("line");
							double distance = (Double) lmap.get("distance");
							if (shortestLine == null || len < distance) {// “无垂直点”或者“距离最近点路径小于垂直点路径”
								detectorConfigData.setOnepoint_id(point.getId());
							} else {
								Point crossPoint = shortestLine.getpCross(); // 车位点在最近直线上的垂直点
								Point sPoint = shortestLine.getPs();
								Point ePoint = shortestLine.getPe();
								detectorConfigData.setOnepoint_id(sPoint.getId());
								detectorConfigData.setAnopoint_id(ePoint.getId());
								detectorConfigData.setVertical_x_axis(crossPoint.getX());
								detectorConfigData.setVertical_y_axis(crossPoint.getY());
							}
							carPointList.add(carPoint);
						}
					} else {
						ctrDetCode = args[i];
					}
					detectorConfigData.setCode(ctrDetCode); // [管理器探测器]
					detectorConfigData.setStatus("1"); // 状态默认1
					detectorConfigData.setEnable("1"); // 默认1 启用
					if (!isExit(detectorConfigData.getCode())) {
						String sql = mapSql.save_detector(detectorConfigData);
						System.out.println("增加探测器sql----"+sql);
						sqlDeDetected.add(sql);
						parkingSpaceData.setId(PrimaryId.getId()); // 车位id
						parkingSpaceData.setDetectorId(detectorConfigData.getId()); // 探测器id
						parkingSpaceData.setPhysicalRegionId(data.getPhysicalRegionId());// 物理区域id
						sqlParkingSpace.add(mapSql.save_parkingSpace(parkingSpaceData));
					} else {// 与数据库重复的探测器则更新
						sqlUpdateDetector.add(mapSql.update_detector(detectorConfigData));
					}
				}
				
				//当前地图的所有探测器
				List<DetectorConfigData> dlist  = this.getJt().queryForListExt(mapSql.get_detectors(data.getId()), DetectorConfigData.class);
				if(dlist.size() > 0){
					String[] des = new String[dlist.size()];
					String[] src = new String[args.length];
					for(int k=0; k<dlist.size(); k++){
						des[k] = dlist.get(k).getCode();
					}
					for(int m=0; m<args.length; m++){
						src[m] = args[m].substring(0, args[m].indexOf("|"));
					}
					Map dlmap = CopyUtil.minusTwoStrArr(src, des);
					String[] adds = (String[])dlmap.get("srcl");		//要添加的探测器
					deleteDet = (String[])dlmap.get("desl");		//要删除的探测器
					for(String code : deleteDet){
						sqlDeleteParkingSpace.add(mapSql.delete_parkingSpace(code));
						sqlDeleteDetector.add(mapSql.delete_detector(code));
					}
				}
			}
			
			/**
			 * 处理地感信息
			 */
			if (!Util.isCon(data.getImp_data_gr())) {
				args = null;
			} else {
				args = data.getImp_data_gr().split(","); // 前台数据用,分割
				// 解析参数
				for (int i = 0; i < args.length; i++) {
					String con_id = ""; // 管理器id
					con_id = getCtlCode(sysModel, args[i]);
					// 用set控制重复的管理器id
					conIdSet.add(con_id);
				}
				// 遍历管理器set 组成管理器插入语句
				for (Iterator<String> iter = conIdSet.iterator(); iter.hasNext();) {
					String con_id = iter.next();
					controllerData.setId(PrimaryId.getId());
					controllerData.setAddr(con_id); // 管理器id
					controllerData.setMapId(data.getId()); // 地图id
					controllerData.setStatus("0"); // 状态默认为0
					if (!condMap.containsKey(controllerData.getAddr())) {
						condMap.put(controllerData.getAddr(),getControllerSeqId(controllerData.getId(),controllerData.getAddr()));
						if ((!isExitCon(controllerData.getAddr()))) {
							sqlCon.add(mapSql.save_con(controllerData));
						}
					}
				}

				for (int i = 0; i < args.length; i++) {
					String detected_id = "", con_id = ""; // 探测器id 管理器id
					DetectorConfigData detectorConfigData = new DetectorConfigData();
					/**
					 * 为兼容地磁管理器地址（6位）+地磁地址（3位），进行改动，add by wj 2013-01-29
					 */
					con_id = getCtlCode(sysModel, args[i]);
					detected_id = getDetCode(sysModel, args[i]);
					if (!isExit(args[i]) && Util.isCon(args[i])) {
						// 探测器开始
						detectorConfigData.setId(PrimaryId.getId()); // 探测器id
						// 现在用生成主键
						detectorConfigData.setMapId(data.getId()); // 地图id
						detectorConfigData.setControllerId(condMap.get(con_id).toString());
						detectorConfigData.setAddr(detected_id); // 暂时存探测器id
						detectorConfigData.setDetectorTypeId("2"); // 默认写2 代表是地感
						detectorConfigData.setCode(args[i]); // [管理器探测器]
						detectorConfigData.setStatus("1"); // 状态默认1
						detectorConfigData.setEnable("1"); // 默认1 启用
						sqlGrDetected.add(mapSql.save_detector(detectorConfigData));// 生成地感插入sql语句
					}

				}
				List<DetectorConfigData> drlist = this.getJt().queryForListExt(mapSql.get_grounders(data.getId()), DetectorConfigData.class);
				if(drlist.size() > 0){
					String[] darr = new String[drlist.size()];
					for(int da=0; da<drlist.size(); da++){
						darr[da] = drlist.get(da).getCode();
					}
					Map grmap = CopyUtil.minusTwoStrArr(args, darr);
					String[] adds = (String[])grmap.get("srcl");		//要添加的地感
					deleteGr = (String[])grmap.get("desl");		//要删除的地感
					for(String code : deleteGr){
						sqlDeleteGr.add(mapSql.delete_detector(code));
					}
				}
			}
			
			
			List<ControllerData> clist = this.getJt().queryForListExt(mapSql.get_controllers(data.getId()), ControllerData.class);
			if(clist.size() > 0){
				String[] carr = new String[clist.size()];
				for(int c=0; c<clist.size(); c++){
					carr[c] = clist.get(c).getAddr();
				}
				String[] a = {};
				String[] src = conIdSet.toArray(a);
				Map crlmap = CopyUtil.minusTwoStrArr(src, carr);
				String[] adds = (String[])crlmap.get("srcl");			//要添加的管理器
				deleteCon = (String[])crlmap.get("desl");				//要删除的管理器
				for(String code : deleteCon){				
					sqlDeleteCon.add(mapSql.delete_controller(code));
				}
			}
			
			/***
			 * 处理引导屏信息
			 */
			if (!Util.isCon(data.getImp_data_sc())) {
				args = null;
			} else {
				args = data.getImp_data_sc().split(","); // 前台数据用,分割
				//原地图上的所有条屏
				List<ScreenData> slist = this.getJt().queryForListExt(mapSql.get_screens(data.getId()), ScreenData.class);
				if(slist.size() > 0){
					String[] fscreen = new String[slist.size()];
					for(int i=0; i<slist.size(); i++){
						fscreen[i] = slist.get(i).getCode();
					}
					Map srmap = CopyUtil.minusTwoStrArr(args, fscreen);
					String[] adds = (String[])srmap.get("srcl");		//要添加的条屏
					deleteSc = (String[])srmap.get("desl");		//要删除的条屏
					for(String code : deleteSc){
						sqlDeleteSRegion.add(mapSql.delete_screenRegion(code));
						sqlDeleteSPara.add(mapSql.delete_screenPara(code));
						sqlDeleteScreen.add(mapSql.delete_screen(code));
					}
				}
				
				for (int i = 0; i < args.length; i++) {
					ScreenData screenData = new ScreenData();
					// 屏编号组成 字母+3位组地址+2位屏地址
					screenData.setId(PrimaryId.getId()); // 引导屏id
					screenData.setMapId(data.getId()); // 引导屏地图id
					screenData.setCode(args[i]); // code
					screenData.setGrpAddr(args[i].substring(1, 4)); // 3位组地址
					screenData.setAddr(args[i].substring(4, 6)); // 2位屏地址
					screenData.setStatus("1"); // 状态默认1
					if (!isExitScreen(screenData.getCode())) {// 判断code是否重复
						sqlScreen.add(mapSql.save_screen(screenData));
					}
				}
			}
			
			/**
			 * 批量执行sql
			 */
			// 由于外键关系 先执行管理器插入 再插入探测器
			if (sqlCon.size() > 0) {
				for (int i = 0; i < sqlCon.size(); i++) {
					getJt().update(sqlCon.get(i));
				}
			}
			this.getJt().update(mapSql.delete_headnodessubs(data.getId())); 	// 删除点关系表中数据
			this.getJt().update(mapSql.delete_headnodes(data.getId())); 		// 删除点数据
			this.getJt().update(mapSql.delete_shortestpathinofline(data.getId()));//删除最短路径中从表数据
			this.getJt().update(mapSql.delete_p_shortestpathinofhead(data.getId()));//删除最短路径主表数据
			
			//删除车位
			if(sqlDeleteParkingSpace.size() > 0){
				String[] sqlArr = new String[sqlDeleteParkingSpace.size()];
				for(int i=0; i<sqlDeleteParkingSpace.size(); i++){
					sqlArr[i] = sqlDeleteParkingSpace.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除管理器
			if(sqlDeleteCon.size() > 0){
				String[] sqlArr = new String[sqlDeleteCon.size()];
				for(int i=0; i<sqlDeleteCon.size(); i++){
					sqlArr[i] = sqlDeleteCon.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除探测器
			if(sqlDeleteDetector.size() > 0){
				String[] sqlArr = new String[sqlDeleteDetector.size()];
				for(int i=0; i<sqlDeleteDetector.size(); i++){
					sqlArr[i] = sqlDeleteDetector.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除地感
			if(sqlDeleteGr.size() > 0){
				String[] sqlArr = new String[sqlDeleteGr.size()];
				for(int i=0; i<sqlDeleteGr.size(); i++){
					sqlArr[i] = sqlDeleteGr.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除条屏区域
			if(sqlDeleteSRegion.size() > 0){
				String[] sqlArr = new String[sqlDeleteSRegion.size()];
				for(int i=0; i<sqlDeleteSRegion.size(); i++){
					sqlArr[i] = sqlDeleteSRegion.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除条屏参数
			if(sqlDeleteSPara.size() > 0){
				String[] sqlArr = new String[sqlDeleteSPara.size()];
				for(int i=0; i<sqlDeleteSPara.size(); i++){
					sqlArr[i] = sqlDeleteSPara.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			//删除条屏
			if(sqlDeleteScreen.size() > 0){
				String[] sqlArr = new String[sqlDeleteScreen.size()];
				for(int i=0; i<sqlDeleteScreen.size(); i++){
					sqlArr[i] = sqlDeleteScreen.get(i);
				}
				this.getJt().batchUpdate(sqlArr);
			}
			
			// 路径点及查询机点插入
			if (sqllinePointList.size() > 0) {
				for (int i = 0; i < sqllinePointList.size(); i++) {
					getJt().update(sqllinePointList.get(i));
				}
			}
			// 路径点及查询机点关系插入
			if (sqlPoint.size() > 0) {
				for (int i = 0; i < sqlPoint.size(); i++) {
					getJt().update(sqlPoint.get(i));
				}
			}
			if (sqlDeDetected.size() > 0) {// 超声波探测器插入sql
				for (int i = 0; i < sqlDeDetected.size(); i++) {
					getJt().update(sqlDeDetected.get(i));
				}
			}
			if (sqlGrDetected.size() > 0) {// 地感探测器插入sql
				for (int i = 0; i < sqlGrDetected.size(); i++) {
					getJt().update(sqlGrDetected.get(i));
				}
			}
			if (sqlParkingSpace.size() > 0) {// 车位插入sql
				for (int i = 0; i < sqlParkingSpace.size(); i++) {
					getJt().update(sqlParkingSpace.get(i));
				}
			}
			if (sqlUpdateDetector.size() > 0) {// 车位更新sql
				for (int i = 0; i < sqlUpdateDetector.size(); i++) {
					getJt().update(sqlUpdateDetector.get(i));
				}
			}
			if (sqlScreen.size() > 0) {// 屏信息插入sql
				for (int i = 0; i < sqlScreen.size(); i++) {
					getJt().update(sqlScreen.get(i));
				}
			}
			// 更新车位导入数量
			int parkingSum = this.getJt().queryForInt(mapSql.getParkingSum(data));
			data.setParkingSum(parkingSum);
			// 更新屏导入数量
			int screenSum = this.getJt().queryForInt(mapSql.getScreenSum(data));
			data.setScreenSum(screenSum);
			// 更新导入数量
			getJt().execute(mapSql.update_impCount(data));
			// 将地图是否字段 置为1
			getJt().execute(mapSql.updateMap(data));
			String updateSql = "update p_map set path=" + Util.toSqlVal(data.getMap_src())+" where id =" + Util.toSqlVal(data.getId());
			getJt().update(updateSql);
			// 如果系统是视频类型，计算最短路径和为条屏分配管理器
			if (sysModel.equals("2")) {
				Reassignment(data.getId());
				getAllShortestPaths(data.getId());
			}
			jobj.element("success", true);
			jobj.element("message", langMap.get("update_map").toString()+langMap.get("process_success"));
			if(deleteCon.length > 0){
				jobj.element("cmess", langMap.get("con_delete_mess").toString()+deleteCon.length+langMap.get("unit_mess")+"："+CopyUtil.generateStr(deleteCon, ","));
			}else{
				jobj.element("cmess", "");
			}
			if(deleteDet.length > 0){
				jobj.element("dmess", langMap.get("det_delete_mess").toString()+deleteDet.length+langMap.get("unit_mess")+"："+CopyUtil.generateStr(deleteDet, ","));
			}else{
				jobj.element("dmess", "");
			}
			if(deleteSc.length > 0){
				jobj.element("smess", langMap.get("screen_delete_mess").toString()+deleteSc.length+langMap.get("unit_mess")+"："+CopyUtil.generateStr(deleteSc, ","));
			}else{
				jobj.element("smess", "");
			}
			if(deleteGr.length > 0){
				jobj.element("gmess", langMap.get("gro_delete_mess").toString()+deleteGr.length+langMap.get("unit_mess")+"："+CopyUtil.generateStr(deleteGr, ","));
			}else{
				jobj.element("gmess", "");
			}
		} catch (Exception e) {
			e.printStackTrace();
			jobj.element("success", false);
		}
		return jobj;
	}

	/**
	 * 校验增量地图数据
	 * 
	 * @param data
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public JSONObject updatemap_check(MapManageData data) {
		JSONObject jobj = new JSONObject();
		Map langMap = (HashMap)data.getCurrent_lang_switch().get("common");//多语言common
		Map langInver = (HashMap)data.getCurrent_lang_switch().get("inversion");//多语言inversion
		Map langMap_dtype = (HashMap)data.getCurrent_lang_switch().get("map_dtype");//多语言inversion
		String args[]; // 前台数据用,分割
		List errorArr = new ArrayList(); // 存放路径点，查询机点，电梯口点有误的数据
		String lerror = ""; // 点错误
		String drepeat = ""; // 车位数据重复
		String derror = ""; // 车位数据错误
		String srepeat = ""; // 条屏数据重复
		String serror = ""; // 条屏数据错误
		String grepeat = ""; // 地感数据重复
		String gerror = ""; // 地感数据错误
		boolean flag = true;
		try {
			Map map = verifyPoint(data);//点数据校验
			flag = (Boolean) map.get("flag");
			errorArr = (List) map.get("errorArr");
			if(!flag){
				jobj.element("pmess", langMap.get("machine_and_line_point").toString()+langMap.get("codeerror"));
			}else{
				jobj.element("pmess", "");
			}
			if (Util.isCon(data.getImp_data_de())) {// 校验车位数据
				args = data.getImp_data_de().split(",");
				drepeat = judgeRepeat(args, data.getSysModel());
				if (Util.isCon(drepeat)) {
					flag = false;
					jobj.element("drmess", langInver.get("carcode").toString()+langMap.get("coderepeat"));
				}else{
					jobj.element("drmess", "");
				}
				derror = verifyData(args, data.getSysModel(), "detector",data.getId());
				if (Util.isCon(derror)) {
					flag = false;
					jobj.element("demess", langInver.get("carcode").toString()+langMap.get("codeerror"));
				}else{
					jobj.element("demess", "");
				}
			}
			if (Util.isCon(data.getImp_data_sc())) {// 校验引导屏数据
				args = data.getImp_data_sc().split(",");
				srepeat = judgeRepeat(args, "");
				if (Util.isCon(srepeat)) {
					flag = false;
					jobj.element("srmess", langMap_dtype.get("screen").toString()+langMap.get("coderepeat"));
				}else{
					jobj.element("srmess", "");
				}
				serror = verifyData(args, data.getSysModel(), "screen",data.getId());
				if (Util.isCon(serror)) {
					flag = false;
					jobj.element("semess", langMap_dtype.get("screen").toString()+langMap.get("codeerror"));
				}else{
					jobj.element("semess", "");
				}
			}
			if (Util.isCon(data.getImp_data_gr())) {// 校验地感数据
				args = data.getImp_data_gr().split(",");
				grepeat = judgeRepeat(args, "");
				if (Util.isCon(grepeat)) {
					flag = false;
					jobj.element("grmess", langMap.get("grounder_mess").toString()+langMap.get("coderepeat"));
				}else{
					jobj.element("grmess", "");
				}
				gerror = verifyData(args, data.getSysModel(), "groundor",data.getId());
				if (Util.isCon(gerror)) {
					flag = false;
					jobj.element("gemess",langMap.get("grounder_mess").toString()+langMap.get("codeerror"));
				}else{
					jobj.element("gemess", "");
				}
			}
			for (int i = 0; i < errorArr.size(); i++) {
				lerror += errorArr.get(i) + ",";
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		jobj.element("flag", flag);
		jobj.element("lerror", lerror);
		jobj.element("drepeat", drepeat);
		jobj.element("derror", derror);
		jobj.element("srepeat", srepeat);
		jobj.element("serror", serror);
		jobj.element("grepeat", grepeat);
		jobj.element("gerror", gerror);
		jobj.element("message", langMap.get("update_map_mess").toString());
		return jobj;
	}

	/**
	 * 路径点、查询机点、电梯入口点数据校验
	 * @param data
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map verifyPoint(MapManageData data){
		Map rmap = new HashMap();	//返回数据存储位置
		
		/** 校验路径点、查询机电、电梯口点*/
		List errorArr = new ArrayList();
		List allArr = new ArrayList();
		List allCodeArr = new ArrayList();
		boolean pointFlag = true;
		boolean flag = true;
		
		if(Util.isCon(data.getImp_data_machinepoint())){//查询机点	
			String[] machineArr = data.getImp_data_machinepoint().split("]");
			for (int i = 0; i < machineArr.length; i++) {
				String machineName = machineArr[i].substring(0,machineArr[i].indexOf("|"));
				if (machineName.indexOf("-") == -1) {
					pointFlag = false;
					errorArr.add(machineName);
				} else {
					allArr.add(machineName);
					allCodeArr.add(machineName.substring(0,machineName.indexOf("-")));
				}
			}
		}
		
		if (Util.isCon(data.getImp_data_linepoint())){//路径点
			String[] lineArr = data.getImp_data_linepoint().split("]");
			for (int i = 0; i < lineArr.length; i++) {
				String lineName = lineArr[i].substring(0,lineArr[i].indexOf("|"));
				if (lineName.indexOf("-") == -1) {
					pointFlag = false;
					errorArr.add(lineName);
				} else {
					allArr.add(lineName);
					allCodeArr.add(lineName.substring(0,lineName.indexOf("-")));
				}
			}
		}

		if (Util.isCon(data.getImp_data_liftentrance())) {//电梯点
			String[] liftArr = data.getImp_data_liftentrance().split("]");
			for (int i = 0; i < liftArr.length; i++) {
				String liftName = liftArr[i].substring(0,liftArr[i].indexOf("|"));
				if (liftName.indexOf("-") == -1) {
					pointFlag = false;
					errorArr.add(liftName);
				} else {
					allArr.add(liftName);
					allCodeArr.add(liftName.substring(0,liftName.indexOf("-")));
				}
			}
		}
		
		if (Util.isCon(data.getImp_data_dimension())) {//二维码点
			String[] dimensionArr = data.getImp_data_dimension().split("]");
			for (int i = 0; i < dimensionArr.length; i++) {
				String dimensionName = dimensionArr[i].substring(0,dimensionArr[i].indexOf("|"));
				if (dimensionName.indexOf("-") == -1) {
					pointFlag = false;
					errorArr.add(dimensionName);
				} else {
					allArr.add(dimensionName);
					allCodeArr.add(dimensionName.substring(0,dimensionName.indexOf("-")));
				}
			}
		}
		if (pointFlag) {// 表示所有点均有中短横线，均有连通关系，下一步校验编码是否重复
			boolean repeatFlag = true; // 是否有重复标识
			for (int i = 0; i < allCodeArr.size(); i++) {
				String itemp = allCodeArr.get(i).toString();
				for (int j = i + 1; j < allCodeArr.size(); j++) {
					String jtemp = allCodeArr.get(j).toString();
					if (itemp.equals(jtemp)) {
						repeatFlag = false;
						errorArr.add(allArr.get(i));
						errorArr.add(allArr.get(j));
					}
				}
			}
			if (repeatFlag) {// 表示所有点的code均不重复，下一步校验连通关系是否完全，即A-B则B也必须描述与A的连通关系
				Map map = new HashMap<String, String[]>();
				for (int i = 0; i < allArr.size(); i++) {
					String Itempstr = allArr.get(i).toString();
					String iTempStart = Itempstr.substring(0,Itempstr.indexOf("-"));
					String iTempEnd = Itempstr.substring(Itempstr.indexOf("-") + 1);
					map.put(iTempStart, iTempEnd.split(","));
				}
				for (int i = 0; i < allCodeArr.size(); i++) {
					String itemp = allCodeArr.get(i).toString();
					String[] itempArr = (String[]) map.get(itemp);
					for (int j = 0; j < itempArr.length; j++) {
						boolean existFlag = false;
						boolean wholeFlag = false;
						String jtemp = itempArr[j];
						for (int m = 0; m < allCodeArr.size(); m++) {
							String mtemp = allCodeArr.get(m).toString();
							if (jtemp.equals(mtemp)) {
								existFlag = true;
								String[] mtempArr = (String[]) map
										.get(mtemp);
								for (String s : mtempArr) {
									if (s.equals(itemp)) {
										wholeFlag = true;
									}
								}
							}
						}
						if (existFlag) {
							if (!wholeFlag) {
								flag = false;
								errorArr.add(allArr.get(i));
							}
						} else {
							flag = false;
							errorArr.add(allArr.get(i));
						}
					}
				}
			} else {
				flag = false;
			}
		} else {
			flag = false;
		}
		rmap.put("flag", flag);
		rmap.put("errorArr", errorArr);
		return rmap;
	}
	/**
	 * 地图探测器数据、引导屏数据、地感数据，本地图内查重
	 * @param args	源数据
	 * @param sysModel 系统类型
	 * @return
	 */
	private String judgeRepeat(String[] args, String sysModel) {
		StringBuilder rStr = new StringBuilder();
		HashMap<String,Integer> map = new HashMap<String, Integer>();
		boolean flag = false;//用于标记是否存在重复，避免不重复时遍历map
		if (args.length > 0) {
			if (sysModel.equals("2")) {// 当前系统类型为视频类型
				for (int i = 0; i < args.length; i++) {
					args[i] = args[i].substring(0, args[i].indexOf("|"));
				}
			}
			for (int i = 0; i < args.length; i++) {
				if(map.containsKey(args[i])){
					flag = true;
					map.put(args[i], map.get(args[i]) + 1);
				}else{
					map.put(args[i], 0);
				}
//				for (int j = i + 1; j < args.length; j++) {
//					if (args[i].equals(args[j])) {
//						if(map.containsKey(args[i])){
//							map.put(args[i], map.get(args[i]) + 1);
//						}else{
//							map.put(args[i], 0);
//						}
//						//rStr.append(args[i]).append(",").append(args[j]).append(";");
//					}
//				}
			}
		}
		if(flag && map.size() > 0){
			Iterator<String> kiter= map.keySet().iterator();
			while(kiter.hasNext()){
				String key = kiter.next();
				if(map.get(key) > 0){
					int t = map.get(key) + 1;
					for(int i=0; i<t; i++){
						rStr.append(key).append(",");
					}
					rStr.deleteCharAt(rStr.length() - 1).append(";");
				}
			}
		}
		if (rStr.length() > 0) {
			rStr.deleteCharAt(rStr.length() - 1);
		}
		return rStr.toString();
	}

	/**
	 * 地图数据校验错误
	 * 
	 * 及与数据库其他地图上数据查重
	 * @param args
	 * @param sysModel
	 * @param type
	 * @return
	 */
	public String verifyData(String[] args, String sysModel, String type,String mapId) {
		StringBuffer rStr = new StringBuffer();
		String regExp = "";
		Matcher mc = null;
		if (type.equals("detector")) {
			if (sysModel.equals("1")) {// 超声波
				regExp = "((0[0-8][0-9])|(09[0-5])){2}";
				Pattern pt = Pattern.compile(regExp);
				for (int i = 0; i < args.length; i++) {
					mc = pt.matcher(args[i]);
					if (!mc.matches()) {
						rStr.append(args[i] + ",");
					}
				}
			} else if (sysModel.equals("2")) {// 视频
//				for (int i = 0; i < args.length; i++) {
//					args[i] = args[i].substring(0, args[i].indexOf("|"));
//				}
				regExp = "[a-f0-9]{4}_0{2}[0123]";
				Pattern pt = Pattern.compile(regExp);
				for(int i=0; i< args.length; i++){
					mc = pt.matcher(args[i]);
					if(!mc.matches()){
						rStr.append(args[i] + ",");
					}
				}
			} else if (sysModel.equals("3")) {// 地磁
				regExp = "[0-9]{6}0([0-2][0-9]|3[0-1])";
				Pattern pt = Pattern.compile(regExp);
				for (int i = 0; i < args.length; i++) {
					mc = pt.matcher(args[i]);
					if (!mc.matches()) {
						rStr.append(args[i] + ",");
					}
				}
			}
		} else if (type.equals("screen")) {// 条屏
			regExp = "P[0-9]{3}([0-5][0-9]|6[0-4])";
			Pattern pt = Pattern.compile(regExp);
			for (int i = 0; i < args.length; i++) {
				mc = pt.matcher(args[i]);
				if (!mc.matches()) {
					rStr.append(args[i] + ",");
				}
			}
		} else if (type.equals("groundor")) {// 地感
		// regExp = "((0[0-8][0-9])|(09[0-5])){2}";
		// Pattern pt = Pattern.compile(regExp);
		// for(int i=0; i<args.length; i++){
		// mc = pt.matcher(args[i]);
		// if(!mc.matches()){
		// rStr.append(args[i]+",");
		// }
		// }
		}
		if(rStr.length() > 0){
			rStr.deleteCharAt(rStr.length() - 1);
		}
		return rStr.toString();
	}
	
	/**
	 * 判断数据库非mapId是否存在detector且
	 * @param code
	 * @param mapId
	 * @return
	 */
	public JSONObject isExistDetector(String code,String mapId){
		JSONObject jobj = new JSONObject();
		JSONArray jarr = this.getJt().queryJson(mapSql.check_detector(code, mapId));
		if(jarr.size() > 0){
			jobj = jarr.getJSONObject(0);
			jobj.element("flag", true);
		}else{
			jobj.element("flag", false);
		}
		return jobj;
	}
	
	/**
	 * 判断数据库非mapId是否存在detector且
	 * @param code
	 * @param mapId
	 * @return
	 */
	public JSONObject isExistScreen(String code,String mapId){
		JSONObject jobj = new JSONObject();
		JSONArray jarr = this.getJt().queryJson(mapSql.check_screen(code, mapId));
		if(jarr.size() > 0){
			jobj = jarr.getJSONObject(0);
			jobj.element("flag", true);
		}else{
			jobj.element("flag", false);
		}
		return jobj;
	}
	
	/**
	 * 判断地图是否已导入数据
	 * @param ids
	 * @return
	 */
	public JSONObject checkMapImport(String ids){
		JSONObject obj = new JSONObject();
		boolean flag = true;
		String mNameStr = "";
		String[] maps = ids.split(";");
		for(int i=0; i<maps.length; i++){
			MapManageData data = new MapManageData();
			data.setId(maps[i]);
			data = this.getJt().queryForObjectExt(mapSql.map_get(data), data);
			if(data.getImportOrNot() == 0){//数据未导入
				flag = false;
				mNameStr +=data.getName()+",";
			}
		}
		if(!mNameStr.equals("")){
			mNameStr = mNameStr.substring(0, mNameStr.length()-1);
		}
		obj.element("flag", flag);
		obj.element("name", "地图"+mNameStr+"未导入数据，请导入地图数据");
		return obj;
	}
	
	/**
	 * 获取最终生成Excel表单的数据结构
	 * @param ids
	 * @return
	 */
	public JSONArray getMapData(String ids){
		JSONArray jarr = new JSONArray();
		if(Util.isCon(ids)){
			String[] maps = ids.split(";");
			for(int i=0; i<maps.length; i++){
				JSONObject jobj = new JSONObject();
				MapManageData data  = new MapManageData();
				data.setId(maps[i]);
				data = this.getJt().queryForObjectExt(mapSql.map_get(data), data);
				jobj.element("name", data.getName());//地图名
				List<DetectorConfigData> list = this.getJt().queryForListExt(mapSql.get_mapdata(maps[i]), DetectorConfigData.class);
				JSONObject dobj = madeJSON(list);
				jobj.element("data", dobj);
				jarr.add(jobj);
			}
		}else{
			Log.log("地图id字符串为空");
		}
		return jarr;
	}
	
	/**
	 * 组合json
	 * @param list
	 * @return
	 */
	public JSONObject madeJSON(List<DetectorConfigData> list){
		JSONObject jobj = new JSONObject();
		if(list.size() > 0){
			for(int i=0; i<list.size(); i++){
				DetectorConfigData data = (DetectorConfigData)list.get(i);
				if(!Util.isCon(data.getParkingSpaceCode())){
					data.setParkingSpaceCode("");
				}
				jobj.element(data.getCode(),data.getParkingSpaceCode());
			}
		}
		return jobj;
	}
	
	/**
	 * 导入Excel数据前判断
	 * @param file
	 * @return
	 */
	public JSONObject beforeImpCheck(File file){
		JSONObject jobj = new JSONObject();
		boolean flag = true;
		String nameStr = "";
		String[] sheetNames = ExcelManage.getSheetNames(file);
		MapManageData data = new MapManageData();
		ArrayList<MapManageData> list = this.getJt().queryForListExt(mapSql.map_list(data, ""), MapManageData.class);
		ArrayList<String> slist = new ArrayList<String>();
		for(MapManageData temp : list){
			slist.add(temp.getName());
		}
		for(int i=0; i<sheetNames.length; i++){
			if(!slist.contains(sheetNames[i])){
				flag = false;
				nameStr += sheetNames[i]+",";
			}
		}
		if(!nameStr.equals("")){
			nameStr = nameStr.substring(0,nameStr.length() - 1);
		}
		jobj.element("flag", flag);
		jobj.element("name", nameStr);
		return jobj;
	}
	
	/**
	 * 导入excel表格数据
	 * @param jarr
	 * @return
	 */
	public JSONObject impExcelData(JSONArray jarr){
		JSONObject jobj = new JSONObject();
		if(jarr.size() > 0){
			for(int i=0; i<jarr.size(); i++){
				JSONObject temp = jarr.getJSONObject(i);
				String mapName = temp.getString("name");
				JSONObject dataObj = temp.getJSONObject("data");
				if(dataObj.size() > 0){
					Set<String> keySet = dataObj.keySet();
					List<String> list = new ArrayList<String>();
					Iterator keyIter = keySet.iterator();
					while(keyIter.hasNext()){
						String code = keyIter.next().toString();
						String parkingSapceCode = dataObj.getString(code);
						if(!parkingSapceCode.equals("")){
							String sql = "update p_parkingspace pp set pp.code = "+Util.toSqlVal(parkingSapceCode)+" where pp.detectorId = (select pd.id from p_detector pd left join p_map pm on pd.mapId = pm.id where pd.code = "+Util.toSqlVal(code)+" and pm.name = "+Util.toSqlVal(mapName)+")";
							list.add(sql);
						}
					}
					if(list.size() > 0){
						String[] sqlStr = new String[list.size()];
						for(int j=0; j<list.size(); j++){
							sqlStr[j] = list.get(j);
						}
						this.getJt().batchUpdate(sqlStr);
					}
				}else{
					Log.log("Excel表单无数据");
				}
			}
		}else{
			Log.log("Excel无表单");
		}
		return jobj;
	}
	
	/**
	 * 获取数据库的“电梯入口点”数据
	 * @return
	 */
	public JSONObject getDBLiftPoints(MapManageData data){
		String liftpoints = data.getImp_data_liftentrance();//地图电梯点字符串
		Map map = (Map)data.getCurrent_lang_switch().get("common");
		JSONObject jobj = new JSONObject();
		//所有的电梯点
		List<Point> list = this.getJt().queryForListExt(mapSql.get_lifts(), Point.class);
		if(list.size() > 0){
			List<Point> oneMap = new ArrayList<Point>();
			Point first = list.get(0);
			oneMap.add(first);
			if(list.size() > 1){
				for(int i=1; i<list.size(); i++){
					if(first.getMapId().equals(list.get(i).getMapId())){
						oneMap.add(list.get(i));
					}
				}
			}
			List<Point> l = getList(liftpoints);
			if(l.size() == oneMap.size()){
				boolean globe = true;
				for(int j=0; j<l.size(); j++){
					boolean flag = false;
					for(int k=0; k<oneMap.size(); k++){
						if(l.get(j).getCode().equals(oneMap.get(k).getCode())){
							flag = true;
							break;
						}
					}
					if(!flag){//有一个电梯点找不到对应点
						globe = false;
					}
				}
				if(globe){
					jobj.element("flag", true);
				}else{
					jobj.element("flag", false);
					jobj.element("msg", map.get("map_liftcode_error").toString());
				}
			}else{
				jobj.element("flag", false);
				jobj.element("msg", map.get("map_liftnum_error").toString());
			}
		}else{//数据库中没有“电梯入口点”，当前地图的电梯点可随意导入
			jobj.element("flag", true);
		}
		return jobj;
	}
	
	/**
	 * 拆分电梯入口点组成字符串
	 * @param liftpoints
	 * @return
	 */
	private List<Point> getList(String liftpoints){
		List<Point> nlist = new ArrayList<Point>();
		String[] larr = liftpoints.split("]");
		for(int i=0; i<larr.length; i++){
			Point p = new Point();
			String[] parr = larr[i].split("\\|");
			String code = "";
			if(parr[0].indexOf("-") != -1){
				String[] narr = parr[0].split("\\-");
				code = narr[0];
			}else{
				code = parr[0];
			}
			String[] xy = parr[1].split(",");
			p.setCode(code);
			p.setX(Double.parseDouble(xy[0]));
			p.setY(Double.parseDouble(xy[1]));
			
			nlist.add(p);
		}
		return nlist;
	}
	
	//更新地图img文件路径
	public boolean updateMapImg(MapManageData data){
		int r = this.getJt().update(mapSql.updateMapImg(data));
		if(r == 1){
			return true;
		}else{
			return false;
		}
	}
}
