package com.ie.its.mapmanage;

import static com.ie.common.Util.*;

import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.lineconfig.LineConfigData;
import com.ie.its.screenconfig.ScreenData;
import com.ie.reverse.PathHead;
import com.ie.reverse.Point;

public class MapManageSql extends ExtendSql {
	/**
	 * Description :查询地图．
	 * 
	 * @param :MapManageData,String
	 * @return :String
	 */
	public String map_list(MapManageData data, String type) {
		String querySql = "";

		if (type.equals("count")) {
			querySql += "select count(*)  ";
		} else {
			querySql += "select  map.id,phy.physicalRegionName as physicalRegionId,map.type,map.path,map.notes,map.number,map.name,map.parkingSum,map.screenSum,map.legend,map.imgPath ";
		}

		querySql += " from p_map map left join p_physicalregion phy on map.physicalRegionId=phy.id where 1=1";

		return querySql;
	}

	/**
	 * Description :保存地图信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_save(MapManageData data) {
		String insertSql = "";

		insertSql += "insert into p_map(id,physicalRegionId,notes,number,path,name,legend) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getPhysicalRegionId()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ",";
		insertSql += Util.toSqlVal(data.getNumber()) + ",";
		insertSql += Util.toSqlVal(data.getPath() + data.getFilename()) + ",";
		insertSql += Util.toSqlVal(data.getName()) + ",";
		insertSql += Util.toSqlVal(data.getLegend()) + ")";
		Log.log(insertSql);
		return insertSql;
	}

	/**
	 * Description :获得地图信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_get(MapManageData data) {
		String querySql = "";

		querySql += "select * from p_map where id=";
		querySql += Util.toSqlVal(data.getId());

		return querySql;
	}

	/**
	 * Description :更新地图信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_update(MapManageData data) {
		String updateSql = "";

		updateSql += "update p_map set physicalRegionId =";
		updateSql += Util.toSqlVal(data.getPhysicalRegionId());
		updateSql += ",notes=" + Util.toSqlVal(data.getNotes());
		updateSql += ",number=" + Util.toSqlVal(data.getNumber());
		updateSql += ",name=" + Util.toSqlVal(data.getName());
//		updateSql += ",parkingSum=" + "0";//修改了地图需要重新导入数据
//		updateSql += ",normalparkSum=" + "0";
//		updateSql += ",screenSum=" + "0";
//		updateSql += ",normalscrSum=" + "0";
//		updateSql += ",importOrNot=" + "0";
		if (Util.isCon(data.getPath())) {
			updateSql += ",path="
					+ Util.toSqlVal(data.getPath() + data.getFilename());
		}

		updateSql += " where id =" + Util.toSqlVal(data.getId());

		Log.log(updateSql);
		return updateSql;
	}

	/**
	 * Description :删除地图信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_delete(String id) {
		String deleteSql = "";

		deleteSql += "delete from p_map where id = " + Util.toSqlVal(id);
		;

		return deleteSql;
	}

	/**
	 * Description :获得物理区域．
	 * 
	 * @param :
	 * @return :String
	 */
	public String get_phyRegionCode() {
		String querySql = "";

		// 2012-4-17 modify by jl 只获取状态为有效的物理区域
		querySql += "select id as code_id,physicalRegionName as code_name from p_physicalregion where status='1' order  by id";

		return querySql;
	}

	/**
	 * Description :检查地图路径是否重复．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_impcheck(MapManageData data) {
		String updateSql = "";

		updateSql += "select count(*) from  p_map where path="
				+ Util.toSqlVal(data.getPath() + data.getFilename());

		if (Util.isCon(data.getId())) {
			updateSql += " and id != " + Util.toSqlVal(data.getId());
		}

		Log.log(updateSql);
		return updateSql;
	}

	/**
	 * Description :保存地图路径．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_impsave(MapManageData data) {
		String updateSql = "";

		updateSql += "update p_map set path="
				+ Util.toSqlVal(data.getPath() + data.getFilename());
		updateSql += " where id = " + Util.toSqlVal(data.getId());

		return updateSql;
	}

	/**
	 * Description :获得地图路径．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_getSrc(String id) {
		String querySql = "";

		querySql += "select path from  p_map where id=" + Util.toSqlVal(id);

		return querySql;
	}

	/**
	 * Description :获得地图路径．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_getParkSum(String id) {
		String querySql = "";

		querySql += "select parkingSum from  p_map where id="
				+ Util.toSqlVal(id);

		return querySql;
	}

	/**
	 * Description :获得地图车位．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String getParkingSum(MapManageData data) {
		String querySql = "";

		querySql += "select count(*) from p_parkingspace pp inner join p_detector pd on pp.detectorId = pd.id where pd.mapId="
			+ Util.toSqlVal(data.getId());
		
		return querySql;
	}
	
	/**
	 * Description :获得地图屏数量．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String getScreenSum(MapManageData data) {
		String querySql = "";

		querySql += "select count(*) from p_screen where mapId="
			+ Util.toSqlVal(data.getId());
		
		return querySql;
	}
	
	/**
	 * Description :保存探测器信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String save_detector(DetectorConfigData data) {
		String insertSql = "";

		insertSql += "insert into p_detector(id,mapId,controllerId,detectorTypeId,code,status,enable,addr,x_axis,y_axis,onepoint_id,anopoint_id,vertical_x_axis,vertical_y_axis) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getMapId()) + ",";
		insertSql += Util.toSqlVal(data.getControllerId()) + ",";
		insertSql += Util.toSqlVal(data.getDetectorTypeId()) + ",";
		insertSql += Util.toSqlVal(data.getCode()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ",";
		insertSql += Util.toSqlVal(data.getEnable()) + ",";
		insertSql += Util.toSqlVal(data.getAddr()) + ",";
		insertSql += Util.toSqlVal(data.getX_axis()) + ",";
		insertSql += Util.toSqlVal(data.getY_axis()) + ",";
		insertSql += Util.toSqlVal(data.getOnepoint_id()) + ",";
		insertSql += Util.toSqlVal(data.getAnopoint_id()) + ",";
		insertSql += Util.toSqlVal(data.getVertical_x_axis()) + ",";
		insertSql += Util.toSqlVal(data.getVertical_y_axis()) + ")";
		//Log.log(insertSql);
		return insertSql;
	}

	/**
	 * 更新车位坐标、垂直点坐标、最近线段
	 * @param data
	 * @return
	 */
	public String update_detector(DetectorConfigData data){
		String updateSql = "update p_detector set x_axis = "+data.getX_axis()+", y_axis = "+data.getY_axis()+", onepoint_id = "+data.getOnepoint_id()+", anopoint_id = "+data.getAnopoint_id();
		updateSql += " ,vertical_x_axis = "+data.getVertical_x_axis()+", vertical_y_axis = "+data.getVertical_y_axis();
		updateSql += " where code = '"+data.getCode()+"'";
		return updateSql;
	}
	/**
	 * Description :保存探测器信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String save_parkingSpace(ParkingSpaceData data) {
		String insertSql = "";

		insertSql += "insert into p_parkingspace(id,physicalRegionId,detectorId,enable,inuse,spotType,spotTypeNow,updateDate) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getPhysicalRegionId()) + ",";
		insertSql += Util.toSqlVal(data.getDetectorId())
				+ ",'1','0','0','0',current_timestamp())";// 状态 可用 无车 临时

		//Log.log(insertSql);
		return insertSql;
	}

	/**
	 * Description :更新导入总数信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String update_impCount(MapManageData data) {
		String updateSql = "";

		updateSql += "update p_map set id=" + Util.toSqlVal(data.getId());

		if (Util.isCon(data.getParkingSum()) && data.getParkingSum() != 0) {
			updateSql += ",parkingSum = " + data.getParkingSum()
					+ ",normalparkSum = " + data.getParkingSum();
		}

		if (Util.isCon(data.getScreenSum()) && data.getScreenSum() != 0) {
			updateSql += ",screenSum = " + data.getScreenSum()
					+ ",normalscrSum = " + data.getScreenSum();
		}

		updateSql += " where id = " + Util.toSqlVal(data.getId());

		Log.log(updateSql);
		return updateSql;
	}

	/**
	 * Description :保存管理器信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String save_con(ControllerData data) {
		String insertSql = "";

		insertSql += "insert into p_controller(id,mapId,addr,status) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getMapId()) + ",";
		insertSql += Util.toSqlVal(data.getAddr()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ")";
		//Log.log(insertSql);

		return insertSql;
	}

	/**
	 * Description :保存引导屏信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String save_screen(ScreenData data) {
		String insertSql = "";

		insertSql += "insert into p_screen(id,addr,mapId,code,grpAddr,status) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getAddr()) + ",";
		insertSql += Util.toSqlVal(data.getMapId()) + ",";
		insertSql += Util.toSqlVal(data.getCode()) + ",";
		insertSql += Util.toSqlVal(data.getGrpAddr()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ")";

		return insertSql;
	}

	/**
	 * Description :保存地图路径．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_getFirstId(MapManageData data) {
		String querySql = "";

		querySql += "select id from  p_map ";

		return querySql;
	}

	/**
	 * Description :获得地图下拉框信息．
	 * 
	 * @param :MapManageData
	 * @return :String
	 */
	public String map_getMapCode() {
		String querySql = "";

		querySql += " select id as code_id,name as code_name,path from p_map order by name";

		return querySql;
	}

	/************************* 地图级联删除 开始 ************************************************************/
	
	public String delete_ParkingSpaceOperationLog(String mapId){
		String querySql = "";
		querySql +=" delete from p_parkingspaceoperationlog where parkingSpaceId in (select ps.id from p_parkingspace ps inner join p_detector pd on ps.detectorId = pd.id where pd.mapId = "+toSqlVal(mapId)+")";
		return querySql;
	}
	/**
	 * Description :删除地图逻辑区域关系表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_MapLogicRegion(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_MapLogicRegion where mapId = "
				+ Util.toSqlVal(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除地图引导区域关系表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_MapGuideRegion(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_MapGuideRegion where mapId = "
				+ Util.toSqlVal(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除地图引导区域关系表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_DetectorParaValue(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_DetectorParaValue where detectorId in "
				+ map_deleteDetectorRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除车位作业计划表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ParkingSpaceTask(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ParkingSpaceTask where parkingSpaceId in "
				+ map_deleteParkingRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除引导屏作业计划表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ScreenTask(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ScreenTask where screenId in "
				+ map_deleteScreenRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除引导屏所引导的区域组表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ScreenRegion(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ScreenRegion where screenId in "
				+ map_deleteScreenRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除屏类型参数值表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ScreenParaValue(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ScreenParaValue where screenId in "
				+ map_deleteScreenRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除下发配置任务表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ConfigTask(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ConfigTask where controllerId in "
				+ map_deleteControllerRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除车位表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_ParkingSpace(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_ParkingSpace where detectorId in "
				+ map_deleteDetectorRela(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除探测器表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_Detector(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_Detector where mapId = "
				+ Util.toSqlVal(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除引导屏表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_Screen(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_Screen where mapId = "
				+ Util.toSqlVal(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :删除管理器表．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteP_Controller(String mapId) {
		String deleteSql = "";

		deleteSql += "delete from P_Controller where mapId = "
				+ Util.toSqlVal(mapId);
		;

		return deleteSql;
	}

	/**
	 * Description :获得级联探测器idsql．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteDetectorRela(String mapId) {
		String str = "(select id from P_Detector where mapId="
				+ Util.toSqlVal(mapId) + ")";
		return str;
	}

	/**
	 * Description :获得级联车位id sql．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteParkingRela(String mapId) {
		String str = "(select id from P_ParkingSpace where detectorId in "
				+ map_deleteDetectorRela(mapId) + ")";
		return str;
	}

	/**
	 * Description :获得级联引导屏idsql．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteScreenRela(String mapId) {
		String str = "(select id from P_Screen where mapId="
				+ Util.toSqlVal(mapId) + ")";
		return str;
	}

	/**
	 * Description :获得级联控制器idsql．
	 * 
	 * @param :String
	 * @return :String
	 */
	public String map_deleteControllerRela(String mapId) {
		String str = "(select id from P_Controller where mapId="
				+ Util.toSqlVal(mapId) + ")";
		return str;
	}

	/************************* 地图级联删除 结束 ************************************************************/

	public String updateMap(MapManageData data) {
		String updateSql = "update p_map set importOrNot = 1 where id = "
				+ Util.toSqlVal(data.getId());
		return updateSql;
	}

	public String is_exit_detector(String code) {
		String querySql = "select count(*) count from p_detector where code = "
				+ toSqlVal(code);
		return querySql;
	}
	public String get_exit_dmess(String code){
		String querySql = "select concat(pm.name,':',pd.code) as code from p_detector as pd, p_map as pm where pm.id = pd.mapId and pd.code= "
			+ toSqlVal(code);
		return querySql;
	}
	public String is_exit_screen(String code) {//addr改code byLLX 0817
		String querySql = "select count(*) count from p_screen where code = "
				+ toSqlVal(code);
		return querySql;
	}
	public String get_exit_smess(String code){
		String querySql = "select concat(pm.name,':',ps.code) as code from p_screen as ps, p_map as pm where ps.mapId = pm.id and ps.code = "
			+ toSqlVal(code);
		return querySql;
	}
	public String is_exit_con(String addr) {
		String querySql = "select count(*) count from p_controller where addr = "
				+ toSqlVal(addr);
		return querySql;
	}
	/**
	 * add by wenzr 2012.7.22
	 * 
	 * @param addr
	 * @return 返回管理器对应的序列号及地图
	 */
	public String getConSeqId(String addr) {
		String querySql = "select * from p_controller where addr = "
				+ toSqlVal(addr);
		return querySql;
	}

	public String readIsExits(String name) {//判断是否有相同路径
		String querySql = "select count(*) count from p_map where name = "
				+ toSqlVal(name);
		return querySql;
	}
	
	public String read(MapManageData data, String type) {
		String querySql = "select count(*) count from p_map where (number = " + toSqlVal(data.getNumber())
		                  + "  or name =" + toSqlVal(data.getName()) + ") ";
		if(type.equals("update")){
			querySql += " and id != " + toSqlVal(data.getId());
		}
		return querySql;
	}
	/**
	 * 保存路径基本点
	 * @param point
	 * @return
	 */
	public String save_headnode(Point point){
		String querySql ="";
		boolean flag=point.getIfcarsearchpc().equals("1");
		if(!flag){
			querySql= " insert into p_pathnodeinfohead(id,mapId,code,name,x_axis,y_axis,ifcarsearchpc,IP,note) values(";	
		}else{
			querySql= " insert into p_pathnodeinfohead(id,mapId,code,name,x_axis,y_axis,ifcarsearchpc,IP,note,status) values(";	
		}
		//String querySql = " insert into p_pathnodeinfohead(id,mapId,code,name,x_axis,y_axis,ifcarsearchpc,IP,note) values(";
		querySql +=toSqlVal(point.getId())+",";
		querySql +=toSqlVal(point.getMapId())+",";
		querySql +=toSqlVal(point.getCode())+",";
		querySql +=toSqlVal(point.getName())+",";
		querySql +=toSqlVal(point.getX())+",";
		querySql +=toSqlVal(point.getY())+",";
		querySql +=toSqlVal(point.getIfcarsearchpc())+",";
		querySql +=toSqlVal(point.getIp())+",";
		querySql +=toSqlVal(point.getNote());
		if(!flag){
			querySql +=")";
		}else{
			querySql +=","+toSqlVal(1)+")";
		}
		return querySql;
	}
	
	/**
	 * 保存点之间的连通关系
	 * @param hpoint
	 * @param subpoint
	 * @return
	 */
	public String save_childnode(Point subpoint){
		String querySql = " insert into p_pathnodeinfoline(id,headid,code,pathweights,note) values(";
		querySql +=toSqlVal(PrimaryId.getId())+",";
		querySql +=toSqlVal(subpoint.getHeadid())+",";
		querySql +=toSqlVal(subpoint.getCode())+",";
		querySql +=toSqlVal(subpoint.getPathweights())+",";
		querySql +=toSqlVal(subpoint.getNote())+")";
		return querySql;
	}
	
	/**
	 * 取出所有的路径点和查询机点
	 * @return
	 */
	public String get_headnodes(String map_id){
		String querySql = "select ID as id,mapId as mapId,name as name,code as code,x_axis as x,y_axis as y,ifcarsearchpc as ifcarsearchpc from p_pathnodeinfohead where mapId ="+toSqlVal(map_id);
		return querySql;
	}
	
	public String get_oneheadnodesubs(Point headPoint){
		String querySql = "select headid as headid, code as code, pathweights as pathweights from p_pathnodeinfoline where headid ="+toSqlVal(headPoint.getId());
		return querySql;
	}
	
	/**
	 * 删除p_pathnodeinfoline中数据
	 * @param map_id	地图id
	 * @return
	 */
	public String delete_headnodessubs(String map_id){
		String querySql = "delete from p_pathnodeinfoline where headid in (select id from p_pathnodeinfohead where mapId ='"+map_id+"')";
		return querySql;
	}
	
	/**
	 * 删除p_pathnodeinfohead中数据
	 * @param map_id	地图id
	 * @return
	 */
	public String delete_headnodes(String map_id){
		String querySql = "delete from p_pathnodeinfohead where mapId ="+toSqlVal(map_id);
		return querySql;
	}
	
	/**
	 * 添加pathhead
	 * @param p
	 * @return
	 */
	public String save_shortlineheads(PathHead p){
		String querySql = "insert into p_shortestpathinofhead(id,mapid,start,end,weight,note) values ( ";
		querySql +=toSqlVal(p.getId()) + ", ";
		querySql +=toSqlVal(p.getMapId()) + ", ";
		querySql +=toSqlVal(p.getStart()) + ", ";
		querySql +=toSqlVal(p.getEnd()) + ", ";
		querySql +=toSqlVal(p.getWeight()) + ", ";
		querySql +=toSqlVal(p.getNote()) + ")";
		return querySql;
	}
	
	public String save_shortlinesubs(PathHead p){
		String querySql = "insert into p_shortestpathinofline(id,headid,pointid,sort,note) values ( ";
		querySql += toSqlVal(PrimaryId.getId()) + ", ";
		querySql += toSqlVal(p.getHeadid()) + ", ";
		querySql += toSqlVal(p.getPointid()) + ", ";
		querySql += toSqlVal(p.getSort()) + ", ";
		querySql += toSqlVal(p.getNote()) + ")";
		return querySql;
	}
	
	/**
	 * 删除最短路径经过点
	 * @param mapId
	 * @return
	 */
	public String delete_shortestpathinofline(String mapId){
		String querySql = "delete from p_shortestpathinofline where headid in (select id from p_shortestpathinofhead where mapId = '"+mapId+"')";
		return querySql;
	}
	
	/**
	 * 删除最短路径起始及结束点记录
	 * @param mapId
	 * @return
	 */
	public String delete_p_shortestpathinofhead(String mapId){
		String querySql = "delete from p_shortestpathinofhead where mapId ='"+mapId+"'";
		return querySql;
	}
	
	/**
	 * 获取尚未绑定条屏的controllerId
	 * @param mapId
	 * @return
	 */
	public String get_Controllers(String mapId){
		StringBuilder querySql = new StringBuilder();
		querySql.append("select id as id,addr as addr from p_controller where mapId = '")
		.append(mapId).append("' and id not in (select controllerId from p_screen where mapId = '")
		.append(mapId).append("' and controllerId is not null) order by addr");
		//String querySql = "select id as id,addr as addr from p_controller where id not in (select controllerId from p_screen where controllerId is not null) order by addr";
		return querySql.toString();
	}
	
	public String get_controller(){
		String querySql = "select pc.id as id, pc.addr as addr from p_controller pc left join p_screen ps on pc.id = ps.controllerId ";
		return querySql;
	}
	/**
	 * 获取所有controllerId为空的条屏记录
	 * @param mapId
	 * @return
	 */
	public String get_Screens(String mapId){
		StringBuilder querySql = new StringBuilder();
		querySql.append("select id as id,code as code from p_screen where mapId = '")
		.append(mapId)
		.append("' and ( controllerId is null or controllerId not in (select id from p_controller where mapId = '")
		.append(mapId).append("') )order by code");
		//String querySql = "select id as id,code as code from p_screen where controllerId is null order by code";
		return querySql.toString();
	}
	
	public String update_screen(String id,String controllerId){
		String querySql = "update p_screen set controllerId = "+Util.toSqlVal(controllerId)+" where id = "+Util.toSqlVal(id);
		return querySql;
	}
	
	public String get_mapdata(String id){
		String querySql = "select pd.code as code,pp.code as parkingSpaceCode from p_parkingspace pp inner join p_detector pd on pp.detectorId = pd.id left join p_map pm on pd.mapId = pm.id where pm.id = "+Util.toSqlVal(id)+" order by pp.code";
		return querySql;
	}
	
	/**
	 * 获取所有的电梯点
	 * @return
	 */
	public String get_lifts(){
		String querySql = "select mapId as mapId,code as code,x_axis as x,y_axis as y from p_pathnodeinfohead where ifcarsearchpc = '2'";
		return querySql;
	}
	
	/**
	 * 更新地图时判断code不与数据库其他地图的code重复
	 * @param code 探测器编码
	 * @param mapId	地图id
	 * @return
	 */
	public String check_detector(String code,String mapId){
		String querySql = "select concat(pm.name,':',pd.code) as code from p_detector as pd, p_map as pm where pm.id = pd.mapId and pd.code= "+toSqlVal(code)+" and pd.mapId !="+toSqlVal(mapId);
		return querySql;
	}
	
	public String check_screen(String code,String mapId){
		String querySql = "select concat(pm.name,':',ps.code) as code from p_screen as ps, p_map as pm where ps.mapId = pm.id and ps.code = "+toSqlVal(code)+" and ps.mapId !="+toSqlVal(mapId);
		return querySql;
	}
	
	public String get_screens(String mapId){
		String querySql = "select code as code from p_screen where mapId ="+toSqlVal(mapId);
		return querySql;
	}
	
	public String get_controllers(String mapId){
		String querySql = "select addr as addr from p_controller where mapId ="+toSqlVal(mapId);
		return querySql;
	}
	
	public String get_detectors(String mapId){
		String querySql = "select code as code from p_detector where detectorTypeId != '2' and mapId ="+toSqlVal(mapId);
		return querySql;
	}
	
	public String get_grounders(String mapId){
		String querySql = "select code as code from p_detector where detectorTypeId = '2' and mapId ="+toSqlVal(mapId);
		return querySql;
	}
	
	public String delete_parkingSpace(String code){
		String querySql = "delete from p_parkingspace where detectorId = (select id from p_detector where code ="+toSqlVal(code)+")";
		return querySql;
	}
	
	public String delete_detector(String code){
		String querySql = "delete from p_detector where code = "+toSqlVal(code);
		return querySql;
	}
	
	public String delete_screenPara(String code){
		StringBuilder querySql = new StringBuilder();
		querySql.append("delete from p_screenparavalue where screenId = (select id from p_screen where code = ")
		.append(toSqlVal(code)).append(")");
		return querySql.toString();
	}
	public String delete_screenRegion(String code){
		String querySql = "delete from p_screenregion where screenId = (select id from p_screen where code = "+toSqlVal(code)+")";
		return querySql;
	}
	
	public String delete_screen(String code){
		String querySql = "delete from p_screen where code = "+toSqlVal(code);
		return querySql;
	}
	
	public String delete_controller(String addr){
		String querySql = "delete from p_controller where addr ="+toSqlVal(addr);
		return querySql;
	}
	
	public String updateMapImg(MapManageData data){
		StringBuilder querySql = new StringBuilder();
		querySql.append("update p_map set imgPath = '").
		append(data.getImgPath()).append("' where id = '").append(data.getId()).append("'");
		return querySql.toString();
	}
	
	public String getSearchMachineIP(String code,String mapId){
		StringBuilder querySql = new StringBuilder();
		querySql.append("select IP as ip, note as note from p_pathnodeinfohead where code = '")
		.append(code)
		.append("' and mapId = '")
		.append(mapId)
		.append("'");
		return querySql.toString();
	}

	public String map_deleteP_Colortacticstask(String mapId) {
		StringBuilder querySql = new StringBuilder();
		querySql.append("delete  from p_colortacticstask where controllerId in ( select distinct controllerId from p_screen where mapId =").append(toSqlVal(mapId)).append(")");
		return querySql.toString();
	}
}
