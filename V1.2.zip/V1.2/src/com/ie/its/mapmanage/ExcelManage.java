package com.ie.its.mapmanage;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 地图数据excel导出及导入
 * 
 * @author wangj
 * @date 2013-06-19
 */
public class ExcelManage {
	
	/**
	 * 导出excel
	 */
	@SuppressWarnings("rawtypes")
	public static void expExcel(JSONArray sjArr,String filename){
		try{
			WritableWorkbook book = Workbook.createWorkbook(new File(filename));
			WritableFont wf = new WritableFont(WritableFont.ARIAL, 12,WritableFont.BOLD);
			WritableCellFormat wcf = new WritableCellFormat(wf);
			for(int i=0; i<sjArr.size(); i++){
				JSONObject jobj = sjArr.getJSONObject(i);
				WritableSheet sheet = book.createSheet(jobj.getString("name"), i);
				JSONObject dataobj = jobj.getJSONObject("data");
				Iterator keyIter = dataobj.keys();
				
				sheet.addCell(new jxl.write.Label(0,0,"探测器编码(可排序但不要修改)",wcf));
				sheet.addCell(new jxl.write.Label(1,0,"车位编号",wcf));
				
				int j=1;
				while(keyIter.hasNext()){
					String str = keyIter.next().toString();
					sheet.addCell( new jxl.write.Label(0, j,str));
					sheet.addCell( new jxl.write.Label(1, j, dataobj.getString(str)));
					j++;
				}
				sheet.setColumnView(0, 40);
				sheet.setColumnView(1, 40);
			}
			book.write();
			book.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * 导入excel
	 */
	public static JSONArray impExcel(File file){
		JSONArray jarr = new JSONArray();
		try {
			Workbook book = Workbook.getWorkbook(file);
			Sheet[] sheets = book.getSheets();//获取所有的工作表单
			for(int i=0; i<sheets.length; i++){
				JSONObject jobj = new JSONObject();
				JSONObject dobj = new JSONObject();
				Sheet temps = sheets[i];
				jobj.element("name", temps.getName());
				int rowNum = temps.getRows();
				for(int j=1; j<rowNum; j++){//从第2行开始，第1行是标题行
					Cell cell0 = temps.getCell(0, j);
					Cell cell1 = temps.getCell(1, j);
					dobj.element(cell0.getContents().toString(), cell1.getContents().toString());
				}
				jobj.element("data", dobj);
				jarr.add(jobj);
			}
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jarr;
	}
	
	/**
	 * 获取一个excel文件中的所有表单名数组
	 * @param filePath
	 * @return
	 */
	public static String[] getSheetNames(File file){
		String[] sheetNames = new String[]{};
		try {
			Workbook book = Workbook.getWorkbook(file);
			sheetNames = book.getSheetNames();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sheetNames;
	}
}
