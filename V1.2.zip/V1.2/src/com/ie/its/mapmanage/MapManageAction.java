/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.mapmanage;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.io.FileTransfer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;

//命名空间
@Namespace("/map_manage")
@Results({@Result(name="list",location="/map_manage/map_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="map_list",location="list.action",type="redirect")})
public class MapManageAction extends ExtendActionSupport {
	
	private MapManageData data;
	@Autowired
	private MapManageService mapService;
	
	private File myFile;  
	private File myFile_fla;
    private String myFileFileName; 
    private String myFile_flaFileName;
    private String myFileFileContentType;
	public File getMyFile() {
		return myFile;
	}
	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}
	public String getMyFileFileName() {
		return myFileFileName;
	}
	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}
	public String getMyFileFileContentType() {
		return myFileFileContentType;
	}
	public void setMyFileFileContentType(String myFileFileContentType) {
		this.myFileFileContentType = myFileFileContentType;
	}
	public MapManageData getData() {
		return data;
	}
	public void setData(MapManageData data) {
		this.data = data;
	}
	public MapManageAction(){
		if(data == null){
			data = new MapManageData();
		}
	}
	
	/**
     * Description :创建地图向导．
     * @throws :Exception
     * @author LLX 20120822
     */
	@Action(value="map_index",results={@Result(name="success",location="/map_manage/map_index.jsp")})
	public String index(){
		data = mapService.map_list(data);
		setLang(data);
		//获得物理区域下拉框
//		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return SUCCESS;
	}
	
	/**
     * Description :地图数据验证结果
     * @throws :Exception
     * @author LLX 20120822
     */
	@Action(value="map_validateresult",results={@Result(name="success",location="/map_manage/map_validate.jsp")})
	public String map_validateresult(){
		data = mapService.map_list(data);
		setLang(data);
		return SUCCESS;
	}
	
	/**
     * Description :查询地图．
     * @throws :Exception
     */
	@Action(value="map_list",results={@Result(name="success",location="/map_manage/map_list.jsp")})
	public String map_list(){
		data = mapService.map_list(data);
		String sysModel = mapService.queryForSystemModel();
		if(sysModel.equals("2")){
			data.setSysModel(sysModel);
		}
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	/**
     * Description :创建地图．
     * @throws :Exception
     */
	@Action(value="map_create",results={@Result(name="create",location="/map_manage/map_create.jsp")})
	public String create(){
		data.setId("");
		//设置多语言
		setLang(data);
		
		//获得物理区域下拉框
		data.setPhyRegionList(mapService.get_phyRegionCode());
		//获取系统类型
		data.setSysModel(mapService.queryForSystemModel());
		return ConstantClass.ACTION_CREATE;
	}
	
	/**
	 * 根据路径判断文件是否存在
	 * @param path 文件路径
	 * @return 
	 */
	private boolean isFileExits(String path){
		File file = new File(path);
		return file.exists();
	}
	
	@Action(value="saveImg",results={@Result(type="json")})
	public void saveImg(){
		JSONObject jobj = new JSONObject();
		String path = StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/";//upload文件夹路径
		data.setPath(path);
		data.setImgPath(path + this.getMyFileFileName());
		boolean flag = false;
		if(isFileExits(path + this.getMyFileFileName())){
			jobj.element("message", "file exists");
		}else{
			try {
				handleUploadFile(data);
				if(mapService.updateMapImg(data)){
					flag = true;
					jobj.element("message", "更新地图图片路径成功");
				}else{
					flag = false;
					jobj.element("message", "更新地图图片路径失败");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				jobj.element("message", "file upload error");
			}
		}
		//通过ajaxFileUpload进行调用的方法必须加这个 不然返回中文乱码
		jobj.element("flag", flag);
		response.setContentType("text/html");
		setJsonRes(jobj);
		
	}
	/**
     * Description :保存地图．
     * @throws :Exception
     */
	@SuppressWarnings("rawtypes")
	@Action(value="map_save",results={@Result(type="json")})
	public void map_save(){
		JSONObject json =  new JSONObject();
		
		try{
			if(mapService.read(data)){//判断地图号与地图名是否重复
				if(mapService.readExits(data)){//判断地图记录是否存在
					json = mapFileHandle(data);//首先处理地图文件
					if(json.getBoolean("success")){
						String mapType = data.getFilename();
						if(mapType.substring(mapType.lastIndexOf(".") + 1, mapType.length()).equals("swf") || mapType.substring(mapType.lastIndexOf(".") + 1, mapType.length()).equals("fla")){
							//如果成功则保存地图信息
							data = mapService.map_save(data);
						}else{
							json.element("success", false);
							Map m = new HashMap();
							m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
							json.element("ex", m.get("alert_upload_file_type_error").toString());
						}
					}
				}else{
					json.element("success", false);
				}	
			}else{
				json.element("success", false);
				json.element("ex", "");
			}
			
		}catch(Exception e){
			//存在相同文件 返回错误提示
			e.printStackTrace();
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		//通过ajaxFileUpload进行调用的方法必须加这个 不然返回中文乱码
		response.setContentType("text/html");
		setJsonRes(json);
	}
	
	/**
     * Description :编辑地图．
     * @throws :Exception
     */
	@Action(value="map_edit",results={@Result(name="edit",location="/map_manage/map_edit.jsp")})
	public String map_edit(){
		mapService.map_get(data);
		
		//设置多语言
		setLang(data);
		
		//获得物理区域下拉框
		data.setPhyRegionList(mapService.get_phyRegionCode());
		return ConstantClass.ACTION_EDIT;
	}
	
	/**
     * Description :更新地图．
     * @throws :Exception
     */
	@SuppressWarnings("rawtypes")
	@Action(value="map_update",results={@Result(type="json")})
	public void map_update(){	
		JSONObject json =  new JSONObject();
		
		try{
			if(mapService.read(data)){
				//首先处理地图文件
				json = mapFileHandle(data);
				//如果成功则保存地图信息
				if(json.getBoolean("success")){
					String mapType = data.getFilename();
					if(mapType != ""){
						if(mapType.substring(mapType.lastIndexOf(".") + 1, mapType.length()).equals("swf") || mapType.substring(mapType.lastIndexOf(".") + 1, mapType.length()).equals("fla")){
							data = mapService.map_update(data);
						}else{
							json.element("success", false);
							Map m = new HashMap();
							m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
							json.element("ex", m.get("alert_upload_file_type_error").toString());
						}
					}else{
						data = mapService.map_update(data);
					}
				}	
			}else{
				json.element("ex", "");
				json.element("success", false);
			}
			
		}catch(Exception e){
			//存在相同文件 返回错误提示
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		//通过ajaxFileUpload进行调用的方法必须加这个 不然返回中文乱码
		response.setContentType("text/html");
		
		setJsonRes(json);
	}
	/**
     * Description :删除地图．
     * @throws :Exception
     */
	@Action(value="map_delete",results={@Result(type="json")})
	public void map_delete(){
		JSONObject json =  new JSONObject();
		try{
			mapService.map_delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
	
		setJsonRes(json);
	}

	/**
     * Description :检查地图是否已经导入数据．
     * @throws :Exception
     */
	@Action(value="check_mapIsImp",results={@Result(type="json")})
	public void check_mapIsImp(){		
		JSONObject json =  new JSONObject();
		boolean flag = true;
		
		//首先判断地图文件是否存在 
		if(mapService.check_mapIsImpFile(data)){
			//如果存在文件 则判断地图数据是否已经导入
			flag = mapService.check_mapIsImpData(data);
			
			if(!flag){
				json.element("msg", "1");
			}
		}else{
			flag = false;
			json.element("msg", "2");
		}
		
		json.element("success", flag);
	
		
		setJsonRes(json);
	}
	
	/**
     * Description :地图文件处理．
     * @throws :Exception
     */
	private JSONObject mapFileHandle(MapManageData data) throws Exception{
		JSONObject json = new JSONObject();
		
		json.element("success", true);
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
		data.setFilename(this.getMyFileFileName());
		
		if(Util.isCon(this.getMyFileFileName())){
			//首先判断文件是否存在
			if(mapService.map_impcheck(data)){
				handleUploadFile(data);
			}else{
				//存在相同文件 返回错误提示
				json.element("success", false);
				json.element("message", "file exist");
			}
			
		}else{
			data.setPath("");
			data.setFilename("");
		}
		return json;
		
	}
	/**
     * Description :导入地图保存．
     * @throws :Exception
     */
	@Action(value="map_impsave",results={@Result(type="json")})
	public void map_impsave() throws Exception{
		JSONObject json =  new JSONObject();
	
		//保存的文件路径
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
		Log.log(data.getPath());
		data.setFilename(this.getMyFileFileName());
		//检查是否有重复文件 如果有 则返回错误
		if(mapService.map_impcheck(data)){
			try{
				handleUploadFile(data);
				mapService.map_impsave(data);
			}catch(Exception e){
				//如果出现异常 则删除文件
				File file = new File(data.getPath());
				file.deleteOnExit();
				
				throw new ExtendUnCheckException(e);
			}
			json.element("success", true);
		}else{
			json.element("success", false);
			json.element("message", "file exist");
		}
		
		
		setJsonRes(json);
	}

	/**
     * Description :处理文件上传方法．
     * @param  :MapManageData
     * @throws :Exception
     */
	public void handleUploadFile(MapManageData data)throws IOException{
		int j=1;
		if(this.getMyFile_flaFileName()!=null){
			j=2;
		}
		for(int i=0;i<j;i++){
			File newFile=null;
			if(i==0){
				newFile = new File(data.getPath()+this.getMyFileFileName());
			}
			else {
				newFile = new File(data.getPath()+this.getMyFile_flaFileName());
			}
			
			if(!new File(data.getPath()).isDirectory()){
	            new File(data.getPath()).mkdirs();
	        }
			if(!newFile.exists()){
				newFile.createNewFile();
			}
			
			FileInputStream inputStream = null;
			FileOutputStream outputStream = null;
			if(i==0){
				inputStream = new FileInputStream(this.getMyFile());  
		        outputStream = new FileOutputStream(newFile);
			}
			else{
				inputStream = new FileInputStream(this.getMyFile_fla());  
		        outputStream = new FileOutputStream(newFile); 
			}
			byte[] buf = new byte[1024];
			int length = 0;
			while ((length = inputStream.read(buf)) != -1) {
				outputStream.write(buf, 0, length);
			}
			inputStream.close();
			outputStream.flush();
			outputStream.close();
		}
	}
	
	/**
     * Description :处理模板下载方法．
     * @param  :FileTransfer
     * @throws :Exception
     * added by LLX 20120822
     */
	public FileTransfer downloadFile(String fileName) throws IOException {
		WebContext webContext = WebContextFactory.get();
//		String realtivepath = webContext.getContextPath() + "/upload/";
		String saveurl = webContext.getHttpServletRequest().getSession()
				.getServletContext().getRealPath("/upload");
		String filename = "MapTemplate";
		String pexName = ".fla";
		String versionName ="";
		String configurl = "";
		try {
			configurl = (getClass().getClassLoader().getResource("").toURI()).getPath();							
			//当无该对应文件时，默认下载MapTemplate.fla文件 add by tanx		
			File filenamePropertiesFile = new File(configurl+"/config.properties");
			FileInputStream in = new FileInputStream(filenamePropertiesFile);
			Properties filenameProperties = new Properties();		
			filenameProperties.load(in);
			versionName = filenameProperties.getProperty("version");
			versionName = versionName.substring(versionName.lastIndexOf("V"), versionName.length());
						
		} catch (URISyntaxException e1) {			
			//当无该对应文件时，默认下载MapTemplate.fla文件             add by tanx
			Log.log("模板版本控制配置文件没有找到，直接使用默认模板文件");
			versionName = "";
		} catch (FileNotFoundException e) {
			//当无该对应文件时，默认下载MapTemplate.fla文件             add by tanx
			Log.log("模板版本控制配置文件没有找到，直接使用默认模板文件");
			versionName = "";
		}
		filename = filename + versionName +pexName;
		String tempUrl = saveurl;
		saveurl += "/" + filename;		
		File file = new File(saveurl);	
		
		if(!file.exists()){
			Log.log("版本"+versionName+"模板文件没找到，直接使用默认模板文件");
			file = new File(tempUrl+"/" + "MapTemplate.fla" );	
			filename = "MapTemplate.fla";
		}
		
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		ByteArrayOutputStream out = null;
		try {
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			out = new ByteArrayOutputStream();
			byte[] temp = new byte[1024];
			int size = 0;
			while ((size = bis.read(temp)) != -1) {
				out.write(temp, 0, size);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		return new FileTransfer(new String( filename.getBytes("GBK"),"iso8859-1" ), "application/xls",out.toByteArray());
	}
	
	/**
     * Description :显示导入flash数据页面．
     * @throws :Exception
     */
	@Action(value="map_impdata",results={@Result(name="success",location="/map_manage/map_impdata.jsp")})
	public String map_list_screentask(){
		data = mapService.map_list(data);
		data.setMap_src(mapService.map_getSrc(data.getId()));
		data.setImpDataTypeList(DisposalCode.getCode("map_dtype",request.getSession().getAttribute("lang").toString()));
		//系统类型
		String sysModel = mapService.queryForSystemModel();
		data.setSysModel(sysModel);
		//设置多语言
		setLang(data);
		return SUCCESS;
	}
	
	/**
	 * 更新地图数据，包括增量、减量、增减
	 * @return
	 */
	@Action(value="update_mapdata",results={@Result(name="success",location="/map_manage/update_mapdata.jsp")})
	public String update_mapdata(){
		data.setMap_src(mapService.map_getSrc(data.getId()));
		data.setImpDataTypeList(DisposalCode.getCode("map_dtype",request.getSession().getAttribute("lang").toString()));
		//系统类型
		String sysModel = mapService.queryForSystemModel();
		data.setSysModel(sysModel);
		//设置多语言
		setLang(data);
		return SUCCESS;
	}
	
	/**
	 * 增量地图上传处理办法
	 */
	@Action(value="save_updatemap",results={@Result(type="json")})
	public void save_updatemap(){
		JSONObject json =  new JSONObject();	
		//保存的文件路径
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
		Log.log(data.getPath());
		data.setFilename(this.getMyFileFileName());
		setLang(data); //设置多语言
		Map map = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
		//检查是否有重复文件 如果有 则返回错误
		if(mapService.map_impcheck(data)){
			try{
				handleUploadFile(data);
				json.element("success", true);
				json.element("path", "../"+ConstantClass.MAP_DIR +"/"+this.getMyFileFileName());
				json.element("mapSrc", data.getPath()+data.getFilename());
				json.element("sysModel", mapService.queryForSystemModel());
			}catch(Exception e){
				//如果出现异常 则删除文件
				File file = new File(data.getPath());
				file.deleteOnExit();
				json.element("success", false);
				throw new ExtendUnCheckException(e);
			}
		}else{
			json.element("success", false);
			json.element("message", map.get("alert_map_already_exists").toString());
		}
		//通过ajaxFileUpload进行调用的方法必须加这个 不然返回中文乱码
		response.setContentType("text/html");
		
		setJsonRes(json);
	}
	
	/**
	 * 更新地图的数据校验
	 */
	@Action(value="updatemap_check",results={@Result(type="json")})
	public void updatemap_check(){
		JSONObject obj = new JSONObject();
		setLang(data);	//多语言
		obj = mapService.updatemap_check(data);
		setJsonRes(obj);
	}
	
	/**
	 * 更新地图的数据导入
	 */
	@Action(value="updatemap_imp",results={@Result(type="json")})
	public void updatemap_imp(){
		JSONObject obj = new JSONObject();
		setLang(data); //多语言
		Log.log("新地图路径：" + data.getMap_src());
		obj = mapService.updatemap_imp(data);
		setJsonRes(obj);
	}
	
	
	/**
     * Description :导入flash数据页面．
     * @throws :Exception
     */
	@Action(value="map_savedata",results={@Result(type="json")})
	public void map_savedata(){
		JSONObject json =  new JSONObject();
		setLang(data);
		try{
			data = mapService.map_savedata(data, request.getSession().getAttribute("lang").toString());
			
			if(request.getSession().getAttribute("register").equals("0")){
				json.element("message", true);
			}else{
				json.element("message", false);
			}
			json.element("dall", data.getDetectorError2());
			json.element("success", data.isErrorflag());
			json.element("derror", data.getDetectorError());
			json.element("drepeat", data.getDrepeat());
			json.element("srepeat", data.getSrepeat());
			json.element("grepeat", data.getGrepeat());
			json.element("pointerror", data.getPointsError());
		}catch(DuplicateKeyException de){//地图已经导入，目前未启用
			json.element("success", false);			
			HashMap lang = (HashMap) data.getCurrent_lang_switch().get("common");
			json.element("ex", lang.get("alert_map_already_import"));
		}catch(Exception e){
			e.printStackTrace();
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
	 * 导出地图数据判断是否地图数据已导入
	 */
	@Action(value="before_expcheck",results={@Result(type="json")})
	public void before_expcheck(){
		setLang(data);
		JSONObject jobj = mapService.checkMapImport(data.getId());
		setJsonRes(jobj);
	}
	
	/**
	 * 导出地图数据excel
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@Action(value="exp_mapdata",results={@Result(name="success",location="/parking_statistics/excel_out.jsp")})
	public String exp_mapdata() throws UnsupportedEncodingException{
		String ids = request.getParameter("ids");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String filename = "地图数据"+sdf.format(new Date());
		ExcelManage.expExcel(mapService.getMapData(ids),filename+".xls");
		request.setCharacterEncoding("UTF-8");
		request.setAttribute("file_name",filename);
		return SUCCESS;
	}
	
	@Action(value="save_excel",results={@Result(type="json")})
	public void save_excel(){
		setLang(data);
		HashMap lang = (HashMap) data.getCurrent_lang_switch().get("common");
		JSONObject jobj = new JSONObject();
		//保存的文件路径
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/"+ ConstantClass.Excel_DIR +"/");
		data.setFilename(this.getMyFileFileName());
		try {
			handleUploadFile(data);
			String filePath = data.getPath()+data.getFilename();
			File file = new File(filePath);
			if(file.exists()){
				JSONObject obj = mapService.beforeImpCheck(file);
				if(obj.getBoolean("flag")){
					JSONArray jarr = ExcelManage.impExcel(file);
					//System.out.println(jarr);
					JSONObject iobj = mapService.impExcelData(jarr);
					jobj.element("flag",true);
					jobj.element("message", lang.get("mapdata_import_excel").toString()+lang.get("process_success").toString());
				}else{
					jobj.element("flag", obj.getBoolean("flag"));
					jobj.element("message", lang.get("sheet_name")+obj.getString("name")+lang.get("notmatch_mapname"));
				}
			}else{
				jobj.element("flag", false);
				jobj.element("message", lang.get("fileupload_failed"));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//通过ajaxFileUpload进行调用的方法必须加这个 不然返回中文乱码
		response.setContentType("text/html");
		setJsonRes(jobj);
	}
	
	/**
	 * 校验当前地图的电梯点与数据库的电梯点
	 * 数据库中无电梯点，返回true
	 * 数据库有电梯点，则按地图分组，当前地图上电梯点的命名、数量、位置与数据库相同，返回true；否则返回false
	 */
	@Action(value="check_lifts",results={@Result(type="json")})
	public void checkLiftPoints(){
		setLang(data);
		JSONObject jobj = mapService.getDBLiftPoints(data);
		setJsonRes(jobj);
	}
	/**
	 * @return the myFile_fla
	 */
	public File getMyFile_fla() {
		return myFile_fla;
	}
	/**
	 * @param myFile_fla the myFile_fla to set
	 */
	public void setMyFile_fla(File myFile_fla) {
		this.myFile_fla = myFile_fla;
	}
	/**
	 * @return the myFile_flaFileName
	 */
	public String getMyFile_flaFileName() {
		return myFile_flaFileName;
	}
	/**
	 * @param myFile_flaFileName the myFile_flaFileName to set
	 */
	public void setMyFile_flaFileName(String myFile_flaFileName) {
		this.myFile_flaFileName = myFile_flaFileName;
	}
}
