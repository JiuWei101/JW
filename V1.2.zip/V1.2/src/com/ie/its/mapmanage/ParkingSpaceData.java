package com.ie.its.mapmanage;

import java.util.List;

import com.ie.common.Log;
import com.ie.frame.ExtendData;

public class ParkingSpaceData extends ExtendData{
	
	private String id;				//车位流水记录id
	private String parkingSpaceId;	//车位id
	private String spotType;		//车位类型
	private String inuse;			//是否有车
	private String inTime;			//入车时间
	private String outTime;			//出车时间
	private String detectorId;		//探测器id
	private String guideRegionId;	//地图引导区id
	private String logicId;			//地图逻辑区id
	private String lightRegionId;	//灯光区域id
	private String code;			//车位编号
	private String enable;			//是否启用
	private String useDate;			//被占用时间？？
	private String updateDate;		//最后更新时间
	private String notes;			//备注
	private String physicalRegionId;//物理区域id
	

	private String s_type;			//查询类型 年月日
	private String s_year;			//查询年
	private String s_month;			//查询月
	private String s_b_date;		//查询开始日期
	private String s_e_date;		//查询结束日期
	private String s_logic_id;		//查询逻辑区域
	private String s_spot_type;		//查询车位类型
	
	private List yearList;			//查询下拉框  年
	private List monthList;			//查询下拉框  月
	private List logicIdList;		//查询下拉框  逻辑区
	private List spotTypeList;		//查询下拉框  车位类型

	private String p_month;			//月份
	private String p_day;			//日期
	private String p_hour;			//小时
	private String in_times;		//入车数
	private String out_times;		//出车数

	private String plateno;			//车牌号
	private String picturepath;	    //最新车位图片路径
	
	public String getPlateno() {
		return plateno;
	}

	public void setPlateno(String plateno) {
		this.plateno = plateno;
	}

	public String getPicturepath() {
		return picturepath;
	}

	public void setPicturepath(String picturepath) {
		this.picturepath = picturepath;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getS_b_date() {
		return s_b_date;
	}

	public void setS_b_date(String s_b_date) {
		this.s_b_date = s_b_date;
	}

	public String getS_e_date() {
		return s_e_date;
	}

	public void setS_e_date(String s_e_date) {
		this.s_e_date = s_e_date;
	}

	public String getParkingSpaceId() {
		return parkingSpaceId;
	}

	public void setParkingSpaceId(String parkingSpaceId) {
		this.parkingSpaceId = parkingSpaceId;
	}

	public String getSpotType() {
		return spotType;
	}

	public void setSpotType(String spotType) {
		this.spotType = spotType;
	}

	public String getInuse() {
		return inuse;
	}

	public void setInuse(String inuse) {
		this.inuse = inuse;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public String getDetectorId() {
		return detectorId;
	}

	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}

	public String getGuideRegionId() {
		return guideRegionId;
	}

	public void setGuideRegionId(String guideRegionId) {
		this.guideRegionId = guideRegionId;
	}

	public String getLogicId() {
		return logicId;
	}

	public void setLogicId(String logicId) {
		this.logicId = logicId;
	}

	public String getLightRegionId() {
		return lightRegionId;
	}

	public void setLightRegionId(String lightRegionId) {
		this.lightRegionId = lightRegionId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getEnable() {
		return enable;
	}

	public void setEnable(String enable) {
		this.enable = enable;
	}

	public String getUseDate() {
		return useDate;
	}

	public void setUseDate(String useDate) {
		this.useDate = useDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getS_logic_id() {
		return s_logic_id;
	}

	public void setS_logic_id(String s_logic_id) {
		this.s_logic_id = s_logic_id;
	}

	public String getS_spot_type() {
		return s_spot_type;
	}

	public void setS_spot_type(String s_spot_type) {
		this.s_spot_type = s_spot_type;
	}


	public String getP_day() {
		return p_day;
	}

	public void setP_day(String p_day) {
		this.p_day = p_day;
	}

	public String getP_hour() {
		return p_hour;
	}

	public void setP_hour(String p_hour) {
		this.p_hour = p_hour;
	}

	public String getOut_times() {
		return out_times;
	}

	public void setOut_times(String out_times) {
		this.out_times = out_times;
	}

	public String getS_type() {
		return s_type;
	}

	public void setS_type(String s_type) {
		this.s_type = s_type;
	}

	
	public String getIn_times() {
		return in_times;
	}

	public void setIn_times(String in_times) {
		this.in_times = in_times;
	}

	public List getYearList() {
		return yearList;
	}

	public void setYearList(List yearList) {
		this.yearList = yearList;
	}

	public List getMonthList() {
		return monthList;
	}

	public void setMonthList(List monthList) {
		this.monthList = monthList;
	}

	public List getLogicIdList() {
		return logicIdList;
	}

	public void setLogicIdList(List logicIdList) {
		this.logicIdList = logicIdList;
	}

	public List getSpotTypeList() {
		return spotTypeList;
	}

	public void setSpotTypeList(List spotTypeList) {
		this.spotTypeList = spotTypeList;
	}

	public String getS_year() {
		return s_year;
	}

	public void setS_year(String s_year) {
		this.s_year = s_year;
	}

	public String getS_month() {
		return s_month;
	}

	public void setS_month(String s_month) {
		this.s_month = s_month;
	}

	public String getP_month() {
		return p_month;
	}

	public void setP_month(String p_month) {
		this.p_month = p_month;
	}

	public String getPhysicalRegionId() {
		return physicalRegionId;
	}

	public void setPhysicalRegionId(String physicalRegionId) {
		this.physicalRegionId = physicalRegionId;
	}
	
	
	
}
