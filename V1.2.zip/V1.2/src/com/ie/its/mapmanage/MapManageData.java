/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.mapmanage;

import java.util.ArrayList;
import java.util.List;

import com.ie.frame.ExtendData;

public class MapManageData extends ExtendData{
	private String physicalRegionId;	//停车场物理区域ID(楼层)
	private String type;				//存储类型
	private String path;				//路径
	private String notes;				//备注
	private List phyRegionList;			//物理区域下拉框
	private List impDataTypeList;		//导入地图数据类型list
	private String filename;			//检查时使用 
	private String number;				//地图号
	private String name;				//地图名
	private String map_src;				//页面获取得图的地址
	private String imp_type;			//导入地图数据的类型 screen为引导屏  detector 为探测器
	private String imp_data_de;			//导入数据探测器
	private String imp_data_sc;			//导入数据引导屏
	private String imp_data_gr;			//导入数据地感
	private int parkingSum;				//车位数
	private int screenSum;				//屏数
	private int importOrNot;			//是否导入
	private String detectorError;		//探测器地址错误提示
	private String detectorError2;		//探测器地址重复错误提示
	private String screenError;			//引导屏编号错误提示
	private String screenError2;		//引导屏编号重复错误
	private String groundError;			//地感地址错误
	private String groundError2;		//地感地址重复错误
	
	private String drepeat;
	private String srepeat;
	private String grepeat;
	
	private double legend;				//图例
	
	private String imp_data_linepoint;	//地图路径点
	private String imp_data_machinepoint; //查询机点
	private String imp_data_liftentrance; //电梯入口点
	private String imp_data_dimension; //二维码点
	private String pointsError;		//点错误
	private boolean errorflag;      //错误全局标识
	
	private String imgPath;		//地图图片路径
	
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public String getImp_data_dimension() {
		return imp_data_dimension;
	}
	public void setImp_data_dimension(String imp_data_dimension) {
		this.imp_data_dimension = imp_data_dimension;
	}
	public boolean isErrorflag() {
		return errorflag;
	}
	public void setErrorflag(boolean errorflag) {
		this.errorflag = errorflag;
	}
	public String getPointsError() {
		return pointsError;
	}
	public void setPointsError(String pointsError) {
		this.pointsError = pointsError;
	}
	public String getImp_data_liftentrance() {
		return imp_data_liftentrance;
	}
	public void setImp_data_liftentrance(String imp_data_liftentrance) {
		this.imp_data_liftentrance = imp_data_liftentrance;
	}
	public String getImp_data_machinepoint() {
		return imp_data_machinepoint;
	}
	public void setImp_data_machinepoint(String imp_data_machinepoint) {
		this.imp_data_machinepoint = imp_data_machinepoint;
	}
	public String getImp_data_linepoint() {
		return imp_data_linepoint;
	}
	public void setImp_data_linepoint(String imp_data_linepoint) {
		this.imp_data_linepoint = imp_data_linepoint;
	}
	public double getLegend() {
		return legend;
	}
	public void setLegend(double legend) {
		this.legend = legend;
	}
	public String getDrepeat() {
		return drepeat;
	}
	public void setDrepeat(String drepeat) {
		this.drepeat = drepeat;
	}
	public String getSrepeat() {
		return srepeat;
	}
	public void setSrepeat(String srepeat) {
		this.srepeat = srepeat;
	}
	public String getGrepeat() {
		return grepeat;
	}
	public void setGrepeat(String grepeat) {
		this.grepeat = grepeat;
	}
	public List getImpDataTypeList() {
		return impDataTypeList;
	}
	public void setImpDataTypeList(List impDataTypeList) {
		this.impDataTypeList = impDataTypeList;
	}
	
	public String getImp_data_de() {
		return imp_data_de;
	}
	public void setImp_data_de(String imp_data_de) {
		this.imp_data_de = imp_data_de;
	}
	public String getImp_data_sc() {
		return imp_data_sc;
	}
	public void setImp_data_sc(String imp_data_sc) {
		this.imp_data_sc = imp_data_sc;
	}
	/**
	 * @return the imp_data_gr
	 */
	public String getImp_data_gr() {
		return imp_data_gr;
	}
	/**
	 * @param imp_data_gr the imp_data_gr to set
	 */
	public void setImp_data_gr(String imp_data_gr) {
		this.imp_data_gr = imp_data_gr;
	}
	public String getMap_src() {
		return map_src;
	}
	public void setMap_src(String map_src) {
		this.map_src = map_src;
	}
	public String getFilename() {
		return filename;
	}
	public String getImp_type() {
		return imp_type;
	}
	public void setImp_type(String imp_type) {
		this.imp_type = imp_type;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getPhysicalRegionId() {
		return physicalRegionId;
	}
	public List getPhyRegionList() {
		return phyRegionList;
	}
	public void setPhyRegionList(List phyRegionList) {
		this.phyRegionList = phyRegionList;
	}
	public void setPhysicalRegionId(String physicalRegionId) {
		this.physicalRegionId = physicalRegionId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getParkingSum() {
		return parkingSum;
	}
	public void setParkingSum(int parkingSum) {
		this.parkingSum = parkingSum;
	}
	public int getScreenSum() {
		return screenSum;
	}
	public void setScreenSum(int screenSum) {
		this.screenSum = screenSum;
	}
	public int getImportOrNot() {
		return importOrNot;
	}
	public void setImportOrNot(int importOrNot) {
		this.importOrNot = importOrNot;
	}
	public String getDetectorError() {
		return detectorError;
	}
	public void setDetectorError(String detectorError) {
		this.detectorError = detectorError;
	}
	public String getScreenError() {
		return screenError;
	}
	public void setScreenError(String screenError) {
		this.screenError = screenError;
	}
	public String getGroundError() {
		return groundError;
	}
	public void setGroundError(String groundError) {
		this.groundError = groundError;
	}
	public String getDetectorError2() {
		return detectorError2;
	}
	public void setDetectorError2(String detectorError2) {
		this.detectorError2 = detectorError2;
	}
	public String getScreenError2() {
		return screenError2;
	}
	public void setScreenError2(String screenError2) {
		this.screenError2 = screenError2;
	}
	public String getGroundError2() {
		return groundError2;
	}
	public void setGroundError2(String groundError2) {
		this.groundError2 = groundError2;
	}
	
}
