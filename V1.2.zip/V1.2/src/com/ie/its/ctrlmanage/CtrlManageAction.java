/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 管理器管理
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.ctrlmanage;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.frame.ExtendActionSupport;

//命名空间
@Namespace("/ctrl_manage")
@Results({@Result(name="list",location="/ctrl_manage/list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="list",location="list.action",type="redirect")})
public class CtrlManageAction extends ExtendActionSupport {
	
	private CtrlManageData data;
	@Autowired
	private CtrlManageService ctrlManageService;
	
	public CtrlManageAction(){
		if(data == null){
			data = new CtrlManageData();
		}
	}
	/**
     * Description :查询图书．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="ctrl_list",results={@Result(name="success",location="/ctrl_manage/ctrl_list.jsp")})
	public String ctrl_list(){
		data = ctrlManageService.ctrl_list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return SUCCESS;
	}
	
	
	
	public CtrlManageService getCtrlManageService() {
		return ctrlManageService;
	}
	public void setCtrlManageService(CtrlManageService ctrlManageService) {
		this.ctrlManageService = ctrlManageService;
	}
}
