package com.ie.its.ctrlmanage;

import static com.ie.common.Util.*;
import com.ie.frame.ExtendSql;

public class CtrlManageSql extends ExtendSql{
	/**
     * Description :查询图书．
     * @param  :book,type
     * @return :String
     */
	public String ctrl_list(CtrlManageData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*) from p_controller where 1=1 ";
		}else{
			querySql += "select * from p_controller where 1=1 ";
		}
		
		
		
		return querySql;
	}
}
