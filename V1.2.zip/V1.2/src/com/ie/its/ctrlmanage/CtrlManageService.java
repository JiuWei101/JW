/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.ctrlmanage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
@Scope("prototype")
@Service
public class CtrlManageService extends ExtendService {
	private CtrlManageSql ctrlSql;
	
	public CtrlManageService(){
		ctrlSql = new CtrlManageSql();
	}


	/**
     * Description :查询管理器．
     * @param  :CtrlManageData
     * @return :CtrlManageData
     * @throws :Exception
     */
	public CtrlManageData ctrl_list(CtrlManageData data) {
		//获得数量
		int count = this.getJt().queryForInt(ctrlSql.ctrl_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <CtrlManageData>rows = this.getJt().<CtrlManageData>queryForListExt(ctrlSql.ctrl_list(data, ""), 
				data.getStart(), data.getLimit(),CtrlManageData.class);
		
		//转换编码
//		for(CtrlManageData tempData:rows){
//			tempData.setType2(DisposalCode.getCodeName(tempData.getType2(), "cdddyfs"));
//		}
		
		data.setPer_data(rows);
		return data;
	}
}
