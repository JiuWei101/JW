/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导区域配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.guideregionmanage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.CodeData;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.inifile.IniFileCreator;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class GuideRegionManageService extends ExtendService {
	private GuideRegionManageSql guideregionSql;
	
	public GuideRegionManageService(){
		guideregionSql = new GuideRegionManageSql();
	}


	/**
     * Description :查询引导区域．
     * @param  :GuideregionData
     * @return :GuideregionData
     * @throws :Exception
     */
	public GuideRegionManageData guideregion_list(GuideRegionManageData data) {
		//获得数量
		int count = this.getJt().queryForInt(guideregionSql.guideregion_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+guideregionSql.guideregion_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <GuideRegionManageData>rows = this.getJt().<GuideRegionManageData>queryForListExt(guideregionSql.guideregion_list(data, ""), 
				data.getStart(), data.getLimit(),GuideRegionManageData.class);
		
		//转换编码
		for(GuideRegionManageData tempData:rows){
			tempData.setRegionTypeName((String) ((HashMap)data.getCurrent_lang_switch().get("detector_type")).get(tempData.getRegionType()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :保存引导区域．
     * @param  :GuideregionData
     * @return :GuideregionData
     * @throws :Exception
     */
	public GuideRegionManageData guideregion_save(GuideRegionManageData data) {
		String[] sql = new String[1];
		
		if(data.getId() == null || "".equals(data.getId())){
			
			if(data.isCheck()){
				if(Util.isCon(data.getStart_g()) && Util.isCon(data.getEnd_g())){
					int length = data.getEnd_g() - data.getStart_g();
					sql = new String[length + 1];
					String name = data.getName();
					String code = data.getCode();
					for(int i = 0; i <= data.getEnd_g() - data.getStart_g(); i++){
						data.setId(PrimaryId.getId());
						data.setName(name + i);
						data.setCode(code + i);
						sql[i] = guideregionSql.guideregion_save(data);
					}
				}
			}else{
				data.setId(PrimaryId.getId());
				sql[0] = guideregionSql.guideregion_save(data);
			}
			
		} else {
			List list = this.getJt().queryForList(guideregionSql.guideregion_code_change(data));
			if(list.size() > 0){
				sql[0] = guideregionSql.guideregion_update(data);
			} else {
				sql = new String[2];
				sql[0] = guideregionSql.guideregion_update(data);
				sql[1] = guideregionSql.guideregion_detector_delete(data.getId());
			}
		}
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :删除引导区域．
     * @param  :GuideregionData
     * @return :GuideregionData
     * @throws :Exception
     */
	public GuideRegionManageData guideregion_delete(GuideRegionManageData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length * 2];
		for(int i = 0;i < id.length;i++){
			sql[i * 2] = guideregionSql.guideregion_delete(id[i]); 
			sql[i * 2 + 1] = guideregionSql.guideregion_detector_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :检查是否屏分区中引用要删除的引导区．
     * @param  :GuideregionData
     * @return :GuideregionData
     * @throws :Exception
     */
	public boolean check_refrence_delete(GuideRegionManageData data) {
		String[] id= data.getId().split(";");
		for(int i = 0;i < id.length;i++){
			int count = this.getJt().queryForInt(guideregionSql.check_refrence_delete(id[i]));
			if(count > 0){
				return false;
			}
		}
		return true;
	}
	/**
     * Description :检查是否屏分区中引用要更改编号的引导区．
     * @param  :GuideregionData
     * @return :GuideregionData
     * @throws :Exception
     */
	public boolean check_refrence_update(GuideRegionManageData data) {
		int count = this.getJt().queryForInt(guideregionSql.check_refrence_update(data));
		if(count > 0){
			return false;
		} else {
			return true;
		}
	}


	/**
	 * 获取探测器类型
	 * @param data
	 * @return
	 */
	public List getTypeList(GuideRegionManageData data) {
		List typeList = Util.getCodeList(data, "detector_type");
//		List rt = new ArrayList();
//		for(int i = 0; i < typeList.size(); i++){
//			int size = rt.size();
//			for(int j = 0; j < size; j++){
//				Log.log(((CodeData)typeList.get(i)).getCode_id());
//				Log.log(((CodeData)rt.get(j)).getCode_id());
//				Log.log(((CodeData)typeList.get(i)).getCode_id().compareTo(((CodeData)rt.get(j)).getCode_id()) );
//				if(((CodeData)typeList.get(i)).getCode_id().compareTo(((CodeData)rt.get(j)).getCode_id()) > 0){
//					continue;
//				}
//				rt.add(j, typeList.get(i));
//			}
//			if(rt.size() < i + 1){
//				rt.add(typeList.get(i));
//				continue;
//			}
//		}
		//删除AKE屏作为引导区
		for(int i = 0; i < typeList.size(); i++){
			CodeData cd=(CodeData)typeList.get(i);
			if(cd.getCode_id().equals("5")){
				typeList.remove(i);
				break;
			}
		}
		return typeList;
	}

	/**
	 * 判断引导区域是否已经存在
	 * @param data
	 * @return
	 */
	public boolean readIsExits(GuideRegionManageData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(guideregionSql.readExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 获取地图列表
	 * @return
	 */
	public List getMapList(){
		List<GuideRegionManageData> mlist = new ArrayList<GuideRegionManageData>();
		mlist = this.getJt().queryForListExt(guideregionSql.getMapList(), GuideRegionManageData.class);
		return mlist;
	}
}
