/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——引导区域配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.guideregionmanage;

import static com.ie.common.Util.*;

import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;

public class GuideRegionManageSql extends ExtendSql{
	/**
     * Description :查询引导区域．
     * @param  :GuideregionData,String
     * @return :String
     */
	public String guideregion_list(GuideRegionManageData data,String type) {
		String querySql = "";
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  gr.id,gr.name,gr.code,gr.regionType,gr.notes ";
		}
//		querySql += " from p_guideregion gr where gr.deleteFlag<>'1' order by gr.code";
		querySql += " from p_guideregion gr order by gr.code";
		return querySql;
	}
	
	/**
     * Description :保存引导区域信息．
     * @param  :GuideregionData
     * @return :String
     */
	public String guideregion_save(GuideRegionManageData data) {
		String insertSql = "";
		insertSql += "insert into p_guideregion(id,code,regionType,name,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getCode()) + ",";
		insertSql += Util.toSqlVal(data.getRegionType()) + ",";
		insertSql += Util.toSqlVal(data.getName()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		return insertSql;
	}
	
	/**
     * Description :更新引导区域信息．
     * @param  :GuideregionData
     * @return :String
     */
	public String guideregion_update(GuideRegionManageData data) {
		String insertSql = "";
		
		insertSql += "update p_guideregion set code=";
		insertSql += Util.toSqlVal(data.getCode()) + ",regionType=";
		insertSql += Util.toSqlVal(data.getRegionType()) + ",name=";
		insertSql += Util.toSqlVal(data.getName()) + ",notes=";
		insertSql += Util.toSqlVal(data.getNotes()) + " where id=";
		insertSql += Util.toSqlVal(data.getId());
		
		
		return insertSql;
	}
	
	/**
     * Description :保存引导区域与地图关联信息．
     * @param  :GuideregionData
     * @return :String
     */
	public String guideregion_map_save(GuideRegionManageData data) {
		String insertSql = "";
		
		insertSql += "insert into p_mapguideregion(id,mapId,guideRegionId) values(";
		insertSql += Util.toSqlVal(PrimaryId.getId()) + ",";
		insertSql += Util.toSqlVal(data.getMapId()) + ",";
		insertSql += Util.toSqlVal(data.getId()) + ")";
		
		
		return insertSql;
	}
	
	/**
     * Description :删除引导区域信息．
     * @param  :GuideregionData
     * @return :String
     */
	public String guideregion_delete(String id) {
		String deleteSql = "";
//		deleteSql += "update p_guideregion set deleteFlag='1' where id = " + Util.toSqlVal(id);
		deleteSql += "delete from p_guideregion where id = " + Util.toSqlVal(id);
		return deleteSql;
	}
	
	/**
     * Description :检查是否屏分区中引用要删除的引导区．
     * @param  :GuideregionData
     * @return :String
     */
	public String check_refrence_delete(String id) {
		String sql = "select count(gr.id) from p_guideregion gr,p_screenregion sr where gr.id=" + Util.toSqlVal(id) + 
				" and FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0";
		return sql;
	}
	
	/**
     * Description :检查是否屏分区中引用要更改编号的引导区．
     * @param  :GuideregionData
     * @return :String
     */
	public String check_refrence_update(GuideRegionManageData data) {
		String sql = "select count(gr.id) from p_guideregion gr,p_screenregion sr where gr.id=" + Util.toSqlVal(data.getId()) + 
				" and gr.code<>" + Util.toSqlVal(data.getCode()) + " and FIND_IN_SET(gr.code,sr.guideRegionCodeList)>0";
		return sql;
	}
	
	/**
     * Description :删除引导区域与地图关联信息．
     * @param  :GuideregionData
     * @return :String
     */
	public String guideregion_map_delete(String id) {
		String deleteSql = "";
		deleteSql += "delete from p_mapguideregion where guideRegionId = " + Util.toSqlVal(id);
		return deleteSql;
	}

	/**
     * Description :删除引导区域与车位关联信息．
     * @param  :logicregionData
     * @return :String
     */
	public String guideregion_detector_delete(String id) {
		String deleteSql = "";
		deleteSql += "update p_detector set guideRegionId=null where guideRegionId = " + Util.toSqlVal(id);
		return deleteSql;
	}

	/**
     * Description :获得地图列表．
     * @param  :
     * @return :String
     */
	public String get_mapCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_map order  by id";
		
		return querySql;
	}

	/**
	 * @param data
	 * @return
	 */
	public String guideregion_code_change(GuideRegionManageData data) {
		return "select id from p_guideregion where id=" + Util.toSqlVal(data.getId()) + " and regionType=" + Util.toSqlVal(data.getRegionType());
	}

	public String readExitsDao(GuideRegionManageData data, String type) {
		String querySql = "select count(*) from p_guideregion  where code = " + toSqlVal(data.getCode());
		if(type.equals("update")){
			querySql += " and id != " + toSqlVal(data.getId());
		}
		return querySql;
	}
	
	public String getMapList(){
		String querySql = "";
		querySql = "select id as code_id,name as code_name from p_map order by id";
		return querySql;
	}
}
