/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.guideregionmanage;

import java.util.List;

import com.ie.frame.ExtendData;

public class GuideRegionManageData extends ExtendData{
	private String mapId;				//地图ID
	private String mapName;				//地图名称 
	private String code;				//编号
	private String regionType;			//引导区类型
	private String regionTypeName;		//引导区类型名称
	private String name;				//名称
	private String notes;				//备注
	private List mapList;				//地图下拉框
	private List typeList;				//类型下拉框
	private int start_g;
	private int end_g;
	private boolean check;
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	/**
	 * @return the mapName
	 */
	public String getMapName() {
		return mapName;
	}
	/**
	 * @param mapName the mapName to set
	 */
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}
	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	/**
	 * @return the typeList
	 */
	public List getTypeList() {
		return typeList;
	}
	/**
	 * @param typeList the typeList to set
	 */
	public void setTypeList(List typeList) {
		this.typeList = typeList;
	}
	/**
	 * @return the regionType
	 */
	public String getRegionType() {
		return regionType;
	}
	/**
	 * @param regionType the regionType to set
	 */
	public void setRegionType(String regionType) {
		this.regionType = regionType;
	}
	/**
	 * @return the regionTypeName
	 */
	public String getRegionTypeName() {
		return regionTypeName;
	}
	/**
	 * @param regionTypeName the regionTypeName to set
	 */
	public void setRegionTypeName(String regionTypeName) {
		this.regionTypeName = regionTypeName;
	}
	
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}
	public int getStart_g() {
		return start_g;
	}
	public void setStart_g(int start_g) {
		this.start_g = start_g;
	}
	public int getEnd_g() {
		return end_g;
	}
	public void setEnd_g(int end_g) {
		this.end_g = end_g;
	}
}
