/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.guideregionmanage;

import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.inifile.IniFileCreator;

//命名空间
@Namespace("/guideregion_manage")
@Results({@Result(name="list",location="/guideregion_manage/guideregion_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="guideregion_list",location="list.action",type="redirect")})
public class GuideRegionManageAction extends ExtendActionSupport {
	
	private GuideRegionManageData data;
	@Autowired
	private GuideRegionManageService guideregionService;
	
	public GuideRegionManageData getData() {
		return data;
	}
	public void setData(GuideRegionManageData data) {
		this.data = data;
	}
	public GuideRegionManageAction(){
		if(data == null){
			data = new GuideRegionManageData();
		}
	}
	/**
     * Description :查询管理器．
     * @throws :Exception
     */
	@Action(value="guideregion_list",results={@Result(name="success",location="/guideregion_manage/guideregion_list.jsp")})
	public String guideregion_list(){
		//设置多语言
		data.setLang(request.getSession().getAttribute("lang").toString());
		setLang(data);
		data = guideregionService.guideregion_list(data);
		//默认
		data.setRegionType("1");
		//设置引导区类型列表
		data.setTypeList(guideregionService.getTypeList(data));
		data.setMapList(guideregionService.getMapList());
		return SUCCESS;
	}
	
	@Action(value="guideregion_save",results={@Result(type="json")})
	public void guideregion_save(){
		JSONObject json =  new JSONObject();
		try{
			if(guideregionService.readIsExits(data)){
				data = guideregionService.guideregion_save(data);
				json.element("success", true);
			}else{
				json.element("success", false);
			}
			
		} catch(Exception e){
			
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="guideregion_delete",results={@Result(type="json")})
	public void guideregion_delete(){		
		JSONObject json =  new JSONObject();
		try{
			guideregionService.guideregion_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
			json.element("ex", m.get("alert_guide_regional_already_used").toString());
		}
		setJsonRes(json);
	}
	
	@Action(value="check_refrence_delete",results={@Result(type="json")})
	public void check_refrence_delete(){		
		JSONObject json =  new JSONObject();
		try{
			boolean flag = guideregionService.check_refrence_delete(data);
			json.element("success", flag);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@Action(value="check_refrence_update",results={@Result(type="json")})
	public void check_refrence_update(){		
		JSONObject json =  new JSONObject();
		try{
			boolean flag = guideregionService.check_refrence_update(data);
			json.element("success", flag);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	/**
	 * @return the guideregionService
	 */
	public GuideRegionManageService getGuideregionService() {
		return guideregionService;
	}
	/**
	 * @param guideregionService the guideregionService to set
	 */
	public void setGuideregionService(GuideRegionManageService guideregionService) {
		this.guideregionService = guideregionService;
	}
}
