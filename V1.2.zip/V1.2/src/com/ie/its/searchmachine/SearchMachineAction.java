package com.ie.its.searchmachine;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;

@SuppressWarnings("serial")
@Namespace("/searchmachine_manage")
public class SearchMachineAction extends ExtendActionSupport{
	private SearchMachineData data;
	@Autowired
	private SearchMachineService searchmachineservice;
	
	private int type;				//日期类型
	private String date;			//日期
	private String searchType;		//查询类型
	private Object excelData;	//要导出excel的数据
	private String downFileName;
	protected InputStream inputStream;
	
	public SearchMachineData getData() {
		return data;
	}
	public void setData(SearchMachineData data) {
		this.data = data;
	}
	public SearchMachineAction(){
		if(data == null){
			data = new SearchMachineData();
		}
	}
	
	/**
	 * 返回查询机记录列表
	 * @return
	 */
	@Action(value="searchmachine_list",results={@Result(name="success",location="/searchmachine_manage/searchmachine_list.jsp")})
	public String searchMachineList(){
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		//获取记录列表
		data  = searchmachineservice.searchmachine_list(data);
		//获取地图下拉列表
		data.setMapList(searchmachineservice.get_mapCode());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return SUCCESS;
	}
	
	/**
	 * 查询机信息编辑
	 */
	@Action(value="searchmachine_edit",results={@Result(type="json")})
	public void searchmachine_edit(){
		JSONObject obj = new JSONObject();
		try{
			data = searchmachineservice.searchmachine_edit(data);
			obj.element("data", data);
			obj.element("success", true);
		}catch(Exception e){
			obj.element("success", false);
			obj.element("error", e);
		}
		setJsonRes(obj);
	}
	
	/**
	 *查询机信息编辑保存
	 */
	@Action(value="searchmachine_save", results={@Result(type="json")})
	public void searchmachine_save(){
		JSONObject jobj = searchmachineservice.searchmachine_save(data);
		setJsonRes(jobj);
	}
	/**
	 * 查询IP是否已使用
	 */
	@Action(value="searchmachine_check", results={@Result(type="json")})
	public void searchmachine_check(){
		JSONObject jobj = searchmachineservice.searchmachine_check(data);
		setJsonRes(jobj);
	}
	
	/**
	 * 进入查询机使用情况页面
	 * @return
	 */
	@Action(value="usemachine_times",results={@Result(name="success",location="/searchmachine_manage/usemachine_times.jsp")})
	public String searchmachine_times(){
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	/**
	 * 获取查询机ip，用以构造查询机下拉框
	 * @throws IOException 
	 * autor:0917
	 */
	@Action(value="searchmachine_ip",results={@Result(type="json")})
	public void searchmachine_ip() throws IOException{
		JSONObject obj = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)data.getLang_switch().get(lang)).get("common");
			obj = searchmachineservice.getMachineIp(map);
			obj.element("success", true);
		}catch(Exception e){
			obj.element("success", false);
		}

		setJsonRes(obj);
	}
	
	/**
	 * 查询查询机使用情况
	 */
	@Action(value="searchmachine_listTimes",results={@Result(type="json")})
	public void searchmachine_listTimes(){
		JSONObject obj = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)data.getLang_switch().get(lang)).get("common");
			obj = searchmachineservice.searchmachine_listTimes(map,searchType, type, date);
			obj.element("success", true);
		}catch(Exception e){
			obj.element("success", false);
		}

		setJsonRes(obj);
	}
	
	/**
	 * 导出查询机使用情况excel
	 */
	@Action(value="exportToExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportToExcel(){
		JSONObject obj = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)data.getLang_switch().get(lang)).get("common");
			obj = searchmachineservice.searchmachine_listTimes(map,searchType, type, date);
			File file = searchmachineservice.exportToExcel(obj, searchType);
			downFileName = file.getName();
		}catch(Exception e){
			
		}
		
		return SUCCESS;
	}
	
	/**
	 * 文件下载流
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 */
	public InputStream getInputStream() throws UnsupportedEncodingException, FileNotFoundException {
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = MachineData.WINEXCELPATH;
		} else {
			path = MachineData.LINUXEXCELPATH;
		}
		
		return new FileInputStream(path + "/" + downFileName);
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public void setExcelData(Object excelData) {
		this.excelData = excelData;
	}
	public Object getExcelData() {
		return excelData;
	}
	public String getDownFileName() {
		return downFileName;
	}
	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}
	
	
}
