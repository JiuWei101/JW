package com.ie.its.searchmachine;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class SearchMachineSql extends ExtendSql{
	/**
	 * 获取查询机记录列表
	 * @param data
	 * @param type
	 * @return
	 */
	public String searchmachine_list(SearchMachineData data,String type){
		String querySql = "";
		if(type.equals("count")){
			querySql +=" select count(*)";
		}else{
			querySql +=" select pp.ID as id,pp.mapId as mapId,pp.code as code,pp.name as name,pp.IP as ip,pp.note as note,pm.name as mapName";
		}
		querySql += " from p_pathnodeinfohead pp, p_map pm";
		querySql += " where pp.mapId = pm.id and pp.ifcarsearchpc = '1'";
		if(Util.isCon(data.getCode())){
			querySql +=" and pp.code like "+Util.toSqlValLike(data.getCode(),"ALL");
		}
		if(Util.isCon(data.getMapId())){
			querySql +=" and pm.id ="+Util.toSqlVal(data.getMapId());
		}
		if(Util.isCon(data.getId())){
			querySql +=" and pp.id !="+Util.toSqlVal(data.getId());
		}
		if(!type.equals("count")){
			querySql +=" order by pp.code";
		}
		Log.log(querySql);
		return querySql;
	}
	
	/**
	 * 获取查询机信息
	 * @param id
	 * @return
	 */
	public String get_onesearchmachine(SearchMachineData data){
		String querySql = " select pp.ID as id,pp.code as code,pp.name as name,pp.IP as ip,pp.note as note,pm.name as mapName from p_pathnodeinfohead pp, p_map pm";
		querySql += " where pp.mapId = pm.id and pp.ifcarsearchpc = '1'";
		if(Util.isCon(data.getMapId())){
			querySql += " and pp.mapId ="+Util.toSqlVal(data.getMapId());
		}
		if(Util.isCon(data.getName())){
			querySql += " and pp.name ="+Util.toSqlVal(data.getName());
		}
		if(Util.isCon(data.getId())){
			querySql += " and pp.ID ="+Util.toSqlVal(data.getId());
		}
		return querySql;
	}
	
	/**
	 * 保存查询机信息
	 * @param data
	 * @return
	 */
	public String searchmachine_save(SearchMachineData data){
		String querySql = " update p_pathnodeinfohead set IP ="+Util.toSqlVal(data.getIp())+", note ="+Util.toSqlVal(data.getNote())+" where id ="+Util.toSqlVal(data.getId());
		return querySql;
	}
	
	/**
	 * 查询IP是否已经使用
	 * @param data
	 * @return
	 */
	public String searchmachine_check(SearchMachineData data){
		String querySql = " select count(*) from p_pathnodeinfohead ppi where ppi.ifcarsearchpc = '1' and ppi.IP ="+Util.toSqlVal(data.getIp()) +" and ppi.id != "+Util.toSqlVal(data.getId());
		return querySql;
	}
	/**
     * Description :获取地图列表
     * @param  :
     * @return :String
     */
	public String get_mapCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_map order by id";
		
		return querySql;
	}
	
	//======查询机统计 START===================================================================================
	/**
	 * 
	 * @param searchType 
	 * @return
	 */
	public String getSearchMachineByDay(String searchType, String date) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		if("machine".equalsIgnoreCase(searchType)){
			sb.append("select machine as searchType, hour(useDateTime) as searchDate, count(machine) as timesCount" +
			" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y-%m-%d') =").append("'")
			.append(date).append("'").append(" group by hour(useDateTime), machine order by" +
			" machine, hour(useDateTime)");
		} else if("method".equalsIgnoreCase(searchType)){
			sb.append("select searchMethod as searchType, hour(useDateTime) as searchDate, count(searchMethod) as timesCount" +
					" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y-%m-%d') =").append("'")
					.append(date).append("'").append(" group by hour(useDateTime), searchMethod order by" +
					" searchMethod, hour(useDateTime)");
		}
		
		return sb.toString();
	}

	public String getSearchMachineByMonth(String searchType, String date) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		if("machine".equalsIgnoreCase(searchType)){
			sb.append("select machine as searchType, day(useDateTime) as searchDate, count(machine) as timesCount" +
			" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y-%m') =").append("'")
			.append(date).append("'").append(" group by day(useDateTime), machine order by" +
			" machine, day(useDateTime)");
		} else if("method".equalsIgnoreCase(searchType)){
			sb.append("select searchMethod as searchType, day(useDateTime) as searchDate, count(searchMethod) as timesCount" +
			" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y-%m') =").append("'")
			.append(date).append("'").append(" group by day(useDateTime), searchMethod order by" +
			" searchMethod, day(useDateTime)");
		}
		
		return sb.toString();
	}

	public String getSearchMachineByYear(String searchType, String date) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		if("machine".equalsIgnoreCase(searchType)){
			sb.append("select machine as searchType, month(useDateTime) as searchDate, count(machine) as timesCount" +
			" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y') =").append("'")
			.append(date).append("'").append(" group by month(useDateTime), machine order by" +
			" machine, month(useDateTime)");
		} else if("method".equalsIgnoreCase(searchType)){
			sb.append("select searchMethod as searchType, month(useDateTime) as searchDate, count(searchMethod) as timesCount" +
			" from p_searchmachine where DATE_FORMAT(useDateTime,'%Y') =").append("'")
			.append(date).append("'").append(" group by month(useDateTime), searchMethod order by" +
			" searchMethod, month(useDateTime)");
		}
		
		return sb.toString();
	}

	/**
	 * 查找地图上所有的查询机 IP
	 * @return
	 */
	public String getSearchMachineByMap() {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT pp.ip as searchType, CONCAT(pm.name, '-', pp.note, '-', ip) as searchMachine FROM p_map AS pm LEFT JOIN p_pathnodeinfohead AS pp ON pm.id = pp.mapId WHERE pp.ip != ''");
		
		return sb.toString();
	}

	
	//======END===================================================================================
}
