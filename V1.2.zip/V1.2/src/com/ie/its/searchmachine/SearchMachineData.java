package com.ie.its.searchmachine;

import java.util.List;

import com.ie.frame.ExtendData;

public class SearchMachineData extends ExtendData{
	private String id;
	private String mapId;
	private String mapName;
	private String code;
	private String name;
	private String ip;
	private String note;
	private List mapList;
	
	public List getMapList() {
		return mapList;
	}
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	@Override
	public String getId() {
		return id;
	}
	@Override
	public void setId(String id) {
		this.id = id;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getMapName() {
		return mapName;
	}
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
}
