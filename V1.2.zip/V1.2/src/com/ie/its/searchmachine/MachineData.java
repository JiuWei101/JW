package com.ie.its.searchmachine;

import java.io.Serializable;

/**
 * 查询机使用情况
 * @author Mo
 */
@SuppressWarnings("serial")
public class MachineData implements Serializable {

	public final static String LINE = "line";
	public final static String LABEL = "labelName";
	protected static final String WINEXCELPATH = "f:/excel";
	protected static final String LINUXEXCELPATH = "/usr/its/excel";
	private String searchType;			//查询方法或查询机
	private int searchDate;			//日期时间
	private String searchMachine;
	private int timesCount;			//数量
	private String note;				//备注 
	
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public int getSearchDate() {
		return searchDate;
	}
	public void setSearchDate(int searchDate) {
		this.searchDate = searchDate;
	}
	public int getTimesCount() {
		return timesCount;
	}
	public void setTimesCount(int timesCount) {
		this.timesCount = timesCount;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getSearchMachine() {
		return searchMachine;
	}
	public void setSearchMachine(String searchMachine) {
		this.searchMachine = searchMachine;
	}
	@Override
	public String toString() {
		return "MachineData [searchType=" + searchType + ", searchDate="
				+ searchDate + ", searchMachine=" + searchMachine
				+ ", timesCount=" + timesCount + ", note=" + note + "]";
	}
}
