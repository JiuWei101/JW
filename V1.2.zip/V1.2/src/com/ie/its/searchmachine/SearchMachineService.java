package com.ie.its.searchmachine;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.DateUtil;
import com.ie.common.FileUtil;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.inversionsearch.SerachMachineOperation;
import com.sun.org.apache.bcel.internal.generic.NEW;


@SuppressWarnings("rawtypes")
@Scope("prototype")
@Service
public class SearchMachineService extends ExtendService{
	private SearchMachineSql searchmachinesql;
	private final String[] SEARCHMETHOD = new String[]{"模糊查询", "车牌查询", "时间查询", "车位查询", "无牌车查询", "总数"}; 
	private final String[] DATEMETHOD = new String[]{"按天查询", "按月查询", "按年查询"};
	private final String DATESEARCH = "按日期查询方式";
	private final String DATEMETHODFORMAT = "时间\\方式";
	private final String EXCELFILE = ".xls";
	private final String MACHINEIP = "machineIp";
	private final String MACHINE = "machine";
	private final String LABEL = "label";
	private final String TICKS = "ticks";
	private final String METHOD = "method";
	
	public SearchMachineService(){
		searchmachinesql = new SearchMachineSql();
	}
	
	public SearchMachineData searchmachine_list(SearchMachineData data){
		//获得数量
		int count = this.getJt().queryForInt(searchmachinesql.searchmachine_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <SearchMachineData>rows = this.getJt().<SearchMachineData>queryForListExt(searchmachinesql.searchmachine_list(data, ""), 
				data.getStart(), data.getLimit(),SearchMachineData.class);
		
//		//转换编码
//		for(ScreenData tempData:rows){
//			tempData.setStatus((String) ((HashMap)data.getCurrent_lang_switch().get("ctrl_status")).get(tempData.getStatus()));
//			tempData.setEnable((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getEnable()));
//			tempData.setColorMode((String) ((HashMap)data.getCurrent_lang_switch().get("color_mode")).get(tempData.getColorMode()));
//			tempData.setIsExit((String) ((HashMap)data.getCurrent_lang_switch().get("enable")).get(tempData.getIsExit()));
//		}
		
		data.setPer_data(rows);
		return data;
	}
	
	public SearchMachineData searchmachine_edit(SearchMachineData data){
		data = this.getJt().queryForObjectExt(searchmachinesql.get_onesearchmachine(data), SearchMachineData.class);
		return data;
	}
	
	/**
	 * 保存查询机信息
	 * @param data
	 * @return
	 */
	public JSONObject searchmachine_save(SearchMachineData data){
		JSONObject jobj = new JSONObject();
		try{
			int r = this.getJt().update(searchmachinesql.searchmachine_save(data));
			if(r == 1){
				jobj.element("success", true);
				Log.log("----将新增的ip放入searchMachineStatus表中-----"+data.getIp());
				SerachMachineOperation.getSearchMachineStatus().put(data.getIp(), 1);
			}else{
				jobj.element("success", false);
			}
		}catch(Exception e){
			jobj.element("success", false);
		}
		return jobj;
	}
	
	/**
	 * 判断IP是否已使用
	 * @param data
	 * @return
	 */
	public JSONObject searchmachine_check(SearchMachineData data){
		JSONObject jobj = new JSONObject();
//		try{
//			int count = this.getJt().queryForInt(searchmachinesql.searchmachine_check(data));
//			if(count > 0){
//				jobj.element("success", false);
//			}else{
//				jobj.element("success", true);
//			}
//		}catch(Exception e){
//			e.printStackTrace();
//			jobj.element("success", false);
//		}
		ArrayList <SearchMachineData>rows = this.getJt().<SearchMachineData>queryForListExt(searchmachinesql.searchmachine_list(data, ""), SearchMachineData.class);
		ArrayList<String> iplist = new ArrayList<String>();
		for(SearchMachineData temp : rows){
			if(Util.isCon(temp.getIp())){
				String[] iparr = temp.getIp().split(",");
				for(String s : iparr){
					iplist.add(s);
				}
			}
		}
		if(iplist.size() > 0){
			boolean flag = true;
			String r = "";
			String[] iparr = data.getIp().split(",");
			for(String s : iparr){
				if(iplist.contains(s)){
					flag = false;
					r = r + s + " ";
				}
			}
			if(!flag){
				jobj.element("success", false);
				jobj.element("message", r);
			}else{
				jobj.element("success", true);
			}
		}else{
			jobj.element("success", true);
		}

		return jobj;
	}
	/**
     * Description :获得地图列表list
     * @param  :DetectorConfigData
     * @return :DetectorConfigData
     * @throws :Exception
     */
	public List get_mapCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(searchmachinesql.get_mapCode(), SearchMachineData.class);
		return codeList;
	}
	
	//===============================================================================================================
	/**
	 * 查询查询机使用情况
	 * @param searchType 分为按查询方式还是查询机
	 * @param type 1: 按天查询, 2: 按月查询 3: 按年查询
	 */
	@SuppressWarnings("unchecked")
	public JSONObject searchmachine_listTimes(Map map,String searchType, int type, String date) {
		// TODO Auto-generated method stub
		List<MachineData> list = new ArrayList<MachineData>();
		JSONObject jsonObject = new JSONObject();
		switch(type){
			case 1:					//按天查询(根据查询方式)
				if(null == date || date.isEmpty()){
					date = DateUtil.getCurDate();
				}
				list = getJt().queryForListExt(searchmachinesql.getSearchMachineByDay(searchType, date), MachineData.class);
				jsonObject = groupDataToJSONBySearchType(map,list, 24, searchType);
				jsonObject.element(DATESEARCH, DATEMETHOD[0]);
				break;
			case 2:					//按月查询(根据查询方式)
				if(null == date || date.isEmpty()){
					date = DateUtil.getCurYear() + "-" + DateUtil.getCurMonth();
				}
				
				list = getJt().queryForListExt(searchmachinesql.getSearchMachineByMonth(searchType, date), MachineData.class);
				int monthDay = getDayByYearMonth(date);
				jsonObject = groupDataToJSONBySearchType(map,list, monthDay, searchType);
				jsonObject.element(DATESEARCH, DATEMETHOD[1]);
				
				break;
			case 3:					//按年查询(根据查询方式)
				if(null == date || date.isEmpty()){
					date = DateUtil.getCurYear();
				}
				
				list = getJt().queryForListExt(searchmachinesql.getSearchMachineByYear(searchType, date), MachineData.class);
				jsonObject = groupDataToJSONBySearchType(map,list, 12, searchType);
				jsonObject.element(DATESEARCH, DATEMETHOD[2]);
				
				break;
		}
		
		return jsonObject;
	}

	/**
	 * 以月为单位查询
	 * @param type
	 * @param list
	 * @param date
	 * @return
	 */
	private int getDayByYearMonth(String date) {
		// TODO Auto-generated method stub
		int monthDay = 30, year = 0;  //默认每月有30天
		
		//--START 计算某年某月有几天--------------------------------------------------
		String[] dateSplit = date.split("-");
		if(dateSplit.length >= 2){
			Calendar cal = Calendar.getInstance();
			year = Integer.parseInt(dateSplit[0]);
			monthDay = Integer.parseInt(dateSplit[1]) - 1;
			cal.set(year, monthDay, 1);
			monthDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		}
		//--END 计算某年某月有几天--------------------------------------------------
		
		return monthDay;
	}

	/**
	 * 根据查询方式来组织数据
	 * @param list
	 * @param date
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONObject groupDataToJSONBySearchType(Map map,List<MachineData> list, int date, String searchType){
		JSONObject json = new JSONObject();
		JSONArray ticks = new JSONArray();				//X轴坐标值
		
		String totalLang = map.get("total").toString();
		String fuzzy_queryLang = map.get("fuzzy_query").toString();
		String car_queryLang = map.get("car_query").toString();
		String time_queryLang = map.get("time_query").toString();
		String pot_queryLang = map.get("pot_query").toString();
		String no_car_queryLang = map.get("no_car_query").toString();
		
		
		List<MachineData> removeMachine = new ArrayList<MachineData>();
		int[] allCount = new int[date];
		if(METHOD.equalsIgnoreCase(searchType)){		//5种查询方式计算 
			for(int j = 2; j <= 6; j++){
				JSONArray arrCount = new JSONArray();
				for(int i = 1; i <= date; i++){				
					int count = 0;
					for(MachineData machine : list){			//将对应时间的计数记录一下.
						if(machine.getSearchType().trim().equals("" + j) && machine.getSearchDate() == i){
							count = machine.getTimesCount();
							allCount[i - 1] += count;
							removeMachine.add(machine);				//减少循环的次数
						}
					}
					arrCount.add(count);
					list.removeAll(removeMachine);
					ticks.add(i + "");
				}
				json.put(MachineData.LINE + j, arrCount);
			}
			json.put(MachineData.LINE + 7, allCount);
			json.put(MachineData.LABEL, METHOD);
		} else if(MACHINE.equalsIgnoreCase(searchType)){
			JSONArray array = new JSONArray(), ipArr = new JSONArray();
			List<MachineData> machineIpList = getJt().queryForListExt(searchmachinesql.getSearchMachineByMap(), MachineData.class);
			for (MachineData machineData : machineIpList) {
				JSONArray arrCount = new JSONArray();
				for(int i = 1; i <= date; i++){			//按时/日/月	
					int count = 0;
					for(MachineData machine : list){			//将对应时间的计数记录一下.
						if(machine.getSearchType().trim().equals(machineData.getSearchType()) && machine.getSearchDate() == i){
							count = machine.getTimesCount();
							allCount[i - 1] += count;
							removeMachine.add(machine);				//减少循环的次数
						}
					}
					arrCount.add(count);
					list.removeAll(removeMachine);
					ticks.add(i + "");
				}
				array.add(arrCount);
				ipArr.add(new JSONObject().element(LABEL, machineData.getSearchMachine()));
			}
			//ipArr.get(0);
			array.add(allCount);
			ipArr.add(new JSONObject().element(LABEL, totalLang));
			
			json.put(MACHINEIP, ipArr);
			json.put(MACHINE, array);
			json.put(MachineData.LABEL, MACHINE);
		}
		json.put(TICKS, ticks);
		json.put("fuzzy_queryLang", fuzzy_queryLang);
		json.put("car_queryLang", car_queryLang);
		json.put("time_queryLang", time_queryLang);
		json.put("pot_queryLang", pot_queryLang);
		json.put("no_car_queryLang", no_car_queryLang);
		json.put("totalLang", totalLang);
		
		return json;
	}
	//===============================================================================================================

	/**
	 * 导出Excel
	 * @param searchType 查询方式
	 * @param obj 要导出的数据
	 */
	public File exportToExcel(JSONObject obj, String searchType) {
		// TODO Auto-generated method stub
		File file = null;
		try {
			file = createFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dateIndex = 0;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet(obj.getString(DATESEARCH), 0);
			if(METHOD.equalsIgnoreCase(searchType)){		//5种查询方式计算 
				for(int i = 0; i < 6; i++){
					Label methodText = new Label(i + 1, 0, SEARCHMETHOD[i]);
					sheet.addCell(methodText);
					
					JSONArray lineArr = (JSONArray) obj.get("line" + (i + 2));
					dateIndex = lineArr.size();
					for (int j = 0; j < lineArr.size(); j++) {
						// 以及单元格内容为test
						Label valueText = new Label(i + 1, j + 1, lineArr.getString(j));
						// 在Label对象的构造子中指名单元格位置是第一列第一行(0,0)
						// 将定义好的单元格添加到工作表中
						sheet.addCell(valueText);
					}
				}
				
				JSONArray array = (JSONArray)obj.get(TICKS);
				addTicksToCell(sheet, dateIndex, array);
			} else if(MACHINE.equalsIgnoreCase(searchType)){	//按查询机
				JSONArray ipArr = obj.getJSONArray(MACHINEIP);
				for(int i = 0; i < ipArr.size(); i++){
					JSONObject machineName = (JSONObject) ipArr.get(i);
					Label text = new Label(i + 1, 0, (String) machineName.get(LABEL));
					sheet.addCell(text);
					
					JSONArray machineArr = obj.getJSONArray(MACHINE);
					JSONArray arrCount = (JSONArray) machineArr.get(i);
					dateIndex = arrCount.size();
					for (int j = 0; j < arrCount.size(); j++) {
						// 以及单元格内容为test
						Label number = new Label(i + 1, j + 1, arrCount.getString(j));
						// 在Label对象的构造子中指名单元格位置是第一列第一行(0,0)
						// 将定义好的单元格添加到工作表中
						sheet.addCell(number);
					}
				}
				
				JSONArray array = (JSONArray)obj.get(TICKS);
				addTicksToCell(sheet, dateIndex, array);
			}

			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 将固定的第一列写到EXCEL对应的CELL
	 * @param sheet
	 * @param dateIndex
	 * @param array
	 * @throws RowsExceededException
	 * @throws WriteException
	 */
	private void addTicksToCell(WritableSheet sheet, int dateIndex,  JSONArray array) throws RowsExceededException, WriteException{
		for(int j = 0; j < dateIndex; j++){
			//在Label对象的构造子中指名单元格位置是第一列第一行(0,0)
			Label text = new Label(0, j + 1, (String) array.get(j));
			// 将定义好的单元格添加到工作表中
			sheet.addCell(text);
		}
		//在Label对象的构造子中指名单元格位置是第一列第一行(0,0)
		Label text = new Label(0, 0, DATEMETHODFORMAT);
		// 将定义好的单元格添加到工作表中
		sheet.addCell(text);
	}
	
	/**
	 * 创建文件
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	private File createFile() throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calender = Calendar.getInstance();
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = MachineData.WINEXCELPATH;
		} else {
			path = MachineData.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + sdf.format(calender.getTime()) + EXCELFILE);
		file.createNewFile();
		return file;
	}

	//===============================================================================================================
	
    //====start获取查询机ip等信息======================================================================================
	
	public JSONObject getMachineIp(Map map){
		JSONObject json=new JSONObject();
		JSONArray jArray=new JSONArray();
		String totalLang = map.get("total").toString();
		List<MachineData> machineIpList = getJt().queryForListExt(searchmachinesql.getSearchMachineByMap(), MachineData.class);
		for(MachineData mData:machineIpList){
			jArray.add(new JSONObject().element("label", mData.getSearchMachine()));
		}
		json.put("machineIp", jArray);
		json.put("totalLang", totalLang);
		return json;
	}
	
	//====end获取查询机ip等信息========================================================================================

}


























