package com.ie.its.parkingstatistics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.its.inversionsearch.ParkingData;
import com.ie.its.inversionsearch.UDWorkingRecordData;
import com.ie.jofc.BarChart;
import com.ie.jofc.BuilderChart;
import com.ie.jofc.LineChart;

//命名空间     parking_statistics
@Namespace("/parking_statistics")
@Results({@Result(name="list",location="inout_list.action",type="redirect")})
public class ParkingStatisticsAction extends ExtendActionSupport {
	
	private ParkingStatisticsData statisticsData;
	//自动注入service
	@Autowired
	private ParkingStatisticsService statisticsService;

	private String sDate; // 起始时间
	private String eDate; // 结束时间
	private String carNum; // 车牌号码
	private int pageIndex = 1; // 页码
	private int pageSize = 15; // 每页显示的条数
	private int start = 1;
	private int limit = 10;
	private int total; // 总的页数
	private Object excelData;	//要导出excel的数据
	private String downFileName;
	protected InputStream inputStream;
	private List<ParkingData> parkingData;
	
	private String detectorId; //探测器编号
	private String connect_type; //探测器连接状态类型
	private List<UDWorkingRecordData> udWorkingData;   //视频探测器运行记录列表，用于存放探测器运行信息
	private UDWorkingRecordData udWorkingRecord;    //视频探测器运行记录，用于初始化页面的下拉框
	
	public ParkingStatisticsAction(){
		if(statisticsData == null){
			statisticsData = new ParkingStatisticsData();
			udWorkingRecord = new UDWorkingRecordData();
		}
		
	}

	public ParkingStatisticsData getStatisticsData() {
		return statisticsData;
	}
	public void setStatisticsData(ParkingStatisticsData statisticsData) {
		this.statisticsData = statisticsData;
	}
	
	/**
     * 停车出入情况报表 初始化及查询
     * @param  :statisticsData
     * @throws :Exception
     */
	@Action(value="inout_list",results={@Result(name="day",location="/parking_statistics/day_inout_times.jsp"),
										@Result(name="year",location="/parking_statistics/year_inout_times.jsp")})
	public String inout_list() throws DataAccessException, InstantiationException, IllegalAccessException{
		String rt="";
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(false));
		//统计数据
		statisticsData = statisticsService.inout_list(statisticsData);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA,statisticsData.getPer_data());
		if(statisticsData.getS_type().equals("year")){
			rt="year";
		}else{
			rt="day";
		}
		return rt;
	}
	
	//===视频探测器运行情况start============================================================================================
	/**
	 * 查询视频探测器运行记录表
	 * @Description : TODO
	 * @return : success 用以调用jsp页面 
	 * @author : 0917
	 */
	@Action(value="ud_workingRecord",results={@Result(name="success",location="/parking_statistics/ud_working_record.jsp")})
	public String ud_working_recordAction() throws Exception{
		
		udWorkingRecord = this.statisticsService.udWorkingRecord_r(udWorkingRecord,sDate,eDate,detectorId,connect_type,udWorkingRecord.getStart(),udWorkingRecord.getLimit());
		udWorkingRecord.setLang(request.getSession().getAttribute("lang").toString());
		setLang(udWorkingRecord);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, udWorkingRecord.getPer_data());
		
		return SUCCESS;
	}
	
	//===Excel文件导出Start==============================================================================================	
	/**
	 * 导出视频探测器运行情况excel
	 */
	@Action(value="exportUDWorkingRecordExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportUDWorkingRecordExcel(){
		
		this.setLang(statisticsData);   //设置多语言
		Map<String, Object> common = (Map<String, Object>) statisticsData.getCurrent_lang_switch().get("common");
		try{
			total = this.statisticsService.getUDWorkingTotalPage(sDate,eDate,detectorId,connect_type, 1);  //获取分页总数
			udWorkingData = this.statisticsService.udWorkingRecord(sDate,eDate,detectorId,connect_type,1, total); //获取所有记录，从第一条到最后一条
			File file = statisticsService.udExportToExcel(udWorkingData, common);   //将记录全部保存到file中
			downFileName = file.getName();
		}catch(Exception e){
			
		}
		
		return SUCCESS;
	}
	//===Excel文件导出End==============================================================================================
	
	//===视频探测器运行情况end============================================================================================
	
	/**
     * 停车占有率情况报表 初始化及查询
     * @param  :statisticsData
     * @throws :Exception
     */
	@Action(value="used_list",results={@Result(name="day",location="/parking_statistics/day_inout_times.jsp"),
									   @Result(name="year",location="/parking_statistics/year_inout_times.jsp")})
	public String used_list() throws DataAccessException, InstantiationException, IllegalAccessException{
		String rt="";
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(false));
		//统计数据
		statisticsData = statisticsService.used_list(statisticsData);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA,statisticsData.getPer_data());
		if(statisticsData.getS_type().equals("year")){
			rt="year";
		}else{
			rt="day";
		}
		return rt;
	}

	/**
     * 查询逻辑区域车位使用率．
     * @param  :statisticsData
     * @throws :Exception
     */
	@Action(value="logical_used_list",results={@Result(name="day",location="/parking_statistics/logical_day_use.jsp"),
									   @Result(name="month",location="/parking_statistics/logical_month_use.jsp"),
									   @Result(name="year",location="/parking_statistics/logical_year_use.jsp")})
	public String logical_used_list() throws DataAccessException, InstantiationException, IllegalAccessException{
		String rt="";
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList());
		//统计数据
		statisticsData = statisticsService.logical_used_list(statisticsData);
		JSONArray arr = new JSONArray();
		try {
			arr = statisticsService.logic_use_chart(statisticsData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.request.setAttribute(ConstantClass.RQ_PER_DATA,statisticsData.getPer_data());
		if(statisticsData.getS_type().equals("year")){//这个模块只做了按月查询和按日查询，但留了按年查询的接口和前台页面，如有需要可以参照前台和后台方法添加
			rt="year";
		}else if(statisticsData.getS_type().equals("month")){
			rt="month";
		}else{
			rt="day";
		}
		return rt;
	}
	
	/**
     * Description :导出excel．
     * @param  :
	 * @throws SQLException 
	 * @throws IOException 
     * @throws :Exception
     */
	@Action(value="export_excel",results={@Result(name="success",location="/parking_statistics/excel_out.jsp")})
	public String export_excel() throws DataAccessException, InstantiationException, IllegalAccessException, SQLException, IOException{
		//设置多语言
		this.setLang(statisticsData);
		statisticsService.excel(statisticsData);
		request.setCharacterEncoding("UTF-8");
		request.setAttribute("file_name",statisticsData.getFile_name());
		System.out.println(statisticsData.getFile_name());
		return SUCCESS;
	}


	/**
     * Description :打印．
     * @param  :
     * @throws :Exception
     */
	@Action(value="export_print",results={@Result(name="success",location="/parking_statistics/statPrintPreview.jsp")})
	public String export_print() throws DataAccessException, InstantiationException, IllegalAccessException{
		//设置多语言
		this.setLang(statisticsData);
		return SUCCESS;
	}
	
	/**
     * Description :停车出入图表初始化
     * @param  :statisticsData
     * @throws :Exception
     */            
	@SuppressWarnings("unchecked")
	@Action(value="park_chart_init",results={@Result(name="success",location="/parking_statistics/park_chart.jsp")})
	public String park_chart_init() throws DataAccessException, InstantiationException, IllegalAccessException{
		
		request.setAttribute("park_type", statisticsService.getParkType());
		request.setAttribute("logic_region", statisticsService.getLogicRegion());
		request.setAttribute("year_array", DateUtil.getYearJsonArray());
		request.setAttribute("month_array", DateUtil.getMonthJsonArray());
		@SuppressWarnings("unused")
		Map setLangExt = this.setLangExt(statisticsData);
		request.setAttribute("lang", JSONObject.fromObject(setLangExt));
		//设置多语言
		this.setLang(statisticsData);
		//
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
		//List li = new ArrayList();
		//statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		statisticsData.setS_type("day");
		if(DateUtil.getMonth(new Date())<10)
			statisticsData.setS_month("0"+DateUtil.getMonth(new Date()));
		else
			statisticsData.setS_month(""+DateUtil.getMonth(new Date()));
		statisticsData.setS_date(DateUtil.getCurDate());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		statisticsData.setChart_type("histogram"); //graph histogram
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());
		//统计数据
		//this.request.setAttribute(ConstantClass.RQ_PER_DATA,statisticsData.getPer_data());
		return SUCCESS;
	}
	
	/**
     * Description :停车占有率图表初始化
     * @param  :statisticsData
     * @throws :Exception
     */
	@SuppressWarnings("unchecked")
	@Action(value="park_use_init",results={@Result(name="success",location="/parking_statistics/park_use.jsp")})
	public String park_use_init() throws DataAccessException, InstantiationException, IllegalAccessException{
		request.setAttribute("park_type", statisticsService.getParkType());
		request.setAttribute("logic_region", statisticsService.getLogicRegion());
		request.setAttribute("year_array", DateUtil.getYearJsonArray());
		request.setAttribute("month_array", DateUtil.getMonthJsonArray());
		@SuppressWarnings("unused")
		Map setLangExt = this.setLangExt(statisticsData);
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
//		List li = new ArrayList();
//		statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		if(DateUtil.getMonth(new Date())<10)
			statisticsData.setS_month("0"+DateUtil.getMonth(new Date()));
		else
			statisticsData.setS_month(""+DateUtil.getMonth(new Date()));
		statisticsData.setS_type("day");
		statisticsData.setS_date(DateUtil.getCurDate());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		statisticsData.setChart_type("graph"); //graph histogram
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());
		//统计数据
		//request.setAttribute("lang", JSONObject.fromObject(setLangExt));
		return SUCCESS;
	}
	
	/**
	 * 逻辑区域占有率图表初始化
	 * @return
	 * @throws DataAccessException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	@Action(value="logic_use_chart_init",results={@Result(name="success",location="/parking_statistics/logic_use_chart.jsp")})
	public String logic_use_chart_init()throws DataAccessException, InstantiationException, IllegalAccessException{
		request.setAttribute("park_type", statisticsService.getParkType());
		request.setAttribute("logic_region", statisticsService.getLogicRegion());
		request.setAttribute("year_array", DateUtil.getYearJsonArray());
		request.setAttribute("month_array", DateUtil.getMonthJsonArray());
		@SuppressWarnings("unused")
		Map setLangExt = this.setLangExt(statisticsData);
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setPhysicalList(statisticsService.getPhysicalRegionCode());
		//逻辑区域
		statisticsData.setLogicIdList(statisticsService.getLogicRegionCode());
//		List li = new ArrayList();
//		statisticsData.setLogicIdList(li);
		//年
		statisticsData.setYearList(DateUtil.getYearJsonArray());
		//月
		statisticsData.setMonthList(DateUtil.getMonthJsonArray());
		if(DateUtil.getMonth(new Date())<10)
			statisticsData.setS_month("0"+DateUtil.getMonth(new Date()));
		else
			statisticsData.setS_month(""+DateUtil.getMonth(new Date()));
		statisticsData.setS_type("day");
		statisticsData.setS_date(DateUtil.getCurDate());
		//车位类型
		statisticsData.setSpotTypeList((List) statisticsService.getParkType());
		//查询类别
		statisticsData.setSTypeList((List) statisticsService.getSTypeList(true));
		statisticsData.setChart_type("graph"); //graph histogram
		//柱形 折线
		statisticsData.setTypeList((List) statisticsService.getTypeList());
		//统计数据
		//request.setAttribute("lang", JSONObject.fromObject(setLangExt));
		return SUCCESS;
	}
	
	/**
	 * 停车出入明细
	 */
	@Action(value="parking_in_detail",results={@Result(name="success",location="/parking_statistics/parking_in_detail.jsp")})
	public String parking_in_detail(){
		//设置多语言
		this.setLang(statisticsData);
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		parkingData = this.statisticsService.carNumDateSearch(carNum, sDate,
				eDate, pageIndex, pageSize);
		total = this.statisticsService.getTotalPage(carNum, sDate, eDate,
				pageSize);
		
		return SUCCESS;
	}
	
	//===Excel文件导出Start==============================================================================================	
	/**
	 * 导出查询机使用情况excel
	 */
	@Action(value="exportParkingDetailExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportParkingDetailExcel(){
		//设置多语言
		this.setLang(statisticsData);
		Map<String, Object> common = (Map<String, Object>) statisticsData.getCurrent_lang_switch().get("common");
		try{
			total = this.statisticsService.getTotalPage(carNum, sDate, eDate, 1);
			parkingData = this.statisticsService.carNumDateSearch(carNum, sDate, eDate, 1, total);
			File file = statisticsService.exportToExcel(parkingData, common);
			downFileName = file.getName();
		}catch(Exception e){
			
		}
		
		return SUCCESS;
	}
	
	/**
	 * 文件下载流
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 */
	public InputStream getInputStream() throws UnsupportedEncodingException, FileNotFoundException {
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = ExpExcel.WINEXCELPATH;
		} else {
			path = ExpExcel.LINUXEXCELPATH;
		}
		
		return new FileInputStream(path + "/" + downFileName);
	}
	//===Excel文件导出End==============================================================================================
	
	/**
     * Description :逻辑区域占有率图表查询
     * @param  :statisticsData
     * @throws :Exception
     */
	@Action(value="logic_use_chart",results={@Result(type="json")})
	public void logic_use_chart() throws Exception{

		JSONArray logic_use_chart = statisticsService.logic_use_chart(statisticsData);
		JSONObject jo = new JSONObject();
		
		jo.element("arr", logic_use_chart);
		BuilderChart bc = new BuilderChart();
		if(statisticsData.getChart_type().equals("line")){
			LineChart line = new LineChart();
			jo = bc.getBuilder(jo, line);
		}else if(statisticsData.getChart_type().equals("bar")){
			BarChart bar = new BarChart();
			jo = bc.getBuilder(jo, bar);
		}
		//System.out.println(jo.toString());
		setJsonRes(jo);
	}
	
	
	/**
     * Description :停车占有率图表查询
     * 改由com.ie.its.monitor.ChartData 的 use_list方法实现
     * @param  :statisticsData
     * @throws :Exception
     */
	@Action(value="use_list",results={@Result(type="json")})
	public void use_list() throws Exception{

		JSONArray use_list = statisticsService.use_list(statisticsData);
		JSONObject jo = new JSONObject();
		
		jo.element("arr", use_list);
		BuilderChart bc = new BuilderChart();
		if(statisticsData.getChart_type().equals("line")){
			LineChart line = new LineChart();
			jo = bc.getBuilder(jo, line, true, null);
		}else if(statisticsData.getChart_type().equals("bar")){
			BarChart bar = new BarChart();
			jo = bc.getBuilder(jo, bar, true, null);
		}
		//System.out.println(jo.toString());
		setJsonRes(jo);
	}
	
	/**
     * Description :停车出入情况图表查询
     * 改由com.ie.its.monitor.ChartData 的 chart_list 方法实现
     * @param  :statisticsData
	 * @throws Exception 
     */
	@Action(value="chart_list",results={@Result(type="json")})
	public void chart_list() throws Exception{

		JSONArray chart_list = statisticsService.chart_list(statisticsData);
		
		JSONObject jo = new JSONObject();
		jo.element("arr", chart_list);
		BuilderChart bc = new BuilderChart();
		String in_park = "",out_park = "";
		String lang = request.getSession().getAttribute("lang").toString();
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("chart_title");
		in_park = map.get("in_park").toString();
		out_park = map.get("out_park").toString();
		if(statisticsData.getChart_type().equals("line")){
			jo = bc.getBuilder(jo, new LineChart(), in_park, out_park);
		}else if(statisticsData.getChart_type().equals("bar")){
			jo = bc.getBuilder(jo, new BarChart(), in_park, out_park);
		}
		setLang(statisticsData);
		setJsonRes(jo);
	}
	
	/**
	 * 物理区域级联逻辑区域
	 * @throws Exception
	 */
	@Action(value="nextLogic",results={@Result(type="json")})
	public void nextLogic() throws Exception{

		String parameter = request.getParameter("phyId");
		List nextLogicList = statisticsService.nextLogicList(parameter);
		JSONObject jo = new JSONObject();
		jo.element("success", true);
		jo.element("list", nextLogicList);
		setJsonRes(jo);
	}

	public ParkingStatisticsService getStatisticsService() {
		return statisticsService;
	}

	public void setStatisticsService(ParkingStatisticsService statisticsService) {
		this.statisticsService = statisticsService;
	}

	public String getSDate() {
		return sDate;
	}

	public void setSDate(String sDate) {
		this.sDate = sDate;
	}

	public String getEDate() {
		return eDate;
	}

	public void setEDate(String eDate) {
		this.eDate = eDate;
	}

	public String getCarNum() {
		return carNum;
	}

	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public List<ParkingData> getParkingData() {
		return parkingData;
	}

	public void setParkingData(List<ParkingData> parkingData) {
		this.parkingData = parkingData;
	}

	public String getDownFileName() {
		return downFileName;
	}

	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}

	public void setUdWorkingData(List<UDWorkingRecordData> udWorkingData) {
		this.udWorkingData = udWorkingData;
	}

	public List<UDWorkingRecordData> getUdWorkingData() {
		return udWorkingData;
	}

	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}

	public String getDetectorId() {
		return detectorId;
	}

	public void setConnect_type(String connect_type) {
		this.connect_type = connect_type;
	}

	public String getConnect_type() {
		return connect_type;
	}

	public void setUdWorkingRecord(UDWorkingRecordData udWorkingRecord) {
		this.udWorkingRecord = udWorkingRecord;
	}

	public UDWorkingRecordData getUdWorkingRecord() {
		return udWorkingRecord;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getStart() {
		return start;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getLimit() {
		return limit;
	}

}
