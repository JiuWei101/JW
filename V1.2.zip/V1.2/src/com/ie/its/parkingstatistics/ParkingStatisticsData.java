package com.ie.its.parkingstatistics;

import java.util.List;

import com.ie.frame.ExtendData;

public class ParkingStatisticsData extends ExtendData{
	
	private String id;				//车位流水记录id
	private String parkingSpaceId;	//车位id
	/*private String spotType;		//车位类型
	private String inuse;			//是否有车
	private String inTime;			//入车时间
	private String outTime;			//出车时间
	private String detectorId;		//探测器id
	private String guideRegionId;	//地图引导区id
	private String logicId;			//地图逻辑区id
	private String lightRegionId;	//灯光区域id
	private String code;			//车位编号
	private String enable;			//是否启用
	private String useDate;			//被占用时间？？
	private String updateDate;		//最后更新时间
	private String notes;			//备注
*/	
	private String recordType;      //视频探测器记录类型
	private String detectorId;      //探测器编号
	private String detectorMacAddr;         //探测器物理地址
	private String runTime;	        //运行状态时间
	private String detectorDesc;    //探测器描述
	private List connTypeList;    //查询连接类型下拉框
	
	private String inTime;			//入车时间
	private String outTime;			//出车时间
	private String flex_type;
	private String list_type;		//占有率  还是出入车数
	private String chart_type;
	private List typeList;
	private String s_type;			//查询类型 年月日
	private String s_year;			//查询年
	private String s_month;			//查询月
	private String s_b_date;		//查询开始日期
	private String s_e_date;		//查询结束日期
	private String s_date;
	private String s_logic_id;		//查询逻辑区域
	private String s_physical_id;	//查询物理区域
	
	private String s_spot_type;		//查询车位类型
	private String file_name;		//导出excel 数据名
	
	private List yearList;			//查询下拉框  年
	private List monthList;			//查询下拉框  月
	private List dayList;			//查询下拉框  日
	private List logicIdList;		//查询下拉框  逻辑区
	private List physicalList;		//查询下拉框  物理区
	private List spotTypeList;		//查询下拉框  车位类型
	private List sTypeList;			//查询类别

	private String p_month;			//月份
	private String p_day;			//日期
	private String p_hour;			//小时
	@Override
	public String toString() {
		return "ParkingStatisticsData [id=" + id + ", parkingSpaceId="
				+ parkingSpaceId + ", recordType=" + recordType
				+ ", detectorId=" + detectorId + ", detectorMacAddr="
				+ detectorMacAddr + ", runTime=" + runTime + ", detectorDesc="
				+ detectorDesc + ", inTime=" + inTime + ", outTime=" + outTime
				+ ", flex_type=" + flex_type + ", list_type=" + list_type
				+ ", chart_type=" + chart_type + ", typeList=" + typeList
				+ ", s_type=" + s_type + ", s_year=" + s_year + ", s_month="
				+ s_month + ", s_b_date=" + s_b_date + ", s_e_date=" + s_e_date
				+ ", s_date=" + s_date + ", s_logic_id=" + s_logic_id
				+ ", s_physical_id=" + s_physical_id + ", s_spot_type="
				+ s_spot_type + ", file_name=" + file_name + ", yearList="
				+ yearList + ", monthList=" + monthList + ", dayList="
				+ dayList + ", logicIdList=" + logicIdList + ", physicalList="
				+ physicalList + ", spotTypeList=" + spotTypeList
				+ ", sTypeList=" + sTypeList + ", p_month=" + p_month
				+ ", p_day=" + p_day + ", p_hour=" + p_hour + ", in_times="
				+ in_times + ", out_times=" + out_times + ", p_time=" + p_time
				+ ", p_days=" + p_days + ", all_times=" + all_times
				+ ", p_in_hour_time=" + p_in_hour_time + ", hh_type=" + hh_type
				+ ", p_out_hour=" + p_out_hour + ", p_out_minute="
				+ p_out_minute + ", col0=" + col0 + ", col1=" + col1
				+ ", col2=" + col2 + ", col3=" + col3 + ", col4=" + col4
				+ ", col5=" + col5 + ", col6=" + col6 + ", col7=" + col7
				+ ", col8=" + col8 + ", col9=" + col9 + ", col10=" + col10
				+ ", col11=" + col11 + ", col12=" + col12 + ", col13=" + col13
				+ ", col14=" + col14 + ", col15=" + col15 + ", col16=" + col16
				+ ", col17=" + col17 + ", col18=" + col18 + ", col19=" + col19
				+ ", col20=" + col20 + ", col21=" + col21 + ", col22=" + col22
				+ ", col23=" + col23 + ", col24=" + col24 + ", col25=" + col25
				+ ", col26=" + col26 + ", col27=" + col27 + ", col28=" + col28
				+ ", col29=" + col29 + ", col30=" + col30 + ", col31=" + col31
				+ "]";
	}

	private String in_times;		//入车数
	private String out_times;		//出车数
	private String p_time;			//停车时长
	private String p_days;			//停车天数
	private String all_times;		//出入车总数
	private String p_in_hour_time;	//当日入车的分钟数 例如2012-03-04 12:54:32  存分钟：54
	private String hh_type;			//当日出车跟入车是否是同一个小时段内 1是 0 不是
	private String p_out_hour;	//出车时间里的小时
	private String p_out_minute;			//出车时间里的分钟
	
	private String col0;			//统计的列数据
	private String col1;			//统计的列数据
	private String col2;			//统计的列数据
	private String col3;			//统计的列数据
	private String col4;			//统计的列数据
	private String col5;			//统计的列数据
	private String col6;			//统计的列数据
	private String col7;			//统计的列数据
	private String col8;			//统计的列数据
	private String col9;			//统计的列数据
	private String col10;			//统计的列数据
	private String col11;			//统计的列数据
	private String col12;			//统计的列数据
	private String col13;			//统计的列数据
	private String col14;			//统计的列数据
	private String col15;			//统计的列数据
	private String col16;			//统计的列数据
	private String col17;			//统计的列数据
	private String col18;			//统计的列数据
	private String col19;			//统计的列数据
	private String col20;			//统计的列数据
	private String col21;			//统计的列数据
	private String col22;			//统计的列数据
	private String col23;			//统计的列数据
	private String col24;			//统计的列数据
	private String col25;			//统计的列数据
	private String col26;			//统计的列数据
	private String col27;			//统计的列数据
	private String col28;			//统计的列数据
	private String col29;			//统计的列数据
	private String col30;			//统计的列数据
	private String col31;			//统计的列数据


	
	
	public ParkingStatisticsData() {
		super();
	}

	public ParkingStatisticsData(String s_logic_id,String s_physical_id,String s_spot_type,String s_month,String s_year,
			String s_type,String s_date,String chart_type) {
		super();
		this.s_physical_id = s_physical_id;
		this.s_type = s_type;
		this.s_year = s_year;
		this.s_month = s_month;
		this.s_b_date = s_date;
		this.s_e_date = s_date;
		this.s_date = s_date;
		this.chart_type = chart_type;
		this.s_logic_id = s_logic_id;
		this.s_spot_type = s_spot_type;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public String getS_b_date() {
		return s_b_date;
	}

	public void setS_b_date(String s_b_date) {
		this.s_b_date = s_b_date;
	}

	public String getS_e_date() {
		return s_e_date;
	}

	public void setS_e_date(String s_e_date) {
		this.s_e_date = s_e_date;
	}

	public String getParkingSpaceId() {
		return parkingSpaceId;
	}

	public void setParkingSpaceId(String parkingSpaceId) {
		this.parkingSpaceId = parkingSpaceId;
	}

	public String getS_logic_id() {
		return s_logic_id;
	}

	public void setS_logic_id(String s_logic_id) {
		this.s_logic_id = s_logic_id;
	}

	public String getS_spot_type() {
		return s_spot_type;
	}

	public void setS_spot_type(String s_spot_type) {
		this.s_spot_type = s_spot_type;
	}


	public String getP_day() {
		return p_day;
	}

	public void setP_day(String p_day) {
		this.p_day = p_day;
	}

	public String getP_hour() {
		return p_hour;
	}

	public void setP_hour(String p_hour) {
		this.p_hour = p_hour;
	}

	public String getOut_times() {
		return out_times;
	}

	public void setOut_times(String out_times) {
		this.out_times = out_times;
	}

	public String getS_type() {
		return s_type;
	}

	public void setS_type(String s_type) {
		this.s_type = s_type;
	}

	public String getCol0() {
		return col0;
	}

	public void setCol0(String col0) {
		this.col0 = col0;
	}

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public String getCol3() {
		return col3;
	}

	public void setCol3(String col3) {
		this.col3 = col3;
	}

	public String getCol4() {
		return col4;
	}

	public void setCol4(String col4) {
		this.col4 = col4;
	}

	public String getCol5() {
		return col5;
	}

	public void setCol5(String col5) {
		this.col5 = col5;
	}

	public String getCol6() {
		return col6;
	}

	public void setCol6(String col6) {
		this.col6 = col6;
	}

	public String getCol7() {
		return col7;
	}

	public void setCol7(String col7) {
		this.col7 = col7;
	}

	public String getCol8() {
		return col8;
	}

	public void setCol8(String col8) {
		this.col8 = col8;
	}

	public String getCol9() {
		return col9;
	}

	public void setCol9(String col9) {
		this.col9 = col9;
	}

	public String getCol10() {
		return col10;
	}

	public void setCol10(String col10) {
		this.col10 = col10;
	}

	public String getCol11() {
		return col11;
	}

	public void setCol11(String col11) {
		this.col11 = col11;
	}

	public String getCol12() {
		return col12;
	}

	public void setCol12(String col12) {
		this.col12 = col12;
	}

	public String getCol13() {
		return col13;
	}

	public void setCol13(String col13) {
		this.col13 = col13;
	}

	public String getCol14() {
		return col14;
	}

	public void setCol14(String col14) {
		this.col14 = col14;
	}

	public String getCol15() {
		return col15;
	}

	public void setCol15(String col15) {
		this.col15 = col15;
	}

	public String getCol16() {
		return col16;
	}

	public void setCol16(String col16) {
		this.col16 = col16;
	}

	public String getCol17() {
		return col17;
	}

	public void setCol17(String col17) {
		this.col17 = col17;
	}

	public String getCol18() {
		return col18;
	}

	public void setCol18(String col18) {
		this.col18 = col18;
	}

	public String getCol19() {
		return col19;
	}

	public void setCol19(String col19) {
		this.col19 = col19;
	}

	public String getCol20() {
		return col20;
	}

	public void setCol20(String col20) {
		this.col20 = col20;
	}

	public String getCol21() {
		return col21;
	}

	public void setCol21(String col21) {
		this.col21 = col21;
	}

	public String getCol22() {
		return col22;
	}

	public void setCol22(String col22) {
		this.col22 = col22;
	}

	public String getCol23() {
		return col23;
	}

	public void setCol23(String col23) {
		this.col23 = col23;
	}

	public String getCol24() {
		return col24;
	}

	public void setCol24(String col24) {
		this.col24 = col24;
	}

	public String getCol25() {
		return col25;
	}

	public void setCol25(String col25) {
		this.col25 = col25;
	}

	public String getCol26() {
		return col26;
	}

	public void setCol26(String col26) {
		this.col26 = col26;
	}

	public String getCol27() {
		return col27;
	}

	public void setCol27(String col27) {
		this.col27 = col27;
	}

	public String getCol28() {
		return col28;
	}

	public void setCol28(String col28) {
		this.col28 = col28;
	}

	public String getCol29() {
		return col29;
	}

	public void setCol29(String col29) {
		this.col29 = col29;
	}

	public String getCol30() {
		return col30;
	}

	public void setCol30(String col30) {
		this.col30 = col30;
	}

	public String getCol31() {
		return col31;
	}

	public void setCol31(String col31) {
		this.col31 = col31;
	}

	public String getIn_times() {
		return in_times;
	}

	public void setIn_times(String in_times) {
		this.in_times = in_times;
	}

	public List getYearList() {
		return yearList;
	}

	public void setYearList(List yearList) {
		this.yearList = yearList;
	}

	public List getMonthList() {
		return monthList;
	}

	public void setMonthList(List monthList) {
		this.monthList = monthList;
	}

	public List getLogicIdList() {
		return logicIdList;
	}

	public void setLogicIdList(List logicIdList) {
		this.logicIdList = logicIdList;
	}

	public List getSTypeList() {
		return sTypeList;
	}

	public void setSTypeList(List typeList) {
		sTypeList = typeList;
	}

	public List getSpotTypeList() {
		return spotTypeList;
	}

	public void setSpotTypeList(List spotTypeList) {
		this.spotTypeList = spotTypeList;
	}

	public String getS_year() {
		return s_year;
	}

	public void setS_year(String s_year) {
		this.s_year = s_year;
	}

	public String getS_month() {
		return s_month;
	}

	public void setS_month(String s_month) {
		this.s_month = s_month;
	}

	public String getP_month() {
		return p_month;
	}

	public void setP_month(String p_month) {
		this.p_month = p_month;
	}

	public String getP_time() {
		return p_time;
	}

	public void setP_time(String p_time) {
		this.p_time = p_time;
	}

	public String getP_days() {
		return p_days;
	}

	public void setP_days(String p_days) {
		this.p_days = p_days;
	}

	public String getAll_times() {
		return all_times;
	}

	public void setAll_times(String all_times) {
		this.all_times = all_times;
	}

	public String getS_date() {
		return s_date;
	}

	public void setS_date(String s_date) {
		this.s_date = s_date;
	}

	public String getP_in_hour_time() {
		return p_in_hour_time;
	}

	public void setP_in_hour_time(String p_in_hour_time) {
		this.p_in_hour_time = p_in_hour_time;
	}

	public String getHh_type() {
		return hh_type;
	}

	public void setHh_type(String hh_type) {
		this.hh_type = hh_type;
	}

	public List getDayList() {
		return dayList;
	}

	public void setDayList(List dayList) {
		this.dayList = dayList;
	}

	public String getList_type() {
		return list_type;
	}

	public void setList_type(String list_type) {
		this.list_type = list_type;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	
	
	

	public List getTypeList() {
		return typeList;
	}

	public void setTypeList(List typeList) {
		this.typeList = typeList;
	}

	public String getChart_type() {
		return chart_type;
	}

	public void setChart_type(String chart_type) {
		this.chart_type = chart_type;
	}

	public String getFlex_type() {
		return flex_type;
	}

	public void setFlex_type(String flex_type) {
		this.flex_type = flex_type;
	}

	public List getPhysicalList() {
		return physicalList;
	}

	public void setPhysicalList(List physicalList) {
		this.physicalList = physicalList;
	}

	public String getS_physical_id() {
		return s_physical_id;
	}

	public void setS_physical_id(String s_physical_id) {
		this.s_physical_id = s_physical_id;
	}

	public String getP_out_hour() {
		return p_out_hour;
	}

	public void setP_out_hour(String p_out_hour) {
		this.p_out_hour = p_out_hour;
	}

	public String getP_out_minute() {
		return p_out_minute;
	}

	public void setP_out_minute(String p_out_minute) {
		this.p_out_minute = p_out_minute;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getRecordType() {
		return recordType;
	}
	
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}

	public String getDetectorId() {
		return detectorId;
	}

	public void setDetectorMacAddr(String detectorMacAddr) {
		this.detectorMacAddr = detectorMacAddr;
	}

	public String getDetectorMacAddr() {
		return detectorMacAddr;
	}

	public void setRunTime(String runTime) {
		this.runTime = runTime;
	}

	public String getRunTime() {
		return runTime;
	}

	public void setDetectorDesc(String detectorDesc) {
		this.detectorDesc = detectorDesc;
	}

	public String getDetectorDesc() {
		return detectorDesc;
	}

	public void setConnTypeList(List connTypeList) {
		this.connTypeList = connTypeList;
	}

	public List getConnTypeList() {
		return connTypeList;
	}
}
