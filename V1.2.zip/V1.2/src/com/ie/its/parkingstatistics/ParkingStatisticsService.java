package com.ie.its.parkingstatistics;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.DateUtil;
import com.ie.common.FileUtil;
import com.ie.common.Log;
import com.ie.common.OperateBeanInfo;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.inversionsearch.ParkingData;
import com.ie.its.inversionsearch.UDWorkingRecordData;
import com.ie.its.udworkingstatistics.UDWorkingStatisticsData;

@Scope("prototype")
@Service
public class ParkingStatisticsService extends ExtendService<ParkingStatisticsData> {
	private ParkingStatisticsSql statistisSql;
	
	public ParkingStatisticsService(){
		statistisSql = new ParkingStatisticsSql();
	}

	
	/**
     * Description :查询出入车总数．之所以用到 s_b_date、s_e_date 之前是为了支持按时间段搜索 ，现在不用了 
     * @param  :statisticsData
     * @return :statisticsData
     * @throws :SQLException
     */
	public ParkingStatisticsData inout_list(Object o) {
		ParkingStatisticsData statisticsData = (ParkingStatisticsData)o;
		String s_type=statisticsData.getS_type();//页面查询的类别  年月日 year month day
		String s_table_type=statisticsData.getS_type();//比页面查询的类别多一个非当日(后面处理)，year month today other_day
		String s_b_date=statisticsData.getS_b_date();//查询开始日期
		String s_e_date=statisticsData.getS_e_date();//查询结束日期
		String s_year=statisticsData.getS_year(); //查询年
		String s_month=statisticsData.getS_month();//查询月
		
		if(!Util.isCon(s_type)){//初始化下 如果是空 则默认为当天
			/*20120316 去掉日统计 改为默认当月
				s_type="day";
				s_b_date=Util.nowDate();
				s_e_date=Util.nowDate();
				statisticsData.setS_type(s_type);
				statisticsData.setS_b_date(s_b_date);
				statisticsData.setS_e_date(s_e_date);
			*/
			s_type="month";
			s_table_type="month";
			s_year=DateUtil.getCurYear();
			s_month=DateUtil.getCurMonth();
			s_b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			s_e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			statisticsData.setS_year(s_year);
			statisticsData.setS_month(s_month);
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_e_date);
			statisticsData.setS_type(s_type);
		}
		if(s_type.equals("day")){//如果是日 把初始时间设为和结束时间设置为开始时间
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_b_date);
			s_e_date=statisticsData.getS_e_date();
			if(statisticsData.getS_b_date().equals(Util.nowDate())){
				s_table_type="today";
			}else{
				s_table_type="other_day";
			}
		}
		if(s_type.equals("month")){//如果是月 把初始时间设为当月第一天 结束时间设置为月末
			s_b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			s_e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_e_date);
		}

		Log.log(statisticsData.getS_type());
		ArrayList <ParkingStatisticsData>statisticsList= new ArrayList();//整理完的数据放在这里 需要返回到页面
		ParkingStatisticsData sumInData =new ParkingStatisticsData();//存储入车总数数据的dto
		ParkingStatisticsData sumOutData =new ParkingStatisticsData();//存储出车总数数据的dto
		//整理数据_
		if(s_table_type.equals("today")){ //当天
			//返回进出车结果集 跟页面样式数据格式不一致 需要整理
			ArrayList <ParkingStatisticsData>in_rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.today_list(statisticsData, "in"),ParkingStatisticsData.class);
			ArrayList <ParkingStatisticsData>out_rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.today_list(statisticsData, "out"),ParkingStatisticsData.class);
			
			int days=0;//查询日期的天数
			days=Integer.parseInt(DateUtil.getTwoDay(s_e_date,s_b_date))+1;
			for(int i=1;i<=days;i++){//循环这些天
				ParkingStatisticsData dayInData =new ParkingStatisticsData();//存储每一天按小时入车数据的dto
				ParkingStatisticsData dayOutData =new ParkingStatisticsData();//存储每一天按小时出车数据的dto
				dayInData.setP_day(s_b_date);
				dayOutData.setP_day(s_b_date);
				sumInData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
				sumOutData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
				for(ParkingStatisticsData sdata:in_rows){//入车部分
					String p_day=sdata.getP_day();
					String p_hour=sdata.getP_hour();
					String in_times=sdata.getIn_times();
					if(p_day.equals(s_b_date)){
						OperateBeanInfo.setPropertyValue(dayInData,"col"+Integer.parseInt(p_hour),in_times);//set bean
					}
				}
				
				int day_in_all=0;//一天入车总数
				for(int p=0;p<24;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayInData,"col"+p))){//给空的col赋值0
						OperateBeanInfo.setPropertyValue(dayInData,"col"+p,"0");//默认0
					}else{
						day_in_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(dayInData,"col"+p).toString());
					}
				}
				dayInData.setAll_times(day_in_all+"");//一天入车总数

				for(ParkingStatisticsData sdata:out_rows){//出车部分
					String p_day=sdata.getP_day();
					String p_hour=sdata.getP_hour();
					String out_times=sdata.getOut_times();
					if(p_day.equals(s_b_date)){
						OperateBeanInfo.setPropertyValue(dayOutData,"col"+Integer.parseInt(p_hour),out_times);//set bean
					}
				}
				
				int day_out_all=0;//一天出车总数
				for(int p=0;p<24;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayOutData,"col"+p))){//给空的col赋值0
						OperateBeanInfo.setPropertyValue(dayOutData,"col"+p,"0");//默认0
					}else{
						day_out_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(dayOutData,"col"+p).toString());
					}
				}
				dayOutData.setAll_times(day_out_all+"");//一天出车总数
				s_b_date=DateUtil.getNextDay(s_b_date, "1");//循环下一日期
				statisticsList.add(dayInData);
				statisticsList.add(dayOutData);
			}
		}
		if(s_table_type.equals("month")){//非当天和 按月查询
			ParkingStatisticsData todayData=new ParkingStatisticsData();
			s_b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			if(DateUtil.getCurDate().substring(0, 7).equals(s_b_date.substring(0, 7))){//按月统计是否含有当天
					statisticsData.setS_type("day");//为了在月统计中包含当天数据
					statisticsData.setS_b_date(DateUtil.getCurDate());
					todayData=inout_list(statisticsData);//查当天的进出车数据
				}
			statisticsData.setS_type("month");//
			statisticsData.setS_b_date(s_b_date);
			
			//返回进出车结果集 跟页面样式数据格式不一致 需要整理
			ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.inout_list(statisticsData, ""),ParkingStatisticsData.class);
			int days=0;//查询日期的天数
			days=Integer.parseInt(DateUtil.getTwoDay(s_e_date,s_b_date))+1;
			for(int i=1;i<=days;i++){//循环这些天
				ParkingStatisticsData dayInData =new ParkingStatisticsData();//存储每一天按小时入车数据的dto
				ParkingStatisticsData dayOutData =new ParkingStatisticsData();//存储每一天按小时出车数据的dto
				if(i==Integer.parseInt(DateUtil.getCurDay())&&DateUtil.getCurDate().substring(0, 7).equals(s_b_date.substring(0, 7))){//如果是当日
					Log.log(i+"-----------iiiiiiiiiiiiii-------------");
					dayInData=(ParkingStatisticsData) ((ArrayList)todayData.getPer_data()).get(0);
					dayOutData=(ParkingStatisticsData) ((ArrayList)todayData.getPer_data()).get(1);
					s_b_date=DateUtil.getNextDay(s_b_date, "1");//循环下一日期
				}else{//非当日
					dayInData.setP_day(s_b_date);
					dayOutData.setP_day(s_b_date);
					sumInData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
					sumOutData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
					for(ParkingStatisticsData sdata:rows){//入车部分
						String p_day=sdata.getP_day();
						String p_hour=sdata.getP_hour();
						String in_times=sdata.getIn_times();
						String out_times=sdata.getOut_times();
						if(p_day.equals(s_b_date)){
							//Log.log(s_b_date+":--"+Integer.parseInt(p_hour)+"---------in_times------------"+in_times);
							//Log.log(s_b_date+":"+Integer.parseInt(p_hour)+"---------out_times------------"+out_times);
							OperateBeanInfo.setPropertyValue(dayInData,"col"+Integer.parseInt(p_hour),in_times);//set bean
							OperateBeanInfo.setPropertyValue(dayOutData,"col"+Integer.parseInt(p_hour),out_times);//set bean
						}
					}
					
					int day_in_all=0;//一天入车总数
					int day_out_all=0;//一天出车总数
					for(int p=0;p<24;p++){
						if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayInData,"col"+p))){//给空的col赋值0
							OperateBeanInfo.setPropertyValue(dayInData,"col"+p,"0");//默认0
						}else{
							day_in_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(dayInData,"col"+p).toString());
						}
						if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayOutData,"col"+p))){//给空的col赋值0
							OperateBeanInfo.setPropertyValue(dayOutData,"col"+p,"0");//默认0
						}else{
							day_out_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(dayOutData,"col"+p).toString());
						}
					}
					dayInData.setAll_times(day_in_all+"");//一天入车总数
					dayOutData.setAll_times(day_out_all+"");//一天出车总数
					
					s_b_date=DateUtil.getNextDay(s_b_date, "1");//循环下一日期
				}
				statisticsList.add(dayInData);
				statisticsList.add(dayOutData);
			}
			//算这些天的总数
			int[] inArr=new int[24];
			int[] outArr=new int[24];
			int in_all=0;
			int out_all=0;
			for(int i=0;i<statisticsList.size();i++){
				ParkingStatisticsData sdata=statisticsList.get(i);
				//~~算24小时中每个小时的总数
				for(int p=0;p<24;p++){
					if(i%2==0){//入车
						inArr[p]+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"col"+p).toString());
					}else{//出车的
						outArr[p]+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"col"+p).toString());
					}
				}
				//~~算所有时间总的
				if(i%2==0){//入车
					in_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
				}else{//出车的
					out_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
				}
			}
			for(int p=0;p<24;p++){
				OperateBeanInfo.setPropertyValue(sumInData,"col"+p,inArr[p]+"");//所有天的按小时入车总数
				OperateBeanInfo.setPropertyValue(sumOutData,"col"+p,outArr[p]+"");//所有天的按小时出车总数
			}
			sumInData.setAll_times(in_all+"");
			sumOutData.setAll_times(out_all+"");
			if(s_table_type.equals("month")){//如果是查月，加上最后一行 总数
				statisticsList.add(sumInData);
				statisticsList.add(sumOutData);
			}
		}
		if(s_table_type.equals("year")){//统计年的
			//返回进出车结果集 跟页面样式数据格式不一致 需要整理
			ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.inout_list(statisticsData, ""),ParkingStatisticsData.class);
			//String s_year=statisticsData.getS_year();
			sumInData.setP_month(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
			sumOutData.setP_month(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());//多语言 总数
			int months=12;//查询的月数
			for(int i=1;i<=months;i++){//循环这些月
				ParkingStatisticsData monthInData =new ParkingStatisticsData();//存储每一月按天入车数据的dto
				ParkingStatisticsData monthOutData =new ParkingStatisticsData();//存储每一月按天出车数据的dto
				String month=i<10?("0"+i):(i+"");
				monthInData.setP_month(i+"");
				monthOutData.setP_month(i+"");
				Log.log("月份-----------"+i);
				for(ParkingStatisticsData sdata:rows){//入车部分
					String p_month=sdata.getP_month();
					String in_times=sdata.getIn_times();
					String out_times=sdata.getOut_times();
					String day=sdata.getP_day().substring(sdata.getP_day().lastIndexOf("-")+1);//日  格式：1、2、3... ...31
					if(p_month.equals(s_year+"-"+month)){
						OperateBeanInfo.setPropertyValue(monthInData,"col"+Integer.parseInt(day),in_times);//set bean
						OperateBeanInfo.setPropertyValue(monthOutData,"col"+Integer.parseInt(day),out_times);//set bean
					}
				}

				String b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), i);
				String e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), i);
				int days=Integer.parseInt(DateUtil.getTwoDay(e_date,b_date))+1;
				
				int month_in_all=0;//一天入车总数
				for(int p=1;p<=days;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(monthInData,"col"+p))){
						OperateBeanInfo.setPropertyValue(monthInData,"col"+p,"0");////给空的col赋值0
					}else{
						month_in_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(monthInData,"col"+p).toString());
					}
				}
				for(int p=days+1;p<=31;p++){
					OperateBeanInfo.setPropertyValue(monthInData,"col"+p,"-");//-
				}
				monthInData.setAll_times(month_in_all+"");

				int month_out_all=0;//按月出车总数
				for(int p=1;p<=days;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(monthOutData,"col"+p))){
						OperateBeanInfo.setPropertyValue(monthOutData,"col"+p,"0");////给空的col赋值0
					}else{
						month_out_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(monthOutData,"col"+p).toString());
					}
				}
				for(int p=days+1;p<=31;p++){
					OperateBeanInfo.setPropertyValue(monthOutData,"col"+p,"-");//默认-
				}
				monthOutData.setAll_times(month_out_all+"");
				
				statisticsList.add(monthInData);
				statisticsList.add(monthOutData);
			}
			//往下的是算总数
			int[] inArr=new int[31];
			int[] outArr=new int[31];
			int in_all=0;
			int out_all=0;
			for(int i=0;i<statisticsList.size();i++){
				ParkingStatisticsData sdata=statisticsList.get(i);
				//~~算一个月中每天的总数
				for(int p=0;p<31;p++){
					String month_all="";
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)))){
						month_all+="0";
					}else{
						if(OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)).equals("-")){
							month_all+="0";
						}else{
							month_all+=OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)).toString();
						}
					}
					if(i%2==0){//入车
						inArr[p]+=Integer.parseInt(month_all);
					}else{//出车的
						outArr[p]+=Integer.parseInt(month_all);
					}
				}
				//~~算所有时间总的
				if(i%2==0){//入车
					in_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
				}else{//出车的
					out_all+=Integer.parseInt(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
				}
			}
			for(int p=0;p<31;p++){
				//Log.log("inArr["+p+"]="+inArr[p]);
				//Log.log("outArr["+p+"]="+outArr[p]);
				OperateBeanInfo.setPropertyValue(sumInData,"col"+(p+1),inArr[p]+"");//所有月的按天入车总数
				OperateBeanInfo.setPropertyValue(sumOutData,"col"+(p+1),outArr[p]+"");//所有月的按天出车总数
			}
			sumInData.setAll_times(in_all+"");
			sumOutData.setAll_times(out_all+"");
			statisticsList.add(sumInData);
			statisticsList.add(sumOutData);
		}
		
		statisticsData.setPer_data(statisticsList);
		return statisticsData;
	}

	/**
	 * 当天各小时停车时间
	 * @param data
	 * @param currDate
	 * @return
	 */
	private double[] today_usehours(ParkingStatisticsData data,String currDate){
		double[] usedArr = new double[24];
		List<ParkingStatisticsData> rows = this.getJt().queryForListExt(statistisSql.today_useddata(data, currDate), ParkingStatisticsData.class);
		for(ParkingStatisticsData sdata : rows){
			int p_in_hour = Integer.parseInt(sdata.getP_hour());//入车时间小时
			int p_in_minutes = Integer.parseInt(sdata.getP_in_hour_time());//入车时间分钟
			int p_out_hour = Integer.parseInt(sdata.getP_out_hour());//出车时间小时
			int p_out_minutes = Integer.parseInt(sdata.getP_out_minute());//出车时间分钟
			if(p_in_hour == p_out_hour){
				usedArr[p_in_hour] += (p_out_minutes - p_in_minutes);
			}else{
				usedArr[p_in_hour] += (60 - p_in_minutes);
				for(int i=p_in_hour + 1; i<p_out_hour; i++){
					usedArr[i] += 60;
				}
				usedArr[p_out_hour] += p_out_minutes;
			}
		}
		return usedArr;
	}
	
	private double today_usedall(double[] usedArr){
		double sum = 0;
		for(int i=0; i<usedArr.length; i++){
			sum += usedArr[i];
		}
		return sum;
	}
	
	private JSONArray today_usedchart(ParkingStatisticsData data,String currDate, int all_park_num){
		JSONArray jarr = new JSONArray();
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数 
		double all_time = all_park_num * 60;//所有车位一个小时
		double[] usedArr = today_usehours(data,currDate);
		if(all_park_num == 0){
			for(int i=0; i<24; i++){
				JSONObject jobj = new JSONObject();
				jobj.element("name", i);
				jobj.element("use_number", 0d);
				jarr.element(jobj);
			}
		}else{
			for(int i=0; i<24; i++){
				JSONObject jobj = new JSONObject();
				jobj.element("name", i);
				double used_percent = (usedArr[i] / all_time) * 100;
				jobj.element("use_number", df2.format(used_percent));
				jarr.element(jobj);
			}
		}
		return jarr;
	}
	/**
	 * 当天停车占有率数据
	 * @param data
	 * @return
	 */
	private ParkingStatisticsData today_useddata(ParkingStatisticsData data,String currDate, int all_park_num){
		ParkingStatisticsData rdata = new ParkingStatisticsData();//日使用率最终数据
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数   
		rdata.setP_day(currDate);//当前日期，页面展示
		double all_time = all_park_num * 60;//所有车位一个小时
		double[] usedArr = today_usehours(data,currDate);
		//一天之内的总停车时间；
		double day_all_time=0;
		for(int i=0; i<24; i++){
			if(all_park_num == 0){
				OperateBeanInfo.setPropertyValue(rdata,"col"+i,"0.00");//默认0
			}else{
				double used_percent = (usedArr[i] / all_time) * 100;
				OperateBeanInfo.setPropertyValue(rdata,"col"+i,df2.format(used_percent));//set bean
				day_all_time += usedArr[i];
			}
		}
		if(all_park_num == 0){
			rdata.setAll_times(df2.format(0.00));
		}else{
			double day_used_percent = ( day_all_time/(all_time * 24) )*100;
			rdata.setAll_times(df2.format(day_used_percent));	
		}

		return rdata;
	}
	
	/**
	 * 月停车占有率数据
	 * @param data
	 * @param all_park_num
	 * @return
	 */
	private ArrayList<ParkingStatisticsData> month_useddata(ParkingStatisticsData data,String currDate, int all_park_num){
		ArrayList<ParkingStatisticsData> statisticsList = new ArrayList<ParkingStatisticsData>();
		ParkingStatisticsData averageData= new ParkingStatisticsData();//平均使用率的数据放在这里 需要放到statisticsList
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数   
		String s_b_date = data.getS_b_date();//月开始日期
		String s_e_date = data.getS_e_date();//月结束日期
		int all_time = all_park_num*60;//all_park_num*60 所有车位*60分钟
		int days = Integer.parseInt(DateUtil.getTwoDay(s_e_date, s_b_date)) + 1;//两个日期之间的天数
		averageData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("average").toString());//平均
		
		ArrayList<ParkingStatisticsData> rows = this.getJt().queryForListExt(statistisSql.month_useddata(data), ParkingStatisticsData.class);
		for(int i=1; i<=days; i++){
			ParkingStatisticsData dayUsedData =new ParkingStatisticsData();//存储每一天按小时停车时长数据的dto
			if(Util.isCon(currDate) && i==Integer.parseInt(currDate.substring(8, 10)) && currDate.substring(0, 7).equals(s_b_date.substring(0, 7))){//如果是当日
				dayUsedData = today_useddata(data, currDate, all_park_num);
			}else{
				dayUsedData.setP_day(s_b_date);
				for(ParkingStatisticsData sdata:rows){
					String p_day=sdata.getP_day();
					String p_hour=sdata.getP_hour();
					String p_time=sdata.getP_time();//停车时长 分钟
					if(p_day.equals(s_b_date)){
						//计算每小时使用率
						double used_percent = (Double.parseDouble(p_time)/all_time)*100;
						OperateBeanInfo.setPropertyValue(dayUsedData,"col"+Integer.parseInt(p_hour),df2.format(used_percent));//set bean  
					}
				}
				double averageUsed=0.00;//平均使用率
				for(int p=0;p<24;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayUsedData,"col"+p))){//给空的col赋值0
						OperateBeanInfo.setPropertyValue(dayUsedData,"col"+p,"0.00");//默认0
					}else{
						averageUsed+=Double.parseDouble(OperateBeanInfo.getPropertyValue(dayUsedData,"col"+p).toString());
					}
				}
				dayUsedData.setAll_times(df2.format(averageUsed/24));//平均使用率
			}
			s_b_date=DateUtil.getNextDay(s_b_date, "1");//循环下一日期
			statisticsList.add(dayUsedData);
		}
		//算这些天的平均
		double[] avgArr=new double[24];
		double average_all=0;
		for(int i=0;i<statisticsList.size();i++){
			ParkingStatisticsData sdata=statisticsList.get(i);
			//~~算24小时中每个小时的平均数
			for(int p=0;p<24;p++){
				//System.out.println(i+"----"+p+"---"+OperateBeanInfo.getPropertyValue(sdata,"col"+p));
				avgArr[p]+=Double.parseDouble(OperateBeanInfo.getPropertyValue(sdata,"col"+p).equals("-")?"0":OperateBeanInfo.getPropertyValue(sdata,"col"+p).toString());
			}
			//~~算所有时间总的
			double hh=0;
			if(!Util.isCon(OperateBeanInfo.getPropertyValue(sdata,"all_times"))){
				hh=0;
			}else{
				if(OperateBeanInfo.getPropertyValue(sdata,"all_times").equals("-")){
					hh=0;
				}else{
					hh=Double.parseDouble(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
				}
			}
			average_all+=hh;
			
		}
		for(int p=0;p<24;p++){
			String avg_h=df2.format(avgArr[p]/days);
			OperateBeanInfo.setPropertyValue(averageData,"col"+p,avg_h);//所有天的按小时平均使用率
		}
		averageData.setAll_times(df2.format(average_all/days));//表格最右下角的数据
	    statisticsList.add(averageData);
		return statisticsList;
	}
	
	private ArrayList<ParkingStatisticsData> year_useddata(ParkingStatisticsData data, String currDate, int all_park_num){
		ArrayList<ParkingStatisticsData> statisticsList = new ArrayList<ParkingStatisticsData>();
		ParkingStatisticsData averageData= new ParkingStatisticsData();//平均使用率的数据放在这里 需要放到statisticsList
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数 
		ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.year_useddata(data, currDate),ParkingStatisticsData.class);
		String s_year = data.getS_year();//查询年
		int months = 12;//查询的月数
		int all_time = all_park_num*60*24;//all_space_num*60 所有车位*60分钟*24小时
		averageData.setP_month(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("average").toString());//平均
		for(int i=1;i<=months;i++){//循环这些月
			ParkingStatisticsData monthUsedData =new ParkingStatisticsData();//存储每一月按天利用率数据的dto
			String month=i<10?("0"+i):(i+"");
			monthUsedData.setP_month(i+"");
			for(ParkingStatisticsData sdata:rows){//存储每一月按天停车时长数据的dto
				String p_month=sdata.getP_month();
				String p_day=sdata.getP_day().substring(sdata.getP_day().lastIndexOf("-")+1);
				String p_time=sdata.getP_time();//停车时长 分钟
				if(p_month.equals(s_year+"-"+month)){
					if(all_park_num==0){//车位总数是0
						OperateBeanInfo.setPropertyValue(monthUsedData,"col"+Integer.parseInt(p_day),"-");//set bean  车位总数是0
					}else{
						//计算使用率
						double used_percent=0.00;
						used_percent=(Double.parseDouble(p_time)/all_time)*100>100?100:(Double.parseDouble(p_time)/all_time)*100;
						OperateBeanInfo.setPropertyValue(monthUsedData,"col"+Integer.parseInt(p_day),df2.format(used_percent));//set bean
					}
				}
			}
			// 一下是处理空数据
			String b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), i);
			String e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), i);
			int days=Integer.parseInt(DateUtil.getTwoDay(e_date,b_date))+1;
			//给空的col赋值0
			double day_avg=0.00;//每一天的平均使用率
			for(int p=1;p<=days;p++){
				if(!Util.isCon(OperateBeanInfo.getPropertyValue(monthUsedData,"col"+p))){
					OperateBeanInfo.setPropertyValue(monthUsedData,"col"+p,"0.00");//默认0
				}else{
					day_avg+=Double.parseDouble(OperateBeanInfo.getPropertyValue(monthUsedData,"col"+p).toString());
				}
			}
			for(int p=days+1;p<=31;p++){
				OperateBeanInfo.setPropertyValue(monthUsedData,"col"+p,"-");//-
			}
			monthUsedData.setAll_times(df2.format(day_avg/days));
			statisticsList.add(monthUsedData);
		}
		
		//往下的是算平均数
		double[] avgArr=new double[31];
		double avg_all=0.00;
		for(int i=0;i<statisticsList.size();i++){
			ParkingStatisticsData sdata=statisticsList.get(i);
			//~~算一个月中每天的总数
			for(int p=0;p<31;p++){
				String month_all="";
				if(!Util.isCon(OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)))){
					month_all+="0";
				}else{
					if(OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)).equals("-")){
						month_all+="0";
					}else{
						month_all+=OperateBeanInfo.getPropertyValue(sdata,"col"+(p+1)).toString();
					}
				}
				avgArr[p]+=Double.parseDouble(month_all);
			}
			//~~算所有时间总的
			avg_all+=Double.parseDouble(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
		}
		for(int p=0;p<31;p++){
			OperateBeanInfo.setPropertyValue(averageData,"col"+(p+1),df2.format(avgArr[p]/12)+"");//所有月的按天入车总数
		}
		averageData.setAll_times(df2.format(avg_all/12));
		statisticsList.add(averageData);
		return statisticsList;
	}
	
	private String get_realcurrDate(){
		ParkingStatisticsData data = this.getJt().queryForObjectExt(statistisSql.get_realday_fromlog(), ParkingStatisticsData.class);
		String hisOutDate = this.getJt().queryForObject(statistisSql.get_date_fromhis(), String.class);
		String logInDate = data.getInTime();
		String logOutDate = data.getOutTime();
		if(Util.isCon(logOutDate)){//log表中有出车未迁移记录，则取此日期数据、包含此日期的月数据、包含此日期的年数据都需要查询p_parkingspaceoperationlog表
			return logOutDate;
		}else if(Util.isCon(hisOutDate)){//log表中没有出车未迁移记录 his表出车日期不为空
			return DateUtil.getNextDay(hisOutDate, "1");//his出车日期后移一天
		}else if(Util.isCon(logInDate)){//入车时间日期不为空
			return logInDate;
		}else{
			return DateUtil.getCurDate();
		}
		
	}
	/**
     * Description 使用率．
     * @param  :statisticsData
     * @return :statisticsData
     * @throws :SQLException
     */
	public ParkingStatisticsData used_list(Object o) {
		ParkingStatisticsData statisticsData = (ParkingStatisticsData)o;
		//获得总车位数量
		int all_space_num = this.getJt().queryForInt(statistisSql.getAllSpaceNum(statisticsData));
		//获取Log表的真实当前时间
		String real_currDate = get_realcurrDate();
		
		String s_type=statisticsData.getS_type();			//页面查询的类别 year month day
		String s_table_type=statisticsData.getS_type();		//比页面查询的类别多一个非当日(后面处理)，year month today other_day
		String s_year=statisticsData.getS_year();			//年
		String s_month=statisticsData.getS_month();			//月
		String s_b_date=statisticsData.getS_b_date();		//起始日期
		String s_e_date=statisticsData.getS_e_date();		//结束日期
		if(!Util.isCon(s_type)){//初始化下 如果是空 则默认为当月
			s_type="month";
			s_table_type="month";
			s_year=DateUtil.getCurYear();
			s_month=DateUtil.getCurMonth();
			statisticsData.setS_year(s_year);
			statisticsData.setS_month(s_month);
			statisticsData.setS_type(s_type);
		}

		if(s_type.equals("day")){//如果是日 把初始时间设为和结束时间设置为开始时间
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_b_date);
			s_e_date=statisticsData.getS_e_date();
			if(statisticsData.getS_b_date().equals(real_currDate)){
				s_table_type="today";
			}else{
				s_table_type="other_day";
			}
		}
		if(s_type.equals("month")){//如果是月 把初始时间设为当月第一天 结束时间设置为月末
			s_b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			s_e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_e_date);
		}
		
		ArrayList <ParkingStatisticsData>statisticsList= new ArrayList<ParkingStatisticsData>();//整理完的数据放在这里 需要返回到页面
		System.out.println("查询参数---"+
				"[Type]: "+statisticsData.getS_type()+
				" [Year]: "+statisticsData.getS_year()+
				" [Month]: "+statisticsData.getS_month()+
				" [B_Date]: "+statisticsData.getS_b_date()+
				" [E_Date]: "+statisticsData.getS_e_date());
		//整理数据_
		if(s_table_type.equals("today")){//按当日查使用率
			//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
			statisticsData.setS_b_date("");
			statisticsData.setS_e_date(s_b_date);
			
			ParkingStatisticsData dayUsedData = today_useddata(statisticsData, real_currDate, all_space_num);
			statisticsList.add(dayUsedData);
		}
		if(s_table_type.equals("other_day")||s_table_type.equals("month")){//非当日或月查使用率//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
			
			statisticsList = month_useddata(statisticsData,real_currDate, all_space_num);
			
		}

		if(s_table_type.equals("year")){//按年查使用率//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
			
			statisticsList = year_useddata(statisticsData,real_currDate, all_space_num);
			
		}
		
		statisticsData.setPer_data(statisticsList);
		return statisticsData;
	}
	
	/**
     * Description 逻辑区域使用率．
     * @author LLX 20120912
     * @param  :statisticsData
     * @return :statisticsData
     * @throws :SQLException
     */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ParkingStatisticsData logical_used_list(Object o) {
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数   
		ParkingStatisticsData statisticsData = (ParkingStatisticsData)o;
		
		List<Map<String, Object>> codeList = new ArrayList<Map<String, Object>>();//取所有逻辑区域List
		codeList = this.getJt().queryForList(statistisSql.getLogicRegionCode());
		String s_type=statisticsData.getS_type();//页面查询的类别 year month day
		String s_table_type=statisticsData.getS_type();//比页面查询的类别多一个非当日(后面处理)，year month today other_day
		String s_year=statisticsData.getS_year();	//查询的年
		String s_month=statisticsData.getS_month(); //查询的月
		String s_date = statisticsData.getS_date();	//查询的日期
		String s_b_date="";		//查询的开始日期
		String s_e_date="";		//查询的结束日期
		if(!Util.isCon(s_type)){//初始化下 如果是空 则默认为当月
			s_type="month";
			s_table_type="month";

			s_year=DateUtil.getCurYear();
			s_month=DateUtil.getCurMonth();
			statisticsData.setS_year(s_year);
			statisticsData.setS_month(s_month);
			statisticsData.setS_type(s_type);
		}

		if(s_type.equals("day")){//如果是日 把初始时间设为和结束时间设置为开始时间
			if(s_date.equals(Util.nowDate())){
				s_table_type="today";
			}else{
				s_table_type="other_day";
			}
		}
		if(s_type.equals("month")){//如果是月 把初始时间设为当月第一天 ，结束时间设置为月末
			s_b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			s_e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), Integer.parseInt(s_month));
			statisticsData.setS_b_date(s_b_date);
			statisticsData.setS_e_date(s_e_date);
			statisticsData.setS_month(s_month);
		}
		ArrayList <ParkingStatisticsData>statisticsList= new ArrayList();//整理完的数据放在这里 需要返回到页面
		ParkingStatisticsData averageData= new ParkingStatisticsData();//单个逻辑区域的平均使用率的数据放在这里 需要放到statisticsList
		
		
		
		for(int j = 0; j < codeList.size(); j++){//取每个逻辑区域的使用率 added by LLX0912
			Map map = codeList.get(j);
			String logicalId = map.get("code_id").toString();//逻辑区域ID
			String logicalName = map.get("code_name").toString();//逻辑区域Name
			statisticsData.setS_logic_id(logicalId);
			//获得逻辑车位数量
			int all_space_num = this.getJt().queryForInt(statistisSql.getAllSpaceNum(statisticsData));
			if(s_table_type.equals("today")){//按当日查使用率
				//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
				statisticsData.setS_e_date(s_date);
				ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.today_list(statisticsData, "used"),ParkingStatisticsData.class);
				
				int all_time=all_space_num*60;//all_space_num*60 所有车位*60分钟
				ParkingStatisticsData dayUsedData =new ParkingStatisticsData();//存储每一天按小时停车时长数据的dto
				
				dayUsedData.setP_day(logicalName);//行头部设置为“区域名”
				
				//算这些天的平均
				double[] usedArr=new double[24];//当日 停车时长 sum(p_time) group by hour
				for(ParkingStatisticsData sdata:rows){
					String p_hour=sdata.getP_hour();
					int p_in_hour_time=Integer.parseInt(sdata.getP_in_hour_time());//当日入车的分钟数 例如2012-03-04 12:54:32  存分钟：54
					String hh_type=sdata.getHh_type();//当日出车跟入车是否是同一个小时段内 1是 0 不是
					int p_time=Integer.parseInt(sdata.getP_time());//停车时长 分钟 
					
					
					//昨天已入车处理
					if (s_date.compareTo(sdata.getP_day())>0) {		
						p_hour= sdata.getP_out_hour();
						p_time= Integer.parseInt(sdata.getP_out_minute()); 
						usedArr[Integer.parseInt(p_hour)]+=p_time;
						for(int p=0;p<Integer.parseInt(p_hour);p++){
						   usedArr[p]+=60;
						}

					}else {  //当天入车处理
						if(hh_type.equals("1")){//同一小时段的  停车时间加一起
							usedArr[Integer.parseInt(p_hour)]+=p_time;
						}else{//不是同一小时段的  停车时间需要往后的小时段加上
							int p_hour_time=60-p_in_hour_time;//算p_hour这个小时段 停车时间
							int h=p_time/60;//算几个整小时的
							int m=(p_time+p_in_hour_time)%60;//余数
							usedArr[Integer.parseInt(p_hour)]+=p_hour_time;
							for(int p=1;p<h;p++){
								if(Integer.parseInt(p_hour)+p<24){//去掉跨天的
									usedArr[Integer.parseInt(p_hour)+p]+=60;
								}
							}
							if (h>0){
								if(Integer.parseInt(p_hour)+h<24){//去掉跨天的
									usedArr[Integer.parseInt(p_hour)+h]+=m;
								}
							}					
						}
					}		
					
				}
				//一天之内的总停车时间；
				double day_all_time=0;
				for(int i=0;i<24;i++){
					if(all_space_num==0){//车位总数是0
						OperateBeanInfo.setPropertyValue(dayUsedData,"col"+i,"-");//set bean  车位总数是0
					}else{
						//计算使用率
						double used_percent=0.00;
						used_percent=(usedArr[i]/all_time)*100>100?100:(usedArr[i]/all_time)*100;
						OperateBeanInfo.setPropertyValue(dayUsedData,"col"+i,df2.format(used_percent));//set bean  
					}
					day_all_time+=usedArr[i];
				}
				if(all_space_num==0){
					dayUsedData.setAll_times("-");//当天的平均使用率  
				}else{
					double day_used_percent=(day_all_time/(all_space_num*24*60))*100>100?100:(day_all_time/(all_space_num*24*60))*100;
					dayUsedData.setAll_times(df2.format(day_used_percent));//当天的平均使用率  
				}
				statisticsList.add(dayUsedData);
			}
			//TODO
			if(s_table_type.equals("other_day")){//非当日查使用率//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
				statisticsData.setS_b_date(s_date);
				statisticsData.setS_e_date(s_date);
				statisticsData.setS_type("day");//按月查非当日，开始时间和结束时间都设为s_date
				ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.inout_list(statisticsData, ""),ParkingStatisticsData.class);
				int all_time=all_space_num*60;//all_space_num*60 所有车位*60分钟
				averageData.setP_day(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("average").toString());//平均
				ParkingStatisticsData dayUsedData =new ParkingStatisticsData();//存储每一天按小时停车时长数据的dto
				dayUsedData.setP_day(logicalName);//逻辑区域名称
				for(ParkingStatisticsData sdata:rows){
					String p_hour=sdata.getP_hour();
					String p_time=sdata.getP_time();//停车时长 分钟
						if(all_space_num==0){//车位总数是0
							OperateBeanInfo.setPropertyValue(dayUsedData,"col"+Integer.parseInt(p_hour),"-");//set bean  车位总数是0
						}else{
							//计算使用率
							double used_percent=0.00;
							used_percent=(Double.parseDouble(p_time)/all_time)*100>100?100:(Double.parseDouble(p_time)/all_time)*100;
							OperateBeanInfo.setPropertyValue(dayUsedData,"col"+Integer.parseInt(p_hour),df2.format(used_percent));//set bean  
						}
				}
				
				double averageUsed=0.00;//平均使用率
				for(int p=0;p<24;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(dayUsedData,"col"+p))){//给空的col赋值0
						OperateBeanInfo.setPropertyValue(dayUsedData,"col"+p,"0.00");//默认0
					}else{
						averageUsed+=Double.parseDouble(OperateBeanInfo.getPropertyValue(dayUsedData,"col"+p).toString());
					}
				}
				dayUsedData.setAll_times(df2.format(averageUsed/24));//平均使用率
				statisticsList.add(dayUsedData);
			
				//算这些天的平均
				double[] avgArr=new double[24];
				double average_all=0;
				for(int i=0;i<statisticsList.size();i++){
					ParkingStatisticsData sdata=statisticsList.get(i);
					//~~算24小时中每个小时的平均数
					for(int p=0;p<24;p++){
						avgArr[p]+=Double.parseDouble(OperateBeanInfo.getPropertyValue(sdata,"col"+p).equals("-")?"0":OperateBeanInfo.getPropertyValue(sdata,"col"+p).toString());
					}
					//~~算所有时间总的
					double hh=0;
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(sdata,"all_times"))){
						hh=0;
					}else{
						if(OperateBeanInfo.getPropertyValue(sdata,"all_times").equals("-")){
							hh=0;
						}else{
							hh=Double.parseDouble(OperateBeanInfo.getPropertyValue(sdata,"all_times").toString());
						}
					}
					average_all+=hh;
				}
				for(int p=0;p<24;p++){
					String avg_h=df2.format(avgArr[p]/codeList.size());
					OperateBeanInfo.setPropertyValue(averageData,"col"+p,avg_h);//所有逻辑区域的按小时平均使用率
				}
				averageData.setAll_times(df2.format(average_all/codeList.size()));//表格最右下角的数据
			}
			if(s_table_type.equals("month")){//按月查询逻辑区域使用率
				//返回停车时间结果集 跟页面样式数据格式不一致 需要整理
				statisticsData.setS_type("year");//置为year 触发sql按年查询类型
				ArrayList <ParkingStatisticsData>rows = this.getJt().<ParkingStatisticsData>queryForListExt(statistisSql.inout_list(statisticsData, ""),ParkingStatisticsData.class);
				statisticsData.setS_type("month");//置为month
				int months=Integer.parseInt(s_month);//查询的月数 即为选择的月份
				int all_time=all_space_num*60*24;//all_space_num*60 所有车位*60分钟*24小时
				ParkingStatisticsData monthUsedData =new ParkingStatisticsData();//存储每一月按天利用率数据的dto
				String month=months<10?("0"+months):(months+"");
				monthUsedData.setP_month(logicalName);
				for(ParkingStatisticsData sdata:rows){//存储每一月按天停车时长数据的dto
					String p_month=sdata.getP_day().substring(0, 7);//2012-09
					String p_day=sdata.getP_day().substring(sdata.getP_day().lastIndexOf("-")+1);
					String p_time=sdata.getP_time();//停车时长 分钟
					if(p_month.equals(s_year+"-"+month)){
						if(all_space_num==0){//车位总数是0
							OperateBeanInfo.setPropertyValue(monthUsedData,"col"+Integer.parseInt(p_day),"0.00");//set bean  车位总数是0
						}else{
							//计算使用率
							double used_percent=0.00;
							//Log.log("年统计p_day: "+p_day);
							//Log.log(("----------"+Double.parseDouble(p_time)/all_time)*100);
							used_percent=(Double.parseDouble(p_time)/all_time)*100>100?100:(Double.parseDouble(p_time)/all_time)*100;
							OperateBeanInfo.setPropertyValue(monthUsedData,"col"+Integer.parseInt(p_day),df2.format(used_percent));//set bean
						}
					}
				}
				// 一下是处理空数据
				String b_date=DateUtil.getYearMonthFirstDay(Integer.parseInt(s_year), months);
				String e_date=DateUtil.getYearMonthEndDay(Integer.parseInt(s_year), months);
				int days=Integer.parseInt(DateUtil.getTwoDay(e_date,b_date))+1;
				//给空的col赋值0
				double day_avg=0.00;//每一天的平均使用率
				for(int p=1;p<=days;p++){
					if(!Util.isCon(OperateBeanInfo.getPropertyValue(monthUsedData,"col"+p))){
						OperateBeanInfo.setPropertyValue(monthUsedData,"col"+p,"0.00");//默认0
					}else{
						day_avg+=Double.parseDouble(OperateBeanInfo.getPropertyValue(monthUsedData,"col"+p).toString());
					}
				}
				for(int p=days+1;p<=31;p++){
					OperateBeanInfo.setPropertyValue(monthUsedData,"col"+p,"-");//-
				}
				monthUsedData.setAll_times(df2.format(day_avg/days));
				statisticsList.add(monthUsedData);
			
			
			}
		}

		statisticsData.setPer_data(statisticsList);
		return statisticsData;
	}
	
	/**
     * Description :获得逻辑区域list．
     * @param  :ParkingStatisticsData
     * @return :ParkingStatisticsData
     * @throws :Exception
     */
	public List getLogicRegionCode(){
		List codeList = new ArrayList();
		List rtList = new ArrayList();
		
		ParkingStatisticsData statisticsData=new ParkingStatisticsData();
		//先加一个 请选择 多语言
		statisticsData.setCode_id("");
		statisticsData.setCode_name("");//多语言 ""
		rtList.add(0, statisticsData);
		
		codeList=this.getJt().queryForListExt(statistisSql.getLogicRegionCode(), ParkingStatisticsData.class);
		Log.log("codeList-----"+codeList.size());
		for(int i=0;i<codeList.size();i++){
			rtList.add(codeList.get(i));
		}
		return rtList;
	}
	
	/**
	 * 逻辑区域使用率图表
	 * @param statisticsData
	 * @return
	 * @throws Exception
	 */
	public JSONArray logic_use_chart(ParkingStatisticsData statisticsData) throws Exception{
		JSONArray arr = new JSONArray();//存储返回结果
		ArrayList<ParkingStatisticsData> li = 
			(ArrayList<ParkingStatisticsData>)this.logical_used_list(statisticsData).getPer_data(); //获取查询数据
		java.lang.reflect.Field[] field = statisticsData.getClass().getDeclaredFields();//获取实体的所有属性，返回Field[]数组
		int liSize = li.size(); //获取li的大小
		if(statisticsData.getS_type().equals("month")){
			JSONArray nameArr = new JSONArray();
			JSONObject nameObj = new JSONObject();
			for(int j=0; j<32; j++){
				JSONObject jobj = new JSONObject();
				jobj.element("name",j);
				nameArr.add(jobj);
			}
			nameObj.element("label", nameArr);
			arr.add(nameObj);//X轴所需
			if(liSize == 0){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				List<Double> vList = new ArrayList<Double>();
				for(int j=0; j<32; j++){
					vList.add(0d);
				}
				dataArr.add(vList);
				dataObj.element("logicname", "");
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
			for(int k=0; k<liSize; k++){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				ParkingStatisticsData data = li.get(k);
				dataObj.element("logicname", data.getP_month());
				List vList = new ArrayList();
				for(int i=0; i<field.length; i++){
					String name = field[i].getName();
					if(name.indexOf("col")!=-1 && Integer.parseInt(name.substring(3, name.length())) < 32){
						String str = name.substring(1, name.length());
						//JSONObject json = new JSONObject();

    					java.lang.reflect.Method m = data.getClass().getMethod("getC"+str);
        				Object invoke = m.invoke(li.get(k));
        				double number = 0d;
        				
        				if(invoke != null ){
        					System.out.println("$$$$$$$$$$$$$$$$$$$"+invoke.toString());
        					if(!invoke.toString().equals("-"))
        							number = Double.parseDouble(invoke.toString());
        				}
        				//json.element("use_number", number);
        				vList.add(number);
        				//dataArr.add(json);
        				
					}
				}
				dataArr.add(vList);
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
		}else if(statisticsData.getS_type().equals("day")){
			JSONArray nameArr = new JSONArray();
			JSONObject nameObj = new JSONObject();
			for(int j=0; j<24; j++){
				JSONObject jobj = new JSONObject();
				jobj.element("name",j);
				nameArr.add(jobj);
			}
			nameObj.element("label", nameArr);
			arr.add(nameObj);//X轴所需
			
			if(liSize == 0){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				List<Double> vList = new ArrayList<Double>();
				for(int j=0; j<24; j++){
					vList.add(0d);
				}
				dataArr.add(vList);
				dataObj.element("logicname", "");
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
			for(int k=0; k<liSize; k++){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				ParkingStatisticsData data = li.get(k);
				dataObj.element("logicname", data.getP_day());
				List vList = new ArrayList();
				for(int i=0; i<field.length; i++){
					String name = field[i].getName();
					if(name.indexOf("col")!=-1 && Integer.parseInt(name.substring(3, name.length())) < 24){
						String str = name.substring(1, name.length());
						//JSONObject json = new JSONObject();
    					java.lang.reflect.Method m = data.getClass().getMethod("getC"+str);
        				Object invoke = m.invoke(li.get(k));
        				double number = 0d;
        				
        				if(invoke != null ){
        					System.out.println("$$$$$$$$$$$$$$$$$$$"+invoke.toString());
        					if(!invoke.toString().equals("-"))
        							number = Double.parseDouble(invoke.toString());
        				}
        				//json.element("use_number", number);
        				vList.add(number);
        				//dataArr.add(json);
					}
				}
				dataArr.add(vList);
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
		}else if(statisticsData.getS_type().equals("year")){
			JSONArray nameArr = new JSONArray();
			JSONObject nameObj = new JSONObject();
			for(int j=0; j<12; j++){
				JSONObject jobj = new JSONObject();
				jobj.element("name",j);
				nameArr.add(jobj);
			}
			nameObj.element("label", nameArr);
			arr.add(nameObj);//X轴所需
			
			if(liSize == 0){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				List<Double> vList = new ArrayList<Double>();
				for(int j=0; j<12; j++){
					vList.add(0d);
				}
				dataArr.add(vList);
				dataObj.element("logicname", "");
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
			for(int k=0; k<liSize; k++){
				JSONObject dataObj = new JSONObject();
				JSONArray dataArr = new JSONArray();
				ParkingStatisticsData data = li.get(k);
				dataObj.element("logicname", data.getP_month());
				for(int i=0; i<field.length; i++){
					String name = field[i].getName();
					if(name.indexOf("col")!=-1 && Integer.parseInt(name.substring(3, name.length())) < 12){
						String str = name.substring(1, name.length());
						JSONObject json = new JSONObject();
    					java.lang.reflect.Method m = data.getClass().getMethod("getC"+str);
        				Object invoke = m.invoke(li.get(k));
        				double number = 0d;
        				
        				if(invoke != null ){
        					System.out.println("$$$$$$$$$$$$$$$$$$$"+invoke.toString());
        					if(!invoke.toString().equals("-"))
        							number = Double.parseDouble(invoke.toString());
        				}
        				json.element("use_number", number);
        				dataArr.add(json);
					}
				}
				dataObj.element("data", dataArr);
				arr.add(dataObj);
			}
		}
		return arr;
	}
	
	/**
	 * 使用率图表list
	 * @param statisticsData
	 * @return
	 */
	public JSONArray use_list(ParkingStatisticsData statisticsData) throws Exception{
		//获得所有车位的车位总数
		int total = getJt().queryForInt(statistisSql.getAllSpaceNum(statisticsData));
		
		String currDate = get_realcurrDate();//获取Log表真实的当前时间
		String currYear = currDate.substring(0,4);
		String currMonth = currDate.substring(5,7);
		String currDay = currDate.substring(8,10);
		DecimalFormat df2  = new DecimalFormat("0.00");//两位小数 
		
		JSONArray arr = new JSONArray();
		if(statisticsData.getS_date().equals(currDate)){//按日查询且是当日,数据需从parkingspacelog表取出
			arr = today_usedchart(statisticsData, currDate, total);
		}else{
			arr = getJt().queryForJSONArrayExt(statistisSql.queryForUse(statisticsData, total));
			//添加当天数据
			if(statisticsData.getS_type().equals("month") && 
					statisticsData.getS_month().equals(currMonth)&& 
					statisticsData.getS_year().equals(currYear)){//按月统计且是本年本月则包含当日数据,此行同年判断 added by LLX 0917
				
				double[] usedArr = today_usehours(statisticsData, currDate);
				double today_usedpercent = 0d;
				if(total > 0){
					today_usedpercent = (today_usedall(usedArr)/(24*60*total))*100;
				}
				boolean flag = false;
				for(int i = 0 ; i < arr.size(); i++){
					if(arr.getJSONObject(i).get("name") != null){
						if(arr.getJSONObject(i).getString("name").equals(currDay)){
							flag = true;
							JSONObject ot = arr.getJSONObject(i);
							ot.element("use_number", df2.format(ot.getDouble("use_number") + today_usedpercent));
						}
					}
				}
				if(!flag){
					JSONObject tobj = new JSONObject();
					tobj.element("name", currDay);
					tobj.element("use_number", df2.format(today_usedpercent));
					arr.add(tobj);
				}
			}else if(statisticsData.getS_type().equals("year") && 
					statisticsData.getS_year().equals(currYear)){//按年统计
				double[] usedArr = today_usehours(statisticsData, currDate);
				double today_usedpercent = 0d;
				if(total > 0){
					int days = DateUtil.getMonthDays(Integer.valueOf(currYear),Integer.valueOf(currMonth));
					today_usedpercent = (today_usedall(usedArr)/(24*60*total*days))*100;
				}
				boolean flag = false;
				for(int i = 0 ; i < arr.size(); i++){
					if(arr.getJSONObject(i).get("name") != null){
						if(arr.getJSONObject(i).getString("name").equals(DateUtil.getCurMonth())){
							JSONObject ot = arr.getJSONObject(i);
							flag = true;
							ot.element("use_number", df2.format(ot.getDouble("use_number") + today_usedpercent));
						}
					}
				}
				if(!flag){
					JSONObject tobj = new JSONObject();
					tobj.element("name", currMonth);
					tobj.element("use_number", df2.format(today_usedpercent));
					arr.add(tobj);
				}
			}
			arr = resetSourceData(arr, statisticsData, "");
		}
		return arr;
	}

	/**
	 * 停车场出入情况图表
	 * @param statisticsData
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONArray chart_list(ParkingStatisticsData statisticsData) throws Exception{
		JSONArray arr = new JSONArray();
		if(statisticsData.getS_date().equals(DateUtil.getCurDate())){//如果查询“起始日期”等于系统“当前日期”
			ArrayList<ParkingStatisticsData> li = 
				(ArrayList<ParkingStatisticsData>)this.inout_list(statisticsData).getPer_data();
			ParkingStatisticsData data0 = li.get(0);
			ParkingStatisticsData data1 = li.get(1);
			//获取实体类的所有属性，返回Field数组  
			java.lang.reflect.Field[] field = data0.getClass().getDeclaredFields();        
	        for(int i=0,j=0 ; i<field.length ; i++){     //遍历所有属性
                String name = field[i].getName();    //获取属性的名字
                if(name.indexOf("col")!=-1){
                	String str = name.substring(1, name.length());
                	JSONObject json = new JSONObject();
    				java.lang.reflect.Method m = data0.getClass().getMethod("getC"+str);
    				java.lang.reflect.Method f = data1.getClass().getMethod("getC"+str);
    				//映射数据 填充到arr;
    				if(m.invoke(data0)!=null){
    					json.element("name", j + "");
    					json.element("use_number", (String)m.invoke(data0));
    				}
    				if(f.invoke(data1)!=null)
    					json.element("use_number_2", (String)f.invoke(data1));
    				
    	            arr.add(json);
    	            j++;
                }
			}
		}else{
			arr = getJt().queryForJSONArrayExt(statistisSql.queryForChart(statisticsData));
			if(statisticsData.getS_type().equals("month") && 
					statisticsData.getS_month().equals(DateUtil.getCurMonth())&& 
					statisticsData.getS_year().equals(DateUtil.getCurYear())){//本年本月统计 则包含当日数据 ,此行同年判断 added by LLX 0917
				
				JSONObject jo = getTodayState(statisticsData);//从parkingspacelog表获取当天数据
				for(int i=0; i<arr.size(); i++){
					if(arr.getJSONObject(i).get("name") != null){
						if(arr.getJSONObject(i).getString("name").equals(DateUtil.getCurDay())){
							JSONObject ot = arr.getJSONObject(i);//获取当日JSON对象的引用
							ot.element("use_number_2", ot.getDouble("use_number_2") + jo.getDouble("use_number_2"));
							ot.element("use_number", ot.getDouble("use_number") + jo.getDouble("use_number"));
						}
					}
				}
				//arr.add(jo);
			}else if(statisticsData.getS_type().equals("year") && 
					statisticsData.getS_year().equals(DateUtil.getCurYear())){//本年统计 则包含当日数据
				
				JSONObject jo = getTodayState(statisticsData);
				for(int i = 0 ; i < arr.size(); i++){
					if(arr.getJSONObject(i).get("name") != null){
						if(arr.getJSONObject(i).getString("name").equals(DateUtil.getCurMonth())){
							JSONObject ot = arr.getJSONObject(i);//获取当月JSON对象的引用
							ot.element("use_number_2", ot.getDouble("use_number_2") + jo.getDouble("use_number_2"));
							ot.element("use_number", ot.getDouble("use_number") + jo.getDouble("use_number"));
						}
					}
				}
				
			}
			arr = resetSourceData(arr,statisticsData,"inout");
		}
		return arr;
	}

	/**
	 * 处理返回数据，增加无数据的横坐标
	 * @param src 源数据
	 * @param data 查询类别
	 * @param type inout 或者 used
	 * @return
	 */
	public JSONArray resetSourceData(JSONArray src,ParkingStatisticsData data,String type){
		JSONArray rarr = new JSONArray();
		if(data.getS_type().equals("year")){
			rarr = generateSourceData(src,1,13,type);
		}else if(data.getS_type().equals("month")){
			int s_year = Integer.parseInt(data.getS_year());//年
			int s_month = Integer.parseInt(data.getS_month());//月
			int days = DateUtil.getMonthDays(s_year, s_month) + 1;
			rarr = generateSourceData(src,1,days,type);
		}else if(data.getS_type().equals("day")){
			rarr = generateSourceData(src,0,24,type);
		}
		return rarr;
	}
	
	/**
	 * 生成完整横坐标数据方法
	 * @param src
	 * @param start 横坐标起始值
	 * @param rangs 横坐标范围
	 * @param type
	 * @return
	 */
	public JSONArray generateSourceData(JSONArray src,int start, int rangs, String type){
		JSONArray rarr = new JSONArray();
		if(src.size() > 0){
			for(int i=start; i<rangs; i++){
				boolean flag = false;
				for(int j=0; j<src.size(); j++){
					if(src.getJSONObject(j).getInt("name") == i){
						src.getJSONObject(j).element("name", i);
						rarr.add(src.getJSONObject(j));
						flag = true;
					}
				}
				if(!flag){
					JSONObject jobj = new JSONObject();
					jobj.element("name", i);
					jobj.element("use_number", 0d);
					if(type.equals("inout")){
						jobj.element("use_number_2", 0d);
					}
					rarr.add(jobj);
				}
			}
		}else{
			for(int i=start; i<rangs; i++){
				JSONObject jobj = new JSONObject();
				jobj.element("name", i);
				jobj.element("use_number", 0d);
				if(type.equals("inout")){
					jobj.element("use_number_2", 0d);
				}
				rarr.add(jobj);
			}
		}
		return rarr;
	}
	
	private String generateXAxis(int i){
		if(i < 10){
			return "0"+i;
		}else{
			return String.valueOf(i);
		}
	}
	/**
	 * 取统计类别list
	 */		
	public  Object getSTypeList(boolean ready){
		List jsonArry =new ArrayList();
		JSONObject item = new JSONObject();
		item.element("code_id", "year");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("year").toString());//多语言 年
		jsonArry.add(item);

		item = new JSONObject();
		item.element("code_id", "month");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("month").toString());//多语言 月
		jsonArry.add(item);
		if(ready){
			item = new JSONObject();
			item.element("code_id", "day");
			item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("day").toString());//多语言 日
			jsonArry.add(item);
			
		}
		return jsonArry;
	}
	
	/**
	 * 取统计类别list
	 */		
	public  Object getSTypeList(){
		List jsonArry =new ArrayList();
		JSONObject item = new JSONObject();
		item.element("code_id", "month");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("month").toString());//多语言 月
		jsonArry.add(item);
		item = new JSONObject();
		item.element("code_id", "day");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("day").toString());//多语言 日
		jsonArry.add(item);
		return jsonArry;
	}

	/**
	 * 折线 柱图
	 * @param ready
	 * @return
	 */
	public  Object getTypeList(){
		List jsonArry =new ArrayList();
		//曲线
		JSONObject item = new JSONObject();
		item.element("code_id", "graph");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("graph").toString());//多语言 年
		jsonArry.add(item);
		//柱状
		item = new JSONObject();
		item.element("code_id", "histogram");
		item.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("histogram").toString());//多语言 月
		jsonArry.add(item);
		
		return jsonArry;
	}
	/**
	 * 设施车位类型数组
	 * @return
	 */
	public Object getParkType() {
		JSONArray arr = new JSONArray();
		JSONObject json = new JSONObject();
		json.element("code_id", "");
		json.element("code_name", "");//多语言 ""
		arr.add(json);
		json.element("code_id", "0");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("temporary_parking").toString());//多语言 临时车位
		arr.add(json);
		json.element("code_id", "1");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("reservation_parking").toString());//多语言 预定车位
		arr.add(json);
		json.element("code_id", "2");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("fixed_parking").toString());//多语言 固定车位
		arr.add(json);
		
		return arr;
	}

	public Object getLogicRegion() {
		JSONArray queryForJSONArrayExt = getJt().queryForJSONArrayExt(statistisSql.getLogicRegionCode());
		return queryForJSONArrayExt;
	}
	

	/**
	 * 导出excel
	 * @return
	 */
	public Object excel(ParkingStatisticsData statisticsData)throws SQLException,InstantiationException,IllegalAccessException{
		JSONObject json=new JSONObject(); 
		String file_name="未命名";//导出excel名称
		String list_type=statisticsData.getList_type();//占有率  还是出入车数
		String s_type=statisticsData.getS_type();//页面查询的类别  年月日 year month day

		String plist_type_inout=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("in_and_out_situation").toString();//出入车情况
		String plist_type_used=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("parking_occupancy_rate").toString();//使用率
		String plist_type_logical_used=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("logical_parking_occupancy_rate").toString();//逻辑区域使用率
		String ps_type_year=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("year").toString();//年
		String ps_type_month=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("month").toString();//月
		String ps_type_date=((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("day").toString();//日
		if(s_type.equals("month")){
			// 停车场使用情况/使用率：2012年12月
			file_name=((statisticsData.getList_type().equals("inout")?plist_type_inout:(statisticsData.getList_type().equals("used")?plist_type_used:plist_type_logical_used))+":")+statisticsData.getS_year()+ps_type_year+statisticsData.getS_month()+ps_type_month;
		}
		if(s_type.equals("year")){
			// 停车场使用情况/使用率：2012
			file_name=((statisticsData.getList_type().equals("inout")?plist_type_inout:(statisticsData.getList_type().equals("used")?plist_type_used:plist_type_logical_used))+":")+statisticsData.getS_year()+ps_type_year;
		}
		if(s_type.equals("day")){
			// 停车场使用情况/使用率：2012年12月25日
			file_name=((statisticsData.getList_type().equals("inout")?plist_type_inout:(statisticsData.getList_type().equals("used")?plist_type_used:plist_type_logical_used))+":")+statisticsData.getS_date();
		}
		statisticsData.setFile_name(file_name);
		json=(JSONObject) setExcelJson(statisticsData);
		json.element("list_type", list_type);
		//导出excel
		ExpExcel.madeExcel(json); 
		return null;
	}
	
	
	public Object setExcelJson(ParkingStatisticsData statisticsData){
		JSONObject json=new JSONObject(); 
		JSONArray title_jsonArray=new JSONArray();//excel表头列
		JSONArray data_jsonArray=new JSONArray();//excel数据
		String file_name=statisticsData.getFile_name();
		String list_type=statisticsData.getList_type();//占有率  还是出入车数
		String s_type=statisticsData.getS_type();//页面查询的类别  年月日 year month day
		if(!list_type.equals("logical_used")){
			if(s_type.equals("month")){
				title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("day_hour").toString());//   多语言 日/时
				title_jsonArray.add("00");
			}
			if(s_type.equals("year")){
				title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("month_day").toString());//   多语言 月/日
			}
			//赋值列表头数据
			title_jsonArray.add("01");
			title_jsonArray.add("02");
			title_jsonArray.add("03");
			title_jsonArray.add("04");
			title_jsonArray.add("05");
			title_jsonArray.add("06");
			title_jsonArray.add("07");
			title_jsonArray.add("08");
			title_jsonArray.add("09");
			title_jsonArray.add("10");
			title_jsonArray.add("11");
			title_jsonArray.add("12");
			title_jsonArray.add("13");
			title_jsonArray.add("14");
			title_jsonArray.add("15");
			title_jsonArray.add("16");
			title_jsonArray.add("17");
			title_jsonArray.add("18");
			title_jsonArray.add("19");
			title_jsonArray.add("20");
			title_jsonArray.add("21");
			title_jsonArray.add("22");
			title_jsonArray.add("23");
			if(s_type.equals("year")){//增加年的其他列
				title_jsonArray.add("24");
				title_jsonArray.add("25");
				title_jsonArray.add("26");
				title_jsonArray.add("27");
				title_jsonArray.add("28");
				title_jsonArray.add("29");
				title_jsonArray.add("30");
				title_jsonArray.add("31");
			}
			if(list_type.equals("inout")){//出入车数
				title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("total").toString());   
			}
			if(list_type.equals("used")){//占有率
				title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("average").toString());   
			}  
			//取全部数据
			//data_jsonArray=this.getJt().queryForJSONArrayExt(statistisSql.inout_list(statisticsData, ""));
			ParkingStatisticsData pkSt= null;

			if(list_type.equals("inout")){//出入车数
				pkSt=inout_list(statisticsData);
			}
			if(list_type.equals("used")){//占有率
				pkSt=used_list(statisticsData);
			} 
			ArrayList datalist=(ArrayList) pkSt.getPer_data();
			for(int i=0;i<datalist.size();i++){
				ParkingStatisticsData itemPkSt=(ParkingStatisticsData) datalist.get(i);
				JSONObject itemJson=new JSONObject();

				if(s_type.equals("month")){
					itemJson.element("p_day", itemPkSt.getP_day());
				}
				if(s_type.equals("year")){
					itemJson.element("p_month", itemPkSt.getP_month());
				}
				itemJson.element("col_0", itemPkSt.getCol0());
				itemJson.element("col_1", itemPkSt.getCol1());
				itemJson.element("col_2", itemPkSt.getCol2());
				itemJson.element("col_3", itemPkSt.getCol3());
				itemJson.element("col_4", itemPkSt.getCol4());
				itemJson.element("col_5", itemPkSt.getCol5());
				itemJson.element("col_6", itemPkSt.getCol6());
				itemJson.element("col_7", itemPkSt.getCol7());
				itemJson.element("col_8", itemPkSt.getCol8());
				itemJson.element("col_9", itemPkSt.getCol9());
				itemJson.element("col_10", itemPkSt.getCol10());
				itemJson.element("col_11", itemPkSt.getCol11());
				itemJson.element("col_12", itemPkSt.getCol12());
				itemJson.element("col_13", itemPkSt.getCol13());
				itemJson.element("col_14", itemPkSt.getCol14());
				itemJson.element("col_15", itemPkSt.getCol15());
				itemJson.element("col_16", itemPkSt.getCol16());
				itemJson.element("col_17", itemPkSt.getCol17());
				itemJson.element("col_18", itemPkSt.getCol18());
				itemJson.element("col_19", itemPkSt.getCol19());
				itemJson.element("col_20", itemPkSt.getCol20());
				itemJson.element("col_21", itemPkSt.getCol21());
				itemJson.element("col_22", itemPkSt.getCol22());
				itemJson.element("col_23", itemPkSt.getCol23());

				if(s_type.equals("year")){//增加年的其他列
					itemJson.element("col_24", itemPkSt.getCol24());
					itemJson.element("col_25", itemPkSt.getCol25());
					itemJson.element("col_26", itemPkSt.getCol26());
					itemJson.element("col_27", itemPkSt.getCol27());
					itemJson.element("col_28", itemPkSt.getCol28());
					itemJson.element("col_29", itemPkSt.getCol29());
					itemJson.element("col_30", itemPkSt.getCol30());
					itemJson.element("col_31", itemPkSt.getCol31());
				}
				itemJson.element("all_times", itemPkSt.getAll_times()); 
				data_jsonArray.add(itemJson);
				}
			}else{//逻辑区域占有率导出
				if(s_type.equals("day")){
					title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("logic_area").toString()+"\\"+((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("hour").toString());//   多语言 逻辑区域/小时
					title_jsonArray.add("00");
				}
				if(s_type.equals("month")){
					title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("logic_area").toString()+"\\"+((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("day").toString());//   多语言 逻辑区域/日期
				}
				//赋值列表头数据
				title_jsonArray.add("01");
				title_jsonArray.add("02");
				title_jsonArray.add("03");
				title_jsonArray.add("04");
				title_jsonArray.add("05");
				title_jsonArray.add("06");
				title_jsonArray.add("07");
				title_jsonArray.add("08");
				title_jsonArray.add("09");
				title_jsonArray.add("10");
				title_jsonArray.add("11");
				title_jsonArray.add("12");
				title_jsonArray.add("13");
				title_jsonArray.add("14");
				title_jsonArray.add("15");
				title_jsonArray.add("16");
				title_jsonArray.add("17");
				title_jsonArray.add("18");
				title_jsonArray.add("19");
				title_jsonArray.add("20");
				title_jsonArray.add("21");
				title_jsonArray.add("22");
				title_jsonArray.add("23");
				if(s_type.equals("month")){//增加月的其他列
					title_jsonArray.add("24");
					title_jsonArray.add("25");
					title_jsonArray.add("26");
					title_jsonArray.add("27");
					title_jsonArray.add("28");
					title_jsonArray.add("29");
					title_jsonArray.add("30");
					title_jsonArray.add("31");
				}
				if(list_type.equals("logical_used")){//占有率
					title_jsonArray.add(((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("average").toString());   
				}  
				//取全部数据
				//data_jsonArray=this.getJt().queryForJSONArrayExt(statistisSql.inout_list(statisticsData, ""));
				ParkingStatisticsData pkSt= null;
					pkSt=logical_used_list(statisticsData);
				ArrayList datalist=(ArrayList) pkSt.getPer_data();
				for(int i=0;i<datalist.size();i++){
					ParkingStatisticsData itemPkSt=(ParkingStatisticsData) datalist.get(i);
					JSONObject itemJson=new JSONObject();

					if(s_type.equals("day")){
						itemJson.element("p_day", itemPkSt.getP_day());
					}
					if(s_type.equals("month")){
						itemJson.element("p_month", itemPkSt.getP_month());
					}
					itemJson.element("col_0", itemPkSt.getCol0());
					itemJson.element("col_1", itemPkSt.getCol1());
					itemJson.element("col_2", itemPkSt.getCol2());
					itemJson.element("col_3", itemPkSt.getCol3());
					itemJson.element("col_4", itemPkSt.getCol4());
					itemJson.element("col_5", itemPkSt.getCol5());
					itemJson.element("col_6", itemPkSt.getCol6());
					itemJson.element("col_7", itemPkSt.getCol7());
					itemJson.element("col_8", itemPkSt.getCol8());
					itemJson.element("col_9", itemPkSt.getCol9());
					itemJson.element("col_10", itemPkSt.getCol10());
					itemJson.element("col_11", itemPkSt.getCol11());
					itemJson.element("col_12", itemPkSt.getCol12());
					itemJson.element("col_13", itemPkSt.getCol13());
					itemJson.element("col_14", itemPkSt.getCol14());
					itemJson.element("col_15", itemPkSt.getCol15());
					itemJson.element("col_16", itemPkSt.getCol16());
					itemJson.element("col_17", itemPkSt.getCol17());
					itemJson.element("col_18", itemPkSt.getCol18());
					itemJson.element("col_19", itemPkSt.getCol19());
					itemJson.element("col_20", itemPkSt.getCol20());
					itemJson.element("col_21", itemPkSt.getCol21());
					itemJson.element("col_22", itemPkSt.getCol22());
					itemJson.element("col_23", itemPkSt.getCol23());

					if(s_type.equals("month")){//增加月的其他列
						itemJson.element("col_24", itemPkSt.getCol24());
						itemJson.element("col_25", itemPkSt.getCol25());
						itemJson.element("col_26", itemPkSt.getCol26());
						itemJson.element("col_27", itemPkSt.getCol27());
						itemJson.element("col_28", itemPkSt.getCol28());
						itemJson.element("col_29", itemPkSt.getCol29());
						itemJson.element("col_30", itemPkSt.getCol30());
						itemJson.element("col_31", itemPkSt.getCol31());
					}
					itemJson.element("all_times", itemPkSt.getAll_times()); 
					data_jsonArray.add(itemJson);
					
				}
			}
		
		json.element("file_name", file_name);//文件名
		json.element("start_row", 0);//
		json.element("start_col", 0);//
		json.element("title_jsonArray", title_jsonArray);
		json.element("data_jsonArray", data_jsonArray);
		
		return json;
	}

	public List getPhysicalRegionCode() {
		List codeList = new ArrayList();
		List rtList = new ArrayList();
		
		ParkingStatisticsData statisticsData=new ParkingStatisticsData();
		//先加一个 请选择 多语言
		statisticsData.setCode_id("");
		statisticsData.setCode_name("");//多语言 ""
		rtList.add(0, statisticsData);
		
		codeList=this.getJt().queryForListExt(statistisSql.getPhysicalRegionCode(), ParkingStatisticsData.class);
		Log.log("codeList-----"+codeList.size());
		for(int i=0;i<codeList.size();i++){
			rtList.add(codeList.get(i));
		}
		return rtList;
	}

	public List nextLogicList(String parameter) {
		// TODO Auto-generated method stub
		return this.getJt().queryForList(statistisSql.getLogicRegionCode(parameter));
	}
	public static void main(String[] args) {
		double a = 240d;
		double b = 36420d;
		double c = (a/b)*100;
		System.out.println(c);
		
	}
	
	/**
	 * 当日总占有率
	 * @param data
	 * @param total 总车数
	 * @return
	 * @throws Exception
	 */
	private  JSONObject getTodayData(ParkingStatisticsData data, int total) throws Exception{
		
		JSONArray arr = this.getJt().queryForJSONArrayExt(statistisSql.getTodaySql(data));
		double hour = 0d;
		JSONObject json = new JSONObject();
		if(arr.size() > 0){
			for(int i = 0; i < arr.size(); i++){
				JSONObject jo = arr.getJSONObject(i);
				jo = this.getCalTodayData(jo);
				if(Util.isCon(jo.get("hour"))){
					hour += jo.getDouble("hour");
				}
				
			}
			json.element("hour", hour / total / 24 * 100);
		}else{
			json.element("hour", 0.00);
		}
		json.element("day", DateUtil.getCurDay());
		return json;
	}

	/**当日总进出车
	 * @param data
	 * @return
	 */
	private JSONObject getTodayState(ParkingStatisticsData data) {
		int put_out = getJt().queryForInt(statistisSql.putOutSql(data)); //出车
		int put_in = getJt().queryForInt(statistisSql.putInSql(data));   //入车
		
		JSONObject json = new JSONObject();
		json.element("use_number_2", put_out);
		json.element("use_number", put_in);
		json.element("name", DateUtil.getCurDay());
		return json;
	}
	
	/**
	 * 计算当天的出入库情况的算法
	 * @param jo
	 * @return
	 */
	private JSONObject getCalTodayState(JSONObject jo) {
		String intime = jo.getString("intime");
		String outtime = jo.getString("outtime");
		String day = intime.substring(0, 10);
		double hour = 0d;
		String twoHour = "";
		int output = 0;
			//当天进车
			if(day.equals(DateUtil.getCurDate())){
				output ++;
			}
		
		hour = Double.parseDouble(twoHour);
		jo.element("hour", hour);
		return jo;
	}

	/**
	 * 计算占有率的算法
	 * 
	 * @param jo
	 * @return
	 */
	private static JSONObject getCalTodayData(JSONObject jo) {
		String intime = jo.getString("intime");
		String outtime = jo.getString("outtime");
		String day = intime.substring(0, 10);
		double hour = 0d;
		String twoHour = "";
		//出车
		if(jo.getString("putout").equals("1")){
			//当天进车
			if(day.equals(DateUtil.getCurDate())){
				twoHour = DateUtil.getTwoHour(outtime.substring(11, 16), intime.substring(11, 16));
			}else{
				twoHour = DateUtil.getTwoHour(outtime.substring(11, 16), "00:00");
			}
			
		//未出车
		}else{
			twoHour = DateUtil.getTwoHour(DateUtil.getCurDateTime().substring(11, 16), "00:00");
		}
		hour = Double.parseDouble(twoHour);
		jo.element("hour", hour);
		return jo;
	}

	//===停车出入明细表=============================================================================================
	/**
	 * @param carport 车牌号码
	 * @param start 页码
	 * @param limit 每页查询的记录数
	 * @param sDate 开始时间
	 * @param eDate 结束时间
	 * @return 
	 */
	public List<ParkingData> carNumDateSearch(String carNum, String sDate, String eDate, int start, int limit) {
		// TODO Auto-generated method stub
		start = (start - 1) * limit;
		StringBuilder sb = new StringBuilder();
		sb = groupCarManageSql(carNum, sDate, eDate);
		sb.append("limit ").append(start).append(",").append(limit);
		Log.log(sb);
		@SuppressWarnings("unchecked")
		List<ParkingData> hisList = (ArrayList<ParkingData>)this.getJt().queryForListExt(sb.toString(), ParkingData.class);
		String path = ServletActionContext.getRequest().getContextPath();
		path += "/inversion/picCreate.jsp?ppath=";
		for(ParkingData park : hisList){
			park.setInTime(park.getInTime() == null ? "" : park.getInTime().substring(0, park.getInTime().lastIndexOf(".")));
			park.setOutTime(park.getOutTime() == null ? "" : park.getOutTime().substring(0, park.getOutTime().lastIndexOf(".")));
			//System.out.println("Image: " + park.getCarSrc());
			try {
				park.setCarSrc(park.getCarSrc() == null ? "" : path + URLEncoder.encode(park.getCarSrc(), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				Log.log("车的图片路经编码失败!");
			}
		}
		
		Log.log(hisList);
		return hisList;
	}

	/**
	 * 查询总条数
	 * @param carNum
	 * @param sDate
	 * @param eDate
	 * @param pageSize
	 * @return
	 */
	public int getTotalPage(String carNum, String sDate, String eDate,
			int pageSize) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb = groupCarManageSql(carNum, sDate, eDate);
		@SuppressWarnings("rawtypes")
		List list = this.getJt().queryForList(sb.toString());
		
		int total = list.size();
		int t = total / pageSize;
		return total % pageSize > 0 ? t + 1 : t;
	}
	
	/**
	 * 组装停车出入明细
	 * @param carport
	 * @param sDate
	 * @param eDate
	 * @return
	 */
	private StringBuilder groupCarManageSql(String carport, String sDate, String eDate){
		StringBuilder sb = new StringBuilder();
		sDate = checkNull(sDate).equals("") ? "" : sDate.split(" ")[0] + " 00:00:00";
		eDate = checkNull(eDate).equals("") ? "" : eDate.split(" ")[0] + " 23:59:59";
		
		sb.append("SELECT log.id as id, log.parkingSpaceCode as code, log.inTime as inTime, log.outTime as outTime, log.plateno as carNum, pm.name as parkName, pg.`code` as areaName FROM p_parkingspaceoperationlog as log")
			.append(" left join p_parkingspace pp on log.parkingSpaceId=pp.id left join p_detector pd on pp.detectorId=pd.id left join p_guideregion pg on pd.guideRegionId=pg.id left join p_map pm on pd.mapId=pm.id WHERE ");
		if (!checkNull(sDate).equals("") && !checkNull(eDate).equals("")) { // 如果开始时间都结束时间不为空就添加时间的查询
			sb.append("log.inTime BETWEEN '" + checkNull(sDate) + "' AND '"
					+ checkNull(eDate) + "' AND ");
		}
		sb.append(" log.plateno LIKE '%" + checkNull(carport) + "%' or log.parkingSpaceCode ='" + checkNull(carport) + "' UNION ");
		sb.append("select hiss.id as id, hiss.code as code, hiss.inTime as inTime, hiss.outTime as outTime, hiss.carNum as carNum, pm.name as parkName, pg.`code` as areaName from (");
		sb.append("select his.id as id, his.parkingSpaceCode as code, his.inTime as inTime, max(his.outTime) as outTime, his.plateno as carNum, his.picturepath as carSrc, his.parkingSpaceId from")
			.append(" (select * from p_parkingspaceoperationhis where id NOT IN(select id from p_parkingspaceoperationlog) order by inTime) ").append("as his group by his.id) as hiss ")
			.append(" left join p_parkingspace pp on hiss.parkingSpaceId=pp.id left join p_detector pd on pp.detectorId=pd.id left join p_guideregion pg on pd.guideRegionId=pg.id left join p_map pm on pd.mapId=pm.id WHERE hiss.inTime != hiss.outTime AND ");
		if(!checkNull(sDate).equals("") && !checkNull(eDate).equals("")){	//如果开始时间都结束时间不为空就添加时间的查询
			sb.append("hiss.inTime BETWEEN '" + checkNull(sDate) + "' AND '" + checkNull(eDate) + "' AND ");
		}
		sb.append("(hiss.carNum LIKE '%" + checkNull(carport) + "%' or hiss.code ='" + checkNull(carport) + "') ");
		
		return sb;
	}
	
	/**
	 * 如果字符串为空就赋值为空,否则返回原值
	 * @param str
	 * @return
	 */
	public String checkNull(String str){
		return str == null ? "" : str;
	}
	//===停车出入明细表=============================================================================================	

	
	//====停车出入明细表-导出EXCEL===========================================================================================================
	
	public File exportToExcel(List<ParkingData> parkingDataList, Map<String, Object> common) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String[] titleList = new String[]{(String) common.get("sequence"), (String) common.get("carNum"), (String) common.get("parking_lot_number"),
				(String) common.get("areaName"), (String) common.get("currentFloor"), (String) common.get("parkTime"), (String) common.get("quitTime")};
		File file = null;
		try {
			file = createFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dataIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("停车出入明细表", 0);
			sheet.setColumnView(5, 20);
			sheet.setColumnView(6, 20);
			for (ParkingData parkingData : parkingDataList) {
				Label sequence = new Label(0, dataIndex, "'" + dataIndex);		//添加序号
				sheet.addCell(sequence);
				
				Label carNum = new Label(1, dataIndex, parkingData.getCarNum());		//添加车牌号码
				sheet.addCell(carNum);
				Label code = new Label(2, dataIndex, parkingData.getCode());		//添加车位编号
				sheet.addCell(code);
				Label areaName = new Label(3, dataIndex, parkingData.getAreaName());		//添加车位编号
				sheet.addCell(areaName);
				Label parkName = new Label(4, dataIndex, parkingData.getParkName());		//添加所在楼层
				sheet.addCell(parkName);
				Label inTime = new Label(5, dataIndex, parkingData.getInTime());		//添加入场时间
				sheet.addCell(inTime);
				Label outTime = new Label(6, dataIndex, parkingData.getOutTime());		//添加出场时间
				sheet.addCell(outTime);

				++dataIndex;
			}
			
			for(int i = 0; i < 7; i++){					//添加表头
				Label title = new Label(i, 0, titleList[i]);
				sheet.addCell(title);
			}
			
			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 创建文件
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	private File createFile() throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calender = Calendar.getInstance();
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = ExpExcel.WINEXCELPATH;
		} else {
			path = ExpExcel.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + sdf.format(calender.getTime()) + ".xls");
		file.createNewFile();
		return file;
	}

	//=======停车出入明细表-导出EXCEL========================================================================================================

	//===start 视频探测器运行情况表======================================================================================
	/**
	 * 使用sql语句查询数据库中的视频探测器运行记录表，以获取探测器运行记录信息
	 * @param : @param sDate
	 * @param : @param eDate
	 * @param : @param detectorId
	 * @param : @param connect_type
	 * @param : @param pageSize
	 * @param : @return  
	 * @return : 探测器运行记录
	 * @throws : 
	 * @author : 0917
	 */
	public List<UDWorkingRecordData> udWorkingRecord(String sDate,String eDate,String detectorId
			,String connect_type,int pageIndex, int pageSize){
		
		int sLimit = (pageIndex-1)*pageSize;
		String sb=new String();
		sb = statistisSql.video_runRecordSql(sDate,eDate,detectorId,connect_type);   //根据条件获取sql语句
		sb += " limit " + sLimit + "," + pageSize;    //根据分页信息，显示出请求页数据
		
		//执行sql语句，并将结果保存到List<UDWorkingRecordData>中
		@SuppressWarnings("unchecked")
		List<UDWorkingRecordData> udList = (ArrayList<UDWorkingRecordData>)this.getJt().queryForListExt(sb.toString(), UDWorkingRecordData.class);
		
		return udList;
		
	}
	
	/**
	 * 
	 * @Description : 根据查询条件，查询视频探测器表中总共有多少条数据，并返回分页数
	 * @param : @param sDate
	 * @param : @param eDate
	 * @param : @param detectorId
	 * @param : @param connect_type
	 * @param : @param pageSize
	 * @param : @return  
	 * @return : 分页数
	 * @throws : 
	 * @author : 0917
	 */
	public int getUDWorkingTotalPage(String sDate,String eDate,String detectorId
			,String connect_type,int pageSize){
		
		String str=new String();
		str = statistisSql.video_runRecordSql(sDate,eDate,detectorId,connect_type);   //根据条件，获取sql语句
		List ls=this.getJt().queryForListExt(str, UDWorkingRecordData.class);   //执行sql语句，查询数据库，并将结果保存到List中
		
		int total = ls.size();
		int t = total / pageSize;
		return total % pageSize > 0 ? t + 1 : t;
		
	}	
	
	public UDWorkingRecordData udWorkingRecord_r(UDWorkingRecordData uData,String sDate,String eDate,String detectorId,String connect_type,int start,int limit){
		
		String sql = statistisSql.video_runRecordSql(sDate,eDate,detectorId,connect_type);
		
		int count = this.getJt().queryForInt(statistisSql.getRecordTotalSql(sDate, eDate, detectorId, connect_type));
		
		uData.setTotal(count);
		uData.setStartExt(count);
		
		List<UDWorkingRecordData> udDataList = this.getJt().queryForListExt(sql,start, limit, UDWorkingRecordData.class);
		uData.setPer_data(udDataList);
		
		return uData;
	}
	
	//===end 视频探测器运行情况表========================================================================================
	
	//===start 视频探测器运行情况表-导出excel=============================================================================
	public File udExportToExcel(List<UDWorkingRecordData> udWorkingDataList, Map<String, Object> common) {
		// TODO 创建列表
		// TODO Auto-generated method stub
		String[] titleList = new String[]{(String) common.get("sequence"), (String) common.get("occurrence_time"), (String) common.get("detector_cid"),
				(String) common.get("detector_mac_addr"), (String) common.get("connect_type"), (String) common.get("connect_desc"), (String) common.get("remark")};
		File file = null;
		try {
			file = createFile();   //调用“停车出入明细表-导出EXCEL”模块中的createFile()来创建一个excel文件
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dataIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("视频探测器运行情况表", 0);
			sheet.setColumnView(1, 20);
			for (UDWorkingRecordData udWorkingData : udWorkingDataList) {
				Label sequence = new Label(0, dataIndex, " " + dataIndex);		//添加序号
				sheet.addCell(sequence);
				
				Label dateTime = new Label(1, dataIndex, udWorkingData.getDateTime());		//记录发生时间
				sheet.addCell(dateTime);
				Label detectorId = new Label(2, dataIndex, udWorkingData.getDetectorId());		//探测器编号
				sheet.addCell(detectorId);
				Label macAddr = new Label(3, dataIndex, udWorkingData.getMacAddr());		//探测器物理地址
				sheet.addCell(macAddr);
				Label connType = null;		//连接状态类型
				if(udWorkingData.getConnType().equals("0")){
					connType = new Label(4, dataIndex, "上线");
				}
				else if(udWorkingData.getConnType().equals("1")){
					connType = new Label(4, dataIndex, "离线");
				}
				else if(udWorkingData.getConnType().equals("2")){
					connType = new Label(4, dataIndex, "半连接");
				}
				else if(udWorkingData.getConnType().equals("3")){
					connType = new Label(4, dataIndex, "未连接");
				}
				else{
					connType = new Label(4, dataIndex, "");
				}
				sheet.addCell(connType);
				Label connDesc = new Label(5, dataIndex, udWorkingData.getConnDesc());		//连接状态描述
				sheet.addCell(connDesc);
				Label remark = new Label(6, dataIndex, udWorkingData.getRemark());		//备注
				sheet.addCell(remark);

				++dataIndex;
			}
			
			for(int i = 0; i < 7; i++){					//添加表头
				Label title = new Label(i, 0, titleList[i]);
				sheet.addCell(title);
			}
			
			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	//===end 视频探测器运行情况表-导出excel===============================================================================
	
	/**
	 * 设置探测器连接类型下拉框数据
	 * @return
	 */
	public List getConnectType() {
		List arr = new ArrayList();
		JSONObject json = new JSONObject();
		json.element("code_id", "");
		json.element("code_name", "");//多语言 ""
		arr.add(json);
		json.element("code_id", "0");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("all").toString());//多语言全部
		arr.add(json);
		json.element("code_id", "1");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("inline").toString());//多语言 上线
		arr.add(json);
		json.element("code_id", "2");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("outline").toString());//多语言 离线
		arr.add(json);
		json.element("code_id", "3");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("half_connect").toString());//多语言 半连接
		arr.add(json);
		json.element("code_id", "4");
		json.element("code_name", ((Map) this.getUserinfo().getCurrent_lang_switch().get("common")).get("not_connect").toString());//多语言 未连接
		arr.add(json);
		
		return arr;
	}
	
	//====start导出Excel=================================================================================
	public File udExportToExcel2(List<UDWorkingStatisticsData> udStatisticsDataList, Map<String, Object> common) {
		// TODO 创建列表
		// TODO Auto-generated method stub
		String[] titleList = new String[]{(String) common.get("sequence"), (String) common.get("detector_id"), (String) common.get("map_name"),
				(String) common.get("parking_lot_number"), (String) common.get("online_last_time"), (String) common.get("outline_last_time"), 
				(String) common.get("online_times"),(String) common.get("outline_times"),(String) common.get("suggest_do_bug")};
		File file = null;
		try {
			file = createFile();   //调用createFile()来创建一个excel文件
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dataIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("视频探测器运行情况统计表", 0);
			sheet.setColumnView(4, 20);
			sheet.setColumnView(5, 20);
			for (UDWorkingStatisticsData udWorkingData : udStatisticsDataList) {
				Label sequence = new Label(0, dataIndex, "s " + dataIndex);		//添加序号
				sheet.addCell(sequence);
				
				Label detectorId = new Label(1, dataIndex, udWorkingData.getDetectorId());		//探测器编号
				sheet.addCell(detectorId);
				Label map = new Label(2, dataIndex, udWorkingData.getMap());		//地图名称
				sheet.addCell(map);
				Label spotCode = new Label(3, dataIndex, udWorkingData.getSpotCode());		//车位编号
				sheet.addCell(spotCode);
				Label lastOnTime = new Label(4, dataIndex, udWorkingData.getLastOnTime());		//最后一次上线时间
				sheet.addCell(lastOnTime);
				Label lastOutTime = new Label(5, dataIndex, udWorkingData.getLastOutTime());		//最后一次离线时间
				sheet.addCell(lastOutTime);
				Label onTimes = new Label(6, dataIndex, String.valueOf(udWorkingData.getOnlineTimes()));		//在线次数
				sheet.addCell(onTimes);
				Label outTimes = new Label(7, dataIndex, String.valueOf(udWorkingData.getOutlineTimes()));		//离线次数
				sheet.addCell(outTimes);
				Label suggest = new Label(8, dataIndex, udWorkingData.getSuggest());		//故障处理建议
				sheet.addCell(suggest); 
				
				++dataIndex;
			}
			
			for(int i = 0; i < 7; i++){					//添加表头
				Label title = new Label(i, 0, titleList[i]);
				sheet.addCell(title);
			}
			
			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	//===end导出Excel=======================================================================================
}
