package com.ie.its.parkingstatistics;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import jxl.Workbook;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.ie.common.Log;

public class ExpExcel {

	protected static final String WINEXCELPATH = "f:/excel";
	protected static final String LINUXEXCELPATH = "/usr/its/excel";
	
	/**
	 * 根据参数json里的值 创建excel
	 * file_name:文件名，start_row:excel开始的行，start_col:excel开始的列，
	 * title_jsonArray：表格头的JSONArray["name1","name2","name3"...]
	 * data_jsonArray: 表格数据JSONArray[{json},{json},{json}...]
	 * 
	 *@param json 格式：{file_name:'',start_row:int,start_col:int,title_jsonArray:JSONArray,data_jsonArray:JSONArray}
	 * @return 
	 *@return null
	*/
	public static void madeExcel(JSONObject json){
		String  list_type=json.has("list_type")?json.getString("list_type"):"used";//统计类别
		Log.log("list_typelist_type------"+list_type);
		String  file_name=(json.has("file_name")?json.getString("file_name"):"未命名")+".xls";//文件名
		int start_row=json.has("start_row")?json.getInt("start_row"):0;//开始行
		int start_col=json.has("start_col")?json.getInt("start_col"):0;//开始列
		JSONArray title_jsonArray=json.getJSONArray("title_jsonArray");
		JSONArray data_jsonArray=json.getJSONArray("data_jsonArray");
		int title_rows=1;//数据开始行
		try {
			WritableWorkbook workbook = Workbook.createWorkbook(new File(file_name));
			WritableSheet sheet = workbook.createSheet("Sheet", 0); 
			//设置边框
			WritableCellFormat wcsB = new WritableCellFormat(); 
			wcsB.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.HAIR);
			//表头
//			System.out.println("json"+json);
//			System.out.println("title_jsonArray"+title_jsonArray);
			if(json.has("groupHeader")&&json.getBoolean("groupHeader")==true){//带合并表头的
				title_rows=title_jsonArray.size();
				for(int i=0;i<title_jsonArray.size();i++){
					JSONObject item=new JSONObject();
					item=title_jsonArray.getJSONObject(i);
					Iterator  keyIter = item.keys();
					int groupcols=0;
					while(keyIter.hasNext()){
						String key=keyIter.next().toString();
						int cols=item.getInt(key);//需要几列合并在一起
//						System.out.println(start_col+groupcols+"，"+(i+start_row)+"，"+(start_col+cols+groupcols-1)+"，"+(i+start_row));
//						System.out.println(groupcols+start_col+"，"+(i+start_row)+"，"+key);
						sheet.mergeCells(start_col+groupcols, i+start_row, start_col+cols+groupcols-1, i+start_row);//(column, row, column1, row1)
						sheet.addCell(new jxl.write.Label(groupcols+start_col,i+start_row,key.indexOf("#*")>0?key.substring(key.indexOf("#*")+2):key));
						groupcols+=cols;
					}
				}
			}else{//正常表头
				jxl.write.WritableFont wfc = new jxl.write.WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD,false,jxl.format.UnderlineStyle.NO_UNDERLINE,jxl.format.Colour.RED);
				jxl.write.WritableCellFormat wcfFC = new jxl.write.WritableCellFormat(wfc);
				for(int i=0;i<title_jsonArray.size();i++){
					sheet.addCell(new jxl.write.Label(i+start_col,start_row, title_jsonArray.getString(i),wcfFC));
				}
				sheet.setColumnView(0,15);//列宽
			}
			//Log.log(json);
			for(int i=0;i<data_jsonArray.size();i++){//数据部分
				JSONObject item = data_jsonArray.getJSONObject(i);
				Iterator  keyIter = item.keys();
				int j=0;
				while(keyIter.hasNext()){
					sheet.addCell(new jxl.write.Label(j+start_col,i+title_rows+start_row,item.getString(keyIter.next().toString())));
					j++;
				}
				if((list_type.equals("inout"))&&(i%2==0)){
					Log.log("start_col----"+start_col);
					Log.log("i+title_rows+start_row----"+i+title_rows+start_row);
					sheet.mergeCells(start_col,i+title_rows+start_row,start_col,i+title_rows+start_row+1);
				}
			}
			workbook.write(); 
			workbook.close();
		} catch (RowsExceededException e) {
			e.printStackTrace();
		} catch (WriteException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
	}
}
