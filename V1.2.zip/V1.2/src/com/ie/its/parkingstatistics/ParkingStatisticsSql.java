package com.ie.its.parkingstatistics;

import static com.ie.common.Util.isCon;
import static com.ie.common.Util.toSqlVal;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
public class ParkingStatisticsSql<T> extends ExtendSql{
	/**
	 * Description:查询视频探测器运行记录总表
	 * @param :statisticsData   输入的查询条件数据
	 * @return：String
	 */
	public String video_runRecordSql(String sDate,String eDate,String detectorId,String connect_type){
		String querySql = "";
		//Log.log(str);  
		querySql += "select ctrlId as detectorId, macAddr as macAddr,date_format(dateTime,'%Y-%m-%d %T') as dateTime,connType as connType,connDesc as connDesc ";
		querySql += "from p_ctrlerconnstate where 1=1 ";
		if(isCon(sDate)){
			querySql += " and dateTime>=" + toSqlVal(sDate);
		}
		if(isCon(eDate)){
			querySql += " and dateTime<=" + toSqlVal(eDate);
		}
		if(isCon(connect_type) && !connect_type.equals("4")){
			querySql += " and connType=" + toSqlVal(connect_type);
		}
		if(isCon(detectorId)){
			querySql += " and macAddr like \"%" +detectorId+"%\"";
		}
		querySql += " order by dateTime DESC";
				
		return querySql;
		
	}
	
	/**
	 * 
	 * @Description : 获取探测器运行记录总数
	 * @param : @param sDate
	 * @param : @param eDate
	 * @param : @param detectorId
	 * @param : @param connect_type
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 1964919885@qq.com
	 */
	public String getRecordTotalSql(String sDate,String eDate,String detectorId,String connect_type){
		String querySql = "select count(*) from p_ctrlerconnstate where 1=1 ";
		if(isCon(sDate)){
			querySql += " and dateTime>=" + toSqlVal(sDate);
		}
		if(isCon(eDate)){
			querySql += " and dateTime<=" + toSqlVal(eDate);
		}
		if(isCon(connect_type) && !connect_type.equals("4")){
			querySql += " and connType=" + toSqlVal(connect_type);
		}
		if(isCon(detectorId)){
			querySql += " and macAddr like \"%" +detectorId+"%\"";
		}
		
		return querySql;
	}
	
	/**
     * Description :查询统计 出入车总数．
     * @param  :statisticsData,
     * @param  :type  暂没用
     * @return :String
     */
	public String inout_list(ParkingStatisticsData statisticsData,String type) {
		String querySql = "";
		Log.log(statisticsData.getS_type());
		if(statisticsData.getS_type().equals("day")||statisticsData.getS_type().equals("month")){//统计类别
			querySql += "select concat(year,'-',month,'-',day) as p_day, hour as p_hour,sum(inCount) as in_times,  ";
			querySql += " sum(outCount) as out_times  ,sum(duration) as p_time ";//sum(duration) as p_time 停车时长 分钟
			querySql += " from p_parkingspacestatistics ps  where 1=1  ";
			if(isCon(statisticsData.getS_b_date())){
				querySql += " and concat(ps.year,'-',ps.month,'-',ps.day) >= " + toSqlVal(statisticsData.getS_b_date());
			}
			if(isCon(statisticsData.getS_e_date())){
				querySql += " and concat(ps.year,'-',ps.month,'-',ps.day) <= " + toSqlVal(statisticsData.getS_e_date());
			}
			if(isCon(statisticsData.getS_spot_type())){
				querySql += " and ps.spotType= " + toSqlVal(statisticsData.getS_spot_type());
			}
			if(isCon(statisticsData.getS_logic_id())){
				querySql += " and mapLogicRegionId= " + toSqlVal(statisticsData.getS_logic_id());
			}
			//物理区域
			if(Util.isCon(statisticsData.getS_physical_id())){
				querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
			}
			querySql+= " group by p_day,p_hour ";
		}
		if(statisticsData.getS_type().equals("year")){
			querySql += "select  concat(year,'-',month) as p_month,concat(year,'-',month,'-',day) as p_day,sum(inCount) as in_times,  ";
			querySql += " sum(outCount) as out_times ,sum(duration) as p_time ";//sum(duration) as p_time 停车时长 分钟
			querySql += " from p_parkingspacestatistics ps  where 1=1  ";
			if(isCon(statisticsData.getS_year())){//应该是必须有值的
				querySql += " and year like '%" + statisticsData.getS_year()+"%'";
			}
			if(isCon(statisticsData.getS_spot_type())){
				querySql += " and ps.spotType= " + toSqlVal(statisticsData.getS_spot_type());
			}
			if(isCon(statisticsData.getS_logic_id())){
				querySql += " and mapLogicRegionId= " + toSqlVal(statisticsData.getS_logic_id());
			}
			//物理区域
			if(Util.isCon(statisticsData.getS_physical_id())){
				querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
			}
			querySql+= " group by p_month,p_day ";
			

			if(isCon(statisticsData.getS_year())&&statisticsData.getS_year().equals(DateUtil.getCurYear())){//当年的话 取当天数据
				
				querySql += " union  ";
				querySql += "select p_month ,p_day ,sum(in_times) as in_times,sum(out_times) as out_times,sum(p_time) as p_time  ";
				querySql += " from ( ";
					querySql += " select date_format(psl.inTime,'%Y-%m') as p_month,  date_format(psl.inTime,'%Y-%m-%d') as p_day,  ";
					querySql += " count(putOut) as in_times ,count(putOut) as out_times, ";
					querySql += " (sum(hour(outTime)-hour(inTime))*60+sum(minute(outTime)-minute(inTime))) as p_time  ";
					querySql += " from p_parkingspaceoperationlog psl  ";
					querySql += " left join p_parkingspace ps on psl.parkingSpaceId = ps.id  ";
					querySql += " where outTime is not null and  date_format(psl.inTime,'%Y-%m-%d') =date_format(now(),'%Y-%m-%d')  ";//取当天有出车的
					if(isCon(statisticsData.getS_spot_type())){
						querySql += " and psl.spotType= " + toSqlVal(statisticsData.getS_spot_type());
					}
					if(isCon(statisticsData.getS_logic_id())){
						querySql += " and LogicId= " + toSqlVal(statisticsData.getS_logic_id());
					}
					//物理区域
					if(Util.isCon(statisticsData.getS_physical_id())){
						querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
					}
					querySql += " group by p_month,p_day  ";
					
				querySql += " union  ";
	
					querySql += " select date_format(psl.inTime,'%Y-%m') as p_month,  date_format(psl.inTime,'%Y-%m-%d') as p_day,  ";
					querySql += " count(putOut) as in_times ,0 as out_times, ";
					querySql += " (sum(hour(now())-hour(inTime))*60+sum(minute(now())-minute(inTime))) as p_time  ";
					querySql += " from p_parkingspaceoperationlog psl  ";
					querySql += " left join p_parkingspace ps on psl.parkingSpaceId = ps.id  ";
					querySql += " where outTime is  null and  date_format(psl.inTime,'%Y-%m-%d') =date_format(now(),'%Y-%m-%d')  ";//取当天没出车的
					if(isCon(statisticsData.getS_spot_type())){
						querySql += " and ps.spotType= " + toSqlVal(statisticsData.getS_spot_type());
					}
					if(isCon(statisticsData.getS_logic_id())){
						querySql += " and LogicId= " + toSqlVal(statisticsData.getS_logic_id());
					}
					//物理区域
					if(Util.isCon(statisticsData.getS_physical_id())){
						querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
					}
					querySql += " group by p_month,p_day  ";

				querySql += " )  a  ";
				querySql += " group by p_month,p_day  ";
			}
			
		}
		return querySql;
	}
	/**
     * Description :查询统计 出入车总数． 当天
     * @param  :statisticsData,
     * @param  :type  出入车类别
     * @return :String
     */
	public String today_list(ParkingStatisticsData statisticsData,String type) {
		String querySql = "";
		Log.log(statisticsData.getS_type());
		Log.log(statisticsData.getS_physical_id());
		if(statisticsData.getS_type().equals("day")){
			if(type.equals("in")){//查入车总数的
				querySql += "select p_day,p_hour,sum(in_times) as in_times   ";
				querySql += "  from (  ";
				querySql += " select date_format(psh.inTime,'%Y-%m-%d') AS p_day,hour(psh.inTime) AS p_hour,psh.spotType AS spotType, ";
				querySql += " count(psh.inTime) AS in_times,ps.logicId AS logicId ,ps.physicalRegionId  ";
				querySql += " from (p_parkingspaceoperationlog psh  ";
				querySql += " left join p_parkingspace ps on((psh.parkingSpaceId = ps.id)))  ";
				querySql += " where (psh.inTime is not null) ";
				querySql += " group by hour(psh.inTime),date_format(psh.inTime,'%Y-%m-%d'),psh.spotType,ps.logicId  ";
				querySql += " order by date_format(psh.inTime,'%Y-%m-%d'),hour(psh.inTime)  ";
				querySql += ") a ";
				querySql += " where 1=1  ";
				if(isCon(statisticsData.getS_b_date())){
					querySql += " and p_day>= " + toSqlVal(statisticsData.getS_b_date());
				}
				if(isCon(statisticsData.getS_e_date())){
					querySql += " and p_day<= " + toSqlVal(statisticsData.getS_e_date());
				}
				if(isCon(statisticsData.getS_spot_type())){
					querySql += " and spotType= " + toSqlVal(statisticsData.getS_spot_type());
				}
				if(isCon(statisticsData.getS_logic_id())){
					querySql += " and logicId= " + toSqlVal(statisticsData.getS_logic_id());
				}
				//物理区域
				if(Util.isCon(statisticsData.getS_physical_id())){
					querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
				}
				querySql+= " group by p_day,p_hour ";
			}
			if(type.equals("out")){//出车
				querySql += "select p_day,p_hour,sum(out_times) as out_times     ";
				querySql += " from ( ";
				querySql += " select date_format(psh.outTime,'%Y-%m-%d') AS p_day,hour(psh.outTime) AS p_hour,psh.spotType AS spotType, ";
				querySql += " count(psh.outTime) AS out_times,ps.logicId AS logicId ,ps.physicalRegionId  ";
				querySql += " from (p_parkingspaceoperationlog psh  ";
				querySql += " left join p_parkingspace ps on((psh.parkingSpaceId = ps.id)))  ";
				querySql += " where (psh.outTime is not null)   ";
				querySql += " group by hour(psh.outTime),date_format(psh.outTime,'%Y-%m-%d'),psh.spotType,ps.logicId   ";
				querySql += " order by date_format(psh.outTime,'%Y-%m-%d'),hour(psh.outTime)   ";
				querySql += " ) a  ";
				querySql += " where 1=1  ";
				if(isCon(statisticsData.getS_b_date())){
					querySql += " and p_day>= " + toSqlVal(statisticsData.getS_b_date());
				}
				if(isCon(statisticsData.getS_e_date())){
					querySql += " and p_day<= " + toSqlVal(statisticsData.getS_e_date());
				}
				if(isCon(statisticsData.getS_spot_type())){
					querySql += " and spotType= " + toSqlVal(statisticsData.getS_spot_type());
				}
				if(isCon(statisticsData.getS_logic_id())){
					querySql += " and logicId= " + toSqlVal(statisticsData.getS_logic_id());
				}
				//物理区域
				if(Util.isCon(statisticsData.getS_physical_id())){
					querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
				}
				querySql+= " group by p_day,p_hour ";
			}
			if(type.equals("used")){//当天使用率  
				//其中p_in_hour_time 是指入车时间的分钟数； a.hh_type 值 1：代表出车时间和入车时间在同一小时段内；0：代表出车时间和入车时间不在同一小时段内
				querySql+="select  a.p_day,  p_in_hour_time,a.p_hour,psh.a.spotType AS spotType,  p_time , ps.logicId,ps.physicalRegionId,a.hh_type,a.p_out_hour,a.p_out_minute ";
				querySql+=" from (  ";
				querySql+=" select date_format(psh.inTime,'%Y-%m-%d') AS p_day,  ";
				querySql+=" 0 AS p_in_hour_time,hour(psh.inTime) AS p_hour,psh.spotType AS spotType, ";
				querySql+=" psh.parkingSpaceId AS parkingSpaceId,  ";
				querySql+=" (minute(psh.outTime) - minute(psh.inTime)) AS p_time,'1' AS hh_type,   ";
				querySql+=" hour(psh.outTime) AS p_out_hour, ";
				querySql+=" minute(psh.outTime) AS p_out_minute ";
				querySql+=" from p_parkingspaceoperationlog psh  ";
				querySql+=" where ((psh.inTime is not null) and (psh.outTime is not null) and (hour(psh.inTime) = hour(psh.outTime)))  ";
				querySql+="union  ";
				querySql+=" select date_format(psh.inTime,'%Y-%m-%d') AS p_day,0 AS p_in_hour_time,hour(psh.inTime) AS p_hour,  ";
				querySql+=" psh.spotType AS spotType,psh.parkingSpaceId AS parkingSpaceId, ";
				querySql+=" (minute(now()) - minute(psh.inTime)) AS p_time,'1' AS hh_type,	  ";
				querySql+="  hour(now()) AS p_out_hour, ";
				querySql+="  minute(now()) AS p_out_minute ";
				querySql+="  from p_parkingspaceoperationlog psh  ";
				querySql+="  where ((psh.inTime is not null) and isnull(psh.outTime) and (hour(psh.inTime) = hour(now())))  ";
				querySql+="union ";
				querySql+="  select date_format(psh.inTime,'%Y-%m-%d') AS p_day,minute(psh.inTime) AS p_in_hour_time, ";
				querySql+="  hour(psh.inTime) AS p_hour,psh.spotType AS spotType,psh.parkingSpaceId AS parkingSpaceId, ";
				querySql+="  (((hour(psh.outTime) - hour(psh.inTime)) * 60) + (minute(psh.outTime) - minute(psh.inTime))) AS p_time, '0' AS hh_type,  ";
				querySql+="  hour(psh.outTime) AS p_out_hour, ";
				querySql+="  minute(psh.outTime) AS p_out_minute ";
				querySql+="  from p_parkingspaceoperationlog psh ";
				querySql+="  where ((psh.inTime is not null) and (psh.outTime is not null) and (hour(psh.inTime) <> hour(psh.outTime))) ";
				querySql+="union  ";
				querySql+="  select date_format(psh.inTime,'%Y-%m-%d') AS p_day,minute(psh.inTime) AS p_in_hour_time, ";
				querySql+="  hour(psh.inTime) AS p_hour,psh.spotType AS spotType,psh.parkingSpaceId AS parkingSpaceId, ";
				querySql+="  (((hour(now()) - hour(psh.inTime)) * 60)+ (minute(now()) - minute(psh.inTime))) AS p_time,'0' AS hh_type, ";
				querySql+="  hour(now()) AS p_out_hour, ";
				querySql+="  minute(now()) AS p_out_minute ";
				querySql+="  from p_parkingspaceoperationlog psh ";
				querySql+="  where ((psh.inTime is not null) and isnull(psh.outTime) and (hour(psh.inTime) <> hour(now()))) ";
				querySql+=") a  ";
				querySql+=" left join p_parkingspace ps  on   a.parkingSpaceId  =  ps.id   ";
				querySql+=" where 1=1 ";
				if(isCon(statisticsData.getS_b_date())){
					querySql += " and a.p_day>= " + toSqlVal(statisticsData.getS_b_date());
				}
				if(isCon(statisticsData.getS_e_date())){
					querySql += " and a.p_day<= " + toSqlVal(statisticsData.getS_e_date());
				}
				if(isCon(statisticsData.getS_spot_type())){
					querySql += " and a.spotType= " + toSqlVal(statisticsData.getS_spot_type());
				}
				if(isCon(statisticsData.getS_logic_id())){
					querySql += " and ps.logicId= " + toSqlVal(statisticsData.getS_logic_id());
				}
				//物理区域
				if(Util.isCon(statisticsData.getS_physical_id())){
					querySql += " and physicalRegionId = " + toSqlVal(statisticsData.getS_physical_id());
				}
			}
		}
		Log.log("类型"+type+"--"+querySql);
		return querySql;
	}

	/**
     * Description :获得所有车位的车位总数．
     * @param  :
     * @return :String
     */
	public String getAllSpaceNum(ParkingStatisticsData statisticsData) {
		String querySql = "";
		
		querySql += "select count(id) as all_space_num from p_parkingspace where 1=1 ";
		if(isCon(statisticsData.getS_spot_type())){
			querySql += " and spotType= " + toSqlVal(statisticsData.getS_spot_type());
		}
		if(isCon(statisticsData.getS_logic_id())){
			querySql += " and logicId= " + toSqlVal(statisticsData.getS_logic_id());
		}
		Log.log("getAllSpaceNum-------------:"+querySql);
		return querySql;
	}

	/**
     * Description :获得逻辑区域．
     * @param  :
     * @return :String
     */
	public String getLogicRegionCode() {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_logicregion order  by name";
		
		return querySql;
	}


	public String queryForUse(ParkingStatisticsData data, int total) {
		String querySql = "select sum(ps.duration)/60/"+total+"/oppo as use_number,";
		if(data.getS_type().equals("year")){
			querySql += "month as name from p_parkingspacestatistics ps ";
		}else if(data.getS_type().equals("month")){
			querySql += "day as name from p_parkingspacestatistics ps ";
		}else if(data.getS_type().equals("day")){
			querySql += "hour as name from p_parkingspacestatistics ps ";
		}
		querySql += " where 1=1 ";
		if(Util.isCon(data.getS_logic_id()))
			querySql += " and maplogicregionId = " + Util.toSqlVal(data.getS_logic_id());
		if(Util.isCon(data.getS_spot_type()))
			querySql += " and spotType = " + Util.toSqlVal(data.getS_spot_type());
		
		if(data.getS_type().equals("year")){
			querySql += " and year = " + Util.toSqlVal(data.getS_year()) ;
			querySql += " group by month ";
			querySql = querySql.replace("oppo", "288");
		}else if(data.getS_type().equals("month")){
			querySql += " and year = " + Util.toSqlVal(data.getS_year()) ;
			querySql += " and month = " + Util.toSqlVal(data.getS_month()) ;
			querySql += " group by day ";
			querySql = querySql.replace("oppo", "24");
		}else if(data.getS_type().equals("day")){
			String date = data.getS_date();
			System.out.println("--------"+date);
			querySql += " and year = " + Util.toSqlVal(date.substring(0, 4)) ;
			querySql += " and month = " + Util.toSqlVal(date.substring(5, 7)) ;
			querySql += " and day = " + Util.toSqlVal(date.substring(8, 10)) ;
			querySql += " group by hour ";
			querySql = querySql.replace("oppo", "1");
		}
		Log.log("占有率--"+querySql);
		return querySql;
	}


	public String queryForChart(ParkingStatisticsData data) {
		String querySql = "select sum(ps.inCount) as use_number, sum(ps.outCount) as use_number_2,";
		if(data.getS_type().equals("year")){
			querySql += "month as name from p_parkingspacestatistics ps ";
		}else if(data.getS_type().equals("month")){
			querySql += "day as name from p_parkingspacestatistics ps ";
		}else if(data.getS_type().equals("day")){
			querySql += "hour as name from p_parkingspacestatistics ps ";
		}
		querySql += " where 1=1 ";
		if(Util.isCon(data.getS_logic_id()))
			querySql += " and maplogicregionId = " + Util.toSqlVal(data.getS_logic_id());
		if(Util.isCon(data.getS_spot_type()))
			querySql += " and spotType = " + Util.toSqlVal(data.getS_spot_type());
		if(data.getS_type().equals("year")){
			querySql += " and year = " + Util.toSqlVal(data.getS_year()) ;
			querySql += " group by month ";
		}else if(data.getS_type().equals("month")){
			querySql += " and year = " + Util.toSqlVal(data.getS_year()) ;
			querySql += " and month = " + Util.toSqlVal(data.getS_month()) ;
			querySql += " group by day ";
		}else if(data.getS_type().equals("day")){
			String date = data.getS_date();
			System.out.println("--------"+date);
			querySql += " and year = " + Util.toSqlVal(date.substring(0, 4)) ;
			querySql += " and month = " + Util.toSqlVal(date.substring(5, 7)) ;
			querySql += " and day = " + Util.toSqlVal(date.substring(8, 10)) ;
			querySql += " group by hour ";
		}
		Log.log("月年-----"+querySql);
		return querySql;
	}
	public String getPhysicalRegionCode() {
		String querySql = "";
		
		querySql += "select id as code_id,physicalRegionName as code_name from p_physicalregion ";
		querySql += " where status = 1 ";
		
		return querySql;
	}
	public String getLogicRegionCode(String parameter) {
		String querySql = "";
		
		querySql += "select id as code_id,name as code_name from p_logicregion ";
			querySql += " where physicalRegionId = " + Util.toSqlVal(parameter);
		
		return querySql;
	}
	
	/**
	 * 当天数据
	 * @param data
	 * @return
	 */
	public String getTodaySql(ParkingStatisticsData data) {
		String querySql = "select intime,outtime,putout from p_parkingspaceoperationlog p " +
				" inner join p_parkingspace pp on p.parkingspaceid=pp.id " +
				" inner join p_logicregion pl on pp.physicalRegionId = pl.physicalRegionId where 1=1 ";
		
		//逻辑区域
		if(Util.isCon(data.getS_logic_id())){
			querySql += " and pl.id = " +  toSqlVal(data.getS_logic_id());
		}
		//物理区域
		if(Util.isCon(data.getS_physical_id())){
			querySql += " and pp.physicalRegionId = " + toSqlVal(data.getS_physical_id());
		}
		//车位类型
		if(Util.isCon(data.getS_spot_type())){
			querySql += " and pp.spottype = " + toSqlVal(data.getS_spot_type());
		}
		return querySql;
	}
	
	/**
	 * @param data
	 * @return
	 */
	public String putOutSql(ParkingStatisticsData data) {
		String querySql = "select sum(putout) from p_parkingspaceoperationlog p " +
			" inner join p_parkingspace pp on p.parkingspaceid=pp.id " +
			" inner join p_logicregion pl on pp.physicalRegionId = pl.physicalRegionId where 1=1 ";
//			"  where 1=1 ";
		
		//逻辑区域
		if(Util.isCon(data.getS_logic_id())){
			querySql += " and pl.id = " +  toSqlVal(data.getS_logic_id());
		}
		//物理区域
		if(Util.isCon(data.getS_physical_id())){
			querySql += " and pp.physicalRegionId = " + toSqlVal(data.getS_physical_id());
		}
		//车位类型
		if(Util.isCon(data.getS_spot_type())){
			querySql += " and pp.spottype = " + toSqlVal(data.getS_spot_type());
		}
		return querySql;
	}
	
	/**
	 * @param data
	 * @return
	 */
	public String putInSql(ParkingStatisticsData data) {
		String querySql = "select count(*) from p_parkingspaceoperationlog p " +
			" inner join p_parkingspace pp on p.parkingspaceid=pp.id " +
			" inner join p_logicregion pl on pp.physicalRegionId = pl.physicalRegionId " +
			" where SUBSTRING(intime,1,10)=curdate() ";
		
		//逻辑区域
		if(Util.isCon(data.getS_logic_id())){
			querySql += " and pl.id = " +  toSqlVal(data.getS_logic_id());
		}
		//物理区域
		if(Util.isCon(data.getS_physical_id())){
			querySql += " and pp.physicalRegionId = " + toSqlVal(data.getS_physical_id());
		}
		//车位类型
		if(Util.isCon(data.getS_spot_type())){
			querySql += " and pp.spottype = " + toSqlVal(data.getS_spot_type());
		}
		return querySql;
	}
	
	/**
	 * 获取当天的停车占有率原始数据
	 * @param statisticsData
	 * @return
	 */
	public String today_useddata(ParkingStatisticsData statisticsData,String currDate){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select hour(a.inTime) as p_hour, hour(a.outTime) as p_out_hour, minute(a.inTime) as p_in_hour_time, minute(a.outTime) as p_out_minute");
		querySql.append(" from");
		querySql.append(" ( select");
		querySql.append(" case when date(pl.inTime) < '").append(currDate).append("' then '").append(currDate).append(" 00:00:00'").append(" else pl.inTime end as inTime,");
		querySql.append(" case when isnull(pl.outTime) then now() else pl.outTime end as outTime");
		querySql.append(" from p_parkingspaceoperationlog pl left join p_parkingspace ps on pl.parkingSpaceId = ps.id where 1=1 ");
		if(isCon(statisticsData.getS_spot_type())){
			querySql.append(" and pl.spotType= '").append(statisticsData.getS_spot_type()).append("'");
		}
		if(isCon(statisticsData.getS_logic_id())){
			querySql.append(" and ps.logicId= '").append(statisticsData.getS_logic_id()).append("'");
		}
		if(isCon(statisticsData.getS_physical_id())){
			querySql.append(" and ps.physicalRegionId= '").append(statisticsData.getS_physical_id()).append("'");
		}
		querySql.append(" ) as a");
		String sql = querySql.toString();
		Log.log(sql);
		return sql;
	}
	
	/**
	 * 月查询数据
	 * @param statisticsData
	 * @return
	 */
	public String month_useddata(ParkingStatisticsData statisticsData){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select concat(year,'-',month,'-',day) as p_day, hour as p_hour,sum(inCount) as in_times,");
		querySql.append(" sum(outCount) as out_times  ,sum(duration) as p_time");
		querySql.append(" from p_parkingspacestatistics ps  where 1=1");
		if(isCon(statisticsData.getS_b_date())){
			querySql.append(" and concat(ps.year,'-',ps.month,'-',ps.day) >= ").append(toSqlVal(statisticsData.getS_b_date()));
		}
		if(isCon(statisticsData.getS_e_date())){
			querySql.append(" and concat(ps.year,'-',ps.month,'-',ps.day) <= ").append(toSqlVal(statisticsData.getS_e_date()));
		}
		if(isCon(statisticsData.getS_spot_type())){
			querySql.append(" and ps.spotType= ").append(toSqlVal(statisticsData.getS_spot_type()));
		}
		if(isCon(statisticsData.getS_logic_id())){
			querySql.append(" and mapLogicRegionId= ").append(toSqlVal(statisticsData.getS_logic_id()));
		}
		//物理区域
		if(Util.isCon(statisticsData.getS_physical_id())){
			querySql.append(" and physicalRegionId = ").append(toSqlVal(statisticsData.getS_physical_id()));
		}
		querySql.append(" group by p_day,p_hour ");
		String sql = querySql.toString();
		Log.log(sql);
		return sql;
	}
	
	public String year_useddata(ParkingStatisticsData statisticsData, String currDate){
		StringBuffer querySql = new StringBuffer();		
		querySql.append("select  concat(year,'-',month) as p_month,concat(year,'-',month,'-',day) as p_day,sum(inCount) as in_times,");
		querySql.append(" sum(outCount) as out_times ,sum(duration) as p_time");
		querySql.append(" from p_parkingspacestatistics ps  where 1=1");
		if(isCon(statisticsData.getS_year())){//应该是必须有值的
			querySql.append(" and year like '%").append(statisticsData.getS_year()).append("%'");
		}
		if(isCon(statisticsData.getS_spot_type())){
			querySql.append(" and ps.spotType= ").append(toSqlVal(statisticsData.getS_spot_type()));
		}
		if(isCon(statisticsData.getS_logic_id())){
			querySql.append(" and mapLogicRegionId= ").append(toSqlVal(statisticsData.getS_logic_id()));
		}
		//物理区域
		if(Util.isCon(statisticsData.getS_physical_id())){
			querySql.append(" and physicalRegionId = ").append(toSqlVal(statisticsData.getS_physical_id()));
		}
		querySql.append(" group by p_month,p_day");
		
		if(isCon(statisticsData.getS_year()) && statisticsData.getS_year().equals(currDate.substring(0, 5))){//当年的话 取当天数据
			querySql.append(" union select");			
			querySql.append(" date_format(a.inTime,'%Y-%m') as p_month,");
			querySql.append(" date_format(a.inTime,'%Y-%m-%d')as p_day,");
			querySql.append(" sum(a.putOut) as in_times,");
			querySql.append(" sum(a.putOut) as out_times,");
			querySql.append(" (sum(hour(a.outTime)-hour(a.inTime))*60+sum(minute(a.outTime)-minute(a.inTime))) as p_time");
			querySql.append(" from");
			querySql.append(" ( select case when date(pl.inTime) < '").append(currDate).append("' then '").append(currDate).append(" 00:00:00'").append(" else pl.inTime end as inTime,");
			querySql.append(" case when isnull(pl.outTime) then now() else pl.outTime end as outTime,");
			querySql.append(" pl.putOut as putOut");
			querySql.append(" from p_parkingspaceoperationlog pl left join p_parkingspace ps on pl.parkingSpaceId = ps.id where 1=1 ");
			if(isCon(statisticsData.getS_spot_type())){
				querySql.append(" and pl.spotType= '").append(statisticsData.getS_spot_type()).append("'");
			}
			if(isCon(statisticsData.getS_logic_id())){
				querySql.append(" and ps.logicId= '").append(statisticsData.getS_logic_id()).append("'");
			}
			if(isCon(statisticsData.getS_physical_id())){
				querySql.append(" and ps.physicalRegionId= '").append(statisticsData.getS_physical_id()).append("'");
			}
			querySql.append(" ) as a");
			querySql.append(" group by p_month,p_day");
		}
		String sql = querySql.toString();
		Log.log(sql);
		return sql;
	}
	
	public String get_realday_fromlog(){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select max(date(inTime)) as inTime, max(date(outTime)) as outTime from p_parkingspaceoperationlog where 1=1");
		return querySql.toString();
	}
	
	public String get_date_fromhis(){
		StringBuffer querySql = new StringBuffer();
		querySql.append("select max(date(outTime)) from p_parkingspaceoperationhis where 1=1");
		return querySql.toString();
	}
}
