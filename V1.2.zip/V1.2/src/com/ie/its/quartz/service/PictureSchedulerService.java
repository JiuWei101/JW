package com.ie.its.quartz.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Properties;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;
import com.ie.its.inversionsearch.ParkingData;

/**
 * 定时清除保存期以外的
 * @author mo
 */
@SuppressWarnings("rawtypes")
@Service
public class PictureSchedulerService extends ExtendService {
	
	/** 修改为直接按日期删除文件夹  --by mingm*/
	@SuppressWarnings("unchecked")
	@Scheduled(cron = "0 */2 * * * ?")
	public void work(){
		try {
			
		
		String dateParam = getDateParam("dateParam");
		String filePath = "/usr/its/";
		
		if(!"".equals(dateParam)){
			String curDate = DateUtil.getCurDate();
			String delDate = DateUtil.getNextDay(curDate, "-"+dateParam);
			
			for (int i = 0; i < 10; i++) {
				filePath = filePath + convertStr(delDate);
				
				File file = new File(filePath);
				Log.log("File: " + file);
				if(file.exists() && file.isDirectory()){
					deleteDir(file);
				} else {
					break;
				}
				
				delDate = DateUtil.getNextDay(delDate, "-1");
			}
		}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private static ArrayList<String> listPicturePath = null;			//用于保存p_parkingspace里的图片路径,删除的图片如果在这个表里就不删除
//	
//	/**
//	 * 定时执行清除图片的任务,设置执行时间为每12小时执行一次
//	 */
//	@SuppressWarnings("unchecked")
//	@Scheduled(cron = "0 0 */23 * * ?")
//	public void work() {
//		JdbcTemplateExtend jdbc = new JdbcTemplateExtend(getDataSource());
//		String dateParam = getDateParam("dateParam");
//		if(!"".equals(dateParam)){
//			Long day = getLongParam(dateParam);
//			if(day > 0){
//				Date now = new Date();
//				Long l = now.getTime() - (day * 24 * 60 * 60 * 1000L);
//				String format = Util.sdfDate.format(new Date(l));
//				StringBuilder sb = new StringBuilder(format);
//				sb.append(" 00:00:00");
//				System.out.println("DeleteTime: " + sb);
//				StringBuilder selectSql = new StringBuilder();
//				//查出所有符合条件的车的记录
//				selectSql.append("SELECT his.id as psid, his.inTime as inTime, his.outTime as outTime, his.plateno as carNum, his.picturepath as carSrc FROM p_parkingspaceoperationhis as his WHERE his.inTime < ")
//							.append(Util.toSqlVal(sb.toString())).append(" and his.picturepath!=''");
//				Log.log("\n[" + selectSql + "]");
//				ArrayList<ParkingData> pdList = (ArrayList<ParkingData>) jdbc.queryForListExt(selectSql.toString(), ParkingData.class);
//				
//				String sqlAllPicturePath = "SELECT picturepath FROM p_parkingspace WHERE picturepath != ''";
//				listPicturePath = (ArrayList<String>) jdbc.queryForList(sqlAllPicturePath, String.class);
//
//				for(ParkingData pd : pdList){	//遍历所有查询结果的文件
//					String carSrc = pd.getCarSrc();
//					String updateSql = removeFile(carSrc, pd.getPsid());
//					if(!"".equalsIgnoreCase(updateSql)){			//如果没有就不操行更新操作
//						Log.log("图片清除后更新的数据库语句: " + updateSql);
//						jdbc.execute(updateSql);
//					}
//				}
//			}
//		}
//		listPicturePath = null;
//		
//	}
	
	/**
	 * 将字符串转成
	 * @param param
	 * @return
	 */
	public Long getLongParam(String param){
		Long day = 0L;
		try{
			day = Long.parseLong(param);
		} catch(Exception e){
			day = 0L;
		}
		return day;
	}
	
	/**
	 * 获取配置文件config.properties下指定KEY的e
	 * @return
	 */
	public String getDateParam(String param){
		FileInputStream fis = null;
		String dateParam = "";
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + "config.properties");
			Properties prop = new Properties();
			prop.load(fis);
			dateParam = prop.getProperty(param);
		} catch (URISyntaxException e) {
			Log.log("获取path失败============>" + e);
		} catch (FileNotFoundException e) {
			Log.log("读取config.properties失败=====>" + e);
		} catch (IOException e) {
			Log.log("加载config.properties失败=====>" + e);
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return dateParam;
	}
//	
//	/**
//	 * 删除文件并更新数据库记录.将图片置为空
//	 * @param filePath
//	 * @param listPicturePath 
//	 * @return
//	 */
//	public String removeFile(String filePath, String id){
//		if(id != null && !"".equalsIgnoreCase(id)){	//如果没有ＩＤ就返回 "",不做任何处理
//			StringBuilder updateSql = new StringBuilder();		//清除数据库记录里的图片
//			updateSql.append("update p_parkingspaceoperationhis set picturepath='' where id=").append(Util.toSqlVal(id));
//			System.out.println("FilePath: " + filePath);
//			String[] filePaths = filePath.split("/");
//			int len = filePaths.length;						// 获取分隔的长度
//			//如果文件夹深度大于5且中间包含月和日
//			if(filePaths.length > 5 && filePaths[len - 4].length() <= 2 && filePaths[len - 3].length() <= 2){
//				String url = filePath.substring(0, filePath.indexOf(filePaths[len - 2]));
//				File file = new File(url);
//				System.out.println("File: " + file);
//				if(file.isDirectory() && file.exists()){
//					deleteDir(file);
//				}
//			}
//			return updateSql.toString();
//		} else{
//			return "";
//		}
//	}
	
	/**
	 * 递归删除目录下的所有文件及子目录下所有文件
	 * @param dir 将要删除的文件目录
	 * @return 
	 */
	private boolean deleteDir(File dir){
		if(dir.isDirectory()){
			String[] children = dir.list();
			//递归删除目录中的子目录
			for(int i = 0; i < children.length; i++){
				deleteDir(new File(dir, children[i]));
			}
			dir.delete();
			return true;
		} 
//		else if (listPicturePath.contains(dir.toString())){			//如果该车没出车就不删除图片
//			return true;
//		} 
		else{
			//目录为空时,可以删除
//			Log.log("正在删除的文件/目录: " + dir);
			return dir.delete();
		}
	}
	
	/**
	 * 将日期格式转换为文件夹格式
	 */
	public String convertStr(String dateStr) {
		dateStr = dateStr.replace("-", "/");
		return dateStr;
	}
}
