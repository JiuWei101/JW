package com.ie.its.quartz.service;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.ie.common.CommonUtil;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;

@Service
public class FreeParkingUploadService extends ExtendService{
	
	public static Socket socket = null;
	
	/**
	 * 获取单例的socket
	 * @return
	 */
	public Socket getInstance(){
		if(socket == null || socket.isClosed()){
			OperatePro op = new OperatePro();
			try {
				String address = op.queryProperty("uploadDataAddress");
				String portStr = op.queryProperty("uploadDataPort");
				int port = Integer.parseInt(portStr == null ? "0" : portStr);
				socket = new Socket(address, port);
				socket.setSoTimeout(1000 * 20);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				Log.log(e.getMessage());
				return null;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Log.log(e.getMessage());
				return null;
			}
		}
		return socket;
	}
	
	/**
	 * 数据上报
	 */
	//@Scheduled(cron = "0/60 * * * * ?")
	public void work() {
		// TODO Auto-generated method stub
		if(getInstance() != null){			//每次执行之前看能不能连上服务器
			OperatePro op = new OperatePro();
			JdbcTemplateExtend jdbc = new JdbcTemplateExtend(getDataSource());
			//查询VIP总数
			String vipSql = "select count(*) as vipCount from p_parkingspace where spotTypeNow=1;";
			//查询VIP占用数
			String vipInuseSql = "select count(*)-(select count(*) from p_parkingspace where spotTypeNow=1 and inuse=1) as vipInuse from p_parkingspace where spotTypeNow=1;";
			//查询总车位数
			String countSql = "select count(*) as nCount from p_parkingspace;";
			//查询总车位占用数
			String countInuseSql = "select count(*)-(select count(*) from p_parkingspace where inuse=1) as Inuse from p_parkingspace;";
			int vipCount = jdbc.queryForInt(vipSql);
			int vipInuseCount = jdbc.queryForInt(vipInuseSql);
			int countCount = jdbc.queryForInt(countSql);
			int countInuseCount = jdbc.queryForInt(countInuseSql);
			String parkString = CommonUtil.concatenateParkString(vipCount, vipInuseCount, countCount,
					countInuseCount, op.queryProperty("parkId"));
			byte[] sendData = CommonUtil.hexStr2ByteArray(CommonUtil.concatenateDTUString(parkString.toUpperCase(), op.queryProperty("DEVICE_ID")));
			OutputStream os = null;
			try {
				os = socket.getOutputStream();
				Log.log("数据上传的格式为: VIP总数: " + vipCount + ", VIP占用总数: " + vipInuseCount + ", 车位总数: " + countCount + ", 车位占用总数: " + countInuseCount);
				os.write(sendData, 0, sendData.length);
				os.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Log.log(e.getMessage());
				closeSocket();
			}
		}
	}
	
	/**
	 * 异常情况下断开socket连接
	 */
	private void closeSocket() {
		// TODO Auto-generated method stub
		try {
			if(socket != null)
				socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.log(e.getMessage());
		}
	}
}
