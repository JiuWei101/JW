package com.ie.its.quartz.service;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationStance {

	private static ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	private static DataSource ds = null;
	public static DataSource getDataSource() {
		// TODO Auto-generated method stub
		if(ds == null){
			ds = (DataSource) context.getBean("dataSource");
		}
		return ds;
	}
}
