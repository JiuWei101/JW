/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.configguide;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.inifile.IniFileCreator;
import com.ie.its.physicalregion.PhysicalRegionData;
import com.ie.its.physicalregion.PhysicalRegionService;

//命名空间
@Namespace("/config_guide")
public class ConfigGuideAction extends ExtendActionSupport {
	
	private ConfigGuideData data;
	@Autowired
	private ConfigGuideService configGuideService;
	
	public ConfigGuideData getData() {
		return data;
	}
	public void setData(ConfigGuideData data) {
		this.data = data;
	}
	public ConfigGuideAction(){
		if(data == null){
			data = new ConfigGuideData();
		}
	}
	/**
     * Description :查询物理区域．
     * @throws :Exception
     */
	@Action(value="config_guide",results={@Result(name="success",location="/config_guide/config_guide.jsp")})
	public String config_guide(){
		setLang(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		configGuideService.setStep(data);
		return SUCCESS;
	}

}
