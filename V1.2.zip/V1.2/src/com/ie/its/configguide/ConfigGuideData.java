/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.configguide;

import java.util.List;

import com.ie.frame.ExtendData;
import com.ie.its.physicalregion.PhysicalRegionData;

public class ConfigGuideData extends ExtendData{
	private String step;		//第几步
	private String nextStep;	//下一步名称
	private String stepName;	//当前步骤名称
	private String frameSrc;	//当前步骤URL

	/**
	 * @return the step
	 */
	public String getStep() {
		return step;
	}

	/**
	 * @param step the step to set
	 */
	public void setStep(String step) {
		this.step = step;
	}

	/**
	 * @return the nextStep
	 */
	public String getNextStep() {
		return nextStep;
	}

	/**
	 * @param nextStep the nextStep to set
	 */
	public void setNextStep(String nextStep) {
		this.nextStep = nextStep;
	}

	/**
	 * @return the stepName
	 */
	public String getStepName() {
		return stepName;
	}

	/**
	 * @param stepName the stepName to set
	 */
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	/**
	 * @return the frameSrc
	 */
	public String getFrameSrc() {
		return frameSrc;
	}

	/**
	 * @param frameSrc the frameSrc to set
	 */
	public void setFrameSrc(String frameSrc) {
		this.frameSrc = frameSrc;
	}
}
