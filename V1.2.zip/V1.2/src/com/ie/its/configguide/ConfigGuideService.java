/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.configguide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.CodeData;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.inifile.IniFileCreator;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class ConfigGuideService extends ExtendService {

	/**
	 * @param data
	 */
	public void setStep(ConfigGuideData data) {
		if(!Util.isCon(data.getStep())){
			data.setStep("0");
		}
		HashMap snMap = (HashMap) data.getCurrent_lang_switch().get("guide_step_name"); 
		HashMap fsMap = (HashMap) data.getCurrent_lang_switch().get("guide_frame_src"); 
		data.setStepName((String) snMap.get(data.getStep()));
		data.setNextStep((String) snMap.get(String.valueOf((Integer.parseInt(data.getStep()) + 1))));
		data.setFrameSrc((String) fsMap.get(data.getStep()));
	}
	
}
