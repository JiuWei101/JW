/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-屏参数值配置
 * Version                  : 1.0
 * create date              : 2012.3.10
 * author                   : heliang
 */
package com.ie.its.screenparavalueconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class ScreenParaValueConfigData extends ExtendData{
	

	private String id;					//探测器id
	private String valueId;				//参数id
	private String screenId;			//屏id
	private String screenCode;			//屏编码
	private String screenTypeParaId;	//屏类型参数id
	private String screenTypeParaName;	//屏类型参数名
	private String screenTypeParaCode;	//屏类型参数编码
	private String value;				//取值
	private String remark;				//备注
	private List screenList;			//引导屏列表
	private List screenTypeParaList;	//屏类型参数列表
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getValueId() {
		return valueId;
	}
	public void setValueId(String valueId) {
		this.valueId = valueId;
	}
	public String getScreenId() {
		return screenId;
	}
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	public String getScreenCode() {
		return screenCode;
	}
	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}
	public String getScreenTypeParaId() {
		return screenTypeParaId;
	}
	public void setScreenTypeParaId(String screenTypeParaId) {
		this.screenTypeParaId = screenTypeParaId;
	}
	public String getScreenTypeParaName() {
		return screenTypeParaName;
	}
	public void setScreenTypeParaName(String screenTypeParaName) {
		this.screenTypeParaName = screenTypeParaName;
	}
	public String getScreenTypeParaCode() {
		return screenTypeParaCode;
	}
	public void setScreenTypeParaCode(String screenTypeParaCode) {
		this.screenTypeParaCode = screenTypeParaCode;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public List getScreenList() {
		return screenList;
	}
	public void setScreenList(List screenList) {
		this.screenList = screenList;
	}
	public List getScreenTypeParaList() {
		return screenTypeParaList;
	}
	public void setScreenTypeParaList(List screenTypeParaList) {
		this.screenTypeParaList = screenTypeParaList;
	}
	

}
