package com.ie.its.screenparavalueconfig;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.screentypeparaconfig.ScreenTypeParaConfigData;

public class ScreenParaValueConfigSql extends ExtendSql{
	/**
     * Description :查询屏参数值．
     * @param  :ScreenParaValueConfigData,String
     * @return :String
     */
	public String screenparavalue_list(ScreenParaValueConfigData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select spv.id as valueId,spv.screenId,scr.code as screenCode,spv.screenTypeParaId as screenTypeParaId,stp.name as screenTypeParaName,stp.code as screenTypeParaCode,spv.value,spv.describes as remark ";
		}
		
		querySql += " from p_screenparavalue spv inner join p_screen scr on spv.screenId=scr.id inner join p_screentypepara stp on spv.screenTypeParaId=stp.id ";
		querySql += " where 1=1 ";
		
		return querySql;
	}
	
	/**
     * Description :获得屏参数值信息．
     * @param  :ScreenParaValueConfigData
     * @return :String
     */
	public String screenparavalue_get(ScreenParaValueConfigData data) {
		String querySql = "";
		
		querySql = "select spv.id as valueId,spv.screenId,scr.code as screenCode,spv.screenTypeParaId as screenTypeParaId,stp.name as screenTypeParaName,stp.code as screenTypeParaCode,spv.value,spv.describes as remark ";
		querySql += " from p_screenparavalue spv inner join p_screen scr on spv.screenId=scr.id inner join p_screentypepara stp on spv.screenTypeParaId=stp.id where spv.id=";
		
		querySql += Util.toSqlVal(data.getId());
		
		return querySql;
	}


	/**
     * Description :更新屏参数值信息．
     * @param  :ScreenParaValueConfigData
     * @return :String
     */
	public String screenparavalue_update(String screenId,String screenTypeParaId,String value,String remark,String valueId) {
		String updateSql = "";
		
		updateSql += "update p_screenparavalue set screenId=" + Util.toSqlVal(screenId);
		updateSql += ",screenTypeParaId=" + Util.toSqlVal(screenTypeParaId);
		updateSql += ",value=" + Util.toSqlVal(value);
		updateSql += ",describes=" + Util.toSqlVal(remark);
		updateSql += " where id =" + Util.toSqlVal(valueId);
		
		Log.log(updateSql);
		return updateSql;
	}	
	
	/**
     * Description :保存屏类型信息．
     * @param  :ScreenParaValueConfigData
     * @return :String
     */
	public String screenparavalue_save(ScreenParaValueConfigData data,String type) {
		String saveSql = "";
		Log.log("hhhh"+data.getValueId()+"|"+data.getScreenId()+"|"+data.getScreenTypeParaId()+"|"+data.getValue()+"|"+data.getRemark());
		if (type.equals("create")){
			saveSql += "insert into p_screenparavalue(id,screenId,screenTypeParaId,value,describes)";
			saveSql +=" values(" + Util.toSqlVal(data.getValueId())+"," + Util.toSqlVal(data.getScreenId())+","+ Util.toSqlVal(data.getScreenTypeParaId())+"," + Util.toSqlVal(data.getValue())+","+ Util.toSqlVal(data.getRemark())+")";
		}else if (type.equals("edit")){
			saveSql += "update p_screenparavalue set screenId=" + Util.toSqlVal(data.getScreenId());
			saveSql += ",screenTypeParaId=" + Util.toSqlVal(data.getScreenTypeParaId());
			saveSql += ",value=" + Util.toSqlVal(data.getValue());
			saveSql += ",describes=" + Util.toSqlVal(data.getRemark());
			saveSql += " where id =" + Util.toSqlVal(data.getValueId());			
		}
		
		return saveSql;
	}	
	
	/**
     * Description :删除屏参数值信息．
     * @param  :ScreenParaValueConfigData
     * @return :String
     */
	public String screenparavalue_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screenparavalue where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	/**
     * Description :获取屏列表
     * @param  :
     * @return :String
     */
	public String get_screen() {
		String querySql = "";
		
		querySql += "select id as code_id,code as code_name from p_screen order by id";
		
		return querySql;
	}
	
	/**
     * Description :获取屏类型参数列表
     * @param  :
     * @return :String
     */
	public String get_screenTypePara(String screenId) {
		String querySql = "";
		
		querySql += "select stp.id as code_id,stp.name as code_name from p_screentypepara stp inner join p_screentype st on stp.screenType=st.code inner join p_screen scr on st.code=scr.screenTypeCode";
		querySql += " where scr.id=" + Util.toSqlVal(screenId) + " order by stp.id";
		
		return querySql;
	}
}
