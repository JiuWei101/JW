/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.3.10
 * author                   : heliang
 */
package com.ie.its.screenparavalueconfig;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;

//命名空间
@Namespace("/screenparavalue_config")
@Results({@Result(name="valuelist",location="/screen_config/screenparavalue_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="screenparavalue_list",location="list.action",type="redirect")})
public class ScreenParaValueConfigAction extends ExtendActionSupport {
	
	private ScreenParaValueConfigData data;
	@Autowired
	private ScreenParaValueConfigService screenparavalueService;
	
	public ScreenParaValueConfigData getData() {
		return data;
	}
	public void setData(ScreenParaValueConfigData data) {
		this.data = data;
	}
	public ScreenParaValueConfigAction(){
		if(data == null){
			data = new ScreenParaValueConfigData();
		}
	}
	/**
     * Description :查询屏参数值．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="screenparavalue_list",results={@Result(name="success",location="/screen_config/screenparavalue_list.jsp")})
	public String screenparavalue_list(){
		data = screenparavalueService.screenparavalue_list(data);
		
		//设置多语言
		setLang(data);
		//获得引导屏下拉框
		data.setScreenList(screenparavalueService.get_screen());
		data.setLang(request.getSession().getAttribute("lang").toString());
		//获得屏类型参数下拉框
		data.setScreenTypeParaList(screenparavalueService.get_screenTypePara(data));
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="screenparavalue_edit",results={@Result(name="valueedit",location="/screen_config/screenparavalue_edit.jsp")})
	public String screenparavalue_edit(){
		screenparavalueService.screenparavalue_get(data);
		
		//设置多语言
		setLang(data);

		return "valueedit";
	}
	
	@Action(value="screenparavalue_save",results={@Result(type="json")})
	public void screenparavalue_save(){		
		screenparavalueService.screenparavalue_save(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}

	@Action(value="screenparavalue_update",results={@Result(type="json")})
	public void screenparavalue_update(){		
		screenparavalueService.screenparavalue_update(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}
	
	@Action(value="screenparavalue_delete",results={@Result(type="json")})
	public void screenparavalue_delete(){		
		System.out.println(data.getId());
		screenparavalueService.screenparavalue_delete(data);
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		setJsonRes(json);
	}
	
	@Action(value="screenparavalue_get",results={@Result(type="json")})
	public void screenparavalue_get(){
//		System.out.println("haha:"+data.getScreenId());
		//获得屏类型参数下拉框
		if(data.getScreenId().isEmpty()){
			data.setScreenId("null");
		}
		data.setScreenTypeParaList(screenparavalueService.get_screenTypePara(data));
		
		JSONObject json =  new JSONObject();
		
		json.element("success", true);
		json.element("list", JSONArray.fromObject(data.getScreenTypeParaList()));
		setJsonRes(json);
		
		
	}
}
