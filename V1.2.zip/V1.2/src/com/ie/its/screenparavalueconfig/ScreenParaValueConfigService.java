/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-屏参数值配置
 * Version                  : 1.0
 * create date              : 2012.3.10
 * author                   : heliang
 */
package com.ie.its.screenparavalueconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.screentypeparaconfig.ScreenTypeParaConfigData;
@Scope("prototype")
@Service
public class ScreenParaValueConfigService extends ExtendService {
	private ScreenParaValueConfigSql screenparavalueSql;
	
	public ScreenParaValueConfigService(){
		screenparavalueSql = new ScreenParaValueConfigSql();
	}

	/**
     * Description :查询屏参数值．
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public ScreenParaValueConfigData screenparavalue_list(ScreenParaValueConfigData data) {
		//获得数量
		int count = this.getJt().queryForInt(screenparavalueSql.screenparavalue_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+screenparavalueSql.screenparavalue_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenParaValueConfigData>rows = this.getJt().<ScreenParaValueConfigData>queryForListExt(screenparavalueSql.screenparavalue_list(data, ""), 
				data.getStart(), data.getLimit(),ScreenParaValueConfigData.class);
		
		//转换编码
		for(ScreenParaValueConfigData tempData:rows){
			
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得屏参数值信息．
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public ScreenParaValueConfigData screenparavalue_get(ScreenParaValueConfigData data) {
		getJt().queryForObjectExt(screenparavalueSql.screenparavalue_get(data), data);
		return data;
	}
	
	/**
     * Description :更新屏参数值．
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public ScreenParaValueConfigData screenparavalue_update(ScreenParaValueConfigData data) {
		String[] valueId= data.getValueId().split(";");
		String screenId= data.getScreenId();
		String screenTypeParaId= data.getScreenTypeParaId();
		String value = data.getValue();
		String remark = data.getRemark();
		String [] sql = new String[valueId.length];
		
		for(int i = 0;i < valueId.length;i++){
			sql[i] = screenparavalueSql.screenparavalue_update(screenId,screenTypeParaId,value,remark,valueId[i]);
		}

		getJt().batchUpdate(sql);
		
		return data;
		
	}
	
	/**
     * Description :保存屏类型．
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public ScreenParaValueConfigData screenparavalue_save(ScreenParaValueConfigData data) {
		Log.log("hh:"+data.getValueId());
		if ((data.getValueId()==null)||(data.getValueId().equals(""))){
			data.setValueId(PrimaryId.getId());
			getJt().execute((screenparavalueSql.screenparavalue_save(data,"create")));		
		}else{
			getJt().execute((screenparavalueSql.screenparavalue_save(data,"edit")));
		}
		return data;
	}
	
	/**
     * Description :删除屏参数值．
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public ScreenParaValueConfigData screenparavalue_delete(ScreenParaValueConfigData data) {
		String[] valueId= data.getValueId().split(";");
		String [] sql = new String[valueId.length];
		for(int i = 0;i < valueId.length;i++){
			sql[i] = screenparavalueSql.screenparavalue_delete(valueId[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :获得屏列表
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public List get_screen() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenparavalueSql.get_screen(), ScreenParaValueConfigData.class);
		return codeList;
	}	
	/**
     * Description :获得屏参数类型list
     * @param  :ScreenParaValueConfigData
     * @return :ScreenParaValueConfigData
     * @throws :Exception
     */
	public List get_screenTypePara(ScreenParaValueConfigData data) {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screenparavalueSql.get_screenTypePara(data.getScreenId()), ScreenParaValueConfigData.class);
		return codeList;
	}		
}
