/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-通讯线路配置
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.lineconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
@Scope("prototype")
@Service
public class LineConfigService extends ExtendService {
	private LineConfigSql lineSql;
	
	public LineConfigService(){
		lineSql = new LineConfigSql();
	}

	/**
     * Description :查询通讯线路．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public LineConfigData line_list(LineConfigData data) {
		//获得数量
		int count = this.getJt().queryForInt(lineSql.line_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+lineSql.line_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <LineConfigData>rows = this.getJt().<LineConfigData>queryForListExt(lineSql.line_list(data, ""), 
				data.getStart(), data.getLimit(),LineConfigData.class);
		
		//转换编码
		for(LineConfigData tempData:rows){
			
			tempData.setStatus(DisposalCode.getCodeName(tempData.getStatus(), "status", this.getUserinfo().getLang()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得通讯线路信息．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public LineConfigData line_get(LineConfigData data) {
		getJt().queryForObjectExt(lineSql.line_get(data), data);
		return data;
	}
	
	/**
     * Description :保存通讯线路．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public LineConfigData line_save(LineConfigData data) {
		data.setId(PrimaryId.getId());
		//保存通讯线路
		getJt().execute(lineSql.line_save(data));
		//保存通讯线路参数
		data.setLineParamId(PrimaryId.getId());
		getJt().execute(lineSql.lineparam_save(data));

		return data;
		
	}
	
	/**
     * Description :更新通讯线路．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public boolean line_update(LineConfigData data) {
		String[] id= data.getId().split(";");
		String ip = data.getIp();
		String status = data.getStatus();
		String notes = data.getNotes();
		String lineParamId = data.getLineParamId();
		String boardNo = data.getBoardNo();
		String port = data.getPort();
		String stationAddr = data.getStationAddr();
		String baudRate = data.getBaudRate();
		String dataBits = data.getDataBits();
		String parity = data.getParity();
		String stopBits = data.getStopBits();
		String mask = data.getMask();
		String purpose = data.getPurpose();
		String describes = data.getDescribes();
		
		String [] sql = new String[id.length];
		String [] paramsql = new String[id.length];
		
		int queryForInt = getJt().queryForInt(lineSql.checkLine(data));
		Log.log("hehe"+queryForInt);
		if(queryForInt > 0 && data.getStatus().equals("0")){  //有管理器关联
			return false;
		}else{   //无关联
			for(int i = 0;i < id.length;i++){
				sql[i] = lineSql.line_update(ip,status,notes,id[i]);
				
				paramsql[i] = lineSql.lineparam_update(id[i],boardNo,port,stationAddr,baudRate,dataBits,parity,stopBits,mask,purpose,describes,lineParamId);
				
			}
			//更新通讯线路
			getJt().batchUpdate(sql);
			//更新通讯线路参数
			getJt().batchUpdate(paramsql);
	
			return true;
		}
		
	}
	
	/**
     * Description :批量更新通讯线路状态．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public LineConfigData line_allupdate(LineConfigData data) {
		
		getJt().execute(lineSql.line_allupdate(data));
		return data;
	}
	/**
     * Description :删除通讯线路．
     * @param  :LineData
     * @return :LineData
     * @throws :Exception
     */
	public LineConfigData line_delete(LineConfigData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		String [] paramsql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = lineSql.line_delete(id[i]);
			paramsql[i] = lineSql.lineparam_delete(id[i]);
		}
		//删除通讯线路
		getJt().batchUpdate(sql);
		//删除通讯线路参数
		getJt().batchUpdate(paramsql);
		return data;
	}

	public boolean readIsExits(LineConfigData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(lineSql.readExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean readIsAllocated(LineConfigData data) {//全部更新时检查是否有
		int queryForInt = getJt().queryForInt(lineSql.readAllocatedDao(data));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	
}
