package com.ie.its.lineconfig;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class LineConfigSql extends ExtendSql{
	/**
     * Description :查询通讯线路．
     * @param  :LineConfigData,String
     * @return :String
     */
	public String line_list(LineConfigData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select l.id,lp.id as lineParamId,l.ip,lp.boardNo,lp.port,lp.stationAddr,lp.baudRate,lp.dataBits,lp.parity,lp.stopBits,lp.mask,lp.purpose,lp.describes,l.status,l.notes ";
		}

		querySql += " from p_line l left join p_lineparam lp on l.id=lp.lineid ";
		querySql += " where 1=1 ";
		
		if(isCon(data.getIp())){
			querySql += " and l.ip like " + toSqlValLike(data.getIp(),"ALL");
		}
		if(isCon(data.getStatus())){
			querySql += " and l.status = " + toSqlVal(data.getStatus());
		}
		
		return querySql;
	}
	
	/**
     * Description :获得通讯线路信息．
     * @param  :LineConfigData
     * @return :String
     */
	public String line_get(LineConfigData data) {
		String querySql = "";
		
		querySql = "select  l.id,lp.id as lineParamId,l.ip,lp.boardNo,lp.port,lp.stationAddr,lp.baudRate,lp.dataBits,lp.parity,lp.stopBits,lp.mask,lp.purpose,lp.describes as lpnotes,l.status,l.notes ";
		querySql += " from p_line l left join p_lineparam lp on l.id=lp.lineid where l.id=";
		
		querySql += Util.toSqlVal(data.getId());
		
		return querySql;
	}

	/**
     * Description :保存通讯线路信息．
     * @param  :LineConfigData
     * @return :String
     */
	public String line_save(LineConfigData data) {
		
		String insertSql = "";
		
		insertSql += "insert into p_line(id,ip,status,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getIp()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
				
		return insertSql;
	}		

	/**
     * Description :保存通讯参数信息．
     * @param  :LineConfigData
     * @return :String
     */
	public String lineparam_save(LineConfigData data) {
		
		String insertSql = "";
		
		insertSql += "insert into p_lineparam(id,lineid,boardNo,port,stationAddr,baudRate,dataBits,parity,stopBits,mask,purpose,describes) values(";
		insertSql += Util.toSqlVal(data.getLineParamId()) + ",";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getBoardNo()) + ",";
		insertSql += Util.toSqlVal(data.getPort().equals("")? "0":data.getPort()) + ",";
		insertSql += Util.toSqlVal(data.getStationAddr()) + ",";
		insertSql += Util.toSqlVal(data.getBaudRate()) + ",";
		insertSql += Util.toSqlVal(data.getDataBits()) + ",";
		insertSql += Util.toSqlVal(data.getParity()) + ",";
		insertSql += Util.toSqlVal(data.getStopBits()) + ",";
		insertSql += Util.toSqlVal(data.getMask()) + ",";
		insertSql += Util.toSqlVal(data.getPurpose()) + ",";
		insertSql += Util.toSqlVal(data.getDescribes()) + ")";
				
		return insertSql;
	}	
	
	/**
     * Description :更新通讯线路信息．
     * @param  :String
     * @return :String
     */
	public String line_update(String ip,String status,String notes,String id) {
		String updateSql = "";
		
		updateSql += "update p_line set ip=" + Util.toSqlVal(ip);
		updateSql += ",status=" + Util.toSqlVal(status);
		updateSql += ",notes=" + Util.toSqlVal(notes);
		updateSql += " where id =" + Util.toSqlVal(id);
		
		return updateSql;
	}	

	/**
     * Description :更新通讯参数信息．
     * @param  :String
     * @return :String
     */
	public String lineparam_update(String lineid,String boardNo,String port,String stationAddr,String baudRate,String dataBits,String parity,String stopBits,String mask,String purpose,String describes,String id) {
		String updateSql = "";
		
		updateSql += "update p_lineparam set boardNo=" + Util.toSqlVal(boardNo);
		updateSql += ",port=" + Util.toSqlVal(port);
		updateSql += ",stationAddr=" + Util.toSqlVal(stationAddr);
		updateSql += ",baudRate=" + Util.toSqlVal(baudRate);
		updateSql += ",dataBits=" + Util.toSqlVal(dataBits);
		updateSql += ",parity=" + Util.toSqlVal(parity);
		updateSql += ",stopBits=" + Util.toSqlVal(stopBits);
		updateSql += ",mask=" + Util.toSqlVal(mask);
		updateSql += ",purpose=" + Util.toSqlVal(purpose);
		updateSql += ",describes=" + Util.toSqlVal(describes);
		updateSql += " where id =" + Util.toSqlVal(id) + " and lineid=" + Util.toSqlVal(lineid);
		
		return updateSql;
	}	
	
	/**
     * Description :全部更新通讯线路信息．
     * @param  :LineConfigData
     * @return :String
     */
	public String line_allupdate(LineConfigData data) {
		String updateSql = "";
		
		updateSql += "update p_line set status=" + Util.toSqlVal(data.getStatus());
		
		return updateSql;
	}
	/**
     * Description :删除通讯线路信息．
     * @param  :String
     * @return :String
     */
	public String line_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_line where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	/**
     * Description :删除通讯参数信息．
     * @param  :String
     * @return :String
     */
	public String lineparam_delete(String lineId) {
		String deleteSql = "";
		
		deleteSql += "delete from p_lineparam where lineid = " + Util.toSqlVal(lineId);;
		
		return deleteSql;
	}
	
	/**
	 * 检验当前的通讯线路是否有管理器关联
	 * @param data
	 * @return
	 */
	public String checkLine(LineConfigData data) {
		
		String querySql = " select count(*) from p_controller where lineId = " + Util.toSqlVal(data.getId());
		return querySql;
	}

	public String readExitsDao(LineConfigData data, String type) {
		String querySql = "select count(*) count from p_line where ip = " + toSqlVal(data.getIp());
//		if(type.equals("update")){
//			querySql += " and id = " + toSqlVal(data.getId());
//		}
		return querySql;
	}
	
	public String readAllocatedDao(LineConfigData data) {
		String querySql = "select count(*) count from p_controller where lineId is not null ";
		return querySql;
	}
		
}
