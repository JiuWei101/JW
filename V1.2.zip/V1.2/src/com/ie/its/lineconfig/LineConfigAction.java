/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.lineconfig;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;

//命名空间
@Namespace("/line_config")
@Results({@Result(name="list",location="/line_config/line_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="line_list",location="list.action",type="redirect")})
public class LineConfigAction extends ExtendActionSupport {
	
	private LineConfigData data;
	@Autowired
	private LineConfigService lineService;
	
	public LineConfigData getData() {
		return data;
	}
	public void setData(LineConfigData data) {
		this.data = data;
	}
	public LineConfigAction(){
		if(data == null){
			data = new LineConfigData();
		}
	}
	/**
     * Description :查询通讯线路．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="line_list",results={@Result(name="success",location="/line_config/line_list.jsp")})
	public String line_list(){
		data = lineService.line_list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		//获得状态拉框
		//获取当前系统类型  edit by jiangyf
	     data.setSysModel(lineService.queryForSystemModel());
		data.setStatusList(Util.getCodeList(data, "status"));
		
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="line_create",results={@Result(name="create",location="/line_config/line_create.jsp")})
	public String line_create(){
		data.setId("");
		//设置多语言
		setLang(data);
		//获取当前系统类型  edit by jiangyf
	     data.setSysModel(lineService.queryForSystemModel());
	
		//设置波特率缺省值
		data.setDefBaudRate("20K");
		//获得波特率下拉框
		data.setBaudRateList(DisposalCode.getCode("baud_rate",request.getSession().getAttribute("lang").toString())); 
		//获得是否开启下拉框
		data.setStatusList(Util.getCodeList(data, "status"));
		//data.setStatusList(DisposalCode.getCode("status",request.getSession().getAttribute("lang").toString()));

		return ConstantClass.ACTION_CREATE;
	}
	
	@Action(value="line_edit",results={@Result(name="edit",location="/line_config/line_edit.jsp")})
	public String line_edit(){
		lineService.line_get(data);
		
		//设置多语言
		setLang(data);

		//设置波特率缺省值
		data.setDefBaudRate("500K");
		//获得波特率下拉框
		data.setBaudRateList(DisposalCode.getCode("baud_rate",request.getSession().getAttribute("lang").toString())); 
		//获得是否开启下拉框
		data.setStatusList(Util.getCodeList(data, "status"));
		//获取当前系统类型  edit by jiangyf
		data.setSysModel(lineService.queryForSystemModel());
		//data.setStatusList(DisposalCode.getCode("status",request.getSession().getAttribute("lang").toString()));
		data.setOldIp(data.getIp());
		return ConstantClass.ACTION_EDIT;
	}
	
	@SuppressWarnings("unchecked")
	@Action(value="line_update",results={@Result(type="json")})
	public void line_update(){		
		JSONObject json =  new JSONObject();
		setLang(data);
		try{
			if((data.getIp()).equals(data.getOldIp())){
				boolean luc = lineService.line_update(data);
				if(luc)
					json.element("success", true);
				else{
					json.element("success", false);//alert_physicalregion_have_map_association
					Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
					json.element("ex", m.get("alert_line_to_be_allocated_cant_disable").toString());
				}
			}else{
				if(lineService.readIsExits(data)){
					boolean luc = lineService.line_update(data);
					if(luc)
						json.element("success", true);
					else{
						json.element("success", false);//alert_physicalregion_have_map_association
						Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
						json.element("ex", m.get("alert_line_to_be_allocated_cant_disable").toString());
					}
				}else{
					json.element("success", false);
					Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
					json.element("ex", m.get("alert_line_already_exists").toString());
				}
			}
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
			
		setJsonRes(json);
	}
	
	/**
	 * 新建通讯线路
	 */
	@Action(value="line_save",results={@Result(type="json")})
	public void line_save(){		
		JSONObject json =  new JSONObject();
		
		try{
			if(lineService.readIsExits(data)){
				data = lineService.line_save(data);
				json.element("success", true);
			}else{
				json.element("success", false);
			}
			
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
			Log.log("新建通讯线路出错："+e);
		}
		
		setJsonRes(json);
	}
	
	@Action(value="line_alledit",results={@Result(name="alledit",location="/line_config/line_alledit.jsp")})
	public String line_alledit(){
		
		//设置多语言
		setLang(data);

		//获得状态下拉框
		data.setStatusList(DisposalCode.getCode("status",request.getSession().getAttribute("lang").toString()));

		return "alledit";
	}	
	
	@Action(value="line_allupdate",results={@Result(type="json")})
	public void line_allupdate(){		
		JSONObject json =  new JSONObject();
		
		if(lineService.readIsAllocated(data)){
			lineService.line_allupdate(data);
			json.element("success", true);
		}else{
			json.element("success", false);
		}
		setJsonRes(json);
	}
	
	@Action(value="line_delete",results={@Result(type="json")})
	public void line_delete(){
		JSONObject json =  new JSONObject();
		setLang(data);
		try{
			lineService.line_delete(data);
			json.element("success", true);
		}catch(DataIntegrityViolationException de){
			
			json.element("success", false);
			
			HashMap lang = (HashMap) data.getCurrent_lang_switch().get("common");
		
			json.element("ex", lang.get("alert_line_to_be_allocated_cant_delete"));
		}catch(Exception e){
			
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);		
		
		
		
	}
}
