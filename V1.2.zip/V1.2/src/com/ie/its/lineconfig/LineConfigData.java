/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-通讯线路配置
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.lineconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class LineConfigData extends ExtendData{
	

	private String id;					//通讯线路id
	private String ip;					//ip
	private String status;				//状态id
	private String notes;				//备注
	private List statusList;			//状态下拉列表
	private String lineParamId;			//通讯线路参数id
	private String boardNo;				//板卡号或IP地址
	private String port;				//端口号或IP端口
	private String stationAddr;			//本地地址
	private String baudRate;			//波特率
	private List baudRateList;			//波特率下拉列表
	private String defBaudRate;			//缺省波特率500K
	private String dataBits;			//数据位
	private String parity;				//校验位
	private String stopBits;			//停止位
	private String mask;				//掩码
	private String purpose;				//用途
	private String describes;			//说明
	private String oldIp;
	
	public String getOldIp() {
		return oldIp;
	}
	public void setOldIp(String oldIp) {
		this.oldIp = oldIp;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public List getStatusList() {
		return statusList;
	}
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	public String getLineParamId() {
		return lineParamId;
	}
	public void setLineParamId(String lineParamId) {
		this.lineParamId = lineParamId;
	}
	public String getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getStationAddr() {
		return stationAddr;
	}
	public void setStationAddr(String stationAddr) {
		this.stationAddr = stationAddr;
	}
	public String getBaudRate() {
		return baudRate;
	}
	public void setBaudRate(String baudRate) {
		this.baudRate = baudRate;
	}
	public List getBaudRateList() {
		return baudRateList;
	}
	public void setBaudRateList(List baudRateList) {
		this.baudRateList = baudRateList;
	}
	public String getDefBaudRate() {
		return defBaudRate;
	}
	public void setDefBaudRate(String defBaudRate) {
		this.defBaudRate = defBaudRate;
	}
	public String getDataBits() {
		return dataBits;
	}
	public void setDataBits(String dataBits) {
		this.dataBits = dataBits;
	}
	public String getParity() {
		return parity;
	}
	public void setParity(String parity) {
		this.parity = parity;
	}
	public String getStopBits() {
		return stopBits;
	}
	public void setStopBits(String stopBits) {
		this.stopBits = stopBits;
	}
	public String getMask() {
		return mask;
	}
	public void setMask(String mask) {
		this.mask = mask;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getDescribes() {
		return describes;
	}
	public void setDescribes(String describes) {
		this.describes = describes;
	}
	

}
