package com.ie.its.inversionsearch;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.its.advertmanage.AdvertService;

/**
 * 智能寻车Action
 * 
 * @author mo Create Date:2013/03/15
 */
@SuppressWarnings("serial")
@Namespace("/inversion")
public class InversionAction extends ExtendActionSupport {

	@Autowired
	private InversionService inversionService;
	private String sDate; // 起始时间
	private String eDate; // 结束时间
	private String carNum; // 车牌号码
	private int pageIndex = 1; // 页码
	private int pageSize = 8; // 每页显示的条数
	private int total; // 总的页数
	private int type; // 查询的类型 1:精确查询, 2:模糊查询, 3:按时间查询
	private List<ParkingData> parkingData;
	private String langCode; // 语言编号
	private Map map; // 国际化
	private String dateParam; // 设置图片存储的参数
	private String dateFormat;
	private String carId; 
	private String inversionInput;
	private String advertPosition;		//广告显示的位置
	
	private String dcode;	
	private String mname;
	private String mapId;

	private String mapName;
	private String dimensionName;
	private String searchMachine;
	
	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getDimensionName() {
		return dimensionName;
	}

	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}

	/**
	 * 查询的Action
	 */
	@Action(value = "carSearch", interceptorRefs = { @InterceptorRef("defaultStack") }, results = { @Result(type = "json") })
	public void searchCar() {
		String machine = inversionService.clickStatistics(searchMachine, type, carNum, pageIndex, dimensionName);		//统计点击率
		JSONObject jo = new JSONObject();
		switch (type) {
			case 1:
				// 1.查询路线
				try{
					jo = inversionService.exactSearch(carId, carNum, mapName, dimensionName);
				}catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			case 2:
				// 2.车牌查询(模糊查詢)
				jo = inversionService.vagueSearch(carNum, pageIndex, pageSize);
				break;
			case 3:
				// 3.时间查询
				eDate = DateUtil.getCurDate() + " " + sDate + ":59:59";	//例: 2013-04-23 15:59:59
				sDate = DateUtil.getCurDate() + " " + sDate + ":00:00"; //例: 2013-04-23 15:00:00
				jo = inversionService.datetimeSearch(sDate, eDate, pageIndex,
						pageSize);
				break;
			case 4:
				// 4.车位查询
				jo = inversionService.carportSearch(carNum, pageIndex, pageSize);
				break;
			case 5:
				// 5.精确查询(包括无牌车)
				jo = inversionService.licenseSearch(carNum, pageIndex, pageSize);
				break;
		}
		jo.put("searchMachine", machine);
		setJsonRes(jo);
	}
	/**接受浏览器发送的心跳 */
	@Action(value="reciveHeart", interceptorRefs={@InterceptorRef("defaultStack")},results={@Result(type="json")})
	public void reciveHeart(){
//		HttpSession session=se.getSession();
//		HttpServletRequest request = WebContextFactory.get().getHttpServletRequest();
//		String ip=session.getId();
		String hostIp = ServletActionContext.getRequest().getRemoteHost();//查询机的IP
		Log.log("--接受浏览器发送的心跳----"+hostIp);
//      String hostIp1 = ServletActionContext.getRequest().getRemoteAddr();//查询机的IP
		String nowTime=inversionService.getCurrentTime();
		//searchMachine.getSearchMachineTime().put(hostIp, nowTime);
		//如果该查询机注册过
		if(SerachMachineOperation.getSearchMachineStatus().containsKey(hostIp)){
			Log.log("--将注册过查询机现在时间加入SearchMachineTime----"+nowTime);
			SerachMachineOperation.getSearchMachineTime().put(hostIp, nowTime);
		}
	}
	/**
	 * 跳转到尋車子系統查询页面1.0
	 */
	@Action(value = "searchPage", interceptorRefs = { @InterceptorRef("defaultStack") }, results = { @Result(name = "success", location = "/inversion/search.jsp") })
	public String searchPage() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(langCode))).get("inversion");
		return SUCCESS;
	}
	
	/**
	 * 跳转到尋車子系統查询页面2.0
	 */
	@Action(value = "searchPage2", interceptorRefs = { @InterceptorRef("defaultStack") }, results = { @Result(name = "success", location = "/inversion/2.0/search.jsp") })
	public String searchPage2() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(langCode))).get("inversion");
		return SUCCESS;
	}
	
	/**
	 * 跳转到尋車子系統查询页面DEBUG
	 */
	@Action(value = "searchPageDebug", interceptorRefs = { @InterceptorRef("defaultStack") }, results = { @Result(name = "success", location = "/inversion/debug/search.jsp") })
	public String searchPageDebug() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(langCode))).get("inversion");
		return SUCCESS;
	}

	/**
	 * 查车管理 searchManage.action
	 */
	@Action(value = "searchManage", results = { @Result(name = "success", location = "/inversion/searchManage.jsp") })
	public String searchManage() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		parkingData = this.inversionService.carNumDateSearch(carNum, sDate,
				eDate, pageIndex, pageSize);
		total = this.inversionService.getTotalPage(carNum, sDate, eDate,
				pageSize);

		return SUCCESS;
	}
	
	/**
	 * 查车管理 searchManage.action
	 */
	@Action(value = "searchCarManage", results = { @Result(name = "success", location = "/inversion/searchManage.jsp") })
	public String searchCarManage() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		map.put("lang", this.request.getSession().getAttribute("lang").toString());
		return SUCCESS;
	}
	
	/**
	 * 尋車储参数设置
	 */
	@Action(value = "setPicParam", results = { @Result(type = "json") })
	public void picParam() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		JSONObject json = new JSONObject();
		boolean flag = inversionService.setupProperty(OperatePro.CONFIGPROPERTIES, OperatePro.DATEPARAM, dateParam);
		json.element("flag", flag).element("dateParam", dateParam).element("map", map);
		setJsonRes(json);
	}
	
	/**
	 * 获取图片设置的参数,
	 */
	@Action(value="queryPicParam", results = {@Result(type="json")})
	public void queryPicParam(){
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		JSONObject json = new JSONObject();
		String param = inversionService.queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.DATEPARAM);
		json.element("param", param).element("map", map);
		setJsonRes(json);
	}

	/**
	 * 日期时间的显示格式设置
	 */
	@Action(value = "setFormatParam", results = { @Result(type = "json") })
	public void setFormatParam() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		JSONObject json = new JSONObject();
		boolean flag = inversionService.setupProperty(OperatePro.CONFIGPROPERTIES, OperatePro.DATEFORMAT, dateFormat);
		json.element("flag", flag).element("dateFormat", dateFormat).element("map", map);
		setJsonRes(json);
	}
	
	/**
	 * 返回主页时间设置
	 */
	@Action(value = "setBackTime", results = { @Result(type = "json") })
	public void setBackTime() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		JSONObject json = new JSONObject();
		boolean flag = inversionService.setupProperty(OperatePro.CONFIGPROPERTIES, OperatePro.BACKTIME, dateParam);
		json.element("flag", flag).element("backTime", dateParam);
		setJsonRes(json);
	}

	/**
	 * 获取返回主页时间
	 */
	@Action(value="queryBackTime", interceptorRefs={@InterceptorRef("defaultStack")}, results = {@Result(type="json")})
	public void queryBackTime(){
		JSONObject json = new JSONObject();
		String param = inversionService.queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.BACKTIME);
		json.element("backTime", param);
		setJsonRes(json);
	}

	/**
	 * 寻车子系统首页文字设置
	 */
	@Action(value = "setInversionIndex", results = { @Result(type = "json") })
	public void setInversionIndex() {
		map = (Map) ((Map) (ExtendData.getLang_switch().get(request.getSession().getAttribute("lang").toString()))).get("inversion");
		JSONObject json = new JSONObject();
		boolean flag = inversionService.setupProperty(OperatePro.CONFIGPROPERTIES, OperatePro.INVERSIONINDEX, inversionInput);
		json.element("flag", flag).element("inversionInput", inversionInput).element("map", map);
		setJsonRes(json);
	}
	
	/**
	 * 获取寻车子系统首页文字
	 */
	@Action(value="queryInversionIndex", interceptorRefs={@InterceptorRef("defaultStack")}, results = {@Result(type="json")})
	public void queryInversionIndex(){
		JSONObject json = new JSONObject();
		String param = inversionService.queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.INVERSIONINDEX);	//从properties文件里找到这个参数
		try {
			param = URLDecoder.decode(param, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			Log.log("inversionInput编码出错.");
		}
		json.element("param", param);
		setJsonRes(json);
	}
	
	@Autowired
	private AdvertService advertService;		//读取广告的service
	
	/**
	 * 查询JSON格式的数据　显示广告
	 * @return 查询后到显示页面
	 */
	@Action(value="queryAdvertJson", interceptorRefs={@InterceptorRef("defaultStack")},
			 results={@Result(type="json")})
	public void queryAdvertJson(){
		JSONObject jobj = new JSONObject();
		JSONArray arr = advertService.queryAdvertJson(advertPosition);
		jobj.element("arr", arr);
		setJsonRes(jobj);
	}
	
	/**
	 *	内部停车路线测试方法 
	 */
	@Action(value="textSearchName", interceptorRefs={@InterceptorRef("defaultStack")},
			 results={@Result(type="json")})
	public void textSearchName(){
		JSONObject jo = inversionService.textSearchName(dcode, mname, mapId);
		setJsonRes(jo);
	}
	
	/**
	 * 属性的get,set 开始*************************
	 * 
	 * @return
	 */
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public String getSDate() {
		return sDate;
	}

	public void setSDate(String sDate) {
		this.sDate = sDate;
	}

	public String getCarNum() {
		return carNum;
	}

	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getLangCode() {
		return langCode;
	}

	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public List<ParkingData> getParkingData() {
		return parkingData;
	}

	public void setParkingData(List<ParkingData> parkingData) {
		this.parkingData = parkingData;
	}

	public String getDateParam() {
		return dateParam;
	}

	public void setDateParam(String dateParam) {
		this.dateParam = dateParam;
	}
	
	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getCarId() {
		return carId;
	}

	public void setCarId(String carId) {
		this.carId = carId;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getInversionInput() {
		return inversionInput;
	}

	public void setInversionInput(String inversionInput) {
		this.inversionInput = inversionInput;
	}

	public String getAdvertPosition() {
		return advertPosition;
	}

	public void setAdvertPosition(String advertPosition) {
		this.advertPosition = advertPosition;
	}

	public String getEDate() {
		return eDate;
	}

	public void setEDate(String eDate) {
		this.eDate = eDate;
	}

	public String getSearchMachine() {
		return searchMachine;
	}

	public void setSearchMachine(String searchMachine) {
		this.searchMachine = searchMachine;
	}

	public void setInversionService(InversionService inversionService) {
		this.inversionService = inversionService;
	}
}
