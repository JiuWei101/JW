package com.ie.its.inversionsearch;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.lineelements.LineElementsService;
import com.ie.its.mapmanage.MapManageData;
import com.ie.reverse.Point;
/**
 * 反向寻车Service
 * @author mo
 */
@Service(value="inversionService")
public class InversionService extends ExtendService {
	@Autowired
	private LineElementsService lineElementService;
	/**
	 * 组合车位位置
	 * @param park 车位相关信息
	 * @param type 0表示同层，1表示跨层
	 * @return 车位位置字符串，形如 “地图名-逻辑区域名-车位号”
	 * @author wangj
	 * @date 2014-09-16
	 */
	private String generatePosition(ParkingData park){
		ArrayList<String> arr = new ArrayList<String>();
		if(park.getAreaName() != null){
			arr.add(park.getAreaName());
		}
		if(park.getCode() != null){
			arr.add(park.getCode());
		}
		StringBuilder sb = new StringBuilder();
		if(arr.size() > 0){
			for(String s : arr){
				sb.append(s).append("-");
			}
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}
	
	/**
	 * 精确查询
	 * @param carNum 车牌号码
	 * @return 车位详细信息数据格式
	 *	carNum:车牌号 position：车位置 parktime：停车时间 img：车图片 flash：寻车数据
	 * 	{carNum:"3423",position:"第一层 324234fr",parktime:"2012-08-09 08:56:23",img:"",flash:""}
	 *	后台接受数据格式：carNum车牌号
	 */
	public JSONObject exactSearch(String carId, String carNum, String mapName, String dimensionName){
		JSONObject jo = new JSONObject();
		try {
		ParkingData park = (ParkingData)this.getJt().queryForObjectExt(getParkSQL(carId, carNum), ParkingData.class);
		if(park.getPsid() == null){	//该车已开出
			return null;
		}
		//组装成前台页面需要的JSON数据格式
		
		jo.element("carNum", park.getCarNum() == null ? "" : park.getCarNum());
		//按楼层和车位编码组合停车位置
		//统一采用generatePosition方法生成位置，by wangj 2014-09-16
//		String areaName = park.getAreaName() == null ? "" : park.getAreaName();
//		String code = park.getCode() == null ? "" : "-"+park.getCode();
//		jo.element("position", areaName + code);
		jo.element("position", generatePosition(park));
		jo.element("parktime", park.getParktime() == null ? "" : park.getParktime().split("\\.")[0]);	//将小数点去掉
		jo.element("img", park.getCarSrc() == null ? "" : park.getCarSrc());
		
		//获取画线参数 add　by wangj 2014-10-24
		JSONObject jobj = this.getLineElements();
		
		String startSql = "";
		if(Util.isCon(mapName) && Util.isCon(dimensionName)){
			startSql = "select pp.mapId as mapId, pp.id as id, pp.x_axis as x, pp.y_axis as y, pp.ifcarsearchpc as ifcarsearchpc from p_pathnodeinfohead pp left join p_map pm on pp.mapId = pm.id where pp.ifcarsearchpc='3' and pp.code = '"+
			dimensionName+"' and pm.number = '"+mapName+"'";
		}else{
			String hostIp = ServletActionContext.getRequest().getRemoteHost();		//查询机的IP
			hostIp = hostIp.equalsIgnoreCase("0:0:0:0:0:0:0:1") ? "127.0.0.1" : hostIp;
			startSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y, ifcarsearchpc as ifcarsearchpc FROM p_pathnodeinfohead WHERE " +
			"FIND_IN_SET('" + hostIp + "',IP) > 0";
		}
		Point startPoint = (Point)this.getJt().queryForObjectExt(startSql, Point.class);	//起始点
		if(startPoint.getId() == null){			//如果当前查询机没登记
			jo.element("errorMsg", 1);
			return jo;
		}
		List<Point> listPoint = new ArrayList<Point>();
		listPoint.add(startPoint);
		//如果当前查询机的地图ID和需要查询的车所在楼层的地图ＩＤ是一样的，说明只有一层，否则有两层
		if(startPoint.getMapId().equalsIgnoreCase(park.getMapId())){
			String shortSql = "SELECT ID FROM p_shortestpathinofhead WHERE mapId='" + startPoint.getMapId() + "' and start='" + startPoint.getId() + "' and end='" + park.getDetectorId() + "'";
			String headId = this.getJt().queryForObject(shortSql, String.class);
			String pathLine = "SELECT pointid FROM p_shortestpathinofline WHERE headid='" + headId + "' ORDER BY sort ASC";
			List<String> list = (List<String>)this.getJt().queryForList(pathLine, String.class);
			for(String str : list){
				String otherSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y FROM p_pathnodeinfohead WHERE " +
				"ID='" + str + "'";
				Point otherPoint = (Point)this.getJt().queryForObjectExt(otherSql, Point.class);	//其他节点
				listPoint.add(otherPoint);
			}
			
			StringBuilder sb = getVerticalEndPoint(listPoint, park);
			jo.element("point", sb.substring(0, sb.length()-1));
			jo.element("zoomRect", getFinalPoint(sb.toString()));		//用于放大指定区域
			jo.element("num", 0);										//用于识别起始终点
			jo.element("flash", park.getFlash() == null ? "" : splitMapSrc(park.getFlash()));//swf文件
			jo.element("imgPath", park.getImgPath() == null ? "" : splitMapImg(park.getImgPath()));//jpg文件
		} else{
			//找到mapId下对应的电梯口和其ID
			String liftSql = "SELECT ID as id, mapId as mapId, code as code, x_axis as x, y_axis as y FROM p_pathnodeinfohead WHERE ifcarsearchpc='2' and mapId='" + startPoint.getMapId() + "'";	
			List<Point> liftPointList = (List<Point>) this.getJt().queryForListExt(liftSql, Point.class);	//执行查询操作
			double minWeight = 0;
			String headId = "";
			String liftId = "";
			Point endPoint = new Point();		//终点
			for(Point liftPoint : liftPointList){	//遍历每一个电梯,用查询机的当前地图的ID作为起点,当前地图上的电梯的ID作为终点,找出最短的距离的电梯
				String startMapSql = "SELECT ID as id, weight as weight FROM p_shortestpathinofhead WHERE start='" + startPoint.getId() + "' and end='" + liftPoint.getId() + "'";
				Point shortPoint = this.getJt().queryForObjectExt(startMapSql, Point.class);	//第一层地图的从查询机到电梯口的距离
				
				String liftIDSql = "SELECT ID as id FROM p_pathnodeinfohead WHERE mapId='" + park.getMapId() + "' and code='" + liftPoint.getCode() + "'";
				String liftCodeId = "";
				try{
					liftCodeId = (String) this.getJt().queryForObject(liftIDSql, String.class);	//找到第二层对应电梯口的ID
				} catch(Exception e){
					continue;
				}
				
				String endMapSql = "SELECT ID as id, weight as weight FROM p_shortestpathinofhead WHERE start='" + liftCodeId + "' and end='" + park.getDetectorId() + "'";
				Point endshortPoint = this.getJt().queryForObjectExt(endMapSql, Point.class);	//第二层地图的从电梯口到车位的距离
				
				minWeight = minWeight == 0 ? (shortPoint.getWeight() + endshortPoint.getWeight()) : minWeight;	//如果是每一次循环就把第一个距离赋给minWeight
				if(minWeight >= (shortPoint.getWeight() + endshortPoint.getWeight())){		//如果当前的电梯口比上一个电梯口的距离还短就赋值给minWeight,并把当前的lift的点赋给finalPoint
					minWeight = shortPoint.getWeight() + endshortPoint.getWeight();
					endPoint = liftPoint;
					headId = shortPoint.getId();
					liftId = liftCodeId;
				}
			}
			String pathLine = "SELECT pointid FROM p_shortestpathinofline WHERE headid='" + headId + "' ORDER BY sort ASC";
			List<String> list = (List<String>)this.getJt().queryForList(pathLine, String.class);
			for(String str : list){
				String otherSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y FROM p_pathnodeinfohead WHERE " +
				"ID='" + str + "'";
				Point otherPoint = (Point)this.getJt().queryForObjectExt(otherSql, Point.class);	//其他节点
				listPoint.add(otherPoint);
			}
			listPoint.add(endPoint);	//将终点添加到所有点的列表中去
			
			StringBuilder sb = new StringBuilder();
			for(Point point : listPoint){
				sb.append(point.getX()).append(",").append(point.getY()).append(";");
			}
			jo.element("point", sb.substring(0, sb.length()-1));	//第一层经过的点
			jo.element("zoomRect", getFinalPoint(sb.toString()));	//第一层要放大区域的点
			String mapPathSql = "SELECT path, name, imgPath FROM p_map WHERE id='" + startPoint.getMapId() + "'";		//因为跨层的地图不同,要返回第一层的地图到前台
			MapManageData mapData = this.getJt().queryForObjectExt(mapPathSql, MapManageData.class);//swf文件
			jo.element("flash", mapData.getPath() == null ? "" : splitMapSrc(mapData.getPath()));//jpg文件
			jo.element("imgPath", mapData.getImgPath() == null ? "" : splitMapImg(mapData.getImgPath()));
			jo.element("currentFloor", mapData.getName());
			jo.element("num", 1);										//用于识别起始终点
			jo.element("nextfloor", nextExactSearch(carId, carNum, liftId, park.getMapId(), jobj));
		}
		//Flash======================================================================================================	
		//重构获取画线参数、箭头参数的代码  modified by wangj 2014-10-24
		jo.element("carFloor", park.getParkName());
		jo.element("line",this.getLineParam(jobj));
		jo.element("arrow", this.getArrow(jobj));
//		jo.element("line", getLineParam());	
//		jo.element("arrow", getArrow());
		jo.element("cratio", this.getCRatio(jobj));
		jo.element("bratio", this.getBRatio(jobj));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return jo;
	}
	/** 返回当前日期时间字符串
	 * 默认格式：yyyy-mm-dd hh:mm:ss
	 * @return String 返回当前字符串型日期时间
	 */
	public String getCurrentTime() {
		String returnStr = null;
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		returnStr = f.format(date);
		return returnStr;
	}
	/**
	 * 跨层查询查第二层的方法
	 * @param carId
	 * @param carNum
	 * @param liftCodeId
	 * @param mapId
	 * @return
	 */
	public JSONObject nextExactSearch(String carId, String carNum, String liftCodeId, String mapId, JSONObject jobj){
		//组装成前台页面需要的JSON数据格式
		JSONObject jo = new JSONObject();
		List<Point> listPoint = new ArrayList<Point>();
		
		ParkingData park = (ParkingData)this.getJt().queryForObjectExt(getParkSQL(carId, carNum), ParkingData.class);
		
		String startSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y, ifcarsearchpc as ifcarsearchpc FROM p_pathnodeinfohead WHERE " +
							"ID='" + liftCodeId + "'";
		Point startPoint = (Point)this.getJt().queryForObjectExt(startSql, Point.class);	//起始点
		listPoint.add(startPoint);
		String shortSql = "SELECT ID FROM p_shortestpathinofhead WHERE mapId='" + startPoint.getMapId() + "' and start='" + startPoint.getId() + "' and end='" + park.getDetectorId() + "'";
		String headId = this.getJt().queryForObject(shortSql, String.class);
		String pathLine = "SELECT pointid FROM p_shortestpathinofline WHERE headid='" + headId + "' ORDER BY sort ASC";
		List<String> list = (List<String>)this.getJt().queryForList(pathLine, String.class);
		for(String str : list){
			String otherSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y FROM p_pathnodeinfohead WHERE " +
			"ID='" + str + "'";
			Point otherPoint = (Point)this.getJt().queryForObjectExt(otherSql, Point.class);	//其他节点
			listPoint.add(otherPoint);
		}
		
		StringBuilder sb = getVerticalEndPoint(listPoint, park);

		jo.element("point", sb.substring(0, sb.length()-1));		//第二层要经过的点的坐标
		jo.element("zoomRect", getFinalPoint(sb.toString()));		//第二层要放大的区域的坐标
		jo.element("num", 2);										//用于识别起始终点
		jo.element("flash", park.getFlash() == null ? "" : splitMapSrc(park.getFlash()));	//第二层的地图
		jo.element("imgPath", park.getImgPath() == null ? "" : splitMapImg(park.getImgPath()));	//第二层的地图
		//重构获取画线参数、箭头参数的代码  modified by wangj 2014-10-24
		jo.element("line", this.getLineParam(jobj));
		jo.element("arrow", this.getArrow(jobj));
//		jo.element("line", getLineParam());						
//		jo.element("arrow", getArrow());
		jo.element("cratio", this.getCRatio(jobj));
		jo.element("bratio", this.getBRatio(jobj));
		return jo;
	}
	
	/**
	 * 获取垂直点和终点,添加到StringBuilder中
	 * @param listPoint
	 * @param park
	 * @return
	 */
	public StringBuilder getVerticalEndPoint(List<Point> listPoint, ParkingData park){
		if(Util.isCon(park.getOnepoint_id()) && Util.isCon(park.getAnopoint_id())){
			Point verticalPoint = new Point();		//垂直点
			verticalPoint.setId(park.getDetectorId());
			verticalPoint.setMapId(park.getMapId());
			verticalPoint.setX(park.getVertical_x_axis());
			verticalPoint.setY(park.getVertical_y_axis());
			listPoint.add(verticalPoint);
		}
		Point endPoint = new Point();		//终点
		endPoint.setId(park.getDetectorId());
		endPoint.setMapId(park.getMapId());
		endPoint.setX(park.getX_axis());
		endPoint.setY(park.getY_axis());
		
		listPoint.add(endPoint);
		
		StringBuilder sb = new StringBuilder();
		for(Point point : listPoint){
			sb.append(point.getX()).append(",").append(point.getY()).append(";");
		}
		return sb;
	}
	
	/**
	 * 组合park的sql语句
	 * @param carId
	 * @param carNum  //不再需要2013-07-09
	 * @return
	 */
	public String getParkSQL(String carId, String carNum){
//		String sql = "SELECT p.id as psid, p.plateno as carNum, p.picturepath as carSrc, p.code as code, p.detectorId as detectorId, " +
//		"p.updateDate as parktime,d.x_axis as x_axis, d.y_axis as y_axis, d.vertical_x_axis as vertical_x_axis, " +
//		"d.vertical_y_axis as vertical_y_axis, d.onepoint_id, d.anopoint_id, m.id as mapId, m.name as parkName, m.path as flash, m.imgPath as imgPath FROM p_parkingspace p, p_detector d, p_map m WHERE " +
//		"p.detectorId = d.id and d.mapId = m.id and p.id=" + Util.toSqlVal(carId) + "";
		String sql = "SELECT p.id as psid, p.plateno as carNum, p.picturepath as carSrc, p.code as code, p.detectorId as detectorId, " +
		"p.updateDate as parktime,d.x_axis as x_axis, d.y_axis as y_axis, d.vertical_x_axis as vertical_x_axis, " +
		"d.vertical_y_axis as vertical_y_axis, d.onepoint_id, d.anopoint_id, l.name as areaName, m.id as mapId, m.name as parkName, m.path as flash, m.imgPath as imgPath " +
		"FROM p_parkingspace p inner join p_detector d on p.detectorId = d.id left join p_logicregion l on p.logicId = l.id left join p_map m on d.mapId = m.id WHERE " +
		"p.id=" + Util.toSqlVal(carId) + "";
		Log.log(sql);
		return sql;
	}
	
	/**
	 * 内部停车路线测试方法
	 * @param dCode
	 * @param mName
	 * @param mapId
	 * @return
	 */
	public JSONObject textSearchName(String dCode, String mName, String mapId){
		JSONObject jo = new JSONObject();
		String sql = "SELECT d.id as detectorId,s.plateno as carNum, m.name as parkName, s.code as code, x_axis, y_axis, vertical_x_axis, vertical_y_axis, onepoint_id, anopoint_id FROM p_detector d inner join p_parkingspace s on d.id = s.detectorId left join p_map m on d.mapId = m.id WHERE d.mapId='" + mapId + "' and d.code='" + dCode + "'";
		ParkingData park = (ParkingData)this.getJt().queryForObjectExt(sql, ParkingData.class);
		
		String startSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y, ifcarsearchpc as ifcarsearchpc FROM p_pathnodeinfohead WHERE " +
				"mapId='" + mapId + "' and name='" + mName + "'";
		//System.out.println("StartSql: " + startSql);
		Point startPoint = (Point)this.getJt().queryForObjectExt(startSql, Point.class);	//起始点
		List<Point> listPoint = new ArrayList<Point>();
		listPoint.add(startPoint);
		
		String shortSql = "SELECT ID FROM p_shortestpathinofhead WHERE mapId='" + startPoint.getMapId() + "' and start='" + startPoint.getId() + "' and end='" + park.getDetectorId() + "'";
		String headId = this.getJt().queryForObject(shortSql, String.class);
		String pathLine = "SELECT pointid FROM p_shortestpathinofline WHERE headid='" + headId + "' ORDER BY sort ASC";
		List<String> list = (List<String>)this.getJt().queryForList(pathLine, String.class);
		for(String str : list){
			String otherSql = "SELECT mapId as mapId, id as id, x_axis as x, y_axis as y FROM p_pathnodeinfohead WHERE " +
			"ID='" + str + "'";
			Point otherPoint = (Point)this.getJt().queryForObjectExt(otherSql, Point.class);	//其他节点
			listPoint.add(otherPoint);
		}
		
		if(Util.isCon(park.getOnepoint_id()) && Util.isCon(park.getAnopoint_id())){
			Point verticalPoint = new Point();		//垂直点
			verticalPoint.setId(park.getDetectorId());
			verticalPoint.setMapId(park.getMapId());
			verticalPoint.setX(park.getVertical_x_axis());
			verticalPoint.setY(park.getVertical_y_axis());
			listPoint.add(verticalPoint);
		}
		
		Point endPoint = new Point();		//终点
		endPoint.setId(park.getDetectorId());
		endPoint.setMapId(park.getMapId());
		endPoint.setX(park.getX_axis());
		endPoint.setY(park.getY_axis());
		
		listPoint.add(endPoint);
		StringBuilder sb = new StringBuilder();
		for(Point point : listPoint){
			sb.append(point.getX()).append(",").append(point.getY()).append(";");
		}
		//Flash======================================================================================================
		String pstr = getFinalPoint(sb.toString())+","+endPoint.getX()+","+endPoint.getY();
		String parkName = park.getParkName()==null?"":park.getParkName();
		String code = park.getCode()==null?"":park.getCode();
		String carNum = park.getCarNum()==null?"":park.getCarNum();
		jo.element("point", sb.substring(0, sb.length()-1));
		jo.element("mapName", "当前楼层,"+parkName);//地图名
		jo.element("parkingSpaceCode", "车位编号,"+code);//车位编码
		jo.element("plateNo", "车牌号,"+carNum);//车牌号
		jo.element("zoomRect", pstr);
		JSONObject jobj = this.getLineElements(); //获取所有的LineElements
//		jo.element("line", getLineParam());
		jo.element("line", this.getLineParam(jobj));
		jo.element("num", 0);										//用于识别起始终点
		//System.out.println(jo.getString("point"));
//		jo.element("arrow", getArrow());
		jo.element("arrow", this.getArrow(jobj));
		
		jo.element("cratio", this.getCRatio(jobj));
		jo.element("bratio", this.getBRatio(jobj));
		return jo;
	}
	
	private JSONObject getLineElements(){
		JSONObject jobj = lineElementService.getLineElements();
		return jobj;
	}
	
	private String getCRatio(JSONObject jobj){
		return jobj.getString("cratio");
	}
	
	private String getBRatio(JSONObject jobj){
		return jobj.getString("bratio");
	}
	
	private String getLineParam(JSONObject jobj){
		StringBuilder sb = new StringBuilder();
		sb.append(jobj.getString("thickness")).append(",")
		.append(jobj.getString("rgb")).append(",")
		.append(jobj.getString("alpha")).append(",")
		.append(jobj.getString("pixelhinting")).append(",")
		.append(jobj.getString("noscale")).append(",")
		.append(jobj.getString("capsstyle")).append(",")
		.append(jobj.getString("jointstyle")).append(",")
		.append(jobj.getString("miterlimit"));
		return sb.toString();
	}
	
	private String getArrow(JSONObject jobj){
		StringBuilder sb = new StringBuilder();
		sb.append(jobj.getString("arrowlen")).append(",")
		.append(jobj.getString("arrowangle")).append(",")
		.append(jobj.getString("range"));
		return sb.toString();
	}
	
//	/**
//	 * 获取flash地图上线条的参数
//	 * @return
//	 */
//	private String getLineParam(){
//		StringBuilder sb = new StringBuilder();
//		FileInputStream fis = null;
//		try {
//			String path = (getClass().getClassLoader().getResource("").toURI())
//					.getPath();
//			fis = new FileInputStream(path + "lineelements.properties");
//			Properties prop = new Properties();
//			prop.load(fis);
//			sb.append((String) prop.get("thickness")).append(",");
//			sb.append((String) prop.get("rgb")).append(",");
//			sb.append((String) prop.get("alpha")).append(",");
//			sb.append((String) prop.get("pixelhinting")).append(",");
//			sb.append((String) prop.get("noscale")).append(",");
//			sb.append((String) prop.get("capsstyle")).append(",");
//			sb.append((String) prop.get("jointstyle")).append(",");
//			sb.append((String) prop.get("miterlimit"));
//		} catch (URISyntaxException e) {
//			Log.log(e);
//		} catch (FileNotFoundException e) {
//			Log.log(e);
//		} catch (IOException e) {
//			Log.log(e);
//		} finally {
//			try {
//				if (fis != null){
//					fis.close();
//				}
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		return sb.toString();
//	}
//	
//	/**
//	 * 获取flash地图上箭头的参数
//	 * @return
//	 */
//	private String getArrow(){
//		StringBuilder sb = new StringBuilder();
//		FileInputStream fis = null;
//		try {
//			String path = (getClass().getClassLoader().getResource("").toURI())
//					.getPath();
//			fis = new FileInputStream(path + "lineelements.properties");
//			Properties prop = new Properties();
//			prop.load(fis);
//			sb.append((String) prop.get("arrowlen")).append(",");
//			sb.append((String) prop.get("arrowangle")).append(",");
//			sb.append((String) prop.get("range"));
//		} catch (URISyntaxException e) {
//			Log.log(e);
//		} catch (FileNotFoundException e) {
//			Log.log(e);
//		} catch (IOException e) {
//			Log.log(e);
//		} finally {
//			try {
//				if (fis != null){
//					fis.close();
//				}
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		return sb.toString();
//	}
	
	//==============================================================================
	//==============================================================================
	
	/**
	 * 拆分要比较的坐标点
	 * @param point
	 * @return
	 */
	private List<Point> getPointList(String point){
		List<Point> list = new ArrayList<Point>();
		String[] points = point.split(";");		//先将每一组[Ｘ,Ｙ]坐标割开
		for(int i = 0; i < points.length; i++){
			String[] pt = points[i].split(",");		//将每一组[x,y]再分开,存到PointData里去
			Point pd = new Point();
			pd.setX(Float.valueOf(pt[0]));			//取Ｘ
			pd.setY(Float.valueOf(pt[1]));			//取Ｙ
			list.add(pd);		
		}
		return list;
	}
	
	/**
	 * 获取最终要放大区域的点坐标
	 * @param point
	 * @return
	 */
	private String getFinalPoint(String point){
		double outSide = 50;
		StringBuilder sb = new StringBuilder();
		List<Point> list = getPointList(point);
		if(list.size() > 0){
			double max_X = list.get(0).getX(), max_Y = list.get(0).getY(),
					min_X = list.get(0).getX(), min_Y = list.get(0).getY();
			
			Point maxPoint = new Point();
			Point minPoint = new Point();
			for(Point pd : list){		
				//找到最大的坐标
				max_X = max_X >= pd.getX() ? max_X : pd.getX();
				max_Y = max_Y >= pd.getY() ? max_Y : pd.getY();
				maxPoint.setX(max_X + outSide);
				maxPoint.setY(max_Y + outSide);
				//找到最小的坐标
				min_X = min_X <= pd.getX() ? min_X : pd.getX();
				min_Y = min_Y <= pd.getY() ? min_Y : pd.getY();
				minPoint.setX(min_X >= outSide ? (min_X - outSide) : min_X);
				minPoint.setY(min_Y >= outSide ? (min_Y - outSide) : min_Y);
			}
			
			sb.append((int)minPoint.getX()).append(",").append((int)minPoint.getY()).append(",").append((int)maxPoint.getX())
				.append(",").append((int)maxPoint.getY());
		}
		return sb.toString();
	}
	
	//===========================================================================
	//===========================================================================
	
	/**
	 * 模糊查询
	 * @param carNum 车牌号码
	 * @param start	页码
	 * @param limit 每页查询的记录数
	 * @return 返回的数据格式
	 * {"total":60,"rows":[{"img":"","carNum":"HN1-0"},{"img":"","carNum":"HN1-1"}]}
	 */
	public JSONObject vagueSearch(String carNum, int start, int limit){
		JSONObject jo = new JSONObject();
		start = (start - 1) * limit;	//计算从第几条开始查询
		
		String sql = "SELECT * FROM (SELECT p.id as psid, p.plateno as carNum, p.picturepath as carSrc, p.code as code, p.detectorId as detectorId, " +
		"p.updateDate as parktime, m.name as parkName, d.code as detectorCode, m.path as flash, pl.name as areaName FROM p_parkingspace p LEFT JOIN p_logicregion" +
		" pl ON p.logicId=pl.id, p_detector d, p_map m WHERE p.detectorId = d.id and d.mapId = m.id and p.picturepath!='' " +
		"and p.inuse=1 and p.plateno LIKE '";
		
		StringBuilder sb = new StringBuilder("SELECT * FROM (");
		//组合模糊查询的顺序
		sb.append(sql).append("%").append(carNum).append("%' ORDER BY p.updateDate desc) park UNION ").append(sql).append(groupCarNum(carNum)).append("'").append(" order by p.updateDate) park) park group by carNum");
		
		@SuppressWarnings("unchecked")
		List<ParkingData> totalList = (ArrayList<ParkingData>)this.getJt().queryForListExt(sb.toString(), ParkingData.class);
		int total = totalList.size();
		sb.append(" LIMIT ").append(start).append(",").append(limit);
		
		@SuppressWarnings("unchecked")
		List<ParkingData> list = (ArrayList<ParkingData>)this.getJt().queryForListExt(sb.toString(), ParkingData.class);
		//System.out.println(sb.toString());
		jo = groupJSONObject(list, total);
		
		return checkSearchDataNull(jo, start, limit);
	}
	
	/**
	 * 组合简易查询中的车牌
	 * @param carNum
	 * @return 例: %c%a%r%N%u%m%
	 */
	public String groupCarNum(String carNum){
		StringBuilder sb = new StringBuilder("%");
		for(int i = 0; i < carNum.length(); i++){
			sb.append(carNum.charAt(i)).append("%");
		}
		return sb.toString();
	}
	
	/**
	 * 组合简易查询中
	 * @param carNum
	 * @return 例: %c%a%r%N%u%m%
	 */
	public String groupCarNum(String field, String carNum){
		StringBuilder sb = new StringBuilder(field);
		
		return sb.toString();
	}
	
	/**
	 * 按时间查询
	 * @param start	页码
	 * @param limit 每页查询的记录数
	 * @param sDate 开始时间
	 * @param eDate 结束时间
	 * @return 返回的数据格式{"total":60,"rows":[{"img":"","carNum":"HN1-0"},{"img":"","carNum":"HN1-1"}]}
	 */
	public JSONObject datetimeSearch(String sDate, String eDate, int start, int limit){
		Date startDate;
		Date endDate;
		SimpleDateFormat sdfTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<ParkingData> list = new ArrayList<ParkingData>();
		try {
			startDate = sdfTime.parse(sDate);
			endDate = sdfTime.parse(eDate);
			if(startDate.getTime() < endDate.getTime()){
				return getJSONObjectResult("p.inuse=1 and p.updateDate BETWEEN '" + sDate + "' AND '" + eDate + "' GROUP BY p.plateno ", start, limit);
			}
		} catch (ParseException e) {
			Log.log(e);
		}
		return groupJSONObject(list, 0);
	}
	
	/**
	 * 按车位查询
	 * @param carport 车位编号
	 * @param start	页码
	 * @param limit 每页查询的记录数
	 * @return 返回的数据格式{"total":60,"rows":[{"img":"","carNum":"HN1-0"},{"img":"","carNum":"HN1-1"}]}
	 */
	public JSONObject carportSearch(String carport, int start, int limit){
		return getJSONObjectResult("p.code like '" + groupCarNum(carport) + "'  GROUP BY p.plateno ", start, limit);
	}
	
	/**
	 * 按全车牌号码查询
	 * @param carNum
	 * @return 
	 */
	public JSONObject licenseSearch(String carNum, int start, int limit){
		if(carNum.equals("nocar")){//手机app的无牌车查询 add by wangj 2013-12-17
			carNum = "无牌车";
		}
		String sql = "p.inuse=1 and p.plateno like '" + carNum + "'";
		JSONObject jo = new JSONObject();
		jo = getJSONObjectResult(sql, start, limit);
		return checkSearchDataNull(jo, start, limit);
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject getJSONObjectResult(String condition, int start, int limit){
		start = (start - 1) * limit;	//计算从第几条开始查询
		String sql = "SELECT * FROM (SELECT p.id as psid, p.plateno as carNum, p.picturepath as carSrc, p. code as code,l. name as areaName, p.detectorId as detectorId, " +
		"p.updateDate as parktime, m.name as parkName,d.code as detectorCode, m.path as flash FROM p_parkingspace p inner join p_detector d on p.detectorId = d.id left join p_logicregion l on p.logicId = l.id left join p_map m on d.mapId = m.id WHERE " +
		"p.picturepath!='' and " + condition + " ORDER BY p.updateDate DESC) park LIMIT " + start + "," + limit;
		Log.log("反向寻车: " + sql);
		List<ParkingData> list = (ArrayList<ParkingData>)this.getJt().queryForListExt(sql, ParkingData.class); 
		String countSql = "SELECT count(*) FROM (SELECT p.id FROM p_parkingspace p inner join p_detector d on p.detectorId = d.id left join p_logicregion l on p.logicId = l.id left join p_map m on d.mapId = m.id WHERE " +
		"p.picturepath!='' and " + condition + ") park";
		int total = this.getJt().queryForInt(countSql);	
		
		return groupJSONObject(list, total);
	}

	/**
	 * 如果字符串为空就赋值为空,否则返回原值
	 * @param str
	 * @return
	 */
	public String checkNull(String str){
		return str == null ? "" : str;
	}
	
	/**
	 * 查一下是否有不能识别车牌的车的信息
	 * @param jo
	 * @param start
	 * @param limit
	 * @return
	 */
	private JSONObject checkSearchDataNull(JSONObject jo, int start, int limit) {
		int total = (Integer) jo.get("total");
		if(total == 0){
			String countSql = "SELECT count(*) FROM p_parkingspace p, p_detector d, p_map m WHERE " +
			"p.detectorId = d.id and d.mapId = m.id and p.picturepath!='' and p.inuse=1 and p.plateno in ('', '无牌车');";
			Log.log("============>" + countSql);
			int count = this.getJt().queryForInt(countSql);
			Log.log("============>" + count);
			if(count == 0){
				jo.element("total", "-1");
			}
		}
		return jo;
	}
	
	//===================================================================================================================================
	//===================================================================================================================================
	
	/**
	 * 获取查车管理页面查询结果的总页数
	 * @param carport
	 * @param sDate
	 * @param eDate
	 * @param limit
	 * @return
	 */
	public int getTotalPage(String carport, String sDate, String eDate,  int pageSize){
		StringBuilder sb = new StringBuilder();
		sb = groupCarManageSql(carport, sDate, eDate);
		List list = this.getJt().queryForList(sb.toString());
		
		int total = list.size();
		int t = total / pageSize;
		return total % pageSize > 0 ? t + 1 : t;
	}
	
	/**
	 * 查车管理的查询功能
	 * @param carport 车牌号码
	 * @param start 页码
	 * @param limit 每页查询的记录数
	 * @param sDate 开始时间
	 * @param eDate 结束时间
	 * @return 
	 */
	@SuppressWarnings("unchecked")
	public List<ParkingData> carNumDateSearch(String carport, String sDate, String eDate, int start, int limit){
		start = (start - 1) * limit;
		StringBuilder sb = new StringBuilder();
		sb = groupCarManageSql(carport, sDate, eDate);
		sb.append("limit ").append(start).append(",").append(limit);
		Log.log(sb);
		List<ParkingData> hisList = (ArrayList<ParkingData>)this.getJt().queryForListExt(sb.toString(), ParkingData.class);
		String path = ServletActionContext.getRequest().getContextPath();
		path += "/inversion/picCreate.jsp?ppath=";
		for(ParkingData park : hisList){
			park.setInTime(park.getInTime() == null ? "" : park.getInTime().substring(0, park.getInTime().lastIndexOf(".")));
			park.setOutTime(park.getOutTime() == null ? "" : park.getOutTime().substring(0, park.getOutTime().lastIndexOf(".")));
			//System.out.println("Image: " + park.getCarSrc());
			try {
				park.setCarSrc(park.getCarSrc() == null ? "" : path + URLEncoder.encode(park.getCarSrc(), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				Log.log("车的图片路经编码失败!");
			}
		}
		
		Log.log(hisList);
		return hisList;
	}
	
	/**
	 * 组装查车管理的ＳＱＬ语句
	 * @param carport
	 * @param sDate
	 * @param eDate
	 * @return
	 */
	private StringBuilder groupCarManageSql(String carport, String sDate, String eDate){
		StringBuilder sb = new StringBuilder();
		sDate = checkNull(sDate).equals("") ? "" : sDate.split(" ")[0] + " 00:00:00";
		eDate = checkNull(eDate).equals("") ? "" : eDate.split(" ")[0] + " 23:59:59";
		
		sb.append("SELECT log.id as id, log.parkingSpaceCode as code, log.inTime as inTime, log.outTime as outTime, log.plateno as carNum, log.picturepath as carSrc FROM p_parkingspaceoperationlog as log WHERE ");
		if (!checkNull(sDate).equals("") && !checkNull(eDate).equals("")) { // 如果开始时间都结束时间不为空就添加时间的查询
			sb.append("log.inTime BETWEEN '" + checkNull(sDate) + "' AND '"
					+ checkNull(eDate) + "' AND ");
		}
		sb.append(" log.plateno LIKE '%" + checkNull(carport) + "%' UNION ");
		sb.append("select hiss.id as id, hiss.code as code, hiss.inTime as inTime, hiss.outTime as outTime, hiss.carNum as carNum, hiss.carSrc as carSrc from (");
		sb.append("select his.id as id, his.parkingSpaceCode as code, his.inTime as inTime, max(his.outTime) as outTime, his.plateno as carNum, his.picturepath as carSrc from")
			.append(" (select * from p_parkingspaceoperationhis where id NOT IN(select id from p_parkingspaceoperationlog) order by inTime) ").append("as his group by his.id) as hiss where ");
		if(!checkNull(sDate).equals("") && !checkNull(eDate).equals("")){	//如果开始时间都结束时间不为空就添加时间的查询
			sb.append("hiss.inTime BETWEEN '" + checkNull(sDate) + "' AND '" + checkNull(eDate) + "' AND ");
		}
		sb.append("hiss.carNum LIKE '%" + checkNull(carport) + "%' ");
		
		return sb;
	}
	
	/**
	 * 将查询结果组合成前台页面需要的JSON数据格式
	 * @param list	根据条件查询出来的结果,含分页
	 * @param total	根据条件查询的总记录数
	 * @return
	 */
	private  JSONObject groupJSONObject(List<ParkingData> list, int total){
		JSONArray array = new JSONArray();
		String path = ServletActionContext.getRequest().getContextPath();
		path += "/inversion/picCreate.jsp?ppath=";
		
		for(ParkingData park : list){
			JSONObject jsonObj = new JSONObject();
			jsonObj.element("carNum", park.getCarNum() == null ? "" : park.getCarNum());
			//按楼层和车位编码组合停车位置
			String parkName = park.getParkName() == null ? "" : park.getParkName();
			String areaName = "";
			if(park.getAreaName() != null){
				areaName = "-" + park.getAreaName();
			}
			String code = park.getCode() == null ? "" : "-"+park.getCode();
			jsonObj.element("position", parkName + areaName + code);
			jsonObj.element("parktime", park.getParktime() == null ? "" : groupTime(park.getParktime()));	//将小数点和秒去掉
			try {
				jsonObj.element("img", park.getCarSrc() == null ? "" : path + URLEncoder.encode(park.getCarSrc(), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				Log.log("车的图片路经编码失败!");
			}
			jsonObj.element("psid", park.getPsid());
			jsonObj.element("flash", park.getFlash() == null ? "" : splitMapSrc(park.getFlash()));
			jsonObj.element("detectorCode", park.getDetectorCode());
			array.add(jsonObj);
		}
		
		JSONObject jo = new JSONObject();
		jo.element("total", total);
		jo.element("rows", array);
		return jo;
	}

	/**
	 * 获取目录的大小
	 * @param file
	 * @return
	 */
	public static double getDirSize(File file) {     
        //判断文件是否存在     
        if (file.exists()) {     
            //如果是目录则递归计算其内容的总大小    
            if (file.isDirectory()) {     
                File[] children = file.listFiles();     
                double size = 0;     
                for (File f : children)     
                    size += getDirSize(f);     
                return size;     
            } else {//如果是文件则直接返回其大小,以“兆”为单位   
                double size = (double) file.length() / 1024 / 1024;        
                return size;     
            }     
        } else {     
            Log.log("文件或者文件夹不存在，请检查路径是否正确！");     
            return 0.0;     
        }     
    }
	
	/**
	 * 获取图片路径
	 * @param carSrc
	 * @return
	private String getPicturePath(String carSrc) {
		if(carSrc != null){
			String src = "";
			FileInputStream fis = null;
			FileOutputStream fos = null;
			try {
				src = ServletActionContext.getRequest().getRealPath("") + "/inversion/carSrc/";
				File file = new File(carSrc);
				File dir = new File(src);
				if(!dir.exists()){
					dir.mkdirs();
				}
				fis = new FileInputStream(file);
				long l = new Date().getTime();
				src += l + carSrc.substring(carSrc.lastIndexOf("."), carSrc.length());
				fos = new FileOutputStream(src);
				byte[] b = new byte[fis.available()];
				while(fis.read(b) != -1){
					fos.write(b);
				}
				fos.flush();
				src = ServletActionContext.getRequest().getContextPath() + "/inversion/carSrc/" + l + carSrc.substring(carSrc.lastIndexOf("."), carSrc.length());
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally{
				if(fos != null){
					try {
						fos.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(fis != null){
					try {
						fis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return src;
		} else{
			return null;
		}
	}
	 */

	/**
	 * 根据配置文件的
	 * @param time
	 * @return
	 */
	private String groupTime(String time){
		int formatType = Integer.parseInt(queryProperty(OperatePro.CONFIGPROPERTIES, OperatePro.DATEFORMAT));
		StringBuilder result = new StringBuilder();
		String[] results = splitTime(time);
		switch (formatType) {
		case 0:
			result.append(results[0]).append("-").append(results[1]).append(" ").append(results[2]).append(":").append(results[3]);
			break;
		case 1:
			result.append(results[1]).append("/").append(results[0]).append(" ").append(results[2]).append(":").append(results[3]);
			break;
		case 2:
			result.append(results[0]).append("/").append(results[1]).append(" ").append(results[2]).append(":").append(results[3]);
			break;
		case 3:
			result.append(results[0]).append("月").append(results[1]).append("日  ").append(results[2]).append(":").append(results[3]);
			break;
		default:
			result.append(results[0]).append("-").append(results[1]).append(" ").append(results[2]).append(":").append(results[3]);
			break;
		}
		return result.toString();
	}
	
	/**
	 * 取出需要用到的时期时间
	 * @param time
	 * @return
	 */
	private String[] splitTime(String time){
		String[] results = new String[4];
		String[] dates = time.split(" ")[0].split("-");
		String[] times = time.split(" ")[1].split(":");
		results[0] = dates[1];
		results[1] = dates[2];
		results[2] = times[0];
		results[3] = times[1];
		return results;
	}
	
	/**
	 * 组合路径的方法
	 * @param path
	 * @return
	 */
	private String splitMapSrc(String path){
		String src = "";
		String[] path_split = path.split(ConstantClass.MAP_DIR);
		src = "./" + ConstantClass.MAP_DIR + (path_split.length > 1 ? path_split[1] : "");
		return src;
	}
	
	private String splitMapImg(String path){
		String src = "";
		String[] path_split = path.split(ConstantClass.MAP_DIR);
		//src = "../" + ConstantClass.MAP_DIR + (path_split.length > 1 ? path_split[1] : "");
		src = path_split.length > 1 ? path_split[1].substring(1) : "";
		return src;
	}

	/**
	 * 设置到配置文件config.properties
	 * @param dateParam
	 * @return
	 */
	public boolean setupProperty(String file, String key, String param) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		if(key == null || param == null){
			return false;
		}
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + file);
			Properties prop = new Properties();
			prop.load(fis);
			prop.setProperty(key, param);
			fos = new FileOutputStream(path + file);
			prop.store(fos, null);
		} catch (URISyntaxException e) {
			Log.log("获取path失败============>" + e);
			return false;
		} catch (FileNotFoundException e) {
			Log.log("读取config.properties失败=====>" + e);
			return false;
		} catch (IOException e) {
			Log.log("加载config.properties失败=====>" + e);
			return false;
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
	/**
	 * 获取config.properties参数的方法
	 */
	public String queryProperty(String file, String params){
		FileInputStream fis = null;
		String param = "";
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + file);
			Properties prop = new Properties();
			prop.load(fis);
			param = (String) prop.get(params);
		} catch (URISyntaxException e) {
			Log.log(e);
		} catch (FileNotFoundException e) {
			Log.log(e);
		} catch (IOException e) {
			Log.log(e);
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return param;
	}

	/**
	 * 保存查询机点击
	 * @param searchMachine
	 * @param type
	 * @param carNum
	 * @param pageIndex
	 * @param dimensionName
	 * @return
	 */
	public String clickStatistics(String searchMachine, int type,
			String carNum, int pageIndex, String dimensionName) {
		// TODO Auto-generated method stub
		String hostIp = ServletActionContext.getRequest().getRemoteHost();		//查询机的IP
		hostIp = hostIp.equalsIgnoreCase("0:0:0:0:0:0:0:1") ? "127.0.0.1" : hostIp;
		StringBuilder sb = new StringBuilder();

		if(null != searchMachine && !("").equals(searchMachine)){
			if(type == 1){			//点击了查询路线按钮
				sb.append("update p_searchmachine set searchRoute = searchRoute + 1 ");
				if(null != dimensionName && !("").equals(dimensionName)){	//如果是用二维码查询
					sb.append(", machine='").append(dimensionName).append("' ");
				}
				sb.append(" where id='").append(searchMachine).append("'");
				this.getJt().update(sb.toString());
			}
		} else if(pageIndex == 1){ //如果没有searchMachine且 pi == 1表示初次点击了查询按钮
			Random random = new Random();
			searchMachine = DateUtil.getDateTimeID() + random.nextInt(1000);
			if(type == 5 && (("无牌车").equals(carNum) || ("nocar").equals(carNum))){ //无牌车查询
				type = 6;
			}
			sb.append("insert into p_searchmachine (id, machine, searchMethod, useDateTime) values ('");
			sb.append(searchMachine).append("','").append(hostIp).append("',").append(type).append(",'")
				.append(DateUtil.getCurDateTime()).append("')");
			
			this.getJt().execute(sb.toString());
		}
		//System.out.println("SearchMachine: " + searchMachine);
		return searchMachine;
	}
}	




























