package com.ie.its.inversionsearch;

import java.io.Serializable;
import java.util.List;

import com.ie.frame.ExtendData;

/**
 * 视频探测器运行记录信息
 * @Description: 视频探测器运行记录信息类，记录了探测器的所有信息
 * * @auth: 10917
 * @data: 2014-9-27 下午02:16:04
 */
@SuppressWarnings("serial")
public class UDWorkingRecordData extends ExtendData implements Serializable{

	private String udid;         //视频探测器运行记录表ID
	private String detectorId;   //探测器ID
	private String macAddr;      //探测器物理地址
	private String dateTime;     //记录产生时间
	private String connType;     //连接状态类型,1-上线,2-离线,3-异常断连,4-3分钟连不上主动做离线操作
	private String connDesc;     //状态描述
	private String remark;       //备注
	
	private List connTypeList;   //连接类型列表，用于初始化下拉框
	
	public void setUdid(String udid) {
		this.udid = udid;
	}
	public String getUdid() {
		return udid;
	}
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}
	public String getDetectorId() {
		return detectorId;
	}
	public void setMacAddr(String macAddr) {
		this.macAddr = macAddr;
	}
	public String getMacAddr() {
		return macAddr;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setConnType(String connType) {
		this.connType = connType;
	}
	public String getConnType() {
		return connType;
	}
	public void setConnDesc(String connDesc) {
		this.connDesc = connDesc;
	}
	public String getConnDesc() {
		return connDesc;
	}
	
	//重写toString方法
	@Override
	public String toString() {
		return "UDWorkingRecordData [udid=" + udid + ", detectorId="
				+ detectorId + ", macAddr=" + macAddr + ", dateTime="
				+ dateTime + ", connType=" + connType + ", connDesc="
				+ connDesc +", remark=" + remark + "]";
	}
	public void setConnTypeList(List connTypeList) {
		this.connTypeList = connTypeList;
	}
	public List getConnTypeList() {
		return connTypeList;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
}
