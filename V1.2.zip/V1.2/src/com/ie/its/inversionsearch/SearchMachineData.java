package com.ie.its.inversionsearch;

import java.io.Serializable;

/**
 * 用于统计查询机使用情况
 * @author Mo
 */
@SuppressWarnings("serial")
public class SearchMachineData implements Serializable {

	private String id;			//ID
	private String machine;		//查询机的IP或二维码
	private String searchMethod;	//使用的查询方法
	private String useDateTime;		//点击发生的时间
	private int searchRoute;		//查询路线的点击次数
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		this.machine = machine;
	}
	public String getSearchMethod() {
		return searchMethod;
	}
	public void setSearchMethod(String searchMethod) {
		this.searchMethod = searchMethod;
	}
	public String getUseDateTime() {
		return useDateTime;
	}
	public void setUseDateTime(String useDateTime) {
		this.useDateTime = useDateTime;
	}
	public int getSearchRoute() {
		return searchRoute;
	}
	public void setSearchRoute(int searchRoute) {
		this.searchRoute = searchRoute;
	}
}
