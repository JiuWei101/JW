package com.ie.its.inversionsearch;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import net.sf.json.JSONObject;

public class SerachMachineOperation {
	private static Map<String, String> searchMachineTime=new HashMap<String, String>();
	private static Map<String, Integer> searchMachineStatus=new HashMap<String, Integer>();
	private static int status=0;
	
	public static Map<String, String> getSearchMachineTime() {
		return searchMachineTime;
	}
	public static void setSearchMachineTime(Map<String, String> searchMachineTime) {
		SerachMachineOperation.searchMachineTime = searchMachineTime;
	}
	public static Map<String, Integer> getSearchMachineStatus() {
		return searchMachineStatus;
	}
	public static void setSearchMachineStatus(Map<String, Integer> searchMachineStatus) {
		SerachMachineOperation.searchMachineStatus = searchMachineStatus;
	}
	public static boolean isInDb(String ip){
		boolean flag=false;
		return  flag;
	}
	public static void setStatus(int status) {
		SerachMachineOperation.status = status;
	}
	public static int getStatus() {
		return status;
	}
	public DataSource getDataSource(){
		WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
		DataSource ds = (DataSource)wac.getBean("dataSource");		
		return ds;
	}
	
//	public void addMachineStatus(String ip, int status){
//		searchMachineStatus.put(ip, status);
//	}
	
}
