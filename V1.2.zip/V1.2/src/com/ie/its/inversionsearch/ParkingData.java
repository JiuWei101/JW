package com.ie.its.inversionsearch;

import java.io.Serializable;

import com.ie.frame.ExtendData;
/**
 * 车位信息
 * @author mo
 */
@SuppressWarnings("serial")
public class ParkingData extends ExtendData implements Serializable {
	
	private String psid; 	//停车信息表ID
	private String detectorId; //探测器ID
	private String code;	//车位编码
	private String carNum;	//车牌号码
	private String carSrc;	//图片路径
	private String parktime;	//停车时间，最后更新时间
	private String parkName;	//地图名,停车场名字,楼层名
	private String flash;	//地图具体信息
	private String langCode; //多语言代码
	private String imgPath; //地图图片
	private String inTime;	//开始时间		用于标识车位流水记录和流水历史记录的两个字段的...
	private String outTime;	//结束时间
	private String areaName; 	//探测器物理分区名称
	private double x_axis;	//X坐标
	private double y_axis;	//y坐标
	private double vertical_x_axis;	//垂直X坐标
	private double vertical_y_axis;	//垂直y坐标
	private String onepoint_id;		//最近线段一个点id
	private String anopoint_id;		//最近线段另一个点id
	private String detectorCode;
	
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public String getOnepoint_id() {
		return onepoint_id;
	}
	public void setOnepoint_id(String onepoint_id) {
		this.onepoint_id = onepoint_id;
	}
	public String getAnopoint_id() {
		return anopoint_id;
	}
	public void setAnopoint_id(String anopoint_id) {
		this.anopoint_id = anopoint_id;
	}
	private String mapId;
	
	public String getPsid() {
		return psid;
	}
	public void setPsid(String psid) {
		this.psid = psid;
	}
	public String getDetectorId() {
		return detectorId;
	}
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getCarSrc() {
		return carSrc;
	}
	public void setCarSrc(String carSrc) {
		this.carSrc = carSrc;
	}
	public String getParktime() {
		return parktime;
	}
	public void setParktime(String parktime) {
		this.parktime = parktime;
	}
	public String getParkName() {
		return parkName;
	}
	public void setParkName(String parkName) {
		this.parkName = parkName;
	}
	public String getFlash() {
		return flash;
	}
	public void setFlash(String flash) {
		this.flash = flash;
	}

	public String getLangCode() {
		return langCode;
	}

	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public double getX_axis() {
		return x_axis;
	}

	public void setX_axis(double x_axis) {
		this.x_axis = x_axis;
	}

	public double getY_axis() {
		return y_axis;
	}

	public void setY_axis(double y_axis) {
		this.y_axis = y_axis;
	}

	public double getVertical_x_axis() {
		return vertical_x_axis;
	}

	public void setVertical_x_axis(double vertical_x_axis) {
		this.vertical_x_axis = vertical_x_axis;
	}

	public double getVertical_y_axis() {
		return vertical_y_axis;
	}

	public void setVertical_y_axis(double vertical_y_axis) {
		this.vertical_y_axis = vertical_y_axis;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getDetectorCode() {
		return detectorCode;
	}
	public void setDetectorCode(String detectorCode) {
		this.detectorCode = detectorCode;
	}
	@Override
	public String toString() {
		return "ParkingData [psid=" + psid + ", detectorId=" + detectorId
				+ ", code=" + code + ", carNum=" + carNum + ", carSrc="
				+ carSrc + ", parktime=" + parktime + ", parkName=" + parkName
				+ ", flash=" + flash + ", langCode=" + langCode + ", imgPath="
				+ imgPath + ", inTime=" + inTime + ", outTime=" + outTime
				+ ", areaName=" + areaName + ", x_axis=" + x_axis + ", y_axis="
				+ y_axis + ", vertical_x_axis=" + vertical_x_axis
				+ ", vertical_y_axis=" + vertical_y_axis + ", onepoint_id="
				+ onepoint_id + ", anopoint_id=" + anopoint_id
				+ ", detectorCode=" + detectorCode + ", mapId=" + mapId + "]";
	}
}
