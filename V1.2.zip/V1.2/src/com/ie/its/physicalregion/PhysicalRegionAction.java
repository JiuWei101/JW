/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.physicalregion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;

//命名空间
@Namespace("/physical_region")
public class PhysicalRegionAction extends ExtendActionSupport {
	
	private PhysicalRegionData data;
	@Autowired
	private PhysicalRegionService phyRegService;
	
	
	public PhysicalRegionData getData() {
		return data;
	}
	public void setData(PhysicalRegionData data) {
		this.data = data;
	}
	public PhysicalRegionAction(){
		if(data == null){
			data = new PhysicalRegionData();
		}
	}
	/**
     * Description :查询．
     * @throws :Exception
     */
	@Action(value="list",results={@Result(name="success",location="/physical_region/list.jsp")})
	public String list(){
		data = phyRegService.list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	/**
     * Description :新建．
     * @throws :Exception
     */
	@Action(value="create",results={@Result(name="create",location="/physical_region/create.jsp")})
	public String create(){
		//设置多语言
		setLang(data);
		data.setStatus("1");
		data.setStatusList(DisposalCode.getCode("status", this.request.getSession().getAttribute("lang").toString()));
		return ConstantClass.ACTION_CREATE;
	}
	
	/**
     * Description :保存．
     * @throws :Exception
     */
	@Action(value="save",results={@Result(type="json")})
	public void map_save(){
		JSONObject json =  new JSONObject();
		
		try{
			data = phyRegService.physical_save(data);
			if(data == null){
				json.element("success", false);
			}else{
				json.element("success", true);
			}
			
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	/**
     * Description :编辑．
     * @throws :Exception
     */
	@Action(value="edit",results={@Result(name="edit",location="/physical_region/edit.jsp")})
	public String edit(){
		phyRegService.get(data);
		
		//设置多语言
		setLang(data);
		data.setStatusList(DisposalCode.getCode("status", this.request.getSession().getAttribute("lang").toString()));
		data.setOldName(data.getPhysicalRegionName());
		
		return ConstantClass.ACTION_EDIT;
	}
	
	/**
     * Description :更新．
     * @throws :Exception
     */
	@SuppressWarnings("unchecked")
	@Action(value="update",results={@Result(type="json")})
	public void update(){	
		JSONObject json =  new JSONObject();
		
		try{
			if(data.getOldName().equals(data.getPhysicalRegionName())){
				boolean suc = phyRegService.physical_update(data);
				if(suc)
					json.element("success", true);
				else{
					json.element("success", false);//alert_physicalregion_have_map_association
					Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
					json.element("ex", m.get("alert_physicalregion_have_map_association").toString());
				}
			}else{
				if(phyRegService.readIsExits(data)){
					boolean suc = phyRegService.physical_update(data);
					if(suc)
						json.element("success", true);
					else{
						json.element("success", false);
						Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
						json.element("ex", m.get("alert_physicalregion_have_map_association").toString());
					}
				}else{
					json.element("success", false);
					Map m = (Map)(((Map) data.getLang_switch().get(request.getSession().getAttribute("lang"))).get("common"));
					json.element("ex", m.get("alert_physicalregion_already_exists").toString());
				}			
			}
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
	
		setJsonRes(json);
	}
	/**
     * Description :删除物理区域．
     * @throws :Exception
     */
	@Action(value="delete",results={@Result(type="json")})
	public void map_delete(){		
		JSONObject json =  new JSONObject();
		
		try{
			phyRegService.physical_delete(data);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}

	
	
}
