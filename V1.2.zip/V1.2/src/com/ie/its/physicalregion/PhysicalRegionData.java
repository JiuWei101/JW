/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.physicalregion;

import java.util.List;

import com.ie.frame.ExtendData;

public class PhysicalRegionData extends ExtendData{
	private String id;
	private String physicalRegionName;			//停车场物理区域名
	private String physicalRegionCode;			//停车场物理区域编码
	private String status;						//状态
	private String notes;						//备注
	private List statusList;					//状态下拉框
	private String oldName;                     //修改前物理区域名
	
	public String getOldName() {
		return oldName;
	}
	public void setOldName(String oldName) {
		this.oldName = oldName;
	}
	public List getStatusList() {
		return statusList;
	}
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	public String getPhysicalRegionName() {
		return physicalRegionName;
	}
	public void setPhysicalRegionName(String physicalRegionName) {
		this.physicalRegionName = physicalRegionName;
	}
	public String getPhysicalRegionCode() {
		return physicalRegionCode;
	}
	public void setPhysicalRegionCode(String physicalRegionCode) {
		this.physicalRegionCode = physicalRegionCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
