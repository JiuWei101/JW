package com.ie.its.physicalregion;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.lineconfig.LineConfigData;
import com.ie.its.screenconfig.ScreenData;

public class PhysicalRegionSql extends ExtendSql{
	/**
     * Description :查询．
     * @param  :PhysicalRegionData,String
     * @return :String
     */
	public String list(PhysicalRegionData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*) from p_physicalregion ";
		}else{
			querySql += "select  id,physicalRegionName,physicalRegionCode,status,notes  from p_physicalregion";
		}
		
		
		return querySql;
	}
	
	/**
     * Description :保存．
     * @param  :PhysicalRegionData
     * @return :String
     */
	public String save(PhysicalRegionData data) {
		String insertSql = "";
		
		insertSql += "insert into p_physicalregion(id,physicalRegionName,physicalRegionCode,status,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getPhysicalRegionName()) + ",";
		insertSql += Util.toSqlVal(data.getPhysicalRegionCode()) + ",";
		insertSql += Util.toSqlVal(data.getStatus()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		
		Log.log(insertSql);
		return insertSql;
	}
	
	/**
     * Description :获得信息．
     * @param  :PhysicalRegionData
     * @return :String
     */
	public String get(PhysicalRegionData data) {
		String querySql = "";
		
		querySql += "select id,physicalRegionName,physicalRegionCode,status,notes from p_physicalregion where id=";
		querySql += Util.toSqlVal(data.getId());
		
		
		return querySql;
	}
	
	/**
     * Description :更新．
     * @param  :PhysicalRegionData
     * @return :String
     */
	public String update(PhysicalRegionData data) {
		String updateSql = "";
		
		updateSql += "update p_physicalregion set physicalRegionName =";
		updateSql += Util.toSqlVal(data.getPhysicalRegionName());
		updateSql += ",physicalRegionCode=" + Util.toSqlVal(data.getPhysicalRegionCode());
		updateSql += ",status=" + Util.toSqlVal(data.getStatus());
		updateSql += ",notes=" + Util.toSqlVal(data.getNotes());
		
		
		updateSql += " where id =" + Util.toSqlVal(data.getId());
		
		Log.log(updateSql);
		return updateSql;
	}
	
	/**
     * Description :删除．
     * @param  :PhysicalRegionData
     * @return :String
     */
	public String delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_physicalregion where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}

	/**
	 * 检验当前的物理区域是否有地图
	 * @param data
	 * @return
	 */
	public String check(PhysicalRegionData data) {
		String querySql = " select count(*) from p_map where physicalRegionId = " + Util.toSqlVal(data.getId());
		return querySql;
	}

	public String read(PhysicalRegionData data) {
		String querySql = "select count(*) count from p_physicalregion "
			+ " where physicalRegionName = " + toSqlVal(data.getPhysicalRegionName());
		querySql += " and id !=" + toSqlVal(data.getId());
		return querySql;
	}

}
