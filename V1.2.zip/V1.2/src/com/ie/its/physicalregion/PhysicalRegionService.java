/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.physicalregion;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendRowMapperObj;
import com.ie.frame.ExtendService;
import com.ie.its.controllerconfig.ControllerData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.lineconfig.LineConfigData;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class PhysicalRegionService extends ExtendService {
	private PhysicalRegionSql phyRegSql;
	
	public PhysicalRegionService(){
		phyRegSql = new PhysicalRegionSql();
	}


	/**
     * Description :查询．
     * @param  :PhysicalRegionData
     * @return :PhysicalRegionData
     * @throws :Exception
     */
	public PhysicalRegionData list(PhysicalRegionData data) {
		//获得数量
		int count = this.getJt().queryForInt(phyRegSql.list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <PhysicalRegionData>rows = this.getJt().<PhysicalRegionData>queryForListExt(phyRegSql.list(data, ""), 
				data.getStart(), data.getLimit(),PhysicalRegionData.class);
		
		//转换编码
		for(PhysicalRegionData tempData:rows){
			tempData.setStatus(DisposalCode.getCodeName(tempData.getStatus(), "status", this.getUserinfo().getLang()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :保存．
     * @param  :PhysicalRegionData
     * @return :PhysicalRegionData
     * @throws :Exception
     */
	public PhysicalRegionData physical_save(PhysicalRegionData data) {
		data.setId(PrimaryId.getId());
		int queryForInt = this.getJt().queryForInt(phyRegSql.read(data));
		if(queryForInt >= 1){
			return null;
		}else{
			getJt().execute(phyRegSql.save(data));
			return data;
		}
		
		
	}
	
	/**
     * Description :获得信息．
     * @param  :PhysicalRegionData
     * @return :PhysicalRegionData
     * @throws :Exception
     */
	public PhysicalRegionData get(PhysicalRegionData data) {
		getJt().queryForObjectExt(phyRegSql.get(data), data);
		
		return data;
	}
	
	/**
     * Description :更新．
     * @param  :PhysicalRegionData
     * @return :PhysicalRegionData
     * @throws :Exception
     */
	public boolean physical_update(PhysicalRegionData data) {
		
		int queryForInt = getJt().queryForInt(phyRegSql.check(data));
		if(queryForInt > 0 && "0".equals(data.getStatus())){  //有地图
			return false;
		}else{   //无地图
			int i = this.getJt().queryForInt(phyRegSql.read(data));
			if(i >= 1){
				return false;
			}else{
				//getJt().execute(phyRegSql.save(data));
				getJt().execute(phyRegSql.update(data));
				return true;
			}
		}
		
	}
	
	public boolean readIsExits(PhysicalRegionData data) {
		int queryForInt = getJt().queryForInt(phyRegSql.read(data));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
		
	}
	/**
     * Description :删除．
     * @param  :PhysicalRegionData
     * @return :PhysicalRegionData
     * @throws :Exception
     */
	public PhysicalRegionData physical_delete(PhysicalRegionData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		String [] mapPath = new  String[id.length];
		
		
		//删除数据库记录
		for(int i = 0;i < id.length;i++){
			sql[i] = phyRegSql.delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		
		
		
		return data;
	}
	

}
