package com.ie.its.mapmonitor;

import static com.ie.common.Util.isCon;
import static com.ie.common.Util.toSqlVal;
import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.controllerdebugtask.ControllerData;

public class MapMonitorSql extends ExtendSql{
	
	
	/**
     * Description :获得车位信息．
     * @param  :MapMonitorData
     * @return :String
     */
	public String get_parking_mess(MapMonitorData data) {
		String querySql = "";
		
		querySql += "select d.code as detector_code,d.enable as enable,p.code as parkingSpace_code,p.spotTypeNow,d.status,p.inuse,p.notes,date_format(p.updateDate,'%Y-%m-%d %H:%i:%s') as updateDate," +
				"substring(timediff(curtime(),p.useTime), 1,instr(timediff(curtime(),p.useTime),':')-1) +  datediff(curdate(),p.useDate) * 24 as zhanyong,p.plateno,p.picturepath "  ;
		querySql += " from p_detector d left join p_parkingspace p on d.id=p.detectorId  where 1=1"  ;
		if(isCon(data.getDetector_code())){
			querySql += " and d.code = "+toSqlVal(data.getDetector_code());
			querySql += " and d.mapId = "+toSqlVal(data.getMap_id());
		}
		return querySql;
	}
	/**
	 * 获得查询机数据
	 */
	public String get_machine_mess(MapMonitorData data){
		String querySql = "select s.name as code,s.id as id,s.status as status,m.id as map_id,m.name as map_name" +
				" from p_pathnodeinfohead s,p_map m where s.mapId=m.id and ifcarsearchpc='1'";
		if(isCon(data.getSearchMachineCode())){
			querySql+=" and s.code = "+toSqlVal(data.getSearchMachineCode());
		}
		if(isCon(data.getMap_id())){
			querySql+=" and m.id = "+toSqlVal(data.getMap_id());
		}
		Log.log(querySql);
		return querySql;
	}
	/**
	 * 取引导分区总数
	 * @return
	 */
	public String get_guideRegion_total(String map_id){
		String querySql = "";
		querySql +="select pg.name as region_name,pg.code as region_code,count(pd.guideRegionId) as totalSum";
		querySql +=	" from p_guideregion pg";
		querySql +=	" left join p_detector pd on pg.id=pd.guideRegionId";
		querySql +=	" where pg.regionType=pd.detectorTypeId ";
//		querySql +=	" where pg.regionType=pd.detectorTypeId and pg.deleteFlag='0' ";
//		querySql +=	" and pd.mapId ="+toSqlVal(map_id);		//去除map_id查询条件，引导屏可以绑定其他地图引导区域
		querySql +=	" group by pd.guideRegionId order by pg.code";
		return querySql;
	}
	
	
	/**
	 * 获得屏分区剩余数
	 * @return
	 */
	public String get_screen_currSum(String screen_code,String map_id){
		String querySql = "select psn.mapId,psn.code,ps.* from p_screenregion ps " ;
			querySql += " left join p_screen psn on ps.screenId = psn.id where 1=1 ";
			querySql += " and psn.code=" +toSqlVal(screen_code);
			querySql += " and psn.mapId=" +toSqlVal(map_id);
			querySql += " order by ps.id";
		return querySql;
	}
	
	/**
	 * 获得屏信息
	 * @return
	 */
	public String get_screen_mess(MapMonitorData data){
		String querySql = "select s.code as screen_code,s.id as screen_id,s.enable as screen_enable,m.id as map_id,m.name as map_name,s.contentFormat,s.status as screen_status" +
				" from p_screen s,p_map m where s.mapId=m.id";
		if(isCon(data.getScreen_code())){
			querySql+=" and s.code = "+toSqlVal(data.getScreen_code());
		}
		if(isCon(data.getMap_id())){
			querySql+=" and m.id = "+toSqlVal(data.getMap_id());
		}
		//System.out.println("---屏数据---"+querySql);
		return querySql;
	}
	
//	/**
//	 * 获取地图数据
//	 * @param MapMonitorData
//	 * @return
//	 */
//	public String getMapData(MapMonitorData data){
//		String querySql = "";
//		String map_id = data.getMap_id();
//		querySql += "select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='0' and p.spotTypeNow='0'" +
//				" group by p.inuse,p.spotTypeNow";
//		querySql += " union all select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='0' and p.spotTypeNow='1'" +
//				" group by p.inuse,p.spotTypeNow";
//		querySql += " union all select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='0' and p.spotTypeNow='2'" +
//				" group by p.inuse,p.spotTypeNow";
//		querySql += " union all select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='1' and p.spotTypeNow='0'" +
//				" group by p.inuse,p.spotTypeNow";
//		querySql += " union all select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='1' and p.spotTypeNow='1'" +
//				" group by p.inuse,p.spotTypeNow";
//		querySql += " union all select count(p.inuse&&p.spotTypeNow) as data_count,p.inuse,p.spotTypeNow,m.parkingSum " +
//				" from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where 1=1" +
//				" and m.id = "+toSqlVal(map_id)+" and p.inuse='1' and p.spotTypeNow='2'" +
//				" group by p.inuse,p.spotTypeNow";
//		return querySql;
//	}
	
	public String initCarStatus(String map_id){
		String querySql = "";
		querySql += "select d.code as detector_code,p.inuse,p.spotTypeNow,p.notes,d.status,m.parkingSum," +
					" substring(timediff(curtime(),p.useTime), 1,instr(timediff(curtime(),p.useTime),':')-1) +  datediff(curdate(),p.useDate) * 24 as zhanyong" +
					" from p_map m"+
					" inner join p_detector d on m.id=d.mapId" +
					" inner join p_parkingspace p on d.id=p.detectorId where 1=1 and d.enable = '1'";
		if(isCon(map_id)){
			querySql +=" and m.id = "+toSqlVal(map_id);
		}
		querySql +=" order by d.code";
		//System.out.println("---单个地图车位信息---"+querySql);
		return querySql;
	}
	public String getCarStatus(){
		String querySql = "";
		querySql += "select (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.spotTypeNow='0' and d.enable = '1') as zong_lin,"+ 
		" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.inuse='0' and p.spotTypeNow='0' and d.status='0' and d.enable = '1') as sheng_lin,"+
		" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.spotTypeNow='1' and d.enable = '1') as zong_gu,"+
		" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.inuse='0' and p.spotTypeNow='1' and d.status='0' and d.enable = '1') as sheng_gu,"+
		" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.spotTypeNow='2' and d.enable = '1') as zong_yu,"+
		" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where p.inuse='0' and p.spotTypeNow='2' and d.status='0' and d.enable = '1') as sheng_yu"+
		" from DUAL";
		//System.out.println("----所有地图数据---"+querySql);
		return querySql;
	}
	public String getSCarData(String map_id){
		String querySql = "";
		if(isCon(map_id)){
			querySql += "select (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.spotTypeNow='0' and d.enable = '1') as zong_lin,"+ 
			" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.inuse='0' and p.spotTypeNow='0' and d.status='0' and d.enable = '1') as sheng_lin,"+
			" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.spotTypeNow='1' and d.enable = '1') as zong_gu,"+
			" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.inuse='0' and p.spotTypeNow='1' and d.status='0' and d.enable = '1') as sheng_gu,"+
			" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.spotTypeNow='2' and d.enable = '1') as zong_yu,"+
			" (select count(*) from p_detector d right join p_map m on m.id=d.mapId left join p_parkingSpace p on d.id=p.detectorId where m.id = '"+map_id+"' and p.inuse='0' and p.spotTypeNow='2' and d.status='0' and d.enable = '1') as sheng_yu"+
			" from DUAL";
		}
		//System.out.println("----单个地图数据---"+querySql);
		return querySql;
	}
	public String getChaoshi(){
		String querySql = "select timeOut as chaoshi,timeToCount from p_parking";
		return querySql;
	}
	
	public String getScreenTaskContent(String screen_id){
		String sql = "";
		sql += "select ps.content as screen_content " +
				"from p_screentask ps " +
				"where ps.screenId="+toSqlVal(screen_id)+" and ps.runState='1'";
		return sql;
	}
	
	public String getChaoshi(String code){
		String querySql = "";
		querySql +="select datediff(curdate(),ps.useDate )*24+timediff(curtime(),ps.useTime) " +
				"from p_parkingspace ps where ps.id='20120311111528000010'";
		return querySql;
	}
	
	/**
	 * 根据屏ID取屏参数里的屏宽度值
	 * @param screen_id
	 * @return
	 */
	public String getScreenwidth(String screen_id){
		String querySql = "";
		querySql +="select psv.value as screen_width " +
				"from p_screentypepara pst " +
				"left join p_screenparavalue psv on pst.id=psv.screenTypeParaId " +
				"where pst.code='Led_w' and psv.screenId="+toSqlVal(screen_id);
		return querySql;
	}
	
	public String getScreenParas(String screen_id){
		String querySql = "";
		querySql +="select pst.code as code, psv.value as value " +
				"from p_screentypepara pst " +
				"left join p_screenparavalue psv on pst.id=psv.screenTypeParaId " +
				"where psv.screenId="+toSqlVal(screen_id);
		return querySql;
	}
	public String getCommunStatus() {
		String querySql = "select stateTime from p_parking ";
		return querySql;
	}

	public String getDetector(String logic_name) {
		String querySql = "select  addr,replace(code,'.','_') as code from p_detector " +
				" where guideRegionId = ( select id from p_guideregion " +
				"where name = " + Util.toSqlVal(logic_name) + ")";
		System.out.println("--------"+querySql);
		return querySql;
	}
	
	public String getDetector(MapMonitorData data){
		String querySql = "select controllerId as controllerId , addr as addr from p_detector where code = "+Util.toSqlVal(data.getDetector_code())+" and mapId = "+Util.toSqlVal(data.getMap_id());
		return querySql;
	}
	
	public String checkTask(ControllerData data){
		String querySql = "select count(*) from p_debugtasklist where controllerId = "+Util.toSqlVal(data.getControllerId())+" and sendcontent = "+Util.toSqlVal(data.getSendcontent());
		return querySql;
	}
	
	public String saveParkingspaceTask(ControllerData data){
		String querySql = " insert into p_debugtasklist values ( "
		+ Util.toSqlVal(data.getId()) +", "
		+ Util.toSqlVal(data.getControllerId()) +", "
		+ Util.toSqlVal(data.getTaskname()) +", "
		+ Util.toSqlVal(data.getFuncode()) +", "
		+ Util.toSqlVal(data.getSendcontent()) +", "
		+ Util.toSqlVal(data.getExpectreturn()) +", "
		+ Util.toSqlVal(data.getOperator()) +", "
		+ Util.toSqlVal(DateUtil.getCurDateTime()) +", "
		+ Util.toSqlVal(data.getRunstate()) +", "
		+ Util.toSqlVal(data.getNotes()) +") ";
		return querySql;
	}
}
