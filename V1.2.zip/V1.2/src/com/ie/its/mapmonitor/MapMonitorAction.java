/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 地图管理
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.mapmonitor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageService;
import com.ie.its.screenlogic.ScreenLogicService;

//命名空间
@Namespace("/mapmonitor")
//@Results({@Result(name="list",location="/task_screen/screen_list.jsp"),@Result(name="ok",location="/success.jsp"),
//	@Result(name="screen_list",location="list.action",type="redirect")})
public class MapMonitorAction extends ExtendActionSupport {
	
	private MapMonitorData data;
	@Autowired
	private MapMonitorService mapmonitorService;
	private String monitor;	//前台连接配置参数
	@Autowired
	private ScreenLogicService screenlogicService;
	
	public MapMonitorData getData() {
		return data;
	}
	public void setData(MapMonitorData data) {
		this.data = data;
	}
	public MapMonitorAction(){
		if(data == null){
			data = new MapMonitorData();
		}
	}
	
	/**
	 * 实时监控界面初始化
     * Description :
     * @throws :Exception
     */
	@Action(value="monitor_main",results={@Result(name="success",location="/map_monitor/monitor_index.jsp")})
	public String monitor_main(){
		String map_id = request.getParameter("map_id");

		data.setMap_id(map_id);
		mapmonitorService.setMapNameList(data);
		String sysModel = mapmonitorService.queryForSystemModel();
		data.setSysModel(sysModel);//当前系统类型
		//设置多语言
		data.setLang(this.request.getSession().getAttribute("lang").toString());
		setLang(data);
		//this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		return "success";
	}
	
	/**
	 * 读取MonitorInfo.xml配置文件的信息
     * Description :
     * @throws :Exception
     */
	@Action(value="readMonitorXml",results={@Result(type="json")})
	public void readMonitorXml(){
		String monitors = mapmonitorService.parserXml();
		JSONObject jo = new JSONObject();
		jo.element("monitor", monitors);
		setJsonRes(jo);
	}
	
	/**
	 * 前台连接配置参数插入到ＸＭＬ文件
     * Description :
     * @throws :Exception
     */
	@Action(value="insertMonitorXml",results={@Result(type="json")})
	public void insertMonitorXml(){
		System.out.println(monitor);
		boolean flag = mapmonitorService.insertMonitorXml(monitor);
		JSONObject jo = new JSONObject();
		jo.element("flag", flag);
		setJsonRes(jo);
	}
	
	/**
     * Description :新建引导屏计划．
     * @throws :Exception
     */
	@Action(value="getLogicInfo",results={@Result(type="json")})
	public void getLogicInfo(){
		String logic_name = request.getParameter("logic_name");
		
		
		JSONObject json = mapmonitorService.getLogicInfo(logic_name);
		
		setJsonRes(json);
	}

	/**
	 * 获得停车位信息
	 */
	@Action(value="get_parking_mess",results={@Result(type="json")})
	public void get_parking_mess(){
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		if(Util.isCon(data.getDetector_code())&&Util.isCon(data.getMap_id())){
			data.setDetector_code(data.getDetector_code().replace("_", "."));
			data = mapmonitorService.get_parking_mess(data,lang);
			if(Util.isCon(data.getPicturepath())){
				String path = ServletActionContext.getRequest().getContextPath();
				path += "/inversion/picCreate.jsp?ppath=";
				data.setPicturepath(path + data.getPicturepath());
			}
		}
		JSONObject json =  new JSONObject();
		json.element("success", true);
		json.element("mapData", data);
		setJsonRes(json);
	}
	
	/**
	 * 获取引导屏信息
	 */
	@Action(value="get_screen_mess",results={@Result(type="json")})
	public void get_screen_mess(){
		JSONObject jobj = new JSONObject();
		String regionCode = "";
		String lang =request.getSession().getAttribute("lang").toString();
		if(Util.isCon(data.getScreen_code())&&Util.isCon(data.getMap_id())){
			data = mapmonitorService.get_screen_mess(data,lang);
			//p_screen 是否启用
			String screen_enable = data.getScreen_enable() == null?"":data.getScreen_enable();
			if(Util.isCon(data.getScreen_code())&&Util.isCon(data.getMap_id())&&Util.isCon(data.getContentFormat())){
				jobj = mapmonitorService.changeContentFormat(data.getMap_id(), data.getScreen_code(), data.getContentFormat());
			}else{
				jobj.element("temp", "");
				jobj.element("srcTemp", "");
			}
			//screen_enable 0 不启用 1启用
			if(screen_enable.equals("0")){//取 p_screentask content
				regionCode = mapmonitorService.getScreenTaskContent(data);
			}else{// 取 contentFormat
				regionCode = jobj.getString("temp");
			}
			
//			int num1 = regionCode.indexOf("↑");
//			int num2 = regionCode.indexOf("↓");
//			if(num1!=-1){
//				regionCode = regionCode.replace(regionCode.substring(num1, num1+1), "↑&nbsp;&nbsp;");
//			}
//			if(num2!=-1){
//				regionCode = regionCode.replace(regionCode.substring(num2, num2+1), "↓&nbsp;&nbsp;");
//			}
//			System.out.println("屏"+data.getScreen_code()+"显示信息："+regionCode);
//			System.out.println("屏"+data.getScreen_code()+"预览信息："+jobj.getString("srcTemp"));
		}
		JSONObject json =  new JSONObject();
		json.element("success", true);
		json.element("mapData", data);
		json.element("regionCode", regionCode);
		json.element("srcRegionCode", jobj.getString("srcTemp"));
		setJsonRes(json);
	}
	
	/**
	 * 获取与引导屏相关的探测器区域信息
	 */
	@Action(value="get_screen_relation_mess",results={@Result(type="json")})
	public void get_screen_relation_mess(){
		JSONObject jobj = new JSONObject();
		if(Util.isCon(data.getScreen_code())&&Util.isCon(data.getMap_id())&&Util.isCon(data.getDirection())){
			jobj = screenlogicService.getDetectors(data.getScreen_code(), "mapMonitor",data.getDirection());
		}else{
			jobj.element("success", false);
		}
		setJsonRes(jobj);
	}
	/**
	 * 获取监控界面所需车位数据
	 */
	@Action(value="getMapMonitorData",results={@Result(type="json")})
	public void getMapMonitorData(){
		JSONObject json =  new JSONObject();
		JSONObject ajson =  new JSONObject();
		String lang = request.getSession().getAttribute("lang").toString();
		if(Util.isCon(data.getMap_id()) && Util.isCon(data.getMap_name()) && lang!=""){
 			ajson = mapmonitorService.getMapMonitorData(data,lang);
		}
		json.element("success", true);
		json.element("mapData", ajson);
		setJsonRes(json);
	}	
	/**
	 * 获取监控界面所需统计数据
	 */
	@Action(value="getSAMapData",results={@Result(type="json")})
	public void getSAMapData(){
		JSONObject json =  new JSONObject();
		JSONObject ajson =  new JSONObject();
			ajson = mapmonitorService.getSAMapData(data);
		json.element("success", true);
		json.element("mapData", ajson);
		setJsonRes(json);
	}		
	/**
	 * 判断通讯程序
	 * @throws Exception
	 */
	@Action(value="communication_status",results={@Result(type="json")})
	public void communication_status() throws Exception{
		
		boolean communStatus = mapmonitorService.getCommunStatus();
		JSONObject json =  new JSONObject();
		json.element("success", communStatus);
		json.element("lang", request.getSession().getAttribute("lang").toString());
		setJsonRes(json);
	}
	
	@Action(value="sendparkingspacetask",results={@Result(type="json")})
	public void send_parkingspace_task(){
		data.setLang(this.request.getSession().getAttribute("lang").toString());
		data.setDetector_code(data.getDetector_code().replace("_", "."));
		JSONObject obj = mapmonitorService.sendparkingspacetask(data);
		setJsonRes(obj);
	}
	
	public static void main(String[] args) throws Exception {
		
		String regionCode="\\R↑[A,B]\\R←[B,X]";
		int num1 = regionCode.indexOf("↑");
		int num2 = regionCode.indexOf("↓");
		if(num1!=-1){
			System.out.println(regionCode.substring(num1, num1+1));
			regionCode = regionCode.replaceAll(regionCode.substring(num1, num1+1), "↑&nbsp;&nbsp;");
			
		}
		if(num2!=-1){
			regionCode = regionCode.replace(regionCode.substring(num2, num2+1), "↓&nbsp;");
		}
		System.out.println(regionCode);
	}
	public String getMonitor() {
		return monitor;
	}
	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}
}
