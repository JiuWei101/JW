/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.mapmonitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ie.common.DateUtil;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;
import com.ie.its.controllerdebugtask.ControllerData;
import com.ie.its.inversionsearch.SerachMachineOperation;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.mapmanage.MapManageService;
@Scope("prototype")
@Service
public class MapMonitorService extends ExtendService {
	private MapMonitorSql mapmonitorSql;
	private String monitorInfoFile = "MonitorInfo.xml";
	@Autowired
	private MapManageService mapService;
	public MapMonitorService(){
		mapmonitorSql = new MapMonitorSql();
	}

	/**
	 * 获得停车位信息
	 * @param data
	 * @return
	 */
	public MapMonitorData get_parking_mess(MapMonitorData data,String lang){
		data = this.getJt().<MapMonitorData>queryForObjectExt(mapmonitorSql.get_parking_mess(data), MapMonitorData.class);
		String sysModel = queryForSystemModel();//获取当前系统类型
		if(Util.isCon(data.getDetector_code())){
			String str = data.getDetector_code();
			int length = str.length();
			int modelInt = Integer.parseInt(sysModel);
			String bgn_detector = "";
			String end_detector = "";
			switch(modelInt){
			case 1:bgn_detector = str.substring(0, 3);end_detector = str.substring(3, 6);break;	//超声波
			case 2:bgn_detector = str.substring(0, length-4);end_detector = str.substring(length-3, length);break; //视频
			case 3:bgn_detector = str.substring(0, 6);end_detector = str.substring(6, 9);break;	//地磁
			}
			data.setBgn_detector(bgn_detector);
			data.setEnd_detector(end_detector);
		}

		MapMonitorData sData = this.getJt().<MapMonitorData>queryForObjectExt(mapmonitorSql.getChaoshi(), MapMonitorData.class);
		sData.setCurrent_lang_switch((Map)((Map)(ExtendData.getLang_switch().get(lang))));
		//车位状态信息
		String notes = data.getNotes()!=null?data.getNotes():"";
		String ss = this.get_car_status(data.getStatus(), data.getInuse(), data.getSpotTypeNow(),notes,data.getZhanyong(), sData,lang);
		if(data.getEnable().equals("0")){//探头未启用
			data.setCur_detector_status((String) ((HashMap)sData.getCurrent_lang_switch().get("state")).get("0"+data.getEnable()));
			data.setData_total("0");
		}else{
			data.setCur_detector_status(ss.split(",")[1].toString());
			//借用统计总数据作车位图标帧位置
			data.setData_total(ss.split(",")[0].toString());
		}
//		if(data.getInuse().equals("0")){
//			data.setUpdateDate("");
//		}    //出车也要显示发生时间
		if(!Util.isCon(data.getParkingSpace_code())){
			data.setParkingSpace_code("");
		}
		if(!Util.isCon(data.getSpotTypeNow())){
			data.setSpotTypeNow("");
		}else {
			data.setSpotTypeNow((String) ((HashMap)sData.getCurrent_lang_switch().get("parking_type")).get(data.getSpotTypeNow()));
		}
		if(!Util.isCon(data.getUpdateDate())){
			data.setUpdateDate("");
		}
		return data;
	}

	/**
	 * 取屏信息
	 * @param data
	 * @return
	 */
	public MapMonitorData get_screen_mess(MapMonitorData data,String lang){
		data = this.getJt().queryForObjectExt(mapmonitorSql.get_screen_mess(data), MapMonitorData.class);
		//取屏宽度值
		//String screen_width = this.getJt().queryForObjectExt(mapmonitorSql.getScreenwidth(data.getScreen_id()), 
		//		MapMonitorData.class).getScreen_width();
		//JSONArray jarr = this.getJt().queryForJSONArrayExt(mapmonitorSql.getScreenParas(data.getScreen_id()));
		String screen_width = getRealScreenWidth(data.getScreen_id());
		System.out.println(screen_width);
		if(Util.isCon(screen_width)){
			data.setScreen_width(screen_width);
		}else{
			data.setScreen_width("10");//默认给10
		}
		//多语言
		data.setCurrent_lang_switch((Map)((Map)(ExtendData.getLang_switch().get(lang))));
		data.setCur_screen_status((String) ((HashMap)data.getCurrent_lang_switch().get("detector_status")).get(data.getScreen_status()));
		return data;
	}

	/**
	 * 根据 下面四个参数，转换这位状态代码
	 * @param status 是否故障
	 * @param inuse 是否占用
	 * @param spotTypeNow 车位类型
	 * @param timeout 超时时间(小时)
	 * @return
	 */
	private String get_car_status(String status, String inuse,
			String spotTypeNow,String notes, String zhanyong, MapMonitorData data,String lang){//增加根据lang返回中英文文字
		Double zhan = 0d;
		if(Util.isCon(zhanyong)){
			zhan = Double.parseDouble(zhanyong);
		}
		Double timeout = 0d;
		Double chaoshi = 10d;
		Double timeTocount = 1d;
		if(Util.isCon(data.getChaoshi())){//p_parking表timeOut字段有值时(允许超时时间  单位小时)
			chaoshi = Double.parseDouble(data.getChaoshi());
		}
		if(Util.isCon(data.getTimeToCount())){
			timeTocount = Double.parseDouble(data.getTimeToCount());
		}
		Map map = (Map)data.getCurrent_lang_switch().get("device_status");
		String flag = "";
		if(status.equals("1")){//故障
			flag = "6,"+map.get("fault_or_offline").toString()+",n";
		}else{//正常
			if(inuse.equals("1")){
				if(zhan - chaoshi > 0){
					flag = "5,";
				}else if(timeTocount - zhan > 0){
					flag = "3,";
				}else{
					flag = "4,";
				}
				if(notes.equals("error")){
					flag += map.get("uc_error")+",e";
				}else{
					flag += map.get("occupied")+",n";
				}
			}else{
				if(spotTypeNow.equals("0")){//临时无
					flag="9,";
				}else if(spotTypeNow.equals("2")){//预定无
					flag="8,";
				}else if(spotTypeNow.equals("1")){//固定无
					flag="1,";
				}
				if(notes.equals("error")){
					flag += map.get("uc_error").toString()+",e";
				}else{
					flag += map.get("free").toString()+",n";
				}
			}
		}
		if(flag.equals("")){
			flag="0,"+map.get("default")+",n";
		}
		return flag;
	}

	/**
	 * 转换引导屏分区内容格式
	 * @param map_id
	 * @param screen_code
	 * @param str
	 * @return
	 */
	public JSONObject changeContentFormat(String map_id,String screen_code,String str){
		JSONObject robj = new JSONObject();
		str = str.replace("{", "");//首先去掉“{”
		String temp = str;
		String srcTemp = str;
		//取总数
		JSONArray guideRegion = this.getJt().queryForJSONArrayExt(mapmonitorSql.get_guideRegion_total(map_id));
		JSONArray screen_currentSums = this.getJt().queryForJSONArrayExt(mapmonitorSql.get_screen_currSum(screen_code, map_id));
		while(str.indexOf("]")>0){//一个一个替换
			String currentSum ="";
			String temp_code = str.substring(str.indexOf("[")+1, str.indexOf("]"));//引导分区code
			str = str.substring(str.indexOf("]")+1);
			JSONObject jobj = this.getRegionCodeSize(guideRegion, temp_code);
			int size = jobj.getInt("temp");//总数位数
			String srcNum = jobj.getString("srcNum");//设置显示车位数
			String s2 = "\\["+temp_code+"\\]";//[A]
			for(int i=0; i<screen_currentSums.size(); i++){
				JSONObject tempObj = screen_currentSums.getJSONObject(i);
				String regionCode = tempObj.get("guideRegionCodeList").toString();
				if(temp_code.equals(regionCode)){
					if(Util.isCon(tempObj.get("currentSum").toString())){//currentSum有值时
						currentSum = tempObj.get("currentSum").toString();
						//						if(size>currentSum.length()){//currentSum位数不够，补0
						//							int s = size-currentSum.length();
						//							for(int j=0;j<s;j++){
						//								currentSum = "0"+currentSum;
						//							}
						//						}
					}else{//currentSum为空时，按总数位数补空格
						for(int j=0;j<size;j++){
							currentSum += "&nbsp;";
						}
					}
					temp = temp.replaceFirst(s2, currentSum);//替换[A]-->12
					srcTemp = srcTemp.replaceFirst(s2, srcNum);
				}
			}
		}
		robj.element("temp", temp);
		robj.element("srcTemp", srcTemp);
		return robj;
	}

	public String getScreenTaskContent(MapMonitorData data){
		try{
			data = this.getJt().queryForObjectExt(mapmonitorSql.getScreenTaskContent(data.getScreen_id()), MapMonitorData.class);
			if(!Util.isCon(data.getScreen_content())){
				data.setScreen_content("");
			}
		}catch(Exception e){
			Log.log("取ScreenTaskContent异常");
		}
		return data.getScreen_content();
	}

	/**
	 * 根据引导区域编号取最大位数
	 * @param map_id
	 * @param code
	 * @return
	 */
	public JSONObject getRegionCodeSize(JSONArray guideRegion,String regionCode){
		JSONObject jobj = new JSONObject();
		int temp =0;
		int srcNum = 0;
		int totalCount = 0;
		String[] rArr = regionCode.split(",");
		for(int i=0;i<guideRegion.size();i++){
			String codes = guideRegion.getJSONObject(i).get("region_code").toString();
			String count = guideRegion.getJSONObject(i).get("totalSum").toString();
			/***
			 * 不能使用indexOf，无法处理区分处理A和A1
			 */
			for(int j=0; j<rArr.length; j++){
				if(codes.equals(rArr[j])){
					totalCount += Integer.parseInt(count);
				}
			}
			//			if(regionCode.indexOf(codes) != -1){
			//				totalCount += Integer.parseInt(count);
			//			}
			//			if(codes.equals(regionCode)){
			//				temp = count.length();
			//				srcNum = Integer.parseInt(count);
			//			}
		}
		temp = String.valueOf(totalCount).length();
		srcNum = totalCount;
		jobj.element("temp", temp);
		jobj.element("srcNum", srcNum);
		return jobj;
	}

	/**
	 * 取地图下拉列表值
	 * @param data
	 * @return
	 */
	public MapMonitorData setMapNameList (MapMonitorData data){
		MapManageData mapData = new MapManageData();
		//获得地图list
		try{
			JSONArray jsonArr = JSONArray.fromObject(mapService.map_getMapCode(mapData));
			if(jsonArr.size() > 0){
				List retVal = new ArrayList();
				for(int i=0;i<jsonArr.size();i++){
					HashMap temp = new LinkedHashMap();
					temp.put("code_id", jsonArr.getJSONObject(i).getString("code_id"));
					temp.put("code_name", jsonArr.getJSONObject(i).getString("code_name"));
					retVal.add(temp);
				}
				if(Util.isCon(data.getMap_id())){
					for(int i=0;i<jsonArr.size();i++){
						String temp_map_id = jsonArr.getJSONObject(i).getString("code_id");
						if(data.getMap_id().equals(temp_map_id)){
							data.setMap_name(jsonArr.getJSONObject(i).getString("code_name"));
							data.setMap_path(jsonArr.getJSONObject(i).getString("path"));
						}
					}
					data.setMap_list(retVal);
				}else{
					data.setMap_name(jsonArr.getJSONObject(0).getString("code_name"));
					data.setMap_path(jsonArr.getJSONObject(0).getString("path"));
					data.setMap_id(jsonArr.getJSONObject(0).getString("code_id"));
					data.setMap_list(retVal);
				}
			}else{
				data.setIsExistMap("none");
			}
		}catch(Exception e){
			Log.log("[读取地图信息异常]"+e.getMessage());
		}
		return data;
	}

	public boolean getCommunStatus() throws Exception{
		String timeStr = getJt().queryForObject(mapmonitorSql.getCommunStatus(), String.class);

		if(timeStr == null || timeStr.equals(""))
			return false;
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		long t2 = formatter.parse(DateUtil.getCurDateTime()).getTime();
		long t1 = formatter.parse(timeStr.substring(0, 19)).getTime();
		if(t2 - t1 > (long)1000 * 300 ){  
			return false;
		}
		return true;
	}

	public JSONObject getLogicInfo(String logic_name) {
		JSONObject json = new JSONObject();
		String dataStr = "";
		String[] gStr = logic_name.split(",");
		for(int j=0;j<gStr.length;j++){
			String ln = gStr[j];
			int of = ln.indexOf("(");
			if(of != -1)
				ln = ln.substring(0, of);
			JSONArray array = this.getJt().queryForJSONArrayExt(mapmonitorSql.getDetector(ln));
			for(int i = 0; i < array.size(); i++){
				dataStr += array.getJSONObject(i).getString("code") + ",";
			}
		}
		if(dataStr.length()>1)
			dataStr = dataStr.substring(0, dataStr.length() - 1);
		System.out.println(dataStr);
		json.element("success", true);
		json.element("dataStr", dataStr);
		return json;
	}
	/**
	 * 获取监控界面地图信息（车位和引导屏）
	 * @param data
	 * @param lang
	 * @return
	 */
	public JSONObject getMapMonitorData(MapMonitorData data,String lang){
		JSONObject rjson = new JSONObject();
		//获取单个地图数据，用于刷新单个地图统计数据和车位状态
		ArrayList <MapMonitorData> scarrows = this.getJt().<MapMonitorData>queryForListExt(mapmonitorSql.initCarStatus(data.getMap_id()), MapMonitorData.class);
		MapMonitorData sData = this.getJt().<MapMonitorData>queryForObjectExt(mapmonitorSql.getChaoshi(), MapMonitorData.class);
		sData.setCurrent_lang_switch((Map)((Map)(ExtendData.getLang_switch().get(lang))));
		//引导屏数据
		ArrayList <MapMonitorData> srows = this.getJt().<MapMonitorData>queryForListExt(mapmonitorSql.get_screen_mess(data), MapMonitorData.class);
		//查询机数据
		JSONArray machineary = this.getJt().queryForJSONArrayExt(mapmonitorSql.get_machine_mess(data));
		StringBuffer sb_str = new StringBuffer();
		try{

			for(MapMonitorData temp:scarrows){
				if(Util.isCon(temp.getDetector_code())){
					String code = temp.getDetector_code().replace(".", "_");
					String flag = "";
					String normalorerror = "";
					String inuse = temp.getInuse()!=null?temp.getInuse():"5";
					String spotType = temp.getSpotTypeNow()!=null?temp.getSpotTypeNow():"5";
					String status = temp.getStatus()!=null?temp.getStatus():"5";
					String notes = temp.getNotes()!=null?temp.getNotes():"";
					String ss = this.get_car_status(status, inuse, spotType,notes, temp.getZhanyong(), sData,lang);
					flag = ss.split(",")[0].toString();
					normalorerror = ss.split(",")[2].toString();
					sb_str.append(code).append('|').append(flag).append('|').append(normalorerror).append(';');

				}

			}
			for(MapMonitorData temp:srows){
				String flag = "";
				String status = temp.getScreen_status();
				if(status.equals("1")){//故障
					flag = "2";
				}else{
					flag = "0";
				}
				sb_str.append(temp.getScreen_code()).append('|').append(flag).append(';');
			}
			if(machineary.size() > 0){
				String status = "";
				String flag = "";
				for(int i=0,len=machineary.size(); i<len; i++){
					JSONObject temp = machineary.getJSONObject(i);
					status = temp.getString("status");
					if(status.equals("1")){//离线
						flag = "1";
					}else{
						flag = "0";
					}
					sb_str.append(temp.getString("code")).append("|").append(flag).append(";");
				}
			}
			rjson.put("str", sb_str.toString());
		}catch(Exception e){
			Log.log("[取车位状态数据异常]"+e.getMessage());
		}
		return rjson;
	}


	/**
	 *获取监控界面统计数据（单个和全部）
	 * @param data
	 * @return
	 */
	public JSONObject getSAMapData(MapMonitorData data){
		JSONObject rjson = new JSONObject();
		JSONArray sjarr = new JSONArray();
		JSONArray ajarr = new JSONArray();

		/**单个地图统计数据***/
		int szhan_lin = 0;	//临时占用
		int szhan_gu = 0;	//固定占用
		int szhan_yu = 0;	//预定占用
		int ssheng_lin = 0;	//临时剩余
		int ssheng_gu = 0;	//固定剩余
		int ssheng_yu = 0;	//预定剩余

		/**所有地图统计数据***/
		int zhan_lin = 0;	//临时占用
		int zhan_gu = 0;	//固定占用
		int zhan_yu = 0;	//预定占用
		int sheng_lin = 0;	//临时剩余
		int sheng_gu = 0;	//固定剩余
		int sheng_yu = 0;	//预定剩余
		if(Util.isCon(data.getMap_id())){
			sjarr = this.getJt().queryForJSONArrayExt(mapmonitorSql.getSCarData(data.getMap_id()));
		}
		String stemp_data = "";
		JSONObject sjson = sjarr.getJSONObject(0);

		ssheng_lin = sjson.getInt("sheng_lin");
		szhan_lin = sjson.getInt("zong_lin") - ssheng_lin;

		ssheng_gu = sjson.getInt("sheng_gu");
		szhan_gu = sjson.getInt("zong_gu") - ssheng_gu;

		ssheng_yu = sjson.getInt("sheng_yu");
		szhan_yu = sjson.getInt("zong_yu") - ssheng_yu;

		stemp_data += String.valueOf(ssheng_lin)+","+String.valueOf(ssheng_gu)+","+String.valueOf(ssheng_yu)+",";
		stemp_data += String.valueOf(szhan_lin)+","+String.valueOf(szhan_gu)+","+String.valueOf(szhan_yu);

		ajarr = this.getJt().queryForJSONArrayExt(mapmonitorSql.getCarStatus());
		String atemp_data = "";
		JSONObject ajson = ajarr.getJSONObject(0);

		sheng_lin = ajson.getInt("sheng_lin");
		zhan_lin = ajson.getInt("zong_lin") - sheng_lin;

		sheng_gu = ajson.getInt("sheng_gu");
		zhan_gu = ajson.getInt("zong_gu") - sheng_gu;

		sheng_yu = ajson.getInt("sheng_yu");
		zhan_yu = ajson.getInt("zong_yu") - sheng_yu;

		atemp_data += String.valueOf(sheng_lin)+","+String.valueOf(sheng_gu)+","+String.valueOf(sheng_yu)+",";
		atemp_data += String.valueOf(zhan_lin)+","+String.valueOf(zhan_gu)+","+String.valueOf(zhan_yu);

		rjson.put("stemp_data", stemp_data);
		rjson.put("atemp_data", atemp_data);
		return rjson;
	}

	/**
	 * 将Monitor数据写到xml里
	 * @param monitors
	 * @return
	 */
	public boolean insertMonitorXml(String monitors){
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory
		.newInstance();
		DocumentBuilder builder;
		try {
			String fileName = (getClass().getClassLoader().getResource("").toURI()).getPath() + monitorInfoFile; //要写入的文件
			builder = factory.newDocumentBuilder();
			document = builder.newDocument();
			String[] monitor = monitors.split(",");
			Element root = document.createElement("xml-body");
			document.appendChild(root);
			for(int i = 0; i < 2; i++){
				Element monitorEle = document.createElement("monitor");
				Element monitorId = document.createElement("monitorId");
				monitorId.setTextContent(i + 1 + "");
				monitorEle.appendChild(monitorId);
				Element ipAddress = document.createElement("ipAddress");
				ipAddress.setTextContent(monitor[i * 4 + 0]);
				monitorEle.appendChild(ipAddress);
				Element port = document.createElement("port");
				port.setTextContent(monitor[i * 4 + 1]);
				monitorEle.appendChild(port);
				Element username = document.createElement("username");
				username.setTextContent(monitor[i * 4 + 2]);
				monitorEle.appendChild(username);
				Element password = document.createElement("password");
				password.setTextContent(monitor[i * 4 + 3]);
				monitorEle.appendChild(password);
				root.appendChild(monitorEle);
			}
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(document);
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			PrintWriter pw = new PrintWriter(new FileOutputStream(fileName));
			StreamResult result = new StreamResult(pw);
			transformer.transform(source, result);
			System.out.println("生成XML文件成功!");
		} catch (ParserConfigurationException e1) {
			return false;
		} catch (TransformerConfigurationException e) {
			return false;
		} catch (FileNotFoundException e) {
			return false;
		} catch (TransformerException e) {
			return false;
		} catch (URISyntaxException e) {
			return false;
		}
		return true;
	}

	/**
	 * 解析ＸＭＬ文件
	 * @param fileName
	 */
	public String parserXml() {
		StringBuilder sb = new StringBuilder();
		try {
			String fileName = (getClass().getClassLoader().getResource("").toURI()).getPath() + monitorInfoFile;			//要读的文件
			File file = new File(fileName);
			if(!file.exists()){
				file.createNewFile();
			}
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			NodeList monitors = document.getChildNodes();
			for (int i = 0; i < monitors.getLength(); i++) {
				Node monitor = monitors.item(i);
				NodeList recordInfo = monitor.getChildNodes();
				for (int j = 1; j < recordInfo.getLength(); j++) {
					Node node = recordInfo.item(j);
					NodeList recordInfoMeta = node.getChildNodes();
					if (node.getNodeName().equals("monitor")) {
						for (int k = 1; k < recordInfoMeta.getLength(); k++) {
							String NodeName = recordInfoMeta.item(k)
							.getNodeName();
							String NodeValue = recordInfoMeta.item(k)
							.getTextContent();
							if (!NodeName.equals("#text")) {
								if (NodeName.equals("ipAddress")) {
									sb.append(NodeValue).append(",");
								} else if (NodeName.equals("port")) {
									sb.append(NodeValue).append(",");
								} else if (NodeName.equals("username")) {
									sb.append(NodeValue).append(",");
								} else if (NodeName.equals("password")) {
									sb.append(NodeValue).append(",");
								}
							}
						}
					}
				}
			}
			Log.log("MonitorXML文件解析完毕...");
		} catch (FileNotFoundException e) {
			Log.log("MonitorXML文件不存在...");
		} catch (ParserConfigurationException e) {
			Log.log("MonitorXML文件" + e.getMessage());
		} catch (SAXException e) {
			Log.log("MonitorXML文件" + e.getMessage());
		} catch (IOException e) {
			Log.log("MonitorXML文件" + e.getMessage());
		} catch (URISyntaxException e) {
		}
		return sb.toString().equals("") ? "" : sb.substring(0, sb.length() - 1);
	}

	/**
	 * JSONObject数据转化为满足特定要求的字符串
	 * @param arr
	 * @return
	 */
	public String JSONArrayToString(JSONArray arr){
		String rStr = "";
		if(!arr.isEmpty()){
			int arrSize = arr.size();
			for(int i=0;i<arrSize;i++){
				JSONObject obj = arr.getJSONObject(i);
				Iterator<String> iter = obj.keys();
				while(iter.hasNext()){
					String key = iter.next();
					rStr = key + "," + obj.get(key) +";";
				}
			}
		}
		return rStr;
	}

	public JSONObject sendparkingspacetask(MapMonitorData data){
		JSONObject obj = new JSONObject();
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(data.getLang()))).get("common");
		ControllerData cData = new ControllerData();
		if(Util.isCon(data.getDetector_code()) && Util.isCon(data.getMap_id())){
			data = this.getJt().queryForObjectExt(mapmonitorSql.getDetector(data), MapMonitorData.class);
			cData.setId(PrimaryId.getId());
			cData.setControllerId(data.getControllerId());
			cData.setTaskname("获取单个车位最新状态");
			cData.setFuncode(0xA0);
			cData.setSendcontent("01;A0;"+data.getAddr().substring(1));
			cData.setExpectreturn("01;A0;"+data.getAddr().substring(1));
			cData.setOperator(this.getUserinfo().getId());
			//cData.setCreatetime(DateUtil.getCurDateTime());
			cData.setRunstate("0");
			cData.setNotes("");
			int count = this.getJt().queryForInt(mapmonitorSql.checkTask(cData));
			if(count == 0){
				this.getJt().update(mapmonitorSql.saveParkingspaceTask(cData));
				obj.element("message", map.get("process_success").toString());
			}else{
				obj.element("message", map.get("task_running").toString());
			}
		}
		return obj;
	}

	public String getRealScreenWidth(String screenId){
		String rStr = "";
		if(Util.isCon(screenId)){
			JSONArray jarr = this.getJt().queryForJSONArrayExt(mapmonitorSql.getScreenParas(screenId));
			System.out.println(jarr.toString());
			int fontSize = -1;
			int sWidth = -1;
			for(int i=0; i<jarr.size(); i++){
				JSONObject temp = jarr.getJSONObject(i);
				if(temp.getString("code").equals("Led_w")){
					sWidth = Integer.parseInt(temp.getString("value"), 16);
				}else if(temp.getString("code").equals("font")){
					fontSize = Integer.parseInt(temp.getString("value"), 16);
				}
			}
			switch(fontSize){
			case 0:	rStr = String.valueOf(sWidth);break;//16*16字体
			case 1:	rStr = String.valueOf(sWidth/2);break;//32*32字体
			case 2:	rStr = String.valueOf(sWidth/1.5);break;//24*24字体
			}
		}
		return rStr;
	}
}

