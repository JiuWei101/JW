/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.mapmonitor;

import java.util.List;

import com.ie.frame.ExtendData;

public class MapMonitorData extends ExtendData{

	private String map_name;			//地图名
	private String map_total;			//地图总停车位数
	private String detector_code;		//探测器编号(4419)
	private String parkingSpace_code;	//车位编号
	private String spotTypeNow;			//车位类型
	private String bgn_detector;		//管理器(44)
	private String end_detector;		//探测器(19)
	private String updateDate;			//发生时间
	private String chaoshi;
	private String timeToCount;
	private String zhanyong;			//占用时间
	private String inuse;
	private String status;
	private String notes;		//车位信息备注，现用于标识超声波错误状态

	private List map_list;
	private String map_id;
	private String map_path;
	private String screen_id;
	private String screen_code;
	private String screen_status;
	private String screen_enable;
	private String screen_content;
	private String screen_width;
	private String contentFormat;
	private String cur_detector_status;	//当前车位状态 汉字
	private String cur_screen_status;	//当前屏状态 汉字

	private String data_count;			//分类数据总数
	private String data_total;
	private String parkingSum;

	private String plateno;			//车牌号
	private String picturepath;	    //最新车位图片路径

	private String controllerId;	//管理器id
	private String addr;		//车位编码

	private String direction;		//引导屏某一区域引导方向
	private String enable;			//探头是否启用
	private String searchMachineCode;//查询机编码

	public String getSearchMachineCode() {
		return searchMachineCode;
	}
	public void setSearchMachineCode(String searchMachineCode) {
		this.searchMachineCode = searchMachineCode;
	}

	public String getEnable() {
		return enable;
	}
	public void setEnable(String enable) {
		this.enable = enable;
	}
	public String getControllerId() {
		return controllerId;
	}
	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPlateno() {
		return plateno;
	}
	public void setPlateno(String plateno) {
		this.plateno = plateno;
	}
	public String getPicturepath() {
		return picturepath;
	}
	public void setPicturepath(String picturepath) {
		this.picturepath = picturepath;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getData_total() {
		return data_total;
	}
	public void setData_total(String data_total) {
		this.data_total = data_total;
	}
	public String getParkingSum() {
		return parkingSum;
	}
	public void setParkingSum(String parkingSum) {
		this.parkingSum = parkingSum;
	}
	public String getData_count() {
		return data_count;
	}
	public void setData_count(String data_count) {
		this.data_count = data_count;
	}
	public String getMap_name() {
		return map_name;
	}
	public void setMap_name(String map_name) {
		this.map_name = map_name;
	}
	public String getMap_total() {
		return map_total;
	}
	public void setMap_total(String map_total) {
		this.map_total = map_total;
	}
	public String getDetector_code() {
		return detector_code;
	}
	public void setDetector_code(String detector_code) {
		this.detector_code = detector_code;
	}
	public String getParkingSpace_code() {
		return parkingSpace_code;
	}
	public void setParkingSpace_code(String parkingSpace_code) {
		this.parkingSpace_code = parkingSpace_code;
	}
	public String getBgn_detector() {
		return bgn_detector;
	}
	public void setBgn_detector(String bgn_detector) {
		this.bgn_detector = bgn_detector;
	}
	public String getEnd_detector() {
		return end_detector;
	}
	public void setEnd_detector(String end_detector) {
		this.end_detector = end_detector;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateData) {
		this.updateDate = updateData;
	}
	public String getSpotTypeNow() {
		return spotTypeNow;
	}
	public void setSpotTypeNow(String spotTypeNow) {
		this.spotTypeNow = spotTypeNow;
	}
	public String getZhanyong() {
		return zhanyong;
	}
	public void setZhanyong(String zhanyong) {
		this.zhanyong = zhanyong;
	}
	public String getInuse() {
		return inuse;
	}
	public void setInuse(String inuse) {
		this.inuse = inuse;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getScreen_code() {
		return screen_code;
	}
	public void setScreen_code(String screen_code) {
		this.screen_code = screen_code;
	}
	public String getScreen_content() {
		return screen_content;
	}
	public void setScreen_content(String screen_content) {
		this.screen_content = screen_content;
	}
	public String getScreen_status() {
		return screen_status;
	}
	public void setScreen_status(String screen_status) {
		this.screen_status = screen_status;
	}
	public List getMap_list() {
		return map_list;
	}
	public void setMap_list(List map_list) {
		this.map_list = map_list;
	}
	public String getMap_path() {
		return map_path;
	}
	public void setMap_path(String map_path) {
		this.map_path = map_path;
	}
	public String getContentFormat() {
		return contentFormat;
	}
	public void setContentFormat(String contentFormat) {
		this.contentFormat = contentFormat;
	}
	public String getMap_id() {
		return map_id;
	}
	public void setMap_id(String map_id) {
		this.map_id = map_id;
	}
	public String getScreen_enable() {
		return screen_enable;
	}
	public void setScreen_enable(String screen_enable) {
		this.screen_enable = screen_enable;
	}
	public String getScreen_width() {
		return screen_width;
	}
	public void setScreen_width(String screen_width) {
		this.screen_width = screen_width;
	}
	public String getScreen_id() {
		return screen_id;
	}
	public void setScreen_id(String screen_id) {
		this.screen_id = screen_id;
	}
	public String getChaoshi() {
		return chaoshi;
	}
	public void setChaoshi(String chaoshi) {
		this.chaoshi = chaoshi;
	}
	public String getCur_detector_status() {
		return cur_detector_status;
	}
	public void setCur_detector_status(String cur_detector_status) {
		this.cur_detector_status = cur_detector_status;
	}
	public String getCur_screen_status() {
		return cur_screen_status;
	}
	public void setCur_screen_status(String cur_screen_status) {
		this.cur_screen_status = cur_screen_status;
	}
	public String getTimeToCount() {
		return timeToCount;
	}
	public void setTimeToCount(String timeToCount) {
		this.timeToCount = timeToCount;
	}

}
