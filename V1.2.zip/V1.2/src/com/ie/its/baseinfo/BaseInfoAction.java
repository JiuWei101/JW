/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : jl
 */
package com.ie.its.baseinfo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DateUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.monitor.MonitorService;

//命名空间
@Namespace("/base_info")

public class BaseInfoAction extends ExtendActionSupport {
	
	private BaseInfoData data;
	@Autowired
	private BaseInfoService baseInfoService;
	@Autowired
	private MonitorService m;
	
	
	public BaseInfoData getData() {
		return data;
	}
	public void setData(BaseInfoData data) {
		this.data = data;
	}
	public BaseInfoAction(){
		if(data == null){
			data = new BaseInfoData();
		}
	}
	
	/**
     * Description :基础信息维护．
     * @throws :Exception
     */
	@SuppressWarnings("unchecked")
	@Action(value="base_info",results={@Result(name="success",location="/base_info/base_info.jsp")})
	public String base_info(){
		

		data = baseInfoService.getBaseInfo();
		setLang(data);
		List asList = Util.asListMap("01,02,03,04,05".split(","));
		data.setDataAnalysisTimeList(asList);
		List asList2 = Util.asListMap("1,2,3,4,5".split(","));
		data.setDataAnalysisDaysList(asList2);
		data.setStateList(Util.getCodeList(data, "state"));
		data.setModelList(Util.getCodeList(data, "sys_model"));
		data.setAttribute1(request.getSession().getAttribute("isSuper").toString());
		return SUCCESS;
	}
	
	/**
     * Description :基础信息保存．
     * @throws :Exception
     */
	@Action(value="base_save",results={@Result(type="json")})
	public void base_save() throws Exception{
		JSONObject json = baseInfoService.base_save(data);
		//m.rateTask();
		setLang(data);
		setJsonRes(json);
	}
	
	/**
     * Description :
     * @throws :Exception
     */
	@Action(value="base_setup",results={@Result(type="json")})
	public void base_setup() throws Exception{
		JSONObject json = baseInfoService.base_setup(data);
		
		setJsonRes(json);
	}
	/**
     * Description :．
     * @throws :Exception
     */
	@Action(value="flash_setup",results={@Result(type="json")})
	public void flash_setup(){
		data= baseInfoService.getBaseInfo();
		JSONObject jobj = new JSONObject();
		jobj.element("timeToCount", data.getTimeToCount());
		jobj.element("timeOut", data.getTimeOut());
		setJsonRes(jobj);
	}
	
}
