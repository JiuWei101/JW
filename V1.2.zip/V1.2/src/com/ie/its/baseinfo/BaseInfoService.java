/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.baseinfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendRowMapperObj;
import com.ie.frame.ExtendService;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class BaseInfoService extends ExtendService {
	
	private BaseInfoSql baseInfoSql;
	
	public BaseInfoService(){
		baseInfoSql = new BaseInfoSql();
	}

	public JSONArray chart_list() {
		JSONArray arr = new JSONArray();
		arr = this.getJt().queryForJSONArrayExt("");
		
		return arr;
	}

	public JSONObject base_save(BaseInfoData data) {
		int queryForInt = this.getJt().queryForInt(baseInfoSql.base_query(data.getId()));
		if(queryForInt==0)   //新增
			this.getJt().update(baseInfoSql.base_save(data));
		else   //更新
			this.getJt().update(baseInfoSql.base_update(data));
		JSONObject json = new JSONObject();
		json.element("success", true);
		return json;
		
	}

	public BaseInfoData getBaseInfo() {
		BaseInfoData queryForObject = getJt().queryForObjectExt(baseInfoSql.getBaseInfo(), BaseInfoData.class);
//		if(queryForObject.getUseColor().equals("1"))
//			queryForObject.setUseColor("true");
//		else
//			queryForObject.setUseColor("false");
		return queryForObject;
		
	}

	public JSONObject base_setup(BaseInfoData data) {
		getJt().update(baseInfoSql.getSetup(data));
		JSONObject json = new JSONObject();
		json.element("success", true);
		return json;
	}
	
	
	
	

}
