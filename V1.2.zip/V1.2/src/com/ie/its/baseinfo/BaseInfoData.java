/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.baseinfo;

import java.util.List;

import com.ie.frame.ExtendData;

public class BaseInfoData extends ExtendData{
	private String id;
	private String name;				//停车场名称
	private String telephone;				//电话
	private int refreshTime;
	private int spacingInterval;
	private String person;			//联系人
	private String addr;				//地址
	private String timeOut;				//超时时间
	private String timeToCount;
	private String useColor;
	private String dataAnalysisTime;
	private int faultJudgmentNum;
	private int faultJudgmentInterval;
	private int exitscreenCarportNum;  //出口屏保护车位数
	private String exitscreenContent;  //出口屏保护内容
	
	private List dataAnalysisTimeList;
	private int dataAnalysisDays;
	private List dataAnalysisDaysList;
	
	private String expireBecomeRed;
	private String attribute1;	//系统版本号（一个系统一个编号）
	private String attribute2;	//系统应用模式（1为超声波，2为视频，3为地磁）
	private String attribute3;
	private String attribute4;
	private String attribute5;
	private List stateList;
	private List modelList;    //应用模式下拉列表值
	public List getModelList() {
		return modelList;
	}
	public void setModelList(List modelList) {
		this.modelList = modelList;
	}
	public String getExpireBecomeRed() {
		return expireBecomeRed;
	}
	public void setExpireBecomeRed(String expireBecomeRed) {
		this.expireBecomeRed = expireBecomeRed;
	}
	public String getAttribute1() {
		return attribute1;
	}
	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}
	public String getAttribute2() {
		return attribute2;
	}
	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}
	public String getAttribute3() {
		return attribute3;
	}
	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}
	public String getAttribute4() {
		return attribute4;
	}
	public void setAttribute4(String attribute4) {
		this.attribute4 = attribute4;
	}
	public String getAttribute5() {
		return attribute5;
	}
	public void setAttribute5(String attribute5) {
		this.attribute5 = attribute5;
	}
	public List getStateList() {
		return stateList;
	}
	public void setStateList(List stateList) {
		this.stateList = stateList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(String timeOut) {
		this.timeOut = timeOut;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getRefreshTime() {
		return refreshTime;
	}
	public void setRefreshTime(int refreshTime) {
		this.refreshTime = refreshTime;
	}
	public int getSpacingInterval() {
		return spacingInterval;
	}
	public void setSpacingInterval(int spacingInterval) {
		this.spacingInterval = spacingInterval;
	}
	public String getTimeToCount() {
		return timeToCount;
	}
	public void setTimeToCount(String timeToCount) {
		this.timeToCount = timeToCount;
	}
	public String getUseColor() {
		return useColor;
	}
	public void setUseColor(String useColor) {
		this.useColor = useColor;
	}
	public String getDataAnalysisTime() {
		return dataAnalysisTime;
	}
	public void setDataAnalysisTime(String dataAnalysisTime) {
		this.dataAnalysisTime = dataAnalysisTime;
	}
	public int getDataAnalysisDays() {
		return dataAnalysisDays;
	}
	public void setDataAnalysisDays(int dataAnalysisDays) {
		this.dataAnalysisDays = dataAnalysisDays;
	}
	public List getDataAnalysisTimeList() {
		return dataAnalysisTimeList;
	}
	public void setDataAnalysisTimeList(List dataAnalysisTimeList) {
		this.dataAnalysisTimeList = dataAnalysisTimeList;
	}
	public List getDataAnalysisDaysList() {
		return dataAnalysisDaysList;
	}
	public void setDataAnalysisDaysList(List dataAnalysisDaysList) {
		this.dataAnalysisDaysList = dataAnalysisDaysList;
	}
	public int getFaultJudgmentNum() {
		return faultJudgmentNum;
	}
	public void setFaultJudgmentNum(int faultJudgmentNum) {
		this.faultJudgmentNum = faultJudgmentNum;
	}
	public int getFaultJudgmentInterval() {
		return faultJudgmentInterval;
	}
	public void setFaultJudgmentInterval(int faultJudgmentInterval) {
		this.faultJudgmentInterval = faultJudgmentInterval;
	}
	public int getExitscreenCarportNum() {
		return exitscreenCarportNum;
	}
	public void setExitscreenCarportNum(int exitscreenCarportNum) {
		this.exitscreenCarportNum = exitscreenCarportNum;
	}
	public String getExitscreenContent() {
		return exitscreenContent;
	}
	public void setExitscreenContent(String exitscreenContent) {
		this.exitscreenContent = exitscreenContent;
	}
	
	
}
