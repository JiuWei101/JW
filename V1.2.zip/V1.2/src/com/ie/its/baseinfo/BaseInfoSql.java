package com.ie.its.baseinfo;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.ctrlmanage.CtrlManageData;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;

public class BaseInfoSql extends ExtendSql{
	/**
     * Description :查询地图．
     * @param  :MapManageData,String
     * @return :String
     */
	public String timeout_list(BaseInfoData data,String type) {
		String querySql = "";
		
		
		return querySql;
	}

	public String base_save(BaseInfoData data) {
		String insertSql = "insert into p_parking(id,name,person,telephone,addr,spacingInterval" +
				",refreshTime,dataAnalysisTime,dataAnalysisDays,exitscreenCarportNum,exitscreenContent,fault_judgment_num,fault_judgment_interval,expireBecomeRed,attribute1,attribute2,attribute3,attribute4,attribute5) ";
			insertSql += " values(" + Util.toSqlVal(PrimaryId.getId()) + "," +Util.toSqlVal(data.getName()) ;
			insertSql += ","+ Util.toSqlVal(data.getPerson()) + "," + Util.toSqlVal(data.getTelephone()) ;
			insertSql += "," + Util.toSqlVal(data.getAddr());
			insertSql += "," + data.getSpacingInterval() + "," + data.getRefreshTime() ;
			insertSql += "," + data.getDataAnalysisTime() + "," + data.getDataAnalysisDays();
			insertSql += "," + data.getExitscreenCarportNum() + "," + Util.toSqlVal(data.getExitscreenContent());
			insertSql += "," + data.getFaultJudgmentNum() + "," + data.getFaultJudgmentInterval();
			insertSql += "," + toSqlVal(data.getExpireBecomeRed()) + "," + toSqlVal(data.getAttribute1());
			insertSql += "," + toSqlVal(data.getAttribute2()) + "," + toSqlVal(data.getAttribute3());
			insertSql += "," + toSqlVal(data.getAttribute4()) + "," + toSqlVal(data.getAttribute5());
			insertSql += ")";
		return insertSql;
	}

	public String base_query(String id) {
		String querySql = "select count(*) from p_parking where id = " + Util.toSqlVal(id);
		return querySql;
	}

	public String base_update(BaseInfoData data) {
		String updateSql = "update p_parking set ";
		 	updateSql += " name = " + Util.toSqlVal(data.getName()) + ",";
		 	updateSql += " person = " + Util.toSqlVal(data.getPerson()) + ",";
		 	updateSql += " telephone = " + Util.toSqlVal(data.getTelephone()) + ",";
		 	updateSql += " addr = " + Util.toSqlVal(data.getAddr()) + ",";
		 	updateSql += " spacingInterval = " + data.getSpacingInterval() + ",";
		 	updateSql += " dataAnalysisTime = " + Util.toSqlVal(data.getDataAnalysisTime()) + ",";
		 	updateSql += " dataAnalysisDays = " + data.getDataAnalysisDays() + ",";
		 	updateSql += " faultJudgmentNum = " + data.getFaultJudgmentNum() + ",";
		 	updateSql += " faultJudgmentInterval = " + data.getFaultJudgmentInterval() + ",";
		 	updateSql += " exitscreenCarportNum = " + data.getExitscreenCarportNum() + ",";
		 	updateSql += " exitscreenContent = " + Util.toSqlVal(data.getExitscreenContent()) + ",";
		 	updateSql += " expireBecomeRed = " + Util.toSqlVal(data.getExpireBecomeRed()) + ",";
		 	updateSql += " refreshTime = " + data.getRefreshTime() + "," ;
		 	updateSql += " attribute2 = " + toSqlVal(data.getAttribute2());
		 	updateSql += " where id = " + Util.toSqlVal(data.getId());
		 	
		return updateSql;
	}

	public String getBaseInfo() {
		String querySql = "select * from p_parking limit 1";
		return querySql;
	}

	public String getSetup(BaseInfoData data) {
		String updateSql = "update p_parking set timeout = " + data.getTimeOut();
			updateSql += ",timetocount = " + data.getTimeToCount();
			updateSql += ",useColor = " + data.getUseColor();
		return updateSql;
	}
	

	
}
