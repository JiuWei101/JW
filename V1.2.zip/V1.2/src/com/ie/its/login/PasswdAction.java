package com.ie.its.login;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.IService;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.example.BookData;
import com.ie.its.example.UploadData;
@Namespace("/passwd")
public class PasswdAction extends ExtendActionSupport {
	
	private UserInfo user;
	@Autowired
	private PasswdService passwdService;


	public PasswdAction(){
		if(user == null){
			user = new UserInfo();
		}
	}	
	
	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public PasswdService getPasswdService() {
		return passwdService;
	}

	public void setPasswdService(PasswdService passwdService) {
		this.passwdService = passwdService;
	}
	@Action(value="passwd_save",results={@Result(type="json")})
	public void passwd_save(){
		String is_valid = (String) passwdService.updateData(user);
		JSONObject json = new JSONObject();
		if("1".equals(is_valid)) {			
			// 密码修改成功		
			//this.setMsg("修改成功。");
			json.element("message", "修改成功。");
		}else {
			// 密码修改失败			
			//this.setMsg("修改失败。");	
			json.element("message", "修改失败。");
		}				
		setJsonRes(json);
	}

	@Action(value="passwd_read",results={@Result(name="read",location="/system_manage/passwd.jsp")})
	public String read(){
		user = (UserInfo)passwdService.readData(user);
		setLang(user);
		return "read";
	}
}
