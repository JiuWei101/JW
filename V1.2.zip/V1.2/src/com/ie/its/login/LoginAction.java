/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 用户登录
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
 * Modified By              : yc
 */
package com.ie.its.login;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.jms.Session;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.IService;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.frame.LocalSessionUtil;
import com.ie.its.operation.OperationData;
//命名空间
@Namespace("/system")
@Results({@Result(name="login",location="/system_manage/login.jsp"),@Result(name="index",location="index.action",type="redirect")})
public class LoginAction extends ExtendActionSupport {

	private UserInfo user;
	@Autowired
	private LoginService loginService;
	
	private String username;    // 网站登录用户名
	private String passwd;      // 网站登录密码
	private Map langmap;
	private List langlist;
	private String text;		//检测是否超级登陆，是的话为su
	private String version;	//版本号
	private String remark;			//标记,用于区分是否noake
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	private String user_name;
	private String password;
	private String check_code;
	private String switch_lang;
	private String save;
	private String lang;
	private String language;
	private String login;
	private String login_img;
	private String username_img;
	private String password_img;
	private String logout_img;
	private String login_title;
	private String date;
	
	private String relogin;
	private ExtendData data;

	public String getRelogin() {
		return relogin;
	}

	public void setRelogin(String relogin) {
		this.relogin = relogin;
	}

	public Map getLangmap() {
		return langmap;
	}

	public void setLangmap(Map langmap) {
		this.langmap = langmap;
	}

	public List getLanglist() {
		return langlist;
	}

	public void setLanglist(List langlist) {
		this.langlist = langlist;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCheck_code() {
		return check_code;
	}

	public void setCheck_code(String check_code) {
		this.check_code = check_code;
	}

	public String getSwitch_lang() {
		return switch_lang;
	}

	public void setSwitch_lang(String switch_lang) {
		this.switch_lang = switch_lang;
	}

	public String getSave() {
		return save;
	}

	public void setSave(String save) {
		this.save = save;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	/**
	 * Description :点击登录按钮验证用户合法
	 * @return String
	 * @throws ParseException 
	 */
	@Action(value="loginaction",interceptorRefs={@InterceptorRef("defaultStack")},
	results={@Result(name="success",location="/index.jsp"),@Result(name="password",location="/system_manage/passwd.jsp")})
	public String valid_User() throws ParseException {
		String isSuper = user.getText();//如果是超级登陆方式 值为”su“
		if(user == null){
			return ConstantClass.NO_SESSION;
		}
		request.getSession().setAttribute("lang", user.getLang());
		JSONObject jo = loginService.getRegister(user.getLang());
		user.setRegister_message(jo.getString("message"));
		user.setWarning_message(jo.getString("warning_message"));
		request.getSession().setAttribute("register", jo.getString("key"));
		String authenCode = (String) request.getSession().getAttribute(ConstantClass.SESSION_AUTHEN_CODE);
		//System.out.println("user.getLang()=" + user.getLang());
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(user.getLang()))).get("common");
		setLanguage((String)map.get("language"));
		setUser_name((String)map.get("user_name"));
		setPassword((String)map.get("password"));
		setCheck_code((String)map.get("check_code"));
		setSwitch_lang((String)map.get("switch_name"));
		setSave((String)map.get("remember"));
		setLogin((String)map.get("login"));
		setLanglist(ExtendData.getLang_list());
		for(int i = 0; i < getLanglist().size(); i++){
			if(user.getLang().equals(((LanguageData)getLanglist().get(i)).getCode_id())){
				setLogin_img(((LanguageData)getLanglist().get(i)).getLogin_img());
				setUsername_img(((LanguageData)getLanglist().get(i)).getUsername_img());
				setPassword_img(((LanguageData)getLanglist().get(i)).getPassword_img());
				logout_img = ((LanguageData)getLanglist().get(i)).getLogout_img();
				request.getSession().setAttribute("logout_img", logout_img);
				break;
			}
		}
		if(!isSuper.equals("su")){//如果是超级用户，不校验验证码，add by wangj 20130116
			if(user.getAuthen_code().equals("")){
				
				this.setMsg(getText("login.valcodenull"));
				return "login";
			}
			if(!user.getAuthen_code().equals(authenCode)){//20110926 暂时取消验证码
				Log.log("校验码输入错误");
				this.setMsg(getText("login.valcodeerr"));
				return "login";
			}
		}
		// 验证用户合法性,1合法,0非法
		String is_valid = (String) loginService.listDataSuper(user,isSuper);//超级登陆方法
		if("1".equals(is_valid)) {
			//user.setUser_name("admin");
			// 设置session超时时间
			request.getSession().setAttribute("isSuper", isSuper);//将isSuper放入session，add by wangj 20130116
			request.getSession().setMaxInactiveInterval(ConstantClass.SESSION_TIME);
			request.getSession().setAttribute(ConstantClass.SESSION_USERNAME,user);
			request.getSession().setAttribute(ConstantClass.SESSION_PATH,request.getRealPath("/"));
			
			user.setCurrent_lang_switch((Map)((Map)(ExtendData.getLang_switch().get(lang))));
			if(user.getState().equals("00")){
				//第一次登陆，跳转到“修改密码”页面，提示进行密码修改。			
				return "password";
			}else{	
				
				return "index";
			}
		
		}else {
			Log.log("登录验证失败转到input");
			this.setMsg(getText("login.err"));
			return "login";
		}
	}
		
	/**
	 * Description :进入登录页面
	 * @return String
	 */
	@Action(value="login",interceptorRefs={@InterceptorRef("defaultStack")})
	public String toLogin() {
		request.getSession().setMaxInactiveInterval(ConstantClass.UNLOGIN_SESSION_TIME);
		request.getSession().setAttribute(ConstantClass.SESSION_USERNAME, null);
		request.getSession().setAttribute(ConstantClass.SESSION_RIGHT, null);
		request.getSession().setAttribute(ConstantClass.SESSION_VIEWINFO, null);
		request.getSession().setAttribute(ConstantClass.SESSION_REMARK, null);
		request.getSession().setAttribute("ghc", "ghc");
		if(lang==null || lang.equals("")){			
			lang = "86";
		}
		if(user == null){
			user = new UserInfo();
		}
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("common");
		setLanguage((String)map.get("language"));
		setUser_name((String)map.get("user_name"));
		setPassword((String)map.get("password"));
		setCheck_code((String)map.get("check_code"));
		setSwitch_lang((String)map.get("switch_name"));
		user.setLang(lang);
		setSave((String)map.get("btn_save"));
		setLogin((String)map.get("login"));
		setLogin_title((String)map.get("login_title"));
		setLanglist(ExtendData.getLang_list());
		for(int i = 0; i < getLanglist().size(); i++){
			if(user.getLang().equals(((LanguageData)getLanglist().get(i)).getCode_id())){
				setLogin_img(((LanguageData)getLanglist().get(i)).getLogin_img());
				setUsername_img(((LanguageData)getLanglist().get(i)).getUsername_img());
				setPassword_img(((LanguageData)getLanglist().get(i)).getPassword_img());
				break;
			}
		}
		
		request.getSession().setAttribute(ConstantClass.SESSION_REMARK, ((LanguageData)getLanglist().get(0)).getRemark() == null ? "" : ((LanguageData)getLanglist().get(0)).getRemark());
		setRemark(request.getSession().getAttribute(ConstantClass.SESSION_REMARK).toString());
		setLanglist(ExtendData.getLang_list());
		return "login";
	}
	
	/**
	 * Description :进入登录页面
	 * @return String
	 */
	@Action(value="exit",interceptorRefs={@InterceptorRef("defaultStack")})
	public String toExit() {
		request.getSession().setAttribute(ConstantClass.SESSION_USERNAME, null);
		request.getSession().setAttribute(ConstantClass.SESSION_RIGHT, null);
		request.getSession().setAttribute(ConstantClass.SESSION_REMARK, null);
		request.getSession().setAttribute(ConstantClass.SESSION_VIEWINFO, null);
		request.getSession().setAttribute("ghc", "ghc");
		String userId = user.getId();
		return "login";
	}
	
	/**
	 * Description :没有权限返回提示页
	 * @return String
	 */
	@Action(value="noright",results={@Result(name="success",location="/system_manage/noright.jsp")})
	public String toNoright() {
		Log.log("action=LoginAction>" + this.getActionPath());
		return SUCCESS;
	}
	
//	@Action(value="left",results={@Result(name="success",location="/left.jsp")})
	@Action(value="left",results={@Result(type="json")})
	public void toLeft() {
		//首先显示用户名
		JSONObject jsonRes = new JSONObject();
		UserInfo user = ((UserInfo) this.request.getSession().getAttribute(ConstantClass.SESSION_USERNAME));
		this.setUser_name(user.getUser_name());
		OperationData od=new OperationData();
		od.setId(data.getId());
		od.setCurrent_lang_switch((Map) od.getLang_switch().get(request.getSession().getAttribute("lang")));
		od.setUserinfo(LocalSessionUtil.currentUserInfo());
		loginService.getSubMenu(od);
		ArrayList list = (ArrayList)(od.getPer_data());
		Log.log("----->" + list.size());
		jsonRes.element("subMenu", list);
		setJsonRes(jsonRes);
	}
	
	@Action(value="top",results={@Result(name="success",location="/top.jsp")})
	public String toTop() {
		data=new ExtendData();
		data.setUserinfo((UserInfo) request.getSession().getAttribute(ConstantClass.SESSION_USERNAME));
		data.setCurrent_lang_switch((Map) data.getLang_switch().get(request.getSession().getAttribute("lang")));
		Log.log("toLeft==" + this.getActionPath());
		return SUCCESS;
	}
	/**
	 * 转向index.jsp页面
	 * @return
	 */
	@Action(value="index",results={@Result(name="success",location="/index.jsp")})
	public String toIndex() {
		OperationData od=new OperationData();
		String attribute = request.getSession().getAttribute("logout_img").toString();
		od.setCurrent_lang_switch((Map) od.getLang_switch().get(request.getSession().getAttribute("lang")));
		od.setUserinfo(LocalSessionUtil.currentUserInfo());
		String sysModel = loginService.queryForSystemModel();
		setRemark(request.getSession().getAttribute(ConstantClass.SESSION_REMARK).toString());
		user = (UserInfo) request.getSession().getAttribute(ConstantClass.SESSION_USERNAME);
		user.setLogout_img(attribute);
		user.setSysModel(sysModel);
		user.setModelList(Util.getCodeList(user, "sys_model"));
		setDate(Util.nowDate());
		request.setAttribute("mess",loginService.getFirstMenu(od));
		request.setAttribute("per_data",od.getPer_data() );
		return SUCCESS;
	}
	
	@Action(value="welcome",results={@Result(name="success",location="/welcome.jsp")})
	public String welcome(){
		String lang = request.getSession().getAttribute("lang").toString();
		setRemark(request.getSession().getAttribute(ConstantClass.SESSION_REMARK).toString());
		if(user == null){
			user = new UserInfo();
		}
		user.setLang(lang);
		return SUCCESS;
	}
	/**
	 * Description :进入登录页面
	 * @return String
	 */
	@Action(value="multi_lan_public",
			results={@Result(name="success",location="/system_manage/multi_lan_public.jsp")})
	public String multi_lan_public() {
		data = new ExtendData();
		//设置多语言
		setLang(data);
		return "success";
	}
	
	/**
	 * 保存系统类型
	 * @return
	 */
	@Action(value="saveSystemModel",results={@Result(type="json")})
	public void saveSystemModel(){
		JSONObject jobj = new JSONObject();
		jobj = loginService.saveSystemModel(user);
		setJsonRes(jobj);
	}
	
	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	/**
	 * @return the data
	 */
	public ExtendData getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(ExtendData data) {
		this.data = data;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the login_img
	 */
	public String getLogin_img() {
		return login_img;
	}

	/**
	 * @param login_img the login_img to set
	 */
	public void setLogin_img(String login_img) {
		this.login_img = login_img;
	}

	/**
	 * @return the username_img
	 */
	public String getUsername_img() {
		return username_img;
	}

	/**
	 * @param username_img the username_img to set
	 */
	public void setUsername_img(String username_img) {
		this.username_img = username_img;
	}

	/**
	 * @return the password_img
	 */
	public String getPassword_img() {
		return password_img;
	}

	/**
	 * @param password_img the password_img to set
	 */
	public void setPassword_img(String password_img) {
		this.password_img = password_img;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the login_title
	 */
	public String getLogin_title() {
		return login_title;
	}

	/**
	 * @param login_title the login_title to set
	 */
	public void setLogin_title(String login_title) {
		this.login_title = login_title;
	}

	public String getLogout_img() {
		return logout_img;
	}

	public void setLogout_img(String logout_img) {
		this.logout_img = logout_img;
	}
	
	//获取系统版本号
	public String getVersion() {
		FileInputStream fis = null;
		try {
			String path = (getClass().getClassLoader().getResource("").toURI())
					.getPath();
			fis = new FileInputStream(path + "config.properties");
			Properties prop = new Properties();
			prop.load(fis);
			this.version = (String) prop.get("version");
		} catch (URISyntaxException e) {
			Log.log(e);
		} catch (FileNotFoundException e) {
			Log.log(e);
		} catch (IOException e) {
			Log.log(e);
		} finally {
			try {
				if (fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return version;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
