/**
 * 
 */
package com.ie.its.login;

/**
 * @author zhaoyan
 *
 */
public class LanguageData {
	private String code_id;				//语言编码
	private String code_name;			//语言名称
	private String remark;				//备注
	private String lang_img;			//语言图片
	private String login_img;			//登录按钮图片
	private String username_img;			//登录按钮图片
	private String password_img;			//登录按钮图片
	private String logout_img;
	/**
	 * @return the code_id
	 */
	public String getCode_id() {
		return code_id;
	}
	/**
	 * @param code_id the code_id to set
	 */
	public void setCode_id(String code_id) {
		this.code_id = code_id;
	}
	/**
	 * @return the code_name
	 */
	public String getCode_name() {
		return code_name;
	}
	/**
	 * @param code_name the code_name to set
	 */
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * @return the lang_img
	 */
	public String getLang_img() {
		return lang_img;
	}
	/**
	 * @param lang_img the lang_img to set
	 */
	public void setLang_img(String lang_img) {
		this.lang_img = lang_img;
	}
	/**
	 * @return the login_img
	 */
	public String getLogin_img() {
		return login_img;
	}
	/**
	 * @param login_img the login_img to set
	 */
	public void setLogin_img(String login_img) {
		this.login_img = login_img;
	}
	/**
	 * @return the username_img
	 */
	public String getUsername_img() {
		return username_img;
	}
	/**
	 * @param username_img the username_img to set
	 */
	public void setUsername_img(String username_img) {
		this.username_img = username_img;
	}
	/**
	 * @return the password_img
	 */
	public String getPassword_img() {
		return password_img;
	}
	/**
	 * @param password_img the password_img to set
	 */
	public void setPassword_img(String password_img) {
		this.password_img = password_img;
	}
	public String getLogout_img() {
		return logout_img;
	}
	public void setLogout_img(String logout_img) {
		this.logout_img = logout_img;
	}
	
}
