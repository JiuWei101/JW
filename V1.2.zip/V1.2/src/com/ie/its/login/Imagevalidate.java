/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 生成图片验证码
 * Version                  : 1.0
 * create date              : 2008.10.22
 * author                   ：国宏超
 */
package com.ie.its.login;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import com.ie.common.ConstantClass;
import com.ie.frame.ExtendActionSupport;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class Imagevalidate extends ExtendActionSupport{

	private static final String CONTENT_TYPE = "image/jpeg"; 
	private static final int WIDTH = 38;
	private static final int HEIGHT = 16;
	private static final int LENGTH = 4;
	
	/**
	 * Description :生成验证码
	 */
	public void getValidateCode() throws IOException{
		response.setContentType(CONTENT_TYPE);
		OutputStream out = response.getOutputStream();
		
		response.setHeader("Pragma","No-cache");
		response.setHeader("Cache-Control","no-cache");
		response.setDateHeader("Expires", 0);
		
		int width = WIDTH; 
		int height = HEIGHT; 
		int length = LENGTH; 
		String sessionName = ConstantClass.SESSION_AUTHEN_CODE; 
		
        //取得随机整数 
		Random ran = new Random(System.currentTimeMillis()); 
		//取除第一位后的指定几位 
		String seed = (ran.nextInt() + "").substring(1, 1 + length); 
        //将取得的保存在session中 
		request.getSession().setAttribute(sessionName, seed); 
		//生成缓冲图象 
		BufferedImage image = new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB); 
        //取得绘图对象 
		Graphics g = image.getGraphics(); 
		g.setColor(new Color(245, 245, 0)); 
		//填充背景色 
		g.fillRect(0, 0, width, height); 
		//设置字体颜色 
		g.setColor(Color.RED); 
		//设置字体样式 
		g.setFont(new Font("Arial", Font.BOLD, 12)); 
		//写入指定文字 
		g.drawString(seed, 4, 13); 
		g.dispose(); 
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out); 
		encoder.encode(image); 
		out.close(); 		
	}
	
	
	public static void main(String[] args) {

	}

}
