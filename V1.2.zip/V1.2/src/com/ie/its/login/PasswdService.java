/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 用户登录
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
 * Modified By              : 国宏超
 */
package com.ie.its.login;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.frame.ExtendService;

public class PasswdService extends ExtendService {
	
	/**
	 * Description 修改密码
	 * @return String
	 */
	@Transactional(readOnly = true)
	public Object updateData(Object ob){
		UserInfo user = (UserInfo)ob;
		String flag = "";
		String encryptPw = Encrypt.EncryptString(user.getOld_password());   // 原密码加密后
		String encryptNewPw = Encrypt.EncryptString(user.getPasswd());    //新密码加密后		
	
		user.setPassword(encryptPw);
		user.setNew_password(encryptNewPw);

		String sql = valid_Sql(user);
		List rows = (ArrayList)getJt().queryForList(sql);
		Iterator it = rows.iterator();

		if(it.hasNext()) { 

			//修改密码
			StringBuffer sb = new StringBuffer();
			sb.append("update sys_user set password = '"+user.getNew_password()+"' ");
			sb.append(",state='01' ");
			sb.append("where user_name = '"+this.getUserinfo().getUser_name()+"' ");
			getJt().update(sb.toString());
			flag="1";
		}else{
			//原密码不正确。
			flag="0";
		}
		return flag;
	}	
	
	/**
	 * Description :生成登录验证sql
	 * @return String
	 */
	public String valid_Sql(UserInfo user){
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT id,user_name,state ");
		sb.append(" FROM sys_user ");
		sb.append(" WHERE user_name = '");
		sb.append(this.getUserinfo().getUser_name());
		sb.append("'");	
		sb.append(" AND password = '");
		sb.append(user.getPassword());
		sb.append("'");	
		
		return sb.toString();
	}
	
	/**
	 * Description 读取用户信息
	 * @return String
	 */
	public Object readData(Object o){
		
		UserInfo user = (UserInfo)o;
		StringBuffer sb = new StringBuffer();
		sb.append("select id,user_name from sys_user ");
		sb.append("where user_name = '" + this.getUserinfo().getUser_name() + "'");
		
		List list = getJt().queryForList(sb.toString());
		Iterator it = list.iterator();
		if(it.hasNext()){
			Map map = (Map)it.next();
			user.setId((String)map.get("id"));
			user.setUser_name((String)map.get("user_name"));		
		}
		return user;
	}		
}
