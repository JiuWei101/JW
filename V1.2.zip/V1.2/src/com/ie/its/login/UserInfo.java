/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 用户信息类
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
 * Modified By              : ghc
 */
package com.ie.its.login;

import java.io.Serializable;
import java.util.List;

import com.ie.frame.ExtendData;


public class UserInfo  extends ExtendData {
	// 用户登录信息
	private String id; // id
	private String user_name; //用户名  登陆名
	private String password; //密码
	private String state; //状态
	private String remark; //备注
	private String text;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	private String authen_code;//校验码
	private String old_password;//旧密码
	private String new_password;//新密码
	private String passwd;// 新密码加密后
	private String logout_img;
	private String register_message;
	private String lang;	//用户语言
	private String warning_message;//注册即将到期提示信息
	private List modelList;			//系统类型列表
	private String menuid;	//当前菜单Id
	private String ip;		//客户端IP
	
	public String getMenuid() {
		return menuid;
	}
	public void setMenuid(String menuid) {
		this.menuid = menuid;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public List getModelList() {
		return modelList;
	}
	public void setModelList(List modelList) {
		this.modelList = modelList;
	}
	public String getWarning_message() {
		return warning_message;
	}
	public void setWarning_message(String warning_message) {
		this.warning_message = warning_message;
	}
	public String getAuthen_code() {
		return authen_code;
	}
	public void setAuthen_code(String authen_code) {
		this.authen_code = authen_code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getOld_password() {
		return old_password;
	}
	public void setOld_password(String old_password) {
		this.old_password = old_password;
	}
	public String getNew_password() {
		return new_password;
	}
	public void setNew_password(String new_password) {
		this.new_password = new_password;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	/**
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}
	/**
	 * @param lang the lang to set
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getLogout_img() {
		return logout_img;
	}
	public void setLogout_img(String logout_img) {
		this.logout_img = logout_img;
	}
	public String getRegister_message() {
		return register_message;
	}
	public void setRegister_message(String register_message) {
		this.register_message = register_message;
	}
	

}