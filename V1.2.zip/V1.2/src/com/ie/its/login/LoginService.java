/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 用户登录
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
 * Modified By              : 国宏超
 */
package com.ie.its.login;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ie.common.BeanUtil;
import com.ie.common.DateUtil;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendData;
import com.ie.frame.ExtendService;
import com.ie.its.operation.OperationData;
import com.ie.its.register.RegisterData;
@Service
public class LoginService extends ExtendService {
	
	/**
	 * Description :点击登录按钮验证用户合法，返回1合法，0不合法
	 * @return String
	 */
	@Transactional(readOnly = true)
	public String listDataSuper(Object ob,String isSuper){
		if(isSuper.equals("su")){//超级登陆方式
			String is_valid = "0";    // 登录验证标志 1合法，0不合法
			UserInfo user = (UserInfo)ob;
			String sql = super_valid_Sql(user);
			List rows = (ArrayList)this.getJt().queryForList(sql);
			Iterator it = rows.iterator();
			if(it.hasNext()) {   
				Map userMap = (Map) it.next();  
				user.setId((String)userMap.get("id"));                       // 人员ID
				user.setUser_name((String)userMap.get("user_name"));         // 姓名
				user.setState((String)userMap.get("state"));
				is_valid = "1";
			}
			return is_valid;
		}else{
			String is_valid = "0";    // 登录验证标志 1合法，0不合法
			UserInfo user = (UserInfo)ob;
			String encryptPw = Encrypt.EncryptString(user.getPassword());    // 加密后密码
			user.setPassword(encryptPw);
			String sql = valid_Sql(user);
			List rows = (ArrayList)this.getJt().queryForList(sql);
			Iterator it = rows.iterator();
			if(it.hasNext()) {   
				Map userMap = (Map) it.next();  
				user.setId((String)userMap.get("id"));                       // 人员ID
				user.setUser_name((String)userMap.get("user_name"));         // 姓名
				user.setState((String)userMap.get("state"));
				is_valid = "1";
			}
			 return is_valid;
		}
		
	   
	}   
	/**
	 * Description :查询用户有权限的一级菜单
	 * @return String
	 */
	@Transactional(readOnly = true)
	public JSONArray getFirstMenu(Object ob){
		String is_valid = "0";    // 登录验证标志 1合法，0不合法
			OperationData o = (OperationData)ob;
			StringBuffer sb=new StringBuffer();
			JSONArray jsonArr = new JSONArray();
			
			//首先取第一层，即不在关系表中有act_id的数据
			if(this.getUserinfo().getUser_name().equals("admin")){
				//模块本身具有权限
				sb.append("select distinct * from ((");
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela ");
				sb.append(" WHERE a.is_model='0' and a.id=rela.act_id and rela.parent_id='00' ) union (");
				//模块的子模块具有权限
				sb.append("SELECT DISTINCT b1.* FROM sys_act a1,sys_act_relation ar1,sys_act b1,sys_act_relation br1 ");
				sb.append(" WHERE a1.is_model='0' and a1.id=ar1.act_id and ar1.parent_id=b1.id and b1.id=br1.act_id and br1.parent_id='00')) t ");
				sb.append("order by sort");
			} else {
				//模块本身具有权限
				sb.append("select distinct * from ((");
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_role_act ra,sys_user_role ur,sys_act_relation rela ");
				sb.append(" WHERE a.id = ra.act_id and ra.role_id = ur.role_id and a.is_model='0' and ur.user_id = '");
				sb.append(this.getUserinfo().getId());
				sb.append("' and a.id=rela.act_id and rela.parent_id='00' ) union (");
				//模块的子模块具有权限
				sb.append("SELECT DISTINCT b1.* FROM sys_act a1,sys_role_act ra1,sys_user_role ur1,sys_act_relation ar1, ");
				sb.append("sys_act b1,sys_act_relation br1 ");
				sb.append(" WHERE a1.id = ra1.act_id and ra1.role_id = ur1.role_id and a1.is_model='0' and ur1.user_id = '");
				sb.append(this.getUserinfo().getId());
				sb.append("' and a1.id=ar1.act_id and ar1.parent_id=b1.id and b1.id=br1.act_id and br1.parent_id='00')) t ");
				sb.append("order by sort");
			}
			Log.log(sb.toString());
			List rows = (ArrayList)this.getJt().queryForList(sb.toString());
			Iterator it = rows.iterator();
			OperationData temp = new OperationData();
			List list = new ArrayList();
			while(it.hasNext()){
				Map map = (Map)it.next();
				temp = new OperationData();
				JSONObject json = new JSONObject();
				
				BeanUtil.setFieldValue(temp, map);

				json.element("id", temp.getId());			//返回菜单具体情况列表 现在只存id  还可以存其对应子菜单数量 以在前台作区分操作
				temp.setModule_name((String) ((Map)o.getCurrent_lang_switch().get("common")).get(temp.getLang_key()));
				list.add(temp);
				jsonArr.add(temp);
			}
	
			o.setPer_data(list);
	    return jsonArr;
	}   
	

	/**
	 * Description :查询用户有权限的菜单
	 * @return String
	 */
	@Transactional(readOnly = true)
	public String getSubMenu(Object ob){
		String is_valid = "0";    // 登录验证标志 1合法，0不合法
		
			OperationData o = (OperationData)ob;
			StringBuffer sb=new StringBuffer();
			if(this.getUserinfo().getUser_name().equals("admin")){
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela ");
				sb.append(" WHERE a.is_model='0' and a.id=rela.act_id and rela.parent_id='");
				sb.append(o.getId());
				sb.append("' order by a.sort");
			} else {
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela,sys_role_act ra,sys_user_role ur ");
				sb.append(" WHERE a.id = ra.act_id and ra.role_id = ur.role_id and a.is_model='0' and ur.user_id = '");
				sb.append(this.getUserinfo().getId());
				sb.append("' and a.id=rela.act_id and rela.parent_id='");
				sb.append(o.getId());
				sb.append("' order by a.sort");
			}
			
			
			List rows = (ArrayList)this.getJt().queryForList(sb.toString());
			Iterator it = rows.iterator();
			OperationData temp = new OperationData();
			List list = new ArrayList();
			while(it.hasNext()){
				Map map = (Map)it.next();
				temp = new OperationData();
				BeanUtil.setFieldValue(temp, map);
				temp.setModule_name((String) ((Map)o.getCurrent_lang_switch().get("common")).get(temp.getLang_key()));
				
				list.add(temp);
			}
			
			for(int i=0;i<list.size();i++){
				OperationData oData=(OperationData)list.get(i);
				sb.setLength(0);
				//取第二层
				
				if(this.getUserinfo().getUser_name().equals("admin")){
					sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela ");
					sb.append(" WHERE a.is_model='0' and a.id=rela.act_id and rela.parent_id='");
					sb.append(oData.getId());
					sb.append("' order by a.sort");
				} else {
					sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela,sys_role_act ra,sys_user_role ur ");
					sb.append(" WHERE a.id = ra.act_id and ra.role_id = ur.role_id and a.is_model='0' and ur.user_id = '");
					sb.append(this.getUserinfo().getId());
					sb.append("' and a.id=rela.act_id and rela.parent_id='");
					sb.append(oData.getId());
					sb.append("' order by a.sort");
				}
				
				Log.log(sb.toString());
				List rows1 = (ArrayList)this.getJt().queryForList(sb.toString());
				Iterator it1 = rows1.iterator();
				OperationData temp1 = new OperationData();
				List list1 = new ArrayList();
				while(it1.hasNext()){
					Map map = (Map)it1.next();
					temp1 = new OperationData();
					BeanUtil.setFieldValue(temp1, map);
					temp1.setModule_name((String) ((Map)o.getCurrent_lang_switch().get("common")).get(temp1.getLang_key()));
					
					list1.add(temp1);
				}
				if(list1.size()>0){
					oData.setSub_module(list1);
				}
			}
			o.setPer_data(list);
			
		//	Log.log("--------->"+list.size());
		
	    return is_valid;
	}   
	
	/**
	 * Description :查询用户有权限的菜单
	 * @return String
	 */
	@Transactional(readOnly = true)
	public String listData(Object ob,String str){
		String is_valid = "0";    // 登录验证标志 1合法，0不合法
		if("left".equals(str)){
			OperationData o = (OperationData)ob;
			StringBuffer sb=new StringBuffer();
			//首先取第一层，即不在关系表中有act_id的数据
			if(this.getUserinfo().getUser_name().equals("admin")){
				//模块本身具有权限
				sb.append("select distinct * from ((");
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela ");
				sb.append(" WHERE a.is_model='0' and a.id=rela.act_id and rela.parent_id='00' ) union (");
				//模块的子模块具有权限
				sb.append("SELECT DISTINCT b1.* FROM sys_act a1,sys_act_relation ar1,sys_act b1,sys_act_relation br1 ");
				sb.append(" WHERE a1.is_model='0' and a1.id=ar1.act_id and ar1.parent_id=b1.id and b1.id=br1.act_id and br1.parent_id='00')) t ");
				sb.append("order by sort");
			} else {
				//模块本身具有权限
				sb.append("select distinct * from ((");
				sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_role_act ra,sys_user_role ur,sys_act_relation rela ");
				sb.append(" WHERE a.id = ra.act_id and ra.role_id = ur.role_id and a.is_model='0' and ur.user_id = '");
				sb.append(this.getUserinfo().getId());
				sb.append("' and a.id=rela.act_id and rela.parent_id='00' ) union (");
				//模块的子模块具有权限
				sb.append("SELECT DISTINCT b1.* FROM sys_act a1,sys_role_act ra1,sys_user_role ur1,sys_act_relation ar1, ");
				sb.append("sys_act b1,sys_act_relation br1 ");
				sb.append(" WHERE a1.id = ra1.act_id and ra1.role_id = ur1.role_id and a1.is_model='0' and ur1.user_id = '");
				sb.append(this.getUserinfo().getId());
				sb.append("' and a1.id=ar1.act_id and ar1.parent_id=b1.id and b1.id=br1.act_id and br1.parent_id='00')) t ");
				sb.append("order by sort");
			}
			Log.log(sb.toString());
			List rows = (ArrayList)this.getJt().queryForList(sb.toString());
			Iterator it = rows.iterator();
			OperationData temp = new OperationData();
			List list = new ArrayList();
			while(it.hasNext()){
				Map map = (Map)it.next();
				temp = new OperationData();
				BeanUtil.setFieldValue(temp, map);
				list.add(temp);
			}
			for(int i=0;i<list.size();i++){
				OperationData oData=(OperationData)list.get(i);
				sb.setLength(0);
				//取第二层
				if(this.getUserinfo().getUser_name().equals("admin")){
					sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela ");
					sb.append(" WHERE a.is_model='0' and a.id=rela.act_id and rela.parent_id='");
					sb.append(oData.getId());
					sb.append("' order by a.sort");
				} else {
					sb.append("SELECT DISTINCT a.* FROM sys_act a,sys_act_relation rela,sys_role_act ra,sys_user_role ur ");
					sb.append(" WHERE a.id = ra.act_id and ra.role_id = ur.role_id and a.is_model='0' and ur.user_id = '");
					sb.append(this.getUserinfo().getId());
					sb.append("' and a.id=rela.act_id and rela.parent_id='");
					sb.append(oData.getId());
					sb.append("' order by a.sort");
				}
				Log.log(sb.toString());
				List rows1 = (ArrayList)this.getJt().queryForList(sb.toString());
				Iterator it1 = rows1.iterator();
				OperationData temp1 = new OperationData();
				List list1 = new ArrayList();
				while(it1.hasNext()){
					Map map = (Map)it1.next();
					temp1 = new OperationData();
					BeanUtil.setFieldValue(temp1, map);
					list1.add(temp1);
				}
				if(list1.size()>0){
					oData.setSub_module(list1);
				}
			}
			o.setPer_data(list);
		}
	    return is_valid;
	}   
	
	/**
	 * Description :生成登录验证sql
	 * @return String
	 */
	public String valid_Sql(UserInfo user){
		String querySql = "select * from sys_user where user_name = "
			+ Util.toSqlVal(user.getUser_name()) + " and password = "
			+ Util.toSqlVal(user.getPassword()) + " and state = '01' ";
		
		return querySql;
	}
	
	/**
	 * Description :生成超级登录验证sql
	 * @return String
	 */
	public String super_valid_Sql(UserInfo user){
		String querySql = "select * from sys_user where user_name = "
			+ Util.toSqlVal(user.getUser_name())  + " and state = '01' ";
		return querySql;
	}
	
	public JSONObject getRegister(String lang) {
		String querySql = "select *  from p_register ";
		String message = "";
		String warning_message = "";
		JSONObject jo = new JSONObject();
		String key = "";
		RegisterData data = getJt().queryForObjectExt(querySql, RegisterData.class);
		Map map = (Map)((Map)(ExtendData.getLang_switch().get(lang))).get("common");
		if(data.getId() != null && !data.getId().equals("")){
			//Registered. 已注册 Unregistered 未注册 Out of date 已过期  Valid until
			/**
			 * 如果日期为1999-01-01，表示系统被锁，需重新获取注册文件
			 * 如果日期为2013-01-01，表示系统未注册
			 * add by wangj 2013-01-10
			 * */
			String validityDate = data.getValidityDate().substring(0, 10);//系统当前注册到期时间
			if(validityDate.equalsIgnoreCase("1999-01-01")){
				message = (String) map.get("locked_message");
				key = "0";
			}
			else
			{
				if(validityDate.equalsIgnoreCase("2013-01-01")){
					message = (String) map.get("unregistered");
					key = "0";
				}
				else{
					String twoDay = DateUtil.getTwoDay(data.getValidityDate(), DateUtil.getCurDate());
					System.out.println("---------------"+lang);
					if(Integer.parseInt(twoDay) > 0){
						message = (String)map.get("registered");
						//message += data.getValidityDate().substring(0, 10);
						key = "1";
						if(Integer.parseInt(twoDay) < 15)
						{
							warning_message = (String)map.get("warning_message_part")+twoDay+(String)map.get("warning_message_part1");
						}
					}else{
						message = (String)map.get("outofdate_message");
						message += data.getValidityDate().substring(0, 10);
						warning_message = (String)map.get("outofdate_warning_message");
						key = "0";
					}
				}
			}
		}else{
			message = (String) map.get("unregistered");
			key = "0";
		}
		jo.element("message", message);
		jo.element("warning_message", warning_message);
		jo.element("key", key);
		return jo;
	}
	
	public JSONObject saveSystemModel(UserInfo user){
		JSONObject jobj = new JSONObject();
		String querySql = "update p_parking set attribute2 = '"+user.getSysModel()+"'";
		int result = this.getJt().update(querySql);
		if(result == 1){
			jobj.element("success", true);
		}else{
			jobj.element("success", false);
		}
		return jobj;
	}
}
