/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.user;

import java.util.List;

import com.ie.frame.ExtendData;

public class UserData extends ExtendData{
	
	private String id;				// id
	private String user_name;		// 用户名
	private String name;			// 姓名
	private String password;		// 密码
	private String state;			// 状态
	
	private List userlist;			// 用户列表LIST
	
	private List roleslist;		// 权限列表
	
	private String[] check1;	// 权限
	private String rolestr;		// 权限
	private List stateList;
	


	public List getStateList() {
		return stateList;
	}

	public void setStateList(List stateList) {
		this.stateList = stateList;
	}

	public String getRolestr() {
		return rolestr;
	}

	public void setRolestr(String rolestr) {
		this.rolestr = rolestr;
	}

	public String[] getCheck1() {
		return check1;
	}

	public void setCheck1(String[] check1) {
		this.check1 = check1;
	}

	public List getRoleslist() {
		return roleslist;
	}

	public void setRoleslist(List roleslist) {
		this.roleslist = roleslist;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public List getUserlist() {
		return userlist;
	}

	public void setUserlist(List userlist) {
		this.userlist = userlist;
	}

}
