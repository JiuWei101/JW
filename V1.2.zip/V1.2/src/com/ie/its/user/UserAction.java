package com.ie.its.user;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.IService;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.login.UserInfo;

//命名空间
@Namespace("/user")
@Results({@Result(name="list",location="/system/user_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="user_list",location="user_list.action",type="redirect")})
public class UserAction extends ExtendActionSupport {
	
	private UserData user;
	@Autowired
	private UserService userService;
	
	private List stateList;		// 用户状态LIST
	
	public UserAction(){
		if(user == null){
			user = new UserData();
		}
	}
	/*
	 * 列表查询
	 */
	@Action(value="user_list")
	public String list(){
		user = (UserData) userService.listData(user);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, user.getPer_data());
		this.setTarget("user_list");
		user.setLang(request.getSession().getAttribute("lang").toString());
		user.setStateList(DisposalCode.getCodeNoDefault("state", request.getSession().getAttribute("lang").toString()));
		//设置多语言
		setLang(user);
		return "list";
	}
	
	public String org(){
		user = (UserData) userService.queryData(user);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, user.getPer_data());
		this.setTarget("user_org");
		return SUCCESS;
	}
	
	@Action(value="user_save",results={@Result(type="json")})
	public void save(){
		JSONObject json =  new JSONObject();
		
		try{
			user.setCheck1(request.getParameterValues("check1"));
			user = (UserData) userService.saveData(user);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}

		setJsonRes(json);
	}

	@Action(value="user_create",results={@Result(name="create",location="/system/user_create.jsp")})
	public String create(){
		user.setId("");
		user = (UserData)userService.transferData(user,"rolelist");
		user.setStateList(DisposalCode.getCodeNoDefault("state", request.getSession().getAttribute("lang").toString()));
		//设置多语言
		setLang(user);
		return ConstantClass.ACTION_CREATE;
	}
	
	@Action(value="user_edit",results={@Result(name="edit",location="/system/user_edit.jsp")})
	public String edit(){
		user.setId(request.getParameter("id"));
		user = (UserData)userService.transferData(user,"rolelist");
		user = (UserData)userService.transferData(user,"rolestr");
		user = (UserData)userService.readData(user);
		user.setStateList(DisposalCode.getCodeNoDefault("state", request.getSession().getAttribute("lang").toString()));
		//设置多语言
		setLang(user);
		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="user_update",results={@Result(type="json")})
	public void update(){
		JSONObject json =  new JSONObject();
		try{
			user.setCheck1(request.getParameterValues("check1"));
			user = (UserData)userService.updateData(user);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	@Action(value="user_delete",results={@Result(type="json")})
	public void delete(){
		JSONObject json =  new JSONObject();
		try{
			user.setChk_record(request.getParameterValues("chk_record"));
			user = (UserData)userService.deleteData(user);
			json.element("success", true);
		}catch(Exception e){
			json.element("success", false);
			json.element("ex", e.getMessage());
		}
		
		setJsonRes(json);
	}
	
	@Action(value="user_read",results={@Result(name="read",location="/system/user_read.jsp")})
	public String read(){
		user.setId(request.getParameter("id"));
		user = (UserData)userService.readData(user);
		user = (UserData)userService.transferData(user,"rolename");
		System.out.println(user.getRolestr());
		return ConstantClass.ACTION_READ;
	}
//	
	@Action(value="user_check")
	public void check(){
		String name="";
		String id = request.getParameter("id");
		user = new UserData();
		try {
			name = java.net.URLDecoder.decode(request.getParameter("user_name"),"UTF-8");
			PrintWriter out;
			out = response.getWriter();
			user.setUser_name(name);
			user.setId(id);
			String str = (String) userService.elseData(user);
			out.print(str);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	@Action(value="user_invalid")
	public String invalid(){
		userService.updateData(user,"00");
		//清空id
		user.setId("");
		return list();
	}
	
	@Action(value="user_valid")
	public String valid(){
		userService.updateData(user,"01");
		//清空id
		user.setId("");
		return list();
	}

	public UserData getUser() {
		return user;
	}

	public void setUser(UserData user) {
		this.user = user;
	}

	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	public List getStateList() {
		return stateList;
	}
	public void setStateList(List stateList) {
		this.stateList = stateList;
	}
}
