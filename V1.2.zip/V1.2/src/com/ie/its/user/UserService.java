/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
@Scope("prototype")
@Service
public class UserService extends ExtendService {
	private UserSql userSql;
	
	public UserService(){
		userSql = new UserSql();
	}
	/*
	 * 列表查询 (non-Javadoc)
	 * 
	 * @see com.forsoft.xzl.common.ExtendService#listData(java.lang.Object)
	 */
	public Object listData(Object o) {
		UserData user = (UserData) o;
		int count = this.getJt().queryForInt(userSql.user_list(user, "count"));
		user.setTotal(count);

		//调用方法设置分页信息 需要参数count
		user.setStartExt(count);
		ArrayList <UserData>rows = this.getJt().<UserData>queryForListExt(userSql.user_list(user, ""), 
				user.getStart(), user.getLimit(),UserData.class);
		

		user.setPer_data(rows);

		return user;
	}

	/*
	 * 列表查询 (non-Javadoc)
	 * 
	 * @see com.forsoft.xzl.common.ExtendService#listData(java.lang.Object)
	 */
	public Object listData(Object o,String str) {
		UserData user = (UserData) o;
			StringBuffer sb = new StringBuffer();
			sb.append("select count(*) ");
			sb.append(" from sys_user u  ");
			sb.append(" where u.id='");
			sb.append(this.getUserinfo().getId());
			sb.append("'");
			
			if(user.getUser_name() != null && !"".equals(user.getUser_name().trim())){
				sb.append(" and u.user_name like '%"+StringManager.reSingleQuote(user.getUser_name().trim())+"%' ");
			}
			if(user.getState() != null && !"".equals(user.getState().trim())){
				sb.append(" and u.state = '"+StringManager.reSingleQuote(user.getState().trim())+"'");
			}
			int count = getJt().queryForInt(sb.toString());
			user.setTotal(count);
			int max = user.getLimit();
			if (count < user.getStart()) {
				if (count != 0) {
					int n = user.getStart() - count;
					if (n % max == 0) {
						n = n / max;
					} else {
						n = n / max + 1;
					}
					user.setStart(user.getStart()- n * max);
				}
			}
			int start = user.getStart();
			List data = new ArrayList();
			sb = new StringBuffer();
			sb.append("select u.id,u.user_name,u.password,u.state");
			sb.append(" from sys_user u");
			sb.append(" where u.id='");
			sb.append(this.getUserinfo().getId());
			sb.append("' ");
			
			if(user.getUser_name() != null && !"".equals(user.getUser_name().trim())){
				sb.append(" and u.user_name like '%"+StringManager.reSingleQuote(user.getUser_name().trim())+"%' ");
			}
			if(user.getState() != null && !"".equals(user.getState().trim())){
				sb.append(" and u.state = '"+StringManager.reSingleQuote(user.getState().trim())+"'");
			}
			Log.log(sb.toString());
			List rows = getJt().queryForList(sb.toString());
			Iterator it = rows.iterator();
			UserData temp = new UserData();
			List list = new ArrayList();
			while (it.hasNext()) {
				Map map = (Map) it.next();
				temp = new UserData();
				BeanUtil.setFieldValue(temp, map);
				list.add(temp);
			}
			user.setPer_data(list);

			return user;
	}

	public Object saveData(Object o) {
		UserData user = (UserData) o;
		String id = PrimaryId.getId();
		List list = new ArrayList();
		if(user.getState().equals("1")){
			user.setState("01");
		}else if(user.getState().equals("0")){
			user.setState("00");
		}
		StringBuffer sb = new StringBuffer();
		sb.append("insert into sys_user(id,user_name,password,state) ");
		sb.append(" values('");
		sb.append(id);
		sb.append("','");
		sb.append(StringManager.reSingleQuote(user.getUser_name()));
		sb.append("','");
		sb.append(Encrypt.EncryptString(user.getPassword()));
		sb.append("','");
		sb.append(user.getState()+"')");
		list.add(sb.toString());
		if(user.getCheck1() != null){
			String[] sqls = new String[user.getCheck1().length];
			for(int i=0;i<user.getCheck1().length;i++){
				sqls[i]="insert into sys_user_role(id,role_id,user_id) " +
						"values('"+PrimaryId.getId()+"','"+user.getCheck1()[i]+"'," +
						"'"+id+"')";
				list.add(sqls[i]);
			}
		}
		String[] sqlArr = new String[list.size()];
		getJt().batchUpdate((String[]) list.toArray(sqlArr));
	//	jt.update(sb.toString());
		return o;
	}

	/*
	 * 用户详细信息查询 (non-Javadoc)
	 * 
	 * @see com.forsoft.xzl.common.ExtendService#readData(java.lang.Object)
	 */
	public Object readData(Object o) {
		UserData user = (UserData) o;
		StringBuffer sb = new StringBuffer();
		sb.append("select u.id,u.user_name,u.state from sys_user u where u.id = '");
		sb.append( user.getId());
		sb.append( "' ");
		List list = getJt().queryForList(sb.toString());
		Iterator it = list.iterator();
		if (it.hasNext()) {
			Map map = (Map) it.next();
			BeanUtil.setFieldValue(user, map);
		}
		return user;
	}

	public Object updateData(Object o) {
		UserData user = (UserData) o;
		List list = new ArrayList();
		if(user.getState().equals("1")){
			user.setState("01");
		}else if(user.getState().equals("0")){
			user.setState("00");
		}
		StringBuffer sb = new StringBuffer();
		sb.append("update sys_user set user_name = '" );
		sb.append( StringManager.reSingleQuote(user.getUser_name()) );
		sb.append( "',");
		if(user.getPassword() != null && !"".equals(user.getPassword())){
			sb.append(" password = '");
			sb.append(Encrypt.EncryptString(user.getPassword()));
			sb.append("',");
		}
		sb.append(" state = '");
		sb.append(user.getState());
		sb.append("' where id = '" );
		sb.append( user.getId() );
		sb.append( "'");
		list.add(sb.toString());
		
		String delsql = "delete from sys_user_role where user_id = '"+user.getId()+"'";
		list.add(delsql);
		
		if(user.getCheck1() != null){
			String[] sqls = new String[user.getCheck1().length];
			for(int i=0;i<user.getCheck1().length;i++){
				sqls[i]="insert into sys_user_role(id,role_id,user_id) " +
						"values('"+PrimaryId.getId()+"','"+user.getCheck1()[i]+"'," +
						"'"+user.getId()+"')";
				list.add(sqls[i]);
			}
		}
		String[] sqlArr = new String[list.size()];
		getJt().batchUpdate((String[]) list.toArray(sqlArr));
		
		return o;
	}

	public Object deleteData(Object o){
		UserData user = (UserData) o;
		String[] id= user.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i]="delete from sys_user where id = "+Util.toSqlVal(id[i]);
		}
		getJt().batchUpdate(sql);
		return user;
	}

	public Object elseData(Object o) {
		UserData user = (UserData) o;
		String sql = "select count(*) from sys_user where user_name = '" + user.getUser_name() + "'";
		if(user.getId() != null && !"".equals(user.getId())){
			sql += " and id <> '"+user.getId()+"'";
		}
		int count = getJt().queryForInt(sql);
		if (count > 0) {
			return "yes";
		}
		return "no";
	}

	 public void updateData(UserData user, String str) {
		 
		 String sql = " update sys_user set state='"+str+"' where id = " + Util.toSqlVal(user.getId());
		 
		 getJt().update(sql);
		 
	 }

	public String conditions(UserData user){
		StringBuffer sb = new StringBuffer();
		sb.append(" from sys_user u  ");
		sb.append(" where 1=1 ");
		
		if(user.getUser_name() != null && !"".equals(user.getUser_name().trim())){
			sb.append(" and u.user_name like '%"+StringManager.reSingleQuote(user.getUser_name().trim())+"%' ");
		}
		if(user.getState() != null && !"".equals(user.getState().trim())){
			sb.append(" and u.state = '"+StringManager.reSingleQuote(user.getState().trim())+"'");
		}
		
		return sb.toString();
	}
	
	public Object rolelist(UserData user){
		StringBuffer sb = new StringBuffer();
		sb.append("select id,role_name from sys_role");
		user.setRoleslist(getJt().queryForList(sb.toString()));
		return user;
	}
	
	public Object rolestr(UserData user){
		StringBuffer sb = new StringBuffer();
		sb.append("select role_id from sys_user_role ");
		sb.append(" where user_id = '"+user.getId()+"'");
		List list = getJt().queryForList(sb.toString());
		Iterator it = list.iterator();
		String rolestr = null;
		while(it.hasNext()){
			Map map = (Map)it.next();
			if(rolestr==null){
				rolestr=(String)map.get("role_id");
			}else{
				rolestr += ","+(String)map.get("role_id");
			}
		}
		user.setRolestr(rolestr);
		return user;
	}
	
	public Object rolename(UserData user){
		StringBuffer sb = new StringBuffer();
		sb.append("select r.role_name as role_name from sys_user_role u, sys_role r ");
		sb.append(" where u.role_id=r.id and u.user_id = '"+user.getId()+"'");
		List list = getJt().queryForList(sb.toString());
		Iterator it = list.iterator();
		String rolename = null;
		while(it.hasNext()){
			Map map = (Map)it.next();
			if(rolename==null){
				rolename=(String)map.get("role_name");
			}else{
				rolename += ","+(String)map.get("role_name");
			}
		}
		user.setRolestr(rolename);
		return user;
	}
}
