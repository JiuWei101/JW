package com.ie.its.user;

import static com.ie.common.Util.isCon;
import static com.ie.common.Util.*;

import com.ie.frame.ExtendSql;
import com.ie.its.example.BookData;

public class UserSql extends ExtendSql{
	/**
     * Description :查询图书．
     * @param  :book,type
     * @return :String
     */
	public String user_list(UserData user,String type){
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*) from sys_user where 1=1 and user_name != 'admin' ";
		}else{
			querySql += "select id,user_name,password,state from sys_user where 1=1 and user_name != 'admin' ";
		}
		
		
		if(isCon(user.getId())){
			querySql += " and id =" + toSqlVal(user.getId());
		}
		
		if(isCon(user.getUser_name())){
			querySql += " and user_name like " + toSqlValLike(user.getUser_name(), "ALL");
		}
		
		if(!type.equals("count")){
			querySql += " order by user_name";
		}
		
		return querySql;
	}
}
