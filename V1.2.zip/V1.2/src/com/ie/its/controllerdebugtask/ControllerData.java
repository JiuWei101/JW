/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.controllerdebugtask;

import java.util.List;

import com.ie.frame.ExtendData;

public class ControllerData extends ExtendData{
	private String mapId;				//地图ID
	private String lineId;				//通讯线路ID
	//private String port;				//端口
	private String type;				//类型
	private String status;				//状态
//	private String maxNum;				//最大管理探头书
	private String notes;				//备注
	private List lineList;				//物理区域下拉框
	private String addr;				//地址
	private List mapList;				//地图下拉框
	private List statusList;			//状态下拉框
	private List controllerPortList;			//端口
	
	private String path;				//配置文件路径
	private String operator;			//发布人
	private String createtime;			//发布时间
	private String runstate;			//任务执行状态
	private String executeTime;			//执行时间
	private String success;				//是否执行成功(1成功0失败)
	private String duration;			//执行时长

	private String field;				//字段名
	private String redcount;				//是否执行成功(1成功0失败)
	private String yellowpercent;			//执行时长
	
	private String controllerId;	//管理器id
	private String debugTaskId;
	private String taskname;				//'任务名称',
	private String sendcontent;				//'发送内容',
	private String expectreturn;				//'期待返回',
	private String realreturn;				//'实际返回',
	
	private int funcode;				//'功能码',
	private String senddata1;				//'发送字节1',
	private String senddata2;				//'发送字节2',
	private String senddata3;				//'发送字节3',
	private String senddata4;				//'发送字节4',
	private String senddata5;				//'发送字节5',
	private String senddata6;				//'发送字节6',
	private String senddata7;				//'发送字节7',
	private String senddata8;				//'发送字节8',
	private String returndata1;				//'接收字节1',
	private String returndata2;				//'接收字节2',
	private String returndata3;				//'接收字节3',
	private String returndata4;				//'接收字节4',
	private String returndata5;				//'接收字节5',
	private String returndata6;				//'接收字节6',
	private String returndata7;				//'接收字节7',
	private String returndata8;				//'接收字节8',
	
	private List debugTaskList;		//引导区域列表
	
	
	public String getControllerId() {
		return controllerId;
	}
	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}
	/**
	 * @return the field
	 */
	public String getField() {
		return field;
	}
	/**
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}
	/**
	 * @return the lineId
	 */
	public String getLineId() {
		return lineId;
	}
	/**
	 * @param lineId the lineId to set
	 */
	public void setLineId(String lineId) {
		this.lineId = lineId;
	}
//	/**
//	 * @return the port
//	 */
//	public String getPort() {
//		return port;
//	}
//	/**
//	 * @param port the port to set
//	 */
//	public void setPort(String port) {
//		this.port = port;
//	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
//	/**
//	 * @return the maxNum
//	 */
//	public String getMaxNum() {
//		return maxNum;
//	}
//	/**
//	 * @param maxNum the maxNum to set
//	 */
//	public void setMaxNum(String maxNum) {
//		this.maxNum = maxNum;
//	}
	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the lineList
	 */
	public List getLineList() {
		return lineList;
	}
	/**
	 * @param lineList the lineList to set
	 */
	public void setLineList(List lineList) {
		this.lineList = lineList;
	}
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}
	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	/**
	 * @return the statusList
	 */
	public List getStatusList() {
		return statusList;
	}
	/**
	 * @param statusList the statusList to set
	 */
	public void setStatusList(List statusList) {
		this.statusList = statusList;
	}
	/**
	 * @return the controllerPortList
	 */
	public List getControllerPortList() {
		return controllerPortList;
	}
	/**
	 * @param controllerPortList the controllerPortList to set
	 */
	public void setControllerPortList(List controllerPortList) {
		this.controllerPortList = controllerPortList;
	}
	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}
	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}
	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * @param operator the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * @return the createtime
	 */
	public String getCreatetime() {
		return createtime;
	}
	/**
	 * @param createtime the createtime to set
	 */
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	/**
	 * @return the runstate
	 */
	public String getRunstate() {
		return runstate;
	}
	/**
	 * @param runstate the runstate to set
	 */
	public void setRunstate(String runstate) {
		this.runstate = runstate;
	}
	/**
	 * @return the executeTime
	 */
	public String getExecuteTime() {
		return executeTime;
	}
	/**
	 * @param executeTime the executeTime to set
	 */
	public void setExecuteTime(String executeTime) {
		this.executeTime = executeTime;
	}
	/**
	 * @return the success
	 */
	public String getSuccess() {
		return success;
	}
	/**
	 * @param success the success to set
	 */
	public void setSuccess(String success) {
		this.success = success;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getRedcount() {
		return redcount;
	}
	public void setRedcount(String redcount) {
		this.redcount = redcount;
	}
	public String getYellowpercent() {
		return yellowpercent;
	}
	public void setYellowpercent(String yellowpercent) {
		this.yellowpercent = yellowpercent;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getSendcontent() {
		return sendcontent;
	}
	public void setSendcontent(String sendcontent) {
		this.sendcontent = sendcontent;
	}
	public String getExpectreturn() {
		return expectreturn;
	}
	public void setExpectreturn(String expectreturn) {
		this.expectreturn = expectreturn;
	}
	public String getRealreturn() {
		return realreturn;
	}
	public void setRealreturn(String realreturn) {
		this.realreturn = realreturn;
	}
	public int getFuncode() {
		return funcode;
	}
	public void setFuncode(int funcode) {
		this.funcode = funcode;
	}
	public String getSenddata1() {
		return senddata1;
	}
	public void setSenddata1(String senddata1) {
		this.senddata1 = senddata1;
	}
	public String getSenddata2() {
		return senddata2;
	}
	public void setSenddata2(String senddata2) {
		this.senddata2 = senddata2;
	}
	public String getSenddata3() {
		return senddata3;
	}
	public void setSenddata3(String senddata3) {
		this.senddata3 = senddata3;
	}
	public String getSenddata4() {
		return senddata4;
	}
	public void setSenddata4(String senddata4) {
		this.senddata4 = senddata4;
	}
	public String getSenddata5() {
		return senddata5;
	}
	public void setSenddata5(String senddata5) {
		this.senddata5 = senddata5;
	}
	public String getSenddata6() {
		return senddata6;
	}
	public void setSenddata6(String senddata6) {
		this.senddata6 = senddata6;
	}
	public String getSenddata7() {
		return senddata7;
	}
	public void setSenddata7(String senddata7) {
		this.senddata7 = senddata7;
	}
	public String getSenddata8() {
		return senddata8;
	}
	public void setSenddata8(String senddata8) {
		this.senddata8 = senddata8;
	}
	public String getReturndata1() {
		return returndata1;
	}
	public void setReturndata1(String returndata1) {
		this.returndata1 = returndata1;
	}
	public String getReturndata2() {
		return returndata2;
	}
	public void setReturndata2(String returndata2) {
		this.returndata2 = returndata2;
	}
	public String getReturndata3() {
		return returndata3;
	}
	public void setReturndata3(String returndata3) {
		this.returndata3 = returndata3;
	}
	public String getReturndata4() {
		return returndata4;
	}
	public void setReturndata4(String returndata4) {
		this.returndata4 = returndata4;
	}
	public String getReturndata5() {
		return returndata5;
	}
	public void setReturndata5(String returndata5) {
		this.returndata5 = returndata5;
	}
	public String getReturndata6() {
		return returndata6;
	}
	public void setReturndata6(String returndata6) {
		this.returndata6 = returndata6;
	}
	public String getReturndata7() {
		return returndata7;
	}
	public void setReturndata7(String returndata7) {
		this.returndata7 = returndata7;
	}
	public String getReturndata8() {
		return returndata8;
	}
	public void setReturndata8(String returndata8) {
		this.returndata8 = returndata8;
	}
	public List getDebugTaskList() {
		return debugTaskList;
	}
	public void setDebugTaskList(List debugTaskList) {
		this.debugTaskList = debugTaskList;
	}
	public String getDebugTaskId() {
		return debugTaskId;
	}
	public void setDebugTaskId(String debugTaskId) {
		this.debugTaskId = debugTaskId;
	}
	
	
	
}
