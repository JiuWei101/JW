/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.controllerdebugtask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.CodeData;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.guideregionmanage.GuideRegionManageData;
import com.ie.its.inifile.IniFileCreator;
import com.ie.its.mapmanage.MapManageData;
import com.ie.its.screenconfig.ScreenData;
import com.ie.its.screenlogic.ScreenLogicData;
@Scope("prototype")
@Service
public class ControllerDebugService extends ExtendService {
	private ControllerSql controllerSql;
	
	public ControllerDebugService(){
		controllerSql = new ControllerSql();
	}


	/**
     * Description :查询管理器．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_list(ControllerData data) {
		//获得数量
		int count = this.getJt().queryForInt(controllerSql.controller_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.controller_list(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		for(ControllerData tempData:rows){
			tempData.setStatus((String) ((HashMap)data.getCurrent_lang_switch().get("ctrl_status")).get(tempData.getStatus()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :保存管理器．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_save(ControllerData data) {
		data.setId(PrimaryId.getId());
		getJt().execute(controllerSql.controller_save(data));
		return data;
	}
	
	/**
     * Description :获得管理器信息．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_get(ControllerData data) {
		getJt().queryForObjectExt(controllerSql.controller_get(data), data);
		
		return data;
	}
	
	/**
     * Description :更新管理器．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_update(ControllerData data) {
		//data.setType("ZC09");//目前管理器默认为ZC09，地址009
		getJt().execute(controllerSql.controller_update(data));
		return data;
	}
	
	/**
     * Description :更新管理器．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_multiupdate(ControllerData data) {
		String [] sql = null;
		String[] fields = data.getField().split(",");
		String[] values = new String[fields.length];
		for(int i = 0; i < fields.length; i++){
			if("lineId".equals(fields[i].trim())){
				values[i] = data.getLineId();
//			} else if("port".equals(fields[i].trim())){
//				values[i] = data.getPort();
			} else if("status".equals(fields[i].trim())){
				values[i] = data.getStatus();
			} else if("notes".equals(fields[i].trim())){
				values[i] = data.getNotes();
			}
		}
		if(data.getId() == null || data.getId().equals("")){
			sql = new String[1];
			sql[0] = controllerSql.controller_multiupdate(null,fields,values);
		} else {
			String[] id= data.getId().split(";");
			sql = new String[id.length];
			for(int i = 0;i < id.length;i++){
				sql[i] = controllerSql.controller_multiupdate(id[i],fields,values);
			}
		}
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :删除管理器．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData controller_delete(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = controllerSql.controller_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :获得地图list．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public List get_mapCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(controllerSql.get_mapCode(), ControllerData.class);
		return codeList;
	}
	
	/**
     * Description :获得通讯线路list．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public List get_lineCode() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(controllerSql.get_lineCode(), ControllerData.class);
		return codeList;
	}

	/**
     * Description :获得修改字段list．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public List get_fieldCode(ControllerData data) {
		List codeList = new ArrayList();
		String[] field_code = {"lineId","port","status","notes"};
		HashMap titles = (HashMap) data.getCurrent_lang_switch().get("common");
		String[] field_value = {(String) titles.get("communication_line"),(String) titles.get("port"),
				(String) titles.get("status"),(String) titles.get("max_detectors"),(String) titles.get("remark")};
		for(int i = 0; i < 4; i++){
			CodeData cd = new CodeData();
			cd.setCode_id(field_code[i]);
			cd.setCode_name(field_value[i]);
			codeList.add(cd);
		}
		return codeList;
	}

	/**
     * Description :获得引导屏类型list．
     * @param  :ScreenData
     * @return :ScreenData
     * @throws :Exception
     */
	public List get_controllerPortCode() {
		List codeList = new ArrayList();
		for(int i =1; i < 4; i++){
			CodeData cd = new CodeData();
			cd.setCode_id(String.valueOf(i));
			cd.setCode_name(String.valueOf(i));
			codeList.add(cd);
		}
		return codeList;
	}
	/**
	 * Description :获得探测器list．
	 * @param controllerId
	 * @return
	 */
	public DetectorConfigData getDetectorConfigData(String controllerId) {
		DetectorConfigData dcd = new DetectorConfigData();
		dcd.setControllerId(controllerId);
		int count = this.getJt().queryForInt(controllerSql.detector_config(dcd, "count"));
		ArrayList <DetectorConfigData>rows = this.getJt().<DetectorConfigData>queryForListExt(controllerSql.detector_config(dcd, ""), DetectorConfigData.class);
		dcd.setTotal(count);
		dcd.setPer_data(rows);
		return dcd;
	}

	/**
	 * Description :获得探测器区域list．
	 * @param DetectorId
	 * @return
	 */
	public DetectorConfigData getDetectorRegion(String DetectorId) {
		DetectorConfigData dcd = new DetectorConfigData();
		dcd.setId(DetectorId);
		int count = this.getJt().queryForInt(controllerSql.detector_region(dcd, "count"));
		ArrayList <DetectorConfigData>rows = this.getJt().<DetectorConfigData>queryForListExt(controllerSql.detector_region(dcd, ""), DetectorConfigData.class);
		dcd.setTotal(count);
		dcd.setPer_data(rows);
		return dcd;
	}

	/**
	 * Description :获得逻辑区域list．
	 * @param controllerId
	 * @return
	 */
	public ControllerData getLogicRegion(String controllerId) {
		ControllerData cd = new ControllerData();
		cd.setId(controllerId);
		int count = this.getJt().queryForInt(controllerSql.logic_region(cd, "count"));
		ArrayList <CodeData>rows = this.getJt().<CodeData>queryForListExt(controllerSql.logic_region(cd, ""), CodeData.class);
		cd.setTotal(count);
		cd.setPer_data(rows);
		return cd;
	}

	/**
	 * Description :获得显示屏list．
	 * @param controllerId
	 * @return
	 */
	public ScreenData getScreenSet(String controllerId) {
		ScreenData dcd = new ScreenData();
		dcd.setControllerId(controllerId);
		int count = this.getJt().queryForInt(controllerSql.screen(dcd, "count"));
		ArrayList <ScreenData>rows = this.getJt().<ScreenData>queryForListExt(controllerSql.screen(dcd, ""), ScreenData.class);
		dcd.setTotal(count);
		dcd.setPer_data(rows);
		return dcd;
	}


	/**
	 * @param id
	 * @return
	 */
	public ArrayList<CodeData> getScreenTypeParamValue(String id) {
		ArrayList <CodeData>rows = this.getJt().<CodeData>queryForListExt(controllerSql.screen_param_value(id), CodeData.class);
		return rows;
	}


	/**
	 * @param id
	 * @param str_old
	 * @return
	 */
	public CodeData getRegionId(String id, String str_old) {
		CodeData data = new CodeData();
		getJt().queryForObjectExt(controllerSql.region_id(id, str_old), data);
		return data;
	}

	/**
	 * @param data
	 */
	public void controller_ini(ControllerData data) {
//		String[] id= data.getId().split(";");
//		String [] sql = new String[id.length * 2];
//		for(int i = 0;i < id.length;i++){
//			IniFileCreator iniFileCreator = new IniFileCreator();
//			String filePath = data.getMap_src() + "zone" + getControllerCode(id[i]) + ".ini";
//			iniFileCreator.create(this, id[i], filePath);
//			sql[i * 2] = controllerSql.plan_delete(id[i]);
//			sql[i * 2 + 1] = controllerSql.plan_save(id[i],filePath,this.getUserinfo().getId());
//		}
//		
//		getJt().batchUpdate(sql);
	}

	/**
	 * @param data
	 */
	public String check_ini(ControllerData data) {
		String msg = "";
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			int result;
			result = this.getJt().queryForInt(controllerSql.check_ini_status(id[i]));
			if(result > 0){
				return (String)((HashMap)data.getCurrent_lang_switch().get("common")).get("task_running");
			}
			result = this.getJt().queryForInt(controllerSql.check_ini_screenpara(id[i]));
			if(result > 0){
				return (String)((HashMap)data.getCurrent_lang_switch().get("common")).get("screen_paravalue_not_enough");
			}
		}
		return msg;
	}

	/**
	 * @param string
	 * @return
	 */
	private String getControllerCode(String id) {
		ControllerData cd = new ControllerData();
		getJt().queryForObjectExt(controllerSql.getControllerCode(id), cd);
		return cd.getAddr();
	}

	/**
     * Description :查询下发任务．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData config_task(ControllerData data) {
		//获得数量
		int count = this.getJt().queryForInt(controllerSql.config_task(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.config_task(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		for(ControllerData tempData:rows){
			tempData.setRunstate((String) ((HashMap)data.getCurrent_lang_switch().get("runstate")).get(tempData.getRunstate()));
		}
		
		data.setPer_data(rows);
		return data;
	}

	
	/**
     * Description :删除下发任务．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData config_task_delete(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = controllerSql.config_task_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :删除下发历史．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData task_history_delete(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = controllerSql.task_history_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	/**
     * Description :查询下发历史．
     * @param  :ControllerData
     * @return :ControllerData
     * @throws :Exception
     */
	public ControllerData config_history(ControllerData data) {
		//获得数量
		int count = this.getJt().queryForInt(controllerSql.config_history(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.config_history(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		//Modified by wj 2012-11-05
		for(ControllerData tempData:rows){
			String str = tempData.getSuccess();
			if(str.equalsIgnoreCase("1")){
				tempData.setSuccess((String) ((HashMap)data.getCurrent_lang_switch().get("success")).get("1"));
			}
			else
			{
				tempData.setSuccess((String) ((HashMap)data.getCurrent_lang_switch().get("success")).get("0"));
			}
		}
		
		data.setPer_data(rows);
		return data;
	}


	/**
	 * 返回true 正常
	 * @param data
	 * @return
	 */
	public boolean getLineId(ControllerData data) {
		String[] split = data.getId().split(";");
		for(int i = 0; i < split.length; i++){
			int queryForInt = getJt().queryForInt(controllerSql.getLineValue(split[i]));
			if(queryForInt != 1){
				return false;
			}
		}
		return true;
		
		
	}
	
	public void create_color_task(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length * 2];
		String taskname="";
		String sendcontent="";
		String expectcontent="";
		int funcode;
		ControllerData tempdata=new ControllerData();
		System.out.println("1111111111111111111");
		System.out.println(controllerSql.getDebugTaskByID(data.getDebugTaskId()));
		tempdata=getJt().queryForObjectExt(controllerSql.getDebugTaskByID(data.getDebugTaskId()), tempdata);
		taskname = tempdata.getTaskname();
		funcode = tempdata.getFuncode();
		sendcontent = tempdata.getSenddata1()+";"+tempdata.getSenddata2()+";"+tempdata.getSenddata3()+";"+tempdata.getSenddata4()+";"
		        +tempdata.getSenddata5()+";"+tempdata.getSenddata6()+";"+tempdata.getSenddata7()+";"+tempdata.getSenddata8();
		expectcontent = tempdata.getReturndata1()+";"+tempdata.getReturndata2()+";"+tempdata.getReturndata3()+";"+tempdata.getReturndata4()+";"
				+tempdata.getReturndata5()+";"+tempdata.getReturndata6()+";"+tempdata.getReturndata7()+";"+tempdata.getReturndata8();

		for(int i = 0;i < id.length;i++){		
			sql[i * 2] = controllerSql.temp_task_delete(id[i]);
			sql[i * 2 + 1] = controllerSql.color_task_save(id[i],taskname,funcode,sendcontent,expectcontent,this.getUserinfo().getId());
		}
		
		getJt().batchUpdate(sql);
	}
	
	public ControllerData check_color_task(ControllerData data) {
		//获得数量
		int count = this.getJt().queryForInt(controllerSql.check_color_task(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.check_color_task(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		for(ControllerData tempData:rows){
			tempData.setRunstate((String) ((HashMap)data.getCurrent_lang_switch().get("runstate")).get(tempData.getRunstate()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	public ControllerData color_task_delete(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = controllerSql.color_task_delete(id[i]);
		}
		getJt().batchUpdate(sql);
		return data;
	}
	
	public ControllerData color_task_history(ControllerData data) {
		//获得数量
		int count = this.getJt().queryForInt(controllerSql.color_task_history(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.color_task_history(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		for(ControllerData tempData:rows){
			tempData.setSuccess((String) ((HashMap)data.getCurrent_lang_switch().get("success")).get(tempData.getSuccess()));
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	public ControllerData custom_debug_task_list(ControllerData data) {
		//获得数量
		System.out.println("111111111111111111111111111111");
		int count = this.getJt().queryForInt(controllerSql.custom_debug_task_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ControllerData>rows = this.getJt().<ControllerData>queryForListExt(controllerSql.custom_debug_task_list(data, ""), 
				data.getStart(), data.getLimit(),ControllerData.class);
		
		//转换编码
		for(ControllerData tempData:rows){
			tempData.setSuccess((String) ((HashMap)data.getCurrent_lang_switch().get("success")).get(tempData.getSuccess()));
		}
		System.out.println("222222222222222222222222");
		data.setPer_data(rows);
		return data;
	}
	
	public boolean readIsExits(ControllerData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(controllerSql.readExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	
	public ControllerData custom_debug_task_save(ControllerData data) {
		String[] sql = new String[1];
		
		if(data.getId() == null || "".equals(data.getId())){
				data.setId(PrimaryId.getId());
				sql[0] = controllerSql.custom_debug_task_save(data);
			
		} else {
				sql[0] = controllerSql.custom_debug_task_update(data);

		}
		System.out.println(sql[0]);
		getJt().batchUpdate(sql);
		return data;
	}
	
	public ControllerData custom_debug_task_delete(ControllerData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = controllerSql.custom_debug_task_delete(id[i]); 
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	public List getDebugTaskList() {
		List list = new ArrayList();
		System.out.println(controllerSql.getDebugTaskList());
		list = getJt().queryForListExt(controllerSql.getDebugTaskList(), ControllerData.class);
		return list;
	}
	
}
