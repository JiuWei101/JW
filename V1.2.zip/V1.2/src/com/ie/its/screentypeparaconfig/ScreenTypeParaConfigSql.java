package com.ie.its.screentypeparaconfig;

import static com.ie.common.Util.*;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class ScreenTypeParaConfigSql extends ExtendSql{
	
	/**
     * Description :查询屏类型．
     * @param  :ScreenTypeParaConfigData,String
     * @return :String
     */
	public String screentype_list(ScreenTypeParaConfigData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select id as typeId,name as typeName,code as typeCode,dllname as typeDllName,describes as typeRemark ";
		}
		
		querySql += " from p_screentype ";
		querySql += " where 1=1 ";
		
		return querySql;
	}

	/**
     * Description :查询屏类型参数．
     * @param  :ScreenTypeParaConfigData,String
     * @return :String
     */
	public String screentypepara_list(ScreenTypeParaConfigData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select stp.id,st.name as typeName,stp.name as name,stp.code,stp.describes as remark,stp.defaultValue,stp.optionalValue ";
		}
		
//		if(isCon(data.getTypeId())){
			querySql += " from p_screentype st inner join p_screentypepara stp on st.code=stp.screenType ";
//		}else{
//			querySql += " from p_screentype st left join p_screentypepara stp on st.code=stp.screenType ";
//		}
		querySql += " where 1=1 ";
		
		if(isCon(data.getScreenType())){
			querySql += " and st.code = " + toSqlVal(data.getScreenType());
		}
		
		return querySql;
	}

	/**
     * Description :获得屏类型信息．
     * @param  :ScreenTypeParaConfigData
     * @return :String
     */
	public String screentype_get(ScreenTypeParaConfigData data) {
		String querySql = "";
		
		querySql = "select id,name,code,dllname,describes as remark ";
		querySql += " from p_screentype where code=";
		
		querySql += Util.toSqlVal(data.getTypeId());
		
		return querySql;
	}
	
	/**
     * Description :获得屏类型参数信息．
     * @param  :ScreenTypeParaConfigData
     * @return :String
     */
	public String screentypepara_get(ScreenTypeParaConfigData data) {
		String querySql = "";
		
		querySql = "select id,screenType as typeId,name,code,describes as remark,defaultValue,optionalValue ";
		querySql += " from p_screentypepara where id=";
		
		querySql += Util.toSqlVal(data.getId());
		
		return querySql;
	}

	/**
     * Description :保存屏类型信息．
     * @param  :ScreenTypeParaConfigData
     * @return :String
     */
	public String screentype_save(ScreenTypeParaConfigData data,String type) {
		String saveSql = "";
		if (type.equals("create")){
			saveSql += "insert into p_screentype(id,name,code,dllname,describes)";
			saveSql +=" values(" + Util.toSqlVal(data.getTypeId())+"," + Util.toSqlVal(data.getTypeName())+","+ Util.toSqlVal(data.getTypeCode())+"," + Util.toSqlVal(data.getTypeDllName())+"," + Util.toSqlVal(data.getTypeRemark())+")";
		}else if (type.equals("edit")){
			saveSql += "update p_screentype set name=" + Util.toSqlVal(data.getTypeName());
			saveSql += ",code=" + Util.toSqlVal(data.getTypeCode());
			saveSql += ",dllname=" + Util.toSqlVal(data.getTypeDllName());
			saveSql += ",describes=" + Util.toSqlVal(data.getTypeRemark());
			saveSql += " where id =" + Util.toSqlVal(data.getTypeId());			
		}
		
		return saveSql;
	}	
	
	/**
     * Description :保存屏类型参数信息．
     * @param  :ScreenTypeParaConfigData
     * @return :String
     */
	public String screentypepara_save(ScreenTypeParaConfigData data) {
		String saveSql = "";
		
		saveSql += "insert into p_screentypepara(id,screenType,name,code,describes,defaultValue,optionalValue)";
		
		saveSql +=" values(" + Util.toSqlVal(data.getId())+"," + Util.toSqlVal(data.getTypeId())+"," + Util.toSqlVal(data.getName())+","+ 
				Util.toSqlVal(data.getCode())+"," + Util.toSqlVal(data.getRemark());
		saveSql += "," + Util.toSqlVal(data.getDefaultValue())+","+Util.toSqlVal(data.getOptionalValue())+")";
		
		return saveSql;
	}	
	
	/**
     * Description :更新屏类型参数信息．
     * @param  :name,code,remark,id
     * @return :String
     */
	public String screentypepara_update(String typeId,String name,String code,String remark,String id,String defaultValue,String optionalValue) {
		String updateSql = "";
		
		updateSql += "update p_screentypepara set name=" + Util.toSqlVal(name);
		updateSql += ",screenType=" + Util.toSqlVal(typeId);
		updateSql += ",code=" + Util.toSqlVal(code);
		updateSql += ",defaultValue=" + Util.toSqlVal(defaultValue);
		updateSql += ",describes=" + Util.toSqlVal(remark);
		updateSql += ",optionalValue=" + Util.toSqlVal(optionalValue);
		updateSql += " where id =" + Util.toSqlVal(id);
		
		return updateSql;
	}	

	/**
     * Description :删除屏类型信息．
     * @param  :id
     * @return :String
     */
	public String screentype_delete(String typeId) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screentype where id = " + Util.toSqlVal(typeId);;
		
		return deleteSql;
	}
	
	/**
     * Description :删除屏类型参数信息．
     * @param  :id
     * @return :String
     */
	public String screentypepara_delete(String id) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screentypepara where id = " + Util.toSqlVal(id);;
		
		return deleteSql;
	}
	
	/**
     * Description :获取屏类型列表
     * @param  :
     * @return :String
     */
	public String get_screenType() {
		String querySql = "";
		
		querySql += "select code as code_id,name as code_name from p_screentype order by id";
		
		return querySql;
	}

	public String getExitsDao(ScreenTypeParaConfigData data, String type) {
		String querySql = "select count(*) count from p_screentypepara where (name = "
			+ toSqlVal(data.getName()) + " or code = " + toSqlVal(data.getCode()) + ")";
			   querySql += " and screenType = " + toSqlVal(data.getTypeId());
		if("update".equals(type)){
			querySql += " and id != " + toSqlVal(data.getId());
		}
		return querySql;
	}

	public String getTypeExitsDao(ScreenTypeParaConfigData data, String type) {
		String querySql = "select count(*) count from p_screentype where (name = "
			+ toSqlVal(data.getTypeName()) + " or code = " + toSqlVal(data.getTypeCode()) + ")";
		if(("update").equals(type)){
			querySql += " and id != " + toSqlVal(data.getId());
		}
		return querySql;
	}
	
	/**
     * Description :查询屏类型．
     * @param  :ScreenTypeParaConfigData,String
     * @return :String
     */
	public String screentype_paraTempl(ScreenTypeParaConfigData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select sh.id as templId,sh.name as templName,st.id as typeId,st.code as typeCode,st.name as typeName,sh.describes as templRemark ";
		}
		
		querySql += " from p_screenparatemplateheader sh ";
		querySql += " left join p_screentype st on sh.screentypecode=st.code";
		querySql += " where 1=1 ";
		
		return querySql;
	}
	
	public String getTemplExitsDao(ScreenTypeParaConfigData data, String type) {
		String querySql = "select count(*) count from p_screenparatemplateheader where (name = "
			+ toSqlVal(data.getTemplName())  + ")";
		if(("update").equals(type)){
			querySql += " and id != " + toSqlVal(data.getTemplId());
		}
		return querySql;
	}
	
	/**
     * Description :保存屏参数值模板．
     * @param  :ScreenTypeParaConfigData
     * @return :String
     */
	public String screenparavalue_temp_save(ScreenTypeParaConfigData data,String type) {
		String saveSql = "";
		if (type.equals("create")){
			saveSql += "insert into p_screenparatemplateheader(id,name,screentypecode,describes)";
			saveSql +=" values(" + Util.toSqlVal(data.getTemplId())+"," + Util.toSqlVal(data.getTemplName())+","+ Util.toSqlVal(data.getTypeCode())+"," + Util.toSqlVal(data.getTemplRemark())+")";
		}else if (type.equals("edit")){
			saveSql += "update p_screenparatemplateheader set name=" + Util.toSqlVal(data.getTemplName());
			saveSql += ",screentypecode=" + Util.toSqlVal(data.getTypeCode());
			saveSql += ",describes=" + Util.toSqlVal(data.getTemplRemark());
			saveSql += " where id =" + Util.toSqlVal(data.getTemplId());	
		}
		
		return saveSql;
	}
	
	/**
     * Description :删除屏模板．
     * @param  :id
     * @return :String
     */
	public String screenparavalue_temp_delete(String tempId) {
		String deleteSql = "";
		
		deleteSql += "delete from p_screenparatemplateheader where id = " + Util.toSqlVal(tempId);;
		
		return deleteSql;
	}	
	
	public String paramvalue(String id, String type) {
		String querySql = "select tv.code,tv.optionalValue,tv.id,tv.name," + (type.equals("1") ? "sv.value" : "'' as value") + ",tv.defaultValue " +
				"from p_screenparatemplateheader s inner join p_screentypepara tv on tv.screenType=s.screenTypeCode " +
				"left join p_screenparatemplateline sv on sv.templateheaderid=s.id and sv.screenTypeParaId=tv.id " +
				"where s.id = " + Util.toSqlVal(id) + " order by tv.id+0";
		System.out.println("---------"+querySql);
		return querySql;
	}
	
	public String screenparavalue_temp_detail_update(String id, String field, String value) {
		String querySql = "update p_screenparatemplateline set value=" + Util.toSqlVal(value) + " where templateheaderid=" + Util.toSqlVal(id) + 
				" and screenTypeParaId=" + Util.toSqlVal(field);
		System.out.println("$$$"+querySql);
		return querySql;
	}
	public String screenparavalue_temp_detail_save(String id, String field, String value) {
		String querySql = "insert into p_screenparatemplateline(id,templateheaderid,screenTypeParaId,value) values(" +
				Util.toSqlVal(PrimaryId.getId()) + "," + Util.toSqlVal(id) + "," + Util.toSqlVal(field) + "," + Util.toSqlVal(value) + ")";
		return querySql;
	}
	
	/**
     * Description :删除屏模板细表里的值．
     * @param  :id
     * @return :String
     */
	public String cleartemplateparavalue(String tempId) {
		String deleteSql = "";
		deleteSql += "delete from p_screenparatemplateline where templateheaderid = " + Util.toSqlVal(tempId);;
		return deleteSql;
	}
	
	public String screenparatemplat_get(ScreenTypeParaConfigData data) {
		String querySql = "";
		
		querySql += "select name as templName,screentypecode as typeCode,describes as templRemark  from p_screenparatemplateheader where id=";
		querySql += Util.toSqlVal(data.getTemplId());
		
		return querySql;
	}
	
	public String RefreshScreenparavalueByTemplateID(String tempId) {
		String Sql = "";
		Sql +="  update "
			 +"   p_screenparavalue a "
			 +"   set a.value = (SELECT l.value FROM p_screenparatemplateheader h ,p_screenparatemplateline l where h.id=l.templateheaderid and l.screentypeparaid=a.screentypeparaid and h.id="+ Util.toSqlVal(tempId)+") "
			 +"  where  "
			 +"   a.screenid in (select  "
			 +"   id  "
			 +"   from  "
			 +"    p_screen  "
			 +"   where  "
			 +"   screenTemplateid = "+Util.toSqlVal(tempId)+")  ";
		return Sql;
	}
	
}
