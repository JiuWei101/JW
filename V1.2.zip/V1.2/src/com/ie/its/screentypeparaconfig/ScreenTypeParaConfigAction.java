/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 :
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.screentypeparaconfig;

import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.DisposalCode;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;

//命名空间
@Namespace("/screentypepara_config")
@Results({@Result(name="list",location="/screentypepara_config/screentypepara_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="screentypepara_list",location="list.action",type="redirect")})
public class ScreenTypeParaConfigAction extends ExtendActionSupport {
	
	private ScreenTypeParaConfigData data;
	@Autowired
	private ScreenTypeParaConfigService screentypeparaService;
	
	public ScreenTypeParaConfigData getData() {
		return data;
	}
	public void setData(ScreenTypeParaConfigData data) {
		this.data = data;
	}
	public ScreenTypeParaConfigAction(){
		if(data == null){
			data = new ScreenTypeParaConfigData();
		}
	}
	/**
     * Description :查询屏类型．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="screentype_list",results={@Result(name="success",location="/screentypepara_config/screentype_list.jsp")})
	public String screentype_list(){
		data = screentypeparaService.screentype_list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}

	/**
     * Description :查询屏类型参数．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="screentypepara_list",results={@Result(name="success",location="/screentypepara_config/screentypepara_list.jsp")})
	public String screentypepara_list(){
		data = screentypeparaService.screentypepara_list(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		//获得屏类型下拉框
		data.setTypeList(screentypeparaService.get_screenType());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="screentype_create",results={@Result(name="typecreate",location="/screentypepara_config/screentype_create.jsp")})
	public String screentype_create(){
		data.setTypeId("");
		
		//设置多语言
		setLang(data);
		return "typecreate";
	}

	@Action(value="screentypepara_create",results={@Result(name="create",location="/screentypepara_config/screentypepara_create.jsp")})
	public String screentypepara_create(){
		data.setId("");
		
		//设置多语言
		setLang(data);
		//获得屏类型下拉框
		data.setTypeList(screentypeparaService.get_screenType());
		return ConstantClass.ACTION_CREATE;
	}
	

	@Action(value="screentype_edit",results={@Result(name="typeedit",location="/screentypepara_config/screentype_edit.jsp")})
	public String screentype_edit(){
		screentypeparaService.screentype_get(data);
		
		//设置多语言
		setLang(data);
		return "typeedit";
	}
	
	@Action(value="screentypepara_edit",results={@Result(name="edit",location="/screentypepara_config/screentypepara_edit.jsp")})
	public String screentypepara_edit(){
		screentypeparaService.screentypepara_get(data);
		
		//设置多语言
		setLang(data);

		//获得屏类型下拉框
		data.setTypeList(screentypeparaService.get_screenType());

		return ConstantClass.ACTION_EDIT;
	}
	
	@Action(value="screentype_save",results={@Result(type="json")})
	public void screentype_save(){		
		
		JSONObject json =  new JSONObject();
		if(screentypeparaService.readTypeExits(data)){
			screentypeparaService.screentype_save(data);
			json.element("success", true);
		}else{
			json.element("success", false);
		}
		
		setJsonRes(json);
	}

	@Action(value="screentypepara_save",results={@Result(type="json")})
	public void screentypepara_save(){		
		
		JSONObject json =  new JSONObject();
		if(screentypeparaService.readIsExits(data)){
			screentypeparaService.screentypepara_save(data);
			json.element("success", true);
		}else{
			json.element("success", false);
		}
		setJsonRes(json);
	}

	@Action(value="screentypepara_update",results={@Result(type="json")})
	public void screentypepara_update(){
		JSONObject json =  new JSONObject();
		if(screentypeparaService.readIsExits(data)){
			screentypeparaService.screentypepara_update(data);
			json.element("success", true);
		}else{
			json.element("success", false);
		}
		setJsonRes(json);
	}

	@SuppressWarnings("rawtypes")
	@Action(value="screentype_delete",results={@Result(type="json")})
	public void screentype_delete() throws Exception{
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		JSONObject json = new JSONObject();
		try {
			screentypeparaService.screentype_delete(data);
			
			json.element("success", true);
			
		} catch (Exception e) {
			json.element("ex",(String)((Map)data.getCurrent_lang_switch().get("screen_alertmess")).get("type_notdeleted"));
		}
		setJsonRes(json);
	}

	@SuppressWarnings("rawtypes")
	@Action(value="screentypepara_delete",results={@Result(type="json")})
	public void screentypepara_delete() throws Exception{
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		JSONObject json = new JSONObject();
		try {
			screentypeparaService.screentypepara_delete(data);
			
			json.element("success", true);
			
		} catch (Exception e) {
			json.element("success", false);
			json.element("ex", (String)((Map)data.getCurrent_lang_switch().get("screen_alertmess")).get("para_notdeleted"));
		}
		setJsonRes(json);
	}
	
	
	/**
     * Description :查询屏类型参数模板．
     * @param  :book
     * @throws :Exception
     */
	@Action(value="screenparavalue_temp",results={@Result(name="success",location="/screentypepara_config/screenparavalue_temp.jsp")})
	public String screenparavalue_temp(){
		data = screentypeparaService.screentype_paraTempl(data);
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		//获得屏类型下拉框 
		data.setTypeList(screentypeparaService.get_screenType());
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	
	@Action(value="screenparavalue_temp_save",results={@Result(type="json")})
	public void screenparavalue_temp_save(){		
		
		JSONObject json =  new JSONObject();
		if(screentypeparaService.readTemplExits(data)){
			screentypeparaService.screenparavalue_temp_save(data);
			json.element("success", true);
		}else{
			json.element("success", false);
		}
		
		setJsonRes(json);
	}
	
	@SuppressWarnings("rawtypes")
	@Action(value="screenparavalue_temp_delete",results={@Result(type="json")})
	public void screenparavalue_temp_delete() throws Exception{	
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		JSONObject json = new JSONObject();
		try {
			screentypeparaService.screenparavalue_temp_delete(data);
			
			json.element("success", true);
			
		} catch (Exception e) {
			json.element("ex", (String)((Map)data.getCurrent_lang_switch().get("screen_alertmess")).get("temp_notdeleted"));
		}
		setJsonRes(json);
	}
	
	@Action(value="screenparavalue_temp_detail",results={@Result(name="success",location="/screentypepara_config/screenparavalue_temp_detail.jsp")})
	public String screenparavalue_temp_detail(){
		//设置多语言
		setLang(data);
		screentypeparaService.templateparavalue_get(data, request.getSession().getAttribute("lang").toString());
		return "success";
	}
	
	@Action(value="screenparavalue_temp_detail_save",results={@Result(type="json")})
	public void screenparavalue_temp_detail_save(){
		JSONObject json =  new JSONObject();
		try{
			//设置多语言
			setLang(data);
			screentypeparaService.screenparavalue_temp_detail_save(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	@SuppressWarnings("rawtypes")
	@Action(value="screenparavalue_temp_reapply",results={@Result(type="json")})
	public void screenparavalue_temp_reapply() throws Exception{
		String lang = request.getSession().getAttribute("lang").toString();
		data.setLang(lang);
		setLang(data);
		JSONObject json = new JSONObject();
		try {
			screentypeparaService.screenparavalue_temp_reapply(data);
			
			json.element("success", true);
			
		} catch (Exception e) {
			json.element("ex", (String)((Map)data.getCurrent_lang_switch().get("screen_alertmess")).get("temp_notreapply"));
		}
		setJsonRes(json);
	}
}
