/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-屏类型参数配置
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.screentypeparaconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.screenconfig.ParamValueData;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class ScreenTypeParaConfigService extends ExtendService {
	private ScreenTypeParaConfigSql screentypeparaSql;
	
	public ScreenTypeParaConfigService(){
		screentypeparaSql = new ScreenTypeParaConfigSql();
	}

	/**
     * Description :查询屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentype_list(ScreenTypeParaConfigData data) {
		//获得数量
		int count = this.getJt().queryForInt(screentypeparaSql.screentype_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+screentypeparaSql.screentype_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenTypeParaConfigData>rows = this.getJt().<ScreenTypeParaConfigData>queryForListExt(screentypeparaSql.screentype_list(data, ""), 
				data.getStart(), data.getLimit(),ScreenTypeParaConfigData.class);
		
		//转换编码
		for(ScreenTypeParaConfigData tempData:rows){			
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :查询屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentypepara_list(ScreenTypeParaConfigData data) {
		//获得数量
		int count = this.getJt().queryForInt(screentypeparaSql.screentypepara_list(data, "count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		Log.log("----"+screentypeparaSql.screentypepara_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenTypeParaConfigData>rows = this.getJt().<ScreenTypeParaConfigData>queryForListExt(screentypeparaSql.screentypepara_list(data, ""), 
				data.getStart(), data.getLimit(),ScreenTypeParaConfigData.class);
		
		//转换编码
		for(ScreenTypeParaConfigData tempData:rows){			
		}
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :获得屏类型信息．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentype_get(ScreenTypeParaConfigData data) {
		getJt().queryForObjectExt(screentypeparaSql.screentype_get(data), data);
		return data;
	}
		
	/**
     * Description :获得屏类型参数信息．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentypepara_get(ScreenTypeParaConfigData data) {
		getJt().queryForObjectExt(screentypeparaSql.screentypepara_get(data), data);
		return data;
	}
	
	/**
     * Description :保存屏类型．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentype_save(ScreenTypeParaConfigData data) {
		if ((data.getTypeId()==null)||(data.getTypeId().equals(""))){
			data.setTypeId(PrimaryId.getId());
			getJt().execute((screentypeparaSql.screentype_save(data,"create")));		
		}else{
			getJt().execute((screentypeparaSql.screentype_save(data,"edit")));
		}
		return data;
	}
	
	/**
     * Description :保存屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentypepara_save(ScreenTypeParaConfigData data) {
		data.setId(PrimaryId.getId());
		
		getJt().execute((screentypeparaSql.screentypepara_save(data)));		
		return data;
	}
	
	/**
     * Description :更新屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentypepara_update(ScreenTypeParaConfigData data) {
		String[] id= data.getId().split(";");
		String typeId = data.getTypeId();
		String name= data.getName();
		String code= data.getCode();
		String defaultValue= data.getDefaultValue();
		String remark = data.getRemark();
		String [] sql = new String[id.length];
		String optionalValue = data.getOptionalValue();
		for(int i = 0;i < id.length;i++){
			sql[i] = screentypeparaSql.screentypepara_update(typeId,name,code,remark,id[i],defaultValue,optionalValue);
		}

		getJt().batchUpdate(sql);
		
		return data;
		
	}
	
	/**
     * Description :删除屏类型．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentype_delete(ScreenTypeParaConfigData data) throws Exception{
		String[] typeId= data.getTypeId().split(";");
		String [] sql = new String[typeId.length];
		for(int i = 0;i < typeId.length;i++){
			sql[i] = screentypeparaSql.screentype_delete(typeId[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :删除屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentypepara_delete(ScreenTypeParaConfigData data) throws Exception{
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length];
		for(int i = 0;i < id.length;i++){
			sql[i] = screentypeparaSql.screentypepara_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}

	/**
     * Description :获得屏类型list
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public List get_screenType() {
		List codeList = new ArrayList();
		
		codeList = getJt().queryForListExt(screentypeparaSql.get_screenType(), ScreenTypeParaConfigData.class);
		return codeList;
	}

	public boolean readIsExits(ScreenTypeParaConfigData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(screentypeparaSql.getExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}

	public boolean readTypeExits(ScreenTypeParaConfigData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(screentypeparaSql.getTypeExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}	
	
	/**
     * Description :查询屏类型参数．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screentype_paraTempl(ScreenTypeParaConfigData data) {
		//获得数量
		int count = this.getJt().queryForInt(screentypeparaSql.screentype_paraTempl(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+screentypeparaSql.screentype_paraTempl(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <ScreenTypeParaConfigData>rows = this.getJt().<ScreenTypeParaConfigData>queryForListExt(screentypeparaSql.screentype_paraTempl(data, ""), 
				data.getStart(), data.getLimit(),ScreenTypeParaConfigData.class);
		
		//转换编码
		for(ScreenTypeParaConfigData tempData:rows){			
		}
		
		data.setPer_data(rows);
		return data;
	}
	

	public boolean readTemplExits(ScreenTypeParaConfigData data) {
		String type = "";
		if(Util.isCon(data.getTemplId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(screentypeparaSql.getTemplExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	
	public ScreenTypeParaConfigData screenparavalue_temp_save(ScreenTypeParaConfigData data) {
		if ((data.getTemplId()==null)||(data.getTemplId().equals(""))){
			data.setTemplId(PrimaryId.getId());
			getJt().execute((screentypeparaSql.screenparavalue_temp_save(data,"create")));		
		}else{
			getJt().execute((screentypeparaSql.screenparavalue_temp_save(data,"edit")));
			
			//更改屏类型后需要清空模板的屏参数值cleartemplateparavalue
			if (!data.getTypeCode().equalsIgnoreCase(data.getOldtypeCode())){
				getJt().execute((screentypeparaSql.cleartemplateparavalue(data.getTemplId())));
			}
		}
		return data;
	}
	
	/**
     * Description :删除屏参数值模板．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
	public ScreenTypeParaConfigData screenparavalue_temp_delete(ScreenTypeParaConfigData data) throws Exception{
		String[] templId= data.getTemplId().split(";");
		String [] sql = new String[templId.length];
		for(int i = 0;i < templId.length;i++){
			sql[i] = screentypeparaSql.screenparavalue_temp_delete(templId[i]);
		}
		
		 
		getJt().batchUpdate(sql);
		return data;
	}
	
	public void templateparavalue_get(ScreenTypeParaConfigData data, String lang) {
		
		ArrayList <ParamValueData>rows = new ArrayList<ParamValueData>();
		data = this.getJt().queryForObjectExt(screentypeparaSql.screenparatemplat_get(data), data);
		rows = this.getJt().<ParamValueData>queryForListExt(screentypeparaSql.paramvalue(data.getTemplId(), "1"), ParamValueData.class);
		for(int i=0;i<rows.size();i++){
			ParamValueData paramValueData = rows.get(i);
			String optionalValue = paramValueData.getOptionalValue();
			JSONArray arr = new JSONArray();
			if(optionalValue != null && !optionalValue.equals("")){
				String[] split = optionalValue.split(",");
				
				for(int j=0;j<split.length;j++){
					JSONObject js = new JSONObject();
					js.element("code_id", split[j]);
					js.element("code_name", split[j]);
					arr.add(js);
				}
			}
			if(lang.equals("44"))
				paramValueData.setLang_text("--- select ---");
			else
				paramValueData.setLang_text("--- 请选择 ---");
			paramValueData.setOptionalList(arr);
			String des = (String) ((HashMap)data.getCurrent_lang_switch().get("screenparades")).get(paramValueData.getCode());
			if(des != null){
				paramValueData.setCode_name(des);
			}
		}
		data.setPer_data(rows);	
	}
	/**
     * Description :新建屏参数值模板．
     * @param  :ScreenTypeParaData
     * @return :ScreenTypeParaData
     * @throws :Exception
     */
   public void screenparavalue_temp_detail_save(ScreenTypeParaConfigData data) {
		
		String[] ids = data.getTemplId().split(";");
		String[] fields = data.getField().split(";");
		String[] values = data.getValue().split(";");
		for(int i = 0; i < ids.length; i++){
			for(int j = 0; j < fields.length; j++){
				if(values[j].equals("!"))
					values[j] = "";
				int count = this.getJt().update(screentypeparaSql.screenparavalue_temp_detail_update(ids[i], fields[j], values[j]));
				if(count == 0){
					this.getJt().update(screentypeparaSql.screenparavalue_temp_detail_save(ids[i], fields[j], values[j]));
				}
			}
		}
		
	}
   
   public void screenparavalue_temp_reapply(ScreenTypeParaConfigData data) {
		
		String[] ids = data.getTemplId().split(";");
		for(int i = 0; i < ids.length; i++){
			this.getJt().update(screentypeparaSql.RefreshScreenparavalueByTemplateID(ids[i]));
		}
		
	}
   
   
}
