/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 停车引导系统-屏类型参数配置
 * Version                  : 1.0
 * create date              : 2012.3.8
 * author                   : heliang
 */
package com.ie.its.screentypeparaconfig;

import java.util.List;

import com.ie.frame.ExtendData;

public class ScreenTypeParaConfigData extends ExtendData{
	

	private String typeId;				//屏类型id
	private String typeName;			//屏类型名称
	private String typeCode;			//屏类型编码
	private String typeRemark;			//屏类型说明
	private String typeDllName;			//屏类型对应动态库文件
	private String screenType;			//查询条件屏类型
	private String id;					//屏类型参数id
	private String name;				//屏类型参数名称
	private String code;				//屏类型参数编码
	private String remark;				//屏类型参数说明
	private List typeList;				//屏类型列表
	private String defaultValue;		//屏参数默认值
	private String optionalValue;       //屏类型参数可选值
	private String templId;				//屏参数值模板ID
	private String templName;			//屏参数值模板名称
	private String templRemark;			//屏参数值模板说明
	private String field;				//字段名
	private String value;				//值
	private String OldtypeCode;			//旧屏类型编码
	public String getTypeId() {
		return typeId;
	}
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getTypeRemark() {
		return typeRemark;
	}
	public void setTypeRemark(String typeRemark) {
		this.typeRemark = typeRemark;
	}
	public String getTypeDllName() {
		return typeDllName;
	}
	public void setTypeDllName(String typeDllName) {
		this.typeDllName = typeDllName;
	}
	public String getScreenType() {
		return screenType;
	}
	public void setScreenType(String screenType) {
		this.screenType = screenType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public List getTypeList() {
		return typeList;
	}
	public void setTypeList(List typeList) {
		this.typeList = typeList;
	}
	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue() {
		return defaultValue;
	}
	/**
	 * @param defaultValue the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getOptionalValue() {
		return optionalValue;
	}
	public void setOptionalValue(String optionalValue) {
		this.optionalValue = optionalValue;
	}
	public String getTemplId() {
		return templId;
	}
	public void setTemplId(String templId) {
		this.templId = templId;
	}
	public String getTemplName() {
		return templName;
	}
	public void setTemplName(String templName) {
		this.templName = templName;
	}
	public String getTemplRemark() {
		return templRemark;
	}
	public void setTemplRemark(String templRemark) {
		this.templRemark = templRemark;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getOldtypeCode() {
		return OldtypeCode;
	}
	public void setOldtypeCode(String oldtypeCode) {
		OldtypeCode = oldtypeCode;
	}
	
	
}
