package com.ie.its.log;

import java.util.List;

import com.ie.frame.ExtendData;

public class LogData extends ExtendData {
	private String id;	//记录id
	private String userId = "";//用户id
	private String userName="";//用户名
	private String operationTime = "";//操作时间
	private String operationType = "";//操作类型
	private String description = "";//详细信息
	private String result="1";//  操作结果   1代表成功，0    代表失败(异常)
    private String exceptionInfo="";//异常信息
    private String stratDate="";// 開始日期   查詢
    private String endDate="";//結束日期    查詢
    private String menuID="";//菜单ID
    private String menuName;//菜单名字
    private String userIp;	//用户IP

    private List userList;		//用户列表  查询
    private List userIpList;    //用户IP列表  查询
    private List resultList;   //结果列表 查询
    
    
	public List getUserList() {
		return userList;
	}

	public void setUserList(List userList) {
		this.userList = userList;
	}

	public List getUserIpList() {
		return userIpList;
	}

	public void setUserIpList(List userIpList) {
		this.userIpList = userIpList;
	}

	public List getResultList() {
		return resultList;
	}

	public void setResultList(List resultList) {
		this.resultList = resultList;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getExceptionInfo() {
		return exceptionInfo;
	}

	public void setExceptionInfo(String exceptionInfo) {
		this.exceptionInfo = exceptionInfo;
	}

	public String getStratDate() {
		return stratDate;
	}

	public void setStratDate(String stratDate) {
		this.stratDate = stratDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}



	public String getUserId() {
		return userId;
	}

	public void setUserId(String userid) {
		this.userId = userid;
	}

	public String getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(String operationTime) {
		this.operationTime = operationTime;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMenuID() {
		return menuID;
	}

	public void setMenuID(String menuID) {
		this.menuID = menuID;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserIp() {
		return userIp;
	}

	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}

}
