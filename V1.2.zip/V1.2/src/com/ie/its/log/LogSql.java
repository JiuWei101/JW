package com.ie.its.log;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;

public class LogSql extends ExtendSql {

	// 增加一条日志记录
	public String addLogRecord(LogData logData) {
		String insertSql = "";
		insertSql += "insert into sys_operator_log (id,userID,operationType,operationTime,description,result,exceptionInfo,menuID,userIp) values(";
		insertSql += Util.toSqlVal(logData.getId()) + ",";
		insertSql += Util.toSqlVal(logData.getUserId()) + ",";
		insertSql += Util.toSqlVal(logData.getOperationType()) + ",";
		insertSql += Util.toSqlVal(logData.getOperationTime()) + ",";
		insertSql += Util.toSqlVal(logData.getDescription()) + ",";
		insertSql += Util.toSqlVal(logData.getResult()) + ",";
		insertSql += Util.toSqlVal(logData.getExceptionInfo()) + ",";
		insertSql += Util.toSqlVal(logData.getMenuID()) + ",";
		insertSql += Util.toSqlVal(logData.getUserIp()) + ")";
		Log.log(insertSql);
		return insertSql;

	}

	public String queryOperatorLogRecods(LogData data,String type) {
		String querySql = "";
		if("count".equals(type)){
			querySql += "select count(*)";
		}else{
			querySql += "select t.id as id, t.userIp as userIp, a.name as menuName, u.user_name as userName,DATE_FORMAT(t.operationTime, '%Y-%m-%d %H:%i:%s') as operationTime ,t.operationType as operationType," 
		         + "t.description as description,t.result as result, t.exceptionInfo as exceptionInfo ";
		}
		
		querySql += "from sys_operator_log t left join sys_user u on t.userID = u.id "
				 + "left join sys_act a on t.menuID = a.id where 1=1";
		if(Util.isCon(data.getStratDate())){
			querySql+=" and DATE_FORMAT(t.operationTime, '%Y-%m-%d')>="+Util.toSqlVal(data.getStratDate());	
		}
		if(Util.isCon(data.getEndDate())){
			querySql+=" and DATE_FORMAT(t.operationTime, '%Y-%m-%d')<="+Util.toSqlVal(data.getEndDate());
		}
		if(Util.isCon(data.getUserId())){
			querySql+=" and t.userID = "+Util.toSqlVal(data.getUserId());
		}
		if(Util.isCon(data.getUserIp())){
			querySql+=" and t.userIp = "+Util.toSqlVal(data.getUserIp());
		}
		querySql+=" order by t.operationTime";
		/*if(!data.getUserName().equals("")){
			querySql+="and t.userName="+Util.toSqlVal(data.getUserName()); 
		}*/
		return querySql;
	}

	/**
	 * 获取用户列表
	 * @return
	 */
	public String getUserList(){
		String querySql = "select distinct(o.userID) as code_id,u.user_name as code_name from sys_operator_log o left join sys_user u on o.userID = u.id where 1=1";
		return querySql;
	}
	
	/**
	 * 获取用户IP列表
	 * @return
	 */
	public String getUserIpList(){
		String querySql = "select distinct(userIP) as code_id,userIp as code_name from sys_operator_log where userIP !=''";
		return querySql;
		
	}
	
	/**
	 * 删除日志记录
	 * @param id
	 * @return
	 */
	public String deleteLog(String id){
		String querySql = "delete from sys_operator_log where id = "+Util.toSqlVal(id);
		return querySql;
	}
}
