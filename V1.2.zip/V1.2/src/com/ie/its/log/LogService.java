package com.ie.its.log;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.ThrowsAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.DateUtil;
import com.ie.common.PrimaryId;
import com.ie.frame.ExtendService;
import com.ie.its.login.UserInfo;
import com.ie.its.parkingstatistics.ParkingStatisticsData;
import com.ie.its.user.UserService;

@Scope("prototype")
@Service
public class LogService extends ExtendService implements ThrowsAdvice {
	@Autowired
	private UserService userService;
	// private UserData user;
	private LogSql logSql;
	private LogData logData;

	public LogService() {

		logSql = new LogSql();
		logData = new LogData();
	}

	public void log() {

		System.out.println("*************Log*******************");

	}

	// 有参无返回值的方法
	// 此方法返回的是一个数组，数组中包括request以及ActionCofig等类对象
	public void logArg(JoinPoint point) {

		// 拦截的实体类
		Object target = point.getTarget();
		// 拦截的方法名称
		String methodName = point.getSignature().getName();
		// 拦截的方法参数
		Object[] args = point.getArgs();

		// 拦截的放参数类型
		Class[] parameterTypes = ((MethodSignature) point.getSignature())
				.getMethod().getParameterTypes();
		Method m = null;
		try {
			// 通过反射获得拦截的method
			m = target.getClass().getMethod(methodName, parameterTypes);

			// 如果是桥则要获得实际拦截的method
			if (m.isBridge()) {
				for (int i = 0; i < args.length; i++) {
					// 获得泛型类型
					Class genClazz = GenericsUtils
							.getSuperClassGenricType(target.getClass());

					// 根据实际参数类型替换parameterType中的类型
					if (args[i].getClass().isAssignableFrom(genClazz)) {
						parameterTypes[i] = genClazz;
					}
				}
				// 获得parameterType参数类型的方法
				m = target.getClass().getMethod(methodName, parameterTypes);
			}

			UserInfo userinfo = userService.getUserinfo();

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}

	}

	// 有参并有返回值的方法

	public void logArgAndReturn(JoinPoint point, Object returnObj) {

		// 此方法返回的是一个数组，数组中包括request以及ActionCofig等类对象
		// 拦截的实体类
		Object target = point.getTarget();
		Object[] args = point.getArgs();
		// 拦截的方法名称
		String methodName = point.getSignature().getName();

		// 拦截的放参数类型
		Class[] parameterTypes = ((MethodSignature) point.getSignature())
				.getMethod().getParameterTypes();
		Method m = null;
		try {
			// 通过反射获得拦截的method
			m = target.getClass().getMethod(methodName, parameterTypes);

			// 如果是桥则要获得实际拦截的method
			if (m.isBridge()) {
				for (int i = 0; i < args.length; i++) {
					// 获得泛型类型
					Class genClazz = GenericsUtils
							.getSuperClassGenricType(target.getClass());

					// 根据实际参数类型替换parameterType中的类型
					if (args[i].getClass().isAssignableFrom(genClazz)) {
						parameterTypes[i] = genClazz;
					}
				}
				// 获得parameterType参数类型的方法
				m = target.getClass().getMethod(methodName, parameterTypes);
			}
			if (methodName.equalsIgnoreCase("setupProperty")) {
				methodName += args[1];
			} else if (methodName.equalsIgnoreCase("excel")) {
				methodName += ((ParkingStatisticsData) args[0]).getList_type();

			}
			SetLogData(methodName);
			insertLogTab();

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
		// System.out.println("执行结果是：" + logData.getRes());

	}

	public void SetLogData(String method_Name) {
		UserInfo userinfo = userService.getUserinfo();
		logData.setId(PrimaryId.getId());
		logData.setUserId(userinfo.getId());
		logData.setUserIp(userinfo.getIp());
		logData.setMenuID(userinfo.getMenuid());
		logData.setOperationTime(DateUtil.getCurDateTime());
		logData.setDescription(getUserOperation(userinfo.getUser_name(),
				method_Name));
		logData.setOperationType(getOperType(method_Name));
	}

	public String getOperType(String str) {
		String retuStr = "其他";
		if (str.indexOf("save") != -1) {
			retuStr = "新增";
		} else if (str.indexOf("update") != -1) {
			retuStr = "修改";
		} else if (str.indexOf("delete") != -1) {
			retuStr = "删除";
		}else if (str.indexOf("getMapData") != -1) {
			retuStr = "导出地图数据到Excel表格";
		}else if (str.indexOf("impExcelData") != -1) {
			retuStr = "从Excel导入地图数据";
		}else if (str.indexOf("setupProperty") != -1) {
			retuStr = "反向寻车参数设置";
		}
		return retuStr;
	}

	public void insertLogTab() {
		getJt().execute(logSql.addLogRecord(logData));
	}

	private String getUserOperation(String user_name, String methodName) {
		String str = user_name;
		if (methodName.equalsIgnoreCase("map_save")) {
			str += "地图管理-->导入地图文件";
		} else if (methodName.equalsIgnoreCase("map_update")) {
			str += "地图管理-->更新地图文件";
		} else if (methodName.equalsIgnoreCase("map_delete")) {
			str += "地图管理-->删除地图文件";
		} else if (methodName.equalsIgnoreCase("getMapData")) {
			str += "地图管理-->导出地图数据";
		} else if (methodName.equalsIgnoreCase("impExcelData")) {
			str += "地图管理-->导入地图数据";
		} else if (methodName
				.equalsIgnoreCase("screenparavalue_temp_detail_save")) {
			str += "新建屏参数值模板";
		} else if (methodName.equalsIgnoreCase("map_savedata")) {
			str += "地图管理-->导入地图数据";
		} else if (methodName.equalsIgnoreCase("screenparavalue_temp_delete")) {
			str += "删除屏参数值模板";
		} else if (methodName.equalsIgnoreCase("screen_update")) {
			str += "更新引导屏";
		} else if (methodName.equalsIgnoreCase("screen_multiupdate")) {
			str += "更新引导屏/批量 ";
		} else if (methodName.equalsIgnoreCase("guideregion_save")) {
			str += "新建/更新引导区 ";
		} else if (methodName.equalsIgnoreCase("guideregion_delete")) {
			str += "删除引导区";
		} else if (methodName.equalsIgnoreCase("logicregion_save")) {
			str += "引导屏逻辑-->新建/更新逻辑区";
		} else if (methodName.equalsIgnoreCase("logicregion_delete")) {
			str += "引导屏逻辑-->删除逻辑区";
		} else if (methodName.equalsIgnoreCase("flash_pub")) {
			str += "引导屏逻辑-->保存引导屏";
		} else if (methodName.equalsIgnoreCase("check_updateDetector")) {
			str += "引导屏逻辑-->保存探测器-->校验所选引导区域类型是否和探测器类型一致";
		} else if (methodName.equalsIgnoreCase("update_detector")) {
			str += "引导屏逻辑-->保存探测器";
		} else if (methodName.equalsIgnoreCase("line_save")) {
			str += "通讯线路配置-->新建通讯线路";
		} else if (methodName.equalsIgnoreCase("line_update")) {
			str += "通讯线路配置-->编辑通讯线路";
		} else if (methodName.equalsIgnoreCase("line_allupdate")) {
			str += "通讯线路配置-->全部更新";
		} else if (methodName.equalsIgnoreCase("line_delete")) {
			str += "通讯线路配置-->删除通讯线路";
		} else if (methodName.equalsIgnoreCase("detector_map_update")) {
			str += "探测器配置-->新增探测器-->更新地图文件";
		} else if (methodName.equalsIgnoreCase("detector_update")) {
			str += "探测器配置-->编辑(更改探测器状态)";
		} else if (methodName.equalsIgnoreCase("detector_allupdate")) {
			str += "探测器配置-->批量编辑(批量更改探测器状态)";
		} else if (methodName.equalsIgnoreCase("detector_delete")) {
			str += "探测器配置-->删除";
		} else if (methodName.equalsIgnoreCase("base_save")) {
			str += "探测器配置-->停车场信息维护更新";
		} else if (methodName.equalsIgnoreCase("save_parking_plan")) {
			str += "计划作业-->保存车位作业计划";
		} else if (methodName.equalsIgnoreCase("parking_update_plan")) {
			str += "引导屏作业管理-->更新车位作业计划";
		} else if (methodName.equalsIgnoreCase("taskParking_delete")) {
			str += "引导屏作业管理-->删除车位作业计划";
		} else if (methodName.equalsIgnoreCase("task_history_delete")) {
			str += "引导屏作业管理-->删除车位作业计划历史";
		} else if (methodName.equalsIgnoreCase("screen_save_plan")) {
			str += "计划作业-->保存引导屏作业计划";
		} else if (methodName.equalsIgnoreCase("screenWork_update")) {
			str += "引导屏作业管理-->更新引导屏作业计划";
		} else if (methodName.equalsIgnoreCase("terminate_update")) {
			str += "引导屏作业管理-->终止引导屏作业计划";
		} else if (methodName.equalsIgnoreCase("task_history_delete")) {
			str += "引导屏作业管理-->删除引导屏作业计划历史";
		} else if (methodName.equalsIgnoreCase("backupToLocal")) {
			str += "数据备份-->备份数据库文件到本地";
		} else if (methodName.equalsIgnoreCase("uploadFile")) {
			str += "数据备份-->数据恢复";
		} else if (methodName.equalsIgnoreCase("create_color_task")) {
			str += "变色策略设置-->下发变色策略";
		} else if (methodName.equalsIgnoreCase("custom_debug_task_save")) {
			str += "自定义调试任务-->管理--->引导区域管理-->新建/编辑";
		} else if (methodName.equalsIgnoreCase("custom_debug_task_delete")) {
			str += "自定义调试任务-->管理--->引导区域管理-->删除";
		} else if (methodName.equalsIgnoreCase("setupPropertydateParam")) {
			str += "反向寻车参数设置-->修改图片存储参数";
		} else if (methodName.equalsIgnoreCase("setupPropertydateFormat")) {
			str += "反向寻车参数设置-->修改时期时间格式参数";
		} else if (methodName.equalsIgnoreCase("setupPropertyinversionParam")) {
			str += "反向寻车参数设置-->修改寻车子系统首页的文字";
		} else if (methodName.equalsIgnoreCase("excelused")) {
			str += "统计报表-->停车占有率导出";
		} else if (methodName.equalsIgnoreCase("excellogical_used")) {
			str += "统计报表-->逻辑区占有率导出";
		} else if (methodName.equalsIgnoreCase("excelinout")) {
			str += "统计报表-->停车出入情况导出";
		} else if (methodName.equalsIgnoreCase("saveSystemModel")) {
			str += "设置系统类型";
		} else if (methodName.equalsIgnoreCase("physical_delete")) {
			str += "物理區域配置-->刪除物理區域";
		} else if (methodName.equalsIgnoreCase("physical_update")) {
			str += "物理區域配置-->更新物理區域";
		} else if (methodName.equalsIgnoreCase("physical_save")) {
			str += "物理區域配置-->新建物理區域";
		} else {
			str += "其他操作:" + methodName;
		}
		return str;
	}

	public void doThrowing(JoinPoint jp, Exception ex) {
		SetLogData(jp.getSignature().getName());
		logData.setResult("0");
		logData.setExceptionInfo(jp.getTarget().getClass().getName() + "."
				+ jp.getSignature().getName() + " throw exception");
		insertLogTab();
	}

	public LogData getOperatorLogRecords(LogData data) {

		int count = this.getJt().queryForInt(logSql.queryOperatorLogRecods(data, "count"));
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		ArrayList<LogData> rows = this.getJt().<LogData> queryForListExt(
				logSql.queryOperatorLogRecods(data,""), data.getStart(),
				data.getLimit(), LogData.class);
		// tempLogData=getJt().q(logSql.queryOperatorLogRecods(tempLogData));
		data.setPer_data(rows);
		return data;
	}
	
	/**
	 * 获取用户列表
	 * @return LogData组成的List
	 */
	public List getUserList(){
		ArrayList list = this.getJt().queryForListExt(logSql.getUserList(), LogData.class);
		return list;
	}
	
	/**
	 * 获取用户IP列表
	 * @return
	 */
	public List getUserIpList(){
		ArrayList list = this.getJt().queryForListExt(logSql.getUserIpList(), LogData.class);
		return list;
	}
	
	/**
	 * 删除日志
	 * @param data
	 * @return
	 */
	public JSONObject deleteLog(LogData data){
		JSONObject jobj = new JSONObject();
		String[] ids = data.getId().split(";");
		if(ids.length > 1){
			String[] sql = new String[ids.length];
			for(int i=0; i<ids.length; i++){
				String onesql = logSql.deleteLog(ids[i]);
				sql[i] = onesql;
			}
			this.getJt().batchUpdate(sql);
		}else{
			String sql = logSql.deleteLog(ids[0]);
			this.getJt().update(sql);
		}
		return jobj;
	}
	
	public LogData getLogData() {
		return logData;
	}

	public void setLogData(LogData logData) {
		this.logData = logData;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
}
