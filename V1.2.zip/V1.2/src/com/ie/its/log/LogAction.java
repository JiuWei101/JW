package com.ie.its.log;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.frame.ExtendActionSupport;
@SuppressWarnings("serial")
@Namespace("/log")
public class LogAction  extends ExtendActionSupport{
     @Autowired
	private LogService logService;
	private LogData logdata;
	public LogAction(){
		if(logdata==null){
			logdata= new LogData();
		}
		
	}
	
	/**
	 * 系统日志查看及查询
	 * @return
	 */
	@Action(value="operatorLog_list",results={@Result(name="success",location="/log/operatorLog_list.jsp")})
	public String getOperatorLogList(){
		logdata=logService.getOperatorLogRecords(logdata);
		logdata.setUserList(logService.getUserList());	//用户下拉列表
		logdata.setUserIpList(logService.getUserIpList());	//用户IP下拉列表
		logdata.setLang(request.getSession().getAttribute("lang").toString());
		setLang(logdata);
		
		return "success";
	}
	
	/**
	 * 删除系统日志
	 */
	@Action(value="deletelog",results={@Result(type="json")})
	public void deleteLog(){
		JSONObject jobj = new JSONObject();
		jobj = logService.deleteLog(logdata);
		jobj.element("success", true);
		setJsonRes(jobj);
	}
	public LogData getLogdata() {
		return logdata;
	}
	public void setLogdata(LogData logdata) {
		this.logdata = logdata;
	}

}
