/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——逻辑区域配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.logicregionmanage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ie.common.BeanUtil;
import com.ie.common.CodeData;
import com.ie.common.DisposalCode;
import com.ie.common.Encrypt;
import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendService;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.example.BookData;
import com.ie.its.example.BookSql;
import com.ie.its.inifile.IniFileCreator;
import com.ie.its.screenconfig.ScreenData;
@Scope("prototype")
@Service
public class LogicRegionManageService extends ExtendService {
	private LogicRegionManageSql logicregionSql;
	
	public LogicRegionManageService(){
		logicregionSql = new LogicRegionManageSql();
	}


	/**
     * Description :查询逻辑区域．
     * @param  :LogicregionData
     * @return :LogicregionData
     * @throws :Exception
     */
	public LogicRegionManageData logicregion_list(LogicRegionManageData data) {
		//获得数量
		int count = this.getJt().queryForInt(logicregionSql.logicregion_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		Log.log("----"+logicregionSql.logicregion_list(data, ""));
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <LogicRegionManageData>rows = this.getJt().<LogicRegionManageData>queryForListExt(logicregionSql.logicregion_list(data, ""), 
				data.getStart(), data.getLimit(),LogicRegionManageData.class);
		
		data.setPer_data(rows);
		return data;
	}
	
	/**
     * Description :保存逻辑区域．
     * @param  :LogicregionData
     * @return :LogicregionData
     * @throws :Exception
     */
	public LogicRegionManageData logicregion_save(LogicRegionManageData data) {
		String [] sql = new String[1];
		if(data.getId() == null || "".equals(data.getId())){
			data.setId(PrimaryId.getId());
			sql[0] = logicregionSql.logicregion_save(data);
		} else {
			sql[0] = logicregionSql.logicregion_update(data);
		}
		getJt().batchUpdate(sql);
		return data;
	}
	
	/**
     * Description :删除逻辑区域．
     * @param  :LogicregionData
     * @return :LogicregionData
     * @throws :Exception
     */
	public LogicRegionManageData logicregion_delete(LogicRegionManageData data) {
		String[] id= data.getId().split(";");
		String [] sql = new String[id.length * 4];
		for(int i = 0;i < id.length;i++){
			sql[i * 4] = logicregionSql.logicregion_delete(id[i]);
			sql[i * 4 + 1] = logicregionSql.logicregion_map_delete(id[i]);
			sql[i * 4 + 2] = logicregionSql.logicregion_parkingspace_delete(id[i]);
			sql[i * 4 + 3] = logicregionSql.logicregion_stat_delete(id[i]);
		}
		
		getJt().batchUpdate(sql);
		return data;
	}


	public List physicalList() {
		List queryForList = getJt().queryForList(logicregionSql.physicalListSql());
		return queryForList;
	}


	public boolean readIsExits(LogicRegionManageData data) {
		String type = "";
		if(Util.isCon(data.getId())){
			type = "update";
		}
		int queryForInt = getJt().queryForInt(logicregionSql.readExitsDao(data, type));
		if(queryForInt == 0){
			return true;
		}else{
			return false;
		}
	}
	
}
