/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.logicregionmanage;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.inifile.IniFileCreator;

//命名空间
@Namespace("/logicregion_manage")
@Results({@Result(name="list",location="/logicregion_manage/logicregion_list.jsp"),@Result(name="ok",location="/success.jsp"),
	@Result(name="logicregion_list",location="list.action",type="redirect")})
public class LogicRegionManageAction extends ExtendActionSupport {
	
	private LogicRegionManageData data;
	@Autowired
	private LogicRegionManageService logicregionService;
	
	public LogicRegionManageData getData() {
		return data;
	}
	public void setData(LogicRegionManageData data) {
		this.data = data;
	}
	public LogicRegionManageAction(){
		if(data == null){
			data = new LogicRegionManageData();
		}
	}
	/**
     * Description :查询管理器．
     * @throws :Exception
     */
	@Action(value="logicregion_list",results={@Result(name="success",location="/logicregion_manage/logicregion_list.jsp")})
	public String logicregion_list(){
		data = logicregionService.logicregion_list(data);
		data.setPhysicalRegionList(logicregionService.physicalList());
		data.setLang(request.getSession().getAttribute("lang").toString());
		//设置多语言
		setLang(data);
		this.request.setAttribute(ConstantClass.RQ_PER_DATA, data.getPer_data());
		
		return SUCCESS;
	}
	
	@Action(value="logicregion_save",results={@Result(type="json")})
	public void logicregion_save(){
		JSONObject json =  new JSONObject();
		try{
			if(logicregionService.readIsExits(data)){
				data = logicregionService.logicregion_save(data);
				json.element("success", true);
			}else{
				json.element("success", false);
			}
			
		} catch(Exception e){
			
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
	
	
	@Action(value="logicregion_delete",results={@Result(type="json")})
	public void logicregion_delete(){		
		JSONObject json =  new JSONObject();
		try{
			logicregionService.logicregion_delete(data);
			json.element("success", true);
		} catch(Exception e){
			json.element("success", false);
			json.element("msg", e.getMessage());
		}
		setJsonRes(json);
	}
}
