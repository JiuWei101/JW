/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——逻辑区域配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.logicregionmanage;

import static com.ie.common.Util.*;

import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.Log;
import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;
import com.ie.its.detectorconfig.DetectorConfigData;
import com.ie.its.screenconfig.ScreenData;

public class LogicRegionManageSql extends ExtendSql{
	/**
     * Description :查询逻辑区域．
     * @param  :logicregionData,String
     * @return :String
     */
	public String logicregion_list(LogicRegionManageData data,String type) {
		String querySql = "";
		
		if(type.equals("count")){
			querySql += "select count(*)  ";
		}else{
			querySql += "select  gr.id,gr.name,gr.code,gr.notes,gr.physicalRegionId ";
		}
		
		querySql += " from p_logicregion gr order by gr.code";
		
		return querySql;
	}
	
	/**
     * Description :保存逻辑区域信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_save(LogicRegionManageData data) {
		String insertSql = "";
		
		insertSql += "insert into p_logicregion(id,code,name,physicalRegionId,notes) values(";
		insertSql += Util.toSqlVal(data.getId()) + ",";
		insertSql += Util.toSqlVal(data.getCode()) + ",";
		insertSql += Util.toSqlVal(data.getName()) + ",";
		insertSql += Util.toSqlVal(data.getPhysicalRegionId()) + ",";
		insertSql += Util.toSqlVal(data.getNotes()) + ")";
		
		
		return insertSql;
	}
	
	/**
     * Description :保存逻辑区域信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_update(LogicRegionManageData data) {
		String insertSql = "";
		
		insertSql += "update p_logicregion set code=";
		insertSql += Util.toSqlVal(data.getCode()) + ",name=";
		insertSql += Util.toSqlVal(data.getName()) + ",physicalRegionId=";
		insertSql += Util.toSqlVal(data.getPhysicalRegionId()) + ",notes=";
		insertSql += Util.toSqlVal(data.getNotes()) + " where id=";
		insertSql += Util.toSqlVal(data.getId());
		
		
		return insertSql;
	}
	
	/**
     * Description :删除逻辑区域信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_delete(String id) {
		String deleteSql = "delete from p_logicregion where id = " + Util.toSqlVal(id);
		return deleteSql;
	}
	
	/**
     * Description :删除逻辑区域与地图关联信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_map_delete(String id) {
		String deleteSql = "delete from p_maplogicregion where logicRegionId = " + Util.toSqlVal(id);
		return deleteSql;
	}
	
	/**
     * Description :删除逻辑区域与统计信息关联信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_stat_delete(String id) {
		String deleteSql = "";
		deleteSql += "delete from p_parkingspacestatistics where maplogicregionId in (select id from p_maplogicregion where logicRegionId = " + 
				Util.toSqlVal(id) + ")";
		return deleteSql;
	}
	
	/**
     * Description :删除逻辑区域与车位关联信息．
     * @param  :logicregionData
     * @return :String
     */
	public String logicregion_parkingspace_delete(String id) {
		String deleteSql = "";
		deleteSql += "update p_parkingspace set logicId='' where logicId = " + Util.toSqlVal(id);
		return deleteSql;
	}

	public String physicalListSql() {
		String querySql = "select  physicalRegionName code_name,id code_id from p_physicalregion ";
			querySql += " where status = 1";
		return querySql;
	}

	public String readExitsDao(LogicRegionManageData data, String type) {
		String querySql = "select count(*) count from p_logicregion where (name = " 
			+ toSqlVal(data.getName()) + " or code = " + toSqlVal(data.getCode()) + ")";
		if(type.equals("update")){
			querySql += " and id != " + toSqlVal(data.getId());
		}
		return querySql;
	}

}
