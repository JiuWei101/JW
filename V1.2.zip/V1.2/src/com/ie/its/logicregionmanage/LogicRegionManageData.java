/**
 * Copy Right Information   : IE 
 * Project                  : ITS
 * JDK version used         : jdk1.6
 * Comments                 : 参数配置——管理器配置
 * Version                  : 1.0
 * create date              : 2012.2.24
 * author                   : zy
 */
package com.ie.its.logicregionmanage;

import java.util.List;

import com.ie.frame.ExtendData;

public class LogicRegionManageData extends ExtendData{
	private String mapId;				//地图ID
	private String mapName;				//地图名称
	private String code;				//编号
	private String name;				//名称
	private String notes;				//备注
	private String physicalRegionId;    //物理区域主键
	private List physicalRegionList;
	private List mapList;				//地图下拉框
	/**
	 * @return the mapId
	 */
	public String getMapId() {
		return mapId;
	}
	/**
	 * @param mapId the mapId to set
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	/**
	 * @return the mapName
	 */
	public String getMapName() {
		return mapName;
	}
	/**
	 * @param mapName the mapName to set
	 */
	public void setMapName(String mapName) {
		this.mapName = mapName;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}
	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
	/**
	 * @return the mapList
	 */
	public List getMapList() {
		return mapList;
	}
	/**
	 * @param mapList the mapList to set
	 */
	public void setMapList(List mapList) {
		this.mapList = mapList;
	}
	public String getPhysicalRegionId() {
		return physicalRegionId;
	}
	public void setPhysicalRegionId(String physicalRegionId) {
		this.physicalRegionId = physicalRegionId;
	}
	public List getPhysicalRegionList() {
		return physicalRegionList;
	}
	public void setPhysicalRegionList(List physicalRegionList) {
		this.physicalRegionList = physicalRegionList;
	}

}
