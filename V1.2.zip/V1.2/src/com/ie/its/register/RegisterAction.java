package com.ie.its.register;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.ConstantClass;
import com.ie.common.StringManager;
import com.ie.common.Util;
import com.ie.frame.ExtendActionSupport;
import com.ie.its.mapmanage.MapManageData;

@Namespace("/register")
public class RegisterAction extends ExtendActionSupport {
	
	private RegisterData data;
	@Autowired
	private RegisterService registerService;
	
	private File myFile;  
    private String myFileFileName;  
    private String myFileFileContentType;
	
	public RegisterAction(){
		if(data == null){
			data = new RegisterData();
		}
	}
	
	/**
     * Description :注册init．
     * @throws :Exception
     */
	@Action(value="register_init",results={@Result(name="success",location="/register/register_index.jsp")})
	public String register_init(){
		data = registerService.getRegister();
		setLang(data);
		return SUCCESS;
	}
	
	/**
     * Description :注册保存．
     * @throws :Exception
     */
	@Action(value="register_save",results={@Result(type="json")})
	public void register_save() throws Exception{
		JSONObject json;
		data.setPath(StringManager.replaceAll(request.getRealPath("/"),"\\","/") + ConstantClass.MAP_DIR +"/");
		data.setFilename(this.getMyFileFileName());
	    //edit by jiangyf,先判断上传文件是否是.AKE文件  
		boolean extName=data.getFilename().substring(data.getFilename().lastIndexOf(".")+1, data.getFilename().length()).equals("AKE")?true:false;
		if(extName){
			 json = registerService.saveInfo(data);
			 if(Util.isCon(this.getMyFileFileName())){
					
					handleUploadFile(data);
					
					//首先判断文件是否存在
//					if(registerService.map_impcheck(data)){
//						handleUploadFile(data);
//					}else{
//						//存在相同文件 返回错误提示
//						json.element("success", false);
//						json.element("message", "file exist");
//					}
				}
		}
		else{
			json=new JSONObject();
			json.element("success", false);
		}
		setJsonRes(json);
	}

	/**
     * Description :处理文件上传方法．
     * @param  :MapManageData
     * @throws :Exception
     */
	public void handleUploadFile(RegisterData data) throws IOException{
		File newFile = new File(data.getPath()+this.getMyFileFileName());
		
		if(!new File(data.getPath()).isDirectory()){
            new File(data.getPath()).mkdirs();
        }
		if(!newFile.exists()){
			newFile.createNewFile();
		}
		
		FileInputStream inputStream = new FileInputStream(this.getMyFile());  
        FileOutputStream outputStream = new FileOutputStream(newFile);  
        byte[] buf = new byte[1024];  
        int length = 0;  
        while ((length = inputStream.read(buf)) != -1) {  
            outputStream.write(buf, 0, length);  
        }  
        inputStream.close();  
        outputStream.flush(); 
        outputStream.close();
	}

	public RegisterData getData() {
		return data;
	}

	public void setData(RegisterData data) {
		this.data = data;
	}

	public RegisterService getRegisterService() {
		return registerService;
	}

	public void setRegisterService(RegisterService registerService) {
		this.registerService = registerService;
	}

	public File getMyFile() {
		return myFile;
	}

	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}

	public String getMyFileFileName() {
		return myFileFileName;
	}

	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}

	public String getMyFileFileContentType() {
		return myFileFileContentType;
	}

	public void setMyFileFileContentType(String myFileFileContentType) {
		this.myFileFileContentType = myFileFileContentType;
	}
}
