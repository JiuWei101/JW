/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.register;

import java.util.ArrayList;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ie.frame.ExtendService;

@Scope("prototype")
@Service
public class RegisterService extends ExtendService {
	private RegisterSql registerSql;
	
	public RegisterService(){
		registerSql = new RegisterSql();
	}
	
	/**
     * Description :查询地图．
     * @param  :MapManageData
     * @return :MapManageData
     * @throws :Exception
     */
	public RegisterData timeout_list(RegisterData data) {
		//获得数量
		int count = this.getJt().queryForInt(registerSql.timeout_list(data, "count"));
		
		//调用方法设置分页信息 需要参数count
		data.setTotal(count);
		data.setStartExt(count);
		
		
		//返回结果集 直接就是BookData 不用转换
		@SuppressWarnings("unchecked")
		ArrayList <RegisterData>rows = this.getJt().<RegisterData>queryForListExt(registerSql.timeout_list(data, ""), 
				data.getStart(), data.getLimit(),RegisterData.class);
		
		return null;
	}


	public JSONArray chart_list() {
		JSONArray arr = new JSONArray();
		arr = this.getJt().queryForJSONArrayExt(registerSql.chart_list());
		return arr;
	}

	public JSONObject saveInfo(RegisterData data) {
		try {
			int queryForInt = this.getJt().queryForInt( registerSql.register_query(data.getId()));
			if (queryForInt == 0) { // 新增
				this.getJt().execute(registerSql.saveSql(data));
			} else { // 更新
				this.getJt().update(registerSql.updateSql(data));
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		JSONObject json = new JSONObject();
		json.element("success", true);
		return json;
	}

	public boolean map_impcheck(RegisterData data) {
		// TODO Auto-generated method stub
		return false;
	}

	public RegisterData getRegister() {
		RegisterData queryForObject = getJt().queryForObjectExt(registerSql.getRegisterSql(), RegisterData.class);
		return queryForObject;
	}

	

	
}
