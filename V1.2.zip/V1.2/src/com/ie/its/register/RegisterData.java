/**
 * Copy Right Information   : Forsoft 
 * Project                  : HSKKW
 * JDK version used         : jdk1.6
 * Comments                 : 汉语水平考务系统-用户管理
 * Version                  : 1.0
 * create date              : 2011.2.14
 * author                   : wenyx
 */
package com.ie.its.register;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import com.ie.frame.ExtendData;

public class RegisterData extends ExtendData{

	private String id;				//主键
	private String name;			//客户名称
	
	private String path;			//路径
	private String validityDate;
	private String ZCLimit;
	private String UDLimit;
	private String LDLimit;
	private String VMSLimit;
	private String filename;
	private String upgradeUrl;//更新中心地址
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getValidityDate() {
		return validityDate;
	}

	public void setValidityDate(String validityDate) {
		this.validityDate = validityDate;
	}

	public String getZCLimit() {
		return ZCLimit;
	}

	public void setZCLimit(String limit) {
		ZCLimit = limit;
	}

	public String getUDLimit() {
		return UDLimit;
	}

	public void setUDLimit(String limit) {
		UDLimit = limit;
	}

	public String getLDLimit() {
		return LDLimit;
	}

	public void setLDLimit(String limit) {
		LDLimit = limit;
	}

	public String getVMSLimit() {
		return VMSLimit;
	}

	public void setVMSLimit(String limit) {
		VMSLimit = limit;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getUpgradeUrl() {
		return upgradeUrl;
	}

	public void setUpgradeUrl(String upgradeUrl) {
		this.upgradeUrl = upgradeUrl;
	}

	
}
