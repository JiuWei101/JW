package com.ie.its.register;


import org.springframework.jdbc.core.ConnectionCallback;

import com.ie.common.PrimaryId;
import com.ie.common.Util;
import com.ie.frame.ExtendSql;


public class RegisterSql extends ExtendSql{

	public String timeout_list(RegisterData data, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public String chart_list() {
		// TODO Auto-generated method stub
		return null;
	}

	public String saveSql(RegisterData data) {
		String insertSql = "insert into p_register(id,name,validityDate,ZCLimit,UDLimit,LDLimit,VMSLimit,path)";
			insertSql += " values (" + Util.toSqlVal(PrimaryId.getId()) + "," + Util.toSqlVal(data.getName()) + "," ;
			insertSql += " '2000-01-01',0,0,0,0, " + Util.toSqlVal(data.getPath()+"/"+data.getFilename()) + ")";
		return insertSql;
	}

	public String getRegisterSql() {
		String querySql = "select * from p_register limit 1";
		return querySql;
	}

	public String register_query(String id) {
		String querySql = "select count(*) from p_register where id = " + Util.toSqlVal(id);
		System.out.println("__"+querySql);
		return querySql;
	}

	public String updateSql(RegisterData data) {
		String updateSql = "update p_register set ";
		 	updateSql += " name = " + Util.toSqlVal(data.getName()) + ",";
		 	updateSql += " validityDate = '2000-01-01',ZCLimit = 0,UDLimit = 0,VMSLimit = 0,LDLimit = 0," ;
		 	updateSql += " path = " + Util.toSqlVal(data.getPath()+"/"+data.getFilename()) ;
		 	updateSql += " where id = " + Util.toSqlVal(data.getId());
		return updateSql;
	}
	
}
