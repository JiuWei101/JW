package com.ie.its.udworkingstatisticsgraph;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.beans.factory.annotation.Autowired;

import com.ie.common.Log;
import com.ie.frame.ExtendActionSupport;
import com.ie.frame.ExtendData;
import com.ie.its.parkingstatistics.ParkingStatisticsData;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

@Namespace("/udworkingStatisticsgraph")
@Results({@Result(name="list",location="inout_list.action",type="redirect")})
public class UDWorkingStatisticsGraphAction extends ExtendActionSupport{
	
	private ParkingStatisticsData statisticsData;   //处理多语言
	//自动注入service
	@Autowired
	private UDWorkingStatisticsGraphService udWorkingStatisticsGraphService;
	
	private String searchType;
	private String date;
	private String type;
	private Object excelData;	//要导出excel的数据
	private String downFileName;
	protected InputStream inputStream;
	
	public ParkingStatisticsData getStatisticsData() {
		return statisticsData;
	}

	public void setStatisticsData(ParkingStatisticsData statisticsData) {
		this.statisticsData = statisticsData;
	}

	public UDWorkingStatisticsGraphAction(){
		if(statisticsData == null){
			statisticsData = new ParkingStatisticsData();
		}
	}
	
	@Action(value="ud_working_statistics_graph",results={@Result(name="success",location="/parking_statistics/ud_working_graph.jsp")})
	public String ud_working_statistics_graph() throws ParseException{
		//设置多语言
		statisticsData.setLang(this.request.getSession().getAttribute("lang").toString());
		this.setLang(statisticsData);
		
		return SUCCESS;
	}
	
	/**
	 * 获取所有探测器在当天的在线、离线时长，并返回到页面之中   或者获取所有探测器每隔5分钟的离线率
	 * @throws IOException 
	 * autor:0917
	 */
	@Action(value="ud_working_get_data",results={@Result(type="json")})
	public void ud_working_get_data() throws IOException{
		JSONObject obj = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)(statisticsData.getLang_switch().get(lang))).get("common");
			
			obj = udWorkingStatisticsGraphService.getUDWorkingStatistic(map,searchType,date,type);
			obj.element("success", true);
			
		}catch(Exception e){
			e.printStackTrace();
			obj.element("success", false);
		}

		setJsonRes(obj);
	}
	
	//====start 导出excel=========================================================================================
	/**
	 * 导出在线or离线时长到excel
	 */
	@Action(value="dataExportToExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String exportToExcel(){
		JSONObject obj = new JSONObject();
		try{
			String lang = request.getSession().getAttribute("lang").toString();
			Map map = (Map)((Map)(statisticsData.getLang_switch().get(lang))).get("common");
			
			obj = udWorkingStatisticsGraphService.getUDWorkingStatistic(map,searchType,date,type);
			File file  = udWorkingStatisticsGraphService.exportToExcel(obj, searchType);
			downFileName = file.getName();
			Log.log(downFileName);
		}catch(Exception e){
			Log.log(e.getMessage());
		}
		
		return SUCCESS;
	}
	
	/**
	 * 文件下载流
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 */
	public InputStream getInputStream() throws UnsupportedEncodingException, FileNotFoundException {
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = UDWorkingStatisticsGraphData.WINEXCELPATH;
		} else {
			path = UDWorkingStatisticsGraphData.LINUXEXCELPATH;
		}
		
		return new FileInputStream(path + "/" + downFileName);
	}
	//=======end 导出excel======================================================================================

	//=======end 将离线探测器导出excel============================================================================
	@Action(value="outUDExportToExcel",results={@Result(type = "stream", params = { "contentType",
			"application/octet-stream;charset=ISO8859-1", "inputName", "inputStream", 
			"contentDisposition", "attachment;filename=${downFileName}", "bufferSize", "4096" })})
	public String outUDExportToExcel(){
		try{
			File file  = udWorkingStatisticsGraphService.getFile();
			downFileName = file.getName();
		}catch(Exception e){
			Log.log(e.getMessage());
		}
		
		return SUCCESS;
	}
	//=======end 将离线探测器导出excel============================================================================
	
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDate() {
		return date;
	}

	public void setExcelData(Object excelData) {
		this.excelData = excelData;
	}

	public Object getExcelData() {
		return excelData;
	}
	
	public String getDownFileName() {
		return downFileName;
	}

	public void setDownFileName(String downFileName) {
		this.downFileName = downFileName;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

}
