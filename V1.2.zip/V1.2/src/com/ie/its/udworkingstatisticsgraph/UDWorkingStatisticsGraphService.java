package com.ie.its.udworkingstatisticsgraph;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.ie.common.DateCompare;
import com.ie.common.FileUtil;
import com.ie.common.Log;
import com.ie.common.OperatePro;
import com.ie.frame.ExtendService;
import com.ie.frame.JdbcTemplateExtend;


@Scope("prototype")
@Service
public class UDWorkingStatisticsGraphService extends ExtendService<UDWorkingStatisticsGraphData>{
	
	private UDWorkingStatisticsGraphSql udWorkingStatisticsGraphSql;   //创建sql对象
	
	private DateCompare dateCompare;
	
	public UDWorkingStatisticsGraphService(){
		if(udWorkingStatisticsGraphSql == null){
			udWorkingStatisticsGraphSql = new UDWorkingStatisticsGraphSql();
		}
		
		dateCompare = new DateCompare();
	}

	public JSONObject getUDWorkingStatistic(Map map,String _search,String _date,String _type) throws ParseException{
		JSONObject json = new JSONObject();
		
		if(_search.equals("duration")){   //调用在线、离线时长函数，得到统计数据
			json = udWorkingStatisticsByDuration(map,_date,_type);
		}
		else if(_search.equals("rate")){    //调用离线率统计函数，得到统计数据
			json = udWorkingByRate(map,_date,_type);
		}

		return json;
	}
	
	//========start 在线离线时长=========================================================================================
	/**
	 * 
	 * @Description : 根据date从数据库中获取原始的数据
	 * @param : @param date 用户输入的时间
	 * @param : @return  
	 * @return : List<UDWorkingStatisticsGraphData> 原始数据列表
	 * @throws : 
	 * @author : 0917
	 */
	@SuppressWarnings("unchecked")
	public List<UDWorkingStatisticsGraphData> getUDWorkingStatisticsDataByDuration(String date,String _type) throws ParseException{
		long eDate = dateCompare.TimeToMSDay(date) + 1000*60*60*24;
		String endDate = dateCompare.MSToTime(eDate);  //查询结束时间范围，第二天的零点
		String sqlStr = udWorkingStatisticsGraphSql.getUDWorkingStatisticsGraphSql(date,endDate,_type);
		List<UDWorkingStatisticsGraphData> udWorkingDataList = new ArrayList<UDWorkingStatisticsGraphData>();
		
		try {
			udWorkingDataList = this.getJt().queryForListExt(sqlStr.toString(), UDWorkingStatisticsGraphData.class);
		} catch (Exception e) {
			Log.log(e.getMessage());
		}
		
		return udWorkingDataList;
	}
	
	/**
	 * 
	 * @Description : 对原始数据进行处理，得出统计数据。。调用 了getUDWorkingStatisticsData()方法
	 * @param : @param date 用户输入的时间
	 * @param : @return  
	 * @return : JSONObject 保存统计数据的对象
	 * @throws : 
	 * @author : 0917
	 * @throws ParseException 
	 */
	public JSONObject udWorkingStatisticsByDuration(Map map,String _date,String _type) throws ParseException{
		JSONObject json = new JSONObject();  //创建一个JSONObject对象，用于存放统计数据
		
		List<UDWorkingStatisticsGraphData> tempUDWorkingList = this.getUDWorkingStatisticsDataByDuration(_date,_type);   //调用getUDWorkingStatisticsData函数获取原始数据
		JSONArray onlineItem = new JSONArray();
		JSONArray outlineItem = new JSONArray();
		
		String xUnitLang = map.get("detector").toString() + "（" 
						+ map.get("unit").toString() + "：" 
						+ map.get("unit_mess").toString() + "）";
		String yUnitLang = map.get("on_out_duration").toString() + "（" 
						+ map.get("unit").toString() + "：h）" ;
		String onlineTile = map.get("ud_online_time").toString();
		String outlineTile = map.get("ud_outline_time").toString();
		
		Iterator<UDWorkingStatisticsGraphData> tempUDWorkingIterator = tempUDWorkingList.iterator();  //使用foreach语言无法动态删除list，所以使用iterator来实现
		
		
		//对原始数据进行处理
		if(tempUDWorkingList!=null){
			while(tempUDWorkingIterator.hasNext()){
				UDWorkingStatisticsGraphData udWorkingData = tempUDWorkingIterator.next();
				if(udWorkingData.getLabel() == 0){
					udWorkingData.setLabel(1);
					String detectorIdStr = udWorkingData.getDetectorId();
					String connTypeStr = udWorkingData.getConnType();
					String dateTimeStr = udWorkingData.getDateTime();
					double onDelay = 0;
					double outDelay = 0;
					
					JSONObject onTime = new JSONObject();
					JSONObject outTime = new JSONObject();

					Iterator<UDWorkingStatisticsGraphData> tempUDWorkingIteratorTo = tempUDWorkingList.iterator();
					while(tempUDWorkingIteratorTo.hasNext()){  //如果此循环中可以动态删除元素的话，系统速度将得到提升。
						UDWorkingStatisticsGraphData udWorkingDataTo = tempUDWorkingIteratorTo.next();
						if(udWorkingDataTo.getLabel() == 0 && udWorkingDataTo.getDetectorId().equals(detectorIdStr)){
							udWorkingDataTo.setLabel(1);
							if(udWorkingDataTo.getConnType().equals(connTypeStr) && udWorkingDataTo.getConnType().equals("1")){   //如果当前记录connType为1，且上一条记录connType也为1，则该时间段为离线
								outDelay += dateCompare.dateDelay(udWorkingDataTo.getDateTime(),dateTimeStr);  
								connTypeStr = udWorkingDataTo.getConnType();
								dateTimeStr = udWorkingDataTo.getDateTime();
							}
							else if(udWorkingDataTo.getConnType().equals(connTypeStr) && udWorkingDataTo.getConnType().equals("0")){//如果当前记录connType为0，且上一条记录connType也为0，则该时间段为上线
								onDelay += dateCompare.dateDelay(udWorkingDataTo.getDateTime(),dateTimeStr);
								connTypeStr = udWorkingDataTo.getConnType();
								dateTimeStr = udWorkingDataTo.getDateTime();
							}
							else if(!udWorkingDataTo.getConnType().equals(connTypeStr) && udWorkingDataTo.getConnType().equals("0")){//如果当前记录connType为0，且上一条记录connType为1，则该时间段为离线
								outDelay += dateCompare.dateDelay(udWorkingDataTo.getDateTime(),dateTimeStr);
								connTypeStr = udWorkingDataTo.getConnType();
								dateTimeStr = udWorkingDataTo.getDateTime();
							}
							else if(!udWorkingDataTo.getConnType().equals(connTypeStr) && udWorkingDataTo.getConnType().equals("1")){//如果当前记录connType为1，且上一条记录connType为0，则该时间段为上线
								onDelay += dateCompare.dateDelay(udWorkingDataTo.getDateTime(),dateTimeStr);
								connTypeStr = udWorkingDataTo.getConnType();
								dateTimeStr = udWorkingDataTo.getDateTime();
							}
							else{
								continue;
							}
						}
						else{
							continue;
						}
					}
					
					tempUDWorkingIterator.remove();   //删除当前元素，减少循环次数
					
					//将毫秒转化为时间类型
					double onDateTime = Double.parseDouble(dateCompare.msToTime(onDelay));
					double outDateTime = Double.parseDouble(dateCompare.msToTime(outDelay));
					//将统计之后的数据保存到JSONArray中
					onTime.put("name", detectorIdStr);
					onTime.put("y",onDateTime);
					outTime.put("name", detectorIdStr);
					outTime.put("y",outDateTime);
					
					onlineItem.add(onTime);
					outlineItem.add(outTime);
				}
				else{
					continue;
				}
			}
			
			//将JSONArray保存到JSONObject中
			json.put("onItem", onlineItem);
			json.put("outItem", outlineItem);
			json.put("xunit", xUnitLang);
			json.put("yunit", yUnitLang);
			json.put("onlineTile", onlineTile);
			json.put("outlineTile", outlineTile);
		}
		json = this.sort(json);   //对数据进行排序，让页面数据更直观
		
		return json;
	}
	
	/**
	 * 
	 * @Description : 每天零点自动将所有探测器的当前状态保存到p_ctrlerstatus表中
	 * @param : @param ds
	 * @param : @param _excuteTime  
	 * @return : void 
	 * @throws : 
	 * @author : 0917
	 */
	public void makeWorkingData(DataSource ds,long _excuteTime){
		String date = dateCompare.MSToTime(_excuteTime);
		String selectSql = udWorkingStatisticsGraphSql.getUDStatusDataFromContorllerSql();
		String selectDetectorSql = udWorkingStatisticsGraphSql.getDetectorSql();
		String insertSql;
		
		JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
		List<UDWorkingStatisticsGraphData> udStatusDataList = jt.queryForListExt(selectSql, UDWorkingStatisticsGraphData.class);
		List<UDWorkingStatisticsGraphData> detectorDataList = jt.queryForListExt(selectDetectorSql, UDWorkingStatisticsGraphData.class);
		for(UDWorkingStatisticsGraphData udData : udStatusDataList){
			int type=0;
			for(UDWorkingStatisticsGraphData detectorData : detectorDataList){
				if(detectorData.getParkCode().contains(udData.getDetectorId())){
					++type;
				}
			}

			insertSql = udWorkingStatisticsGraphSql.setUDStatusDataSql(udData.getDetectorId(), date, udData.getConnType(),type);
			jt.update(insertSql);
		}
	}
	//========end 在线离线时长=========================================================================================
	
	//========start 离线率统计===========================================================================================
	/**
	 * @Description : 计算离线率
	 * @param : @param _outlineNum
	 * @param : @param _udTotal
	 * @param : @return  
	 * @return : double
	 * @author : 0917
	 */
	public double calculatorRate(int _outlineNum,int _udTotal){
		DecimalFormat df = new DecimalFormat("0.00");
		return Double.parseDouble(df.format((double)_outlineNum/(double)_udTotal*100));
	}
	//========end 离线率统计===========================================================================================
	
	//========start导出excel=======================================================================================================
	/**
	 * 导出Excel
	 * @param searchType 查询方式
	 * @param obj 要导出的数据
	 */
	public File exportToExcel(JSONObject obj, String searchType) {
		// TODO Auto-generated method stub
		File file = null;
		try {
			file = createFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dateIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("视频探测器运行情况统计", 0);
			
			if(searchType.equals("duration")){		//查询在线、离线时长
				JSONArray onItem = obj.getJSONArray("onItem");
				JSONArray outItem = obj.getJSONArray("outItem");
				
				for(int i = 0; i < onItem.size(); i++){
					JSONObject onJson = onItem.getJSONObject(i);
					JSONObject outJson = outItem.getJSONObject(i);
					
					Label sequence = new Label(0, dateIndex, " " + dateIndex);		//添加序号
					sheet.addCell(sequence);
					Label detectorId = new Label(1, dateIndex, onJson.get("name").toString());
					sheet.addCell(detectorId);
					Label onTime = new Label(2, dateIndex, onJson.get("y").toString());
					sheet.addCell(onTime);
					Label outTime = new Label(3, dateIndex, outJson.get("y").toString());
					sheet.addCell(outTime);
					
					++dateIndex;
				}
				
				//添加表头
				Label title1 = new Label(0, 0, "序号");
				sheet.addCell(title1);
				Label title2 = new Label(1, 0, "探测器编号");
				sheet.addCell(title2);
				Label title3 = new Label(2, 0, "在线时长");
				sheet.addCell(title3);
				Label title4 = new Label(3, 0, "离线时长");
				sheet.addCell(title4);
				
				
			} else if(searchType.equals("rate")){	//查询离线率
				sheet.setColumnView(1, 20);
				JSONArray rateItem = (JSONArray)obj.getJSONArray("rate");
				
				for(int i = 0; i < rateItem.size(); i++){
					JSONObject onJson = (JSONObject)rateItem.getJSONObject(i);
					
					Label sequence = new Label(0, dateIndex, " " + dateIndex);		//添加序号
					sheet.addCell(sequence);
					Label detectorId = new Label(1, dateIndex, onJson.get("name").toString());
					sheet.addCell(detectorId);
					Label rate = new Label(2, dateIndex, onJson.get("y").toString());
					sheet.addCell(rate);
					
					++dateIndex;
				}
				
				//添加表头
				Label title1 = new Label(0, 0, "序号");
				sheet.addCell(title1);
				Label title2 = new Label(1, 0, "统计时间");
				sheet.addCell(title2);
				Label title3 = new Label(2, 0, "离线率");
				sheet.addCell(title3);
			}

			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 创建文件
	 * @param path
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public File createFile() throws IOException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar calender = Calendar.getInstance();
		String path = "";
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = UDWorkingStatisticsGraphData.WINEXCELPATH;
		} else {
			path = UDWorkingStatisticsGraphData.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + sdf.format(calender.getTime()) + ".xls");
		file.createNewFile();
		
		return file;
	}
	
	//=======end导出excel========================================================================================================

	/**
	 * @Description: 插入排序算法，对在线、离线时长进行排序
	 * @auth: 0917
	 * @data: 2014-10-20 下午04:02:19
	 * @version: UDWorkingStatisticsGraphService 
	 */
	public JSONObject sort(JSONObject json){
		JSONArray onArray = json.getJSONArray("onItem");
		JSONArray outArray = json.getJSONArray("outItem");
		
		//直接插入排序
		for (int i = 1; i < onArray.size(); i++) {
			//待插入元素
			JSONObject onTemp = onArray.getJSONObject(i);
			JSONObject outTemp = outArray.getJSONObject(i);
			
			int j;
			for (j = i-1; j>=0; j--) {
				//将大于temp的往后移动一位
				if(((Double)onArray.getJSONObject(j).get("y"))>((Double)onTemp.get("y"))){
					onArray.set(j+1, onArray.getJSONObject(j));    //注意，在交换在线时长的同时，还要交换离线时长
					outArray.set(j+1, outArray.getJSONObject(j));
				}else{
					break; 
				}
			}
			onArray.set(j+1, onTemp);
			outArray.set(j+1, outTemp);
		}
		
		return json;
	}
	//=====start离线率=================================================================================
	/**
	 * 计算离线率，返回JSON对象
	 * author：0917
	 */
	public JSONObject udWorkingByRate(Map map,String _date,String _type){
		Log.log("----udWorkingByRate");
		JSONObject json = new JSONObject();
		String sqlStr = udWorkingStatisticsGraphSql.getUdStatusData(_date,_type);
		List<UDWorkingStatisticsGraphData> udWorkingDataList = new ArrayList<UDWorkingStatisticsGraphData>();
		udWorkingDataList = this.getJt().queryForListExt(sqlStr, UDWorkingStatisticsGraphData.class);
		
		String timePointLang = map.get("time_point").toString();
		String outlineNumLang = map.get("ud_out_num").toString() 
						+ "(" + map.get("unit_mess").toString() + ")";
		String udTotalLang = map.get("all_ud_in_park").toString();
		String xUnitLang = map.get("time").toString() + "（" 
						+ map.get("unit").toString() + "：" 
						+ map.get("minute").toString() + "）";
		String yUnitLang = map.get("outline_situation").toString();
		String rateLang = map.get("outline_rate").toString() + "(%)";
		
		int udTotal = this.getJt().queryForInt(udWorkingStatisticsGraphSql.getUDTotalSql());   //探测器总数
		int udTotalByType = this.getJt().queryForInt(udWorkingStatisticsGraphSql.getDetectorByType(_type));
		
		JSONArray item = new JSONArray();
		JSONArray udOutNum = new JSONArray();		
		
		for(UDWorkingStatisticsGraphData udData : udWorkingDataList){
			if(udData.getLabel() == 0){
				udData.setLabel(1);
				JSONObject udItem = new JSONObject();
				JSONObject udOutItem = new JSONObject();
				
				String detetor = udData.getDetectorId();
				String dateTime = udData.getDateTime();
				String connType = udData.getConnType();
				
				int outlineNum = 0;   //离线的探测器个数
				if(!connType.equals("0")){
					outlineNum += 1;   //如果当前记录的状态不为0，则离线探测器个数加1
				}
				
				for(UDWorkingStatisticsGraphData udDataTo : udWorkingDataList){
					if(udDataTo.getLabel() == 0){
						if(udDataTo.getDateTime().equals(dateTime)){
							udDataTo.setLabel(1);   //将遍历标志设置为已遍历
							if(!udDataTo.getConnType().equals("0")){
								outlineNum += 1;   //如果当前记录的状态不为0，则离线探测器个数加1
							}
						}
					}
				}
				//String nameStr = timePointLang + "：" + dateTime + " " + outlineNumLang + "：" + outlineNum;  //将离线探测器个数显示在页面坐标值中
				long xValue=0;
				try {
					xValue = dateCompare.TimeToMS(dateTime);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				udItem.put("name", dateTime);
				udItem.put("y", calculatorRate(outlineNum, udTotalByType));
				udItem.put("x", xValue);
				item.add(udItem);
				
				udOutItem.put("name", dateTime);
				udOutItem.put("y", outlineNum);
				udOutItem.put("x", xValue);
				udOutItem.put("color", "#54C85D");
				udOutNum.add(udOutItem);
			}
		}
		String udTotalStr = udTotalLang + "：" + udTotalByType;
		json.put("rate", item);
		json.put("total", udTotalStr);
		json.put("udOutNum", udOutNum);
		
		OperatePro op = new OperatePro();
		String timeStr = op.queryProperty("statisticsTime");
		long excuteTime = Long.parseLong(timeStr);
		
		json.put("excuteTime", excuteTime);
		json.put("xunit", xUnitLang);
		json.put("yunit", yUnitLang);
		json.put("rateTile", rateLang);
		json.put("outTotal", outlineNumLang);
		
		return json;
	}
	
	
	/**
	 * 将p_controller中探测器的状态信息保存到p_ctrlerstatus表中
	 * 被TimeTask调用
	 * author:0917
	 * @throws IOException 
	 */
	public void makeStatusData(DataSource ds,long _excuteTime) throws IOException{
		Log.log("--------makeStatusData");
		String date = dateCompare.MSToTime(_excuteTime);
		String selectSql = udWorkingStatisticsGraphSql.getUDStatusDataFromContorllerSql();
		String selectDetectorSql = udWorkingStatisticsGraphSql.getDetectorSql();
		String insertSql;
		
		JdbcTemplateExtend jt = new JdbcTemplateExtend(ds);
		List<UDWorkingStatisticsGraphData> udStatusDataList = jt.queryForListExt(selectSql, UDWorkingStatisticsGraphData.class);
		List<UDWorkingStatisticsGraphData> detectorDataList = jt.queryForListExt(selectDetectorSql, UDWorkingStatisticsGraphData.class);
		for(UDWorkingStatisticsGraphData udData : udStatusDataList){
			int type=0;
			for(UDWorkingStatisticsGraphData detectorData : detectorDataList){
				if(detectorData.getParkCode().contains(udData.getDetectorId())){
					++type;
				}
			}

			insertSql = udWorkingStatisticsGraphSql.setUDStatusDataSql(udData.getDetectorId(), date, udData.getConnType(),type);
			jt.update(insertSql);
		}
		
		String getOutUDSql = udWorkingStatisticsGraphSql.getUDStatusDataToExcel(date,"0","1");
		List<UDWorkingStatisticsGraphData> udOutDataList = jt.queryForListExt(getOutUDSql, UDWorkingStatisticsGraphData.class);
				
		makeOutUdExcel(udOutDataList);
	}
	
	public File makeOutUdExcel(List<UDWorkingStatisticsGraphData> udOutDataList) throws IOException{
		File file = getFile();
		if(!file.exists()){
			file.createNewFile();
			file = makeSheet(file);
			writeDataToExcel(udOutDataList,file);
		}
		else{
			writeDataToExcel(udOutDataList,file);
		}
		
		return file;
	}
	
	/**
	 * 
	 * @Description : 得到excel文件名
	 * @param : @return  
	 * @return : File 
	 * @throws : 
	 * @author : mingm
	 */
	public File getFile(){
		Log.log("-------getFile");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calender = Calendar.getInstance();
		String path = "";
		
		OperatePro op = new OperatePro();
		String parkId = op.queryProperty("parkId");
		
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().startsWith("windows")) { // 判断当前操作系统是windows还是os
			path = UDWorkingStatisticsGraphData.WINEXCELPATH;
		} else {
			path = UDWorkingStatisticsGraphData.LINUXEXCELPATH;
		}
		FileUtil.mkdir(path);
		File file = new File(path + File.separator + parkId + "rate" + sdf.format(calender.getTime()) + ".xls");
		
		return file;
	}
	
	/**
	 * 
	 * @Description : 将数据添加到excel中
	 * @param : @param udWorkingDataList
	 * @param : @param file  
	 * @return : void 
	 * @throws : 
	 * @author : mingm
	 */
	public void writeDataToExcel(List<UDWorkingStatisticsGraphData> udWorkingDataList,File file){
		Log.log("-------writeDataToExcel");
		WritableWorkbook book=null;
		try{
			Workbook wb = Workbook.getWorkbook(file);
			book = Workbook.createWorkbook(file, wb);
			WritableSheet readSheet = book.getSheet(0);
			int rsRows = readSheet.getRows();
			readSheet.setColumnView(2, 20);
			
			for(UDWorkingStatisticsGraphData udData : udWorkingDataList){
				Label sequence = new Label(0, rsRows, " " + rsRows);		//添加序号
				readSheet.addCell(sequence);
				Label detectorId = new Label(1, rsRows, udData.getDetectorId());
				readSheet.addCell(detectorId);
				Label dateTime = new Label(2, rsRows, udData.getDateTime());
				readSheet.addCell(dateTime);
				Label connType = new Label(3, rsRows, udData.getConnType());
				readSheet.addCell(connType);
				Label mapName = new Label(4, rsRows, udData.getMapName());
				readSheet.addCell(mapName);
				Label code = new Label(5, rsRows, udData.getCode());
				readSheet.addCell(code);
				
				++ rsRows;
			}
			
			book.write();
		}catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
	}
	
	/**
	 * 
	 * @Description : 创建文件列表头
	 * @param : @param file
	 * @param : @return  
	 * @return : File 
	 * @throws : 
	 * @author : mingm
	 */
	public File makeSheet(File file){
		Log.log("-------makeSheet");
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("离线探测器信息统计表", 0);
			//添加表头
			Label title1 = new Label(0, 0, "序号");
			sheet.addCell(title1);
			Label title2 = new Label(1, 0, "探测器编号");
			sheet.addCell(title2);
			Label title3 = new Label(2, 0, "离线时间");
			sheet.addCell(title3);
			Label title4 = new Label(3, 0, "探测器状态");
			sheet.addCell(title4);
			Label title5 = new Label(4, 0, "地图名称");
			sheet.addCell(title5);
			Label title6 = new Label(5, 0, "车位编号");
			sheet.addCell(title6);

			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		
		return file;
	}
	//=====end离线率=================================================================================
	
	//=====start离线探测器导出excel====================================================================
	/**
	 * 导出Excel
	 * @param searchType 查询方式
	 * @param obj 要导出的数据
	 */
	public File outUDExportToExcelService(List<UDWorkingStatisticsGraphData> udWorkingDataList) {
		// TODO Auto-generated method stub
		File file = null;
		try {
			file = createFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			Log.log(e1);
		}
		
		int dateIndex = 1;
		WritableWorkbook book = null;
		try {
			// 打开文件
			 book = Workbook.createWorkbook(file);
			// 生成名为“第一页”的工作表，参数0表示这是第一页
			WritableSheet sheet = book.createSheet("离线探测器信息统计表", 0);
			
			for(UDWorkingStatisticsGraphData udData : udWorkingDataList){
				Label sequence = new Label(0, dateIndex, " " + dateIndex);		//添加序号
				sheet.addCell(sequence);
				Label detectorId = new Label(1, dateIndex, udData.getDetectorId());
				sheet.addCell(detectorId);
				Label dateTime = new Label(2, dateIndex, udData.getDateTime());
				sheet.addCell(dateTime);
				Label connType = new Label(3, dateIndex, udData.getConnType());
				sheet.addCell(connType);
				Label mapName = new Label(4, dateIndex, udData.getMapName());
				sheet.addCell(mapName);
				Label code = new Label(5, dateIndex, udData.getCode());
				sheet.addCell(code);
				
				++dateIndex;
			}
			
			//添加表头
			Label title1 = new Label(0, 0, "序号");
			sheet.addCell(title1);
			Label title2 = new Label(1, 0, "探测器编号");
			sheet.addCell(title2);
			Label title3 = new Label(2, 0, "离线时间");
			sheet.addCell(title3);
			Label title4 = new Label(3, 0, "探测器状态");
			sheet.addCell(title4);
			Label title5 = new Label(4, 0, "地图名称");
			sheet.addCell(title5);
			Label title6 = new Label(5, 0, "车位编号");
			sheet.addCell(title6);

			// 写入数据并关闭文件
			book.write();
		} catch (Exception e) {
			Log.log(e);
		} finally{
			if(book != null){
				try {
					book.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.log(e);
				}
			}
		}
		return file;
	}
	
	/**
	 * 从数据库中查找离线的探测器信息
	 */
	public List<UDWorkingStatisticsGraphData> getOutlineUDDataList(String date,String _type){
		String selectSql = udWorkingStatisticsGraphSql.getUDStatusDataToExcel(date,_type,"");
		List<UDWorkingStatisticsGraphData> udStatusDataList = this.getJt().queryForListExt(selectSql, UDWorkingStatisticsGraphData.class);
		List<UDWorkingStatisticsGraphData> udStatusDataListRet = new ArrayList<UDWorkingStatisticsGraphData>();
		
		for(UDWorkingStatisticsGraphData udData : udStatusDataList){
			if(udData.getConnType().equals("1")){
				udStatusDataListRet.add(udData);
			}
			else{
				continue;
			}
		}
		
		return udStatusDataListRet; 
	}
	//=====start离线探测器导出excel====================================================================
	
	public UDWorkingStatisticsGraphSql getUdWorkingStatisticsGraphSql() {
		return udWorkingStatisticsGraphSql;
	}

	public void setUdWorkingStatisticsGraphSql(
			UDWorkingStatisticsGraphSql udWorkingStatisticsGraphSql) {
		this.udWorkingStatisticsGraphSql = udWorkingStatisticsGraphSql;
	}
}
