package com.ie.its.udworkingstatisticsgraph;

import static com.ie.common.Util.isCon;

public class UDWorkingStatisticsGraphSql {
	
	/**
	 * 
	 * @Description : 查询p_ctrlerstatus表中的数据
	 * @param : _date   date可以是年、年月、年月日三种格式 
	 * @return : sql语句
	 * @throws : 
	 * @author : 0917
	 */
	public String getUDWorkingStatisticsGraphSql(String _date,String _endDate,String _type){
		
		String sqlStr = "select c.macAddr as detectorId,date_format(c.dateTime,'%Y-%m-%d %T') as dateTime,c.status as connType from p_ctrlerstatus as c where 1=1";
		if(isCon(_date)){
			sqlStr += " and c.dateTime>='" + _date+"'";
		}
		if(isCon(_endDate)){
			sqlStr += " and c.dateTime<='" + _endDate +"'"; 
		}
		if(isCon(_type) && !_type.equals("0")){
			sqlStr += " and c.type='" + _type + "'";
		}
		sqlStr += " ORDER BY c.dateTime ASC";

		return sqlStr;
	}
	
	public String getUDTotalSql(){
		String sqlStr = "select Count(*) from p_controller";
		
		return sqlStr;
	}
	
	/**
	 * 
	 * @Description : 从p_controller中查询每个探测器的状态
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String getUDStatusDataFromContorllerSql(){
		String sqlStr = "select addr as detectorId,status as connType from p_controller";
		return sqlStr;
	}
	
	/**
	 * 
	 * @Description : 向p_ctrlerconnstate表中插入每天零点所有探测器的状态
	 * @param : @param _ctrlId
	 * @param : @param _detectorId
	 * @param : @param _date
	 * @param : @param _connType
	 * @param : @param _connDesc
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String setUDWorkintDataSql(String _ctrlId,String _detectorId,String _date,String _connType,String _connDesc){
		String sqlStr = "insert into p_ctrlerconnstate(ctrlId,macAddr,dateTime,connType,connDesc) values(";
		sqlStr += "'" + _ctrlId + "','" + _detectorId + "','" + _date + "','" + _connType + "','" + _connDesc + "')";
		
		return sqlStr;
	}
	
	/**
	 * 
	 * @Description : 把探测器状态信息添加到p_ctrlerstatus表中
	 * @param : @param _detectorId
	 * @param : @param _date
	 * @param : @param _connType
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String setUDStatusDataSql(String _detectorId,String _date,String _connType,int type){
		String sqlStr = "insert into p_ctrlerstatus(macAddr,dateTime,status,type) values(";
		sqlStr += "'" + _detectorId + "'," + "'" + _date + "'," + "'" + _connType +"','" + String.valueOf(type)+"')";
		
		return sqlStr;
	}
	
	/**
	 * 
	 * @Description : 从p_ctrlerstatus表中查询每天探测器的在线、离线情况
	 * @param : @param _date
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : 0917
	 */
	public String getUDStatusDataToExcel(String _date,String _type,String status){
		//String sqlStr = "select macAddr as detectorId,status as connType,dateTime as dateTime from p_ctrlerstatus where 1=1";
		String sqlStr = "select c.macAddr as detectorId,date_format(c.dateTime,'%Y-%m-%d %T') as dateTime,c.status as connType,m.name as mapName,p.code as code";
		sqlStr += " from p_ctrlerstatus as c INNER JOIN p_controller as ct on c.macAddr=ct.addr";
		sqlStr += " INNER JOIN p_detector as d on ct.id=d.controllerId";
		sqlStr += " INNER JOIN p_map as m on m.id=d.mapId";
		sqlStr += " INNER JOIN p_parkingspace as p on p.detectorId=d.id";
		
		if(isCon(_date)){
			sqlStr += 	" and dateTime like '" + _date + "%'";	
		}
		if(isCon(_type) && !_type.equals("0")){
			sqlStr += " and c.type='" + _type + "'";
		}
		if(isCon(status)){
			sqlStr += " and c.status='" + status + "'";
		}
		sqlStr += " ORDER BY dateTime ASC";
		
		return sqlStr;
	}
	
	public String getUdStatusData(String _date,String _type){
		String sqlStr = "select macAddr as detectorId,status as connType,date_format(dateTime,'%Y-%m-%d %T') as dateTime from p_ctrlerstatus where 1=1";
		
		if(isCon(_date)){
			sqlStr += " and dateTime like '" + _date + "%'";	
		}
		if(isCon(_type) && !_type.equals("0")){
			sqlStr += " and type='" + _type + "'";
		}
		sqlStr += " ORDER BY dateTime ASC";
		
		return sqlStr;
	}
	
	//从p_detector表中查找出探测器类型信息，（有两个车位编号就为一对二，依次类推）
	public String getDetectorSql(){
		String sqlStr = "select d.code as parkCode,d.controllerId as controllerId from p_detector as d";
		
		return sqlStr;
	}
	
	/**
	 * 
	 * @Description : 在p_ctrlerstatus根据类型查询探测器总数
	 * @param : @param _type  探测器类型
	 * @param : @return  
	 * @return : String 
	 * @throws : 
	 * @author : mingm	
	 */
	public String getDetectorByType(String _type){
		String sqlsStr = "select count(DISTINCT macAddr) from p_ctrlerstatus where 1=1 ";
		if(isCon(_type) && !_type.equals("0")){
			sqlsStr += " and type='" + _type + "'";
		}
		
		return sqlsStr;
	}
}
