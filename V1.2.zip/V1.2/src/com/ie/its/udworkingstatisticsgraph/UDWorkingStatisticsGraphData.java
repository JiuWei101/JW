package com.ie.its.udworkingstatisticsgraph;

import com.ie.frame.ExtendData;

public class UDWorkingStatisticsGraphData extends ExtendData{

	private String detectorId;    //探测器编号
	private String dateTime;     //记录的时间点
	private String connType;     //探测器状态
	private String mapName;      //地图名称
	private String code;        //车位编号
	private String connDesc;     //状态描述
	private String ctrlId;       //mac地址的十进制
	private int label=0;        //记录是否已遍历标志
	
	private String parkCode;   //车位编号，用于区别探测器类型（一对一、一对二等）
	private String controllerId;  //管理器编号

	protected static final String WINEXCELPATH = "f:/excel";
	protected static final String LINUXEXCELPATH = "/usr/its/excel";
	
	@Override
	public String toString() {
		return "UDWorkingStatisticsGraphData [detectorId=" + detectorId
				+ ", dateTime=" + dateTime + ", connType=" + connType
				+ ", label=" + label + "]";
	}
	
	public void setDetectorId(String detectorId) {
		this.detectorId = detectorId;
	}
	public String getDetectorId() {
		return detectorId;
	}
	
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	
	public String getDateTime() {
		return dateTime;
	}
	
	public void setConnType(String connType) {
		this.connType = connType;
	}
	
	public String getConnType() {
		return connType;
	}

	public void setLabel(int label) {
		this.label = label;
	}

	public int getLabel() {
		return label;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getMapName() {
		return mapName;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setConnDesc(String connDesc) {
		this.connDesc = connDesc;
	}

	public String getConnDesc() {
		return connDesc;
	}

	public void setCtrlId(String ctrlId) {
		this.ctrlId = ctrlId;
	}

	public String getCtrlId() {
		return ctrlId;
	}

	public void setParkCode(String parkCode) {
		this.parkCode = parkCode;
	}

	public String getParkCode() {
		return parkCode;
	}

	public void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}

	public String getControllerId() {
		return controllerId;
	}
}
