/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Service要继承父类，完成DataSource注入
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
 * Modified By              : ghc
*/
package com.ie.frame;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import com.ie.frame.exception.ExtendUnCheckException;
import com.ie.its.login.UserInfo;


public class ExtendService<T> implements IService{
	@Resource(name="dataSource")
	private DataSource ds;
	private JdbcTemplateExtend jt;  //JdbcTemplate扩展类
	public UserInfo userinfo;
	public HashMap  rightMap;

	//设置页面分页信息
	public void setPageInfo(T bean){
		
	}
	public UserInfo getUserinfo() {
		userinfo = (UserInfo)LocalSessionUtil.currentUserInfo();
		return userinfo;
	}
	
	public HashMap getRightMap() {
		rightMap = (HashMap)LocalSessionUtil.currentRightInfo();
		return rightMap;
	}
	
	public String getPath(){
		return (String)LocalSessionUtil.currentPath();
	}
	
	public void setDataSource(DataSource ds){
		this.jt = new JdbcTemplateExtend(ds);	
	}
	
	public DataSource getDataSource(){
		return ds;
	}
	
	public Object listData(Object ob) {
		return null;
	}
	
	public Object listData(Object ob, String str) {
		return null;
	}
	
	public Object queryData(Object ob) {
		return null;
	}
	
	public Object queryData(Object ob, String str) {
		return null;
	}
	
	public Object saveData(Object ob) {
		return null;
	}
	
	public JdbcTemplateExtend getJt(){
		if(this.jt == null){
			this.jt = new JdbcTemplateExtend(ds);
		}
		
		return this.jt;
	}
	public Object saveData(Object ob, String str) {
		return null;
	}
	public Object deleteData(Object ob) {
		return null;
	}
	
	public Object deleteData(Object ob, String str) {
		return null;
	}
	
	public Object updateData(Object ob) {
		return null;
	}
	
	public Object updateData(Object ob, String str) {
		return null;
	}
	public Object transferData(Object ob, String method) {
		Class partypes[] = new Class[1];
		//System.out.println(ob.getClass());
		partypes[0] = ob.getClass();
		//Log.log("类"+this.getClass().getName()+"执行方法:"+method+"开始");
		Method meth = null;
		try {
			meth = this.getClass().getDeclaredMethod(method,partypes);
		} catch (SecurityException e) {
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(Security)");
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(NoSuchMethod)");
		}			
		Object arglist[] = new Object[1];
        arglist[0] = ob;
        Object retobj = null;
              
		try {
			retobj = meth.invoke(this,arglist);
			
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(IllegalArgument)");
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(IllegalAccess)");
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(InvocationTarget)");
		} catch (Exception e){
			e.printStackTrace();
			throw new ExtendUnCheckException("service动态调用方法出错(EXception)");
		}
		//Log.log("类"+this.getClass().getName()+"执行方法:"+method+"结束");
		return retobj;
	}
	public Object transferData(Object ob, String method, String arg) {
		Class partypes[] = new Class[2];
		partypes[0] = ob.getClass();
		partypes[1] = String.class;
		//Log.log("类"+this.getClass().getName()+"执行方法:"+method+"开始");
		Method meth = null;
		try {
			meth = this.getClass().getDeclaredMethod(method,partypes);
		} catch (SecurityException e) {
			throw new ExtendUnCheckException("service动态调用方法出错(Security)");
		} catch (NoSuchMethodException e) {
			throw new ExtendUnCheckException("service动态调用方法出错(NoSuchMethod)");
		}
		Object arglist[] = new Object[2];
        arglist[0] = ob;
        arglist[1] = arg;
        Object retobj = null;
		try {
			retobj = meth.invoke(this,arglist);
		} catch (IllegalArgumentException e) {
			throw new ExtendUnCheckException("service动态调用方法出错(IllegalArgument)");
		} catch (IllegalAccessException e) {
			throw new ExtendUnCheckException("service动态调用方法出错(IllegalAccess)");
		} catch (InvocationTargetException e) {
			throw new ExtendUnCheckException("service动态调用方法出错(InvocationTarget)");
		}
		//Log.log("类"+this.getClass().getName()+"执行方法:"+method+"开始");
		return retobj;
	}

	public Object readData(Object ob) {
		return null;
	}

	public Object readData(Object ob, String str) {
		return null;
	}

	public Object elseData(Object ob) {
		return null;
	}

	public Object elseData(Object ob, String str) {
		return null;
	}
	/**
	 * 获取系统类型
	 * @return
	 */
	public String queryForSystemModel(){
		String rStr = "";
		List<Map<String,Object>> list = this.getJt().queryForList("select * from p_parking");
		if(list.size() > 0){
			rStr = list.get(0).get("attribute2").toString();
		}
		return rStr;
	}
}
