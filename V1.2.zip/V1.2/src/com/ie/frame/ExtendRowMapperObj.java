package com.ie.frame;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ie.common.BeanUtil;


public class ExtendRowMapperObj<T> implements RowMapper{
	private T t;
	public ExtendRowMapperObj(T t){
		this.t = t;
	}
	
	public T mapRow(ResultSet rs, int index) throws SQLException {
		BeanUtil.rs2bean(rs, t);
		
		return t;
	}

}
