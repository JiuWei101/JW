/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 拦截器权限控制业务类
 * Version                  : 1.0
 * create date              : 2008.5.22
 * author                   ：ghc
*/
package com.ie.frame;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class RightCheckService extends ExtendService{	
	
	/**
	 * Description :根据用户Id获得对应的权限路径
	 * @return Object
	 */
	public Object queryData(Object ob){
		Map<String, String> rightMap = new HashMap<String, String>();
		
		StringBuffer sb = new StringBuffer();
		
		sb.append("SELECT DISTINCT a.module_url,a.id ");
		sb.append(" FROM sys_act a,sys_role_act ra,sys_user_role ur ");
		sb.append(" WHERE a.id = ra.act_id AND ra.role_id = ur.role_id ");
		sb.append(" AND ur.user_id = '");
		sb.append(this.getUserinfo().getId());
		sb.append("' ");
		
		System.out.println("*********sql="+sb.toString());
		List rows = this.getJt().queryForList(sb.toString());
		Iterator it = rows.iterator();
		rightMap.put("left", "system/left.action");
		rightMap.put("top", "system/top.action");
		while(it.hasNext()){
			Map map = (Map) it.next(); 
			String path = (String)map.get("module_url")==null?"":(String)map.get("module_url");
			int index = path.indexOf(".action");
			if(index > -1){
				path = path.substring(0, index + 7);
			}
			rightMap.put((String)map.get("id"),path);
		}
		sb.setLength(0);
		sb.append("SELECT DISTINCT a.module_url,a.id ");
		sb.append(" FROM sys_act a WHERE a.is_model='2'");
		
		System.out.println("*********sql="+sb.toString());
		List rows1 = this.getJt().queryForList(sb.toString());
		Iterator it1 = rows1.iterator();
		while(it1.hasNext()){
			Map map1 = (Map) it1.next(); 
			String path = (String)map1.get("module_url")==null?"":(String)map1.get("module_url");
			int index = path.indexOf(".action");
			if(index > -1){
				path = path.substring(0, index + 7);
			}
			rightMap.put((String)map1.get("id"),path);
		}
		
		return rightMap;
	}

}
