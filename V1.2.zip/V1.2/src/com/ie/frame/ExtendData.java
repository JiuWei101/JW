/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Data要继承的父类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
 * Modified By              : ghc
 */
package com.ie.frame;

import java.util.List;
import java.util.Map;

import com.ie.common.ConstantClass;
import com.ie.its.login.UserInfo;


public class ExtendData implements IDATA {

	private String lang;
	private String id;
	private int start = 1; // 初始化为1,默认从第1条开始显示
	private int limit = 10; // 初始化为10,默认每页显示10条
	private int paginationnum = 10;
	private int total; // 总条数
	private Object per_data;
	private String xh; // 序号
	private String queryState; // 查询状态,0无查询条件,1有查询条件,用于处理【解除搜索,显示全部数据】
	private String aid; // 记录点击HREF连接的ID，用于处理样式变换
	private String queryMode; // 查询方式，0普通查询，1高级查询
	private String createBtnRight; // 新建按钮权限标志，0没有权限，1有权限
	private String editBtnRight; // 编辑按钮权限标志，0没有权限，1有权限
	private String delBtnRight; // 删除按钮权限标志，0没有权限，1有权限
	private String[] chk_record;
	private UserInfo userinfo;
	private String jsonReq;
	private String code_id;
	private String code_name;	
	private String map_src;		//地图路径 its系统使用
	private String sysModel;	//系统类型（1为超声波，2为视频，3为地磁）
	private String isExistMap;	//当前系统是否存在地图
	

	//多语言数据
	private Map current_lang_switch;
	private static Map lang_switch;
	private static List lang_list;
		
	public String getIsExistMap() {
		return isExistMap;
	}

	public void setIsExistMap(String isExistMap) {
		this.isExistMap = isExistMap;
	}

	public String getSysModel() {
		return sysModel;
	}

	public void setSysModel(String sysModel) {
		this.sysModel = sysModel;
	}

	public String getMap_src() {
		return map_src;
	}

	public void setMap_src(String map_src) {
		this.map_src = map_src;
	}

	public String getCode_id() {
		return code_id;
	}

	public void setCode_id(String code_id) {
		this.code_id = code_id;
	}

	public String getCode_name() {
		return code_name;
	}

	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}

	public String getJsonReq() {
		return jsonReq;
	}

	public void setJsonReq(String jsonReq) {
		this.jsonReq = jsonReq;
	}

	public String getQueryMode() {
		return queryMode;
	}

	public void setQueryMode(String queryMode) {
		this.queryMode = queryMode;
	}

	public String getQueryState() {
		return queryState;
	}

	public void setQueryState(String queryState) {
		this.queryState = queryState;
	}

	public String getXh() {
		return xh;
	}

	public void setXh(String xh) {
		this.xh = xh;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public Object getPer_data() {
		return per_data;
	}

	public void setPer_data(Object per_data) {
		this.per_data = per_data;
	}



	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPaginationnum() {
		return paginationnum;
	}

	public void setPaginationnum(int paginationnum) {
		this.paginationnum = paginationnum;
	}



	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public void setStartExt(int count) {
		int max = this.getLimit();
		if(count < this.getStart()){
		    if(count!=0){
		    	int n = this.getStart() - count;
		    	if(n%max==0){
		    		n = n/max;
		    	}else{
		    		n = n/max + 1;
		    	}
		    	this.setStart(this.getStart() - n*max);				
		    }
		}
		
		int start = this.getStart();
		if( start <= this.getLimit() && count >0){
			this.setStart(1);
			start = 1;
		}
		
	}
	public int getStartExt(){
		return start;
	}
	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getCreateBtnRight() {
		return createBtnRight;
	}

	public void setCreateBtnRight(String createBtnRight) {
		this.createBtnRight = createBtnRight;
	}

	public String getEditBtnRight() {
		return editBtnRight;
	}

	public void setEditBtnRight(String editBtnRight) {
		this.editBtnRight = editBtnRight;
	}

	public String getDelBtnRight() {
		return delBtnRight;
	}

	public void setDelBtnRight(String delBtnRight) {
		this.delBtnRight = delBtnRight;
	}

	public String[] getChk_record() {
		return chk_record;
	}

	public void setChk_record(String[] chk_record) {
		this.chk_record = chk_record;
	}

	public UserInfo getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInfo userinfo) {
		this.userinfo = userinfo;
	}

	/**
	 * @return the current_lang_switch
	 */
	public Map getCurrent_lang_switch() {
		return current_lang_switch;
	}

	/**
	 * @param current_lang_switch the current_lang_switch to set
	 */
	public void setCurrent_lang_switch(Map current_lang_switch) {
		this.current_lang_switch = current_lang_switch;
	}

	/**
	 * @return the lang_switch
	 */
	public static Map getLang_switch() {
		return lang_switch;
	}

	/**
	 * @param lang_switch the lang_switch to set
	 */
	public static void setLang_switch(Map lang_switch) {
		ExtendData.lang_switch = lang_switch;
	}

	/**
	 * @return the lang_list
	 */
	public static List getLang_list() {
		return lang_list;
	}

	/**
	 * @param lang_list the lang_list to set
	 */
	public static void setLang_list(List lang_list) {
		ExtendData.lang_list = lang_list;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

}
