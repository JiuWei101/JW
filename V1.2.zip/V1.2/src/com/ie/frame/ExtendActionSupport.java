/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Action抽象类 提供session request response的操作
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
 * Modified By              : ghc
*/
package com.ie.frame;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public abstract class ExtendActionSupport extends ActionSupport
				implements ServletRequestAware,ServletResponseAware,SessionAware{
	
	protected HttpServletRequest request;
	protected HttpServletResponse response;
	private   String action_path;				//action名
	protected String msg;					    //返回页面提示信息
	private   String target;					//返回页面文件名
	protected Map att;
	private String jsonRes;					

	public String getActionPath(){
		String all_path[] = request.getRequestURI().split(".action");
		String action[] = all_path[0].split("/");
		action_path = action[action.length-1];
		return action_path;
	}
	
	public void setSession(Map att) {
		this.att = att;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
	public String getJsonRes() {
		return jsonRes;
	}

	public void setJsonRes(JSONObject jsonRes) {
		try{
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print(jsonRes);
			response.getWriter().flush(); 
		}catch(Exception e){
			
		}
	}
	
	public void setJsonRes(JSONArray jsonRes){
		try{
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print(jsonRes);
			response.getWriter().flush(); 
		}catch(Exception e){
			
		}
	}
//	public void setJsonRes(String jsonRes) {
//		try{
//			response.setCharacterEncoding("UTF-8");
//			response.getWriter().print(jsonRes);
//			response.getWriter().flush(); 
//		}catch(Exception e){
//			
//		}
//	}
	
	@SuppressWarnings({ "rawtypes", "static-access" })
	protected void setLang(ExtendData data){
		data.setCurrent_lang_switch((Map) data.getLang_switch().get(request.getSession().getAttribute("lang")));
	}
	
	protected Map setLangExt(ExtendData data) {
		return (Map) data.getLang_switch().get(request.getSession().getAttribute("lang"));
		
	}
}
