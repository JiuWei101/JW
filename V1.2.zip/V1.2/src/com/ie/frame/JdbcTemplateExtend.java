/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 扩展JdbcTemplate类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：ghc
 * modify 					: jl
*/
package com.ie.frame;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.sql.DataSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlProvider;
import org.springframework.jdbc.core.StatementCallback;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.Assert;

import com.ie.frame.dialect.Dialect;
import com.ie.frame.dialect.MySql5Dialect;
import com.ie.frame.dialect.OracleDialect;
import com.ie.common.BeanUtil;
import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.frame.exception.ExtendUnCheckException;


public class JdbcTemplateExtend extends JdbcTemplate{
	/** 
	 * Description :初始构造器 
	 * @param ds   :数据源 
	 */ 
	public JdbcTemplateExtend(DataSource ds) {
		super.setDataSource(ds);
	}
	
	@SuppressWarnings("hiding")
	public int upDateTable(String sql){
		int ret;
		Log.log(sql);
		try{
			ret = super.update(sql);
		}catch (Exception e) {
			throw new ExtendUnCheckException(e);
		}
		return ret;
	}	
	
	/**
     * Description   ：普通分页查询。
     *                 如果结果结合比较大应该调用setFetchsize() 和setMaxRow两个方法来控制一下，否则会内存溢出
     * @param  sql   : 查询的sql语句
     * @param  startRow : 起始行
     * @param  rowsCount   : 获取的行数
     * @return List  : 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	@SuppressWarnings("hiding")
	public <T>  ArrayList queryForListExt(String sql,int startRow,int rowsCount,Class <T> clazz) throws DataAccessException{
	
		
		String querySql = getPageSql(sql,startRow,rowsCount);
		
		Log.log(querySql);
		ArrayList <T>rows  = new ArrayList<T>();
		try{
			rows = (ArrayList<T>) super.<T>query(querySql,new ExtendRowMapper(clazz));
		}catch(Exception e){
			throw new ExtendUnCheckException(e);
		}
		
		return rows;
	}
	
	/**
     * Description   ：根据数据库不同获得分页sql。
     * @param  sql   : 查询的sql语句
     * @param  startRow : 起始行
     * @param  rowsCount   : 获取的行数
     * @return String  
     */
	private String getPageSql(String sql,int startRow,int rowsCount){
		//处理分页
		Dialect dialect = null;
		Dialect.Type databaseType  = null;       
		 
		
		try{           
			 databaseType = Dialect.Type.valueOf(ConstantClass.DB_TYPE.toUpperCase());
		}catch(Exception e){
			
		}
		
		if(databaseType == null){           
			throw new RuntimeException("the value of the DB_TYPE property in config_xxx.xml is not defined : " + ConstantClass.DB_TYPE);       
		} 
		
		switch(databaseType){
			case MYSQL:
				dialect = new MySql5Dialect();  
				break;
			case ORACLE:
				dialect = new OracleDialect();  
				break;
		}  

		String querySql = dialect.getLimitString(sql, startRow, rowsCount);
		
		return querySql;
	}

	/**
     * Description   ：普通结果集查询。
     *                 如果结果结合比较大应该调用setFetchsize() 和setMaxRow两个方法来控制一下，否则会内存溢出
     * @param  sql   			: 查询的sql语句
     * @param  Class<T>
     * @return ArrayList  		: 
	 * @throws ExtendUnCheckException 
	 * @throws DataAccessException 
     */
	@SuppressWarnings("hiding")
	public <T>  ArrayList queryForListExt(String sql,Class <T> clazz) throws DataAccessException{
		ArrayList <T>rows  = new ArrayList<T>();
		try{
			rows = (ArrayList<T>) super.<T>query(sql,new ExtendRowMapper(clazz));
		}catch(Exception e){
			throw new ExtendUnCheckException(e);
		}
		
		return rows;
	}
	
	@SuppressWarnings("hiding")
	public int queryForInt(String sql){
		int total = super.queryForInt(sql);
		return total;
	}
	
	/**
     * Description   ：普通分页查询。
     *                 如果结果结合比较大应该调用setFetchsize() 和setMaxRow两个方法来控制一下，否则会内存溢出
     * @param  sql   : 查询的sql语句
     * @param  startRow : 起始行
     * @param  rowsCount   : 获取的行数
     * @return List  : 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	@SuppressWarnings("hiding")
	public JSONArray queryForJSONArrayExt(String sql,int startRow,int rowsCount) throws DataAccessException{
	
		String querySql = getPageSql(sql,startRow,rowsCount);
		
		Log.log(querySql);
		JSONArray jsonArr = new JSONArray();
		try{
			jsonArr = queryJson(querySql);
		}catch(Exception e){
			throw new ExtendUnCheckException(e);
		}
		
		return jsonArr;
	}
	
	/**
     * Description   ：普通分页查询，返回JSONArray格式数据
     *                 如果结果结合比较大应该调用setFetchsize() 和setMaxRow两个方法来控制一下，否则会内存溢出
     * @param  sql   : 查询的sql语句
     * @param  startRow : 起始行
     * @param  rowsCount   : 获取的行数
     * @return List  : 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	@SuppressWarnings("hiding")
	public JSONArray queryForJSONArrayExt(String sql) throws DataAccessException{		
		//Log.log(sql);
		JSONArray jsonArr = new JSONArray();
		try{
			jsonArr = queryJson(sql);
		}catch(Exception e){
			throw new ExtendUnCheckException(e);
		}
		
		return jsonArr;
	}
	/**
     * Description   ：查询单行数据 将对象传入 并将值付给对象 生成新对象
     * @param  sql   : 查询的sql语句
     * @param class  : 要赋值的对象的类对象
     * @return T  : 类对象对应的对象实例
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	@SuppressWarnings("hiding")
	public <T>T queryForObjectExt(String sql,Class <T> clazz) throws DataAccessException{
		T t;
		try{
			 t= clazz.newInstance();
		}catch(Exception e){
			throw new ExtendUnCheckException(e);
		}
		return this.<T>queryForObject(sql,new ExtendRowMapperObj(t),t);
	}
	/**
     * Description   ：查询单行数据 将对象传入 并将值付给对象 并不生成新对象
     * @param  sql   : 查询的sql语句
     * @param obj 	 : 要赋值的对象
     * @return Object  : 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	public <T>T queryForObjectExt(String sql,T obj){
		Log.log(sql);
		
		//通过调用自己写的继承方法来屏蔽没有结果集返回时 抛出的异常
		return this.<T>queryForObject(sql,new ExtendRowMapperObj(obj),obj);
	}
	
	/**
     * Description   ：覆盖父类方法 不调用DataAccessUtils的requiredSingleResult方法
     * 调用自己复写的方法 以达到没有结果集时 返回对象并不抛出异常
     * @param  sql   			: 查询的sql语句
     * @param RowMapper 	 	: 继承RowMapper的类对象
     * @return T  :  
     */
	public <T> T queryForObject(String sql, RowMapper<T> rowMapper,T t) throws DataAccessException {
		List<T> results = query(sql, rowMapper);
		//调用自己改造的方法
		return this.<T>requiredSingleResult(results,t);
	}
	
	/**
     * Description   ：修改DataAccessUtils的requiredSingleResult方法， 以达到没有结果集时 返回对象并不抛出异常
     * @param  Collection<T>  	 	: 集合
     * @param  T 	 				: 泛型对象
     * @return T  : 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws DataAccessException 
     */
	public <T> T requiredSingleResult(Collection<T> results,T t) throws IncorrectResultSizeDataAccessException {
		int size = (results != null ? results.size() : 0);
		//如果查询没有结果集 那么将传入的对象返回 也就是返回data 并不抛出异常
		if (size == 0) {
			return t;
		}
		if (results.size() > 1) {
			throw new IncorrectResultSizeDataAccessException(1, size);
		}
		return results.iterator().next();
	}
	/**
     * Description   ：修改jdbcTemplate类的query方法 使之返回JSONArray
     * @param  String  	 			: sql语句
     * @return JSONArray  			: JSONArray结果
	 * @throws DataAccessException 
     */
	public JSONArray queryJson(final String sql) throws DataAccessException {
		Assert.notNull(sql, "SQL must not be null");
		if (logger.isDebugEnabled()) {
			logger.debug("Executing SQL query [" + sql + "]");
		}
		class QueryStatementCallback implements StatementCallback, SqlProvider {
			public JSONArray doInStatement(Statement stmt) throws SQLException {
				ResultSet rs = null;
				try {
					rs = stmt.executeQuery(sql);
					ResultSet rsToUse = rs;
					if (getNativeJdbcExtractor() != null) {
						rsToUse = getNativeJdbcExtractor().getNativeResultSet(rs);
					}
					
					JSONArray jsonArr = new JSONArray();
					while(rsToUse.next()){
						JSONObject json = new JSONObject();
						BeanUtil.rs2json(rsToUse, json);
						
						jsonArr.add(json);
					}
					return jsonArr;
				}
				finally {
					JdbcUtils.closeResultSet(rs);
				}
			}
			public String getSql() {
				return sql;
			}
		}
		return (JSONArray) execute(new QueryStatementCallback());
	}

	public static void main(String[] args) {

	}

}
