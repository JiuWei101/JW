/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 业务Service类接口
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：
 * Modified By              : ghc
*/
package com.ie.frame;

import javax.sql.DataSource;

public interface IService {
	public abstract void setDataSource(DataSource ds);
	public abstract Object listData(Object ob);
	public abstract Object listData(Object ob,String str);
	public abstract Object queryData(Object ob);
	public abstract Object queryData(Object ob,String str);
	public abstract Object readData(Object ob);
	public abstract Object readData(Object ob,String str);
	public abstract Object saveData(Object ob);
	public abstract Object saveData(Object ob,String str);
	public abstract Object deleteData(Object ob);
	public abstract Object deleteData(Object ob,String str);
	public abstract Object updateData(Object ob);
	public abstract Object updateData(Object ob,String str);
	public abstract Object elseData(Object ob);
	public abstract Object elseData(Object ob,String str);
	public abstract Object transferData(Object ob,String str1);
	public abstract Object transferData(Object ob,String str1,String str2);
}
