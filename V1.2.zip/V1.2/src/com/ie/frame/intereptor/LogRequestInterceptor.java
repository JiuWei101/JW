/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Session拦截器实现类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
*/
package com.ie.frame.intereptor;

import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts2.StrutsStatics;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.common.Util;
import com.ie.frame.LocalSessionUtil;
import com.ie.its.login.UserInfo;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

@SuppressWarnings("serial")
public class LogRequestInterceptor extends AbstractInterceptor{
	private static Logger log = Logger.getLogger(Log.class);
	public String intercept(ActionInvocation ai) throws Exception{
		String result = "";
		//开始执行时间
		long begin = System.currentTimeMillis();
		//用于标注开始和结束的日志
		double r = Math.random();
		//发送请求用户
		String userLid = "unknown";
		//发送请求IP
		String ip = "unknown";
		//发送请求连接
		String uri = "unknown";
		HttpServletRequest request = (HttpServletRequest) ai.getInvocationContext().get(StrutsStatics.HTTP_REQUEST); 
		uri = getActionPath(request);
		
		ip = request.getRemoteHost();
		
		Object currentuser = ((HttpServletRequest) request)
				.getSession().getAttribute(
						ConstantClass.SESSION_USERNAME);
		if (currentuser != null && currentuser instanceof UserInfo) {
			userLid = ((UserInfo) currentuser).getUser_name();
		}
		//log(uri + ":" + userLid + ":" + ip + ":"
		//		+ Util.sdfTime.format(new Date()) + ":" + r);
		
		result = ai.invoke();
		return result;	
	}
	
	/**
	 * Description :获得用户当前访问Action路径 
	 * @return boolean
	 */
	public String getActionPath(HttpServletRequest request){
		String all_path[] = request.getRequestURI().split(".action");
		String action[] = all_path[0].split("/");
		String action_path = "/"+action[action.length-2] +"/"+ action[action.length-1]+".action";
		return action_path;
	}
	
	public void log(String str){
			if(ConstantClass.SYSTEM_OUT_PRINTLN){
				StackTraceElement stack[] = (new Throwable()).getStackTrace();
				for (int i = 0; i < stack.length; i++) {
					if (i == 1) {
						log.info("(" + stack[i].getFileName() + ":"
								+ stack[i].getLineNumber() + ") "
								+ str);
						break;
					}
				}
			}
	}
}
