/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Session拦截器实现类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
*/
package com.ie.frame.intereptor;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.StrutsStatics;

import com.ie.common.ConstantClass;
import com.ie.common.Log;
import com.ie.frame.LocalSessionUtil;
import com.ie.its.login.UserInfo;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

@SuppressWarnings("serial")
public class SessionInterceptor extends AbstractInterceptor{
	
	public String intercept(ActionInvocation invocation) throws Exception{
		String result = "";
		Object current_user = invocation.getInvocationContext().getSession()
				.get(ConstantClass.SESSION_USERNAME);
		HashMap rightMap = (HashMap) invocation.getInvocationContext().getSession().get(ConstantClass.SESSION_RIGHT);
		ActionContext actionContext = invocation.getInvocationContext();   
		HttpServletRequest request = (HttpServletRequest) actionContext.get(StrutsStatics.HTTP_REQUEST);
		HttpServletResponse response = (HttpServletResponse) actionContext.get(StrutsStatics.HTTP_RESPONSE);
		//Log.log("进入session拦截器");
		String itemId = request.getParameter("itemId");
		String ip = getIpAddr(request);
		if(current_user != null){
			if(itemId != null && ip != null){
				((UserInfo) current_user).setMenuid(itemId);
				((UserInfo) current_user).setIp(ip);
			}
			LocalSessionUtil.setCurrentUserInfo((UserInfo)current_user);
			LocalSessionUtil.setCurrentRightInfo(rightMap);
			LocalSessionUtil.setCurrentPath((String)invocation.getInvocationContext().getSession().get(ConstantClass.SESSION_PATH));
			result = invocation.invoke();
		}else {
			if (request.getSession().getAttribute("user") == null) // 判断session里是否有用户信息
			{
				if (request.getHeader("x-requested-with") != null
						&& request.getHeader("x-requested-with")
								.equalsIgnoreCase("XMLHttpRequest")) // 如果是ajax请求响应头会有，x-requested-with；
				{
					response.setHeader("sessionstatus", "timeout");  // 在响应头设置session状态
					Log.log("Ajax 无session信息 跳转到登录页");
					return ConstantClass.NO_SESSION_AJAX;
				}
			}
			Log.log("无session信息 跳转到登录页");
			return ConstantClass.NO_SESSION;
		}
		return result;
		
	}
	
	public String getIpAddr(HttpServletRequest request){
		String ip = request.getRemoteAddr();
		if(ip.equalsIgnoreCase("0:0:0:0:0:0:0:1")){
			ip = "localhost";
		}
		return ip;
	}
}
