/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 异常拦截器实现类
 *                            在拦截器中，捕获常见的异常，并以友好异常信息抛出
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
 * Modified By              : 
 */
package com.ie.frame.intereptor;

import java.io.IOException;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;

import com.ie.common.Log;
import com.ie.frame.exception.InterceptorException;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class ExceptionIntereptor extends AbstractInterceptor{
	
	public String intercept(ActionInvocation ai) {
		String result;
		try{
			result = ai.invoke();
		}catch(DataAccessException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("数据库操作失败！");
		}catch(NullPointerException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("调用了未经初始化的对象或者是不存在的对象！");
		}catch(IOException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("IO异常！");
		}catch(ClassNotFoundException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("指定的类不存在！");
		}catch(ArithmeticException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("数学运算异常！");
		}catch(ArrayIndexOutOfBoundsException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("数组下标越界!");
		}catch(IllegalArgumentException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("方法的参数错误！");
		}catch(ClassCastException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("类型强制转换错误！");
		}catch(SecurityException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("违背安全原则异常！");
		}catch(SQLException ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("操作数据库异常！");
		}catch(NoSuchMethodError ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("方法未找到异常！");
		}catch(InternalError ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("Java虚拟机发生了内部错误！");
		}catch(Exception ex){
			ex.printStackTrace();
			Log.log(ex.getMessage());
			throw new InterceptorException("程序内部错误！");
		}
		return result;
	}
}
