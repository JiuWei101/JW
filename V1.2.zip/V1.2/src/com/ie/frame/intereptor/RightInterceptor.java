/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : Right拦截器实现类
 * Version                  : 1.0
 * create date              : 2008.5.22
 * author                   ：ghc
*/
package com.ie.frame.intereptor;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.StrutsStatics;

import com.ie.common.ConfigInfo;
import com.ie.common.ConstantClass;
import com.ie.common.IService;
import com.ie.frame.RightCheckService;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class RightInterceptor extends AbstractInterceptor {
	private RightCheckService rc; 
	
	public String intercept(ActionInvocation ai) throws Exception{
		String result = "";
		HttpServletRequest request = (HttpServletRequest) ai.getInvocationContext().get(StrutsStatics.HTTP_REQUEST); 
		String path = getActionPath(request);
		//Log.log("当前请求Action path="+path);
		Object user_right = ai.getInvocationContext().getSession().get(ConstantClass.SESSION_RIGHT);
		Object oper = ai.getInvocationContext().getSession().get(ConstantClass.SESSION_OPER);
		
		if(user_right==null){
			Object ob = rc.queryData(null);
			ai.getInvocationContext().getSession().put(ConstantClass.SESSION_RIGHT, ob);
			user_right = ob;
			ConfigInfo.setRightmap((Map)ob);
		}
		//if(LocalSessionUtil.currentUserInfo().getUser_name().equals("admin")||checkright(user_right,path)){	//20111207取消url权限判断	km		
			result = ai.invoke();
			if(oper!=null){
				String operName = (String) ((Map)oper).get(path);
				if(!(path.equals("counters/getViewMsg.action")||
						path.equals("maintain/ajax_getData.action")||
						path.equals("maintain/ajax_updateOnline.action"))){
					rc.saveData(operName,path);  // 保存用户登录操作日志信息
				}	
			}
			
		/*}else{				
			Log.log(path+"：没有权限！");
			rc.saveData("没有权限访问",path);  // 保存用户登录操作日志信息
			return ConstantClass.NO_ACCESS;
		}
		*/
		
		return result;
		
	}
	
	/**
	 * Description :判断权限是否存在 
	 * @return boolean
	 */
	public boolean checkright(Object ob,String path){		
		HashMap map = (HashMap)ob;
		return map.containsValue(path);
//		return true;
	}
	
	/**
	 * Description :获得用户当前访问Action路径 
	 * @return boolean
	 */
	public String getActionPath(HttpServletRequest request){
		String all_path[] = request.getRequestURI().split(".action");
		String action[] = all_path[0].split("/");
		String action_path = action[action.length-2] +"/"+ action[action.length-1]+".action";
		return action_path;
	}

	public RightCheckService getRc() {
		return rc;
	}

	public void setRc(RightCheckService rc) {
		this.rc = rc;
	}
}
