/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 保存获得本地线程的各种用户信息
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：
 * Modified By              : ghc
*/
package com.ie.frame;

import java.util.HashMap;

import com.ie.its.login.UserInfo;

public final class LocalSessionUtil {	
	/*
	 * ThreadLocal通过为每个线程提供一个独立的变量副本解决了变量并发访问的冲突问题。
	 * ThreadLocal比直接使用synchronized同步机制解决线程安全问题更简单，更方便，且结果程序拥有更高的并发性。
	 */
	private static final ThreadLocal session = new ThreadLocal();      //用户信息
	private static final ThreadLocal session2 = new ThreadLocal();	   //路径
	private static final ThreadLocal session3 = new ThreadLocal();     //登录用户名
	private static final ThreadLocal session4 = new ThreadLocal();     //用户权限
	
	private LocalSessionUtil() {
		
	}	
	
	/**
     * Description :该方法返回当前线程所对应的线程局部变量,用户权限实例
     * @return  HashMap :用户权限实例
     */
	public static HashMap currentRightInfo() {
		HashMap rightMap = (HashMap) session4.get();		
		return rightMap;
	}
	
	/**
     * Description :设置当前线程的线程局部变量的值,用户权限实例
     * @param  hashmap :用户权限实例
     */
	public static void setCurrentRightInfo(HashMap rightMap) {
		session4.set(rightMap);		
	}
	
	/**
     * Description :该方法返回当前线程所对应的线程局部变量,用户信息实例
     * @return  UserInfo :用户信息实例
     */
	public static UserInfo currentUserInfo() {
		UserInfo ui = (UserInfo) session.get();		
		return ui;
	}
	
	/**
     * Description :该方法返回当前线程所对应的线程局部变量,路径
     * @return  String :路径
     */
	public static String currentPath() {
		String path = (String) session2.get();		
		return path;
	}
	
	/**
     * Description :该方法返回当前线程所对应的线程局部变量,登录用户名
     * @return  String :登录用户名
     */
	public static String currentLoginUser() {
		String loginusername = (String) session3.get();		
		return loginusername;
	}
	
	/**
     * Description :设置当前线程的线程局部变量的值,用户信息
     * @param  current_user :用户信息实例
     */
	public static void setCurrentUserInfo(Object current_user) {
		session.set(current_user);		
	}
	
	/**
     * Description :设置当前线程的线程局部变量的值,路径
     * @param  path :路径字符串
     */
	public static void setCurrentPath(String path) {
		session2.set(path);		
	}
	
	/**
     * Description :设置当前线程的线程局部变量的值,登录用户名
     * @param  path :loginusername
     */
	public static void setCurrentLoginUser(String loginusername) {
		session3.set(loginusername);		
	}

}
