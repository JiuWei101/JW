/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 扩展运行时异常类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：huangmingwei
 * Modified By              : ghc
*/
package com.ie.frame.exception;

public class ExtendUnCheckException extends RuntimeException {
	
	private String errorCode;

	public ExtendUnCheckException() {
		super();
	}	
	public ExtendUnCheckException(Throwable t) {
		super(t);
	}
	public ExtendUnCheckException(String s) {
		super(s);
	}

	public  ExtendUnCheckException(String errcode,String errmsg){
		super(errmsg);
		setErrorCode(errcode);
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	
}
