/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 异常处理类
 * Version                  : 1.0
 * create date              : 2008.4.08
 * author                   ：jl
 * Modified By              : ghc
*/
package com.ie.frame.exception;

public class InterceptorException extends RuntimeException{

	public InterceptorException(String frdMessage){
		super(createFriendlyErrMsg(frdMessage));
    }

    public InterceptorException(Throwable throwable){
        super(throwable);
    }

    public InterceptorException(Throwable throwable, String frdMessage){
        super(throwable);
    }

	private static String createFriendlyErrMsg(String msgBody){
	
		String prefixStr = "抱歉，";	
		String suffixStr = " 请稍后再试或与管理员联系！";
		
		StringBuffer friendlyErrMsg = new StringBuffer("");
		
		friendlyErrMsg.append(prefixStr);
		friendlyErrMsg.append(msgBody);
		friendlyErrMsg.append(suffixStr);
		
		return friendlyErrMsg.toString();
	}


}
