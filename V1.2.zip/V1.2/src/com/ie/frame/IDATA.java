/**
 * Copy Right Information   : Forsoft 
 * Project                  : ICS
 * JDK version used         : jdk1.6
 * Comments                 : 公共Data类接口
 * Version                  : 1.0
 * create date              : 2008.4.15
 * author                   ：jl
*/
package com.ie.frame;

public interface IDATA {
	
	public String getId();
	
	public void setId(String string);
	
	public int getStart();
	
	public void setStart(int start);
		
	public int getTotal();
	
	public void setTotal(int string);
	
	public Object getPer_data();
	
	public void setPer_data(Object object);
}
