package com.ie.frame;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ie.common.BeanUtil;
import com.ie.frame.exception.ExtendUnCheckException;


public class ExtendRowMapper<T> implements RowMapper{
	private T t;
	private Class clazz;
	public ExtendRowMapper(final Class<T> clazz){
		this.clazz = clazz;
	}
	 public T mapRow(ResultSet rs, int index) throws SQLException {
		 try{
			 t = (T) this.clazz.newInstance();
			 BeanUtil.rs2bean(rs, t);
		 }catch(Exception e){
			 throw new ExtendUnCheckException(e);
		 }
		 
		 return t;
	}

}
