package com.ie.frame;

import java.util.ArrayList;

import com.ie.common.Util;

public class ExtendSql {
	
	/**
     * Description :返回in查询条件．
     * @param  :String []
     * @return :String
     */
	public String getInCond(String []cond){
		if(cond.length ==0){
			return "";
		}
		String condRet = "(";
		
		for(int i = 0;i < cond.length;i++){
			condRet += Util.toSqlVal(cond[i]);
			
			if((i+1) != cond.length){
				condRet += ",";
			}
		}
		
		condRet += ")";
		return condRet;
	}
	
	/**
     * Description :返回in查询条件．
     * @param  :ArrayList
     * @return :String
     */
	public String getInCond(ArrayList cond){
		if(cond.size() ==0){
			return "";
		}
		String condRet = "(";
		
		for(int i = 0;i < cond.size();i++){
			condRet += Util.toSqlVal(cond.get(i));
			
			if((i+1) != cond.size()){
				condRet += ",";
			}
		}
		
		condRet += ")";
		return condRet;
	}
}
