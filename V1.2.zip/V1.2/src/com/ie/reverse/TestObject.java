package com.ie.reverse;

import java.util.ArrayList;
import java.util.List;

public class TestObject {
	
	public static void main(String[] args) {
		Point p1 = new Point(1, 2,"","");
		Point p2 = new Point(2, 4,"","");
		Point p6 = new Point(5, 1,"","");
		List<Segment> list = new ArrayList<Segment>();
		Segment sg12=new Segment(p1,p2);
		list.add(sg12);
		Segment sg16=new Segment(p1,p6);
		list.add(sg16);
		if(list.get(0).getS()==p1){
			System.out.println("+++");
		}
		
	}
	
}
