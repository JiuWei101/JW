package com.ie.reverse;

import java.util.ArrayList;
import java.util.Iterator;

import java.util.List;

public class TestShortDistanceOfTwoPoint {

	/**
	 * @param args
	 */
	// 描点集合
	static Point p1 = new Point(1, 4,"","");
	static Point p2 = new Point(3.2, 5.5,"","");
	static Point p3 = new Point(4.2, 6,"","");
	static Point p4 = new Point(7.2, 6,"","");
	static Point p5 = new Point(5.5, 3.5,"","");
	static Point p6 = new Point(5, 1.5,"","");

	// 定义起点
	static Point s1 = new Point(3, 1,"","");
	// 定义终点 E1
	static 	Point e1 = new Point(3.55, 4.5,"","");
	static Point pCross=null;
	 static int M=10000;//(此路不通)
	public static void main(String[] args) {

		// 所有点放入集合
		List<Point> pointList = new ArrayList<Point>();
		
		pointList.add(s1);

		pointList.add(p1);
		pointList.add(p2);
		pointList.add(p3);
		pointList.add(p4);

		pointList.add(p5);
		pointList.add(p6);

		// 可达边集合
		List<Segment> list = new ArrayList<Segment>();
		Segment sg12 = new Segment(p1, p2);
		list.add(sg12);
		Segment sg16 = new Segment(p1, p6);
		list.add(sg16);
		Segment sg15 = new Segment(p1, p5);
		list.add(sg15);
		Segment s1p1 = new Segment(p1, s1);
		list.add(s1p1);
		Segment sg23 = new Segment(p2, p3);
		list.add(sg23);
		Segment sg25 = new Segment(p2, p5);
		list.add(sg25);
		Segment sg35 = new Segment(p3, p5);
		list.add(sg35);
		Segment sg45 = new Segment(p4, p5);
		list.add(sg45);
		Segment sg56 = new Segment(p5, p6);
		list.add(sg56);
		Segment s1p6 = new Segment(p6, s1);
		list.add(s1p6);

		// 得到終點到最短邊的所在的線段
		Line l = getTheShortestDistanceOfLine(list, e1);
		System.out.println("start:" + "X:" + l.getPs().getX() + "Y:"
				+ l.getPs().getY());
		System.out.println("end:" + "X:" + l.getPe().getX() + "Y:"
				+ l.getPe().getY());
		/*
		 * 得到经过终点到最短边的垂线方程以及垂线与直线的交点的坐标 经过终点e1到直线y=kx+b 对应垂线方程为 -x -ky + m =
		 * 0;(m为系数) y=ax+b m = e1.x() + A*e1.y(); //终点坐标
		 * ptCross.setX((m-A*B)/(A*A + 1)); ptCross.setY(A*ptCross.x()+B);
		 */
		double m = e1.getX() + l.getK() * e1.getY();
		double A = l.getK();
		double B = l.getB();
		double x = (m - A * B) / (A * A + 1);
		// 垂直点
		 pCross = new Point(x, A * x + B,"","");
		 pointList.add(pCross);
		 pointList.add(e1);
		 
		 //起点到终点的直线距离
		 double se=Math.sqrt(Math.pow(s1.getX()-e1.getX(), 2)+Math.pow(s1.getY()-e1.getY(),2));
		
		// 拆分最短边
		Segment adds1 = new Segment(l.getPs(), pCross);
		Segment adds2 = new Segment(l.getPe(), pCross);
		list.add(adds1);
		list.add(adds2);
		// 删除最短边
		for (int i = 0; i < list.size(); i++) {
			Segment e = (Segment) list.get(i);
			if (e.getS() == l.getPs() && e.getE() == l.getPe()) {
				list.remove(i);
				break;
			}
		}
		double [][] weight1 =new double [pointList.size()][pointList.size()];
		for (int i = 0; i < pointList.size(); i++) {
			Point p = (Point) pointList.get(i);
			// 找出p所对应的所有的子节点集合
			List<Point> subPoints = getSubPoints(p);
			p.setSubPoints(subPoints);
			//拼出二位矩阵
			getTheMatrixPoint(subPoints,pointList,p,weight1,i);
			//p.setSubPoints(subPoints);
			
		}
		for (int i=0;i<weight1.length;i++){
			for( int j=0;j<=weight1[1].length-1;j++){
				if(j==weight1[1].length-1){
					System.out.print(weight1[i][j]);
				}
				else System.out.print(weight1[i][j]+"  ,  ");
			}
			System.out.println("");
		}
		 double[] shortPath  =ShortestDistanceOfTwoPoint_V2.Dijsktra(weight1, 0, 8);
		
         
	        for(int i = 0;i < shortPath.length;i++)  
	            if(i==8){
	            	System.out.println("从"+0+"出发到"+i+"的最短距离为："+shortPath[i]);  
	            } 
	
	        System.out.println("从起点"+"出发到"+"终点的的直线距离为："+se); 
	        System.out.println("pCross X:"+pCross.getX()+"pCross Y:"+pCross.getY()); 
	}

	
	

	//拼出二维矩阵
     private static void getTheMatrixPoint(List subPoints,List allPoints,Point p,double weight[][],int i) {
    	 Iterator<Point> iter = allPoints.iterator() ; 
    	 int k=0;
    	 while(iter.hasNext()) { 
    	    double length=0;
    	    
    		 Point temP= iter.next();
    		 if(subPoints.contains(temP)){
    	    	  length=Math.sqrt(Math.pow(p.getX()-temP.getX(), 2)+Math.pow(p.getY()-temP.getY(),2));
    	    	  weight[i][k]=length;
    	    	 
    	      }else if(i==k){
    	    	  weight[i][k]=0;
    	      }
    	      else {
    	    	  weight[i][k]=M;
    	      }
    		 k++;
    	 }
	}

	//取得每个节点的子节点
	private static List<Point> getSubPoints(Point p) {
		List <Point>list=new ArrayList<Point>();
		if(p==s1){
			list.add(p1);	
			list.add(p6);
		}
		else if(p==p1){
			list.add(p2);	
			list.add(p5);
			list.add(s1);
		}else if(p==p2){
			list.add(p1);
			list.add(p3);
			list.add(pCross);
		}else if(p==p3){
			list.add(p2);	
			list.add(p5);
		}else if(p==p4){
			list.add(p5);
		}else if(p==p5){
			list.add(p1);
			list.add(pCross);	
			list.add(p3);
			list.add(p4);
			list.add(p6);
		}else if(p==p6){
			list.add(p5);
			list.add(s1);
		}
		else if(p==e1){
			list.add(pCross);
		}
		else if(p==pCross){
			list.add(e1);
			list.add(p5);
			list.add(p2);
		}
		return list;
	}

	// 终点到所有可达边的最小距离所在的直线
	public static Line getTheShortestDistanceOfLine(List ls, Point p) {
		Line s = null;
		for (int i = 0; i < ls.size(); i++) {
			Segment e = (Segment) ls.get(i);
			Line l = getLineByPoint(e.getS(), e.getE());
			s = getTheDistanceOfPointToLine(l, p);

		}
		return s;

	}

	// 两点组成一条直线
	public static Line getLineByPoint(Point p1, Point p2) {
		// y=kx+b 直线方程式
		// TODO Auto-generated method stub
		// k=y2-y1/x2-x1;
		// b=y1-(y2-y1)*x1/(x2-x1)
		double k = (p2.getY() - p1.getY()) / (p2.getX() - p1.getX());
		double b = p1.getY() - k * p1.getX();

		return new Line(k, b, p1, p2);
	}

//	static double distance = 0;
//	static Line s = null;
//
//	// 返回点到线的最短距离的线段
//	public static Line getTheShortestLine(Line line, Point p) {
//		// 距离=|kx1-y1+b|/√[k²+（-1）²] kX1-Y1+b的绝对值除以根号下1+k^2
//
//		double m = Math.abs(line.getK() * p.getX() - p.getY() + line.getB());
//		double n = Math.sqrt(1 + line.getK() * line.getK());
//		double tempDistance = m / n;
//
//		if ((distance == 0) || (tempDistance < distance)) {
//			distance = tempDistance;
//			s = line;
//		}
//		return s;
//	}
	static double distance = 0;
	static Line s = null;
	
	// 返回点到线的最短距离的线段
	public static Line getTheDistanceOfPointToLine(Line line, Point p) {
		/*
		 * 得到经过终点到最短边的垂线方程以及垂线与直线的交点的坐标 经过终点e1到直线y=kx+b 对应垂线方程为 -x -ky + m =
		 * 0;(m为系数) y=ax+b m = e1.x() + A*e1.y(); //终点坐标
		 * ptCross.setX((m-A*B)/(A*A + 1)); ptCross.setY(A*ptCross.x()+B);
		 */
       //点到线垂直点
		double m1 = p.getX() + line.getK() * p.getY();
		double A = line.getK();
		double B = line.getB();
		double x = (m1 - A * B) / (A * A + 1);
		
		// 垂直点
		Point pCross = new Point(x, A * x + B,"cross","");
		 line.setpCross(pCross);
		 //起点，终点的横坐标
		 double lineXs=line.getPs().getX();
		 double lineXe=line.getPe().getX();
		 double k;
		 if(lineXe<lineXs){
			 k=lineXe;
			 lineXe=lineXs;
			 lineXs=k;
		 }
		 //起点，终点的纵坐标
		 double lineYs=line.getPs().getY();
		 double lineYe=line.getPe().getY();
		 if(lineYe<lineYs){
			 k=lineYe;
			 lineYe=lineYs;
			 lineYs=k;
		 }
		 //垂直点必须在起点和终点的坐标之间
		if((lineXs<=pCross.getX()&&pCross.getX()<=lineXe)||(lineYs<=pCross.getY()&&pCross.getY()<=lineYe)){
			 // 距离=|kx1-y1+b|/√[k²+（-1）²] kX1-Y1+b的绝对值除以根号下1+k^2

			double m = Math.abs(line.getK() * p.getX() - p.getY() + line.getB());
			double n = Math.sqrt(1 + line.getK() * line.getK());
			double tempDistance = m / n;
			if(distance==0||tempDistance<=distance){
				distance=tempDistance;
				s=line;
			}
		}
		
		return s;
		
	}
}
