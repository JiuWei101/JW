package com.ie.reverse;

public class Line {
	private double k;
	private double b;
    private Point ps;
    private Point pe;
    private  Point pCross;

	public Point getpCross() {
		return pCross;
	}

	public void setpCross(Point pCross) {
		this.pCross = pCross;
	}

	public Line(double k, double b,Point ps,Point pe) {
		this.k = k;
		this.b = b;
		this.ps=ps;
		this.pe=pe;
	}

	public Point getPs() {
		return ps;
	}



	public void setPs(Point ps) {
		this.ps = ps;
	}



	public Point getPe() {
		return pe;
	}



	public void setPe(Point pe) {
		this.pe = pe;
	}



	public double getK() {
		return k;
	}

	public void setK(double k) {
		this.k = k;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	
}
