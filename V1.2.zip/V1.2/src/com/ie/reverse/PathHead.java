package com.ie.reverse;

import java.util.List;

public class PathHead {
	private String id;
	private String mapId;
	private String start;
	private String end;
	private String headid;
	private String pointid;
	private double weight;
	private int sort;
	private String note;
	private List<PathHead> subPathHeads;
	
	public PathHead(String id,String mapId,String start,String end,double weight){
		this.id = id;
		this.mapId = mapId;
		this.start = start;
		this.end = end;
		this.weight = weight;
	}
	
	public PathHead(String headid,String pointid,int sort){
		this.headid = headid;
		this.pointid = pointid;
		this.sort = sort;
	}
	
	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public List<PathHead> getSubPathHeads() {
		return subPathHeads;
	}
	public void setSubPathHeads(List<PathHead> subPathHeads) {
		this.subPathHeads = subPathHeads;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getHeadid() {
		return headid;
	}
	public void setHeadid(String headid) {
		this.headid = headid;
	}
	public String getPointid() {
		return pointid;
	}
	public void setPointid(String pointid) {
		this.pointid = pointid;
	}
	public int getSort() {
		return sort;
	}
	public void setSort(int sort) {
		this.sort = sort;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
}
