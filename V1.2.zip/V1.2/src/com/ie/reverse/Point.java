package com.ie.reverse;

import java.io.Serializable;
import java.util.List;

/**
 * 点基类
 * @author Administrator
 *
 */
@SuppressWarnings("serial")
public class Point implements Serializable{
	private String mapId;	//地图id
	private String id;		//点id
	private String name;	//点flash地图编码，如A1-B1,C1
	private String code;	//点名称，如A1
    private double x;
    private double y;
    private String ip;		//查询机点ip
	private List <Point>subPoints ;   //描点的子节点 集合
    private int flag;				 //标示符，过程点或者起点
    private String note;			//备注
    private String ifcarsearchpc;	//是否查询机(1为查车机；0为普通的路径节点)
    private double weight;		//查询起点到终点的长度
    
    private String headid;	//父节点id，subPoints属性
    private double pathweights;	//连通路径权值，subPoints属性
    public Point(){
    	
    }
    public Point(double x,double y,String name,String code){
    	this.x=x;
    	this.y=y;
    	this.name = name;
    	this.code = code;
    }
    public Point(double x,double y,String name,String code,String mapId){
    	this.x = x;
    	this.y = y;
    	this.name = name;
    	this.code = code;
    	this.mapId = mapId;
    }
    
    public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getMapId() {
		return mapId;
	}
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getIp() {
		return ip;
	}


	public void setIp(String ip) {
		this.ip = ip;
	}


	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public List<Point> getSubPoints() {
		return subPoints;
	}
	public void setSubPoints(List<Point> subPoints) {
		this.subPoints = subPoints;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public void setY(double y) {
		this.y = y;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getIfcarsearchpc() {
		return ifcarsearchpc;
	}
	public void setIfcarsearchpc(String ifcarsearchpc) {
		this.ifcarsearchpc = ifcarsearchpc;
	}
	public String getHeadid() {
		return headid;
	}
	public void setHeadid(String headid) {
		this.headid = headid;
	}
	public double getPathweights() {
		return pathweights;
	}
	public void setPathweights(double pathweights) {
		this.pathweights = pathweights;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "Point [mapId=" + mapId + ", id=" + id + ", name=" + name
				+ ", code=" + code + ", x=" + x + ", y=" + y + ", ip=" + ip
				+ ", subPoints=" + subPoints + ", flag=" + flag + ", note="
				+ note + ", ifcarsearchpc=" + ifcarsearchpc + ", weight="
				+ weight + ", headid=" + headid + ", pathweights="
				+ pathweights + "]";
	}
	
    
    
}
