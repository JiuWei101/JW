package com.ie.reverse;
/**
 * 线段类
 * @author Administrator
 *
 */
public class Segment {
    private Point s;
    private Point e;
	private double length;
    public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public Point getS() {
		return s;
	}

	public void setS(Point s) {
		this.s = s;
	}

	public Point getE() {
		return e;
	}

	public void setE(Point e) {
		this.e = e;
	}

	public Segment (Point s,Point e){
    	this.s=s;
    	this.e=e;
    	this.length = Math.sqrt(Math.pow(s.getX()-e.getX(), 2)+Math.pow(s.getY()-e.getY(),2));
    }
}
