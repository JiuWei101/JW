package com.ie.reverse;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ReverseCommon {
	
	// 两点组成一条直线
	public static Line getLineByPoint(Point p1, Point p2) {
		// y=kx+b 直线方程式
		// TODO Auto-generated method stub
		// k=y2-y1/x2-x1;
		// b=y1-(y2-y1)*x1/(x2-x1)
		double k = (p2.getY() - p1.getY()) / (p2.getX() - p1.getX());
		double b = p1.getY() - k * p1.getX();

		return new Line(k, b, p1, p2);
	}
	
	static double distance = 0;
	static Line s = null;
	
	// 返回点到线的最短距离的线段
	public static Line getTheDistanceOfPointToLine(Line line, Point p) {
		/*
		 * 得到经过终点到最短边的垂线方程以及垂线与直线的交点的坐标 经过终点e1到直线y=kx+b 对应垂线方程为 -x -ky + m =
		 * 0;(m为系数) y=ax+b m = e1.x() + A*e1.y(); //终点坐标
		 * ptCross.setX((m-A*B)/(A*A + 1)); ptCross.setY(A*ptCross.x()+B);
		 */
       //点到线垂直点
		Point pCross=null;
		if(line.getPs().getX()==line.getPe().getX()){
			pCross=new Point(line.getPs().getX(),p.getY(),"","cross");
		}else{
			double m1 = p.getX() + line.getK() * p.getY();
			double A = line.getK();
			double B = line.getB();
			double x = (m1 - A * B) / (A * A + 1);
			pCross = new Point(x, A * x + B,"","cross");
		}
		
		// 垂直点
		 
		 line.setpCross(pCross);
		 //起点，终点的横坐标
		 double lineXs=line.getPs().getX();
		 double lineXe=line.getPe().getX();
		 double k;
		 if(lineXe<lineXs){
			 k=lineXe;
			 lineXe=lineXs;
			 lineXs=k;
		 }
		 //起点，终点的纵坐标
		 double lineYs=line.getPs().getY();
		 double lineYe=line.getPe().getY();
		 if(lineYe<lineYs){
			 k=lineYe;
			 lineYe=lineYs;
			 lineYs=k;
		 }
		 //垂直点必须在起点和终点的坐标之间
		if((lineXs<=pCross.getX()&&pCross.getX()<=lineXe)&&(lineYs<=pCross.getY()&&pCross.getY()<=lineYe)){
			 // 距离=|kx1-y1+b|/√[k²+（-1）²] kX1-Y1+b的绝对值除以根号下1+k^2

//			double m = Math.abs(line.getK() * p.getX() - p.getY() + line.getB());
//			double n = Math.sqrt(1 + line.getK() * line.getK());
			double tempDistance = Math.sqrt(Math.pow(p.getX()-pCross.getX(), 2)+Math.pow(p.getY()-pCross.getY(),2));
			if(distance==0||tempDistance<=distance){
				distance=tempDistance;
				s=line;
			}
		}
		
		return s;
		
	}
//	// 终点到所有可达边的最小距离所在的直线
//	public static Line getTheShortestDistanceOfLine(List ls, Point p) {
//		s = null;
//		distance = 0;
//		Line s = null;
//		for (int i = 0; i < ls.size(); i++) {
//			Segment e = (Segment) ls.get(i);
//			Line l = getLineByPoint(e.getS(), e.getE());
//			s = getTheDistanceOfPointToLine(l, p);
//
//		}
//		return s;
//
//	}
	
	// 终点到所有可达边的最小距离所在的直线
	public static Map getTheShortestDistanceOfLine(List ls, Point p) {
		Map map = new HashMap();
		s = null;
		distance = 0;
		Line s = null;
		for (int i = 0; i < ls.size(); i++) {
			Segment e = (Segment) ls.get(i);
			Line l = getLineByPoint(e.getS(), e.getE());
			s = getTheDistanceOfPointToLine(l, p);

		}
		map.put("line", s);
		map.put("distance", distance);
		return map;

	}
	
	//获取垂直点
	public static Point getCrossPoint(Line l, Point p){
		// 得到終點到最短邊的所在的線段
		//Line l = getTheShortestDistanceOfLine(ls, p);
		/*
		 * 得到经过终点到最短边的垂线方程以及垂线与直线的交点的坐标 经过终点e1到直线y=kx+b 对应垂线方程为 -x -ky + m =
		 * 0;(m为系数) y=ax+b m = e1.x() + A*e1.y(); //终点坐标
		 * ptCross.setX((m-A*B)/(A*A + 1)); ptCross.setY(A*ptCross.x()+B);
		 */
		double m = p.getX() + l.getK() * p.getY();
		double A = l.getK();
		double B = l.getB();
		double x = (m - A * B) / (A * A + 1);
		Point pCross = new Point(x, A * x + B,"","cross");
		return pCross;
	}
	
	/**
	 * 
	 * @param list
	 * @param l
	 * @param pCross
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" }) 
	public static List<Segment> getNewSegmentList(List list,Line l,Point pCross){
		// 拆分最短边
		Segment adds1 = new Segment(l.getPs(), pCross);
		Segment adds2 = new Segment(l.getPe(), pCross);
		list.add(adds1);
		list.add(adds2);
		// 删除最短边
		for (int i = 0; i < list.size(); i++) {
			Segment e = (Segment) list.get(i);
			if (e.getS() == l.getPs() && e.getE() == l.getPe()) {
				list.remove(i);
				break;
			}
		}
		return list;
	}
	/**
	 * 重组图点集
	 * @param list
	 * @param l
	 * @param pCross
	 * @param carPoint
	 * @return
	 */
	public static List<Point> getNewPointList(List list,Line l,Point pCross,Point carPoint){
		List<Point> subs = new ArrayList<Point>();
		subs.add(pCross);
		carPoint.setSubPoints(subs);
		List<Point> carsubs = new ArrayList<Point>();
		Point spoint = l.getPs();
		Point epoint = l.getPe();
		carsubs.add(carPoint);
		carsubs.add(spoint);
		carsubs.add(epoint);
		pCross.setSubPoints(carsubs);
		for(int k=0; k<list.size(); k++){
			Point temp = (Point)list.get(k);
			if(temp.getCode().equals(spoint.getCode())){
				for(int i=0; i<temp.getSubPoints().size(); i++){
					if(temp.getSubPoints().get(i).getCode().equals(epoint.getCode())){
						temp.getSubPoints().remove(i);
					}
				}
				temp.getSubPoints().add(pCross);
			}
			if(temp.getCode().equals(epoint.getCode())){
				for(int i=0; i<temp.getSubPoints().size(); i++){
					if(temp.getSubPoints().get(i).getCode().equals(spoint.getCode())){
						temp.getSubPoints().remove(i);
					}
				}
				temp.getSubPoints().add(pCross);
			}
		}
		list.add(pCross);
		list.add(carPoint);
		return list;
	}
	
	/**
	 * 
	 * @param list
	 * @param onePoint_id
	 * @param anoPoint_id
	 * @param pCross
	 * @param carPoint
	 * @return
	 */
	public static List<Point> getNewPointList(List list,String onePoint_id,String anoPoint_id,Point pCross,Point carPoint){
		List<Point> rList = list;
		List<Point> subs = new ArrayList<Point>();
		subs.add(pCross);
		carPoint.setSubPoints(subs);
		List<Point> carsubs = new ArrayList<Point>();
		Point spoint = new Point();
		Point epoint = new Point();
		carsubs.add(carPoint);
//		carsubs.add(spoint);
//		carsubs.add(epoint);
		pCross.setSubPoints(carsubs);
		for(int k=0; k<rList.size(); k++){
			Point temp = (Point)rList.get(k);
			if(temp.getId().equals(onePoint_id)){//节点id和最短直线某一端点id相同
				for(int i=0; i<temp.getSubPoints().size(); i++){
					if(temp.getSubPoints().get(i).getId().equals(anoPoint_id)){
						temp.getSubPoints().remove(i);
					}
				}
				temp.getSubPoints().add(pCross);
				spoint = temp;
			}
			if(temp.getId().equals(anoPoint_id)){
				for(int i=0; i<temp.getSubPoints().size(); i++){
					if(temp.getSubPoints().get(i).getId().equals(onePoint_id)){
						temp.getSubPoints().remove(i);
					}
				}
				temp.getSubPoints().add(pCross);
				epoint = temp;
			}
		}
		pCross.getSubPoints().add(spoint);
		pCross.getSubPoints().add(epoint);
		rList.add(pCross);
		rList.add(carPoint);
		return rList;
	}
	
	public static List<Point> getNewPointList(List list,String onePoint_id,Point carPoint){
		List<Point> rList = list;
		List<Point> carsubs = new ArrayList<Point>();
		for(int k=0; k<rList.size(); k++){
			Point temp = (Point)rList.get(k);
			if(temp.getId().equals(onePoint_id)){//节点id和最短直线某一端点id相同
				temp.getSubPoints().add(carPoint);
				carsubs.add(temp);
			}
		}
		carPoint.setSubPoints(carsubs);
		rList.add(carPoint);
		return rList;
	}
	
	static int M = 100000;
	public static double[][] getMatrix(List<Point> list){
		double[][] weight = new double[list.size()][list.size()];
		for(int i=0; i<list.size(); i++){
			Point p = list.get(i);
			//System.out.print(p.getCode()+"-");
			List<Point> pSubs = p.getSubPoints();
			for(int j=0; j<list.size(); j++){
				Point jp = list.get(j);
				if(p.getCode().equals(jp.getCode())){
					weight[i][j] = 0;
				}else{
					double length = 0;
					for(int k=0; k<pSubs.size(); k++){
						if(pSubs.get(k).getCode().equals(jp.getCode())){
							length = Math.sqrt(Math.pow(p.getX()-jp.getX(), 2)+ Math.pow(p.getY()-jp.getY(),2));
						}
					}
					if(length != 0){
						weight[i][j] = length;
					}else{
						weight[i][j] = M;
					}
				}
					
			}
		}
		
//		for (int i=0;i<weight.length;i++){
//			for( int j=0;j<=weight[1].length-1;j++){
//				if(j==weight[1].length-1){
//					System.out.print(weight[i][j]);
//				}
//				else System.out.print(weight[i][j]+"  ,  ");
//			}
//			System.out.println("");
//		}
		
		return weight;
	}
	
	/**
	 * Dijsktra算法求最短路径
	 * @param fileWriter
	 * @param weight
	 * @param list
	 * @param startPoint
	 * @param endPoint
	 * @return
	 * @throws IOException
	 */
    public static Map Dijsktra(FileWriter fileWriter,double[][] weight,List<Point> list,Point startPoint,Point endPoint) throws IOException{  
        //接受一个有向图的权重矩阵，和一个起点编号start（从0编号，顶点存在数组中）  
           //返回一个int[] 数组，表示从start到它的最短路径长度  
           int n = weight.length;     //顶点个数 
           Map rmap = new HashMap(); //结果map
           List<Point> rList = new ArrayList<Point>();
           int start = getIndexOfPoint(list,startPoint);
           int end = getIndexOfPoint(list,endPoint);
           double[] shortPath = new double[n];    //存放从start到其他各点的最短路径  
           String[] path=new String[n]; //存放从start到其他各点的最短路径的字符串表示  
           for(int i=0;i<n;i++){
        	   path[i]=new String(start+","+i);  
           }
           int[] visited = new int[n];   //标记当前该顶点的最短路径是否已经求出,1表示已求出  
             
           //初始化，第一个顶点求出  
           shortPath[start] = 0;  
           visited[start] = 1;  
     
           for(int count = 1;count <= n - 1;count++)  //要加入n-1个顶点  
           {  
      
               int k = -1;    //选出一个距离初始顶点start最近的未标记顶点  
               double dmin = Integer.MAX_VALUE;  
               for(int i = 0;i < n;i++)  
               {  
                   if(visited[i] == 0 && weight[start][i] < dmin)  
                   {  
                       dmin = weight[start][i];  
                        
                       k = i;  
                   }    
                         
               }  
             if(k==-1){
            	 break;
             }
              
                  
               //将新选出的顶点标记为已求出最短路径，且到start的最短路径就是dmin  
               shortPath[k] = dmin;  
     
               visited[k] = 1;  
         int m=0;
               //以k为中间点，修正从start到未访问各点的距离  
               for(int i = 0;i < n;i++)  
               {                   
                   if(visited[i] == 0 && weight[start][k] + weight[k][i] < weight[start][i]){  
                        weight[start][i] = weight[start][k] + weight[k][i];  
                        m++;
                        path[i]=path[k]+","+i;  
                      
                   }  
                     
               }    
           if(m==0){
        	   count--;
           }
           }  
//            for(int i=0;i<n;i++)  
//              if(i==end){
//           	   System.out.println("从"+start+"出发到"+i+"的最短路径为："+path[i]); 
//           	   System.out.println("====================================="); 
//              }
           	//System.out.println("从"+start+"出发到"+end+"的最短路径为："+path[end]);
            String[] indexArr = path[end].split(",");
            for(int i=0; i<indexArr.length; i++){
            	rList.add(list.get(Integer.parseInt(indexArr[i])));
            }
            double lineDistance = Math.sqrt(Math.pow(
    				startPoint.getX() - endPoint.getX(), 2)
    				+ Math.pow(startPoint.getY() - endPoint.getY(), 2));
    		// 线路距离小于1倍距离
    		if (shortPath[end] < lineDistance) {
    			fileWriter.write("\r\n");
    			fileWriter.write("===================================");
    			fileWriter.write(startPoint.getCode()+"-->"+endPoint.getCode()+"该路径小于1倍直线距离 ");
    			String[] indexArr1 = path[end].split(",");
    			for (int i = 0; i < indexArr1.length; i++) {
    				//System.out.print((list.get(Integer.parseInt(indexArr[i]))).getCode()+"--->");
    				fileWriter.write((list.get(Integer.parseInt(indexArr1[i]))).getCode()+"--->");
    			}
    			 fileWriter.write(startPoint.getCode()+"-->"+endPoint.getCode() + "的最短路径距离为："
    						+ shortPath[end]);
    			 fileWriter.write(startPoint.getCode()+"-->"+endPoint.getCode() +"的直线距离为："+lineDistance);
    			 fileWriter.flush();
    		}
    		// 线路距离 大于2倍距离
    		else if (shortPath[end] > 2 * lineDistance) {
    			fileWriter.write("\r\n");
    			fileWriter.write("===================================");
    			fileWriter.write(startPoint.getCode()+"-->"+endPoint.getCode()+"该路径大于2倍直线距离");
    			String[] indexArr1 = path[end].split(",");
    			for (int i = 0; i < indexArr1.length; i++) {
    				fileWriter.write((list.get(Integer.parseInt(indexArr1[i]))).getCode()+"--->");
    			}
    			fileWriter.write("该路径是直线距离的" + (int)shortPath[end] / lineDistance
    					+ "倍");
    			fileWriter.write("从" + startPoint.getCode() + "出发到" + endPoint.getCode() + "的直线距离为为："
    					+ lineDistance);
    			fileWriter.write("从" + startPoint.getCode() + "出发到" + endPoint.getCode() + "的最短距离为为："
    					+ shortPath[end]);
    			fileWriter.flush();
    		}

    		
    		// 返回路径的起止节点和输入路径的起止节点不一致
    		if (!startPoint.getCode().equals(rList.get(0).getCode())
    				|| !endPoint.getCode().equals(
    						rList.get(rList.size() - 1).getCode())) {
    			fileWriter.write("\r\n");
    			fileWriter.write("===================================");
    			fileWriter.write("该线路有问题,起止节点不一致");
    			fileWriter.write(rList.get(0).getCode() + "------>"
    					+ rList.get(rList.size() - 1).getCode());
    			fileWriter.flush();
    		}
    		// 线路不连贯
    		int flag = 0 ;
    		for (int i = 0; i < rList.size() - 1; i++) {
    			Point p1 = rList.get(i);
    			int k = i + 1;
    			Point p2 = rList.get(k);
    			Iterator<Point> iter = p1.getSubPoints().iterator();
    			flag=0;
    			while (iter.hasNext()) {
    				Point temP = iter.next();
    				if (temP.getCode().equals(p2.getCode())) {
    					flag++;
    				}
    			}
    			
    		}
    		if (flag == 0) {
				
				fileWriter.write("\r\n");
				fileWriter.write("===================================");
				fileWriter.write("该线路有问题，线路不连贯");
				String[] indexArr1 = path[end].split(",");
				for (int j = 0; j < indexArr1.length; j++) {
					fileWriter.write((list.get(Integer.parseInt(indexArr1[j]))).getCode()+"--->");
				}
				fileWriter.flush();//flag = 0;
				
			}
    		// 起点终点是否只出现一次
    		int k1 = 0;
    		int k2 = 0;
    		for (int j = 0; j < rList.size(); j++) {
    			Point tempP = rList.get(j);
    			if (startPoint.getCode().equals(tempP.getCode())) {
    				k1++;
    			}
    			if (endPoint.getCode().equals(tempP.getCode())) {
    				k2++;
    			}
    		}
    		if (k1 >= 2 || k2 >= 2) {
    			fileWriter.write("\r\n");
    			fileWriter.write("===================================");
    			fileWriter.write("该线路有问题，有重复的起点或者终点!");
    			for (int j = 0; j < rList.size(); j++) {
    				fileWriter.write(rList.get(j).getCode() + "-->");
    				fileWriter.flush();
    			}

    		}
//    		StringBuilder sb = new StringBuilder();
//    		for(int k=0; k<shortPath.length; k++){
//    			sb.append(shortPath[k]).append(",");
//    		}
    		rmap.put("list", rList);
    		rmap.put("path", shortPath[end]);
    		return rmap;
       }
    
    public static int getIndexOfPoint(List<Point> list,Point p){
    	int index = -1;
    	for(int i=0; i<list.size(); i++){
    		Point temp = list.get(i);
    		if(temp.getCode().equals(p.getCode())){
    			index = i;
    		}
    	}
    	return index;
    }
    
    /**
     * 获取离车位点最近的点
     * @param plist
     * @param carPoint
     * @return
     */
    public static Map getNearestPoint(List<Point> plist, Point carPoint){
    	Map map = new HashMap();
    	Point rpoint = new Point();
		double len = Double.MAX_VALUE;
    	if(plist.size() > 0){
    		for(Point temp:plist){
    			double tlen =  Math.sqrt(Math.pow(temp.getX()-carPoint.getX(), 2)+ Math.pow(temp.getY()-carPoint.getY(),2));
    			if(tlen < len){
    				len = tlen;
    				rpoint = temp;
    			}
    		}
    	}
    	map.put("point", rpoint);
    	map.put("len", len);
    	return map;
    }
}
