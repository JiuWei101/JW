package bi;

import javax.servlet.http.HttpSession;

import org.dom4j.Element;

import com.ie.common.ConstantClass;
import com.ie.its.login.UserInfo;
import com.sunnet.bis.BIService;
import com.sunnet.bis.SecurityController;

public class Control {

	BIService m_bis = null;
	SecurityController m_defSC = null;
	public Element AddRole(String arg0) {
		
		return m_defSC.AddRole(arg0);
	}

	public boolean CanEmptySysRecycleBin() {
		return m_defSC.CanEmptySysRecycleBin();
	}

	public boolean CanRestoreObject(Object arg0) {
		return m_defSC.CanRestoreObject(arg0);
	}

	public boolean ContainAuthObject(String arg0) {
		return m_defSC.ContainAuthObject(arg0);
	}

	public Element CreateOrUpdateUser(String arg0, String arg1, String arg2,
			String arg3, boolean arg4) throws Exception {
		return m_defSC.CreateOrUpdateUser(arg0, arg1, arg2, arg3, arg4);
	}

	public int DBExecCheck(String arg0, StringBuffer arg1) {
		return m_defSC.DBExecCheck(arg0, arg1);
	}

	public Element GetGroupNode(String arg0, boolean arg1) {
		return m_defSC.GetGroupNode(arg0, arg1);
	}

	public int GetObjectRights(String arg0, Object arg1) {
		return m_defSC.GetObjectRights(arg0, arg1);
	}

	public Element GetSecurityNode(boolean arg0) {
		return m_defSC.GetSecurityNode(arg0);
	}

	public String GetUserGroup(String arg0) {
		return m_defSC.GetUserGroup(arg0);
	}

	public String GetUserName() {
		return m_defSC.GetUserName();
	}

	public Element GetUserNode(String arg0, boolean arg1) {
		return m_defSC.GetUserNode(arg0, arg1);
	}

	public String GetUserRoles(String arg0) {
		return m_defSC.GetUserRoles(arg0);
	}

	public boolean HasLogin() {
		return m_defSC.HasLogin();
	}

	public int InternalLogin(String strUserName) {
		return m_defSC.InternalLogin(strUserName);
	}

	public boolean IsFunctionAllow(String arg0) {
		return m_defSC.IsFunctionAllow(arg0);
	}

	public int Login(String strUserName, String strPassword) {
		if("ADMIN".equalsIgnoreCase(strUserName))
			return m_defSC.Login(strUserName, strPassword);
		
		HttpSession session = m_bis.getRequest().getSession();
		UserInfo ui = (UserInfo)session.getAttribute(ConstantClass.SESSION_USERNAME);
		if(ui.getUser_name() != null)
		{
			try{
				m_defSC.CreateOrUpdateUser(ui.getUser_name(), "","", "Browser", false);
				return m_defSC.InternalLogin(ui.getUser_name());  //内部登录 不校验密码
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return -1;
	}

	public int Logout() {
		return m_defSC.Logout();
	}

	public int OperatingObjectCheck(short arg0, Object arg1) {
		return m_defSC.OperatingObjectCheck(arg0, arg1);
	}

	public int SavingObjectCheck(Object arg0) {
		return m_defSC.SavingObjectCheck(arg0);
	}

	public int SetUserPassword(String arg0, String arg1) {
		return m_defSC.SetUserPassword(arg0, arg1);
	}

	public int UpdateUsersAndRoles() {
		return m_defSC.UpdateUsersAndRoles();
	}

	public void attachBIService(BIService bis) {
		m_bis = bis;
		m_defSC = m_bis.newDefaultSecurityController();
	}

}
