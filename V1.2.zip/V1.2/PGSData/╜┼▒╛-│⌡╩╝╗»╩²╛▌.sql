-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.21-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema ips
--

CREATE DATABASE IF NOT EXISTS ips;
USE ips;



-- Dumping structure for table ips.p_configtask
DROP TABLE IF EXISTS `p_configtask`;
CREATE TABLE IF NOT EXISTS `p_configtask` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `controllerId` varchar(20) DEFAULT NULL COMMENT '管理器ID',
  `path` varchar(200) DEFAULT NULL COMMENT '配置文件路径',
  `operator` varchar(20) DEFAULT NULL COMMENT '发布人',
  `createtime` datetime DEFAULT NULL COMMENT '发布时间',
  `runstate` char(1) DEFAULT '0' COMMENT '任务执行状态(0停止 1执行中)',
  PRIMARY KEY (`id`),
  KEY `FK_controllerId` (`controllerId`),
  CONSTRAINT `FK_controllerId` FOREIGN KEY (`controllerId`) REFERENCES `p_controller` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='下发配置任务表';

-- Dumping data for table ips.p_configtask: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_configtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_configtask` ENABLE KEYS */;


-- Dumping structure for table ips.p_configtaskhistory
DROP TABLE IF EXISTS `p_configtaskhistory`;
CREATE TABLE IF NOT EXISTS `p_configtaskhistory` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `controllerId` varchar(20) DEFAULT NULL COMMENT '管理器ID',
  `executeTime` datetime DEFAULT NULL COMMENT '执行时间',
  `path` varchar(200) DEFAULT NULL COMMENT '配置文件路径',
  `success` char(1) DEFAULT NULL COMMENT '是否执行成功(1成功0失败2超时)',
  `operator` varchar(20) DEFAULT NULL COMMENT '发布人',
  `createtime` datetime DEFAULT NULL COMMENT '发布时间',
  `duration` int(11) DEFAULT NULL COMMENT '执行时长',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_CONFIGTASK_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='下发配置任务历史表';

-- Dumping data for table ips.p_configtaskhistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_configtaskhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_configtaskhistory` ENABLE KEYS */;


-- Dumping structure for table ips.p_controller
DROP TABLE IF EXISTS `p_controller`;
CREATE TABLE IF NOT EXISTS `p_controller` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `mapId` varchar(20) NOT NULL COMMENT '地图ID',
  `lineId` varchar(20) DEFAULT NULL COMMENT '通讯线路ID',
  `addr` varchar(20) DEFAULT NULL COMMENT ' 物理地址或IP地址',
  `port` varchar(10) DEFAULT NULL COMMENT '端口',
  `type` varchar(10) DEFAULT NULL COMMENT '类型',
  `status` char(1) DEFAULT NULL COMMENT '状态(0正常1离线)',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
   ipport               varchar(20) comment '端口',
   isexist              char(1) default '0' comment '是否出入口(0否1是)',
   macaddress           varchar(50) comment 'Mac地址', 
  PRIMARY KEY (`id`),
  KEY `FK_lineId` (`lineId`),
  KEY `FK_mapId` (`mapId`),
  CONSTRAINT `FK_lineId` FOREIGN KEY (`lineId`) REFERENCES `p_line` (`id`),
  CONSTRAINT `FK_mapId` FOREIGN KEY (`mapId`) REFERENCES `p_map` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理器';

-- Dumping data for table ips.p_controller: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_controller` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_controller` ENABLE KEYS */;


-- Dumping structure for table ips.p_detector
DROP TABLE IF EXISTS `p_detector`;
CREATE TABLE IF NOT EXISTS `p_detector` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `mapId` varchar(20) DEFAULT NULL COMMENT '地图ID',
  `controllerId` varchar(20) DEFAULT NULL COMMENT '管理器ID',
  `detectorTypeId` varchar(20) DEFAULT NULL COMMENT '探测器类型ID',
  `guideRegionId` varchar(20) DEFAULT NULL COMMENT '引导区域ID',
  `addr` varchar(50) DEFAULT NULL COMMENT '物理地址',
  `code` varchar(50) DEFAULT NULL COMMENT '编号，数字，小于65536(由管理器地址+探测器地址组成)',
  `status` char(1) DEFAULT NULL COMMENT '状态(0正常1离线)',
  `enable` char(1) DEFAULT NULL COMMENT '是否开启',
  `detectorModel` char(1) DEFAULT NULL DEFAULT '0' COMMENT '探测器模式（0为正常模式，1为异常模式）',
   x_axis               decimal(11,2) comment 'X坐标值',
   y_axis               decimal(11,2) comment 'Y坐标值',
   onepoint_id                 varchar(20) comment '车位可达边A端点ID',
   anopoint_id                 varchar(20) comment '车位可达边B端点ID',
   vertical_x_axis      decimal(11,2) comment '可达边垂直点X坐标值',
   vertical_y_axis      decimal(11,2) comment '可达边垂直点Y坐标值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_code` (`code`),
  KEY `INDEX_detectorTypeId` (`detectorTypeId`),
  KEY `INDEX_controllerId` (`controllerId`),
  KEY `INDEX_mapId` (`mapId`),
  KEY `FK_guideRegionId` (`guideRegionId`),
  CONSTRAINT `FK_guideRegionId` FOREIGN KEY (`guideRegionId`) REFERENCES `p_guideregion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器';

-- Dumping data for table ips.p_detector: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_detector` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_detector` ENABLE KEYS */;


-- Dumping structure for table ips.p_detectorparavalue
DROP TABLE IF EXISTS `p_detectorparavalue`;
CREATE TABLE IF NOT EXISTS `p_detectorparavalue` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `detectorId` varchar(20) DEFAULT NULL COMMENT '探测器ID',
  `detectorTypeParaId` varchar(20) DEFAULT NULL COMMENT '探测器类型参数ID',
  `value` varchar(100) DEFAULT NULL COMMENT '参数值',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`),
  KEY `FK_detectorTypeParaId` (`detectorTypeParaId`),
  KEY `FK_detectorId` (`detectorId`),
  CONSTRAINT `FK_detectorId` FOREIGN KEY (`detectorId`) REFERENCES `p_detector` (`id`),
  CONSTRAINT `FK_detectorTypeParaId` FOREIGN KEY (`detectorTypeParaId`) REFERENCES `p_detectortypepara` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器参数值';

-- Dumping data for table ips.p_detectorparavalue: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_detectorparavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_detectorparavalue` ENABLE KEYS */;


-- Dumping structure for table ips.p_detectortype
DROP TABLE IF EXISTS `p_detectortype`;
CREATE TABLE IF NOT EXISTS `p_detectortype` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `name` varchar(20) DEFAULT NULL COMMENT '中文名称',
  `ename` varchar(200) DEFAULT NULL COMMENT '英文名称',
  `code` varchar(10) DEFAULT NULL COMMENT '编码',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器类型';

-- Dumping data for table ips.p_detectortype: ~2 rows (approximately)
/*!40000 ALTER TABLE `p_detectortype` DISABLE KEYS */;
INSERT INTO `p_detectortype` (`id`, `name`,`ename`, `code`, `describes`) VALUES
	('1','超声波探测器','Ultrasonic Detector','1','1'),
	('2','地感探测器','Loop Dectector','2','2'),
	('3', '地磁探测器', 'Geomagnetism Detector', '3', '3'),
	('4', '视频探测器', 'Video Detector', '4', '4');
/*!40000 ALTER TABLE `p_detectortype` ENABLE KEYS */;


-- Dumping structure for table ips.p_detectortypepara
DROP TABLE IF EXISTS `p_detectortypepara`;
CREATE TABLE IF NOT EXISTS `p_detectortypepara` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `detectorTypeId` varchar(20) DEFAULT NULL COMMENT '探测器类型ID',
  `name` varchar(20) DEFAULT NULL COMMENT '参数名',
  `code` varchar(10) DEFAULT NULL COMMENT '参数名编码',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`),
  KEY `FK_detectorTypeId` (`detectorTypeId`),
  CONSTRAINT `FK_detectorTypeId` FOREIGN KEY (`detectorTypeId`) REFERENCES `p_detectortype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器类型参数';

-- Dumping data for table ips.p_detectortypepara: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_detectortypepara` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_detectortypepara` ENABLE KEYS */;


-- Dumping structure for table ips.p_equipmentchange
DROP TABLE IF EXISTS `p_equipmentchange`;
CREATE TABLE IF NOT EXISTS `p_equipmentchange` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `equipmentId` varchar(20) DEFAULT NULL COMMENT '设备id',
  `occurrenceTime` datetime DEFAULT NULL COMMENT '发生时间',
  `paramName` varchar(20) DEFAULT NULL COMMENT '参数名称',
  `paramValue` varchar(20) DEFAULT NULL COMMENT '参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备状态信息';

-- Dumping data for table ips.p_equipmentchange: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_equipmentchange` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_equipmentchange` ENABLE KEYS */;


-- Dumping structure for table ips.p_guideregion
DROP TABLE IF EXISTS `p_guideregion`;
CREATE TABLE IF NOT EXISTS `p_guideregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `code` varchar(10) DEFAULT NULL COMMENT '编号',
  `regionType` char(1) DEFAULT NULL COMMENT '区域类型(1探测器2地感)',
  `name` varchar(20) DEFAULT NULL COMMENT '名称',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `deleteFlag` char(1) DEFAULT '0' COMMENT '删除标志(0未删除1删除)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='引导区域表';

-- Dumping data for table ips.p_guideregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_guideregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_guideregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_light
DROP TABLE IF EXISTS `p_light`;
CREATE TABLE IF NOT EXISTS `p_light` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `lightRegionId` varchar(20) DEFAULT NULL COMMENT '灯光引导区域ID',
  `lightName` varchar(20) DEFAULT NULL COMMENT '灯光名称',
  `status` char(1) DEFAULT NULL COMMENT '灯光状态',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `FK_lightRegionId` (`lightRegionId`),
  CONSTRAINT `FK_lightRegionId` FOREIGN KEY (`lightRegionId`) REFERENCES `p_lightregion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='灯光表';

-- Dumping data for table ips.p_light: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_light` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_light` ENABLE KEYS */;


-- Dumping structure for table ips.p_lightregion
DROP TABLE IF EXISTS `p_lightregion`;
CREATE TABLE IF NOT EXISTS `p_lightregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `parkRegionId` varchar(20) DEFAULT NULL COMMENT '引导区域ID',
  `lightRegionName` varchar(20) DEFAULT NULL COMMENT '灯光区域名称',
  `status` char(1) DEFAULT NULL COMMENT '灯光区域状态',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `FK_parkRegionId` (`parkRegionId`),
  CONSTRAINT `FK_parkRegionId` FOREIGN KEY (`parkRegionId`) REFERENCES `p_guideregion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='灯光区域表';

-- Dumping data for table ips.p_lightregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_lightregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_lightregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_line
DROP TABLE IF EXISTS `p_line`;
CREATE TABLE IF NOT EXISTS `p_line` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `ip` varchar(50) DEFAULT NULL COMMENT '线路名称',
  `status` char(1) DEFAULT NULL COMMENT '状态(1有效0无效)',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通讯线路';

-- Dumping data for table ips.p_line: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_line` ENABLE KEYS */;


-- Dumping structure for table ips.p_lineparam
DROP TABLE IF EXISTS `p_lineparam`;
CREATE TABLE IF NOT EXISTS `p_lineparam` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `lineId` varchar(20) DEFAULT NULL COMMENT '通讯线路ID',
  `boardNo` int(11) DEFAULT '0' COMMENT '板卡号',
  `port` int(11) DEFAULT '0' COMMENT '本地端口',
  `stationAddr` int(11) DEFAULT '1' COMMENT '本地地址',
  `baudRate` varchar(20) DEFAULT '500K' COMMENT '波特率',
  `dataBits` varchar(10) DEFAULT NULL COMMENT '数据位',
  `parity` varchar(10) DEFAULT NULL COMMENT '校验位',
  `stopBits` varchar(10) DEFAULT NULL COMMENT '停止位',
  `mask` int(11) DEFAULT '255' COMMENT '掩码',
  `purpose` varchar(20) DEFAULT NULL COMMENT '用途',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`),
  KEY `INDEX_lineId` (`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='通讯线路端口';

-- Dumping data for table ips.p_lineparam: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_lineparam` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_lineparam` ENABLE KEYS */;


-- Dumping structure for table ips.p_logicregion
DROP TABLE IF EXISTS `p_logicregion`;
CREATE TABLE IF NOT EXISTS `p_logicregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `physicalRegionId` varchar(20) NOT NULL COMMENT '物理区域id',
  `code` varchar(10) DEFAULT NULL COMMENT '区域编码',
  `name` varchar(20) DEFAULT NULL COMMENT '名称',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='地理区域表';

-- Dumping data for table ips.p_logicregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_logicregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_logicregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_map
DROP TABLE IF EXISTS `p_map`;
CREATE TABLE IF NOT EXISTS `p_map` (
  `id` varchar(20) NOT NULL COMMENT '停车场地图ID',
  `physicalRegionId` varchar(20) DEFAULT NULL COMMENT '停车场物理区域ID(楼层)',
  `importOrNot` int(1) DEFAULT '0' COMMENT '1是已导入数据 0未导入数据',
  `type` varchar(20) DEFAULT NULL COMMENT '存储类型',
  `path` varchar(200) DEFAULT NULL COMMENT '路径',
  `map` blob COMMENT '地图',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `number` varchar(50) DEFAULT NULL COMMENT '地图号',
  `name` varchar(50) DEFAULT NULL COMMENT '地图名',
  `parkingSum` int(11) DEFAULT NULL COMMENT '车位总数',
  `normalparkSum` int(11) DEFAULT NULL COMMENT '正常车位数',
  `screenSum` int(11) DEFAULT NULL COMMENT '屏总数',
  `normalscrSum` int(11) DEFAULT NULL COMMENT '正常屏总数',
  legend               decimal(11,2) comment '图例(单位：米)',
  `imgPath` varchar(200) DEFAULT NULL COMMENT '地图图片路径',
  PRIMARY KEY (`id`),
  KEY `INDEX_physicalRegionId` (`physicalRegionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='停车场地图信息表';

-- Dumping data for table ips.p_map: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_map` ENABLE KEYS */;


-- Dumping structure for table ips.p_mapguideregion
DROP TABLE IF EXISTS `p_mapguideregion`;
CREATE TABLE IF NOT EXISTS `p_mapguideregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `mapId` varchar(20) DEFAULT NULL COMMENT '停车场地图ID',
  `guideRegionId` varchar(20) DEFAULT NULL COMMENT '引导区域ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='地图引导区域关系表';

-- Dumping data for table ips.p_mapguideregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_mapguideregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_mapguideregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_maplogicregion
DROP TABLE IF EXISTS `p_maplogicregion`;
CREATE TABLE IF NOT EXISTS `p_maplogicregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `mapId` varchar(20) DEFAULT NULL COMMENT '地图ID',
  `logicRegionId` varchar(20) DEFAULT NULL COMMENT '地理区域ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='地图地理区域关系表';

-- Dumping data for table ips.p_maplogicregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_maplogicregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_maplogicregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_parking
DROP TABLE IF EXISTS `p_parking`;
CREATE TABLE IF NOT EXISTS `p_parking` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `parkingCode` varchar(20) DEFAULT NULL COMMENT '停车场序列号',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `telephone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `addr` varchar(200) DEFAULT NULL COMMENT '地址',
  `lng` float DEFAULT NULL COMMENT '经度',
  `lat` float DEFAULT NULL COMMENT '纬度',
  `alt` float DEFAULT NULL COMMENT '高度',
  `fee` float DEFAULT NULL COMMENT '收费',
  `unit` varchar(20) DEFAULT NULL COMMENT '收费单位',
  `total` int(11) DEFAULT NULL COMMENT '总车位',
  `free` int(11) DEFAULT NULL COMMENT '剩余车位',
  `inuse` int(11) DEFAULT NULL COMMENT '已用车位',
  `book` int(11) DEFAULT NULL COMMENT '预约车位',
  `feeDesc` varchar(200) DEFAULT NULL COMMENT '收费说明',
  `showMap` char(1) DEFAULT NULL COMMENT '是否地图显示(1是0否)',
  `zoom` int(11) DEFAULT NULL COMMENT '开始显示层数',
  `info` varchar(500) DEFAULT NULL COMMENT '周边信息',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `useColor` char(1) DEFAULT '0' COMMENT '是否启用停车时长颜色(1是0否)',
  `timeToCount` double DEFAULT NULL COMMENT '停车起算时间(小时，允许输入小数)',
  `timeOut` double DEFAULT NULL COMMENT '停车超时时间(小时，允许输入小数)',
  `spacingInterval` int(11) DEFAULT '1' COMMENT '出入车最小间隔时间（分钟，默认1）',
  `refreshTime` int(11) DEFAULT '5' COMMENT '地感更新时间（分钟，默认5）',
  `stateTime` datetime DEFAULT NULL COMMENT '通讯程序状态更新时间（后台5分钟写一次，前提10分钟判断一次）',
  `dataAnalysisTime` varchar(2) DEFAULT NULL COMMENT '停车数据分析时间',
  `dataAnalysisDays` int(11) DEFAULT NULL COMMENT '停车数据分析天数',
  `faultJudgmentNum` int(11) DEFAULT NULL COMMENT '故障判定次数',
  `faultJudgmentInterval` int(11) DEFAULT NULL COMMENT '故障判定间隔时间',
  `exitscreenCarportNum` int(11) DEFAULT NULL COMMENT '出口屏保护车位数',
  `exitscreenContent` varchar(20) DEFAULT NULL COMMENT '出口屏保护内容',
  `expireBecomeRed` varchar(5) DEFAULT '00' COMMENT '软件到期是否全部变红灯',
  `attribute1` varchar(5) DEFAULT '' COMMENT '备用属性1（记录版本号）',
  `attribute2` varchar(5) DEFAULT '' COMMENT '备用属性2（记录系统应用模式1超声波、2视频、3地磁）',
  `attribute3` varchar(5) DEFAULT '' COMMENT '备用属性3（暂未用）',
  `attribute4` varchar(5) DEFAULT '' COMMENT '备用属性4（暂未用）',
  `attribute5` varchar(5) DEFAULT '' COMMENT '备用属性5（暂未用）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='停车场信息表';

-- Dumping data for table ips.p_parking: ~1 rows (approximately)
/*!40000 ALTER TABLE `p_parking` DISABLE KEYS */;
INSERT INTO `p_parking` (`id`, `parkingCode`, `name`, `person`, `telephone`, `addr`, `lng`, `lat`, `alt`, `fee`, `unit`, `total`, `free`, `inuse`, `book`, `feeDesc`, `showMap`, `zoom`, `info`, `notes`, `useColor`, `timeToCount`, `timeOut`, `spacingInterval`, `refreshTime`, `stateTime`, `dataAnalysisTime`, `dataAnalysisDays`, `faultJudgmentNum`, `faultJudgmentInterval`, `exitscreenCarportNum`, `exitscreenContent`) VALUES
	('20120326171338000001', NULL, 'ake', '2', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 1, 10, 6, 111, '2012-05-17 09:28:34', '03', 3, NULL, NULL,0,'\\\\R满');
/*!40000 ALTER TABLE `p_parking` ENABLE KEYS */;
-- 记录版本号;
UPDATE `p_parking` SET attribute1 ='V2.0';

-- Dumping structure for table ips.p_parkingspace
DROP TABLE IF EXISTS `p_parkingspace`;
CREATE TABLE IF NOT EXISTS `p_parkingspace` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `detectorId` varchar(20) DEFAULT NULL COMMENT '探测器ID',
  `logicId` varchar(20) DEFAULT NULL COMMENT '地理区域ID',
  `lightRegionId` varchar(20) DEFAULT NULL COMMENT '灯光区域ID',
  `physicalRegionId` varchar(20) DEFAULT NULL COMMENT '物理区域ID',
  `code` varchar(20) DEFAULT NULL COMMENT '车位编码',
  `enable` char(1) DEFAULT NULL COMMENT '是否启用',
  `inuse` char(1) DEFAULT NULL COMMENT '是否有车,0无车，1有车',
  `useDate` date DEFAULT NULL COMMENT '被占用日期',
  `useTime` time DEFAULT NULL COMMENT '被占用时间',
  `spotType` char(1) DEFAULT '0' COMMENT '车位配置类型(0临时 1固定 2预订)',
  `spotTypeNow` char(1) DEFAULT NULL COMMENT '当前类型(0临时 1固定 2预订)',
  `updateDate` datetime DEFAULT NULL COMMENT '最后更新时间',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
   plateno              varchar(50) comment '车牌号',
   picturepath          varchar(200) comment '图片路径',
  PRIMARY KEY (`id`),
  KEY `FK_physicalRegionId` (`physicalRegionId`),
  CONSTRAINT `FK_physicalRegionId` FOREIGN KEY (`physicalRegionId`) REFERENCES `p_physicalregion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车位信息表';

-- Dumping data for table ips.p_parkingspace: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspace` ENABLE KEYS */;


-- Dumping structure for table ips.p_parkingspaceoperationhis
DROP TABLE IF EXISTS `p_parkingspaceoperationhis`;
CREATE TABLE IF NOT EXISTS `p_parkingspaceoperationhis` (
  `mainKey` int(11) NOT NULL auto_increment COMMENT '历史表主键id',
  `id` varchar(20) NOT NULL COMMENT '车位流水id',
  `parkingSpaceId` varchar(20) DEFAULT NULL COMMENT '车位id',
  `parkingSpaceCode` varchar(20) DEFAULT NULL COMMENT '车位编码',
  `spotType` char(1) DEFAULT NULL COMMENT '车位类型(0临时  1固定  2预订)',
  `inTime` datetime DEFAULT NULL COMMENT '开始时间',
  `outTime` datetime DEFAULT NULL COMMENT '结束时间',
  `putOut` char(1) DEFAULT NULL COMMENT '是否已出车标志(0否1是)',
   plateno              varchar(50) comment '车牌号',
   picturepath          varchar(200) comment '图片路径',
  PRIMARY KEY (`mainKey`),
  KEY `INDEX_parkingSpaceCode` (`parkingSpaceCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车位流水历史记录';

-- Dumping data for table ips.p_parkingspaceoperationhis: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspaceoperationhis` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspaceoperationhis` ENABLE KEYS */;


-- Dumping structure for table ips.p_parkingspaceoperationlog
DROP TABLE IF EXISTS `p_parkingspaceoperationlog`;
CREATE TABLE IF NOT EXISTS `p_parkingspaceoperationlog` (
  `id` varchar(20) NOT NULL COMMENT '车位流水id',
  `parkingSpaceId` varchar(20) DEFAULT NULL COMMENT '车位id',
  `parkingSpaceCode` varchar(20) DEFAULT NULL COMMENT '车位编码',
  `spotType` char(1) DEFAULT NULL COMMENT '车位类型(0临时  1固定  2预订)',
  `inTime` datetime DEFAULT NULL COMMENT '开始时间',
  `outTime` datetime DEFAULT NULL COMMENT '结束时间',
  `putOut` char(1) DEFAULT NULL COMMENT '是否已出车标志(0否1是)',
   plateno              varchar(50) comment '车牌号',
   picturepath          varchar(200) comment '图片路径',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_id` (`id`),
  KEY `INDEX_parkingSpaceCode` (`parkingSpaceCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车位流水记录';

-- Dumping data for table ips.p_parkingspaceoperationlog: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspaceoperationlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspaceoperationlog` ENABLE KEYS */;


-- Dumping structure for table ips.p_parkingspacestatistics
DROP TABLE IF EXISTS `p_parkingspacestatistics`;
CREATE TABLE IF NOT EXISTS `p_parkingspacestatistics` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `physicalregionId` varchar(20) DEFAULT NULL COMMENT '物理区域ID',
  `maplogicregionId` varchar(20) DEFAULT NULL COMMENT '地理区域ID',
  `physicalregionName` varchar(50) DEFAULT NULL COMMENT '物理区域名称',
  `maplogicregionName` varchar(50) DEFAULT NULL COMMENT '地理区域名称',
  `parkingSpaceId` varchar(20) DEFAULT NULL COMMENT '车位id',
  `parkingSpaceCode` varchar(20) DEFAULT NULL COMMENT '车位编码',
  `year` varchar(4) DEFAULT NULL COMMENT '年',
  `month` varchar(2) DEFAULT NULL COMMENT '月',
  `day` varchar(2) DEFAULT NULL COMMENT '日',
  `hour` varchar(2) DEFAULT NULL COMMENT '小时',
  `duration` int(11) DEFAULT NULL COMMENT '时长',
  `inCount` int(11) DEFAULT NULL COMMENT '进车数',
  `outCount` int(11) DEFAULT NULL COMMENT '出车数',
  `spotType` char(1) DEFAULT NULL COMMENT '车位类型',
  `status` char(1) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `INDEX_physicalregionId` (`physicalregionId`),
  KEY `INDEX_maplogicregionId` (`maplogicregionId`),
  KEY `INDEX_year` (`year`),
  KEY `INDEX_month` (`month`),
  KEY `INDEX_day` (`day`),
  KEY `INDEX_hour` (`hour`),
  KEY `INDEX_spotType` (`spotType`),
  KEY `INDEX_parkingSpaceId` (`parkingSpaceId`),
  KEY `INDEX_parkingSpaceCode` (`parkingSpaceCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='停车周转统计表';

-- Dumping data for table ips.p_parkingspacestatistics: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspacestatistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspacestatistics` ENABLE KEYS */;


-- Dumping structure for table ips.p_parkingspacetask
DROP TABLE IF EXISTS `p_parkingspacetask`;
CREATE TABLE IF NOT EXISTS `p_parkingspacetask` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `parkingSpaceId` varchar(20) DEFAULT NULL COMMENT '车位ID',
  `actNewType` char(1) DEFAULT NULL COMMENT '动作(0临时 1固定 2预订 3正常模式 4异常模式)',
  `type` char(1) DEFAULT NULL COMMENT '执行类型(0每周 1单次 2立即 6更改运行模式作业)',
  `weekDay` varchar(50) DEFAULT NULL COMMENT '每周执行星期(1,3,4表示周日 周二和周三)',
  `startDate` datetime DEFAULT NULL COMMENT '配置开始日期',
  `startTime` datetime DEFAULT NULL COMMENT '实际开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '配置结束日期',
  `timeOut` int(11) DEFAULT NULL COMMENT '超时限制',
  `runState` char(1) DEFAULT '0' COMMENT '任务执行状态（0停止  1执行中 2正在结束）',
  `startDuration` int(11) DEFAULT '0' COMMENT '实际启动时长',
  `retryCount` int(11) DEFAULT '0' COMMENT '实际失败重试次数',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车位作业';

-- Dumping data for table ips.p_parkingspacetask: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspacetask` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspacetask` ENABLE KEYS */;


-- Dumping structure for table ips.p_parkingspacetaskhistory
DROP TABLE IF EXISTS `p_parkingspacetaskhistory`;
CREATE TABLE IF NOT EXISTS `p_parkingspacetaskhistory` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `parkingSpaceId` varchar(20) DEFAULT NULL COMMENT '车位ID',
  `actNewType` char(1) DEFAULT NULL COMMENT '动作(0临时 1固定 2预订)',
  `type` char(1) DEFAULT NULL COMMENT '执行类型(0每周 1单次 2立即)',
  `weekDay` varchar(50) DEFAULT NULL COMMENT '每周执行星期(1,3,4表示周日 周二和周三)',
  `startDate` datetime DEFAULT NULL COMMENT '配置开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '配置结束时间',
  `timeOut` int(11) DEFAULT NULL COMMENT '超时限制',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `success` char(1) DEFAULT NULL COMMENT '是否执行成功(1成功0失败)',
  `startTime` datetime DEFAULT NULL COMMENT '开始执行时间',
  `endTime` datetime DEFAULT NULL COMMENT '结束执行时间',
  `startDuration` int(11) DEFAULT NULL COMMENT '开始执行时长',
  `endDuration` int(11) DEFAULT NULL COMMENT '结束执行时长',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_PARKINGSPACE_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车位作业历史';

-- Dumping data for table ips.p_parkingspacetaskhistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_parkingspacetaskhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_parkingspacetaskhistory` ENABLE KEYS */;


-- Dumping structure for table ips.p_physicalregion
DROP TABLE IF EXISTS `p_physicalregion`;
CREATE TABLE IF NOT EXISTS `p_physicalregion` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `physicalRegionName` varchar(20) DEFAULT NULL COMMENT '停车场物理区域名',
  `physicalregionCode` varchar(20) DEFAULT NULL COMMENT '停车场物理区域编码',
  `status` char(1) DEFAULT NULL COMMENT '状态',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='停车场物理区域表(楼层)';

-- Dumping data for table ips.p_physicalregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_physicalregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_physicalregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_register
DROP TABLE IF EXISTS `p_register`;
CREATE TABLE IF NOT EXISTS `p_register` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `name` varchar(200) NOT NULL COMMENT '客户名称',
  `validityDate` datetime NOT NULL COMMENT '有效期',
  `ZCLimit` int(11) NOT NULL COMMENT '集中器数量上限',
  `UDLimit` int(11) NOT NULL COMMENT '探头数量上限',
  `LDLimit` int(11) NOT NULL COMMENT '地感数量上限',
  `VMSLimit` int(11) NOT NULL COMMENT '引导屏数量上限',
  `path` varchar(200) NOT NULL COMMENT '校验文件路径',
  `upgradeUrl` varchar(300) DEFAULT NULL COMMENT '升级中心地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='注册信息表';

-- Dumping data for table ips.p_register: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_register` DISABLE KEYS */;
INSERT INTO `p_register` (`id`,`name`,`validityDate`,`ZCLimit`,`UDLimit`,`LDLimit`,`VMSLimit`,`path`) VALUES 
 ('20120524115411000073','IE','2013-01-01 00:00:00',80,5120,2560,1280,'');
/*!40000 ALTER TABLE `p_register` ENABLE KEYS */;


-- Dumping structure for table ips.p_screen
DROP TABLE IF EXISTS `p_screen`;
CREATE TABLE IF NOT EXISTS `p_screen` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `mapId` varchar(20) DEFAULT NULL COMMENT '停车场地图ID',
  `controllerId` varchar(20) DEFAULT NULL COMMENT '管理器ID',
  `screenTypeCode` varchar(10) DEFAULT NULL COMMENT '引导屏类型ID',
  `screenTemplateId` varchar(20) DEFAULT NULL COMMENT '引导屏参数值模板ID',
  `addr` varchar(50) DEFAULT NULL COMMENT '引导屏地址，数字，小于256',
  `grpAddr` varchar(50) DEFAULT NULL COMMENT '引导屏组地址，数字，小于256',
  `code` varchar(10) DEFAULT NULL COMMENT '引导屏编号',
  `colorMode` varchar(1) DEFAULT '0' COMMENT '颜色模式(0双色1单色)',
  `serialPort` varchar(50) NOT NULL DEFAULT '01' COMMENT '串口号',
  `baudRate` varchar(20) NOT NULL DEFAULT '19200' COMMENT '波特率',
  `status` char(1) DEFAULT NULL COMMENT '状态',
  `enable` char(1) DEFAULT '1' COMMENT '是否启用',
  `isExit` char(1) DEFAULT '0' COMMENT '是否出口屏',
  `esCarportNum` int(11) DEFAULT '0' COMMENT '出口屏车位临界值',
  `esContent` varchar(20) DEFAULT '\\R满' COMMENT '出口屏保护内容',
  `contentFormat` mediumtext DEFAULT NULL COMMENT '格式为(←d%空格 ↑d% d%→)',
  `dispLen` mediumtext DEFAULT NULL COMMENT '屏分区格式化位数',
  ipaddress            varchar(50) comment 'ip地址',
   ipport               varchar(20) comment 'ip端口',
   macaddress           varchar(20) comment 'mac地址',
  PRIMARY KEY (`id`),
  KEY `FK_screenTypeCode` (`screenTypeCode`),
  CONSTRAINT `FK_screenTypeCode` FOREIGN KEY (`screenTypeCode`) REFERENCES `p_screentype` (`code`),
  KEY `FK_screenTemplateId` (`screenTemplateId`),
  CONSTRAINT `FK_screenTemplateId` FOREIGN KEY (`screenTemplateId`)  REFERENCES `p_screenparatemplateheader` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='引导屏';

-- Dumping data for table ips.p_screen: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_screen` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_screen` ENABLE KEYS */;


-- Dumping structure for table ips.p_screenparavalue
DROP TABLE IF EXISTS `p_screenparavalue`;
CREATE TABLE IF NOT EXISTS `p_screenparavalue` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `screenId` varchar(20) DEFAULT NULL COMMENT '屏ID',
  `screenTypeParaId` varchar(20) DEFAULT NULL COMMENT '引导屏类型参数ID',
  `value` varchar(100) DEFAULT NULL COMMENT '参数值',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`),
  KEY `FK_screenTypeParaId` (`screenTypeParaId`),
  KEY `FK_screenId` (`screenId`),
  CONSTRAINT `FK_screenId` FOREIGN KEY (`screenId`) REFERENCES `p_screen` (`id`),
  CONSTRAINT `FK_screenTypeParaId` FOREIGN KEY (`screenTypeParaId`) REFERENCES `p_screentypepara` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏参数值';

-- Dumping data for table ips.p_screenparavalue: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_screenparavalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_screenparavalue` ENABLE KEYS */;


-- Dumping structure for table ips.p_screenregion
DROP TABLE IF EXISTS `p_screenregion`;
CREATE TABLE IF NOT EXISTS `p_screenregion` (
  `id` varchar(20) NOT NULL COMMENT 'id，数字，小于65536',
  `screenId` varchar(20) DEFAULT NULL COMMENT '屏ID',
  `screenAreaName` varchar(20) DEFAULT NULL COMMENT '屏区域名称(例:左 中 右)',
  `guideRegionCodeList` mediumtext DEFAULT NULL COMMENT '屏对应引导区域编号组[code1Id,code2Id]',
  `dispColor` varchar(20) DEFAULT NULL COMMENT '显示颜色',
  `currentSum` int(11) DEFAULT NULL COMMENT '当前显示数',
  `dispLen` tinyint(2) DEFAULT NULL COMMENT '显示长度',
  PRIMARY KEY (`id`),
  KEY `INDEX_screenId` (`screenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏区域对应引导区域';

-- Dumping data for table ips.p_screenregion: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_screenregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_screenregion` ENABLE KEYS */;


-- Dumping structure for table ips.p_screentask
DROP TABLE IF EXISTS `p_screentask`;
CREATE TABLE IF NOT EXISTS `p_screentask` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `screenId` varchar(20) DEFAULT NULL COMMENT '引导屏ID',
  `type` char(1) DEFAULT NULL COMMENT '执行类型(0 每周 1单次 2立即 3切换显示)',
  `weekDay` varchar(50) DEFAULT NULL COMMENT '每周执行星期(1,3,4表示周日 周二和周三)',
  `startDate` datetime DEFAULT NULL COMMENT '配置开始日期',
  `startTime` datetime DEFAULT NULL COMMENT '开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '配置结束时间',
  `timeOut` int(11) DEFAULT NULL COMMENT '超时',
  `content` varchar(200) DEFAULT NULL COMMENT '发布内容',
  `announceDate` datetime DEFAULT NULL COMMENT '发布时间',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `runState` char(1) DEFAULT '0' COMMENT '任务执行状态(0停止  1执行中 2正在停止)',
  `startDuration` int(11) DEFAULT '0' COMMENT '实际启动时长',
  `SwitchGap` int(11) DEFAULT '10' COMMENT '切换间隔',
  `retryCount` int(11) DEFAULT '0' COMMENT '实际失败重试次数',
  `forceTerminateFlag` char(1) DEFAULT '0' COMMENT '强制终止标志(1 强制终止)',
  `moveMethod` varchar(100) DEFAULT '00' COMMENT '显示方式',
  `moveSpeed` varchar(100) DEFAULT '00' COMMENT '移动速度',
  `moveWidth`  varchar(100) DEFAULT '08' COMMENT '显示宽度',
  PRIMARY KEY (`id`),
  KEY `INDEX_screenId` (`screenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏作业';

-- Dumping data for table ips.p_screentask: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_screentask` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_screentask` ENABLE KEYS */;


-- Dumping structure for table ips.p_screentaskhistory
DROP TABLE IF EXISTS `p_screentaskhistory`;
CREATE TABLE IF NOT EXISTS `p_screentaskhistory` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `screenId` varchar(20) DEFAULT NULL COMMENT '引导屏ID',
  `type` char(1) DEFAULT NULL COMMENT '执行类型(0 每周 1单次 2立即)',
  `weekDay` varchar(50) DEFAULT NULL COMMENT '每周执行星期(1,3,4表示周日 周二和周三)',
  `startDate` datetime DEFAULT NULL COMMENT '配置开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '配置结束时间',
  `timeOut` int(11) DEFAULT NULL COMMENT '超时',
  `content` varchar(200) DEFAULT NULL COMMENT '发布内容',
  `announceDate` datetime DEFAULT NULL COMMENT '发布时间',
  `success` char(1) DEFAULT NULL COMMENT '是否执行成功(1成功0失败)',
  `notes` varchar(200) DEFAULT NULL COMMENT '备注',
  `startTime` datetime DEFAULT NULL COMMENT '开始执行时间',
  `endTime` datetime DEFAULT NULL COMMENT '结束执行时间',
  `startDuration` int(11) DEFAULT NULL COMMENT '开始执行时长',
  `endDuration` int(11) DEFAULT NULL COMMENT '结束执行时长',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQUE_SCREENTASK_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏作业历史';

-- Dumping data for table ips.p_screentaskhistory: ~0 rows (approximately)
/*!40000 ALTER TABLE `p_screentaskhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_screentaskhistory` ENABLE KEYS */;


-- Dumping structure for table ips.p_screentype
DROP TABLE IF EXISTS `p_screentype`;
CREATE TABLE IF NOT EXISTS `p_screentype` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `name` varchar(20) DEFAULT NULL COMMENT '参数名',
  `code` varchar(10) NOT NULL DEFAULT '' COMMENT '类型名编码(0001艾科屏0002青松屏)',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  `dllName` varchar(100) DEFAULT NULL COMMENT '动态库文件名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `INDEX_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='引导屏类型';

-- Dumping data for table ips.p_screentype: ~1 rows (approximately)
/*!40000 ALTER TABLE `p_screentype` DISABLE KEYS */;
INSERT INTO `p_screentype` (`id`, `name`, `code`, `describes`, `dllName`) VALUES
	('01', 'AKE屏', '0001', '艾科屏', '');
/*!40000 ALTER TABLE `p_screentype` ENABLE KEYS */;


-- Dumping structure for table ips.p_screentypepara
DROP TABLE IF EXISTS `p_screentypepara`;
CREATE TABLE IF NOT EXISTS `p_screentypepara` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `screenType` varchar(10) DEFAULT NULL COMMENT '引导屏类型ID',
  `name` varchar(200) DEFAULT NULL COMMENT '参数名',
  `code` varchar(10) DEFAULT NULL COMMENT '参数名编码',
  `defaultValue` varchar(20) DEFAULT NULL COMMENT '缺省值',
  `optionalValue` varchar(20) DEFAULT NULL COMMENT '可选值',
  `describes` varchar(200) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`),
  KEY `FK_screenType` (`screenType`),
  CONSTRAINT `FK_screenType` FOREIGN KEY (`screenType`) REFERENCES `p_screentype` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏类型参数';

-- Dumping data for table ips.p_screentypepara: ~16 rows (approximately)
/*!40000 ALTER TABLE `p_screentypepara` DISABLE KEYS */;
INSERT INTO `p_screentypepara` (`id`, `screenType`, `name`, `code`, `defaultValue`, `optionalValue`, `describes`) VALUES
	('1', '0001', '报文头', 'start', 'DB', '213,321,321', ''),
	('10', '0001', '显示屏宽度', 'Led_w', '08', NULL, ''),
	('11', '0001', '显示屏高度', 'Led_h', '02', NULL, ''),
	('13', '0001', 'X坐标的显示偏移量', 'X_offset', '00', NULL, NULL),
	('14', '0001', 'Y坐标的显示偏移量', 'Y_offset', '00', NULL, NULL),
	('15', '0001', '字体', 'font', '02', NULL, NULL),
	('16', '0001', '亮度', 'light', '00', NULL, NULL),
	('17', '0001', '红色占空比', 'Redretio', '00', NULL, NULL),
	('2', '0001', '结束标识符', 'end', 'DD', NULL, NULL),
	('3', '0001', '操作类型', 'cmd', 'E1', NULL, NULL),
	('4', '0001', '显示方式', 'Inout', '04', NULL, NULL),
	('5', '0001', '移动速度', 'Move', '00', NULL, NULL),
	('6', '0001', '停留时间', 'Pause', '00', NULL, NULL),
	('7', '0001', '显示扩展方式', 'Append', '03', NULL, NULL),
	('8', '0001', '扫描方式选择', 'Mode', '00', NULL, NULL),
	('9', '0001', '驱动选择', 'Reverse', '00', NULL, NULL);
/*!40000 ALTER TABLE `p_screentypepara` ENABLE KEYS */;


-- Dumping structure for table ips.sys_act
DROP TABLE IF EXISTS `sys_act`;
CREATE TABLE IF NOT EXISTS `sys_act` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `module_url` varchar(200) DEFAULT NULL COMMENT '操作链接',
  `act_level` varchar(20) DEFAULT NULL COMMENT '操作级别',
  `sort` int(11) DEFAULT NULL COMMENT '顺序',
  `state` varchar(2) DEFAULT NULL COMMENT '状态',
  `module_name` varchar(100) DEFAULT NULL COMMENT '日志记录模块名称',
  `log_name` varchar(100) DEFAULT NULL COMMENT '日志记录操作名称',
  `is_model` varchar(1) DEFAULT NULL COMMENT '操作类型',
  `name` varchar(100) DEFAULT NULL COMMENT '操作名称',
  `lang_key` varchar(45) DEFAULT NULL COMMENT '多语言Key',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作表';

-- Dumping data for table ips.sys_act: ~30 rows (approximately)
/*!40000 ALTER TABLE `sys_act` DISABLE KEYS */;
INSERT INTO `sys_act` (`id`, `module_url`, `act_level`, `sort`, `state`, `module_name`, `log_name`, `is_model`, `name`, `lang_key`) VALUES
	('20110309110734026108', NULL, NULL, 99, '1', '系统管理', '系统管理', '0', '系统管理', 'sys_manage'),
	('20140626104129426122', 'pgsservice/config_file_manage.action', NULL, 32, '1', '后台配置文件管理', '后台配置文件管理', '0', '后台配置文件管理', 'config_file_manage'),
	('20110309160429426124', 'passwd/passwd_read.action', NULL, 19, '1', '修改密码', '修改密码', '0', '修改密码', 'modify_password'),
	('20110309170545360208', 'user/user_list.action', NULL, 16, '1', '用户管理', '用户管理', '0', '用户管理', 'user_manage'),
	('20110309170644180211', 'role/role_list.action', NULL, 13, '1', '权限管理', '权限管理', '0', '权限管理', 'role_manage'),
	('20120224103249000003', 'ctrl_manage/ctrl_list.action', NULL, 6, '1', '管理器管理', '管理器管理', '0', '管理器管理', NULL),
	('20120225091305000001', NULL, NULL, 80, '1', '统计报表', '统计报表', '0', '统计报表', 'statistical_statement'),
	('20120225100819000003', 'parking_statistics/inout_list.action?list_type=inout', NULL, 6, '1', '停车出入情况', '停车出入情况', '0', '停车出入情况', 'in_and_out_situation'),
	('20140812151119000004', 'parking_statistics/parking_in_detail.action', NULL, 1, '1', '停车出入明细表', '停车出入明细表', '0', '停车出入明细表', 'parking_in_detail'),
	('20120225114758000001', NULL, NULL, 100, '1', '参数配置', '参数配置', '0', '参数配置', 'para_conf'),
	('20120225114914000003', 'controller_config/controller_list.action', NULL, 17, '1', '管理器配置', '管理器配置', '0', '管理器配置', 'controller_conf'),
	('20120225114934000005', 'detector_config/detector_list.action', NULL, 20, '1', '探测器配置', '探测器配置', '0', '探测器配置', 'detector_conf'),
	('20120225114949000007', 'screen_config/screen_list.action', NULL, 7, '1', '引导屏配置', '引导屏配置', '0', '引导屏配置', 'screen_conf'),
	('20120225115009000009', 'screen_logic/logic_main.action', NULL, 8, '1', '引导屏逻辑', '引导屏逻辑', '0', '引导屏逻辑', 'screen_logic'),
	('20120225155544000001', 'task_screen/list.action', NULL, 7, '1', '引导屏作业管理', '引导屏作业管理', '0', '引导屏作业管理', 'screen_work_manage'),
	('20120225162454000001', 'task_parking/list.action', NULL, 10, '1', '车位作业管理', '车位作业管理', '0', '车位作业管理', 'parking_work_manage'),
	('20120227102547000001', 'task_screen/task_main.action', NULL, 4, '1', '计划作业', '计划作业', '0', '计划作业', 'plan_work'),
	('20120228084715000001', NULL, NULL, 1, '1', '实时监控', '实时监控', '0', '实时监控', 'real_time_monitoring'),
	('20120228084939000003', 'monitor/timeout_list.action', NULL, 4, '1', '超时监控', '超时监控', '0', '超时监控', 'timeout_monitoring'),
	('25', 'monitor/message_list.action', NULL, 9, '1', '报警服务', '报警服务', '0', '报警服务', 'message_monitoring'),
	('20120228085036000005', 'monitor/fault_list.action', NULL, 6, '1', '故障监控', '故障监控', '0', '故障监控', 'fault_monitoring'),
	('20120229091532000001', 'mapmonitor/monitor_main.action', NULL, 1, '1', '地图监控', '地图监控', '0', '地图监控', 'map_monitoring'),
	('20120229130731000001', 'monitor/chart_init.action', NULL, 2, '1', '监控图表汇总', '监控图表汇总', '0', '监控图表汇总', 'monitoring_chart_summary'),
	('20120229180329000001', 'parking_statistics/park_chart_init.action', NULL, 3, '1', '停车出入图表', '停车出入图表', '0', '停车出入图表', 'in_and_out_situation_chart'),
	('20120229181958000003', 'parking_statistics/park_use_init.action', NULL, 4, '1', '停车占有率图表', '停车占有率图表', '0', '停车占有率图表', 'parking_occupancy_rate_chart'),
	/*('5', 'parking_statistics/logic_use_chart_init.action', NULL, 5, '1', '逻辑占有率图表', '逻辑占有率图表', '0', '逻辑占有率图表', 'logic_use_chart'),*/
	('20120301184018000001', 'base_info/base_info.action', NULL, 1, '1', '停车场信息维护', '停车场信息维护', '0', '停车场信息维护', 'parking_info_manage'),
	('20120302084200000001', 'physical_region/list.action', NULL, 2, '1', '物理区域配置', '物理区域配置', '0', '物理区域配置', 'physical_area_config'),
	('20120302104520000001', 'parking_statistics/used_list.action?list_type=used', NULL, 8, '1', '停车占有率情况', '停车占有率情况', '0', '停车占有率情况', 'parking_occupancy_rate'),
	('12', 'parking_statistics/logical_used_list.action', NULL, 12, '1', '地理区域占有率', '地理区域占有率', '0', '地理区域占有率', 'logical_parking_occupancy_rate'),
	('20120308100740000025', 'line_config/line_list.action', NULL, 12, '1', '通讯线路配置', '通讯线路配置', '0', '通讯线路配置', 'line_conf'),
	('20120308152156000002', 'screentypepara_config/screentypepara_list.action', NULL, 6, '1', '屏类型参数配置', '屏类型参数配置', '0', '屏类型参数配置', 'screentypepara_conf'),/*sort从7改为6 byLLX*/
	('20120317144457000001', 'map_manage/map_list.action', NULL, 4, '1', '地图管理', '地图管理', '0', '地图管理', 'map_manage'),
	('20120317215650000001', 'config_guide/config_guide.action', NULL, 1, '1', '配置向导', '配置向导', '0', '配置向导', 'config_guide'),
	('20120507142148000001', 'register/register_init.action', NULL, 1, '1', '注册', '注册', '0', '注册', 'register'),
	('22','pgsservice/pgsservice_read.action',NULL,22,'1','PGS服务管理','PGS服务管理','0','PGS服务管理','pgs_service_management'),
	('21','backup/backup_read.action',NULL,21,'1','数据备份','数据备份','0','数据备份','data_backup'),
	('24', 'screencolortactics/screen_list.action', NULL, 24, '1', '变色策略设置', '变色策略设置', '0', '变色策略设置', 'Color_change_tactics'),
	('26', 'controller_debugtask/controller_list_for_color_tactics.action', NULL, 26, '1', '自定义调试任务', '自定义调试任务', '0', '自定义调试任务', 'Custom_debug_task'),
	('29', 'searchmachine_manage/searchmachine_list.action', NULL, 29, '1', '查询机配置', '查询机配置', '0', '查询机配置', 'searchmachine_manage'),
	/*
	('20130128192315000001', NULL, NULL, 101, '1', '系统升级', '系统升级', '0', '系统升级', 'system_remote_update'),
	('20130128192615000001', 'remote_update/available_version_list.action', NULL, 102, '1', '软件版本更新', '软件版本更新', '0', '软件版本更新', 'software_version_update'),
	*/
	('2013031919850', 'advert/queryAdvert.action', null, '4', '1', '广告管理', '广告管理', '0', '广告管理', 'advert_manage'),
	('2013031920251', 'inversion/pictureManage.html', null, '2', '1', '反向寻车参数设置', '反向寻车参数设置', '0', '反向寻车参数设置', 'inversion_param_set'),
	('2013031930694', null, null, '103', '1', '反向寻车管理', '反向寻车管理', '0', '反向寻车管理', 'inversion_search_manage'),
	('2013031947903', 'inversion/index.html', null, '3', '1', '寻车子系统', '寻车子系统', '0', '寻车子系统', 'search_subsystem'),
	('2013031975169', 'inversion/searchCarManage.action', null, '1', '1', '查车管理', '查车管理', '0', '查车管理', 'search_car_manage'),
	('201307181507', 'log/operatorLog_list.action', null, '28', '1', '系统操作日志', '系统操作日志', '0', '系统操作日志', 'sys_operator_log'),
	('2013040714005692978', 'debugtool/debugtool_index.action', null, '20', '1', '调试工具', '调试工具', '0', '调试工具', 'debugging'),
	('20140530093705110001', 'searchmachine_manage/usemachine_times.action', null, '88', '1', '查询机使用统计', '查询机使用统计', '0', '查询机使用统计', 'query_machine_usage'),

	('20141010151422222222', 'parking_statistics/ud_workingRecord.action', null, '81', '1', '视频探测器运行情况', '视频探测器运行情况', '0', '视频探测器运行情况', 'ud_working_record'),
	('20141010151533333333', 'udworkingStatistics/ud_working_statistics.action', null, '82', '1', '视频探测器运行情况统计', '视频探测器运行情况统计', '0', '视频探测器运行情况统计', 'ud_working_statistics'),
	('20141015115822000008', 'udworkingStatisticsgraph/ud_working_statistics_graph.action', null, '83', '1', '视频探测器运行统计图', '视频探测器运行统计图', '0', '视频探测器运行统计图', 'ud_working_graph'),
	('20141028170700123456', 'parkspaceturnoverrate/parkspace_turnover_rate.action', null, '2', '1', '车位周转率', '车位周转率', '0', '车位周转率', 'parkspace_turnover_rate');
/* 	('23','device/device_list.action',NULL,23,'1','设备状态','设备状态','0','设备状态','device_state'),  */
/*!40000 ALTER TABLE `sys_act` ENABLE KEYS */;


-- Dumping structure for table ips.sys_act_relation
DROP TABLE IF EXISTS `sys_act_relation`;
CREATE TABLE IF NOT EXISTS `sys_act_relation` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `act_id` varchar(20) DEFAULT NULL COMMENT '操作ID',
  `parent_id` varchar(20) DEFAULT NULL COMMENT '父ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作关系表';

-- Dumping data for table ips.sys_act_relation: ~33 rows (approximately)
/*!40000 ALTER TABLE `sys_act_relation` DISABLE KEYS */;
INSERT INTO `sys_act_relation` (`id`, `act_id`, `parent_id`) VALUES
	('111111', '231212312312', '20110309110734026108'),
	('20110309110734030109', '20110309110734026108', '00'),
	('20110309110822700111', '20110309110822694110', '20110309110734026108'),
	('20140626105629426131', '20140626104129426122', '20110309110734026108'),
	('20110309160429441125', '20110309160429426124', '20110309110734026108'),
	('20110309170545367209', '20110309170545360208', '20110309110734026108'),
	('20110309170644189212', '20110309170644180211', '20110309110734026108'),
	('20120109154607000002', '20120109154607000001', '00'),
	('20120224103249000004', '20120224103249000003', '20120224103230000001'),
	('20120225091305000002', '20120225091305000001', '00'),
	('20140812151925000014', '20140812151119000004', '20120225091305000001'),
	('20120225100819000004', '20120225100819000003', '20120225091305000001'),
	('20120225114758000002', '20120225114758000001', '00'),
	('20120225114914000004', '20120225114914000003', '20120225114758000001'),
	('20120225114934000006', '20120225114934000005', '20120225114758000001'),
	('20120225114949000008', '20120225114949000007', '20120225114758000001'),
	('20120225115009000010', '20120225115009000009', '20120225114758000001'),
	('20120225155544000002', '20120225155544000001', '20110309110734026108'),
	('20120225162454000002', '20120225162454000001', '20110309110734026108'),
	('20120227102547000002', '20120227102547000001', '20110309110734026108'),
	('20120228084715000002', '20120228084715000001', '00'),
	('20120228084939000004', '20120228084939000003', '20120228084715000001'),
	('20120228085036000006', '20120228085036000005', '20120228084715000001'),
	('20120229091532000002', '20120229091532000001', '20120228084715000001'),
	('20120229130731000002', '20120229130731000001', '20120228084715000001'),
	('20120229180329000002', '20120229180329000001', '20120225091305000001'),
	('20120229181958000004', '20120229181958000003', '20120225091305000001'),
	('20140530094905222001', '20140530093705110001', '20120225091305000001'),
	('20120301184018000002', '20120301184018000001', '20110309110734026108'),
	('20120302084200000002', '20120302084200000001', '20120225114758000001'),
	('20120302104520000002', '20120302104520000001', '20120225091305000001'),
	('20120308100740000026', '20120308100740000025', '20120225114758000001'),
	('20120308152156000003', '20120308152156000002', '20120225114758000001'),
	('20120317144457000002', '20120317144457000001', '20120225114758000001'),
	('20120317215650000002', '20120317215650000001', '20120225114758000001'),
	('20120507142148000002', '20120507142148000001', '20110309110734026108'),
	('21','21','20110309110734026108'),
	('22','22','20110309110734026108'),
	/*('5','5','20120225091305000001'),*/
	('12','12','20120225091305000001'),
	('25','25','20120228084715000001'),
	('24','24','20110309110734026108'),
	('26','26','20110309110734026108'),
	('29','29','20120225114758000001'),
	/*
	('30','20130128192615000001','20130128192315000001'),
	('32','20130128192315000001','00'),
	*/
	('2013031933337', '2013031975169', '2013031930694'),
	('2013031952936', '2013031930694', '00'),
	('2013031981192', '2013031947903', '2013031930694'),
	('2013031986967', '2013031919850', '2013031930694'),
	('2013031994098', '2013031920251', '2013031930694'),
	('201307181509','201307181507','20110309110734026108'),
	('2013040714035032267', '2013040714005692978', '20110309110734026108'),
	
	('20141010151511111111', '20141010151422222222', '20120225091305000001'),
	('20141010151511111112', '20141010151533333333', '20120225091305000001'),
	('20141015120000000001', '20141015115822000008', '20120225091305000001'),
	('20141028171100123456', '20141028170700123456', '20120225091305000001');
/* 	('23','23','20110309110734026108'),   */
/*!40000 ALTER TABLE `sys_act_relation` ENABLE KEYS */;


-- Dumping structure for table ips.sys_language
DROP TABLE IF EXISTS `sys_language`;
CREATE TABLE IF NOT EXISTS `sys_language` (
  `code_id` varchar(20) NOT NULL COMMENT '语言编码',
  `code_name` varchar(200) DEFAULT NULL COMMENT '语言名称',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `lang_img` varchar(500) DEFAULT NULL COMMENT '语言图标',
  `login_img` varchar(500) DEFAULT NULL COMMENT '登录按钮图片',
  `username_img` varchar(500) DEFAULT NULL COMMENT '用户名图片',
  `password_img` varchar(500) DEFAULT NULL COMMENT '密码图片',
  `logout_img` varchar(500) DEFAULT NULL COMMENT '注销图片',
  PRIMARY KEY (`code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='语言表';

-- Dumping data for table ips.sys_language: ~2 rows (approximately)
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
INSERT INTO `sys_language` (`code_id`, `code_name`, `remark`, `lang_img`, `login_img`, `username_img`, `password_img`, `logout_img`) VALUES
	('44', 'English', NULL, '../images/en.jpg', '../images/login.jpg', '../images/login_usname_en.jpg', '../images/login_password_en.jpg', '../images/Management_Logout_en.jpg'),
	('86', '简体中文', NULL, '../images/cn.jpg', '../images/login_botton.jpg', '../images/login_usname.jpg', '../images/login_password.jpg', '../images/Management_Logout.jpg'),
	('87', '繁體中文', NULL, '../images/cn.jpg', '../images/login_botton_fan.jpg', '../images/login_usname_fan.jpg', '../images/login_password_fan.jpg', '../images/Management_Logout_fan.jpg');
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;


-- Dumping structure for table ips.sys_lang_switch
DROP TABLE IF EXISTS `sys_lang_switch`;
CREATE TABLE IF NOT EXISTS `sys_lang_switch` (
  `code_key` varchar(45) NOT NULL COMMENT '编码',
  `code_value` varchar(200) DEFAULT NULL COMMENT '值',
  `code_type` varchar(20) NOT NULL DEFAULT '' COMMENT '类型',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '语言',
  `remark` varchar(45) DEFAULT NULL COMMENT '备注',
  `orderby` int(10) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`code_key`,`code_type`,`lang`),
  UNIQUE KEY `Unique_codevalue_codetype_lang` (`code_value`,`code_type`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多语言表';

-- Dumping data for table ips.sys_lang_switch: ~785 rows (approximately)
/*!40000 ALTER TABLE `sys_lang_switch` DISABLE KEYS */;
INSERT INTO `sys_lang_switch` (`code_key`, `code_value`, `code_type`, `lang`, `remark`, `orderby`) VALUES
	('0', 'Double Color', 'color_mode', '44', NULL, NULL),
	('0', '双基色', 'color_mode', '86', NULL, NULL),
	('0', 'Normal', 'ctrl_status', '44', NULL, NULL),
	('0', '正常', 'ctrl_status', '86', NULL, NULL),
	('0', 'Unopen', 'detector_enable', '44', NULL, NULL),
	('0', '未开启', 'detector_enable', '86', NULL, NULL),
	('0', 'Normal', 'detector_status', '44', NULL, NULL),
	('0', '正常', 'detector_status', '86', NULL, NULL),
	('0', 'No.', 'enable', '44', NULL, NULL),
	('0', '否', 'enable', '86', NULL, NULL),
	('0', '../physical_region/list.action', 'guide_frame_src', '44', NULL, NULL),
	('0', '../physical_region/list.action', 'guide_frame_src', '86', NULL, NULL),
	('0', 'Physical Region Setting', 'guide_step_name', '44', NULL, NULL),
	('0', '物理区域设置', 'guide_step_name', '86', NULL, NULL),
	
	('0', 'Temporary', 'parking_type', '44', NULL, NULL),
	('0', '临时', 'parking_type', '86', NULL, NULL),
	('0', 'Stop', 'runstate', '44', NULL, NULL),
	('0', '停止', 'runstate', '86', NULL, NULL),
	('0', 'Unvalid', 'status', '44', NULL, NULL),
	('0', '无效', 'status', '86', NULL, NULL),
	('0', 'Failed', 'success', '44', NULL, NULL),
	('0', '失败', 'success', '86', NULL, NULL),
	('0', 'Per Week', 'task_type', '44', NULL, NULL),
	('0', '每周', 'task_type', '86', NULL, NULL),
	('6', 'Saturday', 'weekday_type', '44', NULL, NULL),
	('6', '星期六', 'weekday_type', '86', NULL, NULL),
	('00', 'Stop', 'state', '44', NULL, 2),
	('00', '停用', 'state', '86', NULL, 2),
	('01', 'Start', 'state', '44', NULL, 1),
	('01', '启用', 'state', '86', NULL, 1),
	('1', 'Single Color', 'color_mode', '44', NULL, NULL),
	('1', '单基色', 'color_mode', '86', NULL, NULL),
	('1', 'Offline', 'ctrl_status', '44', NULL, NULL),
	('1', '离线', 'ctrl_status', '86', NULL, NULL),
	('1', 'Open ', 'detector_enable', '44', NULL, NULL),
	('1', '开启', 'detector_enable', '86', NULL, NULL),
	('1', 'Abnormal', 'detector_status', '44', NULL, NULL),
	('1', '异常', 'detector_status', '86', NULL, NULL),
	('1', 'Ultrasonic Detector', 'detector_type', '44', NULL, NULL),
	('1', '超声波探测器', 'detector_type', '86', NULL, NULL),
	('1', 'Yes', 'enable', '44', NULL, NULL),
	('1', '是', 'enable', '86', NULL, NULL),
	('1', '../map_manage/map_list.action', 'guide_frame_src', '44', NULL, NULL),
	('1', '../map_manage/map_list.action', 'guide_frame_src', '86', NULL, NULL),
	('1', 'Map', 'guide_step_name', '44', NULL, NULL),
	('1', '地图管理', 'guide_step_name', '86', NULL, NULL),
	
	('1', 'Fixed', 'parking_type', '44', NULL, NULL),
	('1', '固定', 'parking_type', '86', NULL, NULL),
	('1', 'Executing', 'runstate', '44', NULL, NULL),
	('1', '执行中', 'runstate', '86', NULL, NULL),
	('1', 'Valid', 'status', '44', NULL, NULL),
	('1', '有效', 'status', '86', NULL, NULL),
	('1', 'Successfully', 'success', '44', NULL, NULL),
	('1', '成功', 'success', '86', NULL, NULL),
	('1', 'Single', 'task_type', '44', NULL, NULL),
	('1', '单次', 'task_type', '86', NULL, NULL),
	('0', 'Sunday', 'weekday_type', '44', NULL, NULL),
	('0', '星期日', 'weekday_type', '86', NULL, NULL),
	('10K', '10K', 'baud_rate', '44', NULL, 12),
	('10K', '10K', 'baud_rate', '86', NULL, 12),
	('115200', '115200', 'scr_baudrate', '44', NULL, 1),
	('115200', '115200', 'scr_baudrate', '86', NULL, 1),
	('1200', '1200', 'scr_baudrate', '44', NULL, 8),
	('1200', '1200', 'scr_baudrate', '86', NULL, 8),
	('125K', '125K', 'baud_rate', '44', NULL, 8),
	('125K', '125K', 'baud_rate', '86', NULL, 8),
	('19200', '19200', 'scr_baudrate', '44', NULL, 4),
	('19200', '19200', 'scr_baudrate', '86', NULL, 4),
	('1M', '1M', 'baud_rate', '44', NULL, 1),
	('1M', '1M', 'baud_rate', '86', NULL, 1),
	('2', 'Fault', 'ctrl_status', '44', NULL, NULL),
	('2', '故障', 'ctrl_status', '86', NULL, NULL),
	('2', 'Loop Dectector', 'detector_type', '44', NULL, NULL),
	('2', '地感探测器', 'detector_type', '86', NULL, NULL),
	('2', '../screentypepara_config/screentypepara_list.action', 'guide_frame_src', '44', NULL, NULL),
	('2', '../screentypepara_config/screentypepara_list.action', 'guide_frame_src', '86', NULL, NULL),
	('2', 'VMS Parameter Setup', 'guide_step_name', '44', NULL, NULL),
	('2', '屏类型参数配置', 'guide_step_name', '86', NULL, NULL),
	
	('2', 'Reserved', 'parking_type', '44', NULL, NULL),
	('2', '预定', 'parking_type', '86', NULL, NULL),
	('2', 'Immediately', 'task_type', '44', NULL, NULL),
	('2', '立即', 'task_type', '86', NULL, NULL),
	('1', 'Monday', 'weekday_type', '44', NULL, NULL),
	('1', '星期一', 'weekday_type', '86', NULL, NULL),
	('200K', '200K', 'baud_rate', '44', NULL, 7),
	('200K', '200K', 'baud_rate', '86', NULL, 7),
	('20K', '20K', 'baud_rate', '44', NULL, 11),
	('20K', '20K', 'baud_rate', '86', NULL, 11),
	('2400', '2400', 'scr_baudrate', '44', NULL, 7),
	('2400', '2400', 'scr_baudrate', '86', NULL, 7),
	('250K', '250K', 'baud_rate', '44', NULL, 6),
	('250K', '250K', 'baud_rate', '86', NULL, 6),
	('3', '../screen_config/screen_list.action', 'guide_frame_src', '44', NULL, NULL),
	('3', '../screen_config/screen_list.action', 'guide_frame_src', '86', NULL, NULL),
	('3', 'VMS Configuration', 'guide_step_name', '44', NULL, NULL),
	('3', '引导屏配置', 'guide_step_name', '86', NULL, NULL),
	
	('2', 'Tuesday', 'weekday_type', '44', NULL, NULL),
	('2', '星期二', 'weekday_type', '86', NULL, NULL),
	('38400', '38400', 'scr_baudrate', '44', NULL, 3),
	('38400', '38400', 'scr_baudrate', '86', NULL, 3),
	('4', '../guideregion_manage/guideregion_list.action', 'guide_frame_src', '44', NULL, NULL),
	('4', '../guideregion_manage/guideregion_list.action', 'guide_frame_src', '86', NULL, NULL),
	('4', 'Configure Guiding Zone ', 'guide_step_name', '44', NULL, NULL),
	('4', '引导区域配置', 'guide_step_name', '86', NULL, NULL),
	
	('3', 'Wednesday', 'weekday_type', '44', NULL, NULL),
	('3', '星期三', 'weekday_type', '86', NULL, NULL),
	('400K', '400K', 'baud_rate', '44', NULL, 5),
	('400K', '400K', 'baud_rate', '86', NULL, 5),
	('40K', '40K', 'baud_rate', '44', NULL, 10),
	('40K', '40K', 'baud_rate', '86', NULL, 10),
	('4800', '4800', 'scr_baudrate', '44', NULL, 6),
	('4800', '4800', 'scr_baudrate', '86', NULL, 6),
	('5', '../logicregion_manage/logicregion_list.action', 'guide_frame_src', '44', NULL, NULL),
	('5', '../logicregion_manage/logicregion_list.action', 'guide_frame_src', '86', NULL, NULL),
	('5', 'Logic Zone Configuration', 'guide_step_name', '44', NULL, NULL),
	('5', '地理区域配置', 'guide_step_name', '86', NULL, NULL),
	
	('4', 'Thursday', 'weekday_type', '44', NULL, NULL),
	('4', '星期四', 'weekday_type', '86', NULL, NULL),
	('500K', '500K', 'baud_rate', '44', NULL, 4),
	('500K', '500K', 'baud_rate', '86', NULL, 4),
	('50K', '50K', 'baud_rate', '44', NULL, 9),
	('50K', '50K', 'baud_rate', '86', NULL, 9),
	('57600', '57600', 'scr_baudrate', '44', NULL, 2),
	('57600', '57600', 'scr_baudrate', '86', NULL, 2),
	('6', '../screen_logic/logic_main.action', 'guide_frame_src', '44', NULL, NULL),
	('6', '../screen_logic/logic_main.action', 'guide_frame_src', '86', NULL, NULL),
	('6', 'VMS Logic', 'guide_step_name', '44', NULL, NULL),
	('6', '引导屏逻辑', 'guide_step_name', '86', NULL, NULL),
	('5', 'Friday', 'weekday_type', '44', NULL, NULL),
	('5', '星期五', 'weekday_type', '86', NULL, NULL),
	('600', '600', 'scr_baudrate', '44', NULL, 9),
	('600', '600', 'scr_baudrate', '86', NULL, 9),
	('666K', '666K', 'baud_rate', '44', NULL, 3),
	('666K', '666K', 'baud_rate', '86', NULL, 3),
	('7', '../line_config/line_list.action', 'guide_frame_src', '44', NULL, NULL),
	('7', '../line_config/line_list.action', 'guide_frame_src', '86', NULL, NULL),
	('7', 'Communication Line Configuration', 'guide_step_name', '44', NULL, NULL),
	('7', '通讯线路配置', 'guide_step_name', '86', NULL, NULL),
	('8', '../detector_config/detector_list.action', 'guide_frame_src', '44', NULL, NULL),
	('8', '../detector_config/detector_list.action', 'guide_frame_src', '86', NULL, NULL),
	('8', 'UD Configure', 'guide_step_name', '44', NULL, NULL),
	('8', '探测器配置', 'guide_step_name', '86', NULL, NULL),
	('800K', '800K', 'baud_rate', '44', NULL, 2),
	('800K', '800K', 'baud_rate', '86', NULL, 2),
	('9', '../controller_config/controller_list.action', 'guide_frame_src', '44', NULL, NULL),
	('9', '../controller_config/controller_list.action', 'guide_frame_src', '86', NULL, NULL),
	('9', 'ZC Configuration', 'guide_step_name', '44', NULL, NULL),
	('9', '管理器配置', 'guide_step_name', '86', NULL, NULL),
	('9600', '9600', 'scr_baudrate', '44', NULL, 5),
	('9600', '9600', 'scr_baudrate', '86', NULL, 5),
	('a', NULL, 'showmenu', '44', NULL, NULL),
	('a', '第', 'showmenu', '86', NULL, NULL),
	('address', 'Address', 'common', '44', NULL, NULL),
	('address', '地址', 'common', '86', NULL, NULL),
	('add_region', 'Add Area', 'common', '44', NULL, NULL),
	('add_region', '添加区域', 'common', '86', NULL, NULL),
	('alert_abnormal', 'When abnormal times exceed the \'Judging times\'set up within the \'Judging Time\',the equipment will be regarded as abnormal.', 'common', '44', NULL, NULL),
	('alert_abnormal', '在设置的【判断时间】内判定异常次数超过设置的【判定次数】将认为设备异常', 'common', '86', NULL, NULL),
	('alert_account_already_out_of_service', 'Account already out of service, please contact with administrator', 'common', '44', NULL, NULL),
	('alert_account_already_out_of_service', '账户已停用,请联系管理员', 'common', '86', NULL, NULL),
	('alert_again_issued_config_file', 'Please again to issue a configuration file', 'common', '44', NULL, NULL),
	('alert_again_issued_config_file', '请重新下发配置文件', 'common', '86', NULL, NULL),
	('alert_and', 'and', 'common', '44', NULL, NULL),
	('alert_and', '与', 'common', '86', NULL, NULL),
	('alert_auto_split', 'The system will automatically split your data. Please choose the off-peak time.', 'common', '44', NULL, NULL),
	('alert_auto_split', '系统自动为您进行数据拆分,请选择在车流量不大的时间点', 'common', '86', NULL, NULL),
	('alert_batch_config_please_select_same_screen', 'Batch screen type configuration, please choose the type of the same screen', 'common', '44', NULL, NULL),
	('alert_batch_config_please_select_same_screen', '批量屏类型配置,请选择类型相同的屏', 'common', '86', NULL, NULL),
	('alert_com_service_offline', 'Communications services offline', 'common', '44', NULL, NULL),
	('alert_com_service_offline', '通讯服务离线', 'common', '86', NULL, NULL),
	('alert_connect_timeout', 'Connection timed, please check the database links', 'common', '44', NULL, NULL),
	('alert_connect_timeout', '连接超时，请检查数据库链接', 'common', '86', NULL, NULL),
	('alert_delete', 'Are you sure to delete this record?', 'common', '44', NULL, NULL),
	('alert_delete', '您确定要删除此记录吗', 'common', '86', NULL, NULL),
	('alert_detector_conflict', 'The type of ulstrasonic sensors shoule be the same as the guiding zone.', 'common', '44', NULL, NULL),
	('alert_detector_conflict', '探测器类型与引导区类型必须相同', 'common', '86', NULL, NULL),
	('alert_field_format_error', 'Wrong format.', 'common', '44', NULL, NULL),
	('alert_field_format_error', '格式错误', 'common', '86', NULL, NULL),
	('alert_guide_regional_already_used', 'Guide regional has already been used, can not be removed', 'common', '44', NULL, NULL),
	('alert_guide_regional_already_used', '引导区域已经被使用,不能删除', 'common', '86', NULL, NULL),
	('alert_guide_regional_name_repeat', 'Guide regional name or coding cant repeat, please modify', 'common', '44', NULL, NULL),
	('alert_guide_regional_name_repeat', '引导区域名称或编码不能重复,请修改', 'common', '86', NULL, NULL),
	('alert_input_number_is_empty', 'The number of pages of the input is empty', 'common', '44', NULL, NULL),
	('alert_input_number_is_empty', '您输入的页数是空的', 'common', '86', NULL, NULL),
	('alert_input_number_not_Numbers', 'The number of pages of the input is not Numbers', 'common', '44', NULL, NULL),
	('alert_input_number_not_Numbers', '您输入的页数不是数字', 'common', '86', NULL, NULL),
	('alert_input_number_too_big', 'The number of pages of the input is too big', 'common', '44', NULL, NULL),
	('alert_input_number_too_big', '您输入的页数过大', 'common', '86', NULL, NULL),
	('alert_input_number_too_small', 'The number of pages of the input is too small', 'common', '44', NULL, NULL),
	('alert_input_number_too_small', '您输入的页数过小', 'common', '86', NULL, NULL),
	('alert_instructions_issued_by_success', 'Instructions issued by success', 'common', '44', NULL, NULL),
	('alert_instructions_issued_by_success', '下发指令成功', 'common', '86', NULL, NULL),
	('alert_interval_regular_sensor', 'time interval of regular data correction of ground sensor boot sector', 'common', '44', NULL, NULL),
	('alert_interval_regular_sensor', '定时修正地感引导区数据的间隔时间', 'common', '86', NULL, NULL),
	('alert_interval_update_conf', 'Time interval of regular update of data configuration', 'common', '44', NULL, NULL),
	('alert_interval_update_conf', '定时更新配置数据的间隔时间', 'common', '86', NULL, NULL),
	('alert_is_exist', 'Already exist', 'common', '44', NULL, NULL),
	('alert_is_exist', '已存在', 'common', '86', NULL, NULL),
	('alert_is_not_null', 'Null not allowed', 'common', '44', NULL, NULL),
	('alert_is_not_null', '不能为空', 'common', '86', NULL, NULL),
	('alert_line_already_exists', 'Communications lines name already exists, please modify', 'common', '44', NULL, NULL),
	('alert_line_already_exists', '通讯线路名称已经存在,请修改', 'common', '86', NULL, NULL),
	('alert_line_cant_for_empty', 'Communications lines can\'t for empty', 'common', '44', NULL, NULL),
	('alert_line_cant_for_empty', '通讯线路不能为空', 'common', '86', NULL, NULL),
  ('alert_ini_file_task_established','The task has been established, this operation may take a few minutes, during the system will temporarily stop guide, please wait patiently! ','common','44',NULL,NULL),
  ('alert_ini_file_task_established','任务已建立，此项操作可能需要几分钟，期间系统会暂时停止引导，请耐心等候！','common','86',NULL,NULL),
	('alert_line_to_be_allocated_cant_delete', 'The current communication route has been used. You cannot delete.', 'common', '44', NULL, NULL),
	('alert_line_to_be_allocated_cant_delete', '当前通讯线路已被引用，不能删除', 'common', '86', NULL, NULL),
	('alert_line_to_be_allocated_cant_disable', 'The current communication route has been used. You cannot set it as invalid.', 'common', '44', NULL, NULL),
	('alert_line_to_be_allocated_cant_disable', '当前通讯线路已被引用，不能设置无效状态', 'common', '86', NULL, NULL),
	('alert_logic_area_name_repeat', 'Logic area name or coding repeat, please modify', 'common', '44', NULL, NULL),
	('alert_logic_area_name_repeat', '地理区域名称或编码重复,请修改', 'common', '86', NULL, NULL),
	('alert_logout_confirm', 'Are you sure to log out?', 'common', '44', NULL, NULL),
	('alert_logout_confirm', '您确认要从本系统注销吗？', 'common', '86', NULL, NULL),
	('alert_map_already_exists', 'Map already exists,please upload again.', 'common', '44', NULL, NULL),
	('alert_map_already_exists', '地图文件已经存在请重新上传', 'common', '86', NULL, NULL),
	('alert_map_already_import', 'Data has been imported into the map.', 'common', '44', NULL, NULL),
	('alert_map_already_import', '该地图已经导入数据,禁止重复导入', 'common', '86', NULL, NULL),
	('alert_map_file_is_not_correct', 'The Map is incorrect,please import again.', 'common', '44', NULL, NULL),
	('alert_map_file_is_not_correct', '地图文件不正确，请重新导入文件', 'common', '86', NULL, NULL),
	('alert_map_file_not_exits', 'Map does not exist,You cannot import data', 'common', '44', NULL, NULL),
	('alert_map_file_not_exits', '地图文件不存在，不能进行导入数据操作', 'common', '86', NULL, NULL),
	('alert_map_name_already_exists', 'Map name already exists, please modify', 'common', '44', NULL, NULL),
	('alert_map_name_already_exists', '地图名称已经存在,请修改', 'common', '86', NULL, NULL),
	('alert_max_length', 'Max. Qty of UD', 'common', '44', NULL, NULL),
	('alert_max_length', '最大长度为', 'common', '86', NULL, NULL),
	('alert_multiple_values', 'If multiple values, please set off by a comma for example: 12,45,78', 'common', '44', NULL, NULL),
	('alert_multiple_values', '如果多个值 请用逗号分开 例如: 12,45,78', 'common', '86', NULL, NULL),
	('alert_not_reg_limit_use', 'Not registered or has expired,Limit equipment use quantity', 'common', '44', NULL, NULL),
	('alert_not_reg_limit_use', '未注册或已过期，限制设备使用数量', 'common', '86', NULL, NULL),
	('alert_no_same', 'Inconsistent', 'common', '44', NULL, NULL),
	('alert_no_same', '不一致', 'common', '86', NULL, NULL),
	('alert_only_number', 'Only numbers are allowed.', 'common', '44', NULL, NULL),
	('alert_only_number', '只能填数字', 'common', '86', NULL, NULL),
	('alert_physicalregion_have_map_association', 'Map information already exists in the current phisical region.', 'common', '44', NULL, NULL),
	('alert_physicalregion_have_map_association', '当前的物理区域有地图信息,因此不能设置为无效', 'common', '86', NULL, NULL),
	('alert_physical_area_already_exists', 'Physical area name already exists, please modify', 'common', '44', NULL, NULL),
	('alert_physical_area_already_exists', '物理区域名称已经存在,请修改', 'common', '86', NULL, NULL),
	('alert_physical_area_has_related_maps', 'Physical area has related maps, can not be removed', 'common', '44', NULL, NULL),
	('alert_physical_area_has_related_maps', '物理区域已关联地图,不能删除', 'common', '86', NULL, NULL),
	('alert_please_check_the_box_to_confirm', 'Please select the checkbox and confirm revision.', 'common', '44', NULL, NULL),
	('alert_please_check_the_box_to_confirm', '请选中复选框确认修改', 'common', '86', NULL, NULL),
	('alert_please_first_choice_select_screen_type', 'Please first choice select screen type, again configuration screen parameters', 'common', '44', NULL, NULL),
	('alert_please_first_choice_select_screen_type', '请选择屏类型,再配置屏参数', 'common', '86', NULL, NULL),
	('alert_please_input', 'Please input', 'common', '44', NULL, NULL),
	('alert_please_input', '请输入', 'common', '86', NULL, NULL),
	('alert_please_input_a_code', 'Please input code', 'common', '44', NULL, NULL),
	('alert_please_input_a_code', '请输入编码', 'common', '86', NULL, NULL),
	('alert_please_input_a_height', 'Please input height', 'common', '44', NULL, NULL),
	('alert_please_input_a_height', '请输入高度', 'common', '86', NULL, NULL),
	('alert_please_input_a_lineaddress', 'Please input a lineaddress', 'common', '44', NULL, NULL),
	('alert_please_input_a_lineaddress', '请输入线路地址', 'common', '86', NULL, NULL),
	('alert_please_input_a_name', 'Please input name', 'common', '44', NULL, NULL),
	('alert_please_input_a_name', '请输入名称', 'common', '86', NULL, NULL),
	('alert_please_input_a_type', 'Please input type ', 'common', '44', NULL, NULL),
	('alert_please_input_a_type', '请输入类型', 'common', '86', NULL, NULL),
	('alert_please_select_a_record', 'Please select record first.', 'common', '44', NULL, NULL),
	('alert_please_select_a_record', '请先选择记录', 'common', '86', NULL, NULL),
	('alert_input_less_than_area', 'The input value must be less than the value of the area.', 'common', '44', NULL, NULL),
	('alert_input_less_than_area', '输入值须小于该区域车位数', 'common', '86', NULL, NULL),
	('alert_input_less_than_area', '輸入值須小於該區域車位數.', 'common', '87', NULL, NULL),
	('alert_min_cannot_bigger_than_max', '下界值不能大于上界值', 'common', '86', NULL, NULL),
	('alert_min_cannot_bigger_than_max', 'The min value cannot be bigger than the max value.', 'common', '44', NULL, NULL),
	('alert_min_cannot_bigger_than_max', '下界值不能大於上界值', 'common', '87', NULL, NULL),
	('alert_max_cannot_less_than_min', '上界值不能小于下界值', 'common', '86', NULL, NULL),
	('alert_max_cannot_less_than_min', 'The max value cannot be less than the min value.', 'common', '44', NULL, NULL),
	('alert_max_cannot_less_than_min', '上界值不能小於下界值', 'common', '87', NULL, NULL),
        ('alert_give_screen_guid_area', '请先给引导屏分配引导区域', 'common', '86', NULL, NULL),
	('alert_give_screen_guid_area', 'Please give the  screen guide area first.', 'common', '44', NULL, NULL),
	('alert_give_screen_guid_area', '請先給引導屏分配引導區域', 'common', '87', NULL, NULL),
        ('alert_enter_integer_value', '输入值不是正整数', 'common', '86', NULL, NULL),
	('alert_enter_integer_value', 'Enter a positive integer value.', 'common', '44', NULL, NULL),
	('alert_enter_integer_value', '輸入值不是正整數', 'common', '87', NULL, NULL),
	
        ('alert_enter_modify_file_path', '输入要修改的配置文件路径', 'common', '86', NULL, NULL),
	('alert_enter_modify_file_path', 'Enter the path to modify the configuration file', 'common', '44', NULL, NULL),
	('alert_enter_modify_file_path', '輸入要修改的配置文件路徑', 'common', '87', NULL, NULL),
        ('read_configuration_file', '读取配置文件', 'common', '86', NULL, NULL),
	('read_configuration_file', 'Read the configuration file', 'common', '44', NULL, NULL),
	('read_configuration_file', '讀取配置文件', 'common', '87', NULL, NULL),
	('alert', '修改', 'common', '86', NULL, NULL),
	('alert', 'Alert', 'common', '44', NULL, NULL),
	('alert', '修改', 'common', '87', NULL, NULL),
	('system_configuration', '系统相关配置', 'common', '86', NULL, NULL),
	('system_configuration', 'System configuration', 'common', '44', NULL, NULL),
	('system_configuration', '系統相關配置', 'common', '87', NULL, NULL),
	('maxNum__backup_file', '普通日记备份文件的最大数目', 'common', '86', NULL, NULL),
	('maxNum__backup_file', 'The maximum number of ordinary backup diary file ','common','44', NULL, NULL),
	('maxNum__backup_file', '普通日記備份文件的最大數目', 'common', '87', NULL, NULL),
        ('maximum_common_log', '普通日志的最大值(超过此大小则进行转存)', 'common', '86', NULL, NULL),
	('maximum_common_log', 'The maximum common log (exceeds this size is to keep)','common', '44', NULL, NULL),
	('maximum_common_log', '普通日誌的最大值(超過此大小則進行轉存)', 'common', '87', NULL, NULL),
	('maximum_transceiver_diary_file', '收发日记备份文件的最大数目', 'common', '86', NULL, NULL),
	('maximum_transceiver_diary_file', 'Maximum number of transceiver backup diary file', 'common','44', NULL, NULL),
	('maximum_transceiver_diary_file', '收發日記備份文件的最大數目', 'common', '87', NULL, NULL),
	('maximum_transceiver_receive_log', '收发日志的最大值', 'common', '86', NULL, NULL),
	('maximum_transceiver_receive_log', 'The maximum transmit receive log', 'common','44', NULL, NULL),
	('maximum_transceiver_receive_log', '收發日誌的最大值', 'common', '87', NULL, NULL),
	('cylceAI', '定时发A1命令刷新图片的周期', 'common', '86', NULL, NULL),
	('cylceAI', 'The cycle of send A1 command to  refresh picture', 'common','44', NULL, NULL),
	('cylceAI', '定時發A1命令刷新圖片的周期', 'common', '87', NULL, NULL),
        ('Task_processing_threads', '任务处理线程数', 'common', '86', NULL, NULL),
	('Task_processing_threads', 'Task processing threads', 'common','44', NULL, NULL),
	('Task_processing_threads', '任務處理線程數', 'common', '87', NULL, NULL),
	('initial_memory', '是否启用定时出始化内存的功能', 'common', '86', NULL, NULL),
	('initial_memory', 'Whether to enable the timing of initial memory function', 'common','44', NULL, NULL),
	('initial_memory', '是否啟用定時出始化內存的功能', 'common', '87', NULL, NULL),
	('Image_cache_size', '图片缓存大小,单位K', 'common', '86', NULL, NULL),
	('Image_cache_size', 'Image cache size, unit K','common', '44', NULL, NULL),
	('Image_cache_size', '圖片緩存大小,單位K', 'common', '87', NULL, NULL),
	('Picture_base_path', '图片存储基路径(默认:/usr/its)', 'common', '86', NULL, NULL),
	('Picture_base_path', 'Picture storage base path (default: /usr/its)', 'common','44', NULL, NULL),
	('Picture_base_path', '圖片存儲基路徑(默認:/usr/its)', 'common', '87', NULL, NULL),
	('Picture_thread_num', '图片接收线程池中默认创建线程的数量', 'common', '86', NULL, NULL),
	('Picture_thread_num', 'The number of images in the receiving thread pool threads are created by default', 'common','44', NULL, NULL),
	('Picture_thread_num', '圖片接收線程池中默認創建線程的數量', 'common', '87', NULL, NULL),
	('Agent_communication_port', '通讯代理端口,默认5236', 'common', '86', NULL, NULL),
	('Agent_communication_port', 'Agent communication port, the default 5236', 'common','44', NULL, NULL),
	('Agent_communication_port', '通訊代理端口,默認5236', 'common', '87', NULL, NULL),
	('Car_access_num', '收到出入车数,默认100', 'common', '86', NULL, NULL),
	('Car_access_num', 'Receive access number of vehicles, the default 100','common', '44', NULL, NULL),
	('Car_access_num', '收到出入車數,默認100', 'common', '87', NULL, NULL),
	('time_initialization', '每天什么时候初始化内存,默认3点', 'common', '86', NULL, NULL),
	('time_initialization', 'What time of day the default initialization of memory, the default 3', 'common','44', NULL, NULL),
	('time_initialization', '每天什麽時候初始化內存,默認3點', 'common', '87', NULL, NULL),
	('time_offline', '视频探测器离线判断时间,默认180000(3分钟)', 'common', '86', NULL, NULL),
	('time_offline', 'Video detector off-line time of judgment, the default 180000 (3 minutes)', 'common','44', NULL, NULL),
	('time_offline', '視頻探測器離線判斷時間,默認180000(3分鐘)', 'common', '87', NULL, NULL),
	

	('alert_please_select_the_day', 'Please select the date to query.', 'common', '44', NULL, NULL),
	('alert_please_select_the_day', '请选择要查询的日期', 'common', '86', NULL, NULL),
	('alert_please_select_the_month', 'Please select the month to query', 'common', '44', NULL, NULL),
	('alert_please_select_the_month', '请选择要查询的月份', 'common', '86', NULL, NULL),
	('alert_please_select_the_year', 'Please select the year to query.', 'common', '44', NULL, NULL),
	('alert_please_select_the_year', '请选择要查询的年份', 'common', '86', NULL, NULL),
	('alert_remove_parking_and_logicset', 'This operation will remove all parking and its logic setting', 'common', '44', NULL, NULL),
	('alert_remove_parking_and_logicset', '该操作将清除所有车位及它的逻辑设置', 'common', '86', NULL, NULL),
	('alert_right_format', 'Correct format.', 'common', '44', NULL, NULL),
	('alert_right_format', '正确格式', 'common', '86', NULL, NULL),
	('alert_screen_type_code_already_exists', 'Screen type code already exists. Please modify', 'common', '44', NULL, NULL),
	('alert_screen_type_code_already_exists', '屏类型名称或编码已经存在,请修改', 'common', '86', NULL, NULL),
	('alert_screen_type_name_already_exists', 'Screen type name already exists, please modify', 'common', '44', NULL, NULL),
	('alert_screen_type_name_already_exists', '屏类型参数名称或编码已经存在,请修改', 'common', '86', NULL, NULL),
	('alert_should_less', 'Should be less than', 'common', '44', NULL, NULL),
	('alert_should_less', '应该小于', 'common', '86', NULL, NULL),
	('alert_should_more', 'Should be more than', 'common', '44', NULL, NULL),
	('alert_should_more', '应该大于', 'common', '86', NULL, NULL),
	('alert_single_select', 'You can only operate on one record.', 'common', '44', NULL, NULL),
	('alert_single_select', '您只能选择一条记录进行该操作', 'common', '86', NULL, NULL),
	('alert_this', 'This', 'common', '44', NULL, NULL),
	('alert_this', '该', 'common', '86', NULL, NULL),
	('alert_to_deal', 'To deal with the negative effects of emergencies such as power failure, earthquake,flood and so on, please choose the number of days for historical data analysis.', 'common', '44', NULL, NULL),
	('alert_to_deal', '为了应付不可预知情况,例如停电,洪水等对数据拆分的不利影响,请选择分析历史数据的天数', 'common', '86', NULL, NULL),
	('alert_will_delete_controller_settings', 'Will delete controller Settings', 'common', '44', NULL, NULL),
	('alert_will_delete_controller_settings', '将删除管理器相关设置', 'common', '86', NULL, NULL),
	('alert_will_delete_screen_settings', 'Will delete screen Settings', 'common', '44', NULL, NULL),
	('alert_will_delete_screen_settings', '将删除引导屏相关设置', 'common', '86', NULL, NULL),
	('all', 'Total', 'common', '44', NULL, NULL),
	('all', '全部', 'common', '86', NULL, NULL),
	('all_map_collection', 'All map collection', 'common', '44', NULL, NULL),
	('all_map_collection', '全部地图汇总', 'common', '86', NULL, NULL),
	('area', 'Zone', 'common', '44', NULL, NULL),
	('area', '区域', 'common', '86', NULL, NULL),
	('average', 'Average', 'common', '44', NULL, NULL),
	('average', '平均', 'common', '86', NULL, NULL),
	('baud_rate', 'Baud Rate', 'common', '44', NULL, NULL),
	('baud_rate', '波特率', 'common', '86', NULL, NULL),
	('blue', 'blue', 'font_color', '44', NULL, NULL),
	('blue', '蓝', 'font_color', '86', NULL, NULL),
	('board_no', 'Board Port', 'common', '44', NULL, NULL),
	('board_no', '板卡号', 'common', '86', NULL, NULL),
	('btn_add', 'New', 'common', '44', NULL, NULL),
	('btn_add', '新建', 'common', '86', NULL, NULL),
	('btn_alledit', 'Refresh All', 'common', '44', NULL, NULL),
	('btn_alledit', '全部更新', 'common', '86', NULL, NULL),
	('btn_batchedit', 'Batch Edit', 'common', '44', NULL, NULL),
	('btn_batchedit', '批量编辑', 'common', '86', NULL, NULL),
	('btn_clear', 'Clean', 'common', '44', NULL, NULL),
	('btn_clear', '清空', 'common', '86', NULL, NULL),
	('btn_createczone', 'Add User-defined Zone', 'common', '44', NULL, NULL),
	('btn_createczone', '添加自定义区域', 'common', '86', NULL, NULL),
	('btn_creategzone', 'Add Guiding Zone', 'common', '44', NULL, NULL),
	('btn_creategzone', '添加引导区域', 'common', '86', NULL, NULL),
	('btn_default', 'Reset Default', 'common', '44', NULL, NULL),
	('btn_default', '重置缺省值', 'common', '86', NULL, NULL),
	('btn_delete', 'Delete', 'common', '44', NULL, NULL),
	('btn_delete', '删除', 'common', '86', NULL, NULL),
	('btn_detail', 'Detailed Information', 'common', '44', NULL, NULL),
	('btn_detail', '详细信息', 'common', '86', NULL, NULL),
	('btn_edit', 'Edit', 'common', '44', NULL, NULL),
	('btn_edit', '编辑', 'common', '86', NULL, NULL),
	('btn_edits', 'Edit/Batch', 'common', '44', NULL, NULL),
	('btn_edits', '编辑/批量', 'common', '86', NULL, NULL),
	('btn_logiczoneconfig', 'Configure Guiding Zone', 'common', '44', NULL, NULL),
	('btn_logiczoneconfig', '配置引导区域', 'common', '86', NULL, NULL),
	('btn_query', 'Query', 'common', '44', NULL, NULL),
	('btn_query', '查询', 'common', '86', NULL, NULL),
	('btn_resetczone', 'Reset User-define Zone', 'common', '44', NULL, NULL),
	('btn_resetczone', '重置自定义区域', 'common', '86', NULL, NULL),
	('btn_resetgzone', 'Reset Guiding Zone', 'common', '44', NULL, NULL),
	('btn_resetgzone', '重置引导区域', 'common', '86', NULL, NULL),
	('btn_return', 'Back', 'common', '44', NULL, NULL),
	('btn_return', '返回', 'common', '86', NULL, NULL),
	('btn_save', 'Save', 'common', '44', NULL, NULL),
	('btn_save', '保存', 'common', '86', NULL, NULL),
	('checked', 'Select', 'common', '44', NULL, NULL),
	('checked', '选中', 'common', '86', NULL, NULL),
	('check_code', 'Check Code', 'common', '44', NULL, NULL),
	('check_code', '校验码', 'common', '86', NULL, NULL),
	('code', 'Coding', 'common', '44', NULL, NULL),
	('code', '编码', 'common', '86', NULL, NULL),
	('color_mode', 'Color Model', 'common', '44', NULL, NULL),
	('color_mode', '颜色模式', 'common', '86', NULL, NULL),
	('communication_line', 'Communication Line', 'common', '44', NULL, NULL),
	('communication_line', '通讯线路', 'common', '86', NULL, NULL),
	('condition', 'Condition', 'common', '44', NULL, NULL),
	('condition', '条件', 'common', '86', NULL, NULL),
	('config_file_path', 'Configuration File Route', 'common', '44', NULL, NULL),
	('config_file_path', '配置文件路径', 'common', '86', NULL, NULL),
	('config_guide', 'Configuration Wizard', 'common', '44', NULL, NULL),
	('config_guide', '配置向导', 'common', '86', NULL, NULL),
	('config_history', 'Release Event Viewing', 'common', '44', NULL, NULL),
	('config_history', '下发历史查看', 'common', '86', NULL, NULL),
	('config_task', 'Release Event Checking', 'common', '44', NULL, NULL),
	('config_task', '下发任务查看', 'common', '86', NULL, NULL),
	('confirm_password', 'Confirm Password', 'common', '44', NULL, NULL),
	('confirm_password', '确认密码', 'common', '86', NULL, NULL),
	('content', 'Content', 'common', '44', NULL, NULL),
	('content', '内容', 'common', '86', NULL, NULL),
	('content_display', 'Content View', 'common', '44', NULL, NULL),
	('content_display', '内容显示', 'common', '86', NULL, NULL),
	('content_format', 'Content Format', 'common', '44', NULL, NULL),
	('content_format', '内容格式', 'common', '86', NULL, NULL),
	('controller', 'Zonal Controller (ZC)', 'common', '44', NULL, NULL),
	('controller', '管理器', 'common', '86', NULL, NULL),
	('controller_addr', 'ZC Address', 'common', '44', NULL, NULL),
	('controller_addr', '管理器地址', 'common', '86', NULL, NULL),
	('controller_conf', 'ZC Configuration', 'common', '44', NULL, NULL),
	('controller_conf', '管理器配置', 'common', '86', NULL, NULL),
	('controller_id', 'ZC ID', 'common', '44', NULL, NULL),
	('controller_id', '管理器Id', 'common', '86', NULL, NULL),
	('controller_port', 'ZC Port', 'common', '44', NULL, NULL),
	('controller_port', '管理器端口', 'common', '86', NULL, NULL),
	('controller_type', 'ZC Type', 'common', '44', NULL, NULL),
	('controller_type', '管理器类型', 'common', '86', NULL, NULL),
	('custom_area', 'User-defined Zone', 'common', '44', NULL, NULL),
	('custom_area', '自定义区域', 'common', '86', NULL, NULL),
	('data_analysis_days', 'Data analysis days', 'common', '44', NULL, NULL),
	('data_analysis_days', '停车数据分析天数', 'common', '86', NULL, NULL),
	('data_analysis_time', 'Data analysis time', 'common', '44', NULL, NULL),
	('data_analysis_time', '停车数据分析时间', 'common', '86', NULL, NULL),
	('data_bits', 'Data Bit', 'common', '44', NULL, NULL),
	('data_bits', '数据位', 'common', '86', NULL, NULL),
	('date', 'Date', 'common', '44', NULL, NULL),
	('date', '日期', 'common', '86', NULL, NULL),
	('day', 'Day', 'common', '44', NULL, NULL),
	('day', '日', 'common', '86', NULL, NULL),
	('day_hour', 'Day/Hour', 'common', '44', NULL, NULL),
	('day_hour', '日/时', 'common', '86', NULL, NULL),
	('default_value', 'Default', 'common', '44', NULL, NULL),
	('default_value', '默认值', 'common', '86', NULL, NULL),
	('detector', 'UD', 'common', '44', NULL, NULL),
	('detector', '探测器', 'common', '86', NULL, NULL),
	('detector', 'UD', 'map_dtype', '44', NULL, NULL),
	('detector', '探测器', 'map_dtype', '86', NULL, NULL),
	('detector_addr', 'UD Address', 'common', '44', NULL, NULL),
	('detector_addr', '探测器地址', 'common', '86', NULL, NULL),
	('detector_code', 'UD Code', 'common', '44', NULL, NULL),
	('detector_code', '探测器编码', 'common', '86', NULL, NULL),
	('detector_conf', 'UD Configure', 'common', '44', NULL, NULL),
	('detector_conf', '探测器配置', 'common', '86', NULL, NULL),
	('detector_height', 'UD Installed Height', 'common', '44', NULL, NULL),
	('detector_height', '探测器高度', 'common', '86', NULL, NULL),
	('detector_id', 'UD ID', 'common', '44', NULL, NULL),
	('detector_id', '探测器ID', 'common', '86', NULL, NULL),
	('detector_type', 'UD Mode', 'common', '44', NULL, NULL),
	('detector_type', '探测器类型', 'common', '86', NULL, NULL),
	('device_type', 'Device Type', 'common', '44', NULL, NULL),
	('device_type', '设备类型', 'common', '86', NULL, NULL),
	('disable', 'Stop', 'common', '44', NULL, NULL),
	('disable', '停用', 'common', '86', NULL, NULL),
	('display_color', 'Display Color', 'common', '44', NULL, NULL),
	('display_color', '显示颜色', 'common', '86', NULL, NULL),
	('display_displen', 'DispLen', 'common', '44', NULL, NULL),
	('display_displen', '数据显示长度', 'common', '86', NULL, NULL),
	('show_displen', 'Show dispLen', 'common', '44', NULL, NULL),
	('show_displen', '各屏分区数据显示长度', 'common', '86', NULL, NULL),
	('display_mode', 'Display mode', 'common', '44', NULL, NULL),
	('display_mode', '显示方式', 'common', '86', NULL, NULL),
	('dll_name', 'File Name of Dynamic Library', 'common', '44', NULL, NULL),
	('dll_name', '动态库文件名', 'common', '86', NULL, NULL),
	('do_not_modify_please_keep_is_empty', 'Please keep it as null if you do not edit.', 'common', '44', NULL, NULL),
	('do_not_modify_please_keep_is_empty', '不修改请保持为空', 'common', '86', NULL, NULL),
	('duration', 'Execution Time', 'common', '44', NULL, NULL),
	('duration', '执行时长', 'common', '86', NULL, NULL),
	('enable', 'Start', 'common', '44', NULL, NULL),
	('enable', '启用', 'common', '86', NULL, NULL),
	('end_time', 'End Time', 'common', '44', NULL, NULL),
	('end_time', '结束时间', 'common', '86', NULL, NULL),
	('enlargement', 'Zoom In', 'common', '44', NULL, NULL),
	('enlargement', '放大', 'common', '86', NULL, NULL),
	('execute_time', 'Execution Duration', 'common', '44', NULL, NULL),
	('execute_time', '执行时间', 'common', '86', NULL, NULL),
	('execution_day', 'Execution Date', 'common', '44', NULL, NULL),
	('execution_day', '执行日', 'common', '86', NULL, NULL),
	('export_excel', 'Export to Excel', 'common', '44', NULL, NULL),
	('export_excel', '导出excel', 'common', '86', NULL, NULL),
	('fault_judgment_interval', 'Fault judgment interval', 'common', '44', NULL, NULL),
	('fault_judgment_interval', '故障判定间隔时间', 'common', '86', NULL, NULL),
	('fault_judgment_num', 'Fault judgment number', 'common', '44', NULL, NULL),
	('fault_judgment_num', '故障判定次数', 'common', '86', NULL, NULL),
	('fault_monitoring', 'Malfunction Monitor', 'common', '44', NULL, NULL),
	('fault_monitoring', '故障监控', 'common', '86', NULL, NULL),
	('message_monitoring', 'Alarm centre', 'common', '44', NULL, NULL),
	('message_monitoring', '报警服务', 'common', '86', NULL, NULL),
	('fixed_parking', 'Fixed Space', 'common', '44', NULL, NULL),
	('fixed_parking', '固定车位', 'common', '86', NULL, NULL),
	('fold', 'Combine', 'common', '44', NULL, NULL),
	('fold', '合并', 'common', '86', NULL, NULL),
	('searchLoaction', 'Search Loaction', 'common', '44', NULL, NULL),
	('searchLoaction', '查看位置', 'common', '86', NULL, NULL),
	('setnum', 'Set Num', 'common', '44', NULL, NULL),
	('setnum', '设备编号', 'common', '86', NULL, NULL),
	('font_color', 'Font Color', 'common', '44', NULL, NULL),
	('font_color', '字体颜色', 'common', '86', NULL, NULL),
	('\\G', 'G', 'disp_color', '44', NULL, NULL),
	('graph', 'Graph', 'common', '44', NULL, NULL),
	('graph', '曲线图', 'common', '86', NULL, NULL),
	('greater_than', 'greater than', 'common', '44', NULL, NULL),
	('greater_than', '大于', 'common', '86', NULL, NULL),
	('green', 'green', 'font_color', '44', NULL, NULL),
	('green', '绿', 'font_color', '86', NULL, NULL),
	('guideregion_in_screenregion', 'The guideregion is in screenregion', 'common', '44', NULL, NULL),
	('guideregion_in_screenregion', '引导区在屏分区中有引用', 'common', '86', NULL, NULL),
	('guide_line_direction', 'Gudiance Direction', 'common', '44', NULL, NULL),
	('guide_line_direction', '引导方向', 'common', '86', NULL, NULL),
	('guide_regional', 'Guiding Zone', 'common', '44', NULL, NULL),
	('guide_regional', '引导区域', 'common', '86', NULL, NULL),
	('histogram', 'Bar Chart', 'common', '44', NULL, NULL),
	('histogram', '柱状图', 'common', '86', NULL, NULL),
	('holding_time', 'Occupied Time', 'common', '44', NULL, NULL),
	('holding_time', '占用时间', 'common', '86', NULL, NULL),
	('hour', 'Hour', 'common', '44', NULL, NULL),
	('hour', '小时', 'common', '86', NULL, NULL),
	('import_map', 'Input Map', 'common', '44', NULL, NULL),
	('import_map', '导入地图', 'common', '86', NULL, NULL),
	('import_map_data', 'Import Map Data', 'common', '44', NULL, NULL),
	('import_map_data', '导入地图数据', 'common', '86', NULL, NULL),
	('ini_file_save_error', 'Please check the setting of VMS,VMS guidance logic and ultrasonic sensors.', 'common', '44', NULL, NULL),
	('ini_file_save_error', '请检查引导屏、引导屏逻辑以及探测器配置是否正确', 'common', '86', NULL, NULL),
	('in_and_out_situation', 'Parking Rotation ', 'common', '44', NULL, NULL),
	('in_and_out_situation', '停车出入情况', 'common', '86', NULL, NULL),
	('in_and_out_situation_chart', 'Parking Rotation Chart', 'common', '44', NULL, NULL),
	('parking_in_detail', 'Parking In Detail', 'common', '44', NULL, NULL),
	('parking_in_detail', '停車出入明細表', 'common', '87', NULL, NULL),
	('parking_in_detail', '停车出入明细表', 'common', '86', NULL, NULL),
	('in_and_out_situation_chart', '停车出入图表', 'common', '86', NULL, NULL),
	('in_park', 'In', 'common', '44', NULL, NULL),
	('in_park', '进车', 'common', '86', NULL, NULL),
	('ip', 'IP', 'common', '86', NULL, NULL),
	('issued_config_file', 'Release Configuration Files', 'common', '44', NULL, NULL),
	('issued_config_file', '下发配置文件', 'common', '86', NULL, NULL),
	('language', 'Language', 'common', '44', NULL, NULL),
	('language', '语言', 'common', '86', NULL, NULL),
	('less_than', 'less than', 'common', '44', NULL, NULL),
	('less_than', '小于', 'common', '86', NULL, NULL),
	('line_addr', 'Line Address', 'common', '44', NULL, NULL),
	('line_addr', '线路地址', 'common', '86', NULL, NULL),
	('line_conf', 'Communication Line Configuration', 'common', '44', NULL, NULL),
	('line_conf', '通讯线路配置', 'common', '86', NULL, NULL),
	('line_name', 'line name', 'common', '44', NULL, NULL),
	('line_name', '线路名称', 'common', '86', NULL, NULL),
	('line_param_notes', 'Parameter Explanation', 'common', '44', NULL, NULL),
	('line_param_notes', '参数说明', 'common', '86', NULL, NULL),
	('linkman', 'Contact Person', 'common', '44', NULL, NULL),
	('linkman', '联系人', 'common', '86', NULL, NULL),
	('logic_area', 'Logic Zone', 'common', '44', NULL, NULL),
	('logic_area', '地理区域', 'common', '86', NULL, NULL),
	('logic_area_manage', 'Logic Zone Management', 'common', '44', NULL, NULL),
	('logic_area_manage', '地理区域管理', 'common', '86', NULL, NULL),
	('login', 'Login', 'common', '44', NULL, NULL),
	('login', '登录', 'common', '86', NULL, NULL),
	('login_title', 'Welcome to Use AKE Parking Guidance System', 'common', '44', NULL, NULL),
	('login_title', '欢迎使用艾科停车引导系统', 'common', '86', NULL, NULL),
	('Loop Dectector', 'Loop Dectector', 'common', '44', NULL, NULL),
	('malfun_equi', 'Malfunction Device', 'common', '44', NULL, NULL),
	('malfun_equi', '故障设备', 'common', '86', NULL, NULL),
	('manage', 'Manage', 'common', '44', NULL, NULL),
	('manage', '管理', 'common', '86', NULL, NULL),
	('map', 'Map', 'common', '44', NULL, NULL),
	('map', '地图', 'common', '86', NULL, NULL),
	('map_id', 'Map No.', 'common', '44', NULL, NULL),
	('map_id', '地图号', 'common', '86', NULL, NULL),
	('map_manage', 'Map Management', 'common', '44', NULL, NULL),
	('map_manage', '地图管理', 'common', '86', NULL, NULL),
	('map_monitoring', 'Map Monitor', 'common', '44', NULL, NULL),
	('map_monitoring', '地图监控', 'common', '86', NULL, NULL),
	('map_name', 'Map Name', 'common', '44', NULL, NULL),
	('map_name', '地图名', 'common', '86', NULL, NULL),
	('mask', 'Mask Off Code', 'common', '44', NULL, NULL),
	('mask', '掩码', 'common', '86', NULL, NULL),
	('max_detectors', 'Max Length', 'common', '44', NULL, NULL),
	('max_detectors', '最大探头数量', 'common', '86', NULL, NULL),
	('meter', 'm', 'common', '44', NULL, NULL),
	('meter', '米', 'common', '86', NULL, NULL),
	('minute', 'Minute', 'common', '44', NULL, NULL),
	('minute', '分钟', 'common', '86', NULL, NULL),
	('modify_content', 'Modify Content', 'common', '44', NULL, NULL),
	('modify_content', '修改内容', 'common', '86', NULL, NULL),
	('modify_password', 'Modify Password', 'common', '44', NULL, NULL),
	('modify_password', '修改密码', 'common', '86', NULL, NULL),
	('Modular Management', 'Modular Management', 'common', '44', NULL, NULL),
	('mokuai', 'mokuai', 'common', '44', NULL, NULL),
	('mokuai', '模块管理', 'common', '86', NULL, NULL),
	('monitoring_chart_summary', 'Graghic Table', 'common', '44', NULL, NULL),
	('monitoring_chart_summary', '监控图表汇总', 'common', '86', NULL, NULL),
	('month', 'Month', 'common', '44', NULL, NULL),
	('month', '月', 'common', '86', NULL, NULL),
	('month_day', 'Day/Month', 'common', '44', NULL, NULL),
	('month_day', '月/日', 'common', '86', NULL, NULL),
	('must_be_digital', 'It should be numbers.', 'common', '44', NULL, NULL),
	('must_be_digital', '必须是数字', 'common', '86', NULL, NULL),
	('name', 'Name', 'common', '44', NULL, NULL),
	('name', '名称', 'common', '86', NULL, NULL),
	('new_password', 'New Password', 'common', '44', NULL, NULL),
	('new_password', '新密码', 'common', '86', NULL, NULL),
	('new_value', 'New Value', 'common', '44', NULL, NULL),
	('new_value', '新值', 'common', '86', NULL, NULL),
	('next_step', 'Next', 'common', '44', NULL, NULL),
	('next_step', '下一步', 'common', '86', NULL, NULL),
	('not_configured', 'Not configured', 'common', '44', NULL, NULL),
	('not_configured', '未配置', 'common', '86', NULL, NULL),
	('now_time', 'Now', 'common', '44', NULL, NULL),
	('now_time', '当前时间', 'common', '86', NULL, NULL),
	('no_of_vehicle', 'No. of Vehicle', 'common', '44', NULL, NULL),
	('no_of_vehicle', '单位：辆', 'common', '86', NULL, NULL),
	('number', 'Number', 'common', '44', NULL, NULL),
	('number', '编号', 'common', '86', NULL, NULL),
	('num_length', 'Bit Length of Balance Space', 'common', '44', NULL, NULL),
	('num_length', '剩余车位数长度', 'common', '86', NULL, NULL),
	('occupancy_rate', 'Occupancy Rate', 'common', '44', NULL, NULL),
	('occupancy_rate', '占用率', 'common', '86', NULL, NULL),
	('occurrence_time', 'Occurrence Time', 'common', '44', NULL, NULL),
	('occurrence_time', '发生时间', 'common', '86', NULL, NULL),
	('old_password', 'Initial Password', 'common', '44', NULL, NULL),
	('old_password', '原密码', 'common', '86', NULL, NULL),
	('operate_time', 'Operatation Time', 'common', '44', NULL, NULL),
	('operate_time', '操作时间', 'common', '86', NULL, NULL),
	('operator', 'Issuer', 'common', '44', NULL, NULL),
	('operator', '发布人', 'common', '86', NULL, NULL),
	('operator_time', 'Release Time ', 'common', '44', NULL, NULL),
	('operator_time', '发布时间', 'common', '86', NULL, NULL),
	('optional_value', 'Optional Value', 'common', '44', NULL, NULL),
	('optional_value', '可选值', 'common', '86', NULL, NULL),
	('original_proportion', 'Initial', 'common', '44', NULL, NULL),
	('original_proportion', '原始', 'common', '86', NULL, NULL),
	('out_of_date', 'Out of date', 'common', '44', NULL, NULL),
	('out_of_date', '已过期', 'common', '86', NULL, NULL),
	('out_park', 'Out', 'common', '44', NULL, NULL),
	('out_park', '出车', 'common', '86', NULL, NULL),
	('page', 'Page', 'showmenu', '44', NULL, NULL),
	('page', '页', 'showmenu', '86', NULL, NULL),
	('para_conf', 'Parameter Setup', 'common', '44', NULL, NULL),
	('para_conf', '参数配置', 'common', '86', NULL, NULL),
	('parity', 'Check Bit', 'common', '44', NULL, NULL),
	('parity', '校验位', 'common', '86', NULL, NULL),
	('parking_duration', 'parking duration', 'common', '44', NULL, NULL),
	('parking_duration', '停车时长', 'common', '86', NULL, NULL),
	('parking_info_manage', 'Parking Information Maintenance', 'common', '44', NULL, NULL),
	('parking_info_manage', '停车场信息维护', 'common', '86', NULL, NULL),
	('parking_lot_map', 'Carpark Map', 'common', '44', NULL, NULL),
	('parking_lot_map', '停车场地图', 'common', '86', NULL, NULL),
	('parking_lot_number', 'Space Serial No.', 'common', '44', NULL, NULL),
	('parking_lot_number', '车位编号', 'common', '86', NULL, NULL),
	('parking_name', 'Carpark Name', 'common', '44', NULL, NULL),
	('parking_name', '停车场名称', 'common', '86', NULL, NULL),
	('parking_numbers', 'Space Number ', 'common', '44', NULL, NULL),
	('parking_numbers', '车位数', 'common', '86', NULL, NULL),
	('parking_occupancy_rate', 'Parking Occupancy Status', 'common', '44', NULL, NULL),
	('parking_occupancy_rate', '停车占有率情况', 'common', '86', NULL, NULL),
	('parking_occupancy_rate_chart', 'Parking Occupancy Chart', 'common', '44', NULL, NULL),
	('parking_occupancy_rate_chart', '停车占有率图表', 'common', '86', NULL, NULL),
	('parking_state', 'Space Status', 'common', '44', NULL, NULL),
	('parking_state', '车位状态', 'common', '86', NULL, NULL),
	('parking_total', 'Total Space ', 'common', '44', NULL, NULL),
	('parking_total', '车位总数', 'common', '86', NULL, NULL),
	('parking_type', 'Space Type', 'common', '44', NULL, NULL),
	('parking_type', '车位类型', 'common', '86', NULL, NULL),
	('parking_type_can\'t_for_empty', '车位类型不能为空', 'common', '86', NULL, NULL),
	('parking_type_cant_for_empty', 'Slot type cannot be Null.', 'common', '44', NULL, NULL),
	('parking_work_manage', 'Space Event Management', 'common', '44', NULL, NULL),
	('parking_work_manage', '车位作业管理', 'common', '86', NULL, NULL),
	('parking_work_plan', 'Space Event Plan', 'common', '44', NULL, NULL),
	('parking_work_plan', '车位作业计划', 'common', '86', NULL, NULL),
	('password', 'Password', 'common', '44', NULL, NULL),
	('password', '密码', 'common', '86', NULL, NULL),
	('password_different', 'The new passwords input are different.', 'common', '44', NULL, NULL),
	('password_different', '两次输入的新密码不相同', 'common', '86', NULL, NULL),
	('path', 'Route', 'common', '44', NULL, NULL),
	('path', '路径', 'common', '86', NULL, NULL),
	('phone', 'Contact Tel', 'common', '44', NULL, NULL),
	('phone', '联系电话', 'common', '86', NULL, NULL),
	('physical_area', 'Physical Region', 'common', '44', NULL, NULL),
	('physical_area', '物理区域', 'common', '86', NULL, NULL),
	('physical_area_code', 'Physical Region Code', 'common', '44', NULL, NULL),
	('physical_area_code', '物理区域编码', 'common', '86', NULL, NULL),
	('physical_area_config', 'Physical Region Configuration', 'common', '44', NULL, NULL),
	('physical_area_config', '物理区域配置', 'common', '86', NULL, NULL),
	('physical_area_name', 'Physical Region Name', 'common', '44', NULL, NULL),
	('physical_area_name', '物理区域名', 'common', '86', NULL, NULL),
	('pie_chart', 'Pie Chart', 'common', '44', NULL, NULL),
	('pie_chart', '饼图', 'common', '86', NULL, NULL),
	('plan_type', 'Event Type', 'common', '44', NULL, NULL),
	('plan_type', '计划类型', 'common', '86', NULL, NULL),
	('plan_work', 'Event Plan', 'common', '44', NULL, NULL),
	('plan_work', '计划作业', 'common', '86', NULL, NULL),
	('please_select', 'Please select', 'common', '44', NULL, NULL),
	('please_select', '请选择', 'common', '86', NULL, NULL),
	('port', 'Port', 'common', '44', NULL, NULL),
	('port', '端口', 'common', '86', NULL, NULL),
	('preview', 'Preview', 'common', '44', NULL, NULL),
	('preview', '预览', 'common', '86', NULL, NULL),
	('prev_step', 'Previous', 'common', '44', NULL, NULL),
	('prev_step', '上一步', 'common', '86', NULL, NULL),
	('print', 'Print', 'common', '44', NULL, NULL),
	('print', '打印', 'common', '86', NULL, NULL),
	('process_success', 'Operate it Successfully', 'common', '44', NULL, NULL),
	('process_success', '操作成功', 'common', '86', NULL, NULL),
	('purpose', 'Usage', 'common', '44', NULL, NULL),
	('purpose', '用途', 'common', '86', NULL, NULL),
	('\\R', 'R', 'disp_color', '44', NULL, NULL),
	('real_time_monitoring', 'Real-time Monintor', 'common', '44', NULL, NULL),
	('real_time_monitoring', '实时监控', 'common', '86', NULL, NULL),
	('record', 'Item', 'showmenu', '44', NULL, NULL),
	('record', '条', 'showmenu', '86', NULL, NULL),
	('red', 'red', 'font_color', '44', NULL, NULL),
	('red', '红', 'font_color', '86', NULL, NULL),
	('reduction', 'Zoom Out', 'common', '44', NULL, NULL),
	('reduction', '缩小', 'common', '86', NULL, NULL),
	('refresh_time', 'Refresh Time', 'common', '44', NULL, NULL),
	('refresh_time', '地感更新时间', 'common', '86', NULL, NULL),
	('register', 'Register', 'common', '44', NULL, NULL),
	('register', '注册', 'common', '86', NULL, NULL),
	('registered', 'Registered', 'common', '44', NULL, NULL),
	('registered', '已注册', 'common', '86', NULL, NULL),
	('remark', 'Remark', 'common', '44', NULL, NULL),
	('remark', '备注', 'common', '86', NULL, NULL),
	('remember', 'Remember', 'common', '44', NULL, NULL),
	('remember', '记住', 'common', '86', NULL, NULL),
	('reservation_parking', 'Reserved Space', 'common', '44', NULL, NULL),
	('reservation_parking', '预定车位', 'common', '86', NULL, NULL),
	('reset', 'Reset', 'common', '44', NULL, NULL),
	('reset', '重置', 'common', '86', NULL, NULL),
	('role', 'Authority', 'common', '44', NULL, NULL),
	('role', '权限', 'common', '86', NULL, NULL),
	('role_manage', 'Authority Management', 'common', '44', NULL, NULL),
	('role_manage', '权限管理', 'common', '86', NULL, NULL),
	('role_name', 'Authority Name', 'common', '44', NULL, NULL),
	('role_name', '权限名称', 'common', '86', NULL, NULL),
	('role_user', 'Authority User', 'common', '44', NULL, NULL),
	('role_user', '权限用户', 'common', '86', NULL, NULL),
	('runstate', 'Event Executing Status', 'common', '44', NULL, NULL),
	('runstate', '任务执行状态', 'common', '86', NULL, NULL),
	('screen', 'VMS', 'map_dtype', '44', NULL, NULL),
	('screen', '引导屏', 'map_dtype', '86', NULL, NULL),
	('screenparavalue_conf', ' Configure VMS Parameter', 'common', '44', NULL, NULL),
	('screenparavalue_conf', '屏参数值配置', 'common', '86', NULL, NULL),
	('screenparavalue_manage', 'Manage VMS Parameter', 'common', '44', NULL, NULL),
	('screenparavalue_manage', '屏参数值管理', 'common', '86', NULL, NULL),
	('screentypepara_conf', 'VMS Parameter Setup', 'common', '44', NULL, NULL),
	('screentypepara_conf', '屏类型参数配置', 'common', '86', NULL, NULL),
	('screentypepara_name', 'VMS Type and Parameter ', 'common', '44', NULL, NULL),
	('screentypepara_name', '屏类型参数名称', 'common', '86', NULL, NULL),
	('screentype_manage', 'Manage VMS Type ', 'common', '44', NULL, NULL),
	('screentype_manage', '屏类型管理', 'common', '86', NULL, NULL),
	('screen_address', 'VMS Address', 'common', '44', NULL, NULL),
	('screen_address', '引导屏地址', 'common', '86', NULL, NULL),
	('screen_code', 'VMS Code', 'common', '44', NULL, NULL),
	('screen_code', '引导屏编码', 'common', '86', NULL, NULL),
	('screen_conf', 'VMS Configuration', 'common', '44', NULL, NULL),
	('screen_conf', '引导屏配置', 'common', '86', NULL, NULL),
	('screen_group_address', 'VMS Group ID', 'common', '44', NULL, NULL),
	('screen_group_address', '引导屏组地址', 'common', '86', NULL, NULL),
	('screen_id', 'VMS No.', 'common', '44', NULL, NULL),
	('screen_id', '引导屏编号', 'common', '86', NULL, NULL),
	('screen_logic', 'VMS Logic', 'common', '44', NULL, NULL),
	('screen_logic', '引导屏逻辑', 'common', '86', NULL, NULL),
	('screen_logic_not_set', 'The VMS guiding logic is not set.', 'common', '44', NULL, NULL),
	('screen_logic_not_set', '引导屏逻辑没有进行设置', 'common', '86', NULL, NULL),
	('screen_manage', 'Manage Guiding Zone', 'common', '44', NULL, NULL),
	('screen_manage', '引导区域管理', 'common', '86', NULL, NULL),
	('screen_numbers', 'Q\'y of VMS', 'common', '44', NULL, NULL),
	('screen_numbers', '屏数', 'common', '86', NULL, NULL),
	('screen_paravalue_not_enough', 'VMS parameter has not been set completely.', 'common', '44', NULL, NULL),
	('screen_paravalue_not_enough', '屏参数值配置不全', 'common', '86', NULL, NULL),
	('screen_status', 'VMS Status', 'common', '44', NULL, NULL),
	('screen_status', '引导屏状态', 'common', '86', NULL, NULL),
	('screen_the_contents', 'Current VMS Content', 'common', '44', NULL, NULL),
	('screen_the_contents', '引导屏当前内容', 'common', '86', NULL, NULL),
	('screen_type', 'VMS Type', 'common', '44', NULL, NULL),
	('screen_type', '引导屏类型', 'common', '86', NULL, NULL),
	('screen_work_manage', 'VMS Event Management', 'common', '44', NULL, NULL),
	('screen_work_manage', '引导屏作业管理', 'common', '86', NULL, NULL),
	('screen_work_plan', 'VMS Event Plan', 'common', '44', NULL, NULL),
	('screen_work_plan', '引导屏作业计划', 'common', '86', NULL, NULL),
	('second', 'second', 'common', '44', NULL, NULL),
	('second', '秒', 'common', '86', NULL, NULL),
	('select_all', 'Select All', 'common', '44', NULL, NULL),
	('select_all', '全选', 'common', '86', NULL, NULL),
	('serial_number', 'Serial No', 'common', '44', NULL, NULL),
	('serial_number', '序列号', 'common', '86', NULL, NULL),
	('serial_port', 'Port Number', 'common', '44', NULL, NULL),
	('serial_port', '端口号', 'common', '86', NULL, NULL),
	('set', 'Setup', 'common', '44', NULL, NULL),
	('set', '设置', 'common', '86', NULL, NULL),
	('set_stop_color', 'Set the stop time dynamic color', 'common', '44', NULL, NULL),
	('set_stop_color', '设置停车时长的动态颜色', 'common', '86', NULL, NULL),
	('sort', 'Order', 'common', '44', NULL, NULL),
	('sort', '顺序', 'common', '86', NULL, NULL),
	('spacing_interval', 'Spacing Interval', 'common', '44', NULL, NULL),
	('spacing_interval', '间隔时间', 'common', '86', NULL, NULL),
	('start_time', 'Start Time', 'common', '44', NULL, NULL),
	('start_time', '开始时间', 'common', '86', NULL, NULL),
	('state_time', 'State Time', 'common', '44', NULL, NULL),
	('state_time', '通讯程序状态时间', 'common', '86', NULL, NULL),
	('station_addr', 'Local Address', 'common', '44', NULL, NULL),
	('station_addr', '本地地址', 'common', '86', NULL, NULL),
	('statistical_statement', 'Statistic Report', 'common', '44', NULL, NULL),
	('statistical_statement', '统计报表', 'common', '86', NULL, NULL),
	('query_machine_usage', 'Query Machine Usage', 'common', '44', NULL, NULL),
	('query_machine_usage', '查询机使用情况', 'common', '86', NULL, NULL),
	('query_machine_usage', '查詢機使用情況', 'common', '87', NULL, NULL),
	('searchByMachine', 'Search By Machine', 'common', '44', NULL, NULL),
	('searchByMachine', '按查询机', 'common', '86', NULL, NULL),
	('searchByMachine', '按查詢機', 'common', '87', NULL, NULL),
	('searchByMethod', 'Search By Method', 'common', '44', NULL, NULL),
	('searchByMethod', '按查询方式', 'common', '86', NULL, NULL),
	('searchByMethod', '按查詢方式', 'common', '87', NULL, NULL),
	('status', 'Status', 'common', '44', NULL, NULL),
	('status', '状态', 'common', '86', NULL, NULL),
	('stop_bits', 'Stop Bit', 'common', '44', NULL, NULL),
	('stop_bits', '停止位', 'common', '86', NULL, NULL),
	('storage_type', 'Storage Type ', 'common', '44', NULL, NULL),
	('storage_type', '存储类型', 'common', '86', NULL, NULL),
	('success', 'Successfully?', 'common', '44', NULL, NULL),
	('success', '是否成功', 'common', '86', NULL, NULL),
	('sys_manage', 'System Management', 'common', '44', NULL, NULL),
	('sys_manage', '系统管理', 'common', '86', NULL, NULL),
	('take_up', 'Occupied', 'common', '44', NULL, NULL),
	('take_up', '占用', 'common', '86', NULL, NULL),
	('task_running', 'Event is executing.', 'common', '44', NULL, NULL),
	('task_running', '任务正在执行中', 'common', '86', NULL, NULL),
	('temporary_parking', 'Temporary Space', 'common', '44', NULL, NULL),
	('temporary_parking', '临时车位', 'common', '86', NULL, NULL),
	('temporary_parking_space', 'Temporarily Park', 'common', '44', NULL, NULL),
	('temporary_parking_space', '临时停车', 'common', '86', NULL, NULL),
	('the_rest', 'Balance', 'common', '44', NULL, NULL),
	('the_rest', '剩余', 'common', '86', NULL, NULL),
	('time', 'Time', 'common', '44', NULL, NULL),
	('time', '时间', 'common', '86', NULL, NULL),
	('timeout_monitoring', 'Over Time Monitor', 'common', '44', NULL, NULL),
	('timeout_monitoring', '超时监控', 'common', '86', NULL, NULL),
	('time_out', 'Over Time', 'common', '44', NULL, NULL),
	('time_out', '超时时间', 'common', '86', NULL, NULL),
	('time_out_target', 'Overdue Index', 'common', '44', NULL, NULL),
	('time_out_target', '逾时指标', 'common', '86', NULL, NULL),
	('to', 'To', 'common', '44', NULL, NULL),
	('to', '到', 'common', '86', NULL, NULL),
	('total', 'Amount', 'common', '44', NULL, NULL),
	('total', '总数', 'common', '86', NULL, NULL),
	('total', 'Total', 'showmenu', '44', NULL, NULL),
	('total', '共', 'showmenu', '86', NULL, NULL),
	('turn_to', 'Turn to', 'common', '44', NULL, NULL),
	('turn_to', '转到', 'common', '86', NULL, NULL),
	('type', 'Type', 'common', '44', NULL, NULL),
	('type', '类型', 'common', '86', NULL, NULL),
	('Ultrasonic Detector', 'Ultrasonic Detector', 'common', '44', NULL, NULL),
	('unchecked', 'Unselect', 'common', '44', NULL, NULL),
	('unchecked', '未选中', 'common', '86', NULL, NULL),
	('unfold', 'Spread', 'common', '44', NULL, NULL),
	('unfold', '展开', 'common', '86', NULL, NULL),
	('unit', 'Unit', 'common', '44', NULL, NULL),
	('unit', '单位', 'common', '86', NULL, NULL),
	('unregistered', 'Unregistered', 'common', '44', NULL, NULL),
	('unregistered', '未注册', 'common', '86', NULL, NULL),
	('unselect_all', 'Unselect All', 'common', '44', NULL, NULL),
	('unselect_all', '全不选', 'common', '86', NULL, NULL),
	('user_manage', 'User Management', 'common', '44', NULL, NULL),
	('user_manage', '用户管理', 'common', '86', NULL, NULL),
	('user_name', 'User Name', 'common', '44', NULL, NULL),
	('user_name', '用户名', 'common', '86', NULL, NULL),
	('user_status', 'User Status', 'common', '44', NULL, NULL),
	('user_status', '用户状态', 'common', '86', NULL, NULL),
	('use_color', 'use color', 'common', '44', NULL, NULL),
	('use_color', '启用动态颜色', 'common', '86', NULL, NULL),
	('use_default', 'Use Default ', 'common', '44', NULL, NULL),
	('use_default', '使用默认值', 'common', '86', NULL, NULL),
	('valid_until', 'valid until', 'common', '44', NULL, NULL),
	('valid_until', '有效期至', 'common', '86', NULL, NULL),
	('value', 'Value', 'common', '44', NULL, NULL),
	('value', '值', 'common', '86', NULL, NULL),
	('\\Y', 'Y', 'disp_color', '44', NULL, NULL),
	('year', 'Year', 'common', '44', NULL, NULL),
	('year', '年', 'common', '86', NULL, NULL),
	('yellow', 'yellow', 'font_color', '44', NULL, NULL),
	('yellow', '黄', 'font_color', '86', NULL, NULL),
	('yes_or_no_enable', 'Open/Stop', 'common', '44', NULL, NULL),
	('yes_or_no_enable', '更改状态', 'common', '86', NULL, NULL),
	('ZC Management', 'ZC Management', 'common', '44', NULL, NULL),
	('\\G', '绿色', 'disp_color', '86', NULL, NULL),
	('\\R', '红色', 'disp_color', '86', NULL, NULL),
	('\\Y', '黄色', 'disp_color', '86', NULL, NULL),

	('screenparavalue_temp', 'Manage VMS Template', 'common', '44', NULL, NULL),
	('screenparavalue_temp', '屏参数值模板管理', 'common', '86', NULL, NULL),
	('screenparavalue_temp_detail', 'Manage VMS Template Detail', 'common', '44', NULL, NULL),
	('screenparavalue_temp_detail', '屏参数值模板明细管理', 'common', '86', NULL, NULL),
	('screenparavaluetemplate', 'Screen Parameter Template', 'common', '44', NULL, NULL),
	('screenparavaluetemplate', '屏参数值模板', 'common', '86', NULL, NULL),
	('templatename', 'templatename', 'common', '44', NULL, NULL),
	('templatename', '模板名称', 'common', '86', NULL, NULL),
	('alert_templatename_already_exists', 'TemplateName already exists. Please modify', 'common', '44', NULL, NULL),
	('alert_templatename_already_exists', '模板名称已经存在,请修改', 'common', '86', NULL, NULL),
	('show_detail', 'Show detail', 'common', '44', NULL, NULL),
	('show_detail', '显示明细', 'common', '86', NULL, NULL),
	('switch_gap', 'Switch gap', 'common', '44', NULL, NULL),
	('switch_gap', '切换间隔', 'common', '86', NULL, NULL),
	('0', 'Per Week', 'screen_task_type', '44', NULL, NULL),
	('0', '每周', 'screen_task_type', '86', NULL, NULL),
    ('1', 'Single', 'screen_task_type', '44', NULL, NULL),
	('1', '单次', 'screen_task_type', '86', NULL, NULL),
    ('2', 'Immediately', 'screen_task_type', '44', NULL, NULL),
	('2', '立即', 'screen_task_type', '86', NULL, NULL),
	('3', 'Switch view', 'screen_task_type', '44', NULL, NULL),
	('3', '切换显示', 'screen_task_type', '86', NULL, NULL),
	('4', 'Carport Protect', 'screen_task_type', '44', NULL, NULL),
	('4', '车位保护', 'screen_task_type', '86', NULL, NULL),
	('reapply_template', 'Reapply', 'common', '44', NULL, NULL),
	('reapply_template', '重新应用', 'common', '86', NULL, NULL),
	('alert_reapply_template_prompt', 'This operation will override the related screen parameter values.', 'common', '44', NULL, NULL),
	('alert_reapply_template_prompt', '此操作将覆盖相关联显示屏的参数值！', 'common', '86', NULL, NULL),
	('btn_terminate', 'Terminate', 'common', '44', NULL, NULL),
	('btn_terminate', '终止', 'common', '86', NULL, NULL),
	('alert_terminate', 'Are you sure to terminate this task?', 'common', '44', NULL, NULL),
	('alert_terminate', '您确定要终止此项任务吗', 'common', '86', NULL, NULL),
	('00', 'LeftMove', 'move', '44', NULL, NULL),
	('00', '左移', 'move', '86', NULL, NULL),
	('01', 'UpMove', 'move', '44', NULL, NULL),
	('01', '上移', 'move', '86', NULL, NULL),
	('02', 'DownPull', 'move', '44', NULL, NULL),
	('02', '下拉', 'move', '86', NULL, NULL),
	('03', 'UpPull', 'move', '44', NULL, NULL),
	('03', '上拉', 'move', '86', NULL, NULL),
	('04', 'StaticView', 'move', '44', NULL, NULL),
	('04', '即显', 'move', '86', NULL, NULL),
	('05', 'DynamicArrows', 'move', '44', NULL, NULL),
	('05', '动态箭头', 'move', '86', NULL, NULL),
	('moveSpeed', 'Moving speed', 'common', '44', NULL, NULL),
	('moveSpeed', '移动速度', 'common', '86', NULL, NULL),
	('moveWidth', 'View width', 'common', '44', NULL, NULL),
	('moveWidth', '显示宽度', 'common', '86', NULL, NULL),
	('Color_change_tactics', 'Color change tactics', 'common', '44', NULL, NULL),
    ('Color_change_tactics', '变色策略设置', 'common', '86', NULL, NULL),
    ('red_count', 'Red critical by count', 'common', '44', NULL, NULL),
    ('red_count', '变红色临界', 'common', '86', NULL, NULL),
    ('yellow_percent', 'Yellow critical by percent', 'common', '44', NULL, NULL),
    ('yellow_percent', '变黄色临界百分比', 'common', '86', NULL, NULL),
    ('create_color_task', 'Release Color Change Tactics', 'common', '44', NULL, NULL),
	('create_color_task', '下发变色策略', 'common', '86', NULL, NULL),
	('color_task_history', 'Release Event History', 'common', '44', NULL, NULL),
	('color_task_history', '下发历史查询', 'common', '86', NULL, NULL),
	('check_color_task', 'Release Event Check', 'common', '44', NULL, NULL),
	('check_color_task', '当前任务查看', 'common', '86', NULL, NULL),
	('exitscreen_carport_num', 'Exitscreen Carport Num', 'common', '44', NULL, NULL),
	('exitscreen_carport_num', '出口屏保护临界值', 'common', '86', NULL, NULL),
	('exitscreen_carport_num_explain', 'When exitscreen carport num less than the specified num,the exitscreen will show the specified content.', 'common', '44', NULL, NULL),
	('exitscreen_carport_num_explain', '出口屏车位数小于指定数时，出口屏将显示指定的内容', 'common', '86', NULL, NULL),
	('exitscreen_content', 'Exitscreen Content', 'common', '44', NULL, NULL),
	('exitscreen_content', '出口屏保护内容', 'common', '86', NULL, NULL),
	('is_exit_screen', 'Exit', 'common', '44', NULL, NULL),
	('is_exit_screen', '出入口', 'common', '86', NULL, NULL),
	('notice_way', 'Notice way', 'common', '44', NULL, NULL),
	('notice_way', '通知方式', 'common', '86', NULL, NULL),
	('mobile_phone', 'Mobile phone', 'common', '44', NULL, NULL),
	('mobile_phone', '手机号码', 'common', '86', NULL, NULL),
	('1', 'SMS cat', 'notice_way', '44', NULL, NULL),
	('1', '短信猫', 'notice_way', '86', NULL, NULL),
	('2', 'Web supplier', 'notice_way', '44', NULL, NULL),
	('2', '网络服务商', 'notice_way', '86', NULL, NULL),
	('1', 'Controller', 'device_object', '44', NULL, NULL),
	('1', '管理器', 'device_object', '86', NULL, NULL),
	('2', 'Screen', 'device_object', '44', NULL, NULL),
	('2', '条屏', 'device_object', '86', NULL, NULL),
	('3', 'Detector', 'device_object', '44', NULL, NULL),
	('3', '探测器', 'device_object', '86', NULL, NULL),
	('is_need_send', 'Need send', 'common', '44', NULL, NULL),
	('is_need_send', '需发送', 'common', '86', NULL, NULL),
	('is_already_send', 'Already send', 'common', '44', NULL, NULL),
	('is_already_send', '已发送', 'common', '86', NULL, NULL),
	('device_code', 'Device code', 'common', '44', NULL, NULL),
	('device_code', '设备编码', 'common', '86', NULL, NULL),
	
	('Custom_debug_task', 'Custom debug task', 'common', '44', NULL, NULL),
    ('Custom_debug_task', '自定义调试任务', 'common', '86', NULL, NULL),
    ('define_debug_task', 'define debug task', 'common', '44', NULL, NULL),
    ('define_debug_task', '定义调试任务', 'common', '86', NULL, NULL),
    ('create_debug_task', 'Release Task', 'common', '44', NULL, NULL),
	('create_debug_task', '下发任务', 'common', '86', NULL, NULL),
    ('taskname', 'taskname', 'common', '44', NULL, NULL),
    ('taskname', '任务名称', 'common', '86', NULL, NULL),
    ('sendcontent', 'sendcontent', 'common', '44', NULL, NULL),
    ('sendcontent', '发送内容', 'common', '86', NULL, NULL),
    ('expectreturn', 'expectreturn', 'common', '44', NULL, NULL),
    ('expectreturn', '期待返回', 'common', '86', NULL, NULL),
    ('realreturn', 'realreturn', 'common', '44', NULL, NULL),
    ('realreturn', '实际返回', 'common', '86', NULL, NULL),
    ('funcode', 'funcode', 'common', '44', NULL, NULL),
    ('funcode', '功能码', 'common', '86', NULL, NULL),
    ('senddata1', 'SD1', 'common', '44', NULL, NULL),
    ('senddata1', 'SD1', 'common', '86', NULL, NULL),
    ('senddata2', 'SD2', 'common', '44', NULL, NULL),
    ('senddata2', 'SD2', 'common', '86', NULL, NULL),
    ('senddata3', 'SD3', 'common', '44', NULL, NULL),
    ('senddata3', 'SD3', 'common', '86', NULL, NULL),
    ('senddata4', 'SD4', 'common', '44', NULL, NULL),
    ('senddata4', 'SD4', 'common', '86', NULL, NULL),
    ('senddata5', 'SD5', 'common', '44', NULL, NULL),
    ('senddata5', 'SD5', 'common', '86', NULL, NULL),
    ('senddata6', 'SD6', 'common', '44', NULL, NULL),
    ('senddata6', 'SD6', 'common', '86', NULL, NULL),
    ('senddata7', 'SD7', 'common', '44', NULL, NULL),
    ('senddata7', 'SD7', 'common', '86', NULL, NULL),
    ('senddata8', 'SD8', 'common', '44', NULL, NULL),
    ('senddata8', 'SD8', 'common', '86', NULL, NULL), 
    ('returndata1', 'RD1', 'common', '44', NULL, NULL),
    ('returndata1', 'RD1', 'common', '86', NULL, NULL),
    ('returndata2', 'RD2', 'common', '44', NULL, NULL),
    ('returndata2', 'RD2', 'common', '86', NULL, NULL),
    ('returndata3', 'RD3', 'common', '44', NULL, NULL),
    ('returndata3', 'RD3', 'common', '86', NULL, NULL),
    ('returndata4', 'RD4', 'common', '44', NULL, NULL),
    ('returndata4', 'RD4', 'common', '86', NULL, NULL),
    ('returndata5', 'RD5', 'common', '44', NULL, NULL),
    ('returndata5', 'RD5', 'common', '86', NULL, NULL),
    ('returndata6', 'RD6', 'common', '44', NULL, NULL),
    ('returndata6', 'RD6', 'common', '86', NULL, NULL),
    ('returndata7', 'RD7', 'common', '44', NULL, NULL),
    ('returndata7', 'RD7', 'common', '86', NULL, NULL),
    ('returndata8', 'RD8', 'common', '44', NULL, NULL),
    ('returndata8', 'RD8', 'common', '86', NULL, NULL),
    ('todefault', 'ToDefault', 'common', '44', NULL, NULL),
    ('todefault', '初始化', 'common', '86', NULL, NULL),
    ('ifexpireBecomeRedState', 'If expired the lights become red', 'common', '44', NULL, NULL),
    ('ifexpireBecomeRedState', '软件到期车位灯显示红色', 'common', '86', NULL, NULL),
    
    	

  ('logical_parking_occupancy_rate', 'Logical Parking Occupancy Status', 'common', '44', NULL, NULL),
  ('logical_parking_occupancy_rate', '地理区域占有率', 'common', '86', NULL, NULL),
  ('btn_add_detector', 'Add Detector', 'common', '44', NULL, NULL),
  ('btn_add_detector', '新增探测器', 'common', '86', NULL, NULL),
  ('run', 'Run', 'common', '44', NULL, NULL),
  ('run', '运行', 'common', '86', NULL, NULL),
  ('from', 'From', 'common', '44', NULL, NULL),
  ('from', '从', 'common', '86', NULL, NULL),
  ('batch', 'Batch', 'common', '44', NULL, NULL),
  ('batch', '批量', 'common', '86', NULL, NULL),
  ('restart', 'Restart', 'common', '44', NULL, NULL),
  ('restart', '重启', 'common', '86', NULL, NULL),
  ('alert_restart_pgsserver', 'Please restart pgsServer.exe or pgsServer Service', 'common', '44', NULL, NULL),
  ('alert_restart_pgsserver', '请重启 pgsServer.exe或 pgsServer服务', 'common', '86', NULL, NULL),
  ('update_map', 'Update Map', 'common', '44', NULL, NULL),
  ('update_map', '更新地图', 'common', '86', NULL, NULL),
  ('wizard_description', 'The wizard\'s function is testing and importing basic data of map, replacing the manual entry of trouble, but also can ensure the accuracy of the data. Basic data includes the following several parts:', 'common', '44', NULL, NULL),
  ('wizard_description', '地图数据导入功能主要是批量检测和导入地图文件的基础数据，免去手工录入的麻烦，同时也可确保数据的准确性。导入前最好备份一下数据库，地图制作模板可通过点击右下角按钮下载获得。基础数据主要包含以下几部分：', 'common', '86', NULL, NULL),
  ('wizard_description_1', 'The initialization wizard\'s function is mainly:', 'common', '44', NULL, NULL),
  ('wizard_description_1', '地图数据初始化向导主要工作：', 'common', '86', NULL, NULL),
  ('wizard_description_2', '1.Select the data option', 'common', '44', NULL, NULL),
  ('wizard_description_2', '1.选择导入数据选项', 'common', '86', NULL, NULL),
  ('wizard_description_3', '2.Validate the map data', 'common', '44', NULL, NULL),
  ('wizard_description_3', '2.验证导入数据', 'common', '86', NULL, NULL),
  ('init_wizard_description', 'Initialization Wizard Description', 'common', '44', NULL, NULL),
  ('init_wizard_description', '初始化向导说明', 'common', '86', NULL, NULL),
  ('validate_results', 'Validate Results', 'common', '44', NULL, NULL),
  ('validate_results', '数据验证结果', 'common', '86', NULL, NULL),
  ('download_template', 'Download Map Template', 'common', '44', NULL, NULL),
  ('download_template', '下载地图制作模板', 'common', '86', NULL, NULL),
  ('process_failed', 'Operate it Failed', 'common', '44', NULL, NULL),
  ('process_failed', '操作失败', 'common', '86', NULL, NULL),
  ('alert_upload_file_type_error', 'Your uploadfile type is wrong,please select again', 'common', '44', NULL, NULL),
  ('alert_upload_file_type_error', '上传文件类型错误', 'common', '86', NULL, NULL),
  ('alert_select_parkingspace_or_screen', 'Please select parkingspaces or screens', 'common', '44', NULL, NULL),
  ('alert_select_parkingspace_or_screen', '请选择车位或者引导屏来操作', 'common', '86', NULL, NULL),
  ('data_backup', 'Data Backup', 'common', '44', NULL, NULL),
  ('data_backup', '数据备份', 'common', '86', NULL, NULL),
  ('data_recovery', 'Data Recovery', 'common', '44', NULL, NULL),
  ('data_recovery', '数据恢复', 'common', '86', NULL, NULL),
  ('device_state', 'Device State', 'common', '44', NULL, NULL),
  ('device_state', '设备状态', 'common', '86', NULL, NULL),
  ('pgs_service_management', 'PGS Service Management', 'common', '44', NULL, NULL),
  ('pgs_service_management', 'PGS服务管理', 'common', '86', NULL, NULL),
  ('config_file_manage', 'Config File Manage', 'common', '44', NULL, NULL),
  ('config_file_manage', '后台配置文件管理', 'common', '86', NULL, NULL),
  ('config_file_manage', '後台配置文件管理', 'common', '87', NULL, NULL),
  ('occupancy_rate_formula', 'Occupancy Rate = total parking time/(parkingspace number * total time)', 'common', '44', NULL, NULL),
  ('occupancy_rate_formula', '占有率=车位占用时间/(车位数*总时间)', 'common', '86', NULL, NULL),
  
  ('refresh', '刷新', 'common', '86', NULL, NULL),
  ('refresh', 'Refresh', 'common', '44', NULL, NULL),
  
  ('font', '00=16*16,01=32*32,02=24*24', 'screenparades', '44', NULL, NULL),
  ('font', '00为16*16字体，01为32*32字体，02为24*24字体', 'screenparades', '86', NULL, NULL),
  ('Inout', '00=move left,01=move up,02=move down,03=pull up,04=static,05=dynamic arrow', 'screenparades', '44', NULL, NULL),
  ('Inout', '00为左移，01为上移，02为下拉，03为上拉，04为静止，05为动态箭头', 'screenparades', '86', NULL, NULL),
  ('Move', 'HEX rang from 00 to C8', 'screenparades', '44', NULL, NULL),
  ('Move', '16进制00—C8之间取值', 'screenparades', '86', NULL, NULL),
  ('Append', '01=clear srceen before,02=clear screen after,04=availible,08=not show', 'screenparades', '44', NULL, NULL),
  ('Append', '01显示本屏前清屏，02显示本屏后清屏，04为引出方式有效，08为本屏内容不显示', 'screenparades', '86', NULL, NULL),
  ('Led_h', '01 or 02', 'screenparades', '44', NULL, NULL),
  ('Led_h', '01或02', 'screenparades', '86', NULL, NULL),
  ('Led_w', 'Max is 30,usually is 08 or 12 or 18', 'screenparades', '44', NULL, NULL),
  ('Led_w', '最大为16进制30，常用值为08、12、18', 'screenparades', '86', NULL, NULL),
  ('light', 'Hex rang from 00 to 14,00 and 14 is brightest,01 is darkest', 'screenparades', '44', NULL, NULL),
  ('light', '16进制00—14，14和00最亮，01最暗', 'screenparades', '86', NULL, NULL),
  ('Mode', '00=1/16A,01=1/16B,02=1/8,03=1/4A,04=1/4B,05=1/4C,06=1/4D', 'screenparades', '44', NULL, NULL),
  ('Mode', '00为1/16A模式，01为1/16B模式，02为1/8模式，03为1/4A模式，04为1/4B模式，05为1/4C模式，06为1/4D模式', 'screenparades', '86', NULL, NULL),
  ('Pause', 'Hex rang from 00 to 14', 'screenparades', '44', NULL, NULL),
  ('Pause', '16进制00—14取值', 'screenparades', '86', NULL, NULL),
  ('Reverse', '00=Unreverse,11=Reverse', 'screenparades', '44', NULL, NULL),
  ('Reverse', '第一位为使能反向，1代表使能，0代表不使能；第二位为反色显示，1代表反色，0代表不反色', 'screenparades', '86', NULL, NULL),
  ('X_offset', 'the number of offset points on X', 'screenparades', '44', NULL, NULL),
  ('X_offset', '引导屏X轴方向偏移的点数', 'screenparades', '86', NULL, NULL),
  ('Y_offset', 'the number of offset points on Y', 'screenparades', '44', NULL, NULL),
  ('Y_offset', '引导屏Y轴方向偏移的点数', 'screenparades', '86', NULL, NULL),
  ('specialsymbol', 'Sepcial Symbol', 'common', '44', NULL, NULL),
  ('specialsymbol', '特殊符号', 'common', '86', NULL, NULL),
  ('disabledtitle', 'Disabled Symbol', 'common', '44', NULL, NULL),
  ('disabledtitle', '残疾人标识', 'common', '86', NULL, NULL),
  ('showcha', 'X Symbol', 'common', '44', NULL, NULL),
  ('showcha', '叉叉标识', 'common', '86', NULL, NULL),
  ('fullscreen', 'Full Screen Light', 'common', '44', NULL, NULL),
  ('fullscreen', '全屏亮标识', 'common', '86', NULL, NULL),
  ('coderepeat', '编码重复', 'common', '86', NULL, NULL),
  ('coderepeat', 'Repeat Code', 'common', '44', NULL, NULL),
  ('mapPath', '地图图片路径', 'common', '86', NULL, NULL),
  ('mapPath', 'Map path', 'common', '44', NULL, NULL),
  ('mapPath', '地圖圖片路徑', 'common', '87', NULL, NULL),
  ('codeerror', '编码错误', 'common', '86', NULL, NULL),
  ('codeerror', 'Error Code', 'common', '44', NULL, NULL),
  ('dbcoderepeat', '数据库重复', 'common', '86', NULL, NULL),
  ('dbcoderepeat', 'DB Repeat', 'common', '44', NULL, NULL),
  ('screens', '屏编码组合', 'common', '86', NULL, NULL),
  ('screens', 'Led Codes', 'common', '44', NULL, NULL),
  ('colorvalues', '变色值组合', 'common', '86', NULL, NULL),
  ('colorvalues', 'Color Values', 'common', '44', NULL, NULL),
  ('logic_use_chart', '地理区域图表', 'common', '86', NULL, NULL),
  ('logic_use_chart', 'Logic Use Chart', 'common', '44', NULL, NULL),
  ('ucerror', '超声波错误', 'common', '86', NULL, NULL),
  ('ucerror', 'UC Error', 'common', '44', NULL, NULL),
  ('system_remote_update', '系统升级', 'common', '86', NULL, NULL),
  ('system_remote_update', 'System Update', 'common', '44', NULL, NULL),
  ('software_version_update', '软件版本更新', 'common', '86', NULL, NULL),
  ('software_version_update', 'Software Update', 'common', '44', NULL, NULL),
  ('update_name', '系统名称', 'common', '86', NULL, NULL),
  ('update_name', 'Sys Name', 'common', '44', NULL, NULL),
  ('update_code', '系统编码', 'common', '86', NULL, NULL),
  ('update_code', 'Sys Code', 'common', '44', NULL, NULL),
  ('update_currentVer', '当前版本', 'common', '86', NULL, NULL),
  ('update_currentVer', 'Current Ver', 'common', '44', NULL, NULL),
  ('update_waitingVer', '待更新版本', 'common', '86', NULL, NULL),
  ('update_waitingVer', 'Available Ver', 'common', '44', NULL, NULL),
  ('update_state', '更新状态', 'common', '86', NULL, NULL),
  ('update_state', 'Update State', 'common', '44', NULL, NULL),
  ('update_currentDt', '本次更新时间', 'common', '86', NULL, NULL),
  ('update_currentDt', 'Current Dt', 'common', '44', NULL, NULL),
  ('update_lastDt', '上次更新时间', 'common', '86', NULL, NULL),
  ('update_lastDt', 'Last Dt', 'common', '44', NULL, NULL),
  ('update_version', '版本', 'common', '86', NULL, NULL),
  ('update_version', 'Version', 'common', '44', NULL, NULL),
  ('update_time', '更新时间', 'common', '86', NULL, NULL),
  ('update_time', 'Update Dt', 'common', '44', NULL, NULL),
  ('update_des', '描述', 'common', '86', NULL, NULL),
  ('update_des', 'Describe', 'common', '44', NULL, NULL),
  
  ('check_version', '检测版本号', 'common', '86', NULL, NULL),
  ('check_version', 'Check Version', 'common', '44', NULL, NULL),
  ('download_package', '下载更新包', 'common', '86', NULL, NULL),
  ('download_package', 'Download Package', 'common', '44', NULL, NULL),
  ('upload_package', '上传更新包', 'common', '86', NULL, NULL),
  ('upload_package', 'Upload Package', 'common', '44', NULL, NULL),
  ('upload_excute', '执行更新', 'common', '86', NULL, NULL),
  ('upload_excute', 'Excute Update', 'common', '44', NULL, NULL),
  ('upload_path', '设置下载路径', 'common', '86', NULL, NULL),
  ('upload_path', 'Set UpdatePath', 'common', '44', NULL, NULL),
  ('update_his', '升级历史', 'common', '86', NULL, NULL),
  ('update_his', 'Update His', 'common', '44', NULL, NULL),
  ('minColor', 'Min Color', 'common', '44', NULL, NULL),
  ('minColor', '下界颜色', 'common', '86', NULL, NULL),
  ('minColor', '下界顏色', 'common', '87', NULL, NULL),
  ('maxColor', 'Max Color', 'common', '44', NULL, NULL),
  ('maxColor', '上界颜色', 'common', '86', NULL, NULL),
  ('maxColor', '上界顏色', 'common', '87', NULL, NULL),
  ('minValue', 'Min Value', 'common', '44', NULL, NULL),
  ('minValue', '下界值', 'common', '86', NULL, NULL),
  ('minValue', '下界值', 'common', '87', NULL, NULL),
  ('maxValue', 'Max Value', 'common', '44', NULL, NULL),
  ('maxValue', '上界值', 'common', '86', NULL, NULL),
  ('maxValue', '上界值', 'common', '87', NULL, NULL),
  
  
  
 ('0','雙基色','color_mode','87',NULL,NULL),
 ('0','正常','ctrl_status','87',NULL,NULL),
 ('0','未開啟','detector_enable','87',NULL,NULL),
 ('0','正常','detector_status','87',NULL,NULL),
 ('0','否','enable','87',NULL,NULL),
 ('0','../physical_region/list.action','guide_frame_src','87',NULL,NULL),
 ('0','物理區域設置','guide_step_name','87',NULL,NULL),
 ('0','臨時','parking_type','87',NULL,NULL),
 ('0','停止','runstate','87',NULL,NULL),
 ('0','每週','screen_task_type','87',NULL,NULL),
 ('0','無效','status','87',NULL,NULL),
 ('0','失敗','success','87',NULL,NULL),
 ('0','每週','task_type','87',NULL,NULL),
 ('0','星期日','weekday_type','87',NULL,NULL),
 ('00','左移','move','87',NULL,NULL),
 ('00','停用','state','87',NULL,2),
 ('01','上移','move','87',NULL,NULL),
 ('01','啟用','state','87',NULL,1),
 ('02','下拉','move','87',NULL,NULL),
 ('03','上拉','move','87',NULL,NULL),
 ('04','即顯','move','87',NULL,NULL),
 ('05','動態箭頭','move','87',NULL,NULL),
 ('1','單基色','color_mode','87',NULL,NULL),
 ('1','離線','ctrl_status','87',NULL,NULL),
 ('1','開啟','detector_enable','87',NULL,NULL),
 ('1','異常','detector_status','87',NULL,NULL),
 ('1','超聲波探測器','detector_type','87',NULL,NULL),
 ('1','管理器','device_object','87',NULL,NULL),
 ('1','是','enable','87',NULL,NULL),
 ('1','../map_manage/map_list.action','guide_frame_src','87',NULL,NULL),
 ('1','地圖管理','guide_step_name','87',NULL,NULL),
 ('1','短信貓','notice_way','87',NULL,NULL),
 ('1','固定','parking_type','87',NULL,NULL),
 ('1','執行中','runstate','87',NULL,NULL),
 ('1','單次','screen_task_type','87',NULL,NULL),
 ('1','有效','status','87',NULL,NULL),
 ('1','成功','success','87',NULL,NULL),
 ('1','單次','task_type','87',NULL,NULL),
 ('1','星期一','weekday_type','87',NULL,NULL),
 ('10K','10K','baud_rate','87',NULL,12),
 ('115200','115200','scr_baudrate','87',NULL,1),
 ('1200','1200','scr_baudrate','87',NULL,8),
 ('125K','125K','baud_rate','87',NULL,8),
 ('19200','19200','scr_baudrate','87',NULL,4),
 ('1M','1M','baud_rate','87',NULL,1),
 ('2','故障','ctrl_status','87',NULL,NULL),
 ('2','地感探測器','detector_type','87',NULL,NULL),
 ('2','條屏','device_object','87',NULL,NULL),
 ('2','../screentypepara_config/screentypepara_list.action','guide_frame_src','87',NULL,NULL),
 ('2','屏類型參數配置','guide_step_name','87',NULL,NULL),
 ('2','網路服務商','notice_way','87',NULL,NULL),
 ('2','預定','parking_type','87',NULL,NULL),
 ('2','立即','screen_task_type','87',NULL,NULL),
 ('2','立即','task_type','87',NULL,NULL),
 ('2','星期二','weekday_type','87',NULL,NULL),
 ('200K','200K','baud_rate','87',NULL,7),
 ('20K','20K','baud_rate','87',NULL,11),
 ('2400','2400','scr_baudrate','87',NULL,7),
 ('250K','250K','baud_rate','87',NULL,6),
 ('3','探測器','device_object','87',NULL,NULL),
 ('3','../screen_config/screen_list.action','guide_frame_src','87',NULL,NULL),
 ('3','引導屏配置','guide_step_name','87',NULL,NULL),
 ('3','切換顯示','screen_task_type','87',NULL,NULL),
 ('3','星期三','weekday_type','87',NULL,NULL),
 ('38400','38400','scr_baudrate','87',NULL,3),
 ('4','../guideregion_manage/guideregion_list.action','guide_frame_src','87',NULL,NULL),
 ('4','引導區域配置','guide_step_name','87',NULL,NULL),
 ('4','車位保護','screen_task_type','87',NULL,NULL),
 ('4','星期四','weekday_type','87',NULL,NULL),
 ('400K','400K','baud_rate','87',NULL,5),
 ('40K','40K','baud_rate','87',NULL,10),
 ('4800','4800','scr_baudrate','87',NULL,6),
 ('5','../logicregion_manage/logicregion_list.action','guide_frame_src','87',NULL,NULL),
 ('5','地理區域配置','guide_step_name','87',NULL,NULL),
 ('5','星期五','weekday_type','87',NULL,NULL),
 ('500K','500K','baud_rate','87',NULL,4),
 ('50K','50K','baud_rate','87',NULL,9),
 ('57600','57600','scr_baudrate','87',NULL,2),
 ('6','../screen_logic/logic_main.action','guide_frame_src','87',NULL,NULL),
 ('6','引導屏邏輯','guide_step_name','87',NULL,NULL),
 ('6','星期六','weekday_type','87',NULL,NULL),
 ('600','600','scr_baudrate','87',NULL,9),
 ('666K','666K','baud_rate','87',NULL,3),
 ('7','../line_config/line_list.action','guide_frame_src','87',NULL,NULL),
 ('7','通訊線路配置','guide_step_name','87',NULL,NULL),
 ('8','../detector_config/detector_list.action','guide_frame_src','87',NULL,NULL),
 ('8','探測器配置','guide_step_name','87',NULL,NULL),
 ('800K','800K','baud_rate','87',NULL,2),
 ('9','../controller_config/controller_list.action','guide_frame_src','87',NULL,NULL),
 ('9','管理器配置','guide_step_name','87',NULL,NULL),
 ('9600','9600','scr_baudrate','87',NULL,5),
 ('a','第','showmenu','87',NULL,NULL),
 ('address','地址','common','87',NULL,NULL),
 ('add_region','添加區域','common','87',NULL,NULL),
 ('alert_abnormal','在設置的【判斷時間】內判定異常次數超過設置的【判定次數】將認為設備異常','common','87',NULL,NULL),
 ('alert_account_already_out_of_service','帳戶已停用,請聯繫管理員','common','87',NULL,NULL), 
 ('alert_again_issued_config_file','請重新下發配置檔','common','87',NULL,NULL),
 ('alert_and','與','common','87',NULL,NULL),
 ('alert_auto_split','系統自動為您進行數據拆分,請選擇在車流量不大的時間點','common','87',NULL,NULL),
 ('alert_batch_config_please_select_same_screen','批量屏類型配置,請選擇類型相同的屏','common','87',NULL,NULL),
 ('alert_com_service_offline','通訊服務離線','common','87',NULL,NULL),
 ('alert_connect_timeout','連接超時，請檢查資料庫鏈接','common','87',NULL,NULL),
 ('alert_delete','您確定要刪除此記錄嗎','common','87',NULL,NULL),
 ('alert_detector_conflict','探測器類型與引導區類型必須相同','common','87',NULL,NULL),
 ('alert_field_format_error','格式錯誤','common','87',NULL,NULL),
 ('alert_guide_regional_already_used','引導區域已經被使用,不能刪除','common','87',NULL,NULL),
 ('alert_guide_regional_name_repeat','引導區域名稱或編碼不能重複,請修改','common','87',NULL,NULL),
 ('alert_ini_file_task_established','任務已建立,此項操作可能需要幾分鐘,期間系統會暫時停止引導,請耐心等候!','common','87',NULL,NULL),
 ('alert_input_number_is_empty','您輸入的頁數是空的','common','87',NULL,NULL),
 ('alert_input_number_not_Numbers','您輸入的頁數不是數字','common','87',NULL,NULL),
 ('alert_input_number_too_big','您輸入的頁數過大','common','87',NULL,NULL),
 ('alert_input_number_too_small','您輸入的頁數過小','common','87',NULL,NULL),
 ('alert_instructions_issued_by_success','下發指令成功','common','87',NULL,NULL),
 ('alert_interval_regular_sensor','定時修正地感引導區數據的間隔時間','common','87',NULL,NULL),
 ('alert_interval_update_conf','定時更新配置數據的間隔時間','common','87',NULL,NULL),
 ('alert_is_exist','已存在','common','87',NULL,NULL),
 ('alert_is_not_null','不能為空','common','87',NULL,NULL),
 ('alert_line_already_exists','通訊線路名稱已經存在,請修改','common','87',NULL,NULL),
 ('alert_line_cant_for_empty','通訊線路不能為空','common','87',NULL,NULL),
 ('alert_line_to_be_allocated_cant_delete','當前通訊線路已被引用，不能刪除','common','87',NULL,NULL),
 ('alert_line_to_be_allocated_cant_disable','當前通訊線路已被引用，不能設置無效狀態','common','87',NULL,NULL),
 ('alert_logic_area_name_repeat','地理區域名稱或編碼重複,請修改','common','87',NULL,NULL),
 ('alert_logout_confirm','您確認要從本系統註銷嗎？','common','87',NULL,NULL),
 ('alert_map_already_exists','地圖檔已經存在請重新上傳','common','87',NULL,NULL),
 ('alert_map_already_import','該地圖已經導入數據,禁止重複導入','common','87',NULL,NULL),
 ('alert_map_file_is_not_correct','地圖檔不正確，請重新導入檔','common','87',NULL,NULL),
 ('alert_map_file_not_exits','地圖檔不存在，不能進行導入數據操作','common','87',NULL,NULL),
 ('alert_map_name_already_exists','地圖名稱已經存在,請修改','common','87',NULL,NULL),
 ('alert_max_length','最大長度為','common','87',NULL,NULL),
 ('alert_multiple_values','如果多個值 請用逗號分開 例如: 12,45,78','common','87',NULL,NULL),
 ('alert_not_reg_limit_use','未註冊或已過期，限制設備使用數量','common','87',NULL,NULL),
 ('alert_no_same','不一致','common','87',NULL,NULL),
 ('alert_only_number','只能填數字','common','87',NULL,NULL),
 ('alert_physicalregion_have_map_association','當前的物理區域有地圖資訊,因此不能設置為無效','common','87',NULL,NULL),
 ('alert_physical_area_already_exists','物理區域名稱已經存在,請修改','common','87',NULL,NULL),
 ('alert_physical_area_has_related_maps','物理區域已關聯地圖,不能刪除','common','87',NULL,NULL),
 ('alert_please_check_the_box_to_confirm','請選中複選框確認修改','common','87',NULL,NULL),
 ('alert_please_first_choice_select_screen_type','請選擇屏類型,再配置屏參數','common','87',NULL,NULL),
 ('alert_please_input','請輸入','common','87',NULL,NULL),
 ('alert_please_input_a_code','請輸入編碼','common','87',NULL,NULL),
 ('alert_please_input_a_height','請輸入高度','common','87',NULL,NULL),
 ('alert_please_input_a_lineaddress','請輸入線路地址','common','87',NULL,NULL),
 ('alert_please_input_a_name','請輸入名稱','common','87',NULL,NULL),
 ('alert_please_input_a_type','請輸入類型','common','87',NULL,NULL),
 ('alert_please_select_a_record','請先選擇記錄','common','87',NULL,NULL),
 ('alert_please_select_the_day','請選擇要查詢的日期','common','87',NULL,NULL),
 ('alert_please_select_the_month','請選擇要查詢的月份','common','87',NULL,NULL),
 ('alert_please_select_the_year','請選擇要查詢的年份','common','87',NULL,NULL),
 ('alert_reapply_template_prompt','此操作將覆蓋相關聯顯示幕的參數值！','common','87',NULL,NULL),
 ('alert_remove_parking_and_logicset','該操作將清除所有車位及它的邏輯設置','common','87',NULL,NULL),
 ('alert_restart_pgsserver','請重啟 pgsServer.exe或 pgsServer服務！','common','87',NULL,NULL),
 ('alert_right_format','正確格式','common','87',NULL,NULL),
 ('alert_screen_type_code_already_exists','屏類型名稱或編碼已經存在,請修改','common','87',NULL,NULL),
 ('alert_screen_type_name_already_exists','屏類型參數名稱或編碼已經存在,請修改','common','87',NULL,NULL),
 ('alert_select_parkingspace_or_screen','請選擇車位或者引導屏來操作','common','87',NULL,NULL),
 ('alert_should_less','應該小於','common','87',NULL,NULL),
 ('alert_should_more','應該大於','common','87',NULL,NULL),
 ('alert_single_select','您只能選擇一條記錄進行該操作','common','87',NULL,NULL),
 ('alert_templatename_already_exists','範本名稱已經存在,請修改','common','87',NULL,NULL),
 ('alert_terminate','您確定要終止此項任務嗎','common','87',NULL,NULL),
 ('alert_this','該','common','87',NULL,NULL),
 ('alert_to_deal','為了應付不可預知情況,例如停電,洪水等對數據拆分的不利影響,請選擇分析歷史數據的天數','common','87',NULL,NULL),
 ('alert_upload_file_type_error','上傳檔類型錯誤','common','87',NULL,NULL),
 ('alert_will_delete_controller_settings','將刪除管理器相關設置','common','87',NULL,NULL),
 ('alert_will_delete_screen_settings','將刪除引導屏相關設置','common','87',NULL,NULL),
 ('all','全部','common','87',NULL,NULL),
 ('all_map_collection','全部地圖匯總','common','87',NULL,NULL),
 ('Append','01顯示本屏前清屏，02顯示本屏後清屏，04為引出方式有效，08為本屏內容不顯示','screenparades','87',NULL,NULL),
 ('area','區域','common','87',NULL,NULL),
 ('average','平均','common','87',NULL,NULL),
 ('batch','批量','common','87',NULL,NULL),
 ('baud_rate','串列傳輸速率','common','87',NULL,NULL),
 ('blue','藍','font_color','87',NULL,NULL),
 ('board_no','板卡號','common','87',NULL,NULL),
 ('btn_add','新建','common','87',NULL,NULL),
 ('btn_add_detector','新增探測器','common','87',NULL,NULL),
 ('btn_alledit','全部更新','common','87',NULL,NULL),
 ('btn_batchedit','批量編輯','common','87',NULL,NULL),
 ('btn_clear','清空','common','87',NULL,NULL),
 ('btn_createczone','添加自定義區域','common','87',NULL,NULL),
 ('btn_creategzone','添加引導區域','common','87',NULL,NULL),
 ('btn_default','重置缺省值','common','87',NULL,NULL),
 ('btn_delete','刪除','common','87',NULL,NULL),
 ('btn_detail','詳細資訊','common','87',NULL,NULL),
 ('btn_edit','編輯','common','87',NULL,NULL),
 ('btn_edits','編輯/批量','common','87',NULL,NULL),
 ('btn_logiczoneconfig','配置引導區域','common','87',NULL,NULL),
 ('btn_query','查詢','common','87',NULL,NULL),
 ('btn_resetczone','重置自定義區域','common','87',NULL,NULL),
 ('btn_resetgzone','重置引導區域','common','87',NULL,NULL),
 ('btn_return','返回','common','87',NULL,NULL),
 ('btn_save','保存','common','87',NULL,NULL),
 ('btn_terminate','終止','common','87',NULL,NULL),
 ('checked','選中','common','87',NULL,NULL),
 ('check_code','校驗碼','common','87',NULL,NULL),
 ('check_color_task','當前任務查看','common','87',NULL,NULL),
 ('check_version','檢測版本號','common','87',NULL,NULL),
 ('code','編碼','common','87',NULL,NULL),
 ('codeerror','編碼錯誤','common','87',NULL,NULL),
 ('coderepeat','編碼重複','common','87',NULL,NULL),
 ('colorvalues','變色值組合','common','87',NULL,NULL),
 ('Color_change_tactics','變色策略設置','common','87',NULL,NULL),
 ('color_mode','顏色模式','common','87',NULL,NULL),
 ('color_task_history','下發歷史查詢','common','87',NULL,NULL),
 ('communication_line','通訊線路','common','87',NULL,NULL),
 ('condition','條件','common','87',NULL,NULL),
 ('config_file_path','配置檔路徑','common','87',NULL,NULL),
 ('config_guide','配置嚮導','common','87',NULL,NULL),
 ('config_history','下發歷史查看','common','87',NULL,NULL),
 ('config_task','下發任務查看','common','87',NULL,NULL),
 ('confirm_password','確認密碼','common','87',NULL,NULL),
 ('content','內容','common','87',NULL,NULL),
 ('content_display','內容顯示','common','87',NULL,NULL),
 ('content_format','內容格式','common','87',NULL,NULL),
 ('controller','管理器','common','87',NULL,NULL),
 ('controller_addr','管理器地址','common','87',NULL,NULL),
 ('controller_conf','管理器配置','common','87',NULL,NULL),
 ('controller_id','管理器Id','common','87',NULL,NULL),
 ('controller_port','管理器端口','common','87',NULL,NULL),
 ('controller_type','管理器類型','common','87',NULL,NULL),
 ('create_color_task','下發變色策略','common','87',NULL,NULL),
 ('create_debug_task','下發任務','common','87',NULL,NULL),
 ('custom_area','自定義區域','common','87',NULL,NULL),
 ('Custom_debug_task','自定義調試任務','common','87',NULL,NULL),
 ('data_analysis_days','停車數據分析天數','common','87',NULL,NULL),
 ('data_analysis_time','停車數據分析時間','common','87',NULL,NULL),
 ('data_backup','數據備份','common','87',NULL,NULL),
 ('data_bits','數據位','common','87',NULL,NULL),
 ('data_recovery','數據恢復','common','87',NULL,NULL),
 ('date','日期','common','87',NULL,NULL),
 ('day','日','common','87',NULL,NULL),
 ('day_hour','日/時','common','87',NULL,NULL),
 ('dbcoderepeat','資料庫重複','common','87',NULL,NULL),
 ('default_value','默認值','common','87',NULL,NULL),
 ('define_debug_task','定義調試任務','common','87',NULL,NULL),
 ('detector','探測器','common','87',NULL,NULL),
 ('detector','探測器','map_dtype','87',NULL,NULL),
 ('detector_addr','探測器地址','common','87',NULL,NULL),
 ('detector_code','探測器編碼','common','87',NULL,NULL),
 ('detector_conf','探測器配置','common','87',NULL,NULL),
 ('detector_height','探測器高度','common','87',NULL,NULL),
 ('detector_id','探測器ID','common','87',NULL,NULL),
 ('detector_type','探測器類型','common','87',NULL,NULL),
 ('device_code','設備編碼','common','87',NULL,NULL),
 ('device_state','設備狀態','common','87',NULL,NULL),
 ('device_type','設備類型','common','87',NULL,NULL),
 ('disable','停用','common','87',NULL,NULL),
 ('disabledtitle','殘疾人標識','common','87',NULL,NULL),
 ('display_color','顯示顏色','common','87',NULL,NULL),
 ('display_mode','顯示方式','common','87',NULL,NULL),
 ('dll_name','動態庫檔案名','common','87',NULL,NULL),
 ('download_package','下載更新包','common','87',NULL,NULL),
 ('download_template','下載地圖製作範本','common','87',NULL,NULL),
 ('do_not_modify_please_keep_is_empty','不修改請保持為空','common','87',NULL,NULL),
 ('duration','執行時長','common','87',NULL,NULL),
 ('enable','啟用','common','87',NULL,NULL),
 ('end_time','結束時間','common','87',NULL,NULL),
 ('enlargement','放大','common','87',NULL,NULL),
 ('execute_time','執行時間','common','87',NULL,NULL),
 ('execution_day','執行日','common','87',NULL,NULL),
 ('exitscreen_carport_num','出口屏保護臨界值','common','87',NULL,NULL),
 ('exitscreen_carport_num_explain','出口屏車位數小於指定數時，出口屏將顯示指定的內容','common','87',NULL,NULL),
 ('exitscreen_content','出口屏保護內容','common','87',NULL,NULL),
 ('expectreturn','期待返回','common','87',NULL,NULL),
 ('export_excel','導出excel','common','87',NULL,NULL),
 ('fault_judgment_interval','故障判定間隔時間','common','87',NULL,NULL),
 ('fault_judgment_num','故障判定次數','common','87',NULL,NULL),
 ('fault_monitoring','故障監控','common','87',NULL,NULL),
 ('fixed_parking','固定車位','common','87',NULL,NULL),
 ('fold','合併','common','87',NULL,NULL),
 ('font','00為16*16字體，01為32*32字體，02為24*24字體','screenparades','87',NULL,NULL),
 ('font_color','字體顏色','common','87',NULL,NULL),
 ('from','從','common','87',NULL,NULL),
 ('fullscreen','全屏亮標識','common','87',NULL,NULL),
 ('funcode','功能碼','common','87',NULL,NULL),
 ('graph','曲線圖','common','87',NULL,NULL),
 ('greater_than','大於','common','87',NULL,NULL),
 ('green','綠','font_color','87',NULL,NULL),
 ('guideregion_in_screenregion','引導區在屏分區中有引用','common','87',NULL,NULL),
 ('guide_line_direction','引導方向','common','87',NULL,NULL),
 ('guide_regional','引導區域','common','87',NULL,NULL),
 ('histogram','柱狀圖','common','87',NULL,NULL),
 ('holding_time','佔用時間','common','87',NULL,NULL),
 ('hour','小時','common','87',NULL,NULL),
 ('ifexpireBecomeRedState','軟體到期車位燈顯示紅色','common','87',NULL,NULL),
 ('import_map','導入地圖','common','87',NULL,NULL),
 ('import_map_data','導入地圖數據','common','87',NULL,NULL),
 ('init_wizard_description','初始化嚮導說明','common','87',NULL,NULL),
 ('ini_file_save_error','請檢查引導屏、引導屏邏輯以及探測器配置是否正確','common','87',NULL,NULL),
 ('Inout','00為左移，01為上移，02為下拉，03為上拉，04為靜止，05為動態箭頭','screenparades','87',NULL,NULL),
 ('in_and_out_situation','停車出入情況','common','87',NULL,NULL),
 ('in_and_out_situation_chart','停車出入圖表','common','87',NULL,NULL),
 ('in_park','進車','common','87',NULL,NULL),
 ('ip','IP','common','87',NULL,NULL),
 ('issued_config_file','下發配置檔','common','87',NULL,NULL),
 ('is_already_send','已發送','common','87',NULL,NULL),
 ('is_exit_screen','出入口','common','87',NULL,NULL),
 ('is_need_send','需發送','common','87',NULL,NULL),
 ('language','語言','common','87',NULL,NULL),
 ('Led_h','01或02','screenparades','87',NULL,NULL),
 ('Led_w','最大為16進制30，常用值為08、12、18','screenparades','87',NULL,NULL),
 ('less_than','小於','common','87',NULL,NULL),
 ('light','16進制00—14，14和00最亮，01最暗','screenparades','87',NULL,NULL),
 ('line_addr','線路地址','common','87',NULL,NULL),
 ('line_conf','通訊線路配置','common','87',NULL,NULL),
 ('line_name','線路名稱','common','87',NULL,NULL),
 ('line_param_notes','參數說明','common','87',NULL,NULL),
 ('linkman','聯繫人','common','87',NULL,NULL),
 ('logical_parking_occupancy_rate','地理區域佔有率','common','87',NULL,NULL),
 ('logic_area','地理區域','common','87',NULL,NULL),
 ('logic_area_manage','地理區域管理','common','87',NULL,NULL),
 ('logic_use_chart','地理區域圖表','common','87',NULL,NULL),
 ('login','登錄','common','87',NULL,NULL),
 ('login_title','歡迎使用艾科停車引導系統','common','87',NULL,NULL),
 ('malfun_equi','故障設備','common','87',NULL,NULL),
 ('manage','管理','common','87',NULL,NULL),
 ('map','地圖','common','87',NULL,NULL),
 ('map_id','地圖號','common','87',NULL,NULL),
 ('map_manage','地圖管理','common','87',NULL,NULL),
 ('map_monitoring','地圖監控','common','87',NULL,NULL),
 ('map_name','地圖名','common','87',NULL,NULL),
 ('mask','掩碼','common','87',NULL,NULL),
 ('max_detectors','最大探頭數量','common','87',NULL,NULL),
 ('message_monitoring','報警服務','common','87',NULL,NULL),
 ('meter','米','common','87',NULL,NULL),
 ('minute','分鐘','common','87',NULL,NULL),
 ('mobile_phone','手機號碼','common','87',NULL,NULL),
 ('Mode','00為1/16A模式，01為1/16B模式，02為1/8模式，03為1/4A模式，04為1/4B模式，05為1/4C模式，06為1/4D模式','screenparades','87',NULL,NULL),
 ('modify_content','修改內容','common','87',NULL,NULL),
 ('modify_password','修改密碼','common','87',NULL,NULL),
 ('mokuai','模組管理','common','87',NULL,NULL),
 ('monitoring_chart_summary','監控圖表匯總','common','87',NULL,NULL),
 ('month','月','common','87',NULL,NULL),
 ('month_day','月/日','common','87',NULL,NULL),
 ('Move','16進制00—C8之間取值','screenparades','87',NULL,NULL),
 ('moveSpeed','移動速度','common','87',NULL,NULL),
 ('moveWidth','顯示寬度','common','87',NULL,NULL),
 ('must_be_digital','必須是數字','common','87',NULL,NULL),
 ('name','名稱','common','87',NULL,NULL),
 ('new_password','新密碼','common','87',NULL,NULL),
 ('new_value','新值','common','87',NULL,NULL),
 ('next_step','下一步','common','87',NULL,NULL),
 ('notice_way','通知方式','common','87',NULL,NULL),
 ('not_configured','未配置','common','87',NULL,NULL),
 ('now_time','當前時間','common','87',NULL,NULL),
 ('no_of_vehicle','單位：輛','common','87',NULL,NULL),
 ('number','編號','common','87',NULL,NULL),
 ('num_length','剩餘車位數長度','common','87',NULL,NULL),
 ('occupancy_rate','佔用率','common','87',NULL,NULL),
 ('occupancy_rate_formula','佔有率=車位佔用時間/(車位數*總時間)','common','87',NULL,NULL),
 ('occurrence_time','發生時間','common','87',NULL,NULL),
 ('old_password','原密碼','common','87',NULL,NULL),
 ('operate_time','操作時間','common','87',NULL,NULL),
 ('operator','發佈人','common','87',NULL,NULL),
 ('operator_time','發佈時間','common','87',NULL,NULL),
 ('optional_value','可選值','common','87',NULL,NULL),
 ('original_proportion','原始','common','87',NULL,NULL),
 ('out_of_date','已過期','common','87',NULL,NULL),
 ('out_park','出車','common','87',NULL,NULL),
 ('page','頁','showmenu','87',NULL,NULL),
 ('para_conf','參數配置','common','87',NULL,NULL),
 ('parity','校驗位','common','87',NULL,NULL),
 ('parking_duration','停車時長','common','87',NULL,NULL),
 ('parking_info_manage','停車場資訊維護','common','87',NULL,NULL),
 ('parking_lot_map','停車場地圖','common','87',NULL,NULL),
 ('parking_lot_number','車位編號','common','87',NULL,NULL),
 ('parking_name','停車場名稱','common','87',NULL,NULL),
 ('parking_numbers','車位數','common','87',NULL,NULL),
 ('parking_occupancy_rate','停車佔有率情況','common','87',NULL,NULL),
 ('parking_occupancy_rate_chart','停車佔有率圖表','common','87',NULL,NULL),
 ('parking_state','車位狀態','common','87',NULL,NULL),
 ('parking_total','車位總數','common','87',NULL,NULL),
 ('parking_type','車位類型','common','87',NULL,NULL),
 ('parking_type_can\'t_for_empty','車位類型不能為空','common','87',NULL,NULL),
 ('parking_work_manage','車位作業管理','common','87',NULL,NULL),
 ('parking_work_plan','車位作業計畫','common','87',NULL,NULL),
 ('password','密碼','common','87',NULL,NULL),
 ('password_different','兩次輸入的新密碼不相同','common','87',NULL,NULL),
 ('path','路徑','common','87',NULL,NULL),
 ('Pause','16進制00—14取值','screenparades','87',NULL,NULL),
 ('pgs_service_management','PGS服務管理','common','87',NULL,NULL),
 ('phone','聯繫電話','common','87',NULL,NULL),
 ('physical_area','物理區域','common','87',NULL,NULL),
 ('physical_area_code','物理區域編碼','common','87',NULL,NULL),
 ('physical_area_config','物理區域配置','common','87',NULL,NULL),
 ('physical_area_name','物理區域名','common','87',NULL,NULL),
 ('pie_chart','餅圖','common','87',NULL,NULL),
 ('plan_type','計畫類型','common','87',NULL,NULL),
 ('plan_work','計畫作業','common','87',NULL,NULL),
 ('please_select','請選擇','common','87',NULL,NULL),
 ('port','端口','common','87',NULL,NULL),
 ('preview','預覽','common','87',NULL,NULL),
 ('prev_step','上一步','common','87',NULL,NULL),
 ('print','列印','common','87',NULL,NULL),
 ('process_failed','操作失敗','common','87',NULL,NULL),
 ('process_success','操作成功','common','87',NULL,NULL),
 ('purpose','用途','common','87',NULL,NULL),
 ('realreturn','實際返回','common','87',NULL,NULL),
 ('real_time_monitoring','即時監控','common','87',NULL,NULL),
 ('reapply_template','重新應用','common','87',NULL,NULL),
 ('record','條','showmenu','87',NULL,NULL),
 ('red','紅','font_color','87',NULL,NULL),
 ('reduction','縮小','common','87',NULL,NULL),
 ('red_count','變紅色臨界','common','87',NULL,NULL),
 ('refresh','刷新','common','87',NULL,NULL),
 ('refresh_time','地感更新時間','common','87',NULL,NULL),
 ('register','註冊','common','87',NULL,NULL),
 ('registered','已註冊','common','87',NULL,NULL),
 ('remark','備註','common','87',NULL,NULL),
 ('remember','記住','common','87',NULL,NULL),
 ('reservation_parking','預定車位','common','87',NULL,NULL),
 ('reset','重置','common','87',NULL,NULL),
 ('restart','重啟','common','87',NULL,NULL),
 ('returndata1','RD1','common','87',NULL,NULL),
 ('returndata2','RD2','common','87',NULL,NULL),
 ('returndata3','RD3','common','87',NULL,NULL),
 ('returndata4','RD4','common','87',NULL,NULL),
 ('returndata5','RD5','common','87',NULL,NULL),
 ('returndata6','RD6','common','87',NULL,NULL),
 ('returndata7','RD7','common','87',NULL,NULL),
 ('returndata8','RD8','common','87',NULL,NULL),
 ('Reverse','第一位為使能反向，1代表使能，0代表不使能；第二位為反色顯示，1代表反色，0代表不反色','screenparades','87',NULL,NULL),
 ('role','權限','common','87',NULL,NULL),
 ('role_manage','權限管理','common','87',NULL,NULL),
 ('role_name','權限名稱','common','87',NULL,NULL),
 ('role_user','權限用戶','common','87',NULL,NULL),
 ('run','運行','common','87',NULL,NULL),
 ('runstate','任務執行狀態','common','87',NULL,NULL),
 ('screen','引導屏','map_dtype','87',NULL,NULL),
 ('screenparavaluetemplate','屏參數值範本','common','87',NULL,NULL),
 ('screenparavalue_conf','屏參數值配置','common','87',NULL,NULL),
 ('screenparavalue_manage','屏參數值管理','common','87',NULL,NULL),
 ('screenparavalue_temp','屏參數值範本管理','common','87',NULL,NULL),
 ('screenparavalue_temp_detail','屏參數值範本明細管理','common','87',NULL,NULL),
 ('screens','屏編碼組合','common','87',NULL,NULL),
 ('screentypepara_conf','屏類型參數配置','common','87',NULL,NULL),
 ('screentypepara_name','屏類型參數名稱','common','87',NULL,NULL),
 ('screentype_manage','屏類型管理','common','87',NULL,NULL),
 ('screen_address','引導屏地址','common','87',NULL,NULL),
 ('screen_code','引導屏編碼','common','87',NULL,NULL),
 ('screen_conf','引導屏配置','common','87',NULL,NULL),
 ('screen_group_address','引導屏組地址','common','87',NULL,NULL),
 ('screen_id','引導屏編號','common','87',NULL,NULL),
 ('screen_logic','引導屏邏輯','common','87',NULL,NULL),
 ('screen_logic_not_set','引導屏邏輯沒有進行設置','common','87',NULL,NULL),
 ('screen_manage','引導區域管理','common','87',NULL,NULL),
 ('screen_numbers','屏數','common','87',NULL,NULL),
 ('screen_paravalue_not_enough','屏參數值配置不全','common','87',NULL,NULL),
 ('screen_status','引導屏狀態','common','87',NULL,NULL),
 ('screen_the_contents','引導屏當前內容','common','87',NULL,NULL),
 ('screen_type','引導屏類型','common','87',NULL,NULL),
 ('screen_work_manage','引導屏作業管理','common','87',NULL,NULL),
 ('screen_work_plan','引導屏作業計畫','common','87',NULL,NULL),
 ('second','秒','common','87',NULL,NULL),
 ('select_all','全選','common','87',NULL,NULL),
 ('sendcontent','發送內容','common','87',NULL,NULL),
 ('senddata1','SD1','common','87',NULL,NULL),
 ('senddata2','SD2','common','87',NULL,NULL),
 ('senddata3','SD3','common','87',NULL,NULL),
 ('senddata4','SD4','common','87',NULL,NULL),
 ('senddata5','SD5','common','87',NULL,NULL),
 ('senddata6','SD6','common','87',NULL,NULL),
 ('senddata7','SD7','common','87',NULL,NULL),
 ('senddata8','SD8','common','87',NULL,NULL),
 ('serial_number','序列號','common','87',NULL,NULL),
 ('serial_port','端口號','common','87',NULL,NULL),
 ('set','設置','common','87',NULL,NULL),
 ('set_stop_color','設置停車時長的動態顏色','common','87',NULL,NULL),
 ('showcha','叉叉標識','common','87',NULL,NULL),
 ('show_detail','顯示明細','common','87',NULL,NULL),
 ('software_version_update','軟體版本更新','common','87',NULL,NULL),
 ('sort','順序','common','87',NULL,NULL),
 ('spacing_interval','間隔時間','common','87',NULL,NULL),
 ('specialsymbol','特殊符號','common','87',NULL,NULL),
 ('start_time','開始時間','common','87',NULL,NULL),
 ('state_time','通訊程式狀態時間','common','87',NULL,NULL),
 ('station_addr','本地地址','common','87',NULL,NULL),
 ('statistical_statement','統計報表','common','87',NULL,NULL),
 ('status','狀態','common','87',NULL,NULL),
 ('stop_bits','停止位','common','87',NULL,NULL),
 ('storage_type','存儲類型','common','87',NULL,NULL),
 ('success','是否成功','common','87',NULL,NULL),
 ('switch_gap','切換間隔','common','87',NULL,NULL),
 ('system_remote_update','系統升級','common','87',NULL,NULL),
 ('sys_manage','系統管理','common','87',NULL,NULL),
 ('take_up','佔用','common','87',NULL,NULL),
 ('taskname','任務名稱','common','87',NULL,NULL),
 ('task_running','任務正在執行中','common','87',NULL,NULL),
 ('templatename','範本名稱','common','87',NULL,NULL),
 ('temporary_parking','臨時車位','common','87',NULL,NULL),
 ('temporary_parking_space','臨時停車','common','87',NULL,NULL),
 ('the_rest','剩餘','common','87',NULL,NULL),
 ('time','時間','common','87',NULL,NULL),
 ('timeout_monitoring','超時監控','common','87',NULL,NULL),
 ('time_out','超時時間','common','87',NULL,NULL),
 ('time_out_target','逾時指標','common','87',NULL,NULL),
 ('to','到','common','87',NULL,NULL),
 ('todefault','初始化','common','87',NULL,NULL),
 ('total','總數','common','87',NULL,NULL),
 ('total','共','showmenu','87',NULL,NULL),
 ('turn_to','轉到','common','87',NULL,NULL),
 ('type','類型','common','87',NULL,NULL),
 ('ucerror','超聲波錯誤','common','87',NULL,NULL),
 ('unchecked','未選中','common','87',NULL,NULL),
 ('unfold','展開','common','87',NULL,NULL),
 ('unit','單位','common','87',NULL,NULL),
 ('unregistered','未註冊','common','87',NULL,NULL),
 ('unselect_all','全不選','common','87',NULL,NULL),
 ('update_code','系統編碼','common','87',NULL,NULL),
 ('update_currentDt','本次更新時間','common','87',NULL,NULL),
 ('update_currentVer','當前版本','common','87',NULL,NULL),
 ('update_des','描述','common','87',NULL,NULL),
 ('update_his','升級歷史','common','87',NULL,NULL),
 ('update_lastDt','上次更新時間','common','87',NULL,NULL),
 ('update_map','更新地圖','common','87',NULL,NULL),
 ('update_name','系統名稱','common','87',NULL,NULL),
 ('update_state','更新狀態','common','87',NULL,NULL),
 ('update_time','更新時間','common','87',NULL,NULL),
 ('update_version','版本','common','87',NULL,NULL),
 ('update_waitingVer','待更新版本','common','87',NULL,NULL),
 ('upload_excute','執行更新','common','87',NULL,NULL),
 ('upload_package','上傳更新包','common','87',NULL,NULL),
 ('upload_path','設置下載路徑','common','87',NULL,NULL),
 ('user_manage','用戶管理','common','87',NULL,NULL),
 ('user_name','用戶名','common','87',NULL,NULL),
 ('user_status','用戶狀態','common','87',NULL,NULL),
 ('use_color','啟用動態顏色','common','87',NULL,NULL),
 ('use_default','使用默認值','common','87',NULL,NULL),
 ('validate_results','數據驗證結果','common','87',NULL,NULL),
 ('valid_until','有效期至','common','87',NULL,NULL),
 ('value','值','common','87',NULL,NULL),
 ('wizard_description','地圖數據導入功能主要是批量檢測和導入地圖檔的基礎數據，免去手工錄入的麻煩，同時也可確保數據的準確性。導入前最好備份一下資料庫，地圖製作範本可通過點擊右下角按鈕下載獲得。基礎數據主要包含以下幾部分：','common','87',NULL,NULL),
 ('wizard_description_1','地圖數據初始化嚮導主要工作：','common','87',NULL,NULL),
 ('wizard_description_2','1.選擇導入數據選項','common','87',NULL,NULL),
 ('wizard_description_3','2.驗證導入數據','common','87',NULL,NULL),
 ('X_offset','引導屏X軸方向偏移的點數','screenparades','87',NULL,NULL),
 ('year','年','common','87',NULL,NULL),
 ('yellow','黃','font_color','87',NULL,NULL),
 ('yellow_percent','變黃色臨界百分比','common','87',NULL,NULL),
 ('yes_or_no_enable','更改狀態','common','87',NULL,NULL),
 ('Y_offset','引導屏Y軸方向偏移的點數','screenparades','87',NULL,NULL),
 ('\\G','綠色','disp_color','87',NULL,NULL),
 ('\\R','紅色','disp_color','87',NULL,NULL),
 ('\\Y','黃色','disp_color','87',NULL,NULL),
 
 ('locked_message','System Locked,Please contact AKE customer service','common','44',NULL,NULL),
 ('locked_message','注册已被锁，请联系AKE客服','common','86',NULL,NULL),
 ('locked_message','註冊已被鎖，請聯繫AKE客服','common','87',NULL,NULL),
 
 ('register_message','Registered. Valid until ','common','44',NULL,NULL),
 ('register_message','已注册  有效期至','common','86',NULL,NULL),
 ('register_message','已註冊  有效期至','common','87',NULL,NULL),
 
 ('warning_message_part','Attention.Out of date Valid in ','common','44',NULL,NULL),
 ('warning_message_part','温馨提示，系统将在','common','86',NULL,NULL),
 ('warning_message_part','溫馨提示，系統將在','common','87',NULL,NULL),
 ('warning_message_part1',' days','common','44',NULL,NULL),
 ('warning_message_part1','天后过期','common','86',NULL,NULL),
 ('warning_message_part1','天後過期','common','87',NULL,NULL),
 
 ('outofdate_message','Out of date Valid until ','common','44',NULL,NULL),
 ('outofdate_message','已过期  有效期至','common','86',NULL,NULL),
 ('outofdate_message','已過期  有效期至','common','87',NULL,NULL),
 
 ('outofdate_warning_message','Out of date Valid, Please register again','common','44',NULL,NULL),
 ('outofdate_warning_message','已过期，请重新注册','common','86',NULL,NULL),
 ('outofdate_warning_message','已過期，請重新註冊','common','87',NULL,NULL),
 
 ('fault_or_offline','Fault or Offline','device_status','44',NULL,NULL),
 ('fault_or_offline','故障或离线','device_status','86',NULL,NULL),
 ('fault_or_offline','故障或離線','device_status','87',NULL,NULL),
 ('uc_error','UC Error','device_status','44',NULL,NULL),
 ('uc_error','超声波错误','device_status','86',NULL,NULL),
 ('uc_error','超聲波錯誤','device_status','87',NULL,NULL),
 ('occupied','Occupied','device_status','44',NULL,NULL),
 ('occupied','占用','device_status','86',NULL,NULL),
 ('occupied','佔用','device_status','87',NULL,NULL),
 ('free','Vacant','device_status','44',NULL,NULL),
 ('free','空闲','device_status','86',NULL,NULL),
 ('free','空閒','device_status','87',NULL,NULL),
 ('default','Default Setting','device_status','44',NULL,NULL),
 ('default','默认','device_status','86',NULL,NULL),
 ('default','默認','device_status','87',NULL,NULL),
 
 ('use_number','use number','chart_title','44',NULL,NULL),
 ('use_number','使用数','chart_title','86',NULL,NULL),
 ('use_number','使用數','chart_title','87',NULL,NULL),
 ('total_number','total number','chart_title','44',NULL,NULL),
 ('total_number','总数','chart_title','86',NULL,NULL),
 ('total_number','总數','chart_title','87',NULL,NULL),
 ('in_park','in_park','chart_title','44',NULL,NULL),
 ('in_park','进车','chart_title','86',NULL,NULL),
 ('in_park','進車','chart_title','87',NULL,NULL),
 ('out_park','out_park','chart_title','44',NULL,NULL),
 ('out_park','出车','chart_title','86',NULL,NULL),
 ('out_park','出車','chart_title','87',NULL,NULL),
 
 ('filepath','File Path','common','44',NULL,NULL),
 ('filepath','文件路径','common','86',NULL,NULL),
 ('filepath','檔路徑','common','87',NULL,NULL),
 ('legal_url','Legal Url Pattern','common','44',NULL,NULL),
 ('legal_url','合法URL格式','common','86',NULL,NULL),
 ('legal_url','合法URL格式','common','87',NULL,NULL),
 ('operate_success','Success','common','44',NULL,NULL),
 ('operate_success','保存成功','common','86',NULL,NULL),
 ('operate_success','保存成功','common','87',NULL,NULL),
 ('operate_ok','OK','common','44',NULL,NULL),
 ('operate_ok','确定','common','86',NULL,NULL),
 ('operate_ok','確定','common','87',NULL,NULL),
 
 ('type_notdeleted','The type can not be deleted','screen_alertmess','44',NULL,NULL),
 ('type_notdeleted','屏类型已经被引用,不能删除','screen_alertmess','86',NULL,NULL),
 ('type_notdeleted','屏類型已經被引用,不能刪除','screen_alertmess','87',NULL,NULL),
 ('para_notdeleted','The type parameter is used, can not be deleted','screen_alertmess','44',NULL,NULL),
 ('para_notdeleted','屏类型参数已经被引用,不能删除','screen_alertmess','86',NULL,NULL),
 ('para_notdeleted','屏類型參數已經被引用,不能刪除','screen_alertmess','87',NULL,NULL),
 ('temp_notdeleted','The Screen parameters template can not be deleted','screen_alertmess','44',NULL,NULL),
 ('temp_notdeleted','屏参数模板已经被引用,不能删除','screen_alertmess','86',NULL,NULL),
 ('temp_notdeleted','屏參數範本已經被引用,不能刪除','screen_alertmess','87',NULL,NULL),
 ('temp_notreapply','Can\'t reapply','screen_alertmess','44',NULL,NULL),
 ('temp_notreapply','无法重新应用','screen_alertmess','86',NULL,NULL),
 ('temp_notreapply','無法重新應用','screen_alertmess','87',NULL,NULL),
 ('d_record',' records','dadd_mess','44',NULL,NULL),
 ('d_record','条','dadd_mess','86',NULL,NULL),
 ('d_record','條','dadd_mess','87',NULL,NULL),
 ('d_add',' Add Detector success,total ','dadd_mess','44',NULL,NULL),
 ('d_add',' 新增探测器成功，共','dadd_mess','86',NULL,NULL),
 ('d_add',' 新增探測器成功，共','dadd_mess','87',NULL,NULL),
 ('s_add',' Add Screen success,total ','dadd_mess','44',NULL,NULL),
 ('s_add',' 新增引导屏成功，共','dadd_mess','86',NULL,NULL),
 ('s_add',' 新增引導屏成功，共','dadd_mess','87',NULL,NULL),
 ('d_error','Detector of address length error','dadd_mess','44',NULL,NULL),
 ('d_error','探测器地址长度错误','dadd_mess','86',NULL,NULL),
 ('d_error','探測器地址長度錯誤','dadd_mess','87',NULL,NULL),
 ('d_exists','Detector of address has exists','dadd_mess','44',NULL,NULL),
 ('d_exists','探测器地址已存在','dadd_mess','86',NULL,NULL),
 ('d_exists','探測器地址已存在','dadd_mess','87',NULL,NULL),
 ('s_perror','Screen of code length error or not start with P','dadd_mess','44',NULL,NULL),
 ('s_perror','引导屏编号长度错误或未以大写字母P开头','dadd_mess','86',NULL,NULL),
 ('s_perror','引導屏編號長度錯誤或未以大寫字母P開頭','dadd_mess','87',NULL,NULL),
 ('s_exists','Screen of code has exists','dadd_mess','44',NULL,NULL),
 ('s_exists','引导屏编号已存在','dadd_mess','86',NULL,NULL),
 ('s_exists','引導屏編號已存在','dadd_mess','87',NULL,NULL),
 
 ('sys_model','System Model','common','44',NULL,NULL),
 ('sys_model','系统类型','common','86',NULL,NULL),
 ('sys_model','系統類型','common','87',NULL,NULL),
 
 ('1','Ultrasonic','sys_model','44',NULL,NULL),
 ('1','超声波','sys_model','86',NULL,NULL),
 ('1','超聲波','sys_model','87',NULL,NULL),
 ('2','Video','sys_model','44',NULL,NULL),
 ('2','视频','sys_model','86',NULL,NULL),
 ('2','視頻','sys_model','87',NULL,NULL),
 ('3','Geomagnetism','sys_model','44',NULL,NULL),
 ('3','地磁','sys_model','86',NULL,NULL),
 ('3','地磁','sys_model','87',NULL,NULL),
 
 ('map_legend','Legend','common','44',NULL,NULL),
 ('map_legend','图例','common','86',NULL,NULL),
 ('map_legend','圖例','common','87',NULL,NULL),
 ('map_legend_tip','The scale value of flash map and real map ,for example,1:200 then input 200','common','44',NULL,NULL),
 ('map_legend_tip','flash地图与实际地图比例值，如1:200则输入200','common','86',NULL,NULL),
 ('map_legend_tip','flash地圖與實際地圖比例值，如1:200則輸入200','common','87',NULL,NULL),
 
 ('base_task_title','Base Task of ParkingSpace','common','44',NULL,NULL),
 ('base_task_title','基础车位作业','common','86',NULL,NULL),
 ('base_task_title','基礎車位作業','common','87',NULL,NULL),
 ('dtcmodel_task_title','Detector Model Task','common','44',NULL,NULL),
 ('dtcmodel_task_title','超声波模式作业','common','86',NULL,NULL),
 ('dtcmodel_task_title','超聲波模式作業','common','87',NULL,NULL),
 ('dtc_model_title','Detector Model','common','44',NULL,NULL),
 ('dtc_model_title','超声波模式','common','86',NULL,NULL),
 ('dtc_model_title','超聲波模式','common','87',NULL,NULL),
 ('3','Normal Model','dtc_model','44',NULL,NULL),
 ('3','正常模式','dtc_model','86',NULL,NULL),
 ('3','正常模式','dtc_model','87',NULL,NULL),
 ('4','Abnormal Model','dtc_model','44',NULL,NULL),
 ('4','异常模式','dtc_model','86',NULL,NULL),
 ('4','異常模式','dtc_model','87',NULL,NULL),
 ('0','Normal Model','detector_model','44',NULL,NULL),
 ('0','正常模式','detector_model','86',NULL,NULL),
 ('0','正常模式','detector_model','87',NULL,NULL),
 ('1','Abnormal Model','detector_model','44',NULL,NULL),
 ('1','异常模式','detector_model','86',NULL,NULL),
 ('1','異常模式','detector_model','87',NULL,NULL),
 
 ('map_import_tip','The map file name cannot have the Chinese character and must be a SWF file','common','44',NULL,NULL),
 ('map_import_tip','地图文件名不能有中文字符且必须是swf文件','common','86',NULL,NULL),
 ('map_import_tip','地圖文件名不能有中文字符且必須是swf文件','common','87',NULL,NULL),
 
 
 ('gps_video_monitor','Gps Video','common','44',NULL,NULL),
 ('gps_video_monitor','地磁视频监控','common','86',NULL,NULL),
 ('gps_video_monitor','地磁視頻監控','common','87',NULL,NULL),
 
 ('ip_address','IP Address','common','44',NULL,NULL),
 ('ip_address','IP地址','common','86',NULL,NULL),
 ('ip_address','IP地址','common','87',NULL,NULL),
 ('gps_video','Monitor Video','common','44',NULL,NULL),
 ('gps_video','监控画面','common','86',NULL,NULL),
 ('gps_video','監控畫面','common','87',NULL,NULL),
 ('link_config','Configuration','common','44',NULL,NULL),
 ('link_config','连接配置','common','86',NULL,NULL),
 ('link_config','連接配置','common','87',NULL,NULL),
 ('ip_port','IP Port','common','44',NULL,NULL),
 ('ip_port','IP端口','common','86',NULL,NULL),
 ('ip_port','IP端口','common','87',NULL,NULL),
 ('mac_address','MAC Address','common','44',NULL,NULL),
 ('mac_address','MAC地址','common','86',NULL,NULL),
 ('mac_address','MAC地址','common','87',NULL,NULL),
 ('3', 'Geomagnetism Detector', 'detector_type', '44', NULL, NULL),
 ('3', '地磁探测器', 'detector_type', '86', NULL, NULL),
 ('3', '地磁探測器', 'detector_type', '87', NULL, NULL),
 ('4', 'Video Detector', 'detector_type', '44', NULL, NULL),
 ('4', '视频探测器', 'detector_type', '86', NULL, NULL),
 ('4', '视频探测器', 'detector_type', '87', NULL, NULL),
 
  ('5', 'AKE Screen', 'detector_type', '44', NULL, NULL),
 ('5', 'AKE屏', 'detector_type', '86', NULL, NULL),
 ('5', 'AKE屏', 'detector_type', '87', NULL, NULL),
 
 ('sysmodel_null_mess', 'Please select the type of map, in order to map checksum', 'common', '44', NULL, NULL),
 ('sysmodel_null_mess', '请先选择地图类型，以便进行地图校验', 'common', '86', NULL, NULL),
 ('sysmodel_null_mess', '請先選擇地圖類型，以便進行地圖校驗', 'common', '87', NULL, NULL),
 ('sysmodel_notmatch', 'System type does not match the current map file type', 'common', '44', NULL, NULL),
 ('sysmodel_notmatch', '系统类型与当前地图文件类型不符', 'common', '86', NULL, NULL),
 ('sysmodel_notmatch', '系統類型與當前地圖檔類型不符', 'common', '87', NULL, NULL),


 ('advertManage', 'Advert_Manage', 'inversion', '44', null, null),
 ('advertManage', '反向寻车广告管理', 'inversion', '86', null, null),
 ('advertManage', '反向寻车廣告管理', 'inversion', '87', null, null),
 ('advertName', 'Advert Name (Click View)', 'inversion', '44', null, null),
 ('advertName', '广告名称 (点击浏览)', 'inversion', '86', null, null),
 ('advertName', '廣告名稱 (點擊瀏覽)', 'inversion', '87', null, null),
 ('advert_manage', 'Advert Manage', 'common', '44', null, null),
 ('advert_manage', '广告管理', 'common', '86', null, null),
 ('advert_manage', '廣告管理', 'common', '87', null, null),
 ('homeAdvertManage', 'Home page manage', 'inversion', '44', null, null),
 ('homeAdvertManage', '首页广告管理', 'inversion', '86', null, null),
 ('homeAdvertManage', '首頁廣告管理', 'inversion', '87', null, null),
 ('searchAdvertManage', 'Search page manage', 'inversion', '44', null, null),
 ('searchAdvertManage', '查询页广告管理', 'inversion', '86', null, null),
 ('searchAdvertManage', '查詢頁廣告管理', 'inversion', '87', null, null),
 ('suggestUploadPX', 'Suggest upload pixel', 'inversion', '44', null, null),
 ('suggestUploadPX', '建议上传的像素为', 'inversion', '86', null, null),
 ('suggestUploadPX', '建議上傳的像素為', 'inversion', '87', null, null),
 ('sizelimit', 'Max_file_size', 'inversion', '44', null, null),
 ('sizelimit', '上传文件的大小限制为', 'inversion', '86', null, null),
 ('sizelimit', '上傳文件的大小限制為', 'inversion', '87', null, null),
 ('advertPlayTime', 'Playing time (seconds)', 'inversion', '44', null, null),
 ('advertPlayTime', '广告播放时间(秒)', 'inversion', '86', null, null),
 ('advertPlayTime', '廣告播放時間(秒)', 'inversion', '87', null, null),
  ('backspace', 'Back', 'inversion', '44', null, null),
 ('backspace', '退格', 'inversion', '86', null, null),
 ('backspace', '退格', 'inversion', '87', null, null),
  ('reset_inversion', 'Reset', 'inversion', '44', null, null),
 ('reset_inversion', '清空', 'inversion', '86', null, null),
 ('reset_inversion', '清空', 'inversion', '87', null, null),
 ('carcode', 'Parking space number', 'inversion', '44', null, null),
 ('carcode', '车位', 'inversion', '86', null, null),
 ('carcode', '車位', 'inversion', '87', null, null),
 ('carnum', 'Car No.', 'inversion', '44', null, null),
 ('carnum', '车牌号码', 'inversion', '86', null, null),
 ('carnum', '車牌號碼', 'inversion', '87', null, null),
 ('exact_search', 'Exact', 'inversion', '44', null, null),
 ('exact_search', '精确查询', 'inversion', '86', null, null),
 ('exact_search', '精確查詢', 'inversion', '87', null, null),
 ('carnum_prompt1', 'Please enter your license plate,', 'inversion', '44', null, null),
 ('carnum_prompt1', '请输入您车牌中的数字部分进行查询,', 'inversion', '86', null, null),
 ('carnum_prompt1', '請輸入您車牌中的數字部分進行查詢,', 'inversion', '87', null, null),
 ('carnum_prompt2', 'Such as 粤A12345, can input A1, 234, etc', 'inversion', '44', null, null),
 ('carnum_prompt2', '如：粤A78C43，请输入7843、784、843等。', 'inversion', '86', null, null),
 ('carnum_prompt2', '如: 粵A78C43，請輸入7843、784、843等。', 'inversion', '87', null, null),
 ('carport_search', 'Space No.', 'inversion', '44', null, null),
 ('carport_search', '车位查询', 'inversion', '86', null, null),
 ('carport_search', '車位查詢', 'inversion', '87', null, null),
 ('searchroute', 'Find Line', 'inversion', '44', null, null),
 ('searchroute', '寻车路线', 'inversion', '86', null, null),
 ('searchroute', '尋車路線', 'inversion', '87', null, null),
 ('change_word', 'En/中', 'inversion', '44', null, null),
 ('change_word', '切换文字', 'inversion', '86', null, null),
 ('change_word', '切換文字', 'inversion', '87', null, null),
 ('choice_date', 'Date', 'inversion', '44', null, null),
 ('choice_date', '选择日期', 'inversion', '86', null, null),
 ('choice_date', '選擇日期', 'inversion', '87', null, null),
 ('choice_time', 'Time', 'inversion', '44', null, null),
 ('choice_time', '选择时间', 'inversion', '86', null, null),
 ('choice_time', '選擇時間', 'inversion', '87', null, null),
 ('clickphoto', 'Picture (Click to view)', 'inversion', '44', null, null),
 ('clickphoto', '图片 (点击浏览)', 'inversion', '86', null, null),
 ('clickphoto', '圖片 (點擊瀏覽)', 'inversion', '87', null, null),
 ('clickpic', 'click to zoom in', 'inversion', '44', null, null),
 ('clickpic', '点击图片放大', 'inversion', '86', null, null),
 ('clickpic', '點擊圖片放大', 'inversion', '87', null, null),
 ('clickupload', 'Upload', 'inversion', '44', null, null),
 ('clickupload', '点击上传', 'inversion', '86', null, null),
 ('clickupload', '點擊上傳', 'inversion', '87', null, null),
 ('close', 'Close', 'inversion', '44', null, null),
 ('close', '关闭', 'inversion', '86', null, null),
 ('close', '關閉', 'inversion', '87', null, null),
 ('code_prompt1', 'Pls input the parking space number', 'inversion', '44', null, null),
 ('code_prompt1', '请输入您停车的车位编号，', 'inversion', '86', null, null),
 ('code_prompt1', '請輸入您停車的車位編號，', 'inversion', '87', null, null),
 ('code_prompt2', 'Such as 0100, can input 010, 100 and so on.', 'inversion', '44', null, null),
 ('code_prompt2', '如：0100，请输入010, 100等', 'inversion', '86', null, null),
 ('code_prompt2', '如：0100，請輸入010, 100等', 'inversion', '87', null, null),
 ('datetime_search', 'Parking Time', 'inversion', '44', null, null),
 ('datetime_search', '时间查询', 'inversion', '86', null, null),
 ('datetime_search', '時間查詢', 'inversion', '87', null, null),
 ('datetime_input', 'Pls choose parking time', 'inversion', '44', null, null),
 ('datetime_input', '请选择停车时间', 'inversion', '86', null, null),
 ('datetime_input', '請選擇停車時間', 'inversion', '87', null, null),
 ('datetime_prompt1', 'Please choose your parking time，', 'inversion', '44', null, null),
 ('datetime_prompt1', '请选择您停车的时间，', 'inversion', '86', null, null),
 ('datetime_prompt1', '請選擇您停車的時間', 'inversion', '87', null, null),
 ('datetime_prompt2', 'Such as: parking at the time of 10 points ', 'inversion', '44', null, null),
 ('datetime_prompt2', '如：在10点至11点的时间段内停车的，请选择10', 'inversion', '86', null, null),
 ('datetime_prompt2', '如：在10點至11點的時間段內停車的，請選擇10', 'inversion', '87', null, null),
 ('datetime_prompt3', 'to 11 points in the 10, please select 10', 'inversion', '44', null, null),
 ('datetime_prompt3', '如：在11点至12点的时间段内停车的，请选择11', 'inversion', '86', null, null),
 ('datetime_prompt3', '如：在11點至12點的時間段內停車的，請選擇11', 'inversion', '87', null, null),
 ('picmovezoom', 'The picture move or resize button', 'inversion', '44', null, null),
 ('picmovezoom', '图片移动或缩放按钮', 'inversion', '86', null, null),
 ('picmovezoom', '圖片移動或縮放按鈕', 'inversion', '87', null, null),
 ('thecurfloor', 'The current floor', 'inversion', '44', null, null),
 ('thecurfloor', '当前楼层', 'inversion', '86', null, null),
 ('thecurfloor', '當前樓層', 'inversion', '87', null, null),
 ('plsmove', 'Pls move', 'inversion', '44', null, null),
 ('plsmove', '请移步', 'inversion', '86', null, null),
 ('plsmove', '請移步', 'inversion', '87', null, null),
 ('nextstep', 'Next step', 'inversion', '44', null, null),
 ('nextstep', '下一步', 'inversion', '86', null, null),
 ('nextstep', '下一步', 'inversion', '87', null, null),
 ('prevstep', 'Prev', 'inversion', '44', null, null),
 ('prevstep', '上一步', 'inversion', '86', null, null),
 ('prevstep', '上一步', 'inversion', '87', null, null),

 ('day', 'D', 'inversion', '44', null, null),
 ('day', '日', 'inversion', '86', null, null),
 ('day', '日', 'inversion', '87', null, null),
 ('delete', 'Delete', 'inversion', '44', null, null),
 ('delete', '删除', 'inversion', '86', null, null),
 ('delete', '刪除', 'inversion', '87', null, null),
 ('enable', 'Enable', 'inversion', '44', null, null),
 ('enable', '启用', 'inversion', '86', null, null),
 ('enable', '啟用', 'inversion', '87', null, null),
 ('end_datetime', 'EndDate', 'inversion', '44', null, null),
 ('end_datetime', '结束日期', 'inversion', '86', null, null),
 ('end_datetime', '結束日期', 'inversion', '87', null, null),
 ('exact_search1', 'Query please enter your license number', 'inversion', '44', null, null),
 ('exact_search1', '请输入您的车牌号码进行查询，', 'inversion', '86', null, null),
 ('exact_search1', '請輸入您的車牌號碼進行查詢', 'inversion', '87', null, null),
 ('exact_search2', 'Such as: 粤A78C43，Please input 78C43', 'inversion', '44', null, null),
 ('exact_search2', '如：粤A78C43，请输入78C43', 'inversion', '86', null, null),
 ('exact_search2', '如：粵A78C43，請輸入78C43', 'inversion', '87', null, null),
 ('example', 'Such as: set the number of days to 10, can every day in the morning began to calculation, save the date in ten days before the photos will be cleared. (value range is: 0-999, 0 means is not clear)', 'inversion', '44', null, null),
 ('example', '例如：设置的天数为10,会在每天凌晨开始计算,保存日期在10天之前的图片将会被清除.(值范围为: 0-999, 0 表示不清除)', 'inversion', '86', null, null),
 ('example', '例如：設置的天數為10,會在每天凌晨開始計算,保存日期在10天之前的圖片將會被清除.(值範圍為: 0-999, 0 表示不清除)', 'inversion', '87', null, null),
 ('fuzzy_search', 'License Plate', 'inversion', '44', null, null),
 ('fuzzy_search', '车牌查询', 'inversion', '86', null, null),
 ('fuzzy_search', '車牌查詢', 'inversion', '87', null, null),
 ('input_carkeyword', 'Input Plate No.', 'inversion', '44', null, null),
 ('input_carkeyword', '请输入车牌号', 'inversion', '86', null, null),
 ('input_carkeyword', '請輸入車牌號', 'inversion', '87', null, null),
 ('input_carnum', 'License plate Number', 'inversion', '44', null, null),
 ('input_carnum', '请输入车牌号码', 'inversion', '86', null, null),
 ('input_carnum', '請輸入車牌號碼', 'inversion', '87', null, null),
 ('input_parkingcode', 'Parking space No.', 'inversion', '44', null, null),
 ('input_parkingcode', '请输入车位编号', 'inversion', '86', null, null),
 ('input_parkingcode', '請輸入車位編號', 'inversion', '87', null, null),
 ('intime', 'In time', 'inversion', '44', null, null),
 ('intime', '进场时间', 'inversion', '86', null, null),
 ('intime', '進場時間', 'inversion', '87', null, null),
 ('inversionSearch', 'Reverse Search Manage', 'inversion', '44', null, null),
 ('inversionSearch', '反向寻车管理', 'inversion', '86', null, null),
 ('inversionSearch', '反向尋車管理', 'inversion', '87', null, null),
 ('inversion_search_manage', 'Reverse search management', 'common', '44', null, null),
 ('inversion_search_manage', '反向寻车管理', 'common', '86', null, null),
 ('inversion_search_manage', '反向尋車管理', 'common', '87', null, null),
 ('month', 'M', 'inversion', '44', null, null),
 ('month', '月', 'inversion', '86', null, null),
 ('month', '月', 'inversion', '87', null, null),
 ('next', 'Next', 'inversion', '44', null, null),
 ('next', '下一页', 'inversion', '86', null, null),
 ('next', '下一頁', 'inversion', '87', null, null),
 ('nowday', 'Now setting day: ', 'inversion', '44', null, null),
 ('nowday', '当前设置的天数:', 'inversion', '86', null, null),
 ('nowday', '當前設置的天數:', 'inversion', '87', null, null),
 ('ok', 'OK', 'inversion', '44', null, null),
 ('ok', '确定', 'inversion', '86', null, null),
 ('ok', '確定', 'inversion', '87', null, null),
 ('operate', 'Operate', 'inversion', '44', null, null),
 ('operate', '操作', 'inversion', '86', null, null),
 ('operate', '操作', 'inversion', '87', null, null),
 ('outtime', 'Out Time', 'inversion', '44', null, null),
 ('outtime', '出场时间', 'inversion', '86', null, null),
 ('outtime', '出場時間', 'inversion', '87', null, null),
 ('paramset', 'Photo storage param Settings', 'inversion', '44', null, null),
 ('paramset', '图片存储参数设置', 'inversion', '86', null, null),
 ('paramset', '圖片存儲參數設置', 'inversion', '87', null, null),
 ('datetimesetup', 'Datetime param Settings', 'inversion', '44', null, null),
 ('datetimesetup', '日期格式设置', 'inversion', '86', null, null),
 ('datetimesetup', '日期格式設置', 'inversion', '87', null, null),
 ('searchhomesetup', 'Search home param Settings', 'inversion', '44', null, null),
 ('searchhomesetup', '寻车首页文字设置', 'inversion', '86', null, null),
 ('searchhomesetup', '尋車首頁文字設置', 'inversion', '87', null, null),
 ('searchhomereturn', 'Search home Return Time', 'inversion', '44', null, null),
 ('searchhomereturn', '寻车返回首页时间设置', 'inversion', '86', null, null),
 ('searchhomereturn', '尋車返回首頁時間設置', 'inversion', '87', null, null),
 ('returnTimeSetup', 'Sets the return time (unit: s seconds, the default 60 seconds)', 'inversion', '44', null, null),
 ('returnTimeSetup', '设置返回时间(单位: 秒, 默认60秒): ', 'inversion', '86', null, null),
 ('returnTimeSetup', '設置返回時間(單位: 秒, 默認60秒): ', 'inversion', '87', null, null),
 ('choicedateformat', 'Please select a vehicle tracking results to show the date and time format', 'inversion', '44', null, null),
 ('choicedateformat', '请选择寻车结果的时间日期要显示的格式', 'inversion', '86', null, null),
 ('choicedateformat', '請選擇尋車結果的時間日期要顯示的格式', 'inversion', '87', null, null),
 ('wordsetup', 'Please enter the car home to display text', 'inversion', '44', null, null),
 ('wordsetup', '请输入寻车机首页要显示的文字', 'inversion', '86', null, null),
 ('wordsetup', '請輸入尋車機首頁要顯示的文字', 'inversion', '87', null, null),
 ('park_datetime', 'Parking-Time', 'inversion', '44', null, null),
 ('park_datetime', '停车时间', 'inversion', '86', null, null),
 ('park_datetime', '停車時間', 'inversion', '87', null, null),
 ('park_space', 'Car Location', 'inversion', '44', null, null),
 ('park_space', '停车位置', 'inversion', '86', null, null),
 ('park_space', '停車位置', 'inversion', '87', null, null),
 ('inversion_param_set', 'Inversion parameter Settings', 'common', '44', null, null),
 ('inversion_param_set', '反向寻车参数设置', 'common', '86', null, null),
 ('inversion_param_set', '反向寻车參數設置', 'common', '87', null, null),
 ('prev', 'Prev Page', 'inversion', '44', null, null),
 ('prev', '上一页', 'inversion', '86', null, null),
 ('prev', '上一頁', 'inversion', '87', null, null),
 ('search_return', 'RT  ', 'inversion', '44', null, null),
 ('search_return', '返回', 'inversion', '86', null, null),
 ('search_return', '返回', 'inversion', '87', null, null),
 ('home', 'HM', 'inversion', '44', null, null),
 ('home', '主页', 'inversion', '86', null, null),
 ('home', '主頁', 'inversion', '87', null, null),
 ('search', 'Query', 'inversion', '44', null, null),
 ('search', '查询', 'inversion', '86', null, null),
 ('search', '查詢', 'inversion', '87', null, null),
 ('searchManage', 'Search Manage', 'inversion', '44', null, null),
 ('searchManage', '查车管理', 'inversion', '86', null, null),
 ('searchManage', '查車管理', 'inversion', '87', null, null),
 ('search_car_manage', 'Search Manage', 'common', '44', null, null),
 ('search_car_manage', '查车管理', 'common', '86', null, null),
 ('search_car_manage', '查車管理', 'common', '87', null, null),
 ('search_subsystem', 'Search Car Subsystem', 'common', '44', null, null),
 ('search_subsystem', '寻车子系统', 'common', '86', null, null),
 ('search_subsystem', '尋車子系統', 'common', '87', null, null),
 ('search_title', 'Car Location Search', 'inversion', '44', null, null),
 ('search_title', '反向寻车', 'inversion', '86', null, null),
 ('search_title', '反向尋車', 'inversion', '87', null, null),
 ('sequence', 'Sequence No.', 'inversion', '44', null, null),
 ('sequence', '序号', 'inversion', '86', null, null),
 ('sequence', '序號', 'inversion', '87', null, null),
 ('setday', 'Days: ', 'inversion', '44', null, null),
 ('setday', '天数: ', 'inversion', '86', null, null),
 ('setday', '天數: ', 'inversion', '87', null, null),
 ('setup', 'Setup', 'inversion', '44', null, null),
 ('setup', '设置', 'inversion', '86', null, null),
 ('setup', '設置', 'inversion', '87', null, null),
 ('start_datetime', 'StartDate', 'inversion', '44', null, null),
 ('start_datetime', '起始日期', 'inversion', '86', null, null),
 ('start_datetime', '起始日期', 'inversion', '87', null, null),
 ('stop_datetime', 'Stop time', 'inversion', '44', null, null),
 ('stop_datetime', '停车 时间', 'inversion', '86', null, null),
 ('stop_datetime', '停車 時間', 'inversion', '87', null, null),
 ('year', 'Y', 'inversion', '44', null, null),
 ('year', '年', 'inversion', '86', null, null),
 ('year', '年', 'inversion', '87', null, null),
 ('dateinfo', 'Click the textbox to select the date of parking.', 'inversion', '44', null, null),
 ('dateinfo', '请点击文本框进行日期时间选择', 'inversion', '86', null, null),
 ('dateinfo', '請點擊文本框進行日期時間選擇', 'inversion', '87', null, null),
 ('searchmachine_manage', 'SearchMachine Config', 'common', '44', null, null),
 ('searchmachine_manage', '查询机配置', 'common', '86', null, null),
 ('searchmachine_manage', '查詢機配置', 'common', '87', null, null),
 ('searchmachine_code', 'Machine Code', 'common', '44', null, null),
 ('searchmachine_code', '查询机编码', 'common', '86', null, null),
 ('searchmachine_code', '查詢機編碼', 'common', '87', null, null),
 ('ip_pattern_mess', 'Invalid format of IP', 'common', '44', null, null),
 ('ip_pattern_mess', 'IP格式错误', 'common', '86', null, null),
 ('ip_pattern_mess', 'IP格式錯誤', 'common', '87', null, null),
 ('no_maps_mess', 'System has no map', 'common', '44', null, null),
 ('no_maps_mess', '当前系统没有地图文件', 'common', '86', null, null),
 ('no_maps_mess', '當前系統沒有地圖檔', 'common', '87', null, null),
 ('notallowtype', '不允许的文件类型,应该为:.png,.bmp,.pjpeg,.jpg,.jpeg,.swf', 'inversion', '86', null, null),
 ('notallowtype', '不允許的文件類型,應該為:.png,.bmp,.pjpeg,.jpg,.jpeg,.swf', 'inversion', '87', null, null),
 ('notallowtype', 'Dont allow the upload file type, should .png,.bmp,.pjpeg,.jpg,.jpeg,.swf', 'inversion', '44', null, null),
 ('debugging', 'Debugging Tool', 'common', '44', null, null),
 ('debugging', '调试工具', 'common', '86', null, null),
 ('debugging', '調試工具', 'common', '87', null, null),
 ('sedatenote', 'Start date cannot be greater than end date', 'inversion', '44', null, null),
 ('sedatenote', '开始日期不能大于结束日期', 'inversion', '86', null, null),
 ('sedatenote', '開始日期不能大於結束日期', 'inversion', '87', null, null),
 ('data_format_error', 'Invalid format of data', 'common', '44', null, null),
 ('data_format_error', '数据格式错误', 'common', '86', null, null),
 ('data_format_error', '數據格式錯誤', 'common', '87', null, null),
 ('timeout_timetocount_mess', 'TimeOut Value must be bigger than Time-to-Count Value', 'common', '44', null, null),
 ('timeout_timetocount_mess', '超时值必须大于开始值', 'common', '86', null, null),
 ('timeout_timetocount_mess', '超時值必須大於開始值', 'common', '87', null, null),
 ('hour_range', 'Range', 'common', '44', null, null),
 ('hour_range', '范围', 'common', '86', null, null),
 ('hour_range', '範圍', 'common', '87', null, null),
 ('screen_set_content','Screen Set Content','common','44',NULL,NULL),
 ('screen_set_content','引导屏设置内容','common','86',NULL,NULL),
 ('screen_set_content','引導屏設置內容','common','87',NULL,NULL),
('postfree', 'Car Post Free', 'common', '44', null, null),
('postfree', '车位空闲', 'common', '86', null, null),
('postfree', '車位空閒', 'common', '87', null, null),
('postinuse', 'Car Post Inuse', 'common', '44', null, null),
('postinuse', '车位占用', 'common', '86', null, null),
('postinuse', '車位佔用', 'common', '87', null, null),
('camera', 'Camera', 'common', '44', null, null),
('camera', '摄像头', 'common', '86', null, null),
('camera', '攝像頭', 'common', '87', null, null),
('warning', 'Warning Message: ', 'common', '44', null, null),
('warning', '警告信息显示如下：', 'common', '86', null, null),
('warning', '警告信息顯示如下：', 'common', '87', null, null),
('warning1', '1. 您的电脑没有安装浏览视频控件。', 'common', '44', null, null),
('warning1', '1. 您的电脑没有安装浏览视频控件。', 'common', '86', null, null),
('warning1', '1. 您的電腦沒有安裝瀏覽視頻控件。', 'common', '87', null, null),
('warning2', '2. 您已经安装控件但版本不是最新，请重新安装控件。', 'common', '44', null, null),
('warning2', '2. 您已经安装控件但版本不是最新，请重新安装控件。', 'common', '86', null, null),
('warning2', '2. 您已經安裝控件但版本不是最新，請重新安裝控件。', 'common', '87', null, null),
('download', 'Download ', 'common', '44', null, null),
('download', '下载', 'common', '86', null, null),
('download', '下載', 'common', '87', null, null),
('runinstall', '然后点击 运行 安装控件，重新刷新网页，浏览视频。 ', 'common', '44', null, null),
('runinstall', '然后点击 运行 安装控件，重新刷新网页，浏览视频。', 'common', '86', null, null),
('runinstall', '然後點擊 運行 安裝控件，重新刷新網頁，瀏覽視頻。', 'common', '87', null, null),
('view_pic_detail', 'View Detail', 'common', '44', null, null),
('view_pic_detail', '查看图例', 'common', '86', null, null),
('view_pic_detail', '查看圖例', 'common', '87', null, null),
('car_plateno', 'Plate No.', 'common', '44', null, null),
('car_plateno', '车牌号', 'common', '86', null, null),
('car_plateno', '車牌號', 'common', '87', null, null),
('car_pictrue', 'Car Image', 'common', '44', null, null),
('car_pictrue', '车辆图片', 'common', '86', null, null),
('car_pictrue', '車輛圖片', 'common', '87', null, null),
('ip_isused', 'IP is Used,Please choose another IP', 'common', '44', null, null),
('ip_isused', 'IP地址已使用，请选择其他IP地址', 'common', '86', null, null),
('ip_isused', 'IP地址已使用，請選擇其他IP地址', 'common', '87', null, null),
('get_new_state', 'Get Newest State', 'common', '44', null, null),
('get_new_state', '获取车位最新状态', 'common', '86', null, null),
('get_new_state', '獲取車位最新狀態', 'common', '87', null, null),
('btn_getnewstate', 'Get', 'common', '44', null, null),
('btn_getnewstate', '获取', 'common', '86', null, null),
('btn_getnewstate', '獲取', 'common', '87', null, null),

('debug_tool', 'DebugTool', 'debugtool', '44', null, null),
('debug_tool', '调试工具', 'debugtool', '86', null, null),
('debug_tool', '調試工具', 'debugtool', '87', null, null),

('video_detector', 'VideoDetector', 'debugtool', '44', null, null),
('video_detector', '视频探测器', 'debugtool', '86', null, null),
('video_detector', '視屏探測器', 'debugtool', '87', null, null),

('screen', 'Screen', 'debugtool', '44', null, null),
('screen', '条屏',   'debugtool', '86', null, null),
('screen', '條屏',   'debugtool', '87', null, null),

('change_final_Ip_gateway', 'Change the terminal IP and GateWay', 'debugtool', '44', null, null),
('change_final_Ip_gateway', '更改终端机IP 网关', 'debugtool', '86', null, null),
('change_final_Ip_gateway', '更改終端機IP 網関', 'debugtool', '87', null, null),

('change_jizhong_Ip_port', 'Change the concentrator IP PortNumber', 'debugtool', '44', null, null),
('change_jizhong_Ip_port', '更改集中器IP 端口号', 'debugtool', '86', null, null),
('change_jizhong_Ip_port', '更改集中器Ip 端口號', 'debugtool', '87', null, null),

('change_final_photo_time', 'Change the terminal shooting period', 'debugtool', '44', null, null),
('change_final_photo_time', '更改终端机拍照周期', 'debugtool', '86', null, null),
('change_final_photo_time', '更改終端機拍照週期', 'debugtool', '87', null, null),

('refresh_status', 'Refresh the Status', 'debugtool', '44', null, null),
('refresh_status', '刷新状态','debugtool', '86', null, null),
('refresh_status', '刷新狀態', 'debugtool', '87', null, null),

('set_enable', 'Set enable', 'debugtool', '44', null, null),
('set_enable', '设置使能','debugtool', '86', null, null),
('set_enable', '設置使能', 'debugtool', '87', null, null),

('set_parking_type', 'Set Parking type', 'debugtool', '44', null, null),
('set_parking_type', '设置车位类型','debugtool', '86', null, null),
('set_parking_type', '設置車位類型', 'debugtool', '87', null, null),

('change_number_parking', 'Change the number of the parking', 'debugtool', '44', null, null),
('change_number_parking', '更改车位编号','debugtool', '86', null, null),
('change_number_parking', '更改車位編號', 'debugtool', '87', null, null),

('video_detector_ip', 'VideoDetectorIP', 'debugtool', '44', null, null),
('video_detector_ip', '视频探测器IP','debugtool', '86', null, null),
('video_detector_ip', '視頻探測器IP', 'debugtool', '87', null, null),

('port_number', 'PortNumber', 'debugtool', '44', null, null),
('port_number', '端口','debugtool', '86', null, null),
('port_number', '端口', 'debugtool', '87', null, null),

('videoDetector_curr_state', 'The Current Status Of VideoDetector', 'debugtool', '44', null, null),
('videoDetector_curr_state', '视频探测器当前状态','debugtool', '86', null, null),
('videoDetector_curr_state', '視頻探測器當前狀態', 'debugtool', '87', null, null),

('parking_number', 'The number of parking', 'debugtool', '44', null, null),
('parking_number', '车位编号','debugtool', '86', null, null),
('parking_number', '車位編號', 'debugtool', '87', null, null),

('parking_type', 'ParkingType', 'debugtool', '44', null, null),
('parking_type', '车位类型','debugtool', '86', null, null),
('parking_type', '車位類型', 'debugtool', '87', null, null),

('parking_status', 'ParkingStatus', 'debugtool', '44', null, null),
('parking_status', '车位状态','debugtool', '86', null, null),
('parking_status', '车位状态', 'debugtool', '87', null, null),

('parking_currstatus', 'ParkingCurrentStatus', 'debugtool', '44', null, null),
('parking_currstatus', '车位当前状态','debugtool', '86', null, null),
('parking_currstatus', '车位當前状态', 'debugtool', '87', null, null),

('picture_bytes', 'The total number of bytes', 'debugtool', '44', null, null),
('picture_bytes', '图片字节总数','debugtool', '86', null, null),
('picture_bytes', '圖片字節總數', 'debugtool', '87', null, null),

('show_picture', 'Show the picture', 'debugtool', '44', null, null),
('show_picture', '显示图片','debugtool', '86', null, null),
('show_picture', '顯示圖片', 'debugtool', '87', null, null),

('parking_type_linshi', 'interim', 'debugtool', '44', null, null),
('parking_type_linshi', '临时','debugtool', '86', null, null),
('parking_type_linshi', '臨時', 'debugtool', '87', null, null),

('parking_type_yuding', 'schedule', 'debugtool', '44', null, null),
('parking_type_yuding', '预定','debugtool', '86', null, null),
('parking_type_yuding', '預定', 'debugtool', '87', null, null),

('parking_type_guding', 'fixed', 'debugtool', '44', null, null),
('parking_type_guding', '固定','debugtool', '86', null, null),
('parking_type_guding', '固定', 'debugtool', '87', null, null),

('parking_status_jinyong', 'forbidden', 'debugtool', '44', null, null),
('parking_status_jinyong', '禁用','debugtool', '86', null, null),
('parking_status_jinyong', '禁用', 'debugtool', '87', null, null),

('parking_status_shineng', 'enable', 'debugtool', '44', null, null),
('parking_status_shineng', '使能','debugtool', '86', null, null),
('parking_status_shineng', '使能', 'debugtool', '87', null, null),

('parking_currstatus_youche', 'a car', 'debugtool', '44', null, null),
('parking_currstatus_youche', '有车','debugtool', '86', null, null),
('parking_currstatus_youche', '有車', 'debugtool', '87', null, null),

('parking_currstatus_wuche', 'carless', 'debugtool', '44', null, null),
('parking_currstatus_wuche', '无车','debugtool', '86', null, null),
('parking_currstatus_wuche', '無車', 'debugtool', '87', null, null),

('alert_please_select_a_video', 'please select a videoDetector at least', 'debugtool', '44', null, null),
('alert_please_select_a_video', '请至少选择一条视频探测器','debugtool', '86', null, null),
('alert_please_select_a_video', '請至少選擇一條視頻探測器', 'debugtool', '87', null, null),

('alert_please_select_a_parking', 'please select a parkingplace at least', 'debugtool', '44', null, null),
('alert_please_select_a_parking', '请至少选择一个车位','debugtool', '86', null, null),
('alert_please_select_a_parking', '請至少選擇一個車位', 'debugtool', '87', null, null),

('alert_parking_number_notnull', 'The number of the parkingplace can not be empty', 'debugtool', '44', null, null),
('alert_parking_number_notnull', '车位编号不能为空!','debugtool', '86', null, null),
('alert_parking_number_notnull', '車位編號不能為空', 'debugtool', '87', null, null),

('alert_Shootingperiod_notnull', 'Shooting Cycle cannot be empty', 'debugtool', '44', null, null),
('alert_Shootingperiod_notnull', '拍照周期不能为空!','debugtool', '86', null, null),
('alert_Shootingperiod_notnull', '拍照週期不能為空!', 'debugtool', '87', null, null),

('alert_Shootingperiod_isNumber', 'Shooting Cycle must be numeric', 'debugtool', '44', null, null),
('alert_Shootingperiod_isNumber', '拍照周期必须是数字!','debugtool', '86', null, null),
('alert_Shootingperiod_isNumber', '拍照週期必須是數字!', 'debugtool', '87', null, null),

('alert_Shootingperiod_bigzero', 'Shooting Cycle must be greater than 0', 'debugtool', '44', null, null),
('alert_Shootingperiod_bigzero', '拍照周期必须大于0!','debugtool', '86', null, null),
('alert_Shootingperiod_bigzero', '拍照周期必须大於0!', 'debugtool', '87', null, null),

('alert_red_label_notempty', 'The red label cannot be empty', 'debugtool', '44', null, null),
('alert_red_label_notempty', '红色标示的不能为空','debugtool', '86', null, null),
('alert_red_label_notempty', '紅色標示的不能為空', 'debugtool', '87', null, null),

('alert_port_number_notcorrect', 'The port number is not correct', 'debugtool', '44', null, null),
('alert_port_number_notcorrect', '端口号不是正确的','debugtool', '86', null, null),
('alert_port_number_notcorrect', '端口號不是正確的', 'debugtool', '87', null, null),

('alert_please_select_ip', 'please select ip:', 'debugtool', '44', null, null),
('alert_please_select_ip', '请选择ip为:','debugtool', '86', null, null),
('alert_please_select_ip', '請選擇ip為:', 'debugtool', '87', null, null),

('alert_please_select_ip_videodetector', 'videodetector:', 'debugtool', '44', null, null),
('alert_please_select_ip_videodetector', '的探测器','debugtool', '86', null, null),
('alert_please_select_ip_videodetector', '的探測器', 'debugtool', '87', null, null),

('new_ip_final', 'New IP Address:', 'debugtool', '44', null, null),
('new_ip_final', '新IP地址:','debugtool', '86', null, null),
('new_ip_final', '新IP地址:', 'debugtool', '87', null, null),

('new_gateway_final', 'New GateWay Address:', 'debugtool', '44', null, null),
('new_gateway_final', '新网关地址:','debugtool', '86', null, null),
('new_gateway_final', '新網関地址:', 'debugtool', '87', null, null),

('new_port_final', 'New Port:', 'debugtool', '44', null, null),
('new_port_final', '端口号:','debugtool', '86', null, null),
('new_port_final', '端口號:', 'debugtool', '87', null, null),

('send_data', 'Send Data:', 'common', '44', null, null),
('send_data', '发送数据:','common', '86', null, null),
('send_data', '發送數據:', 'common', '87', null, null),

('return_data', 'Return Data:', 'common', '44', null, null),
('return_data', '返回数据:','common', '86', null, null),
('return_data', '返回數據:', 'common', '87', null, null),

('new_ip_jizhong', 'The new terminal concentrator IP address:', 'debugtool', '44', null, null),
('new_ip_jizhong', '新终端机集中器IP地址:','debugtool', '86', null, null),
('new_ip_jizhong', '新終端機集成器IP地址:', 'debugtool', '87', null, null),

('new_port_jizhong', 'The new terminal concentrator port number:', 'debugtool', '44', null, null),
('new_port_jizhong', '新终端机集中器端口号:','debugtool', '86', null, null),
('new_port_jizhong', '新終端機集成器端口號:', 'debugtool', '87', null, null),

('new_photo_cycle', 'New shooting period:', 'debugtool', '44', null, null),
('new_photo_cycle', '新拍照周期:',           'debugtool', '86', null, null),
('new_photo_cycle', '新拍照週期:',           'debugtool', '87', null, null),

('new_photo_cycle_unit', 'Unit: s', 'debugtool', '44', null, null),
('new_photo_cycle_unit', '单位:秒(s)', 'debugtool', '86', null, null),
('new_photo_cycle_unit', '單位:秒(s)',  'debugtool', '87', null, null),

('car_parking_enable', 'Parking spaces enable', 'debugtool', '44', null, null),
('car_parking_enable', '车位使能', 'debugtool', '86', null, null),
('car_parking_enable', '車位使能',  'debugtool', '87', null, null),

('alert_ip_length', 'The IP address you entered is not the correct length, must be 7 to 15', 'debugtool', '44', null, null),
('alert_ip_length', '您输入的IP地址长度不正确，必须是7到15位', 'debugtool', '86', null, null),
('alert_ip_length', '您輸入的IP地址長度不正確，必須是7到15位',  'debugtool', '87', null, null),

('alert_gateway_length', 'You enter the gateway address is not the correct length, must be 7 to 15', 'debugtool', '44', null, null),
('alert_gateway_length', '您输入的网关地址长度不正确，必须是7到15位', 'debugtool', '86', null, null),
('alert_gateway_length', '您輸入的網關地址長度不正確，必須是7到15位',  'debugtool', '87', null, null),

('alert_ip_formate', 'The IP address format is not correct, must be in 000.000.000.000 format', 'debugtool', '44', null, null),
('alert_ip_formate', '您输入的IP地址格式不正确，必须是000.000.000.000格式', 'debugtool', '86', null, null),
('alert_ip_formate', '您輸入的IP地址格式不正確，必須是000.000.000.000格式',  'debugtool', '87', null, null),

('alert_gateway_formate', 'The gateway address format is not correct, must be in 000.000.000.000 format', 'debugtool', '44', null, null),
('alert_gateway_formate', '您输入的网关地址格式不正确，必须是000.000.000.000格式', 'debugtool', '86', null, null),
('alert_gateway_formate', '您輸入的網關地址格式不正確，必須是000.000.000.000格式',  'debugtool', '87', null, null),

('alert_ip_scope', 'You enter the IP address range is not correct, must be between 0~255', 'debugtool', '44', null, null),
('alert_ip_scope', '您输入的IP地址范围不正确，必须是0~255之间', 'debugtool', '86', null, null),
('alert_ip_scope', '您輸入的IP地址範圍不正確，必須是0~255之間',  'debugtool', '87', null, null),

('alert_gateway_scope', 'The gateway address range you entered is not correct, must be between 0~255', 'debugtool', '44', null, null),
('alert_gateway_scope', '您输入的网关地址范围不正确，必须是0~255之间', 'debugtool', '86', null, null),

('alert_gateway_scope', '您輸入的網關地址範圍不正確，必須是0~255之間',  'debugtool', '87', null, null),

('ipport_pattern_mess', 'The format of IP port is wrong', 'common', '44', null, null),
('ipport_pattern_mess', 'IP端口格式错误', 'common', '86', null, null),
('ipport_pattern_mess', 'IP端口格式錯誤',  'common', '87', null, null),

('macaddress_pattern_mess', 'The format of MAC address is wrong', 'common', '44', null, null),
('macaddress_pattern_mess', 'MAC地址格式错误', 'common', '86', null, null),
('macaddress_pattern_mess', 'MAC地址格式錯誤',  'common', '87', null, null),

('machine_and_line_point', 'Research Machine,Line Points and Lift', 'common', '44', null, null),
('machine_and_line_point', '查询机、路径点及电梯口', 'common', '86', null, null),
('machine_and_line_point', '查詢機、路徑點及電梯口',  'common', '87', null, null),

('alert_map_chines_extension', 'The map file name containing Chinese characters or is not a SWF file', 'common', '44', NULL, NULL),
('alert_map_chines_extension', '地图文件名含有中文字符或不是swf文件', 'common', '86', NULL, NULL),
('alert_map_chines_extension', '地圖文件含有中文字符或不是swf文件', 'common', '87', NULL, NULL),

('alert_upload_file_not_exist', 'the file is not exist', 'common', '44', NULL, NULL),
('alert_upload_file_not_exist', '上传的文件不存在', 'common', '86', NULL, NULL),
('alert_upload_file_not_exist', '上傳的文件不存在', 'common', '87', NULL, NULL),

('alert_carpark_number_not_correct', 'Parking lot number must be between -127 to 128', 'common', '44', NULL, NULL),
('alert_carpark_number_not_correct', '车位编号必须在-127到128之间', 'common', '86', NULL, NULL),
('alert_carpark_number_not_correct', '車位編號必須在-127到128之间', 'common', '87', NULL, NULL),

 ('select_screen_mess','Please Select Screen','common','44',NULL,NULL),
 ('select_screen_mess','请先选择引导屏','common','86',NULL,NULL),
 ('select_screen_mess','請先選擇引導屏','common','87',NULL,NULL),
 
 ('no_such_guideRegion','No Such GuideRegion','common','44',NULL,NULL),
 ('no_such_guideRegion','没有这个引导方向','common','86',NULL,NULL),
 ('no_such_guideRegion','沒有這個引導方向','common','87',NULL,NULL),
 
 ('impdata_process','Importing Data......','common','44',NULL,NULL),
 ('impdata_process','导入数据中......','common','86',NULL,NULL),
 ('impdata_process','導入數據中......','common','87',NULL,NULL),
 
 ('btn_cancel','Cancel','common','44',NULL,NULL),
 ('btn_cancel','取消','common','86',NULL,NULL),
 ('btn_cancel','取消','common','87',NULL,NULL),
 
 ('ctask_is_run','Controller Task is Running','common','44',NULL,NULL),
 ('ctask_is_run','下发任务正在执行','common','86',NULL,NULL),
 ('ctask_is_run','下發任務正在執行','common','87',NULL,NULL),
 
 ('task_will_stop','Task will stop','common','44',NULL,NULL),
 ('task_will_stop','任务将中断','common','86',NULL,NULL),
 ('task_will_stop','任務將中斷','common','87',NULL,NULL),

 ('please_binding_screen', 'Controller will bind screen, please bind screen first', 'common', '44', NULL, NULL),
 ('please_binding_screen', '管理器会绑定引导屏,请先绑定引导屏', 'common', '86', NULL, NULL),
 ('please_binding_screen', '管理器會綁定引導屏,請先綁定引導屏', 'common', '87', NULL, NULL),

 ('new_mask_final', 'new mask Address', 'debugtool', '44', null, null),
('new_mask_final', '新子网掩码地址', 'debugtool', '86', null, null),
('new_mask_final', '新子網掩碼地址',  'debugtool', '87', null, null),

 ('read_finalmachine_singalstrong', 'Reading Terminal Signal Strength', 'debugtool', '44', NULL, NULL),
 ('read_finalmachine_singalstrong', '读取终端机信号强度', 'debugtool', '86', NULL, NULL),
 ('read_finalmachine_singalstrong', '讀取終端機信號強度', 'debugtool', '87', NULL, NULL),
 
 ('read_final_version', 'Reading Terminal program version number', 'debugtool', '44', NULL, NULL),
 ('read_final_version', '读取终端机版本号', 'debugtool', '86', NULL, NULL),
 ('read_final_version', '讀取終端機版本號', 'debugtool', '87', NULL, NULL),
 
 ('set_mac_addresss', 'Read and set the Mac address of agreement', 'debugtool', '44', NULL, NULL),
 ('set_mac_addresss', '读取和设置Mac地址', 'debugtool', '86', NULL, NULL),
 ('set_mac_addresss', '讀取和設置Mac地址', 'debugtool', '87', NULL, NULL),
 
 ('change_network_identfi', 'Change the preferred network identification', 'debugtool', '44', NULL, NULL),
 ('change_network_identfi', '读取和更改首选网络标识', 'debugtool', '86', NULL, NULL),
 ('change_network_identfi', '读取和更改首選網絡標識', 'debugtool', '87', NULL, NULL),
 
  ('total_length_data', 'Total length of the data', 'debugtool', '44', NULL, NULL),
 ('total_length_data', '数据总长度', 'debugtool', '86', NULL, NULL),
 ('total_length_data', '數據總長度', 'debugtool', '87', NULL, NULL),
 
 ('AP_length_name', 'AP name length', 'debugtool', '44', NULL, NULL),
 ('AP_length_name', 'AP名称长度', 'debugtool', '86', NULL, NULL),
 ('AP_length_name', 'AP名稱長度', 'debugtool', '87', NULL, NULL),
 
 ('AP_name', 'AP name ', 'debugtool', '44', NULL, NULL),
 ('AP_name', 'AP名称', 'debugtool', '86', NULL, NULL),
 ('AP_name', 'AP名稱', 'debugtool', '87', NULL, NULL),

('Signal_strength', 'Signal strength', 'debugtool', '44', NULL, NULL),
 ('Signal_strength', '信号强度', 'debugtool', '86', NULL, NULL),
 ('Signal_strength', '信號強度', 'debugtool', '87', NULL, NULL),
 
 ('No_signal', 'No signal', 'debugtool', '44', NULL, NULL),
 ('No_signal', '无信号', 'debugtool', '86', NULL, NULL),
 ('No_signal', '無信號', 'debugtool', '87', NULL, NULL),

  ('comm_unstab', 'Communication unstable', 'debugtool', '44', NULL, NULL),
 ('comm_unstab', '通讯不稳定', 'debugtool', '86', NULL, NULL),
 ('comm_unstab', '通訊不穩定', 'debugtool', '87', NULL, NULL),
 
 ('comm_normal', 'Normal communication', 'debugtool', '44', NULL, NULL),
 ('comm_normal', '通讯正常', 'debugtool', '86', NULL, NULL),
 ('comm_normal', '通訊正常', 'debugtool', '87', NULL, NULL),
 
  ('version_length', 'Content length version', 'debugtool', '44', NULL, NULL),
 ('version_length', '版本号内容长度', 'debugtool', '86', NULL, NULL),
 ('version_length', '版本號內容長度', 'debugtool', '87', NULL, NULL),
 
 ('version_content', 'Content Of version', 'debugtool', '44', NULL, NULL),
 ('version_content', '版本号内容', 'debugtool', '86', NULL, NULL),
 ('version_content', '版本號內容', 'debugtool', '87', NULL, NULL),
 
 
 ('mac_addr_content', 'Mac Address Content', 'debugtool', '44', NULL, NULL),
 ('mac_addr_content', 'Mac地址内容', 'debugtool', '86', NULL, NULL),
 ('mac_addr_content', 'Mac地址內容', 'debugtool', '87', NULL, NULL),
 
  ('mac_addcon_length', 'Mac address content length', 'debugtool', '44', NULL, NULL),
 ('mac_addcon_length', 'Mac地址内容长度', 'debugtool', '86', NULL, NULL),
 ('mac_addcon_length', 'Mac地址內容長度', 'debugtool', '87', NULL, NULL),
 
  ('para_setup', 'Parameter settings', 'common', '44', NULL, NULL),
 ('para_setup', '参数设置', 'common', '86', NULL, NULL),
 ('para_setup', '參數設置', 'common', '87', NULL, NULL),
 
 ('base_para_setup', 'Basic parameter settings', 'common', '44', NULL, NULL),
 ('base_para_setup', '基础参数设置', 'common', '86', NULL, NULL),
 ('base_para_setup', '基礎參數設置', 'common', '87', NULL, NULL),
 
  ('stand_send', 'Standard transmission', 'common', '44', NULL, NULL),
 ('stand_send', '标准发送', 'common', '86', NULL, NULL),
 ('stand_send', '標準發送', 'common', '87', NULL, NULL),
 
   ('group_addr_set', 'Group address set', 'common', '44', NULL, NULL),
 ('group_addr_set', '组地址设置', 'common', '86', NULL, NULL),
 ('group_addr_set', '組地址設置', 'common', '87', NULL, NULL),
 
  ('screen_para_setup', 'Parameter settings of the screen', 'common', '44', NULL, NULL),
 ('screen_para_setup', '条屏参数设置', 'common', '86', NULL, NULL),
 ('screen_para_setup', '條屏參數設置', 'common', '87', NULL, NULL),
 
 ('ser_port_setup', 'Serial port settings', 'common', '44', NULL, NULL),
 ('ser_port_setup', '串口设置', 'common', '86', NULL, NULL),
 ('ser_port_setup', '串口設置', 'common', '87', NULL, NULL),
 
  ('ser_port', 'Serial port', 'common', '44', NULL, NULL),
 ('ser_port', '串口', 'common', '86', NULL, NULL),
 ('ser_port', '串口', 'common', '87', NULL, NULL),
 
 ('bit_width', 'Width', 'common', '44', NULL, NULL),
 ('bit_width', '宽度', 'common', '86', NULL, NULL),
 ('bit_width', '寬度', 'common', '87', NULL, NULL),
 
 ('bit_heigth', 'Height', 'common', '44', NULL, NULL),
 ('bit_heigth', '高度', 'common', '86', NULL, NULL),
 ('bit_heigth', '高度', 'common', '87', NULL, NULL),
 
 ('x_Off', 'X Offset', 'common', '44', NULL, NULL),
 ('x_Off', 'X偏移', 'common', '86', NULL, NULL),
 ('x_Off', 'X偏移', 'common', '87', NULL, NULL),
 
  ('y_Off', 'Y Offset', 'common', '44', NULL, NULL),
 ('y_Off', 'Y偏移', 'common', '86', NULL, NULL),
 ('y_Off', 'Y偏移', 'common', '87', NULL, NULL),
 
 ('drive_select', 'Drive Select', 'common', '44', NULL, NULL),
 ('drive_select', '驱动选择', 'common', '86', NULL, NULL),
 ('drive_select', '驅動選擇', 'common', '87', NULL, NULL),
 
 ('enable_reverse', 'Enable Reverse', 'common', '44', NULL, NULL),
 ('enable_reverse', '使能反向', 'common', '86', NULL, NULL),
 ('enable_reverse', '使能反向', 'common', '87', NULL, NULL),
 
  ('anti_color_dis', 'Anti-color display', 'common', '44', NULL, NULL),
 ('anti_color_dis', '反色显示', 'common', '86', NULL, NULL),
 ('anti_color_dis', '反色顯示', 'common', '87', NULL, NULL),
 
 ('scannin_method', 'Scanning', 'common', '44', NULL, NULL),
 ('scannin_method', '扫描方式', 'common', '86', NULL, NULL),
 ('scannin_method', '掃描方式', 'common', '87', NULL, NULL),
 
 ('dis_screen_setup', 'The display settings', 'common', '44', NULL, NULL),
 ('dis_screen_setup', '显示屏设置', 'common', '86', NULL, NULL),
 ('dis_screen_setup', '顯示屏設置', 'common', '87', NULL, NULL),
 
 ('stay_time', 'Residence time', 'common', '44', NULL, NULL),
 ('stay_time', '停留时间', 'common', '86', NULL, NULL),
 ('stay_time', '停留時間', 'common', '87', NULL, NULL),
 
 ('screen_bright', 'Brightness', 'common', '44', NULL, NULL),
 ('screen_bright', '亮度', 'common', '86', NULL, NULL),
 ('screen_bright', '亮度', 'common', '87', NULL, NULL),
 
  ('duty_cycle', 'duty cycle', 'common', '44', NULL, NULL),
 ('duty_cycle', '占空比', 'common', '86', NULL, NULL),
 ('duty_cycle', '佔空比', 'common', '87', NULL, NULL),
 
 ('screen_color', 'color', 'common', '44', NULL, NULL),
 ('screen_color', '顏色', 'common', '86', NULL, NULL),
 ('screen_color', '颜色', 'common', '87', NULL, NULL),
 
 ('screen_font', 'Font', 'common', '44', NULL, NULL),
 ('screen_font', '字体', 'common', '86', NULL, NULL),
 ('screen_font', '字體', 'common', '87', NULL, NULL),
 
 ('com_old', 'Compatible with the old', 'common', '44', NULL, NULL),
 ('com_old', '兼容旧款', 'common', '86', NULL, NULL),
 ('com_old', '兼容舊款', 'common', '87', NULL, NULL),
 
 ('deliver_option', 'Delivery Options', 'common', '44', NULL, NULL),
 ('deliver_option', '发送选项', 'common', '86', NULL, NULL),
 ('deliver_option', '發送選項', 'common', '87', NULL, NULL),
 
 ('trans_time', 'Transmission times', 'common', '44', NULL, NULL),
 ('trans_time', '发送次数', 'common', '86', NULL, NULL),
 ('trans_time', '發送次數', 'common', '87', NULL, NULL),
 
 ('wait_time', 'Wait Time', 'common', '44', NULL, NULL),
 ('wait_time', '等待时间', 'common', '86', NULL, NULL),
 ('wait_time', '等待時間', 'common', '87', NULL, NULL),
 
 ('number_success', 'The number of successes', 'common', '44', NULL, NULL),
 ('number_success', '成功次数', 'common', '86', NULL, NULL),
 ('number_success', '成功次數', 'common', '87', NULL, NULL),
 
 ('success_rate', 'success rate', 'common', '44', NULL, NULL),
 ('success_rate', '成功率', 'common', '86', NULL, NULL),
 ('success_rate', '成功率', 'common', '87', NULL, NULL),
 
   ('send_order', 'Send', 'common', '44', NULL, NULL),
 ('send_order', '发送', 'common', '86', NULL, NULL),
 ('send_order', '發送', 'common', '87', NULL, NULL),
 
  ('aging_order', 'age', 'common', '44', NULL, NULL),
 ('aging_order', '老化', 'common', '86', NULL, NULL),
 ('aging_order', '老化', 'common', '87', NULL, NULL),
 
  ('dtu_order', 'DTU forwarding', 'common', '44', NULL, NULL),
 ('dtu_order', 'DTU转发', 'common', '86', NULL, NULL),
 ('dtu_order', 'DTU轉發', 'common', '87', NULL, NULL),
 
  ('full_screen_order', 'Full screen', 'common', '44', NULL, NULL),
 ('full_screen_order', '满屏', 'common', '86', NULL, NULL),
 ('full_screen_order', '滿屏', 'common', '87', NULL, NULL),
 
  ('clean_screen_order', 'Clean screen', 'common', '44', NULL, NULL),
 ('clean_screen_order', '清屏', 'common', '86', NULL, NULL),
 ('clean_screen_order', '清屏', 'common', '87', NULL, NULL),
 
   ('loop_send_order', 'Loop send', 'common', '44', NULL, NULL),
 ('loop_send_order', '循环发送', 'common', '86', NULL, NULL),
 ('loop_send_order', '循環發送', 'common', '87', NULL, NULL),
 
 ('first_AP_len', 'The preferred AP name length', 'common', '44', NULL, NULL),
 ('first_AP_len', '首选AP名称长度', 'common', '86', NULL, NULL),
 ('first_AP_len', '首選AP名稱長度', 'common', '87', NULL, NULL),
 
  ('first_AP_name', 'The preferred AP name ', 'common', '44', NULL, NULL),
 ('first_AP_name', '首选AP名称', 'common', '86', NULL, NULL),
 ('first_AP_name', '首選AP名稱', 'common', '87', NULL, NULL),
 
   ('encry_type', 'EncryptType ', 'common', '44', NULL, NULL),
 ('encry_type', '加密类型', 'common', '86', NULL, NULL),
 ('encry_type', '加密類型', 'common', '87', NULL, NULL),
 
  ('key_str_length', 'Key string length', 'common', '44', NULL, NULL),
 ('key_str_length', '密钥字符串长度', 'common', '86', NULL, NULL),
 ('key_str_length', '密鈅字符串長度', 'common', '87', NULL, NULL),
 
  ('secret_key', 'SecretKey', 'common', '44', NULL, NULL),
 ('secret_key', '密钥', 'common', '86', NULL, NULL),
 ('secret_key', '密鈅', 'common', '87', NULL, NULL),
 
 ('sheet_name', 'Sheet Name', 'common', '44', NULL, NULL),
 ('sheet_name', '表单名', 'common', '86', NULL, NULL),
 ('sheet_name', '表單名', 'common', '87', NULL, NULL),
 
 ('notmatch_mapname', 'Not Match With Map Name', 'common', '44', NULL, NULL),
 ('notmatch_mapname', '与地图名不符', 'common', '86', NULL, NULL),
 ('notmatch_mapname', '與地圖名不符', 'common', '87', NULL, NULL),
 
  ('fileupload_failed', 'File Upload Failed', 'common', '44', NULL, NULL),
 ('fileupload_failed', '文件上传失败', 'common', '86', NULL, NULL),
 ('fileupload_failed', '文件上傳失敗', 'common', '87', NULL, NULL),
 
 ('excel_file_path', 'Excel File Path', 'common', '44', NULL, NULL),
 ('excel_file_path', 'Excel文件路径', 'common', '86', NULL, NULL),
 ('excel_file_path', 'Excel文件路徑', 'common', '87', NULL, NULL),
 
 ('excel_file_imp', 'Excel File Import', 'common', '44', NULL, NULL),
 ('excel_file_imp', 'Excel文件导入', 'common', '86', NULL, NULL),
 ('excel_file_imp', 'Excel文件導入', 'common', '87', NULL, NULL),
 
 ('mapdata_export_excel', 'Map Data Export', 'common', '44', NULL, NULL),
 ('mapdata_export_excel', '地图数据导出', 'common', '86', NULL, NULL),
 ('mapdata_export_excel', '地圖數據導出', 'common', '87', NULL, NULL),
 
 ('mapdata_import_excel', 'Excel Data Import', 'common', '44', NULL, NULL),
 ('mapdata_import_excel', 'Excel数据导入', 'common', '86', NULL, NULL),
 ('mapdata_import_excel', 'Excel數據導入', 'common', '87', NULL, NULL),
 
 ('operation_type', 'Operation Type', 'common', '44', NULL, NULL),
 ('operation_type', '操作类型', 'common', '86', NULL, NULL),
 ('operation_type', '操作類型', 'common', '87', NULL, NULL),
 
 ('result_mess', 'Result', 'common', '44', NULL, NULL),
 ('result_mess', '结果', 'common', '86', NULL, NULL),
 ('result_mess', '結果', 'common', '87', NULL, NULL),
 
 ('error_mess', 'Error Message', 'common', '44', NULL, NULL),
 ('error_mess', '出错信息', 'common', '86', NULL, NULL),
 ('error_mess', '出錯信息', 'common', '87', NULL, NULL),
 
 ('user_ipaddr', 'User IP Address', 'common', '44', NULL, NULL),
 ('user_ipaddr', '用户IP地址', 'common', '86', NULL, NULL),
 ('user_ipaddr', '用戶IP地址', 'common', '87', NULL, NULL),
 
 ('sys_operator_log', 'System Operation Log', 'common', '44', NULL, NULL),
 ('sys_operator_log', '系统操作日志', 'common', '86', NULL, NULL),
 ('sys_operator_log', '系統操作日誌', 'common', '87', NULL, NULL),
 
 ('map_liftcode_error', 'The code of the current map is not match these in DB', 'common', '44', NULL, NULL),
 ('map_liftcode_error', '当前地图电梯点编号与其他地图不一致', 'common', '86', NULL, NULL),
 ('map_liftcode_error', '當前地圖電梯點編號與其他地圖不一致', 'common', '87', NULL, NULL),
 
 ('map_liftnum_error', 'The lift point number is no equal to these in DB', 'common', '44', NULL, NULL),
 ('map_liftnum_error', '当前地图电梯点的数量与其他地图电梯点数量不相等', 'common', '86', NULL, NULL),
 ('map_liftnum_error', '當前地圖電梯點的數量與其他地圖電梯點數量不相等', 'common', '87', NULL, NULL),
 
 ('con_delete_mess', 'The number of Controller deleted is', 'common', '44', NULL, NULL),
 ('con_delete_mess', '删除管理器', 'common', '86', NULL, NULL),
 ('con_delete_mess', '刪除管理器', 'common', '87', NULL, NULL),
 
 ('det_delete_mess', 'The number of Detector deleted is', 'common', '44', NULL, NULL),
 ('det_delete_mess', '删除探测器', 'common', '86', NULL, NULL),
 ('det_delete_mess', '刪除探測器', 'common', '87', NULL, NULL),
 
 ('gro_delete_mess', 'The number of Grounder deleted is', 'common', '44', NULL, NULL),
 ('gro_delete_mess', '删除地感', 'common', '86', NULL, NULL),
 ('gro_delete_mess', '刪除地感', 'common', '87', NULL, NULL),
 
 ('screen_delete_mess', 'The number of Screen deleted is', 'common', '44', NULL, NULL),
 ('screen_delete_mess', '删除引导屏', 'common', '86', NULL, NULL),
 ('screen_delete_mess', '刪除引導屏', 'common', '87', NULL, NULL),
 
 ('unit_mess', 'individual', 'common', '44', NULL, NULL),
 ('unit_mess', '个', 'common', '86', NULL, NULL),
 ('unit_mess', '個', 'common', '87', NULL, NULL),
 
 ('grounder_mess', 'Grounder', 'common', '44', NULL, NULL),
 ('grounder_mess', '地感', 'common', '86', NULL, NULL),
 ('grounder_mess', '地感', 'common', '87', NULL, NULL),
 
 ('update_map_mess', 'Upload Map File And Verify Data Successfully, Then Please Import Data', 'common', '44', NULL, NULL),
 ('update_map_mess', '上传地图文件、校验地图数据成功，下一步请导入地图数据', 'common', '86', NULL, NULL),
 ('update_map_mess', '上傳地圖文件、校驗地圖數據成功，下一步請導入地圖數據', 'common', '87', NULL, NULL),
 
 ('new_map_path', 'New MapFile', 'common', '44', NULL, NULL),
 ('new_map_path', '新地图文件', 'common', '86', NULL, NULL),
 ('new_map_path', '新地圖文件', 'common', '87', NULL, NULL),
 
 ('viewScreen', 'View Screen', 'common', '44', null, null),
 ('viewScreen', '引导信息屏', 'common', '86', null, null),
 ('viewScreen', '引導信息屏', 'common', '87', null, null),
 ('kiosks', 'Search Machine', 'common', '44', null, null),
 ('kiosks', '查询机', 'common', '86', null, null),
 ('kiosks', '查詢機', 'common', '87', null, null),
 ('inuseovertime', 'Take a timeout', 'common', '44', null, null),
 ('inuseovertime', '占用超时', 'common', '86', null, null),
 ('inuseovertime', '佔用超時', 'common', '87', null, null),
 
 ('startDate', 'Start Date', 'common', '44', null, null),
 ('startDate', '开始日期', 'common', '86', null, null),
 ('startDate', '開始日期', 'common', '87', null, null),
 ('endDate', 'End Date', 'common', '44', null, null),
 ('endDate', '结束日期', 'common', '86', null, null),
 ('endDate', '結束日期', 'common', '87', null, null),
 ('inputCarNumOrCode', 'Input CarNum Or Code', 'common', '44', null, null),
 ('inputCarNumOrCode', '请输入车牌号或车位编号', 'common', '86', null, null),
 ('inputCarNumOrCode', '請輸入車牌號或車位編號', 'common', '87', null, null),
 ('sequence', 'Sequence No.', 'common', '44', null, null),
 ('sequence', '序号', 'common', '86', null, null),
 ('sequence', '序號', 'common', '87', null, null),
 ('carNum', 'Car No.', 'common', '44', null, null),
 ('carNum', '车牌号码', 'common', '86', null, null),
 ('carNum', '車牌號碼', 'common', '87', null, null),
 ('parkTime', 'Park Time', 'common', '44', null, null),
 ('parkTime', '进场时间', 'common', '86', null, null),
 ('parkTime', '進場時間', 'common', '87', null, null),
 ('quitTime', 'Quit Time', 'common', '44', null, null),
 ('quitTime', '出场时间', 'common', '86', null, null),
 ('quitTime', '出場時間', 'common', '87', null, null),
 ('currentFloor', 'Current Floor', 'common', '44', null, null),
 ('currentFloor', '所在楼层', 'common', '86', null, null),
 ('currentFloor', '所在楼层', 'common', '87', null, null),
 ('prev_page', 'Prev Page', 'common', '44', null, null),
 ('prev_page', '上一页', 'common', '86', null, null),
 ('prev_page', '上一頁', 'common', '87', null, null),
 ('next_page', 'Next Page', 'common', '44', null, null),
 ('next_page', '下一页', 'common', '86', null, null),
 ('next_page', '下一頁', 'common', '87', null, null),
 ('areaName', 'Area Name', 'common', '44', null, null),
 ('areaName', '所在区域', 'common', '86', null, null),
 ('areaName', '所在區域', 'common', '87', null, null),
 ('upload_map_jpg', 'Upload Map Jpg Image', 'common', '44', null, null),
 ('upload_map_jpg', '上传地图jpg图片', 'common', '86', null, null),
 ('upload_map_jpg', '上傳地圖jpg圖片', 'common', '87', null, null),
 
 ('all_ud_duration', 'All UD Online or Outline Duration', 'common', '44', NULL, NULL),
 ('all_ud_duration', '所有探测器在线、离线时长', 'common', '86', NULL, NULL),
 ('all_ud_duration', '所有探測器在線、離線時長', 'common', '87', NULL, NULL),
 ('all_ud_rate', 'All UD Outline Rate', 'common', '44', NULL, NULL),
 ('all_ud_rate', '所有探测器离线率', 'common', '86', NULL, NULL),
 ('all_ud_rate', '所有探測器離線率', 'common', '87', NULL, NULL),
 ('connect_desc', 'Connect Description', 'common', '44', NULL, NULL),
 ('connect_desc', '状态描述', 'common', '86', NULL, NULL),
 ('connect_desc', '狀態描述', 'common', '87', NULL, NULL),
 ('connect_type', 'Connect Type', 'common', '44', NULL, NULL),
 ('connect_type', '连接类型', 'common', '86', NULL, NULL),
 ('connect_type', '連接類型', 'common', '87', NULL, NULL),
 ('detector_cid', 'Detector ID', 'common', '44', NULL, NULL),
 ('detector_cid', '探测器编号', 'common', '86', NULL, NULL),
 ('detector_cid', '探測器編號', 'common', '87', NULL, NULL),
 ('detector_mac_addr', 'Detector Mac Address', 'common', '44', NULL, NULL),
 ('detector_mac_addr', '物理地址', 'common', '86', NULL, NULL),
 ('detector_mac_addr', '物理地址', 'common', '87', NULL, NULL),
 ('half_connect', 'Half Connect', 'common', '44', NULL, NULL),
 ('half_connect', '半连接', 'common', '86', NULL, NULL),
 ('half_connect', '半連接', 'common', '87', NULL, NULL),
 ('not_connect', 'Disconnect', 'common', '44', NULL, NULL),
 ('not_connect', '未连接', 'common', '86', NULL, NULL),
 ('not_connect', '未連接', 'common', '87', NULL, NULL),
 ('online_last_time', 'Last Online Time', 'common', '44', NULL, NULL),
 ('online_last_time', '最后一次上线时间', 'common', '86', NULL, NULL),
 ('online_last_time', '最後一次上線時間', 'common', '87', NULL, NULL),
 ('online_time', 'Online Before of Time', 'common', '44', NULL, NULL),
 ('online_time', '最后上线时间小于', 'common', '86', NULL, NULL),
 ('online_time', '最後上線時間小於', 'common', '87', NULL, NULL),
 ('online_times', 'Online Times', 'common', '44', NULL, NULL),
 ('online_times', '上线次数', 'common', '86', NULL, NULL),
 ('online_times', '上線次數', 'common', '87', NULL, NULL),
 ('online_times_more', 'Online Times more than', 'common', '44', NULL, NULL),
 ('online_times_more', '时段内上线次数大于', 'common', '86', NULL, NULL),
 ('online_times_more', '時段內上線次數大於', 'common', '87', NULL, NULL),
 ('on_out_duration', 'On or Out Duration', 'common', '44', NULL, NULL),
 ('on_out_duration', '时长', 'common', '86', NULL, NULL),
 ('on_out_duration', '時長', 'common', '87', NULL, NULL),
 ('outline_last_time', 'Last Outline Times', 'common', '44', NULL, NULL),
 ('outline_last_time', '最后一次离线时间', 'common', '86', NULL, NULL),
 ('outline_last_time', '最後一次離線時間', 'common', '87', NULL, NULL),
 ('outline_rate', 'Outline Rate', 'common', '44', NULL, NULL),
 ('outline_rate', '离线率', 'common', '86', NULL, NULL),
 ('outline_rate', '離線率', 'common', '87', NULL, NULL),
 ('outline_time', 'Outline Before of Time', 'common', '44', NULL, NULL),
 ('outline_time', '最后离线时间小于', 'common', '86', NULL, NULL),
 ('outline_time', '最後離線時間小於', 'common', '87', NULL, NULL),
 ('outline_times', 'Outline Times', 'common', '44', NULL, NULL),
 ('outline_times', '离线次数', 'common', '86', NULL, NULL),
 ('outline_times', '離線次數', 'common', '87', NULL, NULL),
 ('outline_times_more', 'Outline Times more than', 'common', '44', NULL, NULL),
 ('outline_times_more', '时段内离线次数大于', 'common', '86', NULL, NULL),
 ('outline_times_more', '時段內離線次數大於', 'common', '87', NULL, NULL),
 ('outline_ud', 'Outline Detector', 'common', '44', NULL, NULL),
 ('outline_ud', '离线探测器', 'common', '86', NULL, NULL),
 ('outline_ud', '離線探測器', 'common', '87', NULL, NULL),
 ('refer_duration', 'Refer to Duration', 'common', '44', NULL, NULL),
 ('refer_duration', '按时长查询', 'common', '86', NULL, NULL),
 ('refer_duration', '按時長查詢', 'common', '87', NULL, NULL),
 ('refer_outline_rate', 'Refer to Outline Rate', 'common', '44', NULL, NULL),
 ('refer_outline_rate', '按离线率查询', 'common', '86', NULL, NULL),
 ('refer_outline_rate', '按離線率查詢', 'common', '87', NULL, NULL),
 ('ud_working_graph', 'UD Working Statistics Graph', 'common', '44', NULL, NULL),
 ('ud_working_graph', '视频探测器运行统计图', 'common', '86', NULL, NULL),
 ('ud_working_graph', '視頻探測器運行統計圖', 'common', '87', NULL, NULL),
 ('ud_working_record', 'UD Working Record', 'common', '44', NULL, NULL),
 ('ud_working_record', '视频探测器运行情况', 'common', '86', NULL, NULL),
 ('ud_working_record', '視頻探測器運行情況', 'common', '87', NULL, NULL),
 ('ud_working_statistics', 'UD Working Statistics', 'common', '44', NULL, NULL),
 ('ud_working_statistics', '视频探测器运行情况统计', 'common', '86', NULL, NULL),
 ('ud_working_statistics', '視頻探測器運行情況統計', 'common', '87', NULL, NULL),
 ('inline', 'Inline', 'common', '44', NULL, NULL),
 ('inline', '上线', 'common', '86', NULL, NULL),
 ('inline', '上線', 'common', '87', NULL, NULL),
 ('outline', 'Outline', 'common', '44', NULL, NULL),
 ('outline', '离线', 'common', '86', NULL, NULL),
 ('outline', '離線', 'common', '87', NULL, NULL),
 ('suggest_do_bug', 'Suggest of deal with the BUG', 'common', '44', NULL, NULL),
 ('suggest_do_bug', '故障处理建议', 'common', '86', NULL, NULL),
 ('suggest_do_bug', '故障處理建議', 'common', '87', NULL, NULL),
 ('export_excel_btn', 'Export', 'common', '44', NULL, NULL),
 ('export_excel_btn', '导出', 'common', '86', NULL, NULL),
 ('export_excel_btn', '導出', 'common', '87', NULL, NULL),
 ('four_for_ud', 'Four Space for a UD', 'common', '44', null, null),
 ('four_for_ud', '一对四', 'common', '86', null, null),
 ('four_for_ud', '一對四', 'common', '87', null, null),
 ('one_for_ud', 'One Space for a UD', 'common', '44', null, null),
 ('one_for_ud', '一对一', 'common', '86', null, null),
 ('one_for_ud', '一對一', 'common', '87', null, null),
 ('parkspace_turnover_rate', 'Park Space Turnover Rate', 'common', '44', null, null),
 ('parkspace_turnover_rate', '车位周转率', 'common', '86', null, null),
 ('parkspace_turnover_rate', '車位周轉率', 'common', '87', null, null),
 ('three_for_ud', 'Three Space for a UD', 'common', '44', null, null),
 ('three_for_ud', '一对三', 'common', '86', null, null),
 ('three_for_ud', '一對三', 'common', '87', null, null),
 ('two_for_ud', 'Double Space for a UD', 'common', '44', null, null),
 ('two_for_ud', '一对二', 'common', '86', null, null),
 ('two_for_ud', '一對二', 'common', '87', null, null),
 
 ('time_point', '时间点', 'common', '86', NULL, NULL),
('time_point', 'Time Point', 'common', '44', NULL, NULL),
('time_point', '時間點', 'common', '87', NULL, NULL),
('ud_out_num', '离线个数', 'common', '86', NULL, NULL),
('ud_out_num', 'UD Out Number', 'common', '44', NULL, NULL),
('ud_out_num', '離線個數', 'common', '87', NULL, NULL),
('all_ud_in_park', '停车场探测器总数为', 'common', '86', NULL, NULL),
('all_ud_in_park', 'All UD In Park', 'common', '44', NULL, NULL),
('all_ud_in_park', '停車場探測器總數為', 'common', '87', NULL, NULL),
('turnover_rate', '周转率', 'common', '86', NULL, NULL),
('turnover_rate', 'Turnover Rate', 'common', '44', NULL, NULL),
('turnover_rate', '周轉率', 'common', '87', NULL, NULL),
('turnover_number', '周转数', 'common', '86', NULL, NULL),
('turnover_number', 'Turnover Number', 'common', '44', NULL, NULL),
('turnover_number', '周转數', 'common', '87', NULL, NULL),
('data', '数值', 'common', '86', NULL, NULL),
('data', 'Data', 'common', '44', NULL, NULL),
('data', '數值', 'common', '87', NULL, NULL),
('fuzzy_query', '模糊查詢', 'common', '87', NULL, NULL),
('fuzzy_query', 'Fuzzy Query', 'common', '44', NULL, NULL),
('fuzzy_query', '模糊查询', 'common', '86', NULL, NULL),
('car_query', '车牌查询', 'common', '86', NULL, NULL),
('car_query', 'Car Query', 'common', '44', NULL, NULL),
('car_query', '車牌查詢', 'common', '87', NULL, NULL),
('time_query', '时间查询', 'common', '86', NULL, NULL),
('time_query', 'Time Query', 'common', '44', NULL, NULL),
('time_query', '時間查詢', 'common', '87', NULL, NULL),
('pot_query', '车位查询', 'common', '86', NULL, NULL),
('pot_query', 'Pot Query', 'common', '44', NULL, NULL),
('pot_query', '車位查詢', 'common', '87', NULL, NULL),
('no_car_query', '无牌查询', 'common', '86', NULL, NULL),
('no_car_query', 'No Car Query', 'common', '44', NULL, NULL),
('no_car_query', '無牌查詢', 'common', '87', NULL, NULL),
('pot', '车位', 'common', '86', NULL, NULL),
('pot', 'Pot', 'common', '44', NULL, NULL),
('pot', '車位', 'common', '87', NULL, NULL),
('ud_online_time', '在线时长', 'common', '86', NULL, NULL),
('ud_online_time', 'Online Time', 'common', '44', NULL, NULL),
('ud_online_time', '在線時長', 'common', '87', NULL, NULL),
('ud_outline_time', '离线时长', 'common', '86', NULL, NULL),
('ud_outline_time', 'Outline Time', 'common', '44', NULL, NULL),
('ud_outline_time', '離線時長', 'common', '87', NULL, NULL),
('searchLoaction', '查看位置', 'common', '87', NULL, NULL),
('setnum', '設備編號', 'common', '87', NULL, NULL),

('outline_situation', '离线情况', 'common', '86', NULL, NULL),
('outline_situation', 'Outline Situation', 'common', '44', NULL, NULL),
('outline_situation', '離線情況', 'common', '87', NULL, NULL),

('direction_displen', '各方向显示长度', 'common', '86', NULL, NULL),
('direction_displen', 'Direction DispLen', 'common', '44', NULL, NULL),
('direction_displen', '各方向顯示長度', 'common', '87', NULL, NULL),

('map_create_tip_fla', 'FLA文件和SWF文件必须命名相同', 'common', '86', NULL, NULL),
('map_create_tip_fla', 'The FLA file and the SWF file must be named the same', 'common', '44', NULL, NULL),
('map_create_tip_fla', 'FLA文件和SWF文件必須命名相同', 'common', '87', NULL, NULL),
('filename_no_same', '文件名不一致', 'common', '86', NULL, NULL),
('filename_no_same', 'File Name not same', 'common', '44', NULL, NULL),
('filename_no_same', '文件名不一致', 'common', '87', NULL, NULL);
/*!40000 ALTER TABLE `sys_lang_switch` ENABLE KEYS */;


-- Dumping structure for table ips.sys_log
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE IF NOT EXISTS `sys_log` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `act_time` datetime DEFAULT NULL COMMENT '时间',
  `act_user_id` varchar(20) DEFAULT NULL COMMENT '操作用户',
  `act_module_id` varchar(20) DEFAULT NULL COMMENT '操作模块',
  `act_name` varchar(200) DEFAULT NULL COMMENT '操作名称',
  `act_object` varchar(20) DEFAULT NULL COMMENT '操作对象',
  `act_result` varchar(20) DEFAULT NULL COMMENT '操作结果',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户日志表';

-- Dumping data for table ips.sys_log: ~0 rows (approximately)
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;


-- Dumping structure for table ips.sys_role
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE IF NOT EXISTS `sys_role` (
  `id` varchar(32) NOT NULL COMMENT 'id',
  `role_name` varchar(100) DEFAULT NULL COMMENT '权限名称',
  `sort` int(11) DEFAULT NULL COMMENT '顺序',
  `state` varchar(20) DEFAULT NULL COMMENT '状态',
  `remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限表';

-- Dumping data for table ips.sys_role: ~1 rows (approximately)
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` (`id`, `role_name`, `sort`, `state`, `remark`) VALUES
	('20120522133147000001', 'Role1', 222, '1', '');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;


-- Dumping structure for table ips.sys_role_act
DROP TABLE IF EXISTS `sys_role_act`;
CREATE TABLE IF NOT EXISTS `sys_role_act` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `role_id` varchar(20) DEFAULT NULL COMMENT '权限ID',
  `act_id` varchar(20) DEFAULT NULL COMMENT '操作ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限操作表';

-- Dumping data for table ips.sys_role_act: ~14 rows (approximately)
/*!40000 ALTER TABLE `sys_role_act` DISABLE KEYS */;
INSERT INTO `sys_role_act` (`id`, `role_id`, `act_id`) VALUES
	('20120223134228000002', '20120223134228000001', '20110309110734026108'),
	('20120223134228000003', '20120223134228000001', '20110309170545360208'),
	('20120223134228000004', '20120223134228000001', '20110309110822694110'),
	('20120223134228000005', '20120223134228000001', '20110309170644180211'),
	('20120223134228000006', '20120223134228000001', '20110309160429426124'),
	('20120522134403000011', '20120522133147000001', '20110309110734026108'),
	('20120522134403000012', '20120522133147000001', '20120507142148000001'),
	('20120522134403000013', '20120522133147000001', '20120301184018000001'),
	('20120522134403000014', '20120522133147000001', '20120227102547000001'),
	('20120522134403000015', '20120522133147000001', '20120225155544000001'),
	('20120522134403000016', '20120522133147000001', '20120225162454000001'),
	('20120522134403000017', '20120522133147000001', '20110309170644180211'),
	('20120522134403000018', '20120522133147000001', '20110309170545360208'),
	('20120522134403000019', '20120522133147000001', '20110309160429426124');
/*!40000 ALTER TABLE `sys_role_act` ENABLE KEYS */;


-- Dumping structure for table ips.sys_user
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE IF NOT EXISTS `sys_user` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `user_name` varchar(20) DEFAULT NULL COMMENT '用户名',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `state` varchar(20) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- Dumping data for table ips.sys_user: ~1 rows (approximately)
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` (`id`, `user_name`, `password`, `state`) VALUES
	('1', 'admin', 'C4CA4238A0B923820DCC509A6F75849B', '01');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;


-- Dumping structure for table ips.sys_user_role
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE IF NOT EXISTS `sys_user_role` (
  `id` varchar(20) NOT NULL COMMENT 'id',
  `role_id` varchar(20) DEFAULT NULL COMMENT '权限ID',
  `user_id` varchar(20) DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户权限表';

-- Dumping data for table ips.sys_user_role: ~1 rows (approximately)
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` (`id`, `role_id`, `user_id`) VALUES
	('20120223134228000007', '20120223134228000001', '20120223114216000001');
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;


--
-- Definition of table `p_screenparatemplateheader`
--

DROP TABLE IF EXISTS `p_screenparatemplateheader`;
CREATE TABLE `p_screenparatemplateheader` (
  `id` varchar(20) NOT NULL COMMENT 'ID',
  `name` varchar(20) DEFAULT NULL COMMENT '模板名',
  `screentypecode` varchar(20) DEFAULT NULL COMMENT '屏类型编码',
  `describes` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏参数值模板头表';

--
-- Dumping data for table `p_screenparatemplateheader`
--

/*!40000 ALTER TABLE `p_screenparatemplateheader` DISABLE KEYS */;
INSERT INTO `p_screenparatemplateheader` (`id`,`name`,`screentypecode`,`describes`) VALUES 
('20120824120004000001', '24点阵单向屏', '0001', ''),
('20120824120023000002', '24点阵双向屏', '0001', ''),
('20120824120033000003', '24点阵三向屏', '0001', ''),
('20121106164913000001', '32点阵单向组合灯箱', '0001', ''),
('20121106164933000002', '32点阵双向组合灯箱', '0001', ''),
('20121106165001000003', '32点阵三向组合灯箱', '0001', ''),
('20121106165607000052', '32点阵四字条屏', '0001', ''),
('20121106165622000053', '32点阵八字条屏', '0001', ''),
('20121106165638000054', '16点阵四字条屏', '0001', ''),
('20121106165654000055', '16点阵八字条屏', '0001', ''),
('20121106170133000120', '400*200室外灯箱', '0001', ''),
('20121106170151000121', '512*256室外灯箱', '0001', ''),
('20121106170231000122', '640*320室外灯箱', '0001', '');
/*!40000 ALTER TABLE `p_screenparatemplateheader` ENABLE KEYS */;


--
-- Definition of table `p_screenparatemplateline`
--

DROP TABLE IF EXISTS `p_screenparatemplateline`;
CREATE TABLE `p_screenparatemplateline` (
  `ID` varchar(20) NOT NULL COMMENT 'ID',
  `TemplateHeaderID` varchar(20) DEFAULT NULL COMMENT '主表ID',
  `ScreenTypeParaID` varchar(20) DEFAULT NULL COMMENT '参数ID',
  `Value` varchar(100) DEFAULT NULL COMMENT '值',
  PRIMARY KEY (`ID`),
  KEY `FK_screenparatemplateheaderid` (`TemplateHeaderID`),
  CONSTRAINT `FK_screenparatemplateheaderid` FOREIGN KEY (`TemplateHeaderID`) REFERENCES `p_screenparatemplateheader` (`id`) on delete cascade
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏参数值模板细表';

--
-- Dumping data for table `p_screenparatemplateline`
--

/*!40000 ALTER TABLE `p_screenparatemplateline` DISABLE KEYS */;
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES 
('20120824120128000004', '20120824120004000001', '1', 'DB'),
('20120824120128000005', '20120824120004000001', '2', 'DD'),
('20120824120128000006', '20120824120004000001', '3', 'E1'),
('20120824120128000007', '20120824120004000001', '4', '04'),
('20120824120128000008', '20120824120004000001', '5', '00'),
('20120824120128000009', '20120824120004000001', '6', '00'),
('20120824120128000010', '20120824120004000001', '7', '03'),
('20120824120128000011', '20120824120004000001', '8', '00'),
('20120824120128000012', '20120824120004000001', '9', '00'),
('20120824120128000013', '20120824120004000001', '10', '08'),
('20120824120128000014', '20120824120004000001', '11', '02'),
('20120824120128000015', '20120824120004000001', '13', '00'),
('20120824120128000016', '20120824120004000001', '14', '00'),
('20120824120128000017', '20120824120004000001', '15', '02'),
('20120824120128000018', '20120824120004000001', '16', '00'),
('20120824120128000019', '20120824120004000001', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES 
('20120824120242000020', '20120824120023000002', '1', 'DB'),
('20120824120242000021', '20120824120023000002', '2', 'DD'),
('20120824120242000022', '20120824120023000002', '3', 'E1'),
('20120824120242000023', '20120824120023000002', '4', '04'),
('20120824120242000024', '20120824120023000002', '5', '00'),
('20120824120242000025', '20120824120023000002', '6', '00'),
('20120824120242000026', '20120824120023000002', '7', '03'),
('20120824120242000027', '20120824120023000002', '8', '00'),
('20120824120242000028', '20120824120023000002', '9', '00'),
('20120824120242000029', '20120824120023000002', '10', '12'),
('20120824120242000030', '20120824120023000002', '11', '02'),
('20120824120242000031', '20120824120023000002', '13', '00'),
('20120824120242000032', '20120824120023000002', '14', '00'),
('20120824120242000033', '20120824120023000002', '15', '02'),
('20120824120242000034', '20120824120023000002', '16', '00'),
('20120824120242000035', '20120824120023000002', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES 
('20120824120301000036', '20120824120033000003', '1', 'DB'),
('20120824120301000037', '20120824120033000003', '2', 'DD'),
('20120824120301000038', '20120824120033000003', '3', 'E1'),
('20120824120301000039', '20120824120033000003', '4', '04'),
('20120824120301000040', '20120824120033000003', '5', '00'),
('20120824120301000041', '20120824120033000003', '6', '00'),
('20120824120301000042', '20120824120033000003', '7', '03'),
('20120824120301000043', '20120824120033000003', '8', '00'),
('20120824120301000044', '20120824120033000003', '9', '00'),
('20120824120301000045', '20120824120033000003', '10', '18'),
('20120824120301000046', '20120824120033000003', '11', '02'),
('20120824120301000047', '20120824120033000003', '13', '00'),
('20120824120301000048', '20120824120033000003', '14', '00'),
('20120824120301000049', '20120824120033000003', '15', '02'),
('20120824120301000050', '20120824120033000003', '16', '00'),
('20120824120301000051', '20120824120033000003', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165108000004', '20121106164913000001', '1', 'DB'),
('20121106165108000005', '20121106164913000001', '2', 'DD'),
('20121106165108000006', '20121106164913000001', '3', 'E1'),
('20121106165108000007', '20121106164913000001', '4', '04'),
('20121106165108000008', '20121106164913000001', '5', '00'),
('20121106165108000009', '20121106164913000001', '6', '00'),
('20121106165108000010', '20121106164913000001', '7', '03'),
('20121106165108000011', '20121106164913000001', '8', '00'),
('20121106165108000012', '20121106164913000001', '9', '00'),
('20121106165108000013', '20121106164913000001', '10', '10'),
('20121106165108000014', '20121106164913000001', '11', '02'),
('20121106165108000015', '20121106164913000001', '13', '00'),
('20121106165108000016', '20121106164913000001', '14', '00'),
('20121106165108000017', '20121106164913000001', '15', '01'),
('20121106165108000018', '20121106164913000001', '16', '00'),
('20121106165108000019', '20121106164913000001', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165130000020', '20121106164933000002', '1', 'DB'),
('20121106165130000021', '20121106164933000002', '2', 'DD'),
('20121106165130000022', '20121106164933000002', '3', 'E1'),
('20121106165130000023', '20121106164933000002', '4', '04'),
('20121106165130000024', '20121106164933000002', '5', '00'),
('20121106165130000025', '20121106164933000002', '6', '00'),
('20121106165130000026', '20121106164933000002', '7', '03'),
('20121106165130000027', '20121106164933000002', '8', '00'),
('20121106165130000028', '20121106164933000002', '9', '00'),
('20121106165130000029', '20121106164933000002', '10', '18'),
('20121106165130000030', '20121106164933000002', '11', '02'),
('20121106165130000031', '20121106164933000002', '13', '00'),
('20121106165130000032', '20121106164933000002', '14', '00'),
('20121106165130000033', '20121106164933000002', '15', '01'),
('20121106165130000034', '20121106164933000002', '16', '00'),
('20121106165130000035', '20121106164933000002', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165157000036', '20121106165001000003', '1', 'DB'),
('20121106165157000037', '20121106165001000003', '2', 'DD'),
('20121106165157000038', '20121106165001000003', '3', 'E1'),
('20121106165157000039', '20121106165001000003', '4', '04'),
('20121106165157000040', '20121106165001000003', '5', '00'),
('20121106165157000041', '20121106165001000003', '6', '00'),
('20121106165157000042', '20121106165001000003', '7', '03'),
('20121106165157000043', '20121106165001000003', '8', '00'),
('20121106165157000044', '20121106165001000003', '9', '00'),
('20121106165157000045', '20121106165001000003', '10', '28'),
('20121106165157000046', '20121106165001000003', '11', '02'),
('20121106165157000047', '20121106165001000003', '13', '00'),
('20121106165157000048', '20121106165001000003', '14', '00'),
('20121106165157000049', '20121106165001000003', '15', '01'),
('20121106165157000050', '20121106165001000003', '16', '00'),
('20121106165157000051', '20121106165001000003', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165734000056', '20121106165607000052', '1', 'DB'),
('20121106165734000057', '20121106165607000052', '2', 'DD'),
('20121106165734000058', '20121106165607000052', '3', 'E1'),
('20121106165734000059', '20121106165607000052', '4', '04'),
('20121106165734000060', '20121106165607000052', '5', '00'),
('20121106165734000061', '20121106165607000052', '6', '00'),
('20121106165734000062', '20121106165607000052', '7', '03'),
('20121106165734000063', '20121106165607000052', '8', '00'),
('20121106165734000064', '20121106165607000052', '9', '00'),
('20121106165734000065', '20121106165607000052', '10', '10'),
('20121106165734000066', '20121106165607000052', '11', '02'),
('20121106165734000067', '20121106165607000052', '13', '00'),
('20121106165734000068', '20121106165607000052', '14', '00'),
('20121106165734000069', '20121106165607000052', '15', '01'),
('20121106165734000070', '20121106165607000052', '16', '00'),
('20121106165734000071', '20121106165607000052', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165811000072', '20121106165622000053', '1', 'DB'),
('20121106165811000073', '20121106165622000053', '2', 'DD'),
('20121106165811000074', '20121106165622000053', '3', 'E1'),
('20121106165811000075', '20121106165622000053', '4', '04'),
('20121106165811000076', '20121106165622000053', '5', '00'),
('20121106165811000077', '20121106165622000053', '6', '00'),
('20121106165811000078', '20121106165622000053', '7', '03'),
('20121106165811000079', '20121106165622000053', '8', '00'),
('20121106165811000080', '20121106165622000053', '9', '00'),
('20121106165811000081', '20121106165622000053', '10', '20'),
('20121106165811000082', '20121106165622000053', '11', '02'),
('20121106165811000083', '20121106165622000053', '13', '00'),
('20121106165811000084', '20121106165622000053', '14', '00'),
('20121106165811000085', '20121106165622000053', '15', '01'),
('20121106165811000086', '20121106165622000053', '16', '00'),
('20121106165811000087', '20121106165622000053', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165837000088', '20121106165638000054', '1', 'DB'),
('20121106165837000089', '20121106165638000054', '2', 'DD'),
('20121106165837000090', '20121106165638000054', '3', 'E1'),
('20121106165837000091', '20121106165638000054', '4', '04'),
('20121106165837000092', '20121106165638000054', '5', '00'),
('20121106165837000093', '20121106165638000054', '6', '00'),
('20121106165837000094', '20121106165638000054', '7', '03'),
('20121106165837000095', '20121106165638000054', '8', '00'),
('20121106165837000096', '20121106165638000054', '9', '00'),
('20121106165837000097', '20121106165638000054', '10', '08'),
('20121106165837000098', '20121106165638000054', '11', '02'),
('20121106165837000099', '20121106165638000054', '13', '00'),
('20121106165837000100', '20121106165638000054', '14', '00'),
('20121106165837000101', '20121106165638000054', '15', '00'),
('20121106165837000102', '20121106165638000054', '16', '00'),
('20121106165837000103', '20121106165638000054', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106165902000104', '20121106165654000055', '1', 'DB'),
('20121106165902000105', '20121106165654000055', '2', 'DD'),
('20121106165902000106', '20121106165654000055', '3', 'E1'),
('20121106165902000107', '20121106165654000055', '4', '04'),
('20121106165902000108', '20121106165654000055', '5', '00'),
('20121106165902000109', '20121106165654000055', '6', '00'),
('20121106165902000110', '20121106165654000055', '7', '03'),
('20121106165902000111', '20121106165654000055', '8', '00'),
('20121106165902000112', '20121106165654000055', '9', '00'),
('20121106165902000113', '20121106165654000055', '10', '10'),
('20121106165902000114', '20121106165654000055', '11', '02'),
('20121106165902000115', '20121106165654000055', '13', '00'),
('20121106165902000116', '20121106165654000055', '14', '00'),
('20121106165902000117', '20121106165654000055', '15', '00'),
('20121106165902000118', '20121106165654000055', '16', '00'),
('20121106165902000119', '20121106165654000055', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106170353000123', '20121106170133000120', '1', 'DB'),
('20121106170353000124', '20121106170133000120', '2', 'DD'),
('20121106170353000125', '20121106170133000120', '3', 'E1'),
('20121106170353000126', '20121106170133000120', '4', '04'),
('20121106170353000127', '20121106170133000120', '5', '00'),
('20121106170353000128', '20121106170133000120', '6', '00'),
('20121106170353000129', '20121106170133000120', '7', '03'),
('20121106170353000130', '20121106170133000120', '8', '04'),
('20121106170353000131', '20121106170133000120', '9', '00'),
('20121106170353000132', '20121106170133000120', '10', '04'),
('20121106170353000133', '20121106170133000120', '11', '02'),
('20121106170353000134', '20121106170133000120', '13', '00'),
('20121106170353000135', '20121106170133000120', '14', '00'),
('20121106170353000136', '20121106170133000120', '15', '00'),
('20121106170353000137', '20121106170133000120', '16', '00'),
('20121106170353000138', '20121106170133000120', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106170414000139', '20121106170151000121', '1', 'DB'),
('20121106170414000140', '20121106170151000121', '2', 'DD'),
('20121106170414000141', '20121106170151000121', '3', 'E1'),
('20121106170414000142', '20121106170151000121', '4', '04'),
('20121106170414000143', '20121106170151000121', '5', '00'),
('20121106170414000144', '20121106170151000121', '6', '00'),
('20121106170414000145', '20121106170151000121', '7', '03'),
('20121106170414000146', '20121106170151000121', '8', '05'),
('20121106170414000147', '20121106170151000121', '9', '00'),
('20121106170414000148', '20121106170151000121', '10', '04'),
('20121106170414000149', '20121106170151000121', '11', '02'),
('20121106170414000150', '20121106170151000121', '13', '00'),
('20121106170414000151', '20121106170151000121', '14', '00'),
('20121106170414000152', '20121106170151000121', '15', '00'),
('20121106170414000153', '20121106170151000121', '16', '00'),
('20121106170414000154', '20121106170151000121', '17', '00');
INSERT INTO `p_screenparatemplateline` (`ID`,`TemplateHeaderID`,`ScreenTypeParaID`,`Value`) VALUES
('20121106170440000155', '20121106170231000122', '1', 'DB'),
('20121106170440000156', '20121106170231000122', '2', 'DD'),
('20121106170440000157', '20121106170231000122', '3', 'E1'),
('20121106170440000158', '20121106170231000122', '4', '04'),
('20121106170440000159', '20121106170231000122', '5', '00'),
('20121106170440000160', '20121106170231000122', '6', '00'),
('20121106170440000161', '20121106170231000122', '7', '03'),
('20121106170440000162', '20121106170231000122', '8', '06'),
('20121106170440000163', '20121106170231000122', '9', '00'),
('20121106170440000164', '20121106170231000122', '10', '04'),
('20121106170440000165', '20121106170231000122', '11', '02'),
('20121106170440000166', '20121106170231000122', '13', '00'),
('20121106170440000167', '20121106170231000122', '14', '00'),
('20121106170440000168', '20121106170231000122', '15', '00'),
('20121106170440000169', '20121106170231000122', '16', '00'),
('20121106170440000170', '20121106170231000122', '17', '00');
/*!40000 ALTER TABLE `p_screenparatemplateline` ENABLE KEYS */;


drop table if exists p_colortacticstask;
/*==============================================================*/
/* Table: p_colortacticstask                                    */
/*==============================================================*/
create table p_colortacticstask
(
   id                   varchar(20) not null comment 'id',
   controllerId         varchar(20) comment '管理器ID',
   screens 				varchar(500) default null comment '屏编码字符串，如P00001，P00117',
   colorvalues 			varchar(500) default null comment '变色值字符串，如5,20；10,30；',
   redcount             int(11) comment '变红色临界',
   yellowpercent        int(11) comment '变黄色临界百分比',
   operator             varchar(20) comment '发布人',
   createtime           datetime comment '发布时间',
   runstate             char(1) default '0' comment '任务执行状态(0停止 1执行中)',
   notes                varchar(200) comment '备注',
   primary key (id),
   KEY `FK_colortactics_controllerId` (`controllerId`),
   CONSTRAINT `FK_colortactics_controllerId` FOREIGN KEY (`controllerId`) REFERENCES `p_controller` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏变色策略任务表';


drop table if exists p_colortacticstaskhistory;
/*==============================================================*/
/* Table: p_colortacticstaskhistory                             */
/*==============================================================*/
create table p_colortacticstaskhistory
(
   id                   varchar(20) not null comment 'id',
   controllerId         varchar(20) comment '管理器ID',
   screens 				varchar(500) default null comment '屏编码字符串，如P00001，P00117',
   colorvalues 			varchar(500) default null comment '变色值字符串，如5,20；10,30；',
   redcount             int(11) comment '变红色临界',
   yellowpercent        int(11) comment '变黄色临界百分比',
   operator             varchar(20) comment '发布人',
   createtime           datetime comment '发布时间',
   executeTime           datetime comment '执行时间',
   success              char(1) comment '是否执行成功(1成功0失败)',
   notes                varchar(200) comment '备注',
   duration int(11) DEFAULT NULL COMMENT '执行时长',
   primary key (id),
   unique key AK_Key_colortacticstask (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏变色策略任务执行历史表';



drop table if exists p_alarmservicebase;

/*==============================================================*/
/* Table: p_alarmservicebase                                    */
/*==============================================================*/
create table p_alarmservicebase
(
   id                   varchar(20) not null comment 'ID',
   mobilephone          varchar(20) comment '手机号码',
   noticeway            char(1) comment '通知方式(1 短信猫 2网络)',
   enabledflag          char(1) default '0' comment '是否启用',
   describes            varchar(200) comment '备注',
   attribute1           varchar(50) comment 'attribute1',
   attribute2           varchar(50) comment 'attribute2',
   attribute3           varchar(50) comment 'attribute3',
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='报警服务基础信息表';

INSERT INTO `p_alarmservicebase` (`id`,`mobilephone`,`noticeway`,`describes`) VALUES 
 ('20121013120301000038','','1','');




drop table if exists p_alarmservicecentre;

/*==============================================================*/
/* Table: p_alarmservicecentre                                  */
/*==============================================================*/
create table p_alarmservicecentre
(
   id                   varchar(20) not null comment 'ID',
   deviceid             varchar(20) comment '设备ID',
   devicetype           char(1) comment '设备类型(1管理器 2显示屏 3探测器)',
   alarmmessage         varchar(200) comment '报警信息',
   mobilephone          varchar(20) comment '手机号码',
   noticeway            char(1) comment '通知方式(1 短信猫 2网络)',
   isneedsend           char(1) comment '是否需要发送短信',
   alreadysend          char(1) default '0' comment '是否已发送短信(0 未发 1已发)',
   describes            varchar(200) comment '备注',
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='报警服务中心表';



drop table if exists p_costomdebugtask;

/*==============================================================*/
/* Table: p_costomdebugtask                                     */
/*==============================================================*/
create table p_costomdebugtask
(
   id                   varchar(20) not null comment 'id',
   taskname             varchar(100) comment '任务名称',
   funcode              int(11) comment '功能码',
   senddata1            varchar(2) comment '发送字节1',
   senddata2            varchar(2) comment '发送字节2',
   senddata3            varchar(2) comment '发送字节3',
   senddata4            varchar(2) comment '发送字节4',
   senddata5            varchar(2) comment '发送字节5',
   senddata6            varchar(2) comment '发送字节6',
   senddata7            varchar(2) comment '发送字节7',
   senddata8            varchar(2) comment '发送字节8',
   returndata1          varchar(2) comment '接收字节1',
   returndata2          varchar(2) comment '接收字节2',
   returndata3          varchar(2) comment '接收字节3',
   returndata4          varchar(2) comment '接收字节4',
   returndata5          varchar(2) comment '接收字节5',
   returndata6          varchar(2) comment '接收字节6',
   returndata7          varchar(2) comment '接收字节7',
   returndata8          varchar(2) comment '接收字节8',
   notes                varchar(200) comment '备注',
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自定义调试任务';


/*!40000 ALTER TABLE `p_costomdebugtask` DISABLE KEYS */;
INSERT INTO `p_costomdebugtask` (`id`,`taskname`,`funcode`,`senddata1`,`senddata2`,`senddata3`,`senddata4`,`senddata5`,`senddata6`,`senddata7`,`senddata8`,`returndata1`,`returndata2`,`returndata3`,`returndata4`,`returndata5`,`returndata6`,`returndata7`,`returndata8`,`notes`) VALUES 
 ('20121205131552000173','复位管理器',0,'22','00','00','00','00','00','00','00','22','00','00','00','00','00','00','00','通过上位机软件复位管理器'),
 ('20121205131843000174','自动设置探头高度',5,'80','AB','FF','00','00','00','00','00','60','01','00','00','00','00','00','00','SD3=\'FF\'表示广播，如果要设置具体某个探头的高度，只需把SD3改成对应探头的编号即可');
/*!40000 ALTER TABLE `p_costomdebugtask` ENABLE KEYS */;


drop table if exists p_debugtasklist;

/*==============================================================*/
/* Table: p_debugtasklist                                       */
/*==============================================================*/
create table p_debugtasklist
(
   id                   varchar(20) not null comment 'id',
   controllerId         varchar(20) comment '管理器ID',
   taskname             varchar(100) comment '任务名称',
   funcode              int(11) comment '功能码',
   sendcontent          varchar(200) comment '发送内容',
   expectreturn         varchar(200) comment '期待返回',
   operator             varchar(20) comment '发布人',
   createtime           datetime comment '发布时间',
   runstate             char(1) default '0' comment '任务执行状态(0停止 1执行中)',
   notes                varchar(200) comment '备注',
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='调试任务列表';



drop table if exists p_debugtaskhistory;

/*==============================================================*/
/* Table: p_debugtaskhistory                                    */
/*==============================================================*/
create table p_debugtaskhistory
(
   id                   varchar(20) not null comment 'id',
   controllerId         varchar(20) comment '管理器ID',
   taskname             varchar(100) comment '任务名称',
   funcode              int(11) comment '功能码',
   sendcontent          varchar(200) comment '发送内容',
   expectreturn         varchar(200) comment '期待返回',
   realreturn           varchar(200) comment '实际返回',
   operator             varchar(20) comment '发布人',
   createtime           datetime comment '发布时间',
   executeTime          datetime comment '执行时间',
   duration             int(11) comment '执行时长',
   success              char(1) comment '是否执行成功(1成功0失败)',
   notes                varchar(200) comment '备注',
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='调试任务历史表';

-- ----------------------------
-- Table structure for `sysextrainfo`
-- ----------------------------
DROP TABLE IF EXISTS `sysextrainfo`;
CREATE TABLE `sysextrainfo` (
  `SysID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '系统id，自增',
  `SysCode` varchar(80) CHARACTER SET utf8 DEFAULT NULL COMMENT '系统编号，用于识别对应客户',
  `F_DataCenterID` char(6) CHARACTER SET utf8 DEFAULT NULL COMMENT '数据中心代码',
  `SysType` varchar(15) CHARACTER SET utf8 DEFAULT NULL COMMENT '系统类型',
  `CurrentVerNo` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '当前软件版本号',
  `WaitingVerNo` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '待更新软件版本号',
  `State` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '更新状态',
  `CurrentDt` datetime DEFAULT NULL COMMENT '本次更新时间',
  `LastDt` datetime DEFAULT NULL COMMENT '上次更新时间',
  PRIMARY KEY (`SysID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统附加信息表';

-- ----------------------------
-- Table structure for `upgradehis`
-- ----------------------------
DROP TABLE IF EXISTS `upgradehis`;
CREATE TABLE `upgradehis` (
  `VerID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '更新历史记录id',
  `VerNo` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '版本号',
  `SysID` int(10) unsigned NOT NULL COMMENT '系统id',
  `UploadState` smallint(5) unsigned DEFAULT NULL COMMENT '上传状态',
  `UpgradeState` smallint(5) unsigned DEFAULT NULL COMMENT '更新状态',
  `VerDes` varchar(500) CHARACTER SET utf8 DEFAULT NULL COMMENT '更新描述',
  `CreatedDt` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`VerID`),
  KEY `SysID` (`SysID`),
  CONSTRAINT `upgradehis_ibfk_1` FOREIGN KEY (`SysID`) REFERENCES `sysextrainfo` (`SysID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='更新历史表';

-- ----------------------------
-- View structure for `carofallandavailable`
-- ----------------------------
DROP VIEW IF EXISTS `carofallandavailable`;
CREATE ALGORITHM=UNDEFINED DEFINER=`ips`@`localhost` SQL SECURITY INVOKER VIEW `carofallandavailable` AS select count(0) AS `total`,(select count(0) from (`p_detector` `pd` join `p_parkingspace` `ps` on((`pd`.`id` = `ps`.`detectorId`))) where ((`pd`.`status` = '0') and (`pd`.`enable` = '1') and (`ps`.`inuse` = '0') and (`ps`.`enable` = '1') and (`ps`.`spotTypeNow` = '0'))) AS `avai` from `p_detector` ;

-- ----------------------------
-- View structure for `caroflogicarea`
-- ----------------------------
DROP VIEW IF EXISTS `caroflogicarea`;
CREATE ALGORITHM=UNDEFINED DEFINER=`ips`@`localhost` SQL SECURITY INVOKER VIEW `caroflogicarea` AS select `pg`.`name` AS `logicareaname`,`pg`.`code` AS `logicareacode`,`pg`.`id` AS `logicareaid`,(select count(0) from (`p_detector` `pd` join `p_parkingspace` `pp` on((`pd`.`id` = `pp`.`detectorId`))) where ((`pd`.`guideRegionId` = `pg`.`id`) or (`pd`.`guideRegionId` = NULL))) AS `total`,(select count(0) from (`p_detector` `pd` join `p_parkingspace` `pp` on((`pd`.`id` = `pp`.`detectorId`))) where ((`pd`.`guideRegionId` = `pg`.`id`) or ((`pd`.`guideRegionId` = NULL) and (`pd`.`enable` = '1') and (`pp`.`enable` = '1') and (`pp`.`inuse` = '0') and (`pd`.`status` = '0') and (`pp`.`spotTypeNow` = '0')))) AS `avai` from `p_guideregion` `pg` group by `pg`.`name` ;


drop table if exists p_pathnodeinfohead;

/*==============================================================*/
/* Table: p_pathnodeinfohead                                    */
/*==============================================================*/
create table p_pathnodeinfohead
(
   ID                   varchar(20) not null comment '节点ID',
   mapId                varchar(20) comment '地图ID',
   code                 varchar(50) comment '节点编号',
   name                 varchar(50) comment '节点名称',
   x_axis               decimal(11,2) comment 'X坐标值',
   y_axis               decimal(11,2) comment 'Y坐标值',
   ifcarsearchpc        char(1) comment '是否查询机(1为查车机；0为普通的路径节点)',
   IP                   varchar(50) comment 'IP地址',
   note                 varchar(100) comment '备注',
   status				  char(1) comment '查询机是否离线（1为离线，0为在线）',
   primary key (ID),
   key AK_Key_code_mapid (mapId, code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='路径节点信息主表';



drop table if exists p_pathnodeinfoline;

/*==============================================================*/
/* Table: p_pathnodeinfoline                                    */
/*==============================================================*/
create table p_pathnodeinfoline
(
   ID                   varchar(20) not null comment 'ID',
   headid               varchar(20) not null comment '主表节点ID',
   code                 varchar(50) comment '可达节点编号',
   pathweights          decimal(11,2) comment '路径权值',
   note                 varchar(100) comment '备注',
   primary key (ID),
   constraint FK_Reference_Pathnodeinfo foreign key (headid)
      references p_pathnodeinfohead (ID)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='路径节点信息从表';





drop table if exists p_screenparamcomment;

/*==============================================================*/
/* Table: p_screenparamcomment                                  */
/*==============================================================*/
create table p_screenparamcomment
(
   code_type            varchar(50) comment '类型',
   code_key             varchar(50) comment '参数关键字',
   code_name            varchar(50) comment '参数名称',
   code_value           varchar(100) comment '参数值',
   lang                 varchar(10) comment '语言版本（44英文 86中文简体 87繁体）',
   orderby              int(10) comment '排序号',
   note                 varchar(100) comment '备注',
   key AK_code_type_code_key_code_name_lang (code_type, code_key, code_name, lang)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='引导屏参数值注释表';



drop table if exists p_shortestpathinofhead;

/*==============================================================*/
/* Table: p_shortestpathinofhead                                */
/*==============================================================*/
create table p_shortestpathinofhead
(
   ID                   varchar(20) not null comment 'ID',
   mapId                varchar(20) comment '地图ID',
   start                varchar(20) comment '起点ID',
   end                  varchar(20) comment '终点ID',
   weight 				decimal(10,2) comment '路径长度',
   note                 varchar(100) comment '备注',
   primary key (ID),
   key AK_p_shortestpathinofhead_mapid_start_end (mapId, start, end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='最短路径信息主表';



drop table if exists p_shortestpathinofline;

/*==============================================================*/
/* Table: p_shortestpathinofline                                */
/*==============================================================*/
create table p_shortestpathinofline
(
   ID                   varchar(20) not null comment 'ID',
   headid               varchar(20) comment '主表ID',
   pointid              varchar(20) comment '端点ID',
   sort                 int(11) comment '序号',
   note                 varchar(100) comment '备注',
   primary key (ID),
   constraint FK_p_shortestpathinofhead_ID foreign key (headid)
      references p_shortestpathinofhead (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='最短路径信息从表';


drop table if exists p_advertbaseinfo;

/*==============================================================*/
/* Table: p_advertbaseinfo                                      */
/*==============================================================*/
create table p_advertbaseinfo
(
   ID                   varchar(20) not null comment 'ID',
   advertName           varchar(50) comment '广告文件名',
   advertSrc            varchar(200) comment '广告文件所在路径',
   advertType           varchar(50) comment '广告文件类型',
   inuse                char(1) comment '是否启用(0表示不启用,1表示启用)',
   updateDate           datetime comment '最后更新时间',
   playTime             int(11) comment '播放时间(秒)',
   advertPosition       char(1) comment '广告放置的位置(0表示寻车首页,1表示查询界面下方的广告)',
   primary key (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告基础信息表';

-- ----------------------------
-- Records of p_advertbaseinfo
-- ----------------------------
INSERT INTO `p_advertbaseinfo` VALUES ('20130812141646000003', '1', '/advertupload/20130812141646.jpg', 'image/pjpeg', '0', '2013-08-12 14:16:46', '10', '0');
INSERT INTO `p_advertbaseinfo` VALUES ('20130812141653000004', 'advert3', '/advertupload/20130812141653.jpg', 'image/pjpeg', '0', '2013-08-12 14:16:53', '10', '1');
INSERT INTO `p_advertbaseinfo` VALUES ('20140217085015000011', '广告3', '/advertupload/20140217085015.jpg', 'image/jpeg', '1', '2014-02-17 08:50:15', '3', '0');
INSERT INTO `p_advertbaseinfo` VALUES ('20140217085019000012', '广告2', '/advertupload/20140217085019.jpg', 'image/jpeg', '1', '2014-02-17 08:50:19', '3', '0');
INSERT INTO `p_advertbaseinfo` VALUES ('20140217085022000013', '广告1', '/advertupload/20140217085022.jpg', 'image/jpeg', '1', '2014-02-17 08:50:22', '3', '0');
INSERT INTO `p_advertbaseinfo` VALUES ('20140217085042000014', '广告4', '/advertupload/20140217085042.jpg', 'image/jpeg', '1', '2014-02-17 08:50:42', '3', '1');

drop table if exists t_screencontent;

/*==============================================================*/
/* Table: t_screencontent                                       */
/*==============================================================*/
create table t_screencontent
(
   addr                 varchar(50) not null comment '屏地址',
   grpAddr              varchar(50) not null comment '组地址',
   areanum1             varchar(10) comment '屏区域数字一',
   areanum2             varchar(10) comment '屏区域数字二',
   areanum3             varchar(10) comment '屏区域数字三',
   content              varchar(100) comment '所有数据信息',
   primary key (grpAddr, addr)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='引导屏显示信息测试表';


drop table if exists sys_operator_log;
/*==============================================================*/
/* Table: sys_operator_log                                      */
/*==============================================================*/
create table sys_operator_log
(
   ID                   varchar(20) not null comment 'ID',
   userID                varchar(20) comment '用户ID',
   operationType        varchar(50) comment '操作类型',
   operationTime        datetime comment '操作时间',
   description          varchar(50) comment '描述',
   result               varchar(10) comment '操作结果',
   exceptionInfo        varchar(200) comment '异常信息',
   menuID               varchar(20) comment '功能菜单ID',
   userIp           	varchar(20) comment '用户IP(本机用localhost)',
   attribute2           varchar(20) comment '备用字段2',
   attribute3           varchar(20) comment '备用字段3',
   primary key (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统操作日记表';


-- ----------------------------
-- Table structure for `p_searchmachine`
-- ----------------------------
DROP TABLE IF EXISTS `p_searchmachine`;
CREATE TABLE `p_searchmachine` (
  `id` varchar(255) NOT NULL,
  `machine` varchar(255) default NULL,
  `searchMethod` varchar(255) default NULL,
  `useDateTime` varchar(255) default NULL,
  `searchRoute` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_searchmachine_machine` (`machine`),
  KEY `idx_searchmachine_searchMethod` (`searchMethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='查询机使用统计';

-- ----------------------------
-- Table structure for `p_ctrlerConnState`
-- ----------------------------
DROP TABLE IF EXISTS `p_ctrlerConnState`;
create TABLE `p_ctrlerConnState` (
	`id` int not null auto_increment primary key comment '创建主键', 
	`ctrlId` varchar(20) not null comment  '探测器ID,p_controller.id',
	`macAddr` varchar(20) not null comment '探测器Mac地址,p_controller.addr',
	`dateTime` datetime not null  comment '插入日志时间',
	`connType` char(1) not null comment '连接状态类型,0-上线,1-离线,2-异常断连,3-3分钟连不上主动做离线操作',
	`connDesc` varchar(250) comment '状态描述'
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器基本连接状态记录日志';

-- ----------------------------
-- Table structure for `p_ctrlerstatus`
-- ----------------------------
DROP TABLE IF EXISTS `p_ctrlerstatus`;
CREATE TABLE `p_ctrlerstatus` (
  `id` int not null auto_increment primary key comment '创建主键',
  `macAddr` varchar(20) not null comment '探测器地址,p_controller.addr',
  `dateTime` datetime not null comment '记录的时间点',
  `status` char(1) not null comment '探测器状态,0-上线,1-离线',
  `type` char(1) DEFAULT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探测器状态信息日志';


